2975 上式代入9.84式，可得：

 $$ \nabla\cdot\vec{\boldsymbol{S}}=-\frac{\partial w}{\partial t}-\vec{\boldsymbol{E}}\cdot\vec{\boldsymbol{J}}_{0}=-\frac{\partial w}{\partial t}+\frac{\partial w}{\partial t}+\nabla\cdot(\vec{\boldsymbol{E}}\times\vec{\boldsymbol{H}})=\nabla\cdot(\vec{\boldsymbol{E}}\times\vec{\boldsymbol{H}}) $$ 

2976 可知，若取：

 $$ \vec{S}=\vec{E}\times\vec{H} $$ 

则  $ \vec{S} $ 将满足由能量守恒要求得到的上述9.91式。

根据9.92式，我们可以分析常见的电路元器件中电磁场的能量流动的方向，下图列出了几种常见元器件的  $ \vec{E} $ 、 $ \vec{B} $ 和  $ \vec{S} $ 的方向示意图：

<div style="text-align: center;"><img src="imgs/img_in_image_box_209_583_358_784.jpg" alt="Image" width="12%" /></div>


<div style="text-align: center;">电池放电</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_409_599_527_770.jpg" alt="Image" width="9%" /></div>


电阻

<div style="text-align: center;"><img src="imgs/img_in_image_box_593_555_776_818.jpg" alt="Image" width="15%" /></div>


<div style="text-align: center;">电容充电</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_825_563_960_814.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;">电感充电(I增加)</div>


- 对处于放电状态的电池： $ \vec{E} $ 方向与电池内的电流方向相反， $ \vec{B} $ 方向由电流方向根据右手螺旋决定， $ \vec{S} $ 指向电池外，即电磁场能量从电池内部向电池外部流动。

- 对于流有电流的电阻， $ \vec{E} $ 方向与电流方向同向， $ \vec{B} $ 方向由电流方向根据右手螺旋决定， $ \vec{S} $ 指向电阻内，即电磁场能量从电阻外部流向电阻内部，而后在电阻内转化为焦耳热。

- 对于处于充电状态的电容， $ \vec{E} $ 方向为从正极板指向负极板， $ \vec{B} $ 方向由位移电流方向根据右手螺旋决定， $ \vec{S} $ 指向电容器内部，即电磁场能量从外部流向电容器内被储存起来。

- 对于流有电流且电流在增加的线圈（即处于充电状态的电感），在线圈内部附近， $ \vec{B} $ 方向为图中方向向上，此时变化的磁场产生的感生电场  $ \vec{E} $ 的方向与电流方向相反， $ \vec{S} $ 垂直于线圈的轴线指向电感内部，即电磁场能量从外部流向电感内被储存起来。

对于本章中讨论的平面电磁波而言，根据上一节的结论，平面电磁波的波矢  $ \vec{k} $ 的方向（即电磁波的传播方向）与  $ \vec{E} $ 和  $ \vec{B} $ 成右手法则关系，因而空间中任意一点的能流密度矢量  $ \vec{S} = \vec{E} \times \vec{H} $ 的方向与电磁波的传播方向相同，又由平面电磁波中  $ \vec{E} $ 和  $ \vec{B} $ 的关系（9.75），可知  $ \vec{S} $ 的大小为：

 $$ S=EH=\frac{E^{2}}{v\mu}=\varepsilon vE^{2} $$ 

2994 对于单一频率的电磁波，其  $ \vec{E} $ 和  $ \vec{B} $ 均随时间做简谐变化，我们把上述能流密度矢量的大小在