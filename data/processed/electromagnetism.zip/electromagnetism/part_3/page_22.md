2736 量，在 dt 时间内，非静电力做功为：

 $$ \mathrm{d}A_{m}=\mathcal{E}_{L}I\mathrm{d}t=-L\frac{\mathrm{d}I}{\mathrm{d}t}I\mathrm{d}t=-L I\mathrm{d}I $$ 

2737 因此，线圈中的磁场能量为：

 $$ W_{m}=\int\mathrm{d}A_{m}=-\int_{I}^{0}L I\mathrm{d}I=\frac{1}{2}L I^{2} $$ 

上式中我们得到的，是线圈产生的磁场的总能量。与电场类似，该总能量分布在所有磁场存在的空间，那我们能否像静电场的  $ w_e = \frac{1}{2} \vec{D} \cdot \vec{E} $ 那样，找出磁场的能量密度呢？我们不妨计算最简单的情形，即单个线圈（即单个闭合电流回路）产生的磁场对应的能量密度，对于单个闭合电流回路产生的磁场，我们可以用这个闭合回路的磁通量  $ \Phi $ 代替上式中的  $ LI $，可得：

 $$ W_{m}=\frac{1}{2}\Phi I $$ 

2742 将  $ \Phi $ 写成磁场面积分的形式，可得：

 $$ W_{m}=\frac{1}{2}I\iint_{S}\vec{B}\cdot\vec{S} $$ 

2743 利用  $ \vec{B} = \nabla \times \vec{A} $，上式可写成：

 $$ W_{m}=\frac{1}{2}I\iint_{S}(\nabla\times\vec{A})\cdot\vec{\boldsymbol{S}}=\frac{1}{2}\oint_{L}\vec{A}\cdot I\mathrm{d}\vec{l} $$ 

2744 将  $ I d \vec{l} $ 写成电流密度体积分  $ \vec{J} d V $ 的形式，可得：

 $$ W_{m}=\frac{1}{2}\iiint_{V}\vec{A}\cdot\vec{J}\mathrm{d}V $$ 

2745 将  $ \nabla \times \vec{B} = \mu_0 \vec{J} $ 代入上式，可得：

 $$ W_{m}=\frac{1}{2\mu_{0}}\iiint_{V}\vec{A}\cdot(\nabla\times\vec{B})\mathrm{d}V $$ 

2746 利用散度的叉乘恒等式  $ \nabla \cdot (\vec{A} \times \vec{B}) = \vec{B} \cdot (\nabla \times \vec{A}) - \vec{A} \cdot (\nabla \times \vec{B}) $，上式可写成：

 $$ \begin{aligned}W_{m}&=\frac{1}{2\mu_{0}}\Big[\iiint_{V}\vec{B}\cdot(\nabla\times\vec{A})\mathrm{d}V-\iiint_{V}\nabla\cdot(\vec{A}\times\vec{B})\mathrm{d}V\Big]\\&=\frac{1}{2\mu_{0}}\Big[\iiint_{V}\vec{B}\cdot\vec{B}\mathrm{d}V-\iint_{S}(\vec{A}\times\vec{B})\cdot\mathrm{d}\vec{S}\Big]\end{aligned} $$ 

2747 其中 S 为包围体积 V 的闭合曲面，由于积分空间在全空间，因此 S 为包围全空间的闭合曲面，即  $ r \to \infty $，当  $ r \to \infty $ 时， $ \vec{A} \times \vec{B} $ 的衰减速度快于  $ 1/r^2 $，因而上式第二项积分为零，即：

 $$ W_{m}=\frac{1}{2\mu_{0}}\iiint_{V}B^{2}\mathrm{d}V $$ 