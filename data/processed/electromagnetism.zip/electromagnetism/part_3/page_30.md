2866 因此：

 $$ B=\begin{cases}\frac{\mu_{0}I r}{2\pi R^{2}},&r<R,\\\frac{\mu_{0}I}{2\pi r},&r>R.\end{cases} $$ 

### 9.2 麦克斯韦方程组

麦克斯韦总结了库仑、安培和法拉第等人的电磁学研究成果，将真空中的电场和磁场的基本规律（电场的高斯定理、包含感应电场的环路定理，磁场的高斯定理、包含位移电流的环路定理）总结成了四个基本方程，我们把这四个方程，称为麦克斯韦方程组：

 $$ \nabla\cdot\vec{E}=\frac{\rho}{\varepsilon_{0}} $$ 

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t} $$ 

 $$ \nabla\cdot\vec{B}=0 $$ 

 $$ \nabla\times\vec{B}=\mu_{0}\bigg(\vec{J}+\varepsilon_{0}\frac{\partial\vec{E}}{\partial t}\bigg) $$ 

上述方程组对应的积分形式为：

 $$ \iint_{S}\vec{E}\cdot\mathrm{d}\vec{S}=\iiint_{V}\frac{\rho}{\varepsilon_{0}}\mathrm{d}V $$ 

 $$ \oint_{L}\vec{E}\cdot\mathrm{d}\vec{l}=-\iint_{S}\frac{\partial\vec{B}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

 $$ \iint_{S}\vec{B}\cdot\mathrm{d}\vec{S}=0 $$ 

 $$ \oint_{L}\vec{B}\cdot\mathrm{d}\vec{l}=\mu_{0}\iint_{S}\left(\vec{J}+\varepsilon_{0}\frac{\partial\vec{E}}{\partial t}\right)\cdot\mathrm{d}\vec{S} $$ 

麦克斯韦通过上述方程组，统一了电场和磁场，完善了宏观的电磁场理论。上述四个微分方程，加上电场和磁场在分界面上的边值关系，以及电场和磁场在介质内的介质方程，联合求解便可以解决电磁场的一般问题：

1. 边值关系：

 $$ E_{\tau1}=E_{\tau2} $$ 

 $$ D_{n1}-D_{n2}=\sigma_{0} $$ 

 $$ H_{\tau1}-H_{\tau2}=(\vec{K}_{0}\times\vec{n})\cdot\hat{\tau} $$ 

 $$ B_{n1}=B_{n2} $$ 