2611

### 例 8.2

如图所示，有一无限长直线电流，其电流随时间变化的关系为  $ I = I_{0} \sin \omega t $，其中  $ I_{0} $ 和  $ \omega $ 为常数，I > 0 的方向如图中箭头所示竖直向上。在与该直线相距 d 处有一个 N 匝矩形回路，矩形回路与直线电流共面，长和高分别为 a 和 h。求该回路 L 中的感应电动势（顺时针方向为 L 的正方向）。

<div style="text-align: center;"><img src="imgs/img_in_image_box_794_177_1024_423.jpg" alt="Image" width="19%" /></div>


解:

2612

如图所示进行面积分，可得 t 时刻穿过回路 L 的磁链为：



 $$ \Psi(t)=N\iint_{S}\vec{B}\cdot\mathrm{d}\vec{S}=N\int_{d}^{d+a}\frac{\mu_{0}I}{2\pi x}h\mathrm{d}x=\frac{N\mu_{0}I_{0}h\sin\omega t}{2\pi}\ln\frac{d+a}{d} $$ 

2613 因此，回路 L 中的感应电动势为：

 $$ \mathcal{E}=-\frac{\mathrm{d}\Psi(t)}{\mathrm{d}t}=-\frac{N\mu_{0}I_{0}h\omega\cos\omega t}{2\pi}\ln\frac{d+a}{d} $$ 

2614

### 例 8.3

如图所示，在半径为 R 的区域内有一垂直纸面向内的均匀磁场  $ \vec{B} $，其大小随时间以恒定速率变化，求纸面上任意一点 P 的感生电场  $ \vec{E}_{感} $。

<div style="text-align: center;"><img src="imgs/img_in_image_box_790_772_1029_1001.jpg" alt="Image" width="20%" /></div>


解:

设 P 点与圆心 O 的距离为 r，以 O 为圆心取一半径为 r 的圆周 L，则由法拉第电磁感应定律：

 $$ \oint_{L}\vec{E}_{ 感 }\cdot\mathrm{d}\vec{l}=2\pi rE_{ 感 }=-\frac{\mathrm{d}\Phi}{\mathrm{d}t} $$ 

2615 得：

 $$ E_{ 感 }=-\frac{1}{2\pi r}\frac{\mathrm{d}\Phi}{\mathrm{d}t}=\begin{cases}-\frac{1}{2\pi r}\pi r^{2}\frac{\mathrm{d}B}{\mathrm{d}t}=-\frac{r}{2}\frac{\mathrm{d}B}{\mathrm{d}t},&r<R,\\-\frac{1}{2\pi r}\pi R^{2}\frac{\mathrm{d}B}{\mathrm{d}t}=-\frac{R^{2}}{2r}\frac{\mathrm{d}B}{\mathrm{d}t},&r>R.\end{cases} $$ 

2616  $ \vec{E}_{感} $ 的方向：当  $ \frac{dB}{dt} > 0 $ 时， $ \vec{E}_{感} $ 沿逆时针方向，反之为顺时针方向。