3177 其中， $ \sigma $ 为导体的电导率，其值与电阻率  $ \rho $ 互为倒数。传导电流  $ \dot{J}_{0} $ 不为零但是净电荷密度  $ \rho $ 为零时，麦克斯韦方程组变为：

 $$ \nabla\cdot\vec{E}=0 $$ 

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t} $$ 

 $$ \nabla\cdot\vec{B}=0 $$ 

 $$ \nabla\times\vec{B}=\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}}{\partial t}+\mu_{0}\vec{J}_{0}=\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}}{\partial t}+\mu_{0}\sigma\vec{E} $$ 

3179 刘9.121式水旋度开将9.129式代入，并利用  $ \nabla \times (\nabla \times \vec{E}) = \nabla (\nabla \cdot \vec{E}) - \nabla^2 \vec{E} = -\nabla^2 \vec{E} $，可得：

 $$ -\nabla^{2}\vec{E}=\nabla\times(\nabla\times\vec{E})=-\frac{\partial(\nabla\times\vec{B})}{\partial t}=-\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}}-\mu_{0}\sigma\frac{\partial\vec{E}}{\partial t} $$ 

3180 即：

 $$ \nabla^{2}\vec{E}=\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}}+\mu_{0}\sigma\frac{\partial\vec{E}}{\partial t} $$ 

3181 类似的，可得：

 $$ \nabla^{2}\vec{B}=\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{B}}{\partial t^{2}}+\mu_{0}\sigma\frac{\partial\vec{B}}{\partial t} $$ 

可知，E 和 B 满足同样的波动方程，只不过上述波动方程与真空中电磁场满足的波动方程不同点在于多了一项对时间的一次求导项。我们不妨假设上述两个方程的解是与真空中电磁波的波函数类似的复指数形式：

 $$ \vec{E}=\vec{E}(\vec{r},t)=\vec{E}_{0}e^{i(\vec{k}_{E}\cdot\vec{r}-\omega_{E}t+\phi_{E})} $$ 

 $$ \vec{B}=\vec{B}(\vec{r},t)=\vec{B}_{0}e^{i(\vec{k}_{B}\cdot\vec{r}-\omega_{B}t+\phi_{B})} $$ 

3185 通过与9.3节类似的方法，我们可以分析出， $ \vec{k}_E = \vec{k}_B = \vec{k} $， $ \omega_E = \omega_B = \omega $，但是两者的相位  $ \phi_E $ 和  $ \phi_B $ 不一定相等，因为，将上式代入9.129式后：

 $$ i\vec{k}\times\vec{B}=-i\omega\mu_{0}\varepsilon_{0}\vec{E}+\mu_{0}\varepsilon_{0}\vec{E} $$ 

3187或者说：

 $$ i\vec{k}\times\vec{B}+i\omega\mu_{0}\varepsilon_{0}\vec{E}=\mu_{0}\varepsilon_{0}\vec{E} $$ 

3188 若  $ \vec{E} $ 和  $ \vec{B} $ 相位相同，则上式可化为：

 $$ i\vec{k}\times\vec{B}_{0}+i\omega\mu_{0}\varepsilon_{0}\vec{E}_{0}=\mu_{0}\varepsilon_{0}\vec{E}_{0} $$ 

3189 很显然，上式中，等式左边为虚数，右边为实数，两者不会相等。因此， $ \vec{E} $ 和  $ \vec{B} $ 的相位不相等：

 $$ \vec{E}=\vec{E}(\vec{r},t)=\vec{E}_{0}e^{i(\vec{k}\cdot\vec{r}-\omega t+\phi_{E})} $$ 

 $$ \vec{B}=\vec{B}(\vec{r},t)=\vec{B}_{0}e^{i(\vec{k}\cdot\vec{r}-\omega t+\phi_{B})} $$ 