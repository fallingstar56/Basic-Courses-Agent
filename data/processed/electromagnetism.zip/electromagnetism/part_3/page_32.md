2895 为：

 $$ \nabla\cdot\vec{E}=0 $$ 

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t} $$ 

 $$ \nabla\cdot\vec{B}=0 $$ 

 $$ \nabla\times\vec{B}=\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}}{\partial t} $$ 

2896 我们发现  $ \vec{E} $ 和  $ \vec{B} $ 具有高度对称性，对9.43式求旋度并将9.45式代入，可得：

 $$ \nabla\times(\nabla\times\vec{E})=-\nabla\times\frac{\partial\vec{B}}{\partial t}=-\frac{\partial(\nabla\times\vec{B})}{\partial t}=-\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}} $$ 

2897 由矢量旋度恒等式  $ \nabla \times (\nabla \times \vec{E}) = \nabla (\nabla \cdot \vec{E}) - \nabla^2 \vec{E} $（见习题1.1），以及上述  $ \rho = 0 $ 的麦克斯韦方程组中的  $ \nabla \cdot \vec{E} = 0 $，可得：

 $$ \nabla\times(\nabla\times\vec{E})=\nabla(\nabla\cdot\vec{E})-\nabla^{2}\vec{E}=-\nabla^{2}\vec{E}=-\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}} $$ 

2899 即：

 $$ \nabla^{2}\vec{E}-\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}}=0 $$ 

同理，我们可以得到  $ \vec{B} $ 的类似方程：

 $$ \nabla^{2}\vec{B}-\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{B}}{\partial t^{2}}=0 $$ 

对比上面我们提到的波动方程9.41式，我们发现，在  $ \vec{J}_{0}=0 $ 和  $ \rho=0 $ 时，从麦克斯韦方程组出发，电场  $ \vec{E} $ 和  $ \vec{B} $ 这两个物理量也满足波动方程的形式（即上述9.48和9.49式），即  $ \vec{E} $ 和  $ \vec{B} $ 均会以波动的形式在真空中传播，我们把这种波，称为电磁波。

由9.48和9.49式可知，电磁波的传播速度为：

 $$ v=\frac{1}{\sqrt{\mu_{0}\varepsilon_{0}}} $$ 

由于真空介电常数  $ \varepsilon_{0} $ 和真空磁导率  $ \mu_{0} $ 均为常数，因而我们发现真空中电磁波的传播速度是一个常数（与参考系无关）。将  $ \varepsilon_{0} $ 和  $ \mu_{0} $ 的数值代入上式，我们还发现该速度的值正好是我们熟知的真空中的光速 c:

 $$ c=\frac{1}{\sqrt{\mu_{0}\varepsilon_{0}}}\approx3\times10^{8}m/s $$ 

也就是说，麦克斯韦通过麦克斯韦方程组，预言了一种可以在真空中传播（而不依赖于传统机械波传播所需要的媒介）的电磁波，而且其传播速度等于真空中的光速，即光也是一种电磁波。