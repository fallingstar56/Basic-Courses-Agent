容易验证，各分界面处的总面电流密度相等，即：

 $$ \vec{\boldsymbol{K}}_{1}^{\prime}(R_{1})+\vec{\boldsymbol{K}}_{0,1}(R_{1})=\vec{\boldsymbol{K}}_{2}^{\prime}(R_{1})+\vec{\boldsymbol{K}}_{0,2}(R_{1})=\vec{\boldsymbol{K}}_{3}^{\prime}(R_{1})+\vec{\boldsymbol{K}}_{0,3}(R_{1})=\vec{\boldsymbol{K}}_{4}^{\prime}(R_{4})+\vec{\boldsymbol{K}}_{0,4}(R_{1}) $$ 

 $$ \vec{\boldsymbol{K}}_{1}^{\prime}(R_{2})+\vec{\boldsymbol{K}}_{0,1}(R_{2})=\vec{\boldsymbol{K}}_{2}^{\prime}(R_{2})+\vec{\boldsymbol{K}}_{0,2}(R_{2})=\vec{\boldsymbol{K}}_{3}^{\prime}(R_{2})+\vec{\boldsymbol{K}}_{0,3}(R_{2})=\vec{\boldsymbol{K}}_{4}^{\prime}(R_{2})+\vec{\boldsymbol{K}}_{0,4}(R_{2}) $$ 

因此，这也进一步验证了同一 r 处 B 与圆周的切线平行且大小处处相等这一结论。

## 习题

7.1: 证明：在各向同性线性均匀磁介质中，无传导电流处也无磁化电流。

7.2: 有一均匀磁化的介质球，球内部的磁化强度矢量为  $ \vec{M} $，求球内部各处的  $ \vec{H} $ 和  $ \vec{B} $。

486 7.3: 有一各向同性均匀线性磁介质球，相对磁导率为  $ \mu_{r} $，将其放入一个均匀磁场  $ \vec{B}_{0} $ 中，求 487 球内部各处的  $ \vec{M} $、 $ \vec{H} $ 和  $ \vec{B} $。

2488 7.4: 已知均匀载流无限大厚平板，厚度为 d，其内部的传导电流密度为  $ \vec{J}_{0} $，方向沿 -z 方向，平板的相对磁导率为  $ \mu_{r} $，求空间各处的磁感应强度，以及平板内的磁化体电流密度  $ \vec{J}' $ 和平板表面的磁化面电流密度  $ \vec{K}' $。

191 7.5: z = 0 的无限大平面将两个各向同性线性均匀介质隔开 (z > 0 和 z < 0 的区域的磁导率分别为  $ \mu_1 $ 和  $ \mu_2 $)，在分界面上的  $ y = \pm a $ 处分别有两个无限长直导线，两根导线中的电流方向相反（分别为  $ \pm x $ 方向），大小均为 I，求空间各处的  $ \vec{B} $。

7.6: 如图所示，一边长为 l 的矩形电磁铁有一个宽为 d 的空气间隙，磁铁绕有 N 匝导线，导线内电流为 I，磁铁内的介质的磁导率为  $ \mu $，假设空气间隙中没有漏磁，求空气间隙中的磁感应强度。

<div style="text-align: center;"><img src="imgs/img_in_image_box_831_1005_1035_1190.jpg" alt="Image" width="17%" /></div>
