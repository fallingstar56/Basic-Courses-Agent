 $$ \iint_{S}(\nabla\times\vec{E}_{ 感 })\cdot\mathrm{d}\vec{S}=-\iint_{S}\frac{\partial\vec{B}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

因此，感生电场的旋度为：

 $$ \nabla\times\vec{E}_{ 感 }=-\frac{\partial\vec{B}}{\partial t} $$ 

由于  $ \overrightarrow{E}_{感} $ 是一个涡旋场，其场线为闭合的环路，没有起点或终点，因而也就不存在发散或汇聚的点，其散度为零：

 $$ \nabla\cdot\vec{E}_{ 感 }=0 $$ 

我们注意到，上面两个公式给出的感生电场  $ \vec{E}_{感} $ 的散度和旋度方程，与磁失势所满足的散度和旋度方程类似（即  $ \nabla \times \vec{A} = \vec{B} $，以及库仑规范  $ \nabla \cdot \vec{A} = 0 $），因而感生电场也可以写成：

 $$ \vec{E}_{ 感 }=-\frac{\partial\vec{A}}{\partial t} $$ 

我们把变化的磁场激发的感生电场  $ \vec{E}_{感} $，和由电荷产生的静电场  $ \vec{E}_{静} $，统称为电场  $ \vec{E} $：

 $$ \vec{E}=\vec{E}_{ 感 }+\vec{E}_{ 静 } $$ 

其中， $ \vec{E}_{感} $ 无散度， $ \vec{E}_{静} $ 无旋度。根据亥姆霍兹定理，任何电场  $ \vec{E} $ 都可以分解成一个无散度的场  $ \vec{E}_{旋} $ 和一个无旋度的场  $ \vec{E}_{势} $，而这刚好与上式中的  $ \vec{E}_{感} $ 和  $ \vec{E}_{静} $ 对应。

结合感生电场的基本规律（8.19和8.20式）和真空中静电场的基本规律：

 $$ \nabla\times\vec{E}_{ 静 }=0,\qquad\nabla\cdot\vec{E}_{ 静 }=\frac{\rho}{\varepsilon_{0}} $$ 

2607 我们很容易得出真空中电场的基本规律：

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t} $$ 

 $$ \nabla\cdot\vec{E}=\frac{\rho}{\varepsilon_{0}} $$ 

2609 而这便是下一章我们将要学习的麦克斯韦方程组的其中两个方程。同时，由静电场和感应电场的势，可以将总电场写为：

 $$ \vec{E}=-\nabla U-\frac{\partial\vec{A}}{\partial t} $$ 