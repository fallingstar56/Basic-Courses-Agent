2617

### 例 8.4

如图所示为电子感应加速器（Betatron）的原理示意图，磁场 $ \vec{B} $ 垂直纸面向内且 B 随时间逐渐增大，电子在纸面内顺时针做圆周运动，由于 B 随时间增大，在电子所在位置产生与电子速度方向相反的感生电场 $ \vec{E}_{感} $，电子在运动的过程中被 $ \vec{E}_{感} $ 加速。问：若要使电子在被加速的过程中其圆周运动的半径保持不变，磁场B 的空间分布应该满足什么条件？

<div style="text-align: center;"><img src="imgs/img_in_image_box_789_174_1029_358.jpg" alt="Image" width="20%" /></div>


2618 解:

由洛伦兹力公式，电子做圆周运动应该满足：

 $$ mv=qB(R)R $$ 

其中， $ B(R) $ 表示半径为 R 处的磁感应强度大小。电子被  $ \vec{E}_{感} $ 加速满足牛顿第二定律：

 $$ \frac{\mathrm{d}(mv)}{\mathrm{d}t}=q\vec{E}_{ 感 }=q\frac{1}{2\pi R}\frac{\mathrm{d}\Phi}{\mathrm{d}t}=q\frac{1}{2\pi R}\frac{\mathrm{d}}{\mathrm{d}t}\int_{0}^{R}2\pi rB(r)\mathrm{d}r $$ 

定义半径 R 的圆形区域内的平均磁感应强度:

 $$ \bar{B}(R)=\frac{\int_{0}^{R}2\pi rB(r)\mathrm{d}r}{\pi R^{2}} $$ 

当电子运动半径保持不变时（即  $ \frac{dR}{dt}=0 $），将8.31式和8.33式代入8.32式，可得：

 $$ qR\frac{\mathrm{d}B(R)}{\mathrm{d}t}=\frac{qR}{2}\frac{\mathrm{d}\bar{B}(R)}{\mathrm{d}t} $$ 

即：

 $$ \frac{\mathrm{d}B(R)}{\mathrm{d}t}=\frac{1}{2}\frac{\mathrm{d}\bar{B}(R)}{\mathrm{d}t} $$ 

当产生磁场的线圈的几何形状不随时间变化时，这意味着任意时刻：

 $$ B(R)=\frac{\bar{B}(R)}{2} $$ 

即：要想在电子被加速过程中其圆周运动的半径保持不变，我们要求半径为 R 处的磁感应强度是以 R 为半径的圆内的平均磁感应强度的一半，也即磁感应强度从圆心向外应该逐渐降低。容易验证，其中一个可能的选择是让  $ B \propto \frac{1}{r} $。实际设计的电子感应加速器，往往让电子在上下两个磁体之间的水平面上做圆周运动，且上下两个磁体之间的距离被设计成中间小、两边