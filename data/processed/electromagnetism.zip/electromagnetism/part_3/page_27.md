的源除了传导电流  $ \vec{J}_{0} $ 外，还多了一项量纲与电流密度相同的一项， $ \varepsilon_{0}\frac{\partial E}{\partial t} $。1862 年，英国物理学家詹姆斯·克拉克·麦克斯韦（James Clerk Maxwell，1831-1879）把这一多出来的项，解释为“以太的弹性移动”（类似于传导电流是电荷的移动），并把它称为位移电流密度（displacement current density）：

 $$ \vec{J}_{d}=\varepsilon_{0}\frac{\partial\vec{E}}{\partial t} $$ 

2815 在各向同性线性介质中，可以用同样的推导方法证明，上述9.1式变为：

 $$ \nabla\times\vec{H}=\frac{\partial\vec{D}}{\partial t}+\vec{J}_{0} $$ 

2816

2817 对应的位移电流密度为：

 $$ \vec{J}_{d}=\frac{\partial\vec{D}}{\partial t} $$ 

与传导电流密度  $ \vec{J}_{0} $ 和传导电流 I 的关系类似，通过某个面积的位移电流密度的积分，则被称为位移电流（displacement current）：

 $$ I_{d}=\iint_{S}\vec{J}_{d}\cdot\mathrm{d}\vec{S}=\iint_{S}\frac{\partial\vec{D}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

2821 例 9.1

铜导线中通有频率为 50 Hz 的交流电  $ I = I_{0} \cos \omega t $，求位移电流和传导电流的比值。

2823 解:

2824 由欧姆定律，可知导线中的电场强度的大小为：

 $$ E=J\rho=\frac{I\rho}{S} $$ 

2825 因此，导线中的位移电流为：

 $$ I_{d}=\iint_{S}\vec{J}_{d}\cdot\mathrm{d}\vec{S}=S\varepsilon_{0}\frac{\partial E}{\partial t}=S\varepsilon_{0}\frac{\rho}{S}\frac{\mathrm{d}I}{\mathrm{d}t}=\varepsilon_{0}\rho\omega I_{0}\cos(\omega t+\frac{\pi}{2}) $$ 

2826 可知，位移电流与传导电流相位相差 90 度。位移电流和传导电流的振幅之比为：

 $$ \frac{I_{d0}}{I_{0}}=\varepsilon_{0}\rho\omega $$ 

2827 将  $ \omega = 2\pi \times 50Hz $，铜的电阻率  $ \rho = 1.68 \times 10^{-8}\Omega \cdot m $ 代入，可得：

 $$ \frac{I_{d0}}{I_{0}}=\varepsilon_{0}\rho\omega=8.85\times10^{-12}\times1.68\times10^{-8}\times2\pi\times50=4.7\times10^{-17} $$ 