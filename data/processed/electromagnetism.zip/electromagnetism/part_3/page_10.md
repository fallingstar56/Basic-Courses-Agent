2532 E:

 $$ \mathcal{E}=\frac{\mathrm{d}A_{\mathrm{ne}}}{\mathrm{d}q}=U+I r=\int_{-}^{+}\vec{E}_{\mathrm{ne}}\cdot\mathrm{d}\vec{l} $$ 

根据这个定义，我们知道，电动势的正方向是从负极到正极，也就是电源的电势升高的方向，这与电源的电势的正方向刚好相反。对应的，其非静电场  $ \vec{E}_{ne} $ 的方向也是从电源的负极指向正极，这与电源中静电场  $ \vec{E} $ 的方向刚好相反。

2537 电源中的非静电刀，对不同类型的电源可以有不同源头，比如对电池来说是化学反应造成的，而我们日常生活中还有一种常见的非静电力来源，那就是发电机里的洛伦兹力。如下图所示是发电机的原理示意图，其通过机械能，使导线切割磁感线运动，假设导线运动方向与磁场方向垂直，速度为  $ \vec{v} $，则导线内电荷 q 受到的洛伦兹力为：

<div style="text-align: center;"><img src="imgs/img_in_image_box_372_591_814_840.jpg" alt="Image" width="37%" /></div>


2541

 $$ \vec{F}_{\mathrm{L o r e n t z}}=q\vec{v}\times\vec{B} $$ 

2542 该洛伦兹力的作用，便是搬运导线中的电荷，比如上图中，该洛伦兹力会将负电荷从正极搬运到负极，而这正是我们上文中提到的电源中的非静电力做的事情，因此，这里的洛伦兹力，便是发电机这个电源对应的非静电力，其对应的非静电场为：

 $$ \vec{E}_{\mathrm{ne}}=\frac{\vec{F}_{\mathrm{Lorentz}}}{q}=\vec{v}\times\vec{B} $$ 

2545 对应的电动势为：

 $$ \mathcal{E}=\int_{-}^{+}\vec{E}_{\mathrm{n e}}\cdot\mathrm{d}\vec{l}=\int_{-}^{+}(\vec{v}\times\vec{B})\cdot\mathrm{d}\vec{l} $$ 

2546 我们把这种由于导线在磁场中切割磁感线的运动产生的电动势，称为动生电动势（motion emf）。

2547

例 8.1

如图所示，有一半径为 R 的导体圆盘，绕其圆心在垂直磁场  $ \vec{B} $ 的平面做角速度为  $ \omega $ 的匀速转动。若将圆盘的圆心和圆盘的最外围作为电源的两极，求该电源的电动势。

<div style="text-align: center;"><img src="imgs/img_in_image_box_794_1295_1034_1489.jpg" alt="Image" width="20%" /></div>


解:

图中，圆盘的圆心为电源负极，外围为电源正极，其电动势为：