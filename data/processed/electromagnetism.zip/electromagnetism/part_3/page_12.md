2575 其中，磁通量（magnetic flux）的定义为：

 $$ \Phi=\iint_{S}\vec{B}\cdot\mathrm{d}\vec{S} $$ 

2576 感应电动势的方向，可以由楞次定律来确定：感应电流的方向，总是使它所产生的磁场来阻碍引起感应电流的磁通量的变化。因此，上式也可以写成：

 $$ \mathcal{E}=-\frac{\mathrm{d}\Phi}{\mathrm{d}t}=-\frac{\mathrm{d}}{\mathrm{d}t}\iint_{S}\vec{B}\cdot\mathrm{d}\vec{S} $$ 

2579 其中，L 的正方向与  $ \vec{S} $ 的正方向成右手螺旋关系。

容易看出，上述定律中的闭合回路所对应的曲面  $ \vec{S} $ 的选取是任意的，只要曲面  $ \vec{S} $ 是以 L 为周线就可以，而之所以这一选取具有任意性，是因为磁场  $ \vec{B} $ 满足高斯定理，即对任意两个满足以 L 为周线的曲面  $ \vec{S}_1 $ 和  $ \vec{S}_2 $，让它们组成一个闭合曲面  $ \vec{S} = \vec{S}_1 - \vec{S}_2 $（负号表示  $ \vec{S} $ 的法向与  $ \vec{S}_2 $ 法向相反），则由高斯定理：

 $$ 0=\iint_{\vec{S}}\vec{B}\cdot\mathrm{d}\vec{S}=\iint_{\vec{S}_{1}}\vec{B}\cdot\mathrm{d}\vec{S}-\iint_{\vec{S}_{2}}\vec{B}\cdot\mathrm{d}\vec{S}\quad\Rightarrow\quad\iint_{\vec{S}_{1}}\vec{B}\cdot\mathrm{d}\vec{S}=\iint_{\vec{S}_{2}}\vec{B}\cdot\mathrm{d}\vec{S} $$ 

当回路中存在多匝线圈串联时，产生的总感应电动势是每匝线圈的感应电动势的和，即：

 $$ \mathcal{E}=\sum_{i}\mathcal{E}_{i}=-\frac{\mathrm{d}}{\mathrm{d}t}\sum_{i}\Phi_{i} $$ 

上式中的总磁通量  $ \sum_{i} \Phi_{i} $，通常被称为通过线圈的磁链（magnetic flux linkage）  $ \Psi = \sum_{i} \Phi_{i} $

当回路静止，磁场随时间变化时，我们把这种情况下产生的感应电动势称为感生电动势（transformer emf）：

 $$ \mathcal{E}_{ 感生 }=-\frac{\mathrm{d}}{\mathrm{d}t}\iint_{S 固定 }\vec{B}\cdot\mathrm{d}\vec{S}=-\iint_{S 固定 }\frac{\partial\vec{B}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

上一节提到，与电动势对应的，是驱动导体中电荷运动的一个非静电力场。对于与感生电动势对应的非静电力场，麦克斯韦预言它的本质是一种电场，并且把它称为感生电场（induced electric field），记为  $ \vec{E}_{感} $。由法拉第电磁感应定律， $ \vec{E}_{感} $ 是由变化的磁场在其周围空间激发的。 $ \vec{E}_{感} $ 的存在与导体或者闭合回路的存在与否无关；同时，与静电场类似， $ \vec{E}_{感} $ 可以由检验电荷、一小段导体等手段检测出来。此外，与静电场不同的是， $ \vec{E}_{感} $ 是一个涡旋状的有旋场，根据8.13式，当回路 L 静止时，该式可以写成  $ \vec{E}_{感} $ 在环路 L 上的线积分：

 $$ \mathcal{E}_{ 感生 }=\oint_{L}\vec{E}_{ 感 }\cdot\mathrm{d}\vec{l}=-\frac{\mathrm{d}}{\mathrm{d}t}\iint_{S 固定 }\vec{B}\cdot\mathrm{d}\vec{S}=-\iint_{S 固定 }\frac{\partial\vec{B}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

2594 根据斯托克斯定理，上式可以写成：