<div style="text-align: center;"><img src="imgs/img_in_image_box_369_150_821_407.jpg" alt="Image" width="37%" /></div>


解:

设任意一点 P 到轴线的距离为 r，则当介质不存在时（即全部换成真空），P 点的  $ \vec{B} $ 和  $ \vec{H} $ 均与该点所在的圆周的切线平行；由于所加的介质的分界面与真空情况下的磁感应强度平行，因此加入介质后 P 点的  $ \vec{B} $ 和  $ \vec{H} $ 仍然与该点所在的圆周的切线平行（事实上，本题由简单的电流分布的对称性就可以得出  $ \vec{B} $ 和  $ \vec{H} $ 处处与该点所在圆周切线平行且同一圆周上大小处处相等这一结论）。

由  $ \vec{H} $ 的环路定理，有：

 $$ H(\vec{r})=\frac{\sum I_{0}}{2\pi r}=\begin{cases}0,&r<R_{1} 或 r>R_{3},\\\frac{I}{2\pi r},&R_{1}<r<R_{2},\\\frac{I}{2\pi r},&R_{2}<r<R_{3}.\end{cases} $$ 

 $ \vec{H} $ 的方向与  $ R_{1} $ 处的 I 的方向满足右手定则。由  $ \vec{B} $ 和  $ \vec{H} $ 之间的线性关系，有：

 $$ B(\vec{r})=\mu H=\begin{cases}0,&r<R_{1} 或 r>R_{3},\\\frac{\mu_{2}I}{2\pi r},&R_{1}<r<R_{2},\\\frac{\mu_{3}I}{2\pi r},&R_{2}<r<R_{3}.\end{cases} $$ 

2450 为了求磁化面电流密度，先求各处的磁化强度矢量：

 $$ M(\vec{r})=\chi_{m}H=(\frac{\mu}{\mu_{0}}-1)H=\begin{cases}0,&r<R_{1} 或 r>R_{3},\ $ \frac{\mu_{2}}{\mu_{0}}-1)\frac{I}{2\pi r},&R_{1}<r<R_{2},\ $ \frac{\mu_{3}}{\mu_{0}}-1)\frac{I}{2\pi r},&R_{2}<r<R_{3}.\end{cases} $$ 

假设  $ R_1 $ 处传导电流  $ I $ 的方向为正  $ z $ 方向  $ \hat{z} $，则：以  $ R_1 $ 处的磁化面电流密度  $ \vec{K}_1' $ 为例， $ \vec{K}_1' $ 为介质 1 的  $ \vec{M}_1 $ 产生的  $ \vec{K}_{11}' $ 和介质 2 的  $ \vec{M}_2 $ 产生的  $ \vec{K}_{21}' $ 的和，其中：

1. 介质 1 在  $ R_{1} $ 处的表面法向  $ \vec{n}_{11} $ 垂直轴线向外， $ \vec{K}_{11}^{\prime}=\vec{M}_{1}(R_{1})\times\vec{n}_{11}=0 $;