 $$ \begin{array}{r l r}{\nabla\times\vec{B}=\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}}{\partial t}}&{{}\Rightarrow}&{i\vec{k}_{B}\times\vec{B}=-i\mu_{0}\varepsilon_{0}\omega_{E}\vec{E}}\end{array} $$ 

可知，任意一点的  $ \vec{k}_{B} $、 $ \vec{E} $、 $ \vec{k}_{B} $ 三者两两互相垂直且由右手法则确定。因此，我们可以确定， $ \vec{E} $ 和  $ \vec{B} $ 的波矢  $ \vec{k}_{E} $ 和  $ \vec{k}_{B} $ 必定方向相同，且与  $ \vec{E} $ 和  $ \vec{k}_{B} $ 成右手法则关系。至于  $ \vec{k}_{E} $ 和  $ \vec{k}_{B} $ 的大小，由于  $ \vec{E} $ 和  $ \vec{B} $ 的速度均为光速，可知：

 $$ c=v_{E}=\frac{\omega}{k_{E}}=v_{B}=\frac{\omega}{k_{B}} $$ 

2933 因此  $ \vec{k}_{E} $ 和  $ \vec{k}_{B} $ 大小也相同，即：

 $$ \vec{k}=\vec{k}_{E}=\vec{k}_{B} $$ 

最后，我们来看一下  $ \vec{E} $ 和  $ \vec{B} $ 的初始相位  $ \phi_{E} $ 和  $ \phi_{B} $ 之间的关系。将  $ \vec{k}_{E} = \vec{k}_{B} = \vec{k} $ 和  $ \omega_{E} = \omega_{B} = \omega $ 代入9.61式，可得：

 $$ \vec{\pmb{k}}\times\vec{\pmb{E}}_{0}e^{i(\vec{\pmb{k}}\cdot\vec{\pmb{r}}-\omega t+\phi_{E})}=\omega\vec{\pmb{B}}_{0}e^{i(\vec{\pmb{k}}\cdot\vec{\pmb{r}}-\omega t+\phi_{B})} $$ 

2937 化简上式可得：

 $$ \vec{k}\times\vec{E}_{0}e^{i(\phi_{E}-\phi_{B})}=\omega\vec{B}_{0} $$ 

2938 上式左右两边实部和虚部都应该相等，而右边为实数，因而左边的虚部也应该为零，即：

 $$ \phi_{E}=\phi_{B} $$ 

也就是说  $ \vec{E} $ 和  $ \vec{B} $ 在任一相同位置的任意时刻都是同相位的， $ \vec{E} $ 取最大值时  $ \vec{B} $ 也取最大值。

综上，电磁波的  $ \vec{E} $ 和  $ \vec{B} $ 的波函数可以写成：

 $$ \vec{E}=\vec{E}(\vec{r},t)=\vec{E}_{0}e^{i(\vec{k}\cdot\vec{r}-\omega t+\phi)} $$ 

 $$ \vec{B}=\vec{B}(\vec{r},t)=\vec{B}_{0}e^{i(\vec{k}\cdot\vec{r}-\omega t+\phi)} $$ 

由上述分析和证明，可以总结出平面电磁波有如下特征：

• 电磁波的传播方向与  $ \vec{E} $ 和  $ \vec{B} $ 的方向都垂直，表明电磁波是横波；

•  $ \vec{E} $、 $ \vec{B} $、 $ \vec{k} $ 三个矢量且成右手螺旋关系；

•  $ \vec{E} $ 和  $ \vec{B} $ 同相位；

• 真空中电磁波的传播速度（相速度）为：

 $$ v=\frac{\omega}{k}=\frac{1}{\sqrt{\mu_{0}\varepsilon_{0}}}=c $$ 

2948 介质中电磁波的传播速度（相速度）为：

 $$ v=\frac{1}{\sqrt{\mu\varepsilon}}=\frac{c}{n} $$ 