速度，直到介质内所有可用的磁偶极矩均被磁化成与外加磁场平行为止，此时介质内部 M 将达到饱和不再进一步增加，且其内部的 B 的增加将趋于平缓（速度类似于真空情形）；此时，若逐渐开始降低线圈内的电流，介质内的 B 也会相应的降低，但是不同点在于，当线圈内电流降为零时，硬铁磁性介质将会有较大 B 的残留（由于“磁畴”在前述过程被磁化了），此时该类介质便实现了永久磁化变成了永磁体，而软铁磁性介质内部残存的 B 很小，而对于其他非铁磁性介质的各向同性线性均匀介质，B 将恢复到零。下图中的 a、b、c 三张示意图表示的便是这三种不同的介质内部的 B 随线圈中的电流的关系曲线（也可以等价成与介质内部的 H 的关系曲线，因为密绕环形螺线管或长直螺线管中 H 与传导电流成正比）。以 a 图为例，从 0 点到 1 点便是上面说的初始磁化阶段；当电流从点 1 开始降到零时，B 将变为点 2 处的值，此时，若继续降低电流（即将电流反向），B 和 I 的关系曲线将沿着  $ 2 \rightarrow 3 \rightarrow 4 $ 这条曲线，直到介质内部的 M 达到反向饱和为止；此时若降低反向电流直到将电流变为正向，该曲线又将沿着  $ 4 \rightarrow 5 \rightarrow 6 \rightarrow 1 $ 的曲线回到正向饱和点 1。我们把类似该图的从  $ 1 \rightarrow 2 \rightarrow 3 \rightarrow 4 \rightarrow 5 \rightarrow 6 \rightarrow 1 $ 的这条闭合曲线，称为介质的磁滞回线。

<div style="text-align: center;"><img src="imgs/img_in_image_box_190_609_464_847.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_471_608_742_846.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;">a. 硬铁磁性介质</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_748_609_1003_847.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">b. 软铁磁性介质</div>


<div style="text-align: center;">c. 各向同性线性均匀介质</div>


那对于永磁介质，我们如何来计算其产生的磁场呢？首先，不管是何种介质， $ \vec{H} $ 的定义以及  $ \vec{H} $， $ \vec{B} $ 满足的微分方程是不变的：

 $$ \vec{H}=\frac{\vec{B}}{\mu_{0}}-\vec{M},\quad 或 \quad\vec{B}=\mu_{0}(\vec{H}+\vec{M}) $$ 

 $$ \nabla\times\vec{H}=\vec{J}_{0} $$ 

 $$ \nabla\cdot\vec{B}=0 $$ 

2370 将7.31式代入7.33式，可得：

 $$ \nabla\cdot\vec{H}=-\nabla\cdot\vec{M} $$ 

2371 当没有传导电流时，7.32式中的  $ \vec{J}_{0}=0 $，因此，在没有传导电流的情况下， $ \vec{H} $ 满足如下方程：

 $$ \nabla\times\vec{H}=0 $$ 

 $$ \nabla\cdot\vec{H}=-\nabla\cdot\vec{M} $$ 

2372 对于永磁介质，如果我们已知其内部的磁化强度矢量  $ \vec{M} $，我们便可以根据上式求解得出各处的  $ \vec{H} $ 分布，进而求出各处的磁感应强度分布。同时，我们也注意到，上式两个方程跟静电场  $ \vec{E} $ 满足的方程非常像（可以把  $ \rho_m = -\nabla \cdot \vec{M} $ 类比成体电荷密度，也称“束缚磁荷”），求解时也可参