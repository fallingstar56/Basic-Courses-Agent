3190 将上式代入波动方程9.131，可得：

 $$ -k^{2}\vec{E}=-\mu_{0}\varepsilon_{0}\omega^{2}\vec{E}-i\omega\mu_{0}\sigma\vec{E} $$ 

3191 即：

 $$ k^{2}=\mu_{0}\varepsilon_{0}\omega^{2}+i\omega\mu_{0}\sigma $$ 

3192 我们发现，满足上述方程的解，是一个复数，即波矢 k 存在虚部。我们假设 k 可以写成：

 $$ k=k_{r}+ik_{i} $$ 

3193 则实部和虚部的解分别为：

 $$ k_{r}=\omega\sqrt{\frac{\varepsilon_{0}\mu_{0}}{2}}\bigg[\sqrt{1+(\frac{\sigma}{\varepsilon_{0}\omega})^{2}}+1\bigg]^{1/2} $$ 

 $$ k_{i}=\omega\sqrt{\frac{\varepsilon_{0}\mu_{0}}{2}}\left[\sqrt{1+(\frac{\sigma}{\varepsilon_{0}\omega})^{2}}-1\right]^{1/2} $$ 

3194 对于一般良导体， $ \sigma \gg \varepsilon_{0}\omega $，则上式可以写成：

 $$ k_{r}=k_{i}=\sqrt{\frac{\mu_{0}\sigma\omega}{2}} $$ 

当  $ \vec{k} $ 为复数时，电磁场的波函数可以写成：

 $$ \vec{E}=\vec{E}(\vec{r},t)=\vec{E}_{0}e^{-\vec{k}_{i}\cdot\vec{r}}e^{i(\vec{k}_{r}\cdot\vec{r}-\omega t+\phi_{E})} $$ 

 $$ \vec{B}=\vec{B}(\vec{r},t)=\vec{B}_{0}e^{-\vec{k}_{i}\cdot\vec{r}}e^{i(\vec{k}_{r}\cdot\vec{r}-\omega t+\phi_{B})} $$ 

3196 至于  $ \vec{E} $ 和  $ \vec{B} $ 的相位差，将上式代入9.127式可得：

 $$ \begin{array}{r l r}{i\vec{\pmb{k}}\times\vec{\pmb{E}}=i\omega\vec{\pmb{B}}}&{{}\Rightarrow}&{B=\frac{k}{\omega}E=\frac{k}{\omega}E_{0}e^{-\vec{\pmb{k}}_{i}\cdot\vec{\pmb{r}}}e^{i(\vec{\pmb{k}}_{r}\cdot\vec{\pmb{r}}-\omega t+\phi_{E})}}\end{array} $$ 

3197 即  $ \vec{B} $ 和  $ \vec{E} $ 的相位差等于波矢 k 的相位，对于良导体，由9.145式我们可知，这是个 45° 角。

即，导体中，电场和磁场的波函数分别为：

 $$ \vec{E}=\vec{E}(\vec{r},t)=\vec{E}_{0}e^{-\vec{k}_{i}\cdot\vec{r}}e^{i(\vec{k}_{r}\cdot\vec{r}-\omega t+\phi_{E})} $$ 

 $$ \vec{B}=\vec{B}(\vec{r},t)=\frac{\vec{k}\times\vec{E}_{0}}{\omega}e^{-\vec{k}_{i}\cdot\vec{r}}e^{i(\vec{k}_{r}\cdot\vec{r}-\omega t+\phi_{B})} $$ 

由上述波函数，我们可知，在导体中，由于传导电流的存在，会使得波动方程中多了一项电磁场对时间的一次求导，而这一项的存在会使得电磁波的波函数中的电场和磁场的振幅中出现了一个衰减项：

 $$ e^{-\vec{k}_{i}\cdot\vec{r}} $$ 