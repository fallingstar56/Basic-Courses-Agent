下面，我们以平面电磁波为例来分析电磁波的一些性质，即假定空间中任意一点的  $ \vec{E} $ 和  $ \vec{B} $ 均分别以单一角频率  $ \omega_{E} $ 和  $ \omega_{B} $ 随时间做简谐变化，且假设波矢分别为  $ \vec{k}_{E} $ 和  $ \vec{k}_{B} $ （波的传播方向为波矢的方向）。则上述关于  $ \vec{E} $ 和  $ \vec{B} $ 的波动方程的解（即波函数），可以用复指数的形式来表示，即任意一点  $ \vec{r} $ 、任意时刻 t 的  $ \vec{E} $ 和  $ \vec{B} $ 的值可以写成：

 $$ \vec{E}=\vec{E}(\vec{r},t)=\vec{E}_{0}e^{i(\vec{k}_{E}\cdot\vec{r}-\omega_{E}t+\phi_{E})} $$ 

 $$ \vec{B}=\vec{B}(\vec{r},t)=\vec{B}_{0}e^{i(\vec{k}_{B}\cdot\vec{r}-\omega_{B}t+\phi_{B})} $$ 

2918 其中， $ \vec{E}_{0} $ 和  $ \vec{B}_{0} $ 均为实数振幅， $ \phi_{E} $ 和  $ \phi_{B} $ 分别为  $ \vec{E} $ 和  $ \vec{B} $ 的初始相位因子。

根据上述波函数，可以得出  $ \vec{E} $ 的散度、旋度以及对时间的偏微分，分别为：

 $$ \nabla\cdot\vec{E}=i\vec{k}_{E}\cdot\vec{E}_{0}e^{i(\vec{k}_{E}\cdot\vec{r}-\omega_{E}t+\phi_{E})}=i\vec{k}_{E}\cdot\vec{E} $$ 

 $$ \nabla\times\vec{E}=i\vec{k}_{E}\times\vec{E}_{0}e^{i(\vec{k}_{E}\cdot\vec{r}-\omega_{E}t+\phi_{E})}=i\vec{k}_{E}\times\vec{E} $$ 

 $$ \frac{\partial\vec{E}}{\partial t}=-i\omega_{E}\vec{E}_{0}e^{i(\vec{k}_{E}\cdot\vec{r}-\omega_{E}t+\phi_{E})}=-i\omega_{E}\vec{E} $$ 

2920 同理：

 $$ \nabla\cdot\vec{B}=i\vec{k}_{B}\cdot\vec{B} $$ 

 $$ \nabla\times\vec{B}=i\vec{k}_{B}\times\vec{B} $$ 

 $$ \frac{\partial\vec{B}}{\partial t}=-i\omega_{B}\vec{B} $$ 

2921 首先，我们来看一下  $ \bar{E} $ 和  $ \bar{B} $ 的振动角频率  $ \omega_{E} $ 和  $ \omega_{B} $ 之间的关系：将上述各式，代入麦克斯韦方程组（9.43式），可得：

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t}\quad\Rightarrow\quad i\vec{k}_{E}\times\vec{E}=i\omega_{B}\vec{B} $$ 

2923 即：

 $$ i\vec{k}_{E}\times\vec{E}_{0}e^{i(\vec{k}_{E}\cdot\vec{r}-\omega_{E}t+\phi_{E})}=i\omega_{B}\vec{B}_{0}e^{i(\vec{k}_{B}\cdot\vec{r}-\omega_{B}t+\phi_{B})} $$ 

2924 上式对任意时刻 t 都成立，这就要求等式两边的角频率必须相等，即：

 $$ \omega_{E}=\omega_{B}=\omega $$ 

我们再来看一下  $ \vec{E} $ 和  $ \vec{B} $ 的波矢  $ \vec{k}_{E} $ 和  $ \vec{k}_{B} $ 之间的关系：将  $ \nabla \cdot \vec{E} = i \vec{k}_{E} \cdot \vec{E} $ 代入麦克斯韦方程组中的  $ \nabla \cdot \vec{E} = 0 $，可得：

 $$ \vec{k}_{E}\cdot\vec{E}=0 $$ 

2928 即：任意一点的矢量  $ \vec{k}_{E} $ 与该点的  $ \vec{E} $ 垂直，而由9.60可知  $ \vec{E} $ 和  $ \vec{B} $ 垂直且  $ \vec{B} $ 和  $ \vec{k}_{E} $ 垂直，因此任意一点的  $ \vec{k}_{E} $、 $ \vec{E} $、 $ \vec{k}_{B} $ 三者两两互相垂直且由右手法则确定。同理，对于  $ \vec{B} $，我们可知：

 $$ \nabla\cdot\vec{B}=0\quad\Rightarrow\quad i\vec{k}_{B}\cdot\vec{B}=0 $$ 