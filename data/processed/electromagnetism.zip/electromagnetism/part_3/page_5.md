2. 介质 2 在  $ R_2 $ 处的表面法向  $ \vec{n}_{21} $ 垂直轴线向内， $ \vec{K}_{21}' = \vec{M}_2(R_1) \times \vec{n}_{21} = (\frac{\mu_2}{\mu_0} - 1)\frac{I}{2\pi R_1} \hat{z} $ 因此，在  $ R_1 $ 分界面处的磁化面电流密度为：

 $$ \vec{K}_{1}^{\prime}=\vec{K}_{11}^{\prime}+\vec{K}_{21}^{\prime}=(\frac{\mu_{2}}{\mu_{0}}-1)\frac{I}{2\pi R_{1}}\hat{z} $$ 

2456 类似的，在  $ R_{2} $ 分界面处的磁化面电流密度为：

 $$ \begin{aligned}\vec{\boldsymbol{K}}_{2}^{\prime}&=\vec{\boldsymbol{K}}_{22}^{\prime}+\vec{\boldsymbol{K}}_{32}^{\prime}=\vec{\boldsymbol{M}}_{2}(R_{2})\times\vec{\boldsymbol{n}}_{22}+\vec{\boldsymbol{M}}_{3}(R_{2})\times\vec{\boldsymbol{n}}_{32}\\&=-(\frac{\mu_{2}}{\mu_{0}}-1)\frac{\boldsymbol{I}}{2\pi R_{2}}\hat{\boldsymbol{z}}+(\frac{\mu_{3}}{\mu_{0}}-1)\frac{\boldsymbol{I}}{2\pi R_{2}}\hat{\boldsymbol{z}}\\&=\frac{\mu_{3}-\mu_{2}}{\mu_{0}}\frac{\boldsymbol{I}}{2\pi R_{2}}\hat{\boldsymbol{z}}\end{aligned} $$ 

2457 同理，在  $ R_{3} $ 分界面处的磁化面电流密度为：

 $$ \vec{K}_{3}^{\prime}=\vec{K}_{33}^{\prime}=\vec{M}_{3}(R_{3})\times\vec{n}_{33}=-(\frac{\mu_{3}}{\mu_{0}}-1)\frac{I}{2\pi R_{3}}\hat{z} $$ 

### 2458 例 7.5

如图，半径为  $ R_{1} $ 和  $ R_{2} $ 的无限长共轴圆柱面上分别有沿轴向的大小为 I、方向相反的传导电流，柱面间的空间被均分成四份，其间填充了四种各向同性线性均匀介质，介质分界面与轴线平行，求空间各处的磁感应强度  $ \vec{B} $ 和磁场强度  $ \vec{H} $，以及各分界面处的磁化面电流密度  $ K' $ 和传导面电流密度  $ \vec{K}_{0} $。

<div style="text-align: center;"><img src="imgs/img_in_image_box_372_948_818_1201.jpg" alt="Image" width="37%" /></div>


2464 解:

设任意一点 P 与轴线的距离为 r，则当介质不存在时（即全部换成真空），P 点的  $ \vec{B} $ 和  $ \vec{H} $ 均与该点所在的圆周的切线平行；由于所加的介质的分界面与真空情况下的磁感应强度垂直，因此加入介质后 P 点的  $ \vec{B} $ 和  $ \vec{H} $ 仍然与该点所在的圆周的切线垂直。

由于  $ \vec{B} $ 的法向分量在介质分界面连续，因此在同一 r 处的圆柱面各点上四种介质内的  $ \vec{B} $