其中  $ n = \sqrt{\mu_r \varepsilon_r} $ 为折射率。

•  $ \vec{E} $ 和  $ \vec{B} $ 的振幅之间的关系为（可由9.69式得出）：

 $$ \frac{E}{B}=\frac{\omega}{k}=v=\frac{1}{\sqrt{\mu\varepsilon}} $$ 

或者写成：

 $$ \varepsilon E^{2}=\frac{B^{2}}{\mu} $$ 

 $ \vec{E} $、 $ \vec{B} $ 的方向和相位，以及它们和电磁波的传播方向之间的关系可以用如下示意图来表示。

<div style="text-align: center;"><img src="imgs/img_in_image_box_403_613_848_882.jpg" alt="Image" width="37%" /></div>


### 9.4 电磁场的能量和动量

在学习机械波的时候我们知道，波的传播的本质，是运动状态和能量通过介质在空间中的传播，对机械波而言，传播的能量是机械能。在第五章和第八章我们学习到，电场和磁场都能够储存能量，且空间中某点的电场和磁场的能量密度与电场和磁场强度的关系为：

 $$ w_{e}=\frac{1}{2}\vec{D}\cdot\vec{E}=\frac{1}{2}\varepsilon E^{2} $$ 

 $$ w_{m}=\frac{1}{2}\vec{B}\cdot\vec{H}=\frac{1}{2}\frac{B^{2}}{\mu} $$ 

2958 空间中电磁场（电场和磁场）的总能量密度为：

 $$ w=w_{e}+w_{m}=\frac{1}{2}\vec{D}\cdot\vec{E}+\frac{1}{2}\vec{B}\cdot\vec{H}=\frac{1}{2}\varepsilon E^{2}+\frac{1}{2}\frac{B^{2}}{\mu} $$ 

当空间中某一点有随时间变化的电场或磁场时, 该点的电磁场能量密度也会随时间变化。而由能量守恒, 当空间中一闭合表面 S 所包围的体积 V 内的总电磁能随时间发生变化时, 那就意味着会有能量从这个闭合表面流入或者流出, 亦或者是电磁场对体积 V 内的带电粒子做功: