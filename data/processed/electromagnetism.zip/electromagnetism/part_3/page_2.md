由于磁化面电流的出现，会导致磁场在表面两侧不连续。下面，我们来分析  $ \vec{B} $ 和  $ \vec{H} $ 在介质表面两侧的大小关系。

我们先来看一下磁感应强度  $ \vec{B} $ 在介质分界面两侧的边值关系。如下图所示，在介质 1 和介质 2 的分界面处，设  $ \vec{B} $ 的法向分量和切向分量分别为  $ B_{n1}, B_{\tau1}, B_{n2}, B_{\tau3} $，如下图所示跨过边界取一个底面为  $ \Delta S $（平行于介质表面）、高度为 h（无限小）的圆柱面：

<div style="text-align: center;"><img src="imgs/img_in_image_box_196_362_1000_583.jpg" alt="Image" width="67%" /></div>


2403

2404 由  $ \vec{B} $ 的高斯定理：

 $$ 0=\iint_{S}\vec{B}\cdot\mathrm{d}\vec{S}=B_{n1}\Delta S-B_{n2}\Delta S=(B_{n1}-B_{n2})\Delta S $$ 

2405 上式对于任何大小的圆柱面  $ \Delta S $ 都是成立的，因此：

 $$ B_{n1}=B_{n2} $$ 

2407 对应的，对各向同性线性均匀介质，由  $ \vec{B} $ 和  $ \vec{H} $ 的线性关系  $ \vec{B} = \mu \vec{H} $，可得：

 $$ \frac{H_{n1}}{H_{n2}}=\frac{\mu_{2}}{\mu_{1}} $$ 

关于  $ \vec{H} $ 的切向分量的边值关系，我们可以通过  $ \vec{H} $ 的环路定理得出，如下图所示，跨越介质表面取一个闭合矩形：

<div style="text-align: center;"><img src="imgs/img_in_image_box_200_1111_1000_1398.jpg" alt="Image" width="67%" /></div>


2411

2412 当介质表面没有传导电流时，我们有：

 $$ 0=\oint_{L}\vec{H}\mathrm{d}\vec{l}=H_{\tau1}l-H_{\tau2}l $$ 