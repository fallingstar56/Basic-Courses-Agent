2469 处处大小相等（设值为  $ B(\vec{r}) $），由  $ \vec{H} $ 的环路定理，有：

 $$ \sum I=\oint_{L}\vec{H}\cdot\mathrm{d}\vec{l}=\sum_{i}\frac{B(\vec{r})}{\mu_{i}}\frac{1}{2}\pi r $$ 

2470 得：

 $$ B(\vec{\mathbf{r}})=\frac{2\sum I}{\pi r\sum\frac{1}{\mu_{i}}}=\begin{cases}0,&r<R_{1} 或 r>R_{2},\\\frac{2I}{\pi r\sum_{i}\frac{1}{\mu_{i}}},&R_{1}<r<R_{2}.\end{cases} $$ 

2471 对应的各区域的磁场强度为：

 $$ H_{i}(\vec{r})=B(\vec{r})/\mu_{i}=\begin{cases}0,&r<R_{1} 或 r>R_{2},\\\frac{2I}{\pi r\mu_{i}\sum_{j}\frac{1}{\mu_{i}}},&R_{1}<r<R_{2}.\end{cases} $$ 

2472  $ \vec{B} $ 和  $ \vec{H} $ 的方向与  $ R_{1} $ 处的 I 的方向满足右手定则。为了求各分界面的磁化面电流密度，先求各处的磁化强度矢量：

 $$ M_{i}(\vec{\mathbf{r}})=(\frac{\mu_{i}}{\mu_{0}}-1)H_{i}(\vec{\mathbf{r}})=\begin{cases}0,&r<R_{1} 或 r>R_{2},\ $ \frac{\mu_{i}}{\mu_{0}}-1)\frac{2I}{\pi r\mu_{i}\sum_{j}\frac{1}{\mu_{j}}},&R_{1}<r<R_{2}.\end{cases} $$ 

 $ \vec{M}_i(\vec{r}) $ 的方向与该处圆周的切线方向平行，因此，在四个介质之间的分界面上， $ \vec{K}' = \vec{M} \times \vec{n} = 0 $，只有在介质与真空的分界面上有磁化面电流。

在  $ r = R_{1} $ 处:

 $$ \vec{\boldsymbol{K}}_{i}^{\prime}(R_{1})=M_{i}(R_{1})\hat{\boldsymbol{z}}=(\frac{\mu_{i}}{\mu_{0}}-1)\frac{2\boldsymbol{I}}{\pi R_{1}\mu_{i}\sum_{j}\frac{1}{\mu_{j}}}\hat{\boldsymbol{z}} $$ 

在  $ r = R_{2} $ 处:

 $$ \vec{K}_{i}^{\prime}(R_{2})=-M_{i}(R_{2})\hat{z}=-(\frac{\mu_{i}}{\mu_{0}}-1)\frac{2I}{\pi R_{2}\mu_{i}\sum_{j}\frac{1}{\mu_{j}}}\hat{z} $$ 

由  $ \vec{H} $ 的边值关系，可知在  $ r = R_{1} $ 和  $ r = R_{2} $ 处的传导面电流密度为：

 $$ \vec{K}_{0,i}(R_{1})=H_{i}(R_{1})\hat{z}=\frac{2I}{\pi R_{1}\mu_{i}\sum_{j}\frac{1}{\mu_{j}}}\hat{z} $$ 

 $$ \vec{\mathbf{K}}_{0,i}(R_{2})=-H_{i}(R_{2})\hat{\mathbf{z}}=\frac{2I}{\pi R_{2}\mu_{i}\sum_{j}\frac{1}{\mu_{j}}}\hat{\mathbf{z}} $$ 