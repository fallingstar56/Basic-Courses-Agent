1. 体积 V 内的总电磁能随时间的变化率为：

 $$ \iiint_{V}\frac{\partial w}{\partial t}\mathrm{d}V $$ 

2. 电磁场对体积 V 内的带电粒子做功的功率为：

 $$ \iiint_{V}n\vec{F}\cdot\vec{v}\mathrm{d}V=\iiint_{V}n q\vec{E}\cdot\vec{v}\mathrm{d}V=\iiint_{V}\rho\vec{E}\cdot\vec{v}\mathrm{d}V=\iiint_{V}\vec{E}\cdot\vec{J}_{0}\mathrm{d}V $$ 

3. 为了表征能量从闭合表面 S 的流出，我们定义能流密度矢量  $ \vec{S} $，其大小为单位时间内通过能量传播方向流动的单位面积的能量，其方向为能量流动的方向。因此，单位时间从闭合表面 S 流出的总能量为：

 $$ \iint_{S}\vec{S}\cdot\mathrm{d}\vec{\sigma}=\iiint_{V}\nabla\cdot\vec{S}\mathrm{d}V $$ 

2967 由能量守恒，上述三个量之间的关系为：

 $$ -\iiint_{V}\frac{\partial w}{\partial t}\mathrm{d}V=\iiint_{V}\vec{E}\cdot\vec{J}_{0}\mathrm{d}V+\iiint_{V}\nabla\cdot\vec{S}\mathrm{d}V $$ 

2968 写成微分形式为：

 $$ \nabla\cdot\vec{S}+\frac{\partial w}{\partial t}=-\vec{E}\cdot\vec{J}_{0} $$ 

上式也被称为坡印廷定理（Poyning's theorem），能量密度矢量  $ \vec{S} $ 也称为坡印廷矢量。

下面，我们将进一步推导，得出坡印廷矢量  $ \vec{S} $ 的具体表达式。首先，由9.79式，可知：

 $$ \frac{\partial w}{\partial t}=\varepsilon\vec{E}\cdot\frac{\partial\vec{E}}{\partial t}+\frac{\vec{B}}{\mu}\cdot\frac{\partial\vec{B}}{\partial t} $$ 

2972 其次，由麦克斯韦方程组，可将9.84式中的  $ \vec{E} \cdot \vec{J}_{0} $ 写成：

 $$ \vec{E}\cdot\vec{J}_{0}=\vec{E}\cdot(\nabla\times\vec{H}-\varepsilon\frac{\partial\vec{E}}{\partial t}) $$ 

 $$ =\vec{E}\cdot\nabla\times\vec{H}-\varepsilon\vec{E}\cdot\frac{\partial\vec{E}}{\partial t} $$ 

2973 由链式法则  $ \nabla \cdot (\vec{E} \times \vec{H}) = \vec{H} \cdot (\nabla \times \vec{E}) - \vec{E} \cdot (\nabla \times \vec{H}) $，可知：

 $$ \vec{E}\cdot\vec{J}_{0}=\vec{H}\cdot(\nabla\times\vec{E})-\nabla\cdot(\vec{E}\times\vec{H})-\varepsilon\vec{E}\cdot\frac{\partial\vec{E}}{\partial t} $$ 

 $$ -\vec{H}\cdot\frac{\partial\vec{B}}{\partial t}-\nabla\cdot(\vec{E}\times\vec{H})-\varepsilon\vec{E}\cdot\frac{\partial\vec{E}}{\partial t} $$ 

2974 将9.85式代入上式，可得：

 $$ \vec{E}\cdot\vec{J}_{0}=-\frac{\partial w}{\partial t}-\nabla\cdot(\vec{E}\times\vec{H}) $$ 