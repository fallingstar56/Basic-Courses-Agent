 $$ \vec{g}=\frac{\vec{E}\times\vec{H}}{c^{2}}=\frac{\vec{S}}{c^{2}}=\vec{D}\times\vec{B} $$ 

由于电磁波有动量，当电磁波入射到物体表面而被反射或者被吸收时，电磁波的动量将发生改变，而由牛顿第二定律：

 $$ \vec{F}=\frac{\mathrm{d}\vec{p}}{\mathrm{d}t} $$ 

电磁波动量的改变意味着电磁波会受到来自物体表面的一个作用力，或者说物体表面会受到电磁波的一个作用力。如右图所示，假设电磁波垂直入射物体表面，而后发生反射，则在 $ \Delta S $的表面面积、 $ \Delta t $时间内，电磁波的动量改变为：

<div style="text-align: center;"><img src="imgs/img_in_image_box_748_459_1022_654.jpg" alt="Image" width="23%" /></div>


 $$ \Delta p=2\bar{g}\Delta S c\Delta t $$ 

3018 其中， $ \bar{g} $ 为电磁波的动量密度随时间的平均值。对应的， $ \Delta S $ 的面积物体表面受到的力为：

 $$ F=\frac{\Delta p}{\Delta t}=2\bar{g}\Delta S c $$ 

3019或者说，物体表面受到来自电磁波的压强为：

 $$ p_{r}=\frac{F}{\Delta S}=2\bar{g}c=\frac{2\bar{S}}{c}=\frac{2I}{c} $$ 

3020 我们把物体表面受到的这个压强，称为电磁波的辐射压强，也称为光压。

例 9.3

一个半径为 r 的尘埃（密度  $ \rho $ 取  $ 3g/cm^{3} $）在太阳系中，其受到的来自太阳的万有引力和太阳光的光压力之比是多大？当 r 为多大时，这两个力大小相等？

3024 解:

假设尘埃与太阳之间的距离为 R，太阳质量为 M，则尘埃受到的万有引力为：

 $$ F_{g}=\frac{GMm}{R^{2}}=\frac{4GM\rho\pi r^{3}}{3R^{2}} $$ 

3026 太阳的辐射总功率为  $ P_{0}=3.8\times10^{26}W $，则尘埃受到的光的压力为（假设光全部吸收）：

 $$ F_{r}=p_{r}\pi r^{2}=\frac{S\pi r^{2}}{c}=\frac{P_{0}\pi r^{2}}{4\pi R^{2}c} $$ 

3027 万有引力和光压力之比为：

 $$ \frac{F_{g}}{F_{r}}=\frac{16GM\rho\pi cr}{3P_{0}} $$ 