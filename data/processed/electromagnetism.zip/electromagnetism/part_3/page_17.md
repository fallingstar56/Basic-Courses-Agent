<div style="text-align: center;"><img src="imgs/img_in_image_box_333_157_857_424.jpg" alt="Image" width="43%" /></div>


2659

 $$ \begin{aligned}\Psi_{21}&=N_{2}\iint_{S2}\vec{B}_{1}\cdot\mathrm{d}\vec{\boldsymbol{S}}=N_{2}\iint_{S2}\left(\nabla\times\vec{A}_{1}\right)\cdot\mathrm{d}\vec{\boldsymbol{S}}=N_{2}\oint_{L2}\vec{A}_{1}\cdot\mathrm{d}\vec{\boldsymbol{r}}_{2}\\&=N_{2}\oint_{L2}\left(\oint_{L1}\frac{\mu_{0}N_{1}I_{1}\mathrm{d}\vec{r}_{1}}{4\pi|\vec{r}_{2}-\vec{r}_{1}|}\right)\cdot\mathrm{d}\vec{\boldsymbol{r}}_{2}=\frac{\mu_{0}N_{2}N_{1}I_{1}}{4\pi}\oint_{L2}\oint_{L1}\frac{\mathrm{d}\vec{r}_{1}\cdot\mathrm{d}\vec{r}_{2}}{|\vec{r}_{2}-\vec{r}_{1}|}\end{aligned} $$ 

2660 可知，当线圈 1 中的电流变化时，线圈 2 中的磁通量也会发生相应的变化，因而会在线圈 2661 中产生感应电动势：

 $$ \mathcal{E}_{21}=-\frac{\mathrm{d}\Psi_{21}}{\mathrm{d}t}=-\frac{\mu_{0}N_{2}N_{1}}{4\pi}\oint_{L2}\oint_{L1}\frac{\mathrm{d}\vec{r}_{1}\cdot\mathrm{d}\vec{r}_{2}}{\left|\vec{r}_{2}-\vec{r}_{1}\right|}\frac{\mathrm{d}I_{1}}{\mathrm{d}t} $$ 

2662 令：

 $$ M_{21}=\frac{\mu_{0}N_{2}N_{1}}{4\pi}\oint_{L2}\oint_{L1}\frac{\mathrm{d}\vec{r}_{1}\cdot\mathrm{d}\vec{r}_{2}}{\left|\vec{r}_{2}-\vec{r}_{1}\right|} $$ 

2663 则：

 $$ \Psi_{21}=M_{21}I_{1} $$ 

2664

 $$ \mathcal{E}_{21}=-M_{21}\frac{\mathrm{d}I_{1}}{\mathrm{d}t} $$ 

2665 即，一个线圈中电流的变化，会在另一个线圈中产生感应电动势，我们把这种现象，称为互感现象，产生的电动势，称为互感电动势。在线圈 2 中产生的感应电动势的大小，与线圈 1 中的电流随时间变化的速率成正比。而上式中的比例系数  $ M_{21} $，称为线圈 1 对线圈 2 的互感系数（mutual inductance）。

类似的，可以得出，当线圈 2 中电流变化时，线圈 1 中产生的互感电动势为：

 $$ \mathcal{E}_{12}=-M_{12}\frac{\mathrm{d}I_{2}}{\mathrm{d}t} $$ 

2670 其中，

 $$ M_{12}=\frac{\mu_{0}N_{1}N_{2}}{4\pi}\oint_{L1}\oint_{L2}\frac{\mathrm{d}\vec{r}_{2}\cdot\mathrm{d}\vec{r}_{1}}{|\vec{r}_{2}-\vec{r}_{1}|} $$ 

2671 可以看出， $ M_{12} $ 和  $ M_{21} $ 都只跟两个线圈的形状、大小、匝数、相对位置等有关，与线圈中