760 下面，我们来计算任意带电体系产生的静电场的旋度：

 $$ \nabla\times\vec{E}(\vec{r})=\nabla\times\left[\frac{1}{4\pi\varepsilon_{0}}\iiint_{V}\rho(\vec{r}_{0})\frac{\vec{r}-\vec{r}_{0}}{|\vec{r}-\vec{r}_{0}|^{3}}\mathrm{d}^{3}\vec{r}_{0}\right]=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V}\rho(\vec{r}_{0})\nabla\times\frac{\vec{r}-\vec{r}_{0}}{|\vec{r}-\vec{r}_{0}|^{3}}\mathrm{d}^{3}\vec{r}_{0} $$ 

761 问题转换成了形如  $ \frac{\vec{r}-\vec{r}_{0}}{|\vec{r}-\vec{r}_{0}|^{3}} $ 的矢量场的旋度的计算：

 $$ \nabla\times\frac{\vec{r}-\vec{r}_{0}}{\left|\vec{r}-\vec{r}_{0}\right|^{3}} $$ 

762 由于旋度的计算结果与坐标系的选取无关，因此可以将坐标系平移至以  $ \vec{r}_{0} $ 为中心，即：

 $$ \nabla\times\frac{\vec{r}-\vec{r}_{0}}{\left|\vec{r}-\vec{r}_{0}\right|^{3}}=\nabla\times\frac{\vec{r}}{r^{3}} $$ 

763 根据上一章中习题1.9得出的旋度在球坐标系中的表达式：

 $$ \nabla\times\vec{\boldsymbol{F}}=\hat{\boldsymbol{r}}\frac{1}{r\sin\theta}\bigg(\frac{\partial(F_{\phi}\sin\theta)}{\partial\theta}-\frac{\partial F_{\theta}}{\partial\phi}\bigg)+\hat{\phi}\frac{1}{r}\bigg(\frac{\partial F_{r}}{\partial\phi}-\frac{\partial(r F_{\phi})}{\partial r}\bigg)+\hat{\boldsymbol{z}}\frac{1}{r}\bigg(\frac{\partial(r F_{\theta})}{\partial r}-\frac{\partial F_{r}}{\partial\theta}\bigg) $$ 

764 我们可以得出：

 $$ \nabla\times\frac{\vec{r}}{r^{3}}=\hat{\boldsymbol{r}}\frac{1}{r\sin\theta}(0-0)+\hat{\phi}\frac{1}{r}(0-0)+\hat{z}\frac{1}{r}(0-0)=0 $$ 

765 因此，2.88式变成：

 $$ \nabla\times\vec{E}(\vec{r})=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V}\rho(\vec{r}_{0})\nabla\times\frac{\vec{r}-\vec{r}_{0}}{|\vec{r}-\vec{r}_{0}|^{3}}\mathrm{d}^{3}\vec{r}_{0}=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V}\rho(\vec{r}_{0})\cdot0\cdot\mathrm{d}^{3}\vec{r}_{0}=0 $$ 

766 从而我们可以把电场的斯托克斯定理（2.87式）写成：

 $$ \oint_{C}\vec{E}\cdot\mathrm{d}\vec{r}=\iint_{\vec{S}}(\nabla\times\vec{E})\cdot\mathrm{d}\vec{S}=0 $$ 

767 从而我们便得出了静电场的环路定理：

### 定理 2.2 静电场的环路定理

静电场沿任意闭合路径的积分等于零：

 $$  环量 =\oint_{C}\vec{E}\cdot\mathrm{d}\vec{r}=0 $$ 

该式的微分形式为：

 $$ \nabla\times\vec{E}=0 $$ 

需要指出的是，环路定理同样也是库仑定律和叠加原理的必然结果。由于静电场沿任意闭合路径的积分等于零，根据我们第一章学习的保守场的讨论，我们知道，静电场的这一性质表明静电场是保守场，即静电场对电荷做的功与电荷的运动路径无关，只与电荷运动的起始和结束点有关。

 $$ 772 $$ 