### 2.4 高斯定理

688 因此，将矢量场的高斯定理应用到电场中，我们有：

 $$ \begin{aligned}\iint_{\vec{S}}\vec{E}\cdot\mathrm{d}\vec{S}&=\iiint_{V}\nabla\cdot\vec{E}(\vec{r})\mathrm{d}V\\&=\iiint_{V}\sum_{i=1}^{N}\frac{q_{i}}{\varepsilon_{0}}\delta(\vec{r}-\vec{r}_{i})\mathrm{d}V\\&=\sum_{i=1}^{N}\frac{q_{i}}{\varepsilon_{0}}\iiint_{V}\delta(\vec{r}-\vec{r}_{i})\mathrm{d}V\\&=\frac{1}{\varepsilon_{0}}\sum_{\vec{r}_{i}\text{in}V}q_{i}\\&=\frac{1}{\varepsilon_{0}}Q_{\text{in}}\end{aligned} $$ 

689 其中， $ Q_{in} $ 是闭合曲面  $ \vec{S} $ 内部电荷总量。

对于连续分布的电荷的情况，类似的我们有：

 $$ \nabla\cdot\vec{E}(\vec{r})=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V}\rho(\vec{r}_{0})\nabla\cdot\frac{\vec{r}-\vec{r}_{0}}{|\vec{r}-\vec{r}_{0}|^{3}}\mathrm{d}^{3}\vec{r}_{0}=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V}\rho(\vec{r}_{0})4\pi\delta(\vec{r}-\vec{r}_{0})\mathrm{d}^{3}\vec{r}_{0}=\frac{\rho(\vec{r})}{\varepsilon_{0}} $$ 

691 对应的矢量场的高斯定理为：

 $$ \begin{aligned}\iint_{\vec{S}}\vec{E}\cdot\mathrm{d}\vec{S}&=\iiint_{V}\nabla\cdot\vec{E}(\vec{r})\mathrm{d}V\\&=\iiint_{V}\frac{\rho(\vec{r})}{\varepsilon_{0}}\mathrm{d}V\\&=\frac{1}{\varepsilon_{0}}Q_{\mathrm{in}}\end{aligned} $$ 

692 这样，我们便得到了电场的高斯定理：

### 定理 2.1 电场的高斯定理

真空中的静电场  $ \vec{E} $ 通过任意闭合曲面  $ \vec{S} $ 的通量，等于该闭合曲面所包围的体积内的电荷量的代数和的  $ \frac{1}{\varepsilon_{0}} $ 倍，即：

 $$ \Phi_{\vec{E}}=\iint_{\vec{S}}\vec{E}\cdot\mathrm{d}\vec{S}=\frac{Q_{\mathrm{in}}}{\varepsilon_{0}} $$ 

上式对应的微分形式为：

 $$ \nabla\cdot\vec{E}(\vec{r})=\frac{\rho(\vec{r})}{\varepsilon_{0}} $$ 

也就是说，只有闭合曲面内部的电荷对总通量有贡献，闭合曲面外部的电荷产生的电场在闭合曲面上的净通量永远为 0。这一特点，是由电场强度的平方反比形式（即  $ \frac{\vec{r}}{r^3} $）决定的，由于这一平方反比与计算面积时出现的  $ r^2 $ 刚好抵消，导致点电荷产生的电场在任意曲面上的通量只跟这个曲面对点电荷所张开的立体角大小有关（即  $ \iint_S \frac{\vec{r}}{r^3} d\vec{S} = d\Omega $），而跟这个曲面的位置无关。当点电荷位于闭合曲面外部时，闭合曲面刚好有两个相对点电荷所张开立体角相等但法向