1248

2. 导体球面面电荷密度为：



 $$ \sigma_{e}(\vec{r})=-\varepsilon_{0}\frac{\partial U}{\partial n}\bigg|_{r=R}=-\varepsilon_{0}\frac{\partial U}{\partial r}\bigg|_{r=R} $$ 

1249 其中，电势 U 在球坐标系中的表达式为：

 $$ \begin{aligned}U(\vec{r})&=\frac{1}{4\pi\varepsilon_{0}}\Big(\frac{Q}{r_{a}}+\frac{q}{r_{b}}\Big)\\&=\frac{1}{4\pi\varepsilon_{0}}\Big(\frac{Q}{\sqrt{r^{2}+a^{2}-2ar\cos\theta}}-\frac{R}{a}\frac{Q}{\sqrt{r^{2}+b^{2}-2br\cos\theta}}\Big)\end{aligned} $$ 

1250 因此，

 $$ \begin{aligned}\sigma_{e}(\vec{r})&=-\varepsilon_{0}\frac{\partial U}{\partial r}\bigg|_{r=R}\\&=-\frac{Q}{4\pi}\bigg(-\frac{R-a\cos\theta}{(R^{2}+a^{2}-2aR\cos\theta)^{3/2}}+\frac{R}{a}\frac{R-b\cos\theta}{(R^{2}+b^{2}-2bR\cos\theta)^{3/2}}\bigg)\\&=-\frac{Q}{4\pi}\bigg(-\frac{R-a\cos\theta}{(R^{2}+a^{2}-2aR\cos\theta)^{3/2}}+\frac{R}{a}\frac{R-(R^{2}/a)\cos\theta}{(R^{2}+(R^{2}/a)^{2}-2(R^{2}/a)R\cos\theta)^{3/2}}\bigg)\\&=-\frac{Q}{4\pi}\bigg(-\frac{R-a\cos\theta}{(R^{2}+a^{2}-2aR\cos\theta)^{3/2}}+\frac{R}{a}\frac{R-(R^{2}/a)\cos\theta}{(R^{2}/a^{2})^{3/2}(R^{2}+a^{2}-2aR\cos\theta)^{3/2}}\bigg)\\&=-\frac{Q(a^{2}-R^{2})}{4\pi R(R^{2}+a^{2}-2aR\cos\theta)^{3/2}}\\ \end{aligned} $$ 

1251 总电荷为：

 $$ \begin{aligned}q_{e}&=\int\sigma_{e}\mathrm{d}S\\&=\int_{0}^{\pi}-\frac{Q(a^{2}-R^{2})}{4\pi R(R^{2}+a^{2}-2aR\cos\theta)^{3/2}}2\pi R^{2}\sin\theta\mathrm{d}\theta\\&=\frac{Q(a^{2}-R^{2})}{2a}\frac{1}{\sqrt{R^{2}+a^{2}-2aR\cos\theta}}\bigg|_{0}^{\pi}\\&=-\frac{R}{a}Q\\ \end{aligned} $$ 

1252 当然，计算球面总电荷时，也可以利用球心处电势为零来计算，注意到球面上的电荷在球心产生的电势与电荷具体在球面上何处无关，所以球心处的总电势为：

 $$ 0=U_{O}=\frac{Q}{4\pi\varepsilon_{0}a}+\frac{q_{e}}{4\pi\varepsilon_{0}R} $$ 

1254 可得：

 $$ q_{e}=-\frac{R}{a}Q $$ 

3. 若导体球不接地且总电荷为零，此时导体球面仍然为一个等势体，但是电势不一定为零。此时，可以引入两个镜像电荷，其中一个是第1问中的位于 $ R^{2}/a $处的负电荷 $ -\frac{R}{a}Q $，另一个是位于球心处的正电荷 $ \frac{R}{a}Q $，注意到引入的负镜像电荷与Q产生的电场在球面是个等势面，而引