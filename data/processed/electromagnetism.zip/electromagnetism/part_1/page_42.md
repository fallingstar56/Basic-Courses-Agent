1417 定理，可得：

 $$ \begin{aligned}U(\vec{r})&=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V^{\prime}}\vec{P}\cdot\nabla^{\prime}\left(\frac{1}{\left|\vec{r}-\vec{r}^{\prime}\right|}\right)\mathrm{d}V^{\prime}\\&=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V^{\prime}}\left[\nabla^{\prime}\cdot\left(\frac{\vec{P}}{\left|\vec{r}-\vec{r}^{\prime}\right|}\right)-\frac{\nabla^{\prime}\cdot\vec{P}}{\left|\vec{r}-\vec{r}^{\prime}\right|}\right]\mathrm{d}V^{\prime}\\&=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V^{\prime}}\nabla^{\prime}\cdot\left(\frac{\vec{P}}{\left|\vec{r}-\vec{r}^{\prime}\right|}\right)\mathrm{d}V^{\prime}-\frac{1}{4\pi\varepsilon_{0}}\iiint_{V^{\prime}}\frac{\nabla^{\prime}\cdot\vec{P}}{\left|\vec{r}-\vec{r}^{\prime}\right|}\mathrm{d}V^{\prime}\\&=\frac{1}{4\pi\varepsilon_{0}}\iint_{S^{\prime}}\frac{\vec{P}}{\left|\vec{r}-\vec{r}^{\prime}\right|}\cdot\vec{n}\mathrm{d}S^{\prime}-\frac{1}{4\pi\varepsilon_{0}}\iiint_{V^{\prime}}\frac{\nabla^{\prime}\cdot\vec{P}}{\left|\vec{r}-\vec{r}^{\prime}\right|}\mathrm{d}V^{\prime}\end{aligned} $$ 

1418 而对于任意一个体积为  $ V' $ 的电介质，其极化电荷产生的电场在  $ \vec{r} $ 处的电势也等于极化面

1419 电荷和极化体电荷产生的电场的电势的叠加，即：

 $$ U(\vec{\mathbf{r}})=\frac{1}{4\pi\varepsilon_{0}}\iint_{S^{\prime}}\frac{\sigma_{e}^{\prime}(\vec{\mathbf{r}}^{\prime})}{|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|}\mathrm{d}S^{\prime}+\frac{1}{4\pi\varepsilon_{0}}\iiint_{V^{\prime}}\frac{\rho_{e}^{\prime}(\vec{\mathbf{r}}^{\prime})}{|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|}\mathrm{d}V^{\prime} $$ 

1420 由  $ V' $ 的任意性，对比上述两式可知，极化面电荷密度和体电荷密度分别为：

 $$ \sigma_{e}^{\prime}=\vec{P}\cdot\vec{n},\qquad\rho_{e}^{\prime}=-\nabla\cdot\vec{P} $$ 

田此，我们便通过新定义的极化强度矢量 P 这个量，将宏观层面的极化电荷分布与微观层面的单个分子的电偶极矩联系起来。那我们又要如何确定介质中各处的极化强度矢量呢？从  $ \vec{P} $ 的定义我们知道，我们需要计算的是单位体积内所有电偶极矩的矢量和。而在上一节中我们学习到，对于各向同性的线性介质，无论是有极分子还是无极分子，单个分子的平均电偶极矩都是正比于电场的，而且比例系数是一个常数，这个常数只与物质本身的性质有关（不受电场等因素影响）。而对于单个分子而言，它感受到的“电场”不仅包含外界施加给介质的电场，还包括介质产生的极化电荷产生的电场，即这里的“电场”是总电场  $ \vec{E} $。因此，对于各向同性的线性介质，介质中某一点极化强度矢量  $ \vec{P} $ 必然也正比于该点的总电场，且比例系数只与介质本身的性质有关：

 $$ \vec{P}=c\vec{E} $$ 

1430 其中 c 为常数，其量纲为  $  \mathrm{C}^{2} / (\mathrm{N} \cdot \mathrm{m}^{2})  $，与真空介电常数的量纲相同，因此，上式也可以写成：

 $$ \vec{P}=\chi_{e}\varepsilon_{0}\vec{E} $$ 

其中  $ \chi_{e} $ 是一个无量纲的量，我们把它称为电极化率（electric susceptibility）。它是一个大于零的正数，描述的是宏观物质在电场作用下的极化程度，其值越高，表示介质极化程度越高。对于均匀介质， $ \chi_{e} $ 处处相同；而对于不均匀介质， $ \chi_{e} $ 会随着空间的变化而变化。