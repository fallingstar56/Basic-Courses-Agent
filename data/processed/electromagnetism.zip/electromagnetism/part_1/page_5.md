<div style="text-align: center;"><img src="imgs/img_in_image_box_157_166_1015_488.jpg" alt="Image" width="72%" /></div>


### 2.5 环路定理

上一节中，我们计算了电场的面积分及其散度，这一节我们将要计算并讨论静电场的线积分和旋度及它们的物理意义。

首先我们来看一下电场的线积分，即  $ \vec{E} $ 沿着某一路径 C 的线积分：

 $$ \int_{C}\vec{E}\cdot\mathrm{d}\vec{r} $$ 

752 现任，我们设想有一个电量为 q 的试探电荷，沿着路径 C 从一端运动到另一端，那么，在这个过程中，电场对电荷做的功为：

 $$ \begin{aligned}&A=\int_{C}\vec{F}\cdot\mathrm{d}\vec{r}=\int_{C}q\vec{E}\cdot\mathrm{d}\vec{r}\\ &\Rightarrow\int_{C}\vec{E}\cdot\mathrm{d}\vec{r}=\frac{A}{q}\\ \end{aligned} $$ 

754 即：静电场沿某一路径 C 的积分，等于电场对沿该路径运动的单位正电荷做的功。

如果路径 C 为闭合路径, 那么我们称电场在 C 上的路径积分为静电场的环量 (circulation):

 $$  环量 \equiv\oint_{C}\vec{E}\cdot\mathrm{d}\vec{r}=\frac{A}{q} $$ 

由于此处涉及到矢量场在闭合曲线上的线积分，因此我们在第一章所学习的矢量场的斯托克斯定理（定理1.75）对电场同样成立：

 $$ \oint_{C}\vec{E}\cdot\mathrm{d}\vec{r}=\iint_{\vec{S}}(\nabla\times\vec{E})\cdot\mathrm{d}\vec{S} $$ 