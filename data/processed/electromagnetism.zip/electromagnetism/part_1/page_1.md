方向相反的曲面组成，因而点电荷产生的电场在这个闭合曲面的电场净通量为 0.

高斯定理是库仑定律和叠加原理的必然结果，也是麦克斯韦方程组的第一个方程。实际应用中，我们常用高斯定理来计算具有对称性电荷体系所产生的电场。

702

### 例 2.10

求均匀带电球（半径 R，总电荷 q）产生的电场  $ \vec{E}(\vec{r}) $。

解:

如图，令  $ \vec{S} $ 为以 O 为球心、半径为 r 的球面。由对称性， $ \vec{S} $ 上所有的点的电场的大小相同，且方向与  $ \vec{S} $ 的法向平行。由高斯定理：

<div style="text-align: center;"><img src="imgs/img_in_image_box_794_320_1029_506.jpg" alt="Image" width="19%" /></div>


 $$ \begin{aligned}&\iint_{\vec{S}}\vec{E}\cdot\mathrm{d}\vec{S}=\frac{Q_{\mathrm{in}}}{\varepsilon_{0}}\\ &\Rightarrow4\pi r^{2}E=\frac{Q_{\mathrm{in}}}{\varepsilon_{0}}\\ &\Rightarrow E=\frac{Q_{\mathrm{in}}}{4\pi\varepsilon_{0}r^{2}}\\ \end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_823_543_982_670.jpg" alt="Image" width="13%" /></div>


1. 当  $ r \geq R $ 时， $ Q_{\mathrm{in}} = q $，

 $$ E=\frac{q}{4\pi\varepsilon_{0}r^{2}} $$ 

2. 当 r < R 时，

 $$ \begin{aligned}&Q_{in}=q\frac{r^{3}}{R^{3}}\\ &E=\frac{q\frac{r^{3}}{R^{3}}}{4\pi\varepsilon_{0}r^{2}}=\frac{qr}{4\pi\varepsilon_{0}R^{3}}\\ \end{aligned} $$ 

例 2.11

求均匀带电球面产生的电场  $ \vec{E}(\vec{r}) $ （球面半径为 R，总电荷量为 q）

解:

取以带电球面的球心为球心、半径为 r 的球面 S。由对称性， $ \vec{S} $ 上各点的电场大小相等，方向与  $ \vec{S} $ 的法向平行。由高斯定理：

 $$ \begin{aligned}&\iint_{\vec{S}}\vec{E}\cdot\mathrm{d}\vec{S}=\frac{Q_{in}}{\varepsilon_{0}}\\ &\Rightarrow4\pi r^{2}E=\frac{Q_{in}}{\varepsilon_{0}}\\ &\Rightarrow E=\frac{Q_{in}}{4\pi\varepsilon_{0}r^{2}}\\ \end{aligned} $$ 