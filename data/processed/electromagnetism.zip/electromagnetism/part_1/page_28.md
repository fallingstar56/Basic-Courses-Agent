1177

### 例 3.5

如图，点电荷 q 位于 x = a 处，在 x = 0 的平面上有一块无穷大的接地导体平板，求：

1. x > 0 的空间各处的电场强度。

2. 导体平板上各处的面电荷密度及总电荷。

<div style="text-align: center;"><img src="imgs/img_in_image_box_792_166_1030_385.jpg" alt="Image" width="19%" /></div>


解:

1. 这里我们关心的区域，是 x > 0 的所有三维空间，也就是从导体平板到无穷远处。这个区域由导体平板和无穷远处作为边界，边界上电势处处为零。现在我们需要找的，是从点电荷 q 发出的一个电场，使得电场在 x = 0 处电势为零。如果我们回想一下在第二章计算过的带电体系的电场，去寻找存在一个等势面为平面的情况，会发现电偶极子的中垂面刚好是一个等势面。如下面的左图，假如在 x = -a 处有一个电荷为 -q 的电荷，并且我们把 x = 0 处的导体平面去掉，那么由 -q 和 q 这对电荷产生的电场  $ \vec{E} $ 为：

 $$ \vec{E}(\vec{r})=\frac{1}{4\pi\varepsilon_{0}}\bigg(\frac{q(\vec{r}-\vec{a})}{|\vec{r}-\vec{a}|^{3}}-\frac{q(\vec{r}+\vec{a})}{|\vec{r}+\vec{a}|^{3}}\bigg) $$ 

其中， $ \vec{a}=(a,0,0) $。我们注意到，这样一个电场，它在 x=0 处刚好是一个等势面且 U=0 （无穷远处为电势零点）。也就是说，下面左图中的电场，在 x>0 这个区域，完全满足右图中 x>0 区域的电荷分布，而且满足其边界条件（即 x=0 是等势面且与无穷远处电势相等）。

<div style="text-align: center;"><img src="imgs/img_in_image_box_357_870_587_1133.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_643_870_815_1148.jpg" alt="Image" width="14%" /></div>


1187

因此，我们上面通过猜测得到的电场分布（即3.35式），对于题目中所求的 x > 0 这个区域，满足了其给定的电荷分布和边界条件，由唯一性定理，我们找到的这个电场分布，就是这个区域的唯一解。

1191 2. 下面我们求导体平面上的面电荷密度。由3.8式可知，导体平面上任意一点  $ \vec{r} $ 的面电荷密度为：

 $$ \sigma_{e}(\vec{r})=\varepsilon_{0}E\bigg|_{x=0}=\varepsilon_{0}\frac{1}{4\pi\varepsilon_{0}}\bigg(\frac{-2q}{r^{2}+a^{2}}\frac{a}{\sqrt{r^{2}+a^{2}}}\bigg)=\frac{-qa}{2\pi(r^{2}+a^{2})^{3/2}} $$ 

1193 总电荷为：

 $$ Q=\int\sigma_{e}\mathrm{d}S=\int_{0}^{\infty}\frac{-qa}{2\pi(r^{2}+a^{2})^{3/2}}2\pi r\mathrm{d}r=qa\frac{1}{\sqrt{r^{2}+a^{2}}}\bigg|_{0}^{\infty}=-q $$ 