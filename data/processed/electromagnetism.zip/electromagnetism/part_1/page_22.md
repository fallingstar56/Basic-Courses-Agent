### 例 3.2

034 如下图所示，将一个不带电的导体球放入一个均匀外场  $ \vec{E} $ 中，求静电平衡后导体球表面电荷分布。

<div style="text-align: center;"><img src="imgs/img_in_image_box_319_285_873_611.jpg" alt="Image" width="46%" /></div>


1036

1037 解:

由静电平衡，我们知道导体球内部电场为零，而其内部电场等于外场  $ \vec{E} $ 和其自身的表面电荷产生的电场的矢量和，这意味着表面电荷在球内产生的电场为  $ -\vec{E} $，是个均匀电场。那什么样的球面电荷分布会在球内部产生均匀电场呢？在第二章中的例2.14的讨论中我们提到，对于形如  $ \cos\theta $ 的球面电荷分布，其在球内部产生的电场是一个均匀电场。不妨假设球面电荷的面电荷密度分布为：

 $$ \sigma_{e}(\vec{\boldsymbol{r}})=\sigma_{0}\cos\theta $$ 

1043 我们来计算一下这样一个面电荷在球心产生的电场强度。由电荷分布的对称性，球心的电场强度必然与 z 轴（即  $ \vec{E} $ 所在的轴）平行，球面上一个面元在球心产生的电场在 z 轴的分量为：

 $$ \mathrm{d}E_{z}=-\frac{\mathrm{d}q}{4\pi\varepsilon_{0}r^{2}}\cos\theta=-\frac{\sigma\mathrm{d}S}{4\pi\varepsilon_{0}r^{2}}\cos\theta $$ 

1045 其中：

 $$ \sigma=\sigma_{0}\cos\theta,\quad\mathrm{d}S=r^{2}\sin\theta\mathrm{d}\theta\mathrm{d}\phi $$ 

1046 因此，

 $$ \mathrm{d}E_{z}=-\frac{\sigma\mathrm{d}S}{4\pi\varepsilon_{0}r^{2}}\cos\theta=-\frac{\sigma_{0}}{4\pi\varepsilon_{0}}\cos^{2}\theta\sin\theta\mathrm{d}\theta\mathrm{d}\phi $$ 

1047 积分可得：

 $$ \begin{aligned}E_{z}&=\int_{0}^{2\pi}\int_{0}^{\pi}-\frac{\sigma_{0}}{4\pi\varepsilon_{0}}\cos^{2}\theta\sin\theta\mathrm{d}\theta\mathrm{d}\phi\\&=2\pi\int_{0}^{\pi}-\frac{\sigma_{0}}{4\pi\varepsilon_{0}}\cos^{2}\theta\sin\theta\mathrm{d}\theta\\&=\frac{\sigma_{0}}{2\varepsilon_{0}}\int_{0}^{\pi}\cos^{2}\theta\mathrm{d}\cos\theta\end{aligned} $$ 