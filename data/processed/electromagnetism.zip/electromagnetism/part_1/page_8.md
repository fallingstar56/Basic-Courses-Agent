### 2.6 电势

786 P 到点 Q 电场对试探电荷 q 所做的功：

 $$ A_{PQ}=\int_{P}^{Q}q\vec{E}\cdot\mathrm{d}\vec{r}=q\int_{P}^{Q}\nabla\Phi(\vec{r})\cdot\mathrm{d}\vec{r}=q\int_{P}^{Q}\mathrm{d}\Phi=q\Phi(Q)-q\Phi(P) $$ 

787 由能量守恒，电场力对点电荷做的功，必然等于这个系统某种能量的减少，对于保守场，其做功的能量来源是保守场的势能 W，即：

 $$ A_{PQ}=W(P)-W(Q) $$ 

789 比较2.103式和2.104式我们发现，我们可以把势能函数定义为：

 $$ W(\vec{r})=-q\Phi(r)=-q\int_{\infty}^{\vec{r}}\vec{E}\cdot\mathrm{d}\vec{r}=q\int_{\vec{r}}^{\infty}\vec{E}\cdot\mathrm{d}\vec{r} $$ 

790 需要注意的是，上述定义我们实际上是把无穷远处定义为势能为零的地方，实际上势能为零的地方可以任意选取，因为讨论势能的绝对大小是没有意义的，只有势能的改变才具有实际意义，实际应用或研究电路问题时，我们常常把大地或者仪器外壳等处定义为势能为零的地方。势能不仅与电场的性质有关，还与试探电荷本身的电荷大小有关。为了表征电场本身的“势”，我们定义一个只跟电场有关的量，叫电势  $ U(\vec{r}) $，其定义为：

 $$  电势 \quad U(\vec{r})\equiv\int_{\vec{r}}^{\infty}\vec{E}\cdot\mathrm{d}\vec{r} $$ 

796 写成微分形式，上式等价于：

 $$ \vec{E}(\vec{r})=-\nabla U(\vec{r}) $$ 

797 电势的单位是 V（伏特）。有了电势的定义，电荷 q 在电场中的势能便可以写成：

 $$ W(\vec{\mathbf{r}})=q U(\vec{\mathbf{r}}) $$ 

798 2.103式也可以写成：

 $$ A_{PQ}=\int_{P}^{Q}q\vec{E}\cdot\mathrm{d}\vec{r}=q\Big[U(P)-U(Q)\Big] $$ 

799 即：电场力做正功，等于势能的减少。

800 根据点电荷电场的形式及2.106，很容易计算出点电荷 q 产生的电场的电势为：

 $$ U(\vec{\bf r})=\frac{q}{4\pi\varepsilon_{0}r} $$ 

801 由电场的叠加原理，可得电势的叠加原理，即带电体系产生的电场在某点的电势为各点电荷在该点的电势的代数和：

 $$ U(\vec{\mathbf{r}})=\sum_{1}^{N}U_{i}(\vec{\mathbf{r}})=\sum_{1}^{N}\frac{q_{i}}{4\pi\varepsilon_{0}|\vec{\mathbf{r}}-\vec{\mathbf{r}}_{i}|} $$ 