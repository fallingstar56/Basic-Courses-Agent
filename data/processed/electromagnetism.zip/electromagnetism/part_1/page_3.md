724 场大小相等且方向与  $ \vec{S}_{side} $ 法向平行。因此，由高斯定理：

 $$ \begin{aligned}&\iint_{\vec{S}}\vec{E}\cdot\mathrm{d}\vec{S}=\iint_{\vec{S}_{\mathrm{up}}+\vec{S}_{\mathrm{down}}}\vec{E}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{\mathrm{side}}}\vec{E}\cdot\mathrm{d}\vec{S}=\frac{Q_{\mathrm{in}}}{\varepsilon_{0}}\\ &\Rightarrow0+2\pi r h E=\frac{Q_{\mathrm{in}}}{\varepsilon_{0}}\\ &\Rightarrow E=\frac{Q_{\mathrm{in}}}{2\pi\varepsilon_{0}r h}\\ \end{aligned} $$ 

1. 当 r < R 时， $ Q_{in} = 0 $，E = 0

2. 当 r > R 时， $ Q_{\mathrm{in}} = 2\pi Rh\sigma_{e} $

 $$ E=\frac{2\pi R h\sigma_{e}}{2\pi\varepsilon_{0}r h}=\frac{\sigma_{e}R}{\varepsilon_{0}r} $$ 

3. 当  $ r \rightarrow R + $ 时（即在无限贴近圆柱面外表面的地方），

 $$ E\rightarrow\frac{\sigma_{e}}{\varepsilon_{0}} $$ 

该结果与带电球面的外表面附近的电场强度一致。电场在圆柱面内外两侧发生了从 0 到  $ \frac{\sigma_{e}}{\varepsilon_{0}} $ 的突变。

730

### 例 2.13

求无限大带电平板（电荷面密度  $ \sigma_{e} $）产生的电场  $ \vec{E}(z) $

解:

由对称性，平板外任意一点的电场的方向应当与平板垂直，且在与平板平行的平面上各点的电场强度应当相等。如图，以 P 点为原型作平行于平板的一个圆 S，并以 S 为底作一个高度为 2z 的圆柱，圆柱的另一个底面在平板的另一侧。对圆柱体表面应用高斯定理：

<div style="text-align: center;"><img src="imgs/img_in_image_box_751_903_1026_1122.jpg" alt="Image" width="23%" /></div>


 $$ \begin{aligned}&\iint\vec{E}\cdot\mathrm{d}\vec{S}=\iint_{\vec{S}_{left}}\vec{E}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{right}}\vec{E}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{side}}\vec{E}\cdot\mathrm{d}\vec{S}=\frac{Q_{in}}{\varepsilon_{0}}\\ &\Rightarrow ES+ES+0=\frac{\sigma_{e}S}{\varepsilon_{0}}\\ &\Rightarrow E=\frac{\sigma_{e}}{2\varepsilon_{0}}\\ \end{aligned} $$ 

732 即：

 $$ \vec{E}(z)=\begin{cases}\frac{\sigma_{e}}{2\varepsilon_{0}}\hat{z},&z>0,\\-\frac{\sigma_{e}}{2\varepsilon_{0}}\hat{z},&z<0.\end{cases} $$ 

733 该电场在 z = 0 处不连续。