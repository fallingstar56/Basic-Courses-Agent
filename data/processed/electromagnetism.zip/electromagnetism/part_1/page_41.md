1403 由电荷守恒，介质内部的体电荷总数应该为上述总表面电荷的负数：

 $$ Q_{ 体 }^{\prime}=\iiint_{V}\rho_{e}^{\prime}\mathrm{d}V=-Q_{ 面 }^{\prime}=-\iint_{\vec{S}}\vec{P}\cdot\mathrm{d}\vec{S} $$ 

1404 由高斯定理（定理1.63），上式可以写成：

 $$ \iiint_{V}\rho_{e}^{\prime}\mathrm{d}V=-\iint_{\vec{S}}\vec{P}\cdot\mathrm{d}\vec{S}=-\iiint_{V}\nabla\cdot\vec{P}\mathrm{d}V $$ 

由于绝缘体介质内部没有电荷的宏观移动，因此上述电荷守恒对介质内任意一个闭合表面及其围起来的体积都是成立的，也就是上式对任意体积 V 都成立，从而，我们可以得出，介质内部的极化体电荷密度为：

 $$ \rho_{e}^{\prime}=-\nabla\cdot\vec{P} $$ 

实际上，上面关于面电荷密度及体电荷密度与极化强度矢量的关系也可以通过直接叠加物质中各个电偶极子产生的电场推导出来。由2.16式，一个中心点位于  $ \vec{r}^{i} $ 的电偶极子产生的电场在远处  $ \vec{r} $ 的电势为：

 $$ U(\vec{\boldsymbol{r}})=\frac{\vec{\boldsymbol{p}}\cdot(\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}^{\prime})}{4\pi\varepsilon_{0}|\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}^{\prime}|^{3}} $$ 

1412 因此，在  $ \vec{r}' $ 附近一个大小为  $ dV' $ 的体积微元内所有电偶极子产生的电场在  $ \vec{r} $ 处的电势为：

 $$ \mathrm{d}U(\vec{\boldsymbol{r}})=\frac{\sum_{i}\vec{p}_{i}\cdot(\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}^{\prime})}{4\pi\varepsilon_{0}|\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}^{\prime}|^{3}} $$ 

1413 由极化强度矢量的定义（4.11式），上式可写成：

 $$ \mathrm{d}U(\vec{r})=\frac{\vec{P}\cdot(\vec{r}-\vec{r}^{\prime})\mathrm{d}V^{\prime}}{4\pi\varepsilon_{0}|\vec{r}-\vec{r}^{\prime}|^{3}} $$ 

1414 因此，对任意一个体积为  $ V' $ 的电介质，其极化电荷产生的电场在  $ \vec{r} $ 处的电势为：

 $$ \begin{aligned}U(\vec{r})&=\int\mathrm{d}U(\vec{r})\\&=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V^{\prime}}\frac{\vec{P}\cdot(\vec{r}-\vec{r}^{\prime})\mathrm{d}V^{\prime}}{|\vec{r}-\vec{r}^{\prime}|^{3}}\end{aligned} $$ 

1415 我们注意到：

 $$ \nabla^{\prime}\bigg(\frac{1}{|\vec{r}-\vec{r}^{\prime}|}\bigg)=\frac{\vec{r}-\vec{r}^{\prime}}{|\vec{r}-\vec{r}^{\prime}|^{3}} $$ 

1416 代入4.20式并利用散度的乘积法则（即： $ \nabla \cdot (\phi \vec{F}) = \phi \nabla \cdot \vec{F} + (\nabla \phi) \cdot \vec{F} $，见习题1.13）以及高斯