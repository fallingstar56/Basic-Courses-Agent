1494 得：

 $$ \vec{D}(\vec{r})=\frac{q}{4\pi r^{2}}\hat{\boldsymbol{r}} $$ 

1495 由于是各向同性线性介质，可知总电场强度为：

 $$ \vec{E}(\vec{r})=\frac{\vec{D}}{\varepsilon}=\frac{q}{4\pi\varepsilon r^{2}}\hat{\boldsymbol{r}} $$ 

1496 极化强度矢量  $ \vec{P} $ 为：

 $$ \vec{P}(\vec{r})=\chi_{e}\varepsilon_{0}\vec{E}=(\varepsilon_{r}-1)\varepsilon_{0}\vec{E}=(\varepsilon-\varepsilon_{0})\vec{E}=\frac{q\left(\varepsilon-\varepsilon_{0}\right)}{4\pi\varepsilon r^{2}}\hat{\boldsymbol{r}} $$ 

1497 贴近金属表面的油面上的极化面电荷密度为：

 $$ \sigma^{\prime}=\vec{P}(\vec{R})\cdot\vec{n}=\vec{P}(\vec{R})\cdot(-\hat{\boldsymbol{r}})=-\frac{q(\varepsilon-\varepsilon_{0})}{4\pi\varepsilon R^{2}} $$ 

1498 油内的极化体电荷密度为（参见2.63式）：

 $$ \rho^{\prime}=-\nabla\cdot\vec{\boldsymbol{P}}=-\frac{q(\varepsilon-\varepsilon_{0})}{4\pi\varepsilon}\nabla\cdot\frac{\hat{\boldsymbol{r}}}{r^{2}}=-\frac{q(\varepsilon-\varepsilon_{0})}{4\pi\varepsilon}4\pi\delta(\vec{\boldsymbol{r}})=-\frac{q(\varepsilon-\varepsilon_{0})}{\varepsilon}\delta(\vec{\boldsymbol{r}}) $$ 

1499 由于油内 r > 0，因而  $ \rho' = 0 $

1500

例 4.5

如图所示，一个半径为 R 的各向同性线性均匀介质球，其球心处有一个自由点电荷 q，求各处电场、介质球球面上的极化面电荷密度  $ \sigma' $ 、以及介质内部极化体电荷密度  $ \rho' $ 。

<div style="text-align: center;"><img src="imgs/img_in_image_box_836_823_1031_1010.jpg" alt="Image" width="16%" /></div>


解：

如图所示，在取一半径为 r 、与介质球同心的球面 S ，由对称性及  $ \vec{D} $ 的高斯定理：

 $$ q=\iint_{S}\vec{D}\cdot\mathrm{d}\vec{S}=4\pi r^{2}D $$ 

1501 得：

 $$ \vec{D}(\vec{r})=\frac{q}{4\pi r^{2}}\hat{\boldsymbol{r}} $$ 

1502 由于是各向同性线性介质，可知总电场强度为：

 $$ \vec{E}(\vec{\boldsymbol{r}})=\begin{cases}\frac{\vec{D}}{\varepsilon}=\frac{q}{4\pi\varepsilon r^{2}}\hat{\boldsymbol{r}},&r<R,\\\frac{\vec{D}}{\varepsilon_{0}}=\frac{q}{4\pi\varepsilon_{0}r^{2}}\hat{\boldsymbol{r}},&r>R.\end{cases} $$ 

1503 介质球内的极化强度矢量为：

 $$ \vec{P}=(\varepsilon-\varepsilon_{0})\vec{E}=\frac{q(\varepsilon-\varepsilon_{0})}{4\pi\varepsilon r^{2}}\hat{\boldsymbol{r}} $$ 