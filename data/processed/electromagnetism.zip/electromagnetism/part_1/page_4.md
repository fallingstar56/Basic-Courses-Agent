734

### 例 2.14

均匀带电球体（半径 R，体电荷密度  $ \rho_{e} $）内挖掉一个半径为 r 的空腔，求空腔内的电场。

解:

如图所示，由叠加原理，该带电体系可以看成一个完整的半径为 R、体电荷密度  $ \rho_{e} $ 的大带电球和一个半径为 r、体电荷密度  $ -\rho_{e} $ 的小带电球的叠加。

<div style="text-align: center;"><img src="imgs/img_in_image_box_755_179_1022_434.jpg" alt="Image" width="22%" /></div>


由例2.10可知，均匀带电球在其内部的电场为：

 $$ \vec{E}=\frac{q\vec{r}}{4\pi\varepsilon_{0}R^{3}}=\frac{\rho_{e}\vec{r}}{3\varepsilon_{0}} $$ 

736 因此，大带电球和小带电球在 P 点产生的电场分别为：

 $$ \vec{E}_{+}=\frac{\rho_{e}\vec{r}_{1}}{3\varepsilon_{0}} $$ 

 $$ \vec{E}_{-}=\frac{-\rho_{e}\vec{r}_{2}}{3\varepsilon_{0}} $$ 

737 两者矢量叠加便得到了 P 点总的电场强度：

 $$ \vec{E}=\vec{E}_{+}+\vec{E}_{-}=\frac{\rho_{e}\vec{r}_{1}}{3\varepsilon_{0}}+\frac{-\rho_{e}\vec{r}_{2}}{3\varepsilon_{0}}=\frac{\rho_{e}(\vec{r}_{1}-\vec{r}_{2})}{3\varepsilon_{0}}=\frac{\rho_{e}\vec{a}}{3\varepsilon_{0}} $$ 

即：空腔内的电场是均匀电场，方向与两圆心组成的矢量同向（ $ \vec{a}=O\vec{O}' $），大小是  $ \frac{\rho_{e}a}{3\varepsilon_{0}} $。

上述结论也可以应用到两个半径相同、带等量异号的电荷的球有部分重叠的情况，如下图左图所示，两球的重叠部分净电荷密度为 0，该部分的空间内的电场为：

 $$ \vec{E}=\frac{\rho_{e}\vec{a}}{3\varepsilon_{0}} $$ 

当两个球之间的距离逐渐缩小时，重叠部分（电荷空腔）的体积逐渐增大，此时空腔内的电场依然是均匀场。当两个球无限靠近后近似变成一个球时，这个时候只有球的表面有电荷分布，球内部没有电荷且电场为均匀场。如下面右图所示，球表面带电部分的“壁厚”与该处的θ角的关系是 $ d = a \cos \theta $，即这个时候如果简化成面电荷分布，那面电荷密度将呈现 $ \cos \theta $的分布。也就是说，对于一个表面电荷分布为形如 $ \cos \theta $的球面电荷系统，其在球内部产生的电场是一个均匀电场。