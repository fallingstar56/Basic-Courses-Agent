1390

### 4.2 极化强度矢量  $ \vec{P} $

定量计算有介质存在时的电场分布的关键在于计算极化产生的极化电荷的分布，下面我们以介质表面的面电荷密度为例，来推导极化面电荷密度与极化产生的分子的电偶极矩的关系。

如图所示，假设在物质的一个足够小的表面 d $ \vec{S} $ 内侧紧贴表面有 N 个分子，每个分子的平均电偶极矩为  $ \vec{p}=q\vec{L} $ 且都与 d $ \vec{S} $ 的法向平行，则 d $ \vec{S} $ 上的极化面电荷密度为：

 $$ \sigma_{e}^{\prime}=\frac{Nq}{\mathrm{d}S} $$ 

为了能将上式与分子的电偶极矩联系起来，我们可以在分子分母都乘以 L:

<div style="text-align: center;"><img src="imgs/img_in_image_box_747_344_1029_564.jpg" alt="Image" width="23%" /></div>


 $$ \sigma_{e}^{\prime}=\frac{Nq}{\mathrm{d}S}=\frac{NqL}{\mathrm{d}S\cdot L}=\left|\frac{\sum_{i=1}^{N}\vec{p}_{i}}{\mathrm{d}V}\right| $$ 

其中， $ \sum_{i=1}^{N}\vec{p}_{i} $ 为体积微元 dV 内的分子的总电偶极矩，即上式可以理解为，物质表面内侧单位体积内的电偶极矩的矢量和的大小就等于该表面的极化面电荷密度。

若分子的电偶极矩  $ \vec{p} $ 与  $ \mathrm{d}\vec{S} $ 的法向不平行，而是存在一个如右图所示的非零的角度  $ \theta $，则  $ \mathrm{d}V = \mathrm{d}S \cdot L \cos \theta $，因而：

<div style="text-align: center;"><img src="imgs/img_in_image_box_751_593_1024_918.jpg" alt="Image" width="22%" /></div>


 $$ \sigma_{e}^{\prime}=\frac{Nq}{\mathrm{d}S}=\frac{NqL}{\mathrm{d}S\cdot L}=\left|\frac{\sum_{i=1}^{N}\vec{p}_{i}}{\mathrm{d}V}\right|\cos\theta $$ 

如果我们将上式中单位体积内的电偶极矩的矢量和定义为一个新的矢量  $ \vec{P} $ :

 $$ \vec{P}=\frac{\sum_{i=1}^{N}\vec{p}_{i}}{\mathrm{d}V} $$ 

其中 dV 为微观足够大（比分子尺度大很多），宏观足够小（比宏观尺度小很多）的一个体积元。则物质表面的极化面电荷密度便可以写成：

 $$ \sigma_{e}^{\prime}=\vec{P}\cdot\vec{n} $$ 

其中  $ \vec{n} $ 为表面的法向矢量（从物质内部向外为正方向）。我们把上面定义的新的矢量  $ \vec{P} $，称为介质的极化强度矢量。由上式可知，极化强度矢量的量纲与面电荷密度的量纲相同，为  $ C/m^2 $。

由上面定义的极化强度矢量，我们也可以推导出极化体电荷密度的表达式。对于任意一个原本电中性的电介质，经过外加电场的极化之后，其表面总电荷为：

 $$ Q_{ 面 }^{\prime}=\iint_{S}\sigma_{e}^{\prime}\mathrm{d}S=\iint_{S}\vec{P}\cdot\vec{n}\mathrm{d}S=\iint_{\vec{S}}\vec{P}\cdot\mathrm{d}\vec{S} $$ 