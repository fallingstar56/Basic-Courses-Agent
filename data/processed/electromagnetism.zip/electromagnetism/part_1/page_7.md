实际上，关于静电场是保守场的结论，我们也可以直接通过计算静电场对电荷的做功得出。如图所示，在点电荷 q 产生的电场中，让试探电荷  $ q_{0} $ 从 P 点运动到 Q 点，在这个过程中，q 产生的电场对  $ q_{0} $ 做的功为：

 $$ \begin{aligned}A_{PQ}&=\int_{P}^{Q}q_{0}\vec{E}\cdot\mathrm{d}\vec{l}\\&=\int_{P}^{Q}\frac{q q_{0}}{4\pi\varepsilon_{0}r^{2}}\hat{\boldsymbol{r}}\cdot\mathrm{d}\vec{l}\end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_759_176_1029_508.jpg" alt="Image" width="22%" /></div>


由图中几何关系可知， $ \hat{r} \cdot \mathrm{d}\vec{l} = \mathrm{d}r $，因此：

 $$ A_{PQ}=\int_{P}^{Q}\frac{qq_{0}}{4\pi\varepsilon_{0}r^{2}}\mathrm{d}r=\frac{qq_{0}}{4\pi\varepsilon_{0}}\left(\frac{1}{r_{P}}-\frac{1}{r_{Q}}\right) $$ 

774 可知结果只与试探电荷的起始和结束位置有关，与路径无关，因而点电荷产生的电场是保守场。

775 再根据电场的叠加原理，可知一般带电体系的电场也是保守场。

### 2.6 电势

777 在第一章学习梯度定理的时候我们也学习了梯度定理的逆定理，即保守场一定可以写成一个标量场的梯度的形式。上一节我们知道，电荷产生的静电场  $ \vec{E}(\vec{r}) $ 是保守场，因此我们也可以定义一个标量场  $ \Phi(\vec{r}) $，使得  $ \vec{E}(\vec{r}) = \nabla \Phi(\vec{r}) $，例如，我们可以将  $ \Phi(\vec{r}) $ 定义为：

 $$ \Phi(\vec{r})=\int_{\infty}^{\vec{r}}\vec{E}\cdot\mathrm{d}\vec{r} $$ 

780 即： $ \vec{E}(\vec{r}) $ 在从无穷远处到  $ \vec{r} $ 的任意一条曲线上的线积分，由于  $ \vec{E}(\vec{r}) $ 是保守场，因此上述定义是唯一的，与选取哪条路径无关。根据积分的定义，我们有：

 $$ \mathrm{d}\Phi(\vec{r})=\vec{E}\cdot\mathrm{d}\vec{r} $$ 

782 同时，根据梯度的定义，我们有：

 $$ \mathrm{d}\Phi(\vec{r})=\nabla\Phi\cdot\mathrm{d}\vec{r} $$ 

783 由上述两式可得：

 $$ \vec{E}\cdot\mathrm{d}\vec{r}=\nabla\Phi\cdot\mathrm{d}\vec{r} $$ 

上式对任意  $ d\vec{r} $ 都成立，因而  $ \vec{E}(\vec{r}) = \nabla \Phi(\vec{r}) $。

下面，我们来试图理解一下上述定义的  $ \Phi(\vec{r}) $ 的物理意义，为此，我们不妨再来看一下从点