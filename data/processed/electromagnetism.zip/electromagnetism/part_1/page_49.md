1522 向上为正值):

 $$ E_{n1}-E_{n2}=\frac{\sigma^{\prime}}{\varepsilon_{0}} $$ 

1523 即：

 $$ \varepsilon_{0}E_{n1}-\varepsilon_{0}E_{n2}=\sigma^{\prime}=\sigma_{0}+\sigma_{1}^{\prime}+\sigma_{2}^{\prime} $$ 

1524 而由面电荷密度与极化强度矢量的关系，我们有（设上图中  $ \vec{P} $ 方向向上为正）：

 $$ \sigma_{1}^{\prime}=-P_{n1},\qquad\sigma_{2}^{\prime}=P_{n2} $$ 

1525 代入4.71式，可得：

 $$ \varepsilon_{0}E_{n1}-\varepsilon_{0}E_{n2}=\sigma_{0}-P_{n1}+P_{n2} $$ 

1526 也即：

 $$ \left(\varepsilon_{0}E_{n1}+P_{n1}\right)-\left(\varepsilon_{0}E_{n2}+P_{n2}\right)=\sigma_{0} $$ 

1527 而上式左边括号中的两项，刚好是边界两侧的电位移矢量  $ \vec{D} $ 的法向分量，即：

 $$ D_{n1}-D_{n2}=\sigma_{0} $$ 

1528

29 当然，上式关于  $ \vec{D} $ 的边界关系也可以通过  $ \vec{D} $ 的高斯定理更简单地得出：如下图所示，在 30 介质表面取一个底面为  $ \Delta S $（平行于介质表面）、高度为 h（无限小）的圆柱面：

<div style="text-align: center;"><img src="imgs/img_in_image_box_328_891_864_1043.jpg" alt="Image" width="45%" /></div>


1531

1532 则由高斯定理：

 $$ \iint_{S}\vec{D}\cdot\mathrm{d}\vec{S}=q_{0} $$ 

 $$ \Rightarrow(D_{n1}-D_{n2})\Delta S=\sigma_{0}\Delta S $$ 

 $$ \Rightarrow D_{n1}-D_{n2}=\sigma_{0} $$ 

1533 当边界上没有自由电荷时， $ \vec{D} $ 的边界关系变成：

 $$ D_{n1}=D_{n2} $$ 

1534 此时，如果介质 1 和介质 2 均为各向同性线性介质，则上式可以进一步写成：

 $$ \varepsilon_{1}E_{n1}=\varepsilon_{2}E_{n2}\quad\Rightarrow\quad\frac{E_{n1}}{E_{n2}}=\frac{\varepsilon_{2}}{\varepsilon_{1}} $$ 