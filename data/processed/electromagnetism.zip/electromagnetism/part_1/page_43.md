1435

例 4.1

如图所示，有一在 z 方向均匀极化的介质球，其内部极化强度矢量为  $ \vec{P} $，求球表面的极化面电荷密度  $ \sigma_{e}^{\prime} $ 和球内各点的退极化场。

<div style="text-align: center;"><img src="imgs/img_in_image_box_787_169_1035_347.jpg" alt="Image" width="20%" /></div>


解:

球表面任意一点的极化面电荷密度为：

 $$ \sigma_{e}^{\prime}=\vec{P}\cdot\vec{n}=P\cos\theta $$ 

其中，θ 是该点在球坐标系中的 θ 坐标值。可知该面电荷分布为余弦分布，在例3.2我们曾经计算过，遵循余弦分布的球面面电荷其在球内产生的电场是个均匀场，因而我们可以直接套用例3.2的计算结果，该例题中  $ \sigma = 3\varepsilon_0E\cos\theta $ 的面电荷产生的均匀场的大小为 -E（负号表示沿 -z 方向）；因而本题中  $ \sigma_e' = P\cos\theta $ 的极化面电荷在球内产生的退极化场应为：

 $$ \vec{E}^{\prime}=-\frac{\vec{P}}{3\varepsilon_{0}} $$ 

1440 负号表示退极化场与极化强度矢量方向相反。

1441

### 例 4.2

如图所示，有一个半径为  $ R $ 的非均匀极化介质球，已知其内部的极化强度矢量大小处处相同，但是方向处处沿着  $ \hat{r} $ 方向，即： $ \vec{P} = P \hat{r} $，求球面极化面电荷密度  $ \sigma_e' $ 和球内极化体电荷密度  $ \rho_e' $，以及极化电荷在球内和球外产生的电场  $ \vec{E}' $。

<div style="text-align: center;"><img src="imgs/img_in_image_box_789_772_1031_1006.jpg" alt="Image" width="20%" /></div>


解:

球表面任意一点的极化面电荷密度为：

 $$ \sigma_{e}^{\prime}=\vec{P}\cdot\vec{n}=P $$ 

1442 球内部任意一点的极化体电荷密度为：

 $$ \rho_{e}^{\prime}=-\nabla\cdot\vec{\boldsymbol{P}}=-P\nabla\cdot\hat{\boldsymbol{r}}=-P\left[\frac{1}{r^{2}}\frac{\partial(r^{2}\cdot1)}{\partial r}\right]=-\frac{2P}{r} $$ 

1443 下面我们计算极化电荷产生的电场。由对称性，极化电荷产生的电场在同一半径 r 处大小应该处处相等，且方向均与  $ \vec{r} $ 方向平行。因此，选取半径为 r 的球面作为高斯面，由高斯定理可得：

 $$ E(r)=\frac{Q^{\prime}}{4\pi\varepsilon_{0}r^{2}} $$ 

1445 其中  $ Q' $ 为半径为 r 的球内所有极化电荷的总量：