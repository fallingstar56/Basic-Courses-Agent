### 2.6 电势

815 将  $ r_{+} $,  $ r_{-} $用三角函数表示，并取  $ l/r \ll 1 $ 时的泰勒展开后的一次项，可得：

 $$ \begin{aligned}U(\vec{r})&=\frac{q}{4\pi\varepsilon_{0}}\Big[(r^{2}+(\frac{l}{2})^{2}-rl\cos\theta)^{-\frac{1}{2}}-(r^{2}+(\frac{l}{2})^{2}+rl\cos\theta)^{-\frac{1}{2}}\Big]\\&=\frac{q}{4\pi\varepsilon_{0}r}\Big[(1+(\frac{l}{2r})^{2}-\frac{l}{r}\cos\theta)^{-\frac{1}{2}}-(1+(\frac{l}{2r})^{2}+\frac{l}{r}\cos\theta)^{-\frac{1}{2}}\Big]\\&\approx\frac{q}{4\pi\varepsilon_{0}r}\Big[(1-\frac{l}{r}\cos\theta)^{-\frac{1}{2}}-(1+\frac{l}{r}\cos\theta)^{-\frac{1}{2}}\Big]\\&\approx\frac{q}{4\pi\varepsilon_{0}r}\Big[(1+\frac{l}{2r}\cos\theta)-(1-\frac{l}{2r}\cos\theta)\Big]\\&=\frac{ql\cos\theta}{4\pi\varepsilon_{0}r^{2}}\\&=\frac{\vec{p}\cdot\vec{r}}{4\pi\varepsilon_{0}r^{2}}\\ \end{aligned} $$ 

816 其中  $ \vec{p}=q\vec{l} $ 为电偶极矩。

在讨论高斯定理和环路定理的时候，我们都提到过这两个定理是库仑定律和叠加原理的直接结果。实际上，从数学上这个逻辑反过来也是可以推导出来的，即如果已知高斯定理和环路定理，那么我们便可以得出电场的平方反比规律（即库仑定律的形式）和叠加原理的结论。其推导过程也并不复杂，首先，由环路定理的微分形式：

 $$ \nabla\times\vec{E}=0 $$ 

821 我们可以得出：

 $$ \vec{E}=-\nabla U $$ 

822 再代入高斯定理的微分形式：

 $$ \nabla\cdot\vec{E}=\frac{\rho}{\varepsilon_{0}} $$ 

823 可得：

 $$ \nabla\cdot\nabla U=\nabla^{2}U=-\frac{\rho}{\varepsilon_{0}} $$ 

824 上述方程，也被称为静电场的泊松方程，其中  $ \nabla^{2} $ 称为拉普拉斯算符，有时也用  $ \Delta $ 来表示：

 $$ \nabla^{2}=\Delta=\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}} $$ 

825 求解泊松方程（边界条件  $ U(\infty)=0 $），便可得到 U 的表达式：

 $$ U(\vec{\mathbf{r}})=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V_{0}}\frac{\rho(\vec{\mathbf{r}}_{0})}{|\vec{\mathbf{r}}-\vec{\mathbf{r}}_{0}|}\mathrm{d}V_{0} $$ 

826 已知该电势，便可使用2.119求出电场：

 $$ \vec{E}=-\nabla U=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V_{0}}\frac{\rho(\vec{r}_{0})(\vec{r}-\vec{r}_{0})}{|\vec{r}-\vec{r}_{0}|^{3}}\mathrm{d}V_{0} $$ 

827 而上式，便是库仑定律和叠加原理。