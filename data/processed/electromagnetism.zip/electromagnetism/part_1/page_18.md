958

当然，我们也可以通过静电场的环路定理来证明导体表面电场与表面垂直，如右图所示，沿导体表面取一个无穷窄的长条形环路 C，其中长边与导体表面平行（长度为 l），则根据环路定理：



 $$ 0=\oint_{C}\vec{E}\mathrm{d}\vec{l}=E_{\parallel 内 }l-E_{\parallel 外 }l $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_811_167_1066_385.jpg" alt="Image" width="21%" /></div>


由于导体内部电场处处为零，因此  $ E_{\parallel内}=0 $，从而有  $ E_{\parallel外}=0 $，即导体表面电场的切向分量为零。

2. 导体是个等势体，导体表面是个等势面。

这个也很好理解，由于导体内部没有电场，因此导体上任意两点之间的在导体内部的路径上的电场的路径积分为零，也就是电势差为零，因而导体是个等势体，导体的表面也是个等势面。

3. 导体内部体电荷密度  $ \rho_{e} $ 处处为零，电荷只分布在导体表面。

导体内部的体电荷密度，可以由高斯定理的微分形式给出：

 $$ \rho_{e}=\varepsilon_{0}\nabla\cdot\vec{E} $$ 

由于导体内部电场处处为零，因而  $ \rho_{e}=0 $

#### 3.2.2 导体表面电场强度

上面提到，处于静电平衡的导体，其表面电场的切向分量为零，那么表面电场的垂直分量是多大呢？为了计算电场的垂直分量，我们可以取如右图所示的圆柱面作为高斯面，该圆柱面的侧面与导体表面垂直，其中一个底面位于导体内部，则由高斯定理：

 $$ \begin{aligned}&\iint_{\vec{S}}\vec{E}\cdot\mathrm{d}\vec{S}=\frac{Q_{\mathrm{in}}}{\varepsilon_{0}}\\\Rightarrow&E_{ 外 }S+E_{ 内 }S+\iint_{ 侧面 }\vec{E}\cdot\mathrm{d}\vec{S}=\frac{\sigma_{e}S}{\varepsilon_{0}}\end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_746_911_1026_1144.jpg" alt="Image" width="23%" /></div>


其中，由静电平衡我们知道导体内部电场  $ E_{内} = 0 $，此外我们再令这个圆柱面的高无限小，则有  $ \iint_{侧面} \vec{E} \cdot d\vec{S} = 0 $，因此：

 $$ E_{ 外 }S=\frac{\sigma_{e}S}{\varepsilon_{0}} $$ 

970 即导体表面的电场强度为：

 $$ \vec{E}=\frac{\sigma_{e}}{\varepsilon_{0}}\vec{n} $$ 

注意到该电场强度有以下一些有趣的现象：

1. 导体表面某一处的电场强度，应该是外加电场加上导体上所有表面电荷共同叠加的结果，