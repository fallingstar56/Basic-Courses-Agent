1. 当 r < R 时，

 $$ Q^{\prime}=\iiint\rho_{e}^{\prime}\mathrm{d}V=\int_{0}^{r}-\frac{2P}{r}4\pi r^{2}\mathrm{d}r=-4\pi r^{2}P\quad\Rightarrow\quad\vec{E}(\vec{r})=-\frac{\vec{P}}{\varepsilon_{0}} $$ 

2. 当 r > R 时，

 $$ Q^{\prime}=Q^{\prime}_{ 体 }+Q^{\prime}_{ 面 }=-4\pi R^{2}P+4\pi R^{2}P=0\qquad\Rightarrow\qquad\vec{E}(\vec{r})=0 $$ 

1448

### 例 4.3

如图所示，两带电平板上的电荷在其内部产生的均匀电场为  $ \vec{E}_{0} $，现在在其内部插入各向同性线性均匀电介质，已知电介质的电极化率为  $ \chi_{e} $，求插入平板后：电介质表面的面电荷密度  $ \sigma' $，极化强度矢量  $ \vec{P} $，退极化场  $ \vec{E}' $ 以及平板之间总电场  $ \vec{E} $。

<div style="text-align: center;"><img src="imgs/img_in_image_box_876_455_1029_733.jpg" alt="Image" width="12%" /></div>


解:

如图所示，由极化面电荷与  $ \vec{P} $ 的关系，可知介质右表面极化面电荷密度为正，左表面极化面电荷密度为负，且：

 $$ \sigma_{+}^{\prime}=-\sigma_{-}^{\prime}=P=\sigma^{\prime} $$ 

1449 由高斯定理易得出，该极化面电荷在介质内部产生的电场为：

 $$ \vec{E}^{\prime}=-\frac{\sigma^{\prime}}{\varepsilon_{0}}\hat{z}=-\frac{\vec{P}}{\varepsilon_{0}} $$ 

负号表示 E 与 P 方向相反。由于外加电场  $ E_0 $ 是均匀场，且介质为各向同性线性均匀介质，因此  $ \vec{P} $ 也是各处相等，因而介质内部极化体电荷密度  $ \rho' = -\nabla \cdot \vec{P} = 0 $。因此，上述  $ \vec{E}' $ 便是所有极化电荷产生的电场之和。根据极化强度矢量  $ \vec{P} $ 与总电场之间的关系，可知介质内  $ \vec{P} $ 为：

 $$ \vec{P}=\chi_{e}\varepsilon_{0}\vec{E}=\chi_{e}\varepsilon_{0}(\vec{E}_{0}+\vec{E}^{\prime})=\chi_{e}\varepsilon_{0}(\vec{E}_{0}-\frac{\vec{P}}{\varepsilon_{0}}) $$ 

1453 求解上式可得：

 $$ \vec{P}=\frac{\chi_{e}}{1+\chi_{e}}\varepsilon_{0}\vec{E}_{0} $$ 

1454 因而有：

 $$ \sigma^{\prime}=P=\frac{\chi_{e}}{1+\chi_{e}}\varepsilon_{0}E_{0} $$ 

 $$ \vec{E}^{\prime}=-\frac{\vec{P}}{\varepsilon_{0}}=-\frac{\chi_{e}}{1+\chi_{e}}\vec{E}_{0} $$ 

 $$ \vec{E}=\vec{E}_{0}+\vec{E}^{\prime}=\frac{1}{1+\chi_{e}}\vec{E}_{0} $$ 

1455 由于通常情况下  $ \chi_{e} > 0 $，因而由上式结果可知，由于电介质的存在，平行板之间的总电场被减