803 对连续分布的带电体系则有：

 $$ U(\vec{\mathbf{r}})=\iiint_{V^{\prime}}\mathrm{d}U_{\vec{\mathbf{r}}^{\prime}}(\vec{\mathbf{r}})=\iiint_{V^{\prime}}\frac{\rho(\vec{\mathbf{r}}^{\prime})\mathrm{d}V^{\prime}}{4\pi\varepsilon_{0}|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|} $$ 

空间中电势相等的平面称为电场的等势面。在第一章学习标量场的梯度的时候我们提到， $ \nabla U $ 的方向平行于等势面的法向，因此，电场的方向与等势面的法向是平行的（方向相反），且电场的大小等于电势 U 在等势面法向方向的导数的负数。

在求解一个带电系统的电场或电势时，可以通过叠加原理先计算电场然后通过积分得到电势，也可以通过叠加原理先计算电势然后通过微分得到电场。

809

例 2.15

同例2.6，求如图所示的均匀带电细圆环（半径 R，总电荷 q）在其轴线上任意一点  $ P(z) $ 处的电场强度。

<div style="text-align: center;"><img src="imgs/img_in_image_box_749_539_1024_716.jpg" alt="Image" width="23%" /></div>


解:

810 如图所示，将带电圆环分成无限个点电荷 dq，该点电荷的电场在 P 点的电势为：

 $$ \mathrm{d}U(z)=\frac{\mathrm{d}q}{4\pi\varepsilon_{0}r} $$ 

811 因此，整个带电圆环产生的电场在 P 点的电势为：

 $$ U(z)=\int\mathrm{d}U=\int_{0}^{q}\frac{\mathrm{d}q}{4\pi\varepsilon_{0}r}=\frac{q}{4\pi\varepsilon_{0}r}=\frac{q}{4\pi\varepsilon_{0}\sqrt{R^{2}+z^{2}}} $$ 

812 由对称性，P 点的电场方向指向 z 方向，且：

 $$ E_{z}=-\frac{\partial U}{\partial z}=\frac{qz}{4\pi\varepsilon_{0}(R^{2}+z^{2})^{3/2}} $$ 

813 该结果与例2.6中直接通过叠加原理求电场得到的结果相同。

814

例 2.16

求电偶极子在远点的电势。

解:

如图所示，由叠加原理，电偶极子在 P 点的电势等于正负电荷在 P 点的电势之和：

 $$ \begin{aligned}U(\vec{\mathbf{r}})&=U_{+}(\vec{\mathbf{r}})+U_{-}(\vec{\mathbf{r}})\\&=\frac{q}{4\pi\varepsilon_{0}}\bigg(\frac{1}{r_{+}}-\frac{1}{r_{-}}\bigg)\end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_752_1216_1031_1471.jpg" alt="Image" width="23%" /></div>
