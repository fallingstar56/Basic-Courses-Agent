入的正镜像电荷产生的电场在球面仍然是个等势面，因此两个镜像电荷加上 Q 在球面产生的电场依然是个等势面。此外，引入的负镜像电荷等价于总量为  $ -\frac{R}{a}Q $ 的负电荷以3.47式的形式分布在球面，而引入的正镜像电荷等价于总量为  $ \frac{R}{a}Q $ 的正电荷均匀分布在球面，球面上的总电荷刚好为零，满足了唯一性定理的边界条件（给定导体的总电荷量），得到的解便是唯一解。

此时，球外电场分布为两个镜像电荷和 Q 三者产生的电场的叠加：

 $$ \begin{aligned}\vec{E}&=(\vec{E}_{-}+\vec{E}_{Q})+\vec{E}_{+}\\&=\frac{Q}{4\pi\varepsilon_{0}}\bigg(\frac{\vec{r}_{a}}{|\vec{r}_{a}|^{3}}-\frac{R}{a}\frac{\vec{r}_{b}}{|\vec{r}_{b}|^{3}}\bigg)+\frac{RQ\vec{r}}{4\pi\varepsilon_{0}a|\vec{r}|^{3}}\end{aligned} $$ 

1263 球面的总面电荷分布等于负电荷分布和正电荷分布的叠加，如下图所示，

<div style="text-align: center;"><img src="imgs/img_in_image_box_280_597_895_746.jpg" alt="Image" width="51%" /></div>


1264

1265 面电荷密度分布的具体值为：

 $$ \begin{aligned}\sigma_{e}(\vec{r})&=\sigma_{e-}(\vec{r})+\sigma_{e+}(\vec{r})\\&=-\frac{Q(a^{2}-R^{2})}{4\pi R(R^{2}+a^{2}-2aR\cos\theta)^{3/2}}+\frac{Q}{4\pi R a}\end{aligned} $$ 

## 习题

1266

3.1: 如图，带电导体球 A（带电量 q）与带电导体球壳 B（带电量 Q）同心，求：

1) 各表面上的电荷；

2）导体球 A 的电势；

3）如果将球壳 B 接地，求各表面电荷分布；

<div style="text-align: center;"><img src="imgs/img_in_image_box_866_1169_1080_1368.jpg" alt="Image" width="17%" /></div>


4）将 B 的地线拆掉后，再将 A 接地后各表面电荷分布。

1268 3.2: 接地导体球壳内有一点电荷，球壳内表面半径为 R，点电荷离圆心距离为 a，求球壳内电场分布。

1270 3.3: 利用电镜像法，计算均匀电场中放置一原本不带电的导体球时球外任意一点的电场。(提示：利用两个相隔无限远的点电荷在其中心点处产生的电场来模拟均匀电场)