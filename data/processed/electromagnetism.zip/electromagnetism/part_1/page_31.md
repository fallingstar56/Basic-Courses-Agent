1236 解:

1. 上文提到，两个符号相反、电荷量绝对值不相等的电荷系统的电势为零的等势面是一个球面，为此，我们取一镜像电荷 q，如右图所示，设它位于球心与 Q 的连线上且与球心的距离为 b，则由 Q 和 q 产生的电场在 P 点的电势为：

<div style="text-align: center;"><img src="imgs/img_in_image_box_750_170_1032_371.jpg" alt="Image" width="23%" /></div>


 $$ U=\frac{1}{4\pi\varepsilon_{0}}\bigg(\frac{Q}{r_{a}}+\frac{q}{r_{b}}\bigg) $$ 

其中， $ r_{a}, r_{b} $ 分别为 P 到 Q, q 的距离。令 U = 0，得：

 $$ \frac{Q}{r_{a}}+\frac{q}{r_{b}}=0 $$ 

1237 将任意两个特殊点代入上式（如 P 位于 x 轴上的两个点），可得：

 $$ \frac{Q}{a-R}+\frac{q}{R-b}=0 $$ 

 $$ \frac{Q}{a+R}+\frac{q}{R+b}=0 $$ 

1238 解得：

 $$ b=\frac{R^{2}}{a},\quad q=-\frac{R}{a}Q $$ 

1239 事实上，将上述 b, q 的值代入 U = 0 的等势面的表达式（3.40式），可得：

 $$ \begin{aligned}&\frac{Q}{\sqrt{(x-a)^{2}+y^{2}+z^{2}}}-\frac{R}{a}\frac{Q}{\sqrt{(x-b)^{2}+y^{2}+z^{2}}}=0\\&\Rightarrow a\sqrt{(x-b)^{2}+y^{2}+z^{2}}=R\sqrt{(x-a)^{2}+y^{2}+z^{2}}\\&\Rightarrow a^{2}\Big[(x-b)^{2}+y^{2}+z^{2}\Big]=R^{2}\Big[(x-a)^{2}+y^{2}+z^{2}\Big]\\&\Rightarrow(a^{2}-R^{2})(x^{2}+y^{2}+z^{2})-R^{2}(a^{2}-R^{2})=0\\&\quad\Rightarrow x^{2}+y^{2}+z^{2}=R^{2}\end{aligned} $$ 

1244 也就是说，我们已经得到，由3.43式定义的镜像电荷和 Q 组成的电荷系统产生的 U = 0 的等势面是一个以原点为球心，半径为 R 的球面。

1246 导体外任意一点 P 的电场为：

 $$ \vec{E}=\frac{Q}{4\pi\varepsilon_{0}}\bigg(\frac{\vec{r}_{a}}{|\vec{r}_{a}|^{3}}-\frac{R}{a}\frac{\vec{r}_{b}}{|\vec{r}_{b}|^{3}}\bigg) $$ 

1247 其中  $ \vec{r}_{a}, \vec{r}_{b} $ 分别是 Q, q 到 P 的位移矢量。