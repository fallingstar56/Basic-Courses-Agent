1504 球面上的极化面电荷密度为：

 $$ \sigma^{\prime}=\vec{P}\cdot\vec{n}=\frac{q\left(\varepsilon-\varepsilon_{0}\right)}{4\pi\varepsilon R^{2}} $$ 

1505 介质内部极化体电荷密度为（参见2.63式）：

 $$ \rho^{\prime}=-\nabla\cdot\vec{\boldsymbol{P}}=-\frac{q(\varepsilon-\varepsilon_{0})}{4\pi\varepsilon}\nabla\cdot\frac{\hat{\boldsymbol{r}}}{r^{2}}=-\frac{q(\varepsilon-\varepsilon_{0})}{4\pi\varepsilon}4\pi\delta(\vec{\boldsymbol{r}})=-\frac{q(\varepsilon-\varepsilon_{0})}{\varepsilon}\delta(\vec{\boldsymbol{r}}) $$ 

### 4.4 电介质中静电场的边值关系

1507 通过上一节电位移矢量的引入，我们得到了有介质存在时的求解静电场的微分方程及物质方程：

 $$ \nabla\cdot\vec{D}=\rho_{0} $$ 

 $$ \nabla\times\vec{E}=0 $$ 

 $$ \vec{D}=\varepsilon_{0}\vec{E}+\vec{P} $$ 

1509 然而，要想在整个区域求解静电场，我们还需要知道每个区域的边界条件。而我们在第二章曾经分析过，面电荷产生的电场在表面两侧是不连续的。因此，被极化后的电介质，由于极化面电荷的产生，总电场在介质表面也是不连续的。下面，我们来分析  $ \vec{D} $ 和  $ \vec{E} $ 在介质表面两侧的大小关系。

我们先来看一下电场强度  $ \vec{E} $ 的边值关系。如下图所示，设在介质 1 和介质 2 的分界面某点处，电场强度在分界面的法向和切向分量分别是  $ E_{n1}, E_{\tau1}, E_{n2}, E_{\tau2} $。如下图所示跨过边界取一个长为 l，高为 h 的闭合曲线 C，当  $ h \to 0 $ 时，由静电场的环路定理：

<div style="text-align: center;"><img src="imgs/img_in_image_box_324_1001_862_1191.jpg" alt="Image" width="45%" /></div>


1516

 $$ 0=\oint_{C}\vec{E}\cdot\mathrm{d}\vec{l}=(E_{\tau1}-E_{\tau2})l $$ 

1517 可知，

 $$ E_{\tau1}=E_{\tau2} $$ 

显然，由于极化面电荷的存在， $ E_{n1} \neq E_{n2} $，且由第二章中的结论我们知道，假设在分界面上总面电荷密度为  $ \sigma' = \sigma_0 + \sigma_1' + \sigma_2' $，其中  $ \sigma_0 $ 为总自由电荷面密度， $ \sigma_1' $ 和  $ \sigma_2' $ 分别为介质 1 和 2 中的极化面电荷面密度，则该面电荷将导致分界面两侧的法向电场相差值为（设上图中  $ \vec{E} $ 方