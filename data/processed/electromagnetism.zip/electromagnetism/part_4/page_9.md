3360 1.15: 9

3361 2.1:

 $$ \left(\frac{\mathrm{d}E}{\mathrm{d}x}\right)_{\mathrm{ion}}=-\frac{4\pi N Z k^{2}z^{2}e^{4}}{m_{0}v^{2}}\ln\left(\frac{2m_{0}v^{2}}{I}\right)^{1/2} $$ 

3362 （提示： $ b_{min} $ 对应的是经典碰撞理论中的对心碰撞， $ b_{max} $ 对应的是电子获得的能量刚好够它激发或电离（即激发能级 I））

3364 2.2:

3365 1)  $ z = \pm 2R $ 处（即束团最外侧的质子）

3366 2)  $ F_{\text{max}} = 2.6 \times 10^{-7} \, \text{N} $

3367 2.3:

 $$ E_{r}=\frac{p\cos\theta}{2\pi\varepsilon_{0}r^{3}} $$ 

3368

 $$ E_{\theta}=\frac{p\sin\theta}{4\pi\varepsilon_{0}r^{3}} $$ 

3369 2.4:

 $$ \vec{E}(x)=\frac{6ql^{2}}{4\pi\varepsilon_{0}x^{4}} $$ 

3370 2.5: 两平板之间： $ E=\frac{\sigma}{\varepsilon_{0}} $，方向由正带电平板指向负带电平板；两平板外：E=0

3371 2.6:

 $$ \frac{q}{\sqrt{2}\varepsilon_{0}} $$ 

3372 2.7:

 $$ U(x,y,z)=\frac{Q}{4\pi\varepsilon_{0}\sqrt{x^{2}+y^{2}+z^{2}}}-\frac{q}{4\pi\varepsilon_{0}\sqrt{x^{2}+(y-d)^{2}+z^{2}}} $$ 

3374 2) 球心位置： $ (0,\frac{d}{1-(q/Q)^{2}},0) $，半径： $ \frac{d}{Q/q-q/Q} $

3375 2.8:

 $$ \mathrm{d}F=\frac{Q\mathrm{d}q}{8\pi\varepsilon_{0}R^{2}} $$ 

3376 方向向外

3377 2.9:

 $$ F=\frac{Q^{2}}{32\pi\varepsilon_{0}R^{2}} $$ 

3378 方向垂直于断面指向球心

3379 2.10: 使用柱坐标系，当 r > R 时， $ \vec{E}(\vec{r}) = \frac{\rho_e R^2}{2\varepsilon_0 r} \hat{r} $; 当  $ r \leq R $ 时， $ \vec{E}(\vec{r}) = \frac{\rho_e r}{2\varepsilon_0} \hat{r} $