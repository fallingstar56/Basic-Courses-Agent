 $$ \frac{E_{\parallel r0}}{E_{\parallel0}}=\frac{\tan(\theta-\theta_{t})}{\tan(\theta+\theta_{t})} $$ 

 $$ \frac{E_{\parallel t0}}{E_{\parallel0}}=\frac{2\cos\theta\sin\theta_{t}}{\sin\theta\cos\theta+\sin\theta_{t}\cos\theta_{t}} $$ 

上述我们从麦克斯韦方程组以及电磁场边值关系出发推导得出的9.186、9.187、9.194、9.195式，就是光学中的菲涅尔公式。

由上述菲涅尔公式，我们还可以看出几个有趣的光学现象：

- 反射波的半波损失：当入射波的  $ \vec{E} $ 与入射面垂直且  $ \theta > \theta_{t} $ (即由波疏介质射入波密介质) 时，由9.186式，反射波和入射波的振幅的符号相反，即两者相位相差  $ \pi $，好像差了半个波长，这种现象称为“半波损失”。

- 平行偏振反射波的消失：由9.194式，当  $ \theta + \theta_t = \pi/2 $ 时， $ E_{\parallel r0} = 0 $，即反射波消失。我们把满足  $ \theta + \theta_t = \pi/2 $ 的这一特殊入射角，称为布鲁斯特角  $ \theta_B $。根据折射定律，可以得出：

 $$ n_{21}=\frac{\sin\theta_{B}}{\sin\theta_{t}}=\frac{\sin\theta_{B}}{\sin(\pi/2-\theta_{B})}=\tan\theta_{B}\quad\Rightarrow\quad\tan\theta_{B}=\frac{1}{n_{21}} $$ 

一个任意偏振的波，总可以分为  $ \vec{E} $ 平行和垂直入射面的两个入射波。当平面波的入射角为布鲁斯特角时，反射波的  $ \vec{E} $ 只剩下了垂直入射面方向的分量。

下面，我们再来看一个简单情形，即入射波为垂直入射（入射波波矢与介质表明垂直）时的情况。此时，入射角、反射角和折射角都为 0，根据9.182、9.183、9.190和9.191式，我们有：

 $$ \frac{E_{\perp r0}}{E_{\perp0}}=\frac{1-\beta}{1+\beta} $$ 

 $$ \frac{E_{\perp t0}}{E_{\perp0}}=\frac{2}{1+\beta} $$ 

 $$ \frac{E_{\parallel r0}}{E_{\parallel0}}=\frac{\beta-1}{1+\beta} $$ 

 $$ \frac{E_{\parallel t0}}{E_{\parallel0}}=\frac{2}{1+\beta} $$ 

3305 其中，

 $$ \beta=\sqrt{\frac{\varepsilon_{2}\mu_{1}}{\varepsilon_{1}\mu_{2}}}=\frac{\sqrt{\mu_{1}/\varepsilon_{1}}}{\sqrt{\mu_{2}/\varepsilon_{2}}} $$ 

3306 如果我们对每一个介质，定义一个量：

 $$ Z=\sqrt{\frac{\mu}{\varepsilon}} $$ 

3307 即：

 $$ Z_{1}=\sqrt{\frac{\mu_{1}}{\varepsilon_{1}}},\quad Z_{2}=\sqrt{\frac{\mu_{2}}{\varepsilon_{2}}},\quad\beta=\frac{Z_{1}}{Z_{2}} $$ 