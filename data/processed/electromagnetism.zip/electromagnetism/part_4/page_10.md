3380 2.11: 设带电细线的中心在 x = 0 处，则当 x > l/2 时  $ E(x) = \frac{\lambda e}{4\pi \varepsilon_{0}} \frac{4l}{4x^{2} - l^{2}} $; 当 0 < x < l/2 时  $ E(x) = \frac{\lambda e}{4\pi \varepsilon_{0}} \frac{8x}{l^{2} - 4x^{2}} $; 当 x < 0 时  $ E(x) = -E(-x) $。电荷会向两端聚集。

3382 2.12: ...

3383 2.13:

 $$ Q_{m}=\frac{4\pi\varepsilon_{0}R(E_{m}-mc^{2})}{e} $$ 

3384 2.14:  $ U = \frac{\lambda}{2\pi\varepsilon_0} \ln \frac{r_0}{r} $，其中  $ r_0 $ 为电势为零的参考点离带电直线的距离（注意不能将无穷远或带电直线选为电势为零的参考点）。

3386 2.15: ...

3387 2.16:

3388 1)  $  U(x, y, z) = \frac{\lambda}{4\pi\varepsilon_0} \ln \frac{z + f + r_1}{z - f + r_2}  $

3389 2) 椭球面

3390 3.1:

3391 1) A: q; B 内表面: -q; B 外表面  $ Q + q $

3392 2) U_{A} =  $ \frac{1}{4\pi\varepsilon_{0}}\left(\frac{q}{R_{1}} + \frac{-q}{R_{2}} + \frac{Q+q}{R_{3}}\right) $

3393 3) A: q; B 内表面: -q; B 外表面 0

3394 4) A:  $ q' $; B 内表面:  $ -q' $; B 外表面  $ -q + q' $，其中：

 $$ 0=\frac{q^{\prime}}{R_{1}}+\frac{-q^{\prime}}{R_{2}}+\frac{-q+q^{\prime}}{R_{3}} $$ 

3395 3.2: 提示：利用习题2.7的结论寻找镜像电荷。

3396 3.3: ...

3397 3.4: ...

3398 3.5:

 $$ F=(-\frac{\sqrt{3}}{12}+\frac{5}{16})\frac{q^{2}}{4\pi\varepsilon_{0}a^{2}} $$ 

3399 3.6: ...

3400 3.7:

 $$ q=2\pi\varepsilon_{0}h^{2}E $$ 