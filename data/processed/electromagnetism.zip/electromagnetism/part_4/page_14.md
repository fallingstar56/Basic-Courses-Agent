3456 8.2:

 $$ \vec{E}=-\frac{\mu_{0}\sigma R k r}{2}\hat{\theta} $$ 

3457 8.3:

 $$ \mathcal{E}_{AC}=\frac{\mu_{0}M\omega}{4\pi R} $$ 

3458 8.4:

 $$ M=\frac{\pi\mu_{0}r^{2}R^{2}}{2(R^{2}+d^{2})^{3/2}} $$ 

3459 8.5:

 $$ \mathcal{E}=\frac{\mu_{0}d}{2\pi}\frac{\mathrm{d}I}{\mathrm{d}t}\ln\frac{4}{3} $$ 

3460 8.6: ...

9.1: P 的电场为  $ E = \frac{V_{0} \cos \omega t}{d} $，磁场为  $ B = \frac{\mu_{0} \varepsilon_{0} V_{0} \omega}{2d} r \sin \omega t $。

Q 的电场为零，磁场为  $ B = \frac{\mu_{0} \varepsilon_{0} R^{2} V_{0} \omega}{2 dr} \sin \omega t $。

463 E 和 B 在极板两侧都不连续，是因为极板上存在面电荷和面电流（可证明满足边值关系）。

464 9.2:

 $$ \omega=2\pi\times10^{9}s^{-1},k=\frac{20\pi}{3}m^{-1} $$ 

3466 2) Bx = By = 0, Bz = E0  $ \frac{\omega}{k} $  $ \cos(\omega t - kx) $

3467 9.3:

 $$ P=2\pi\varepsilon_{0}c R^{2}E_{0}^{2}\approx1.8\mathrm{M W} $$ 

3468 9.4:

 $$ \vec{E}=-\frac{\alpha E_{0}\omega^{2}\sin\theta\cos(\omega(t-r/c))}{4\pi\varepsilon_{0}c^{2}r}\hat{\theta} $$ 

 $$ \vec{B}=-\frac{\alpha E_{0}\omega^{2}\sin\theta\cos(\omega(t-r/c))}{4\pi\varepsilon_{0}c^{3}r}\hat{\phi} $$ 

3469 9.5:

 $$ \cos\theta=\frac{1}{n\beta} $$ 

 $$ v\geq\frac{c}{n} $$ 