3418 5.4: 8.85 nm

3419 5.5: ...

3420 5.6:

3421

 $$ R_{1}=R_{2}/\sqrt{e} $$ 

 $$ R_{1}=R_{2}/e $$ 

3423 5.7:

 $$ q^{\prime}=\frac{Qq}{Q-q} $$ 

3424 5.8:

 $$ U=-\frac{e^{2}}{4\pi\varepsilon_{0}a}=-27.2eV $$ 

3426 2) 13.6 eV

3427 5.9: 负功,  $ W = \frac{q^{2}}{8\pi\varepsilon_{0}}\left(\frac{1}{R} - \frac{1}{r}\right) $

3428 6.1: ...

3429 6.2: ...

3430 6.3:

 $$ \vec{A}(\vec{r})=\begin{cases}\frac{\mu_{0}R\omega\sigma}{3}r\sin\theta\hat{\phi},&r\leq R,\\\frac{\mu_{0}R^{4}\omega\sigma}{3}\frac{\sin\theta}{r^{2}}\hat{\phi},&r>R.\end{cases} $$ 

3431 球内磁感应强度：

 $$ \vec{B}=\frac{2}{3}\mu_{0}\sigma R\vec{\omega} $$ 

3432 6.4:

 $$ B=\frac{\mu_{0}}{2\pi d_{1}d_{2}}\sqrt{(I_{1}+I_{2})(I_{1}d_{2}^{2}+I_{2}d_{1}^{2})-d^{2}I_{1}I_{2}} $$ 

3433 其中  $ d_{1} $ 和  $ d_{2} $ 分别是该点到两导线的距离。

3434 6.5: ...

3435 6.6:

3436 1）磁感应强度为零的点在三根导线所处平面上，与中间导线距离为  $ d/\sqrt{3} $

3437 2) 加速运动