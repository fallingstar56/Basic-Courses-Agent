3401

 $$ \frac{d^{2}+2dh}{(d+h)^{2}} $$ 

3402 3.8:

 $$ a\approx16r $$ 

3403 3.9: ...

3404 3.10:

 $$ U=\frac{\lambda}{2\pi\varepsilon_{0}}\ln(\frac{d_{2}}{d_{1}})-\frac{\lambda}{2\pi\varepsilon_{0}}\ln(\frac{R}{a}) $$ 

3405 其中  $ d_{1} $， $ d_{2} $ 分别为点到线电荷和镜像线电荷的距离；镜像线电荷距离圆柱轴距离为  $ R^{2}/a $，线电荷密度为  $ -\lambda $（提示：本题的难点在于如何推导出镜像线电荷的大小和位置）。

3407 3.11:

 $$ q>\frac{R^{2}(3a-R)}{a(a-R)^{2}}Q $$ 

3408 4.1:

 $$ \vec{E}=\frac{3}{2+\varepsilon_{r}}\vec{E}_{0} $$ 

3409 4.2: ...

3410 4.3: ...

3411 4.4:

 $$ \vec{E}_{1}=\vec{E}_{2}=\frac{Q\vec{r}^{\prime}}{2\pi(\varepsilon_{r1}+\varepsilon_{r2})\varepsilon_{0}r^{\prime3}} $$ 

3412 4.5: ...

3413 4.6:

 $$ F=-\frac{(\varepsilon_{r}-1)q^{2}}{16\pi\varepsilon_{0}(\varepsilon_{r}+1)d^{2}} $$ 

3414 负号表示为吸引力

3415 5.1:

 $$ W=\frac{Q^{2}}{8\pi\varepsilon_{0}R} $$ 

3416 5.2: 17 fF

3417 5.3:

 $$ 9\times10^{9}m $$ 