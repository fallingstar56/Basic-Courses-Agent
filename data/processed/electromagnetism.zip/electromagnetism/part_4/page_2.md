3251 要求上式对任意 x, y, t 都成立，因此，必然有：

 $$ \omega=\omega_{r}=\omega_{t} $$ 

 $$ k_{x}=k_{r x}=k_{t x} $$ 

 $$ k_{y}=k_{r y}=k_{t y} $$ 

3252 即：

入射波、反射波和折射波的频率相同。

现在，假设入射波的波矢在 xz 平面（接下来都使用这个假设），即  $ k_{y}=0 $，此时，根据9.172式，我们有：

 $$ k_{r y}=k_{t y}=k_{y}=0 $$ 

3256 也就是说，反射波和折射波也在 xz 平面，即：

 $$  入射波、反射波和折射波的波矢在同一平面。 $$ 

下面，我们来看反射角和入射角之间的关系。由于反射波和入射波在同一介质内，波的传播速度相同，即：

 $$ v_{1}=\frac{\omega}{k}=\frac{\omega_{r}}{k_{r}}=\frac{\omega}{k_{r}}\quad\Rightarrow\quad k=k_{r} $$ 

3260 由9.171式：

 $$ k_{r x}=k_{x}\quad\Rightarrow\quad k_{r}\sin\theta_{r}=k\sin\theta\quad\Rightarrow\quad\frac{\sin\theta}{\sin\theta_{r}}=\frac{k_{r}}{k}=1 $$ 

3261 也就是说：

 $$  入射角 = 反射角 ( 反射定律 )。 $$ 

我们再来看折射角和入射角之间的关系。由9.171式：

 $$ k_{tx}=k_{x}\quad\Rightarrow\quad k_{t}\sin\theta_{t}=k\sin\theta\quad\Rightarrow\quad\frac{\sin\theta}{\sin\theta_{t}}=\frac{k_{t}}{k} $$ 

3264 再由两种介质内的波速：

 $$ k=\frac{\omega}{v_{1}},\quad k_{t}=\frac{\omega}{v_{2}}\quad\Rightarrow\quad\frac{k_{t}}{k}=\frac{v_{1}}{v_{2}}=\frac{\sqrt{\mu_{2}\varepsilon_{2}}}{\sqrt{\mu_{1}\varepsilon_{1}}} $$ 

3265 结合上述两式可得下面的折射定律：

 $$ \frac{\sin\theta}{\sin\theta_{t}}=\frac{v_{1}}{v_{2}}=\frac{\sqrt{\mu_{2}\varepsilon_{2}}}{\sqrt{\mu_{1}\varepsilon_{1}}}=\frac{n_{2}}{n_{1}} $$ 

接下来，我们来分析反射波、折射波和入射波的振幅（或者强度）之间的关系。为了推导出这些关系，我们必须使用上文中所有的四个边值条件。同时，为了便于分析，我们根据入射波的电场方向和入射面的关系分两种情况讨论：

• 一种是入射波中的  $ \vec{E} $ 与入射面（即 xz 平面）垂直的情况；