• 另一种是入射波中的  $ \vec{E} $ 与入射面（即 xz 平面）平行的情况。

可以严格证明，当入射波中的的 E 与入射面（即 xz 平面）垂直时，反射波和折射波的  $ \vec{E} $ 也必然会与入射面（即 xz 平面）垂直。对于一般情况，我们可以把  $ \vec{E} $ 分解成垂直于入射面和平行于入射面两个分量，分别计算反射波和折射波的电磁场在两个方向上的分量而后进行叠加。

首先，假设入射波  $ \vec{E} $ 与入射面垂直，不妨假设  $ \vec{E} $ 垂直纸面向里，如下图所示：

<div style="text-align: center;"><img src="imgs/img_in_image_box_355_417_861_783.jpg" alt="Image" width="42%" /></div>


3277

3278 由边值关系：

 $$ E_{\tau1}=E_{\tau2}\quad\Rightarrow\quad E_{0}+E_{r0}=E_{t0} $$ 

3279

 $$ H_{\tau1}=H_{\tau2}\quad\Rightarrow\quad\frac{B_{0}}{\mu_{1}}\cos\theta-\frac{B_{r0}}{\mu_{1}}\cos\theta=\frac{B_{t0}}{\mu_{2}}\cos\theta_{t}\quad\Rightarrow\quad\frac{E_{0}}{v_{1}\mu_{1}}\cos\theta-\frac{E_{r0}}{v_{1}\mu_{1}}\cos\theta=\frac{E_{t0}}{v_{2}\mu_{2}}\cos\theta_{t} $$ 

3280 也即：

 $$ \sqrt{\frac{\varepsilon_{1}}{\mu_{1}}}(E_{0}\cos\theta-E_{r0}\cos\theta)=\sqrt{\frac{\varepsilon_{2}}{\mu_{2}}}E_{t0}\cos\theta_{t} $$ 

3281 联合求解9.179和9.181式，可得：

 $$ \frac{E_{r0}}{E_{0}}=\frac{\sqrt{\frac{\varepsilon_{1}}{\mu_{1}}}\cos\theta-\sqrt{\frac{\varepsilon_{2}}{\mu_{2}}}\cos\theta_{t}}{\sqrt{\frac{\varepsilon_{1}}{\mu_{1}}}\cos\theta+\sqrt{\frac{\varepsilon_{2}}{\mu_{2}}}\cos\theta_{t}} $$ 

 $$ \frac{E_{t0}}{E_{0}}=\frac{2\sqrt{\frac{\varepsilon_{1}}{\mu_{1}}}\cos\theta}{\sqrt{\frac{\varepsilon_{1}}{\mu_{1}}}\cos\theta+\sqrt{\frac{\varepsilon_{2}}{\mu_{2}}}\cos\theta_{t}} $$ 

3282 对于一般介质， $ \mu_{1}\approx\mu_{1}\approx\mu_{0} $，因此：

\[\frac{E_{r0}}{\pi}=\frac{\cos\theta-\sqrt{\frac{\varepsilon_{2}}{\varepsilon_{1}}\cos\theta_{t}}}{\sqrt{\frac{\varepsilon_{1}}{\varepsilon_{2}}}}=\frac{\cos\theta-\frac{\sin\theta}{\sin\theta_{t}}\cos\theta_{t}}{\frac{\sin\theta}{\sin\theta_{t}}}=-\frac{\sin(\theta-\theta_{t})

 $$ E_{0}\quad\cos\theta+\sqrt{\frac{\varepsilon_{2}}{\varepsilon_{1}}}\cos\theta_{t}\quad\cos\theta+\frac{\sin\theta}{\sin\theta_{t}}\cos\theta_{t}\quad\sin(\overline{\theta+\theta_{t}}) $$ 

 $$ \frac{E_{t0}}{E_{0}}=\frac{2\cos\theta}{\cos\theta+\sqrt{\frac{\varepsilon_{2}}{\varepsilon_{1}}}\cos\theta_{t}}=\frac{2\cos\theta\sin\theta_{t}}{\sin(\theta+\theta_{t})} $$ 