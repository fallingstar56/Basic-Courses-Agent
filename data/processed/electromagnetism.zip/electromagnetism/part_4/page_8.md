## 习题参考答案

 $$ \begin{array}{r l}{{3345}}&{{1.1;}}\end{array} $$ 

 $$ \begin{array}{r l r l}{{3346}}&{{}1.2;\quad\dots}\end{array} $$ 

 $$ \begin{array}{r l r l}{{3347}}&{{}1.3;\quad\dots}\end{array} $$ 

 $$ \begin{array}{r l r l}{{3348}}&{{}1.4;\dots}&{\dots}&{{}}&{{}}\\ \end{array} $$ 

 $$ \begin{array}{r l}{{3349}}&{{1.5;\dots}}\end{array} $$ 

 $$ \begin{array}{r l r l}{{3350}}&{{1.6:}}&{{\ldots}}\end{array} $$ 

 $$ \begin{array}{r l r l}{{3351}}&{{1.7:}}&{\ldots}&{{}}\end{array} $$ 

 $$ \begin{array}{r l r l}{{3352}}&{{1.8;}}&{\ldots}&{{}}\end{array} $$ 

 $$ \begin{array}{r l r l}{{3353}}&{{}1.9;\quad\dots}\end{array} $$ 

 $$ \begin{array}{r l}{{3354}}&{{}1.10;}\end{array} $$ 

 $$ \nabla U=\frac{-\hat{\mathbf{r}}}{r^{2}}, $$ 

 $$ \nabla\times(\nabla U)=0\qquad(r\neq0) $$ 

 $$ \nabla\cdot\vec{F}=0,\nabla\times\vec{F}=0 $$ 

3357 1.12:

 $$ \nabla\cdot\vec{F}=0,\quad\nabla\times\vec{F}=-2\hat{z} $$ 

 $$ \begin{array}{r l r l}{{3359}}&{{}1.14;\quad}&{{}12\sqrt{2}}\end{array} $$ 