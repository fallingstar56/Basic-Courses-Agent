3438 6.7:

 $$ B=\frac{\mu_{0}I}{4r} $$ 

3439 6.8: 内部： $ \vec{B} = \mu_0 \sigma r \vec{\omega} $; 外部  $ \vec{B} = 0 $

3440 6.9:

 $$ \rho_{e}^{\prime}=-p_{0},\ \sigma_{e}^{\prime}=\frac{p_{0}R}{2} $$ 

3442 2) 内部： $ \vec{B}=\frac{\mu_{0}p_{0}r^{2}}{2}\vec{\omega} $; 外部： $ \vec{B}=0 $

3443 6.10:

 $$ \vec{B}=\frac{\mu_{0}q}{2\pi R}\vec{\omega} $$ 

 $$ \vec{M}=\tfrac{1}{4}q\omega B R^{2}\hat{x} $$ 

3446 7.1: ...

3447 7.2:

 $$ \vec{H}=-\frac{\vec{M}}{3},\quad\vec{B}=\frac{2\mu_{0}\vec{M}}{3} $$ 

3448 提示：可借用习题6.3的结论。

3449 7.3:

 $$ \vec{M}=\frac{3(\mu_{r}-1)}{(\mu_{r}+2)\mu_{0}}\vec{B}_{0} $$ 

 $$ \vec{H}=\frac{3}{(\mu_{r}+2)\mu_{0}}\vec{B}_{0} $$ 

 $$ \vec{B}=\frac{3\mu_{r}}{\mu_{r}+2}\vec{B}_{0} $$ 

3452 7.4: ...

3453 7.5: ...

3454 7.6:

 $$ B=\frac{NI\mu\mu_{0}}{d(\mu-\mu_{0})+4l\mu_{0}} $$ 

3455 8.1:

 $$ Z_{0}=\frac{60}{\sqrt{\varepsilon_{r}}}\ln\frac{R_{2}}{R_{1}}\quad\Rightarrow\quad\frac{R_{2}}{R_{1}}=e^{5/3}=5.29 $$ 