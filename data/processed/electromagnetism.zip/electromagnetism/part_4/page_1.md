<div style="text-align: center;"><img src="imgs/img_in_image_box_343_144_849_527.jpg" alt="Image" width="42%" /></div>


3244

 $$ \vec{E}=\vec{E}_{0}e^{i(\vec{k}\cdot\vec{r}-\omega t)} $$ 

 $$ \vec{E}_{r}=\vec{E}_{r0}e^{i(\vec{k}_{r}\cdot\vec{r}-\omega_{r}t)} $$ 

 $$ \vec{E}_{t}=\vec{E}_{t0}e^{i(\vec{k}_{t}\cdot\vec{r}-\omega_{t}t)} $$ 

3245 同时，由电磁波中  $ \vec{B}=\frac{\vec{k}\times\vec{E}}{\omega} $，有：

 $$ \vec{B}=\frac{1}{\omega}\vec{k}\times\vec{E}_{0}e^{i(\vec{k}\cdot\vec{r}-\omega t)} $$ 

 $$ \vec{B}_{r}=\frac{1}{\omega_{r}}\vec{k}\times\vec{E}_{r0}e^{i(\vec{k}_{r}\cdot\vec{r}-\omega_{r}t)} $$ 

 $$ \vec{B}_{t}=\frac{1}{\omega_{t}}\vec{k}\times\vec{E}_{t0}e^{i(\vec{k}_{t}\cdot\vec{r}-\omega_{t}t)} $$ 

3246 下面，我们开始利用边界条件来分析三个电磁波的波矢、频率、振幅等之间的关系。首先，3247 由  $ E_{\tau1}=E_{\tau2} $，可知，在 z=0 处的任意一点，任意时刻，均有：

 $$ \left.\vec{E}_{\tau1}\right|_{z=0}+\left.\vec{E}_{r,\tau1}\right|_{z=0}=\left.\vec{E}_{t,\tau1}\right|_{z=0} $$ 

3248 即：

 $$ \left.E_{0\tau}e^{i(\vec{\pmb{k}}\cdot\vec{\pmb{r}}-\omega t)}\right|_{z=0}+E_{r0\tau}e^{i(\vec{\pmb{k}}_{r}\cdot\vec{\pmb{r}}-\omega_{r}t)}\bigg|_{z=0}=E_{t0\tau}e^{i(\vec{\pmb{k}}_{t}\cdot\vec{\pmb{r}}-\omega_{t}t)}\bigg|_{z=0} $$ 

3249 要想让上式对任意 x, y 和 t 都成立，必须有：

 $$ \left.E_{0\tau}\right|_{z=0}+\left.E_{r0\tau}\right|_{z=0}=\left.E_{t0\tau}\right|_{z=0} $$ 

 $$ \left.\vec{\boldsymbol{k}}\cdot\vec{\boldsymbol{r}}-\omega t\right|_{z=0}=\left.\vec{\boldsymbol{k}}_{r}\cdot\vec{\boldsymbol{r}}-\omega_{r}t\right|_{z=0}=\left.\vec{\boldsymbol{k}}_{t}\cdot\vec{\boldsymbol{r}}-\omega_{t}t\right|_{z=0} $$ 

3250 此时，必然有：

 $$ k_{x}x+k_{y}y-\omega t=k_{r x}x+k_{r y}y-\omega_{r}t=k_{t x}x+k_{t y}y-\omega_{t}t $$ 