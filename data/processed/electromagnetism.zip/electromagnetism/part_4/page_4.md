3283 即，当入射波中的  $ \vec{E} $ 与入射面垂直时，反射波和折射波中的  $ \vec{E} $ 的振幅分别为：

 $$ \frac{E_{\perp r0}}{E_{\perp0}}=-\frac{\sin(\theta-\theta_{t})}{\sin(\theta+\theta_{t})} $$ 

 $$ \frac{E_{\perp t0}}{E_{\perp0}}=\frac{2\cos\theta\sin\theta_{t}}{\sin(\theta+\theta_{t})} $$ 

3284

当入射波中的  $ \vec{E} $ 与入射面平行时，不妨假设此时入射波的  $ \vec{B} $ 垂直纸面向外，如下图所示：

<div style="text-align: center;"><img src="imgs/img_in_image_box_342_557_852_923.jpg" alt="Image" width="42%" /></div>


3286

3287 由边值关系：

 $$ E_{\tau1}=E_{\tau2}\quad\Rightarrow\quad E_{0}\cos\theta-E_{r0}\cos\theta=E_{t0}\cos\theta_{t} $$ 

3288

 $$ H_{\tau1}=H_{\tau2}\quad\Rightarrow\quad\sqrt{\frac{\varepsilon_{1}}{\mu_{1}}}(E_{0}+E_{r0})=\sqrt{\frac{\varepsilon_{2}}{\mu_{2}}}E_{t0} $$ 

3289 解得：

 $$ \frac{E_{r0}}{E_{0}}=\frac{\sqrt{\varepsilon_{2}\mu_{1}}\cos\theta-\sqrt{\varepsilon_{1}\mu_{2}}\cos\theta_{t}}{\sqrt{\varepsilon_{2}\mu_{1}}\cos\theta+\sqrt{\varepsilon_{1}\mu_{2}}\cos\theta_{t}} $$ 

 $$ \frac{E_{t0}}{E_{0}}=\frac{2\sqrt{\varepsilon_{1}\mu_{2}}\cos\theta}{\sqrt{\varepsilon_{2}\mu_{1}}\cos\theta+\sqrt{\varepsilon_{1}\mu_{2}}\cos\theta_{t}} $$ 

3290 对于一般介质， $ \mu_{1}\approx\mu_{1}\approx\mu_{0} $，因此：

 $$ \frac{E_{r0}}{E_{0}}=\frac{\sqrt{\frac{\varepsilon_{2}}{\varepsilon_{1}}}\cos\theta-\cos\theta_{t}}{\sqrt{\frac{\varepsilon_{2}}{\varepsilon_{1}}}\cos\theta+\cos\theta_{t}}=\frac{\frac{\sin\theta}{\sin\theta_{t}}\cos\theta-\cos\theta_{t}}{\frac{\sin\theta}{\sin\theta_{t}}\cos\theta+\cos\theta_{t}}=\frac{\sin(\theta-\theta_{t})\cos(\theta+\theta_{t})}{\sin(\theta+\theta_{t})\cos(\theta-\theta_{t})}=\frac{\tan(\theta-\theta_{t})}{\tan(\theta+\theta_{t})} $$ 

 $$ \frac{E_{t0}}{E_{0}}=\frac{2\cos\theta}{\sqrt{\frac{\varepsilon_{2}}{\varepsilon_{1}}}\cos\theta+\cos\theta_{t}}=\frac{2\cos\theta}{\frac{\sin\theta}{\sin\theta_{t}}\cos\theta+\cos\theta_{t}}=\frac{2\cos\theta\sin\theta_{t}}{\sin\theta\cos\theta+\sin\theta_{t}\cos\theta_{t}} $$ 

3291 即，当入射波中的  $ \vec{E} $ 与入射面平行时，反射波和折射波中的  $ \vec{E} $ 的振幅分别为：