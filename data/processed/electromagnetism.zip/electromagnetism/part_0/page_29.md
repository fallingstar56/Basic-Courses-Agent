381

 $$ \nabla\cdot\vec{E}=\frac{\rho}{\varepsilon_{0}} $$ 

 $$ \iint_{S}\vec{E}\cdot\mathrm{d}\vec{S}=\iiint_{V}\frac{\rho}{\varepsilon_{0}}\mathrm{d}V $$ 

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t} $$ 

 $$ \oint_{L}\vec{E}\cdot\mathrm{d}\vec{l}=-\iint_{S}\frac{\partial\vec{B}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

 $$ \nabla\cdot\vec{B}=0 $$ 

 $$ \nabla\times\vec{B}=\mu_{0}\vec{J}+\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}}{\partial t} $$ 

 $$ \iint_{S}\vec{B}\cdot\mathrm{d}\vec{S}=0 $$ 

 $$ \oint_{L}\vec{B}\cdot\mathrm{d}\vec{l}=\mu_{0}\iint_{S}\vec{J}\cdot\mathrm{d}\vec{S}+\mu_{0}\varepsilon_{0}\iint_{S}\frac{\partial\vec{E}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

382 1.4: 对于矢量算符  $ \nabla $，我们已经学过它在直角坐标系中的表达式为：

 $$ \nabla=\hat{\mathbf{x}}\frac{\partial}{\partial x}+\hat{\mathbf{y}}\frac{\partial}{\partial y}+\hat{z}\frac{\partial}{\partial z} $$ 

383 现在，请你根据直角坐标系和柱坐标系的转换关系，证明上述  $ \nabla $ 在柱坐标系中的表达式为：

 $$ \nabla=\hat{\boldsymbol{r}}\frac{\partial}{\partial\boldsymbol{r}}+\hat{\phi}\frac{1}{r}\frac{\partial}{\partial\phi}+\hat{\boldsymbol{z}}\frac{\partial}{\partial z} $$ 

84（提示：将直角坐标系中  $ \nabla $ 的各个元素转换到柱坐标系中，比如用  $ r, \phi, z $ 和  $ \hat{r}, \hat{\phi}, \hat{z} $ 来表示  $ \hat{x}, \hat{y}, \hat{z} $，再利用链式法则将  $ \frac{\partial}{\partial x} $ 写成  $ \frac{\partial r}{\partial x} \frac{\partial}{\partial r} + \frac{\partial \phi}{\partial x} \frac{\partial}{\partial \phi} + \frac{\partial z}{\partial x} \frac{\partial}{\partial z} $ 的形式并进一步展开）

1.5: 现在，我们换一种方法来推导矢量算符  $ \nabla $ 在柱坐标系中的表达式：结合标量场  $ \Phi $ 的梯度的物理意义，即方向与等势面的切线方向垂直，大小等于  $ \Phi $ 在等势面法向方向的导数  $ \frac{d\Phi}{d\vec{r}} $，通过结合求解标量场的梯度在柱坐标系中的表达式的形式求出柱坐标系中的矢量算符  $ \nabla $ 的表达式。

1.6: 利用习题1.4得到的  $ \nabla $ 算符在柱坐标系中的表达式，证明：在柱坐标系中，标量场  $ \Phi $ 的梯度，矢量场  $ \vec{F} = F_r \hat{r} + F_\phi \hat{\phi} + F_z \hat{z} $ 的散度和旋度分别为：

 $$ \nabla\Phi=\hat{\boldsymbol{r}}\frac{\partial\Phi}{\partial\boldsymbol{r}}+\hat{\boldsymbol{\phi}}\frac{\partial\Phi}{\boldsymbol{r}\partial\phi}+\hat{\boldsymbol{z}}\frac{\partial\Phi}{\partial z} $$ 

 $$ \nabla\cdot\vec{\boldsymbol{F}}=\frac{1}{r}\frac{\partial(r F_{r})}{\partial r}+\frac{1}{r}\frac{\partial F_{\phi}}{\partial\phi}+\frac{\partial F_{z}}{\partial z} $$ 

 $$ \nabla\times\vec{\boldsymbol{F}}=\hat{\boldsymbol{r}}\bigg(\frac{1}{r}\frac{\partial F_{z}}{\partial\phi}-\frac{\partial F_{\phi}}{\partial z}\bigg)+\hat{\phi}\bigg(\frac{\partial F_{r}}{\partial z}-\frac{\partial F_{z}}{\partial r}\bigg)+\hat{\boldsymbol{z}}\frac{1}{r}\bigg(\frac{\partial(r F_{\phi})}{\partial r}-\frac{\partial F_{r}}{\partial\phi}\bigg) $$ 

391（提示：推导过程中可能会用到： $ \frac{\partial\hat{r}}{\partial\phi}=\hat{\phi} $ 等结论。）

392 1.7: 用与习题1.4类似的方法，证明矢量算符  $ \nabla $ 在球坐标系中的表达式为：

 $$ \nabla=\hat{\boldsymbol{r}}\frac{\partial}{\partial r}+\hat{\boldsymbol{\theta}}\frac{1}{r}\frac{\partial}{\partial\theta}+\hat{\phi}\frac{1}{r\sin\theta}\frac{\partial}{\partial\phi} $$ 

1.8: 用与习题1.5类似的方法，证明矢量算符  $ \nabla $ 在球坐标系中的表达式为：

 $$ \nabla=\hat{\boldsymbol{r}}\frac{\partial}{\partial r}+\hat{\boldsymbol{\theta}}\frac{1}{r}\frac{\partial}{\partial\theta}+\hat{\phi}\frac{1}{r\sin\theta}\frac{\partial}{\partial\phi} $$ 