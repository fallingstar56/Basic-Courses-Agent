#### 1.3.2 散度

当我们考虑一个矢量场  $ \vec{F} $ 随着空间的变化的时候，我们不仅要考虑空间中的三个自由度 x, y, z，还需要考虑矢量场本身有三个分量  $ F_{x}, F_{y}, F_{z} $，而每个分量都会随着 x, y, z 的改变而改变，因此总共存在 9 个微分量：

 $$ \begin{aligned}\frac{\partial F_{x}}{\partial x},&\quad\frac{\partial F_{x}}{\partial y},&\frac{\partial F_{x}}{\partial z}\\\frac{\partial F_{y}}{\partial x},&\quad\frac{\partial F_{y}}{\partial y},&\frac{\partial F_{y}}{\partial z}\\\frac{\partial F_{z}}{\partial x},&\quad\frac{\partial F_{z}}{\partial y},&\frac{\partial F_{z}}{\partial z}\end{aligned} $$ 

307 从这 9 个微分量中，我们可以通过组合其中某些微分量得到具有重要物理含义的一些量，比如，308 我们将上面  $ 3 \times 3 $ 个微分量里面的对角线上的 3 个相加，可以得到一个标量，我们称之为矢量 309 场  $ \vec{F} $ 的散度 (divergence)：

 $$ \mathrm{div}\vec{F}=\frac{\partial F_{x}}{\partial x}+\frac{\partial F_{y}}{\partial y}+\frac{\partial F_{z}}{\partial z} $$ 

310 矢量场的散度是一个标量，它也可以写成  $ \nabla $ 和  $ \vec{F} $ 的点乘的形式：

 $$ \mathrm{div}\vec{F}=\frac{\partial F_{x}}{\partial x}+\frac{\partial F_{y}}{\partial y}+\frac{\partial F_{z}}{\partial z}=(\frac{\partial}{\partial x},\frac{\partial}{\partial y},\frac{\partial}{\partial z})\cdot(F_{x},F_{y},F_{z})=\nabla\cdot\vec{F} $$ 

需要说明的是，上述关于散度的定义只是单纯的从数学上组合部分  $ \vec{F} $ 的空间变化的偏微分量给出的，仅从这个数学上的组合是很难看出其物理含义的。关于散度，还有一个更具有物理含义的定义，即：矢量场  $ \vec{F} $ 在空间  $ \vec{r} $ 处的散度，是指该矢量场在包含  $ \vec{r} $ 的一个无穷小的闭合曲面 S 上的通量，除以该闭合曲面所围起来的空间的体积 dV：

 $$ \mathrm{div}\vec{F}=\lim_{\mathrm{d}V\rightarrow0}\frac{\oint_{S}\vec{F}\cdot\mathrm{d}\vec{S}}{\mathrm{d}V} $$ 

也就是说，散度这个量表征的是矢量场的“场线”在某一点的发散或者会聚程度（因此取名“散度”）， $ \operatorname{div}\vec{F}>0 $ 表示在这一点  $ \vec{F} $ 是向外发散的， $ \operatorname{div}\vec{F}<0 $ 则表示在这一点  $ \vec{F} $ 是向内会聚的，而  $ \operatorname{div}\vec{F}=0 $ 则表示在这一点既不发散也不会聚（即：有多少场线进来就有多少出去）。

下面，我们将证明，上述1.57式和1.58式关于  $ \vec{F} $ 的散度的定义是等价的。如右图所示，取直角坐标系在空间中某点  $ \vec{r} = (x, y, z) $ 处，以该点为中心取边为 dx, dy, dz 的长方体，下面我们来计算矢量场  $ \vec{F} $ 在该长方体的六个表面组成的闭合曲面上的通量。

<div style="text-align: center;"><img src="imgs/img_in_image_box_641_1368_1046_1547.jpg" alt="Image" width="34%" /></div>
