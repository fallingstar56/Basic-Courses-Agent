 $$ \begin{aligned}\mathrm{d}V&=\mathrm{d}\vec{r}_{i}\cdot(\mathrm{d}\vec{r}_{j}\times\mathrm{d}\vec{r}_{k})\\&=(\frac{\partial\vec{r}}{\partial i}\mathrm{d}i)\cdot\left((\frac{\partial\vec{r}}{\partial j}\mathrm{d}j)\times(\frac{\partial\vec{r}}{\partial k}\mathrm{d}k)\right)\\&=\frac{\partial\vec{r}}{\partial i}\cdot\left(\frac{\partial\vec{r}}{\partial j}\times\frac{\partial\vec{r}}{\partial k}\right)\mathrm{d}i\mathrm{d}j\mathrm{d}k\end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_736_166_1000_404.jpg" alt="Image" width="22%" /></div>


下面我们将分别计算在几种典型的坐标系中的体积元的表达式：

1\. 直角坐标系：

 $$ \begin{aligned}\vec{\boldsymbol{r}}&=(x,y,z)\\\frac{\partial\vec{\boldsymbol{r}}}{\partial x}&=(1,0,0),\quad\frac{\partial\vec{\boldsymbol{r}}}{\partial y}=(0,1,0),\quad\frac{\partial\vec{\boldsymbol{r}}}{\partial z}=(0,0,1)\end{aligned} $$ 

 $$ \begin{aligned}\mathrm{d}V&=\frac{\partial\vec{r}}{\partial x}\cdot\left(\frac{\partial\vec{r}}{\partial y}\times\frac{\partial\vec{r}}{\partial z}\right)\mathrm{d}x\mathrm{d}y\mathrm{d}z\\&=(1,0,0)\cdot\left((0,1,0)\times(0,0,1)\right)\mathrm{d}x\mathrm{d}y\mathrm{d}z\\&=(1,0,0)\cdot(1,0,0)\mathrm{d}x\mathrm{d}y\mathrm{d}z\\&=\mathrm{d}x\mathrm{d}y\mathrm{d}z\end{aligned} $$ 

显然，对于直角坐标系，我们也可以通过下图很直观地看出， $ \vec{r} $ 处的三个线元的大小分别是 dx, dy, dz，且它们之间互相垂直，因此体积元就是 dxdydz。

<div style="text-align: center;"><img src="imgs/img_in_image_box_413_1112_842_1541.jpg" alt="Image" width="36%" /></div>
