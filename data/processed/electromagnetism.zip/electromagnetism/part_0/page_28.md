 $$ \vec{n}_{S}\cdot\mathrm{curl}\vec{F}=\lim_{\mathrm{d}S\rightarrow0}\frac{\oint_{C}\vec{F}\cdot\mathrm{d}\vec{r}}{\mathrm{d}S} $$ 

上面的1.70式也可以写成如下等式：

 $$ \oint_{C}\vec{F}\cdot\mathrm{d}\vec{r}=\iint_{S}(\nabla\times\vec{F})\cdot\mathrm{d}\vec{S}\quad(S\rightarrow0) $$ 

372 事实上，上式中的  $ S \rightarrow 0 $ 这个条件也可以去掉，即上式对于一般的有限大的曲面及其对应的闭合曲线也是成立的，这就是下面的斯托克斯 (Stokes) 定理：

定理 1.3 斯托克斯定理

矢量场  $ \vec{F} $ 在任意闭合曲线 C 上的线积分，等于该矢量场的旋度  $ \nabla \times \vec{F} $ 在 C 所包围的曲面 S 内的面积分：

 $$ \oint_{C}\vec{F}\cdot\mathrm{d}\vec{r}=\iint_{S}(\nabla\times\vec{F})\cdot\mathrm{d}\vec{S} $$ 

上述定理的证明方法与上一节中高斯定理的证明方法非常类似，即将一个大的曲面分成多个足够小的小曲面，相邻曲面间共享的路径上  $ \vec{F} $ 的路径积分刚好抵消（如右图所示），于是最终可以将  $ \vec{F} $ 在 C 上的线积分写成多个小的闭合曲面上的线积分之和，而这些小的线积分又可以由1.70式写成多个面积分的和，最终得出1.75式。

<div style="text-align: center;"><img src="imgs/img_in_image_box_791_755_1028_949.jpg" alt="Image" width="19%" /></div>


## 习题

377 1.1: 请证明：对于任意矢量场  $ \vec{F} $ 和标量场  $ \Phi $，有以下恒等式：

 $$ \nabla\cdot(\nabla\times\vec{F})=0 $$ 

 $$ \nabla\times\nabla\Phi=0 $$ 

 $$ \nabla\times(\nabla\times\vec{F})=\nabla(\nabla\cdot\vec{F})-\nabla^{2}\vec{F} $$ 

378 1.2: 请证明矢量叉乘形式的高斯定理:

 $$ \iiint_{V}\nabla\times\vec{F}\mathrm{d}V=-\iint_{\vec{S}}\vec{F}\times\mathrm{d}\vec{S}=-\iint_{\vec{S}}\vec{F}\times\vec{n}\mathrm{d}S $$ 

1.3: 卜式左右两边分别是真空中麦克斯韦方程组的微分形式和积分形式，请从微分形式推出积分形式，以及从积分形式推出微分形式。