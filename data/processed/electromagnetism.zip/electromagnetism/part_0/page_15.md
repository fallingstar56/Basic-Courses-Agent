206 数方程：

 $$ x=\sin\theta\cos\phi,\quad y=\sin\theta\sin\phi,\quad z=\cos\theta;\quad\theta\in[0,\pi],\phi\in[0,2\pi] $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_381_238_816_555.jpg" alt="Image" width="36%" /></div>


207

208 如上图所示，结合向量叉乘的几何意义（面积），我们可以利用曲面的参数方程，将面积元  $ \mathrm{d}\vec{S} $ 写成：



 $$ \mathrm{d}\vec{\boldsymbol{S}}=\mathrm{d}\vec{\boldsymbol{r}}_{1}\times\mathrm{d}\vec{\boldsymbol{r}}_{2},\quad\mathrm{d}\vec{\boldsymbol{r}}_{1}=\frac{\partial\vec{\boldsymbol{r}}(s,t)}{\partial s}\mathrm{d}s,\quad\mathrm{d}\vec{\boldsymbol{r}}_{2}=\frac{\partial\vec{\boldsymbol{r}}(s,t)}{\partial t}\mathrm{d}t $$ 

 $$ \Rightarrow\mathrm{d}\vec{S}=\frac{\partial\vec{r}(s,t)}{\partial s}\times\frac{\partial\vec{r}(s,t)}{\partial t}\mathrm{d}s\mathrm{d}t $$ 

 $$ \mathrm{d}S=\left|\frac{\partial\vec{\boldsymbol{r}}(s,t)}{\partial s}\times\frac{\partial\vec{\boldsymbol{r}}(s,t)}{\partial t}\right|\mathrm{d}s\mathrm{d}t $$ 

210 因此，上述标量场和矢量场的面积分便可以写成关于参数 s 和 t 的普通二重积分：

 $$ \iint_{S}f\mathrm{d}S=\iint_{S}f(\vec{\mathbf{r}}(s,t))\Big|\frac{\partial\vec{\mathbf{r}}(s,t)}{\partial s}\times\frac{\partial\vec{\mathbf{r}}(s,t)}{\partial t}\Big|\mathrm{d}s\mathrm{d}t $$ 

 $$ \iint_{S}\vec{f}\cdot\mathrm{d}\vec{S}=\iint_{S}\vec{f}(\vec{r}(s,t))\cdot\left(\frac{\partial\vec{r}(s,t)}{\partial s}\times\frac{\partial\vec{r}(s,t)}{\partial t}\right)\mathrm{d}s\mathrm{d}t $$ 

211 例 1.2

212 在柱坐标系中，求以 z 轴为对称轴、半径为 r 的圆柱面上位于  $ (r,\phi,z) $ 处的面积元 d $ \vec{S} $