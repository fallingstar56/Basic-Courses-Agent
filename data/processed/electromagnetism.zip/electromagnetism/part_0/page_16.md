213 解:

如右图所示，可知  $ \mathrm{d}\vec{S} $ 与  $ \vec{r} $ 同向，其大小为：



 $$ \mathrm{d}S=\left|\mathrm{d}\vec{r}_{1}\times\mathrm{d}\vec{r}_{2}\right|=r\mathrm{d}\phi\mathrm{d}z $$ 

因此，柱坐标系的圆柱面的面元为：

 $$ \mathrm{d}\vec{S}=\hat{\boldsymbol{r}}r\mathrm{d}\phi\mathrm{d}z $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_698_225_1043_536.jpg" alt="Image" width="28%" /></div>


此外，也可以直接通过圆柱面的参数方程求解：首先，我们已知圆柱面的参数方程为：

 $$ \vec{r}(\phi,z)=(r\cos\phi,r\sin\phi,z) $$ 

215 将  $ \vec{r} $ 对  $ \phi $ 和 z 求偏导，可得：

 $$ \frac{\partial\vec{r}}{\partial\phi}=(-r\sin\phi,r\cos\phi,0) $$ 

 $$ \frac{\partial\vec{\bf r}}{\partial z}=(0,0,1) $$ 

216 因而：

 $$ \mathrm{d}\vec{S}=\frac{\partial\vec{r}}{\partial\phi}\times\frac{\partial\vec{r}}{\partial z}\mathrm{d}\phi\mathrm{d}z $$ 

 $$ =(-r\sin\phi,r\cos\phi,0)\times(0,0,1)\mathrm{d}\phi\mathrm{d}z $$ 

 $$ =(r\cos\phi,r\sin\phi,0)\mathrm{d}\phi\mathrm{d}z $$ 

 $$ =\hat{\boldsymbol{r}}\mathrm{r}\mathrm{d}\phi\mathrm{d}z $$ 

请注意，在上面的推导过程中，我们把圆柱面的参数方程写到了直角坐标系中（即： $ \vec{r} = r \cos \phi \hat{x} + r \sin \phi \hat{y} + z \hat{z} $），而不是写到柱坐标系中（即： $ \vec{r} = r \hat{r} + \phi \hat{\phi} + z \hat{z} $），这是因为，如果使用后者，那么在求诸如  $ \frac{\partial \vec{r}}{\partial \phi} $ 偏导时，我们就要考虑单位矢量  $ \hat{r} $ 对  $ \phi $ 的偏导（ $ \phi $ 变化时， $ \hat{r} $ 也会变），但是如果采用前者的直角坐标系，由于单位矢量  $ \hat{x}, \hat{y}, \hat{z} $ 不会随着  $ \phi $ 或者  $ z $ 的改变而改变，因而只需要考虑坐标值本身的偏导就可以了。类似这样的处理方法在本书的后面部分还会经常使用。

222 例 1.3

223 在球坐标系中，求以原点为球心、半径为 r 的球面上位于  $ (r, \theta, \phi) $ 处的面积元  $ \mathrm{d}\vec{S} $