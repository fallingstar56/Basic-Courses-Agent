582

 $$ \vec{E}=\frac{\vec{F}}{q_{0}} $$ 

根据电场强度的定义和库仑定律，我们可以很容易求出真空中静止点电荷产生的电场：

 $$ \vec{E}=\frac{q}{4\pi\varepsilon_{0}r^{2}}\hat{\boldsymbol{r}} $$ 

可知，点电荷产生的电场其强度与距离  $ r^{2} $ 成反比，方向与  $ \vec{r} $ 同向（负电荷为反向），即这是一个有心力场。

电场与库仑力一样，也满足矢量叠加原理，即 N 个点电荷在空间某点产生的总电场强度，等于每个电荷单独在该点产生的电场强度的矢量和：

 $$ \vec{E}(\vec{r})=\sum_{i=1}^{N}\vec{E}_{i}(\vec{r})=\frac{1}{4\pi\varepsilon_{0}}\sum_{i=1}^{N}\frac{q_{i}}{|\vec{r}-\vec{r}_{i}|^{3}}(\vec{r}-\vec{r}_{i}) $$ 

588 有了电场的叠加原理，我们便可以计算任意带电体系产生的电场。下面我们选取几个典型的常见带电体系，来分析它们产生的电场有什么特征。

590

例 2.4

求电偶极子在远点  $ P(\vec{r}) $ 处  $ (r \gg l) $ 产生的电场  $ \vec{E}(\vec{r}) $。

<div style="text-align: center;"><img src="imgs/img_in_image_box_832_807_1034_1006.jpg" alt="Image" width="16%" /></div>


解:

由叠加原理， $ P(\vec{r}) $ 点的电场强度等于正负电荷在该点产生的电场强度的矢量和：

 $$ \begin{aligned}\vec{E}(\vec{r})&=\vec{E}_{+}(\vec{r})+\vec{E}_{-}(\vec{r})\\&=\frac{q}{4\pi\varepsilon_{0}}\bigg[\frac{\vec{r}_{+}}{r_{+}^{3}}-\frac{\vec{r}_{-}}{r_{-}^{3}}\bigg]\end{aligned} $$ 

591 其中：

 $$ \vec{r}_{+}=\vec{r}-\frac{\vec{l}}{2},\quad\vec{r}_{-}=\vec{r}+\frac{\vec{l}}{2} $$ 

592

 $$ r_{+}^{-3}=\left[\left(\vec{r}-\frac{\vec{l}}{2}\right)\cdot\left(\vec{r}-\frac{\vec{l}}{2}\right)\right]^{-3/2}=\left(r^{2}+\frac{l^{2}}{4}-\vec{r}\cdot\vec{l}\right)^{-3/2}=r^{-3}\Biggl(1+\frac{l^{2}}{4r^{2}}-\frac{\vec{r}\cdot\vec{l}}{r^{2}}\Biggr)^{-3/2} $$ 

593 由于  $ r \gg l $，上式可通过泰勒展开只保留 l/r 的一次项：

 $$ r_{+}^{-3}=r^{-3}\bigg(1+\frac{l^{2}}{4r^{2}}-\frac{\vec{r}\cdot\vec{l}}{r^{2}}\bigg)^{-3/2}\approx r^{-3}\bigg(1-\frac{\vec{r}\cdot\vec{l}}{r^{2}}\bigg)^{-3/2}\approx r^{-3}\bigg(1+\frac{3}{2}\frac{\vec{r}\cdot\vec{l}}{r^{2}}\bigg) $$ 

594 类似可得：

 $$ r_{-}^{-3}\approx r^{-3}\bigg(1-\frac{3}{2}\frac{\vec{r}\cdot\vec{l}}{r^{2}}\bigg) $$ 