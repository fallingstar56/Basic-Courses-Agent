637 4. 电偶极子： $ E \propto r^{-3} $

638 5. 电四极子： $ E \propto r^{-4} $

可以看出，以点电荷的电场  $ E \propto r^{-2} $ 为参考，诸如电偶极子和电四极子等存在正电荷和负电荷之间有“内耗”的情况会使得产生的场更不容易向远处传播（长程变短程）；而诸如线电荷和面电荷等同类电荷的排布会使得产生的场随距离衰减得更慢（“团结就是力量”），这种增强效应有些类似于影院中使用的呈一条直线排布的柱形音响（音柱），这类音响常被作为远距离声音传播设备。

643



### 例 2.9

求如图所示的均匀带电球（半径 R，体电荷密度  $ \rho_{e} $）在其球外距离球心 z 处的一点  $ P(z) $ 处的电场强度。

<div style="text-align: center;"><img src="imgs/img_in_image_box_708_604_1019_753.jpg" alt="Image" width="26%" /></div>


解:

645 如图所示，将带电球切分为无穷个与 OP 垂直的均匀带电圆盘，在2.35式中，用  $ \rho dx $ 代替  $ \sigma_{e} $，用  $ \sqrt{R^{2}-x^{2}} $ 代替 R，用 z-x 代替 z，可得在 x 处厚度为 dx 的圆盘在 P 处产生的电场强度为：

 $$ \begin{aligned}\mathrm{d}E&=\frac{\rho_{e}\mathrm{d}x}{2\varepsilon_{0}}\Big[1-\frac{z-x}{\sqrt{R^{2}-x^{2}+(z-x)^{2}}}\Big]\\&=\frac{\rho_{e}\mathrm{d}x}{2\varepsilon_{0}}\Big[1-\frac{z-x}{\sqrt{R^{2}+z^{2}-2z x}}\Big]\\&=\frac{\rho_{e}\mathrm{d}x}{2\varepsilon_{0}}\Big[1-\frac{z-x}{\sqrt{2z}\sqrt{\frac{R^{2}+z^{2}}{2z}-x}}\Big]\end{aligned} $$ 

令  $ a=\frac{z^{2}+R^{2}}{2z} $， $ b=z-a=\frac{z^{2}-R^{2}}{2z} $，可得：

 $$ \begin{aligned}\mathrm{d}E&=\frac{\rho_{e}\mathrm{d}x}{2\varepsilon_{0}}\left[1-\frac{a-x+b}{\sqrt{2z}\sqrt{a-x}}\right]\\&=\frac{\rho_{e}\mathrm{d}x}{2\varepsilon_{0}}\frac{1}{\sqrt{2z}}\left[\sqrt{2z}-\sqrt{a-x}-\frac{b}{\sqrt{a-x}}\right]\end{aligned} $$ 

649 于是：

 $$ \begin{aligned}E&=\int\mathrm{d}E=\frac{\rho_{e}}{2\varepsilon_{0}}\frac{1}{\sqrt{2z}}\int_{-R}^{R}\left[\sqrt{2z}-\sqrt{a-x}-\frac{b}{\sqrt{a-x}}\right]\mathrm{d}x\\&=\frac{\rho_{e}}{2\varepsilon_{0}}\frac{1}{\sqrt{2z}}\Big[\sqrt{2z}x+\frac{2}{3}(a-x)^{3/2}+2b\sqrt{a-x}\Big]\Big|_{-R}^{R}\\&=\frac{\rho_{e}}{2\varepsilon_{0}}\frac{1}{\sqrt{2z}}\Big[\sqrt{2z}\cdot2R-\frac{2}{3}[(a+R)^{3/2}-(a-R)^{3/2}]-2b[\sqrt{a+R}-\sqrt{a-R}]\Big]\end{aligned} $$ 