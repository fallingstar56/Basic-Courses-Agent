上面提到的关于矢量场的“旋转”的图像，很容易让人联想到在第1.2节学习矢量场的线积分，比如对于上面提到的这种从 A 到 D 点  $ \vec{F} $ 向右旋转且  $ \vec{F} $ 的方向在各个地方都大致与路径的切线方向平行的情况， $ \vec{F} $ 从 A 到 D 的线积分必然将与个点的  $ A = \frac{\partial F_y}{\partial x} - \frac{\partial F_x}{\partial y} $ 这个量有关。为了定量的理解上面定义的  $ \vec{A} $ 矢量与  $ \vec{F} $ 的线积分的联系，我们不妨取右图中这样一个以  $ (x, y) $ 为中心，长宽分别为  $ dx, dy $ 的很小的长方形组成的闭合曲线，则  $ \vec{F} $ 在这一闭合曲线上的线积分为：

<div style="text-align: center;"><img src="imgs/img_in_image_box_693_173_1040_403.jpg" alt="Image" width="29%" /></div>


 $$ \begin{aligned}\oint_{ABCD}\vec{F}\cdot\mathrm{d}\vec{r}=&\int_{AB}\vec{F}\cdot\mathrm{d}\vec{r}+\int_{BC}\vec{F}\cdot\mathrm{d}\vec{r}+\int_{CD}\vec{F}\cdot\mathrm{d}\vec{r}+\int_{DA}\vec{F}\cdot\mathrm{d}\vec{r}\\=&\Big(-F_{y}(x-\frac{\mathrm{d}x}{2},y)\mathrm{d}y\Big)+\Big(F_{x}(x,y-\frac{\mathrm{d}y}{2})\mathrm{d}x\Big)+\\&\Big(F_{y}(x+\frac{\mathrm{d}x}{2},y)\mathrm{d}y\Big)+\Big(-F_{x}(x,y+\frac{\mathrm{d}y}{2})\mathrm{d}x\Big)\\=&\Big(F_{y}(x+\frac{\mathrm{d}x}{2},y)-F_{y}(x-\frac{\mathrm{d}x}{2},y)\Big)\mathrm{d}y-\Big(F_{x}(x,y+\frac{\mathrm{d}y}{2})-F_{x}(x,y-\frac{\mathrm{d}y}{2})\Big)\mathrm{d}x\\=&\Big(\frac{\partial F_{y}}{\partial x}\mathrm{d}x\Big)\mathrm{d}y-\Big(\frac{\partial F_{x}}{\partial y}\mathrm{d}y\Big)\mathrm{d}x\\=&\Big(\frac{\partial F_{y}}{\partial x}-\frac{\partial F_{x}}{\partial y}\Big)\mathrm{d}x\mathrm{d}y=\Big(\frac{\partial F_{y}}{\partial x}-\frac{\partial F_{x}}{\partial y}\Big)\mathrm{d}S\end{aligned} $$ 

359 结合上面我们关于矢量  $ \vec{A} $ 的定义，我们可以把上式进一步写成：

 $$ \oint_{C}\vec{F}\cdot\mathrm{d}\vec{r}=\iint_{S}\vec{A}\cdot\mathrm{d}\vec{S}\quad(S\rightarrow0) $$ 

360 或者写成：

 $$ A=\vec{A}\cdot\hat{z}=\frac{\partial F_{y}}{\partial x}-\frac{\partial F_{x}}{\partial y}=\frac{\oint_{C}\vec{F}\cdot\mathrm{d}\vec{r}}{\mathrm{d}S}\quad(\mathrm{d}S\rightarrow0) $$ 

61 即：上面在二维平面上定义的表征二维矢量场  $ \vec{F} $ 旋转程度的矢量  $ \vec{A} $，其在某处的大小等于  $ \vec{F} $ 在以该处为中心的一个小的闭合曲线上的线积分，除以该闭合曲线包围的曲面的面积，而其符号（方向）则与线积分的符号相同，即正号表示  $ \vec{F} $ 在该点是逆时针“旋转”（线积分为正）。

对于一般情况下的三维情况下的矢量场  $ \vec{F} $，我们可以类似地定义一个表征  $ \vec{F} $ 的“旋转”程度的矢量，我们称之为  $ \vec{F} $ 的旋度（Curl）：

 $$ \mathrm{curl}\vec{F}=\left(\frac{\partial F_{z}}{\partial y}-\frac{\partial F_{y}}{\partial z}\right)\hat{\boldsymbol{x}}+\left(\frac{\partial F_{x}}{\partial z}-\frac{\partial F_{z}}{\partial x}\right)\hat{\boldsymbol{y}}+\left(\frac{\partial F_{y}}{\partial x}-\frac{\partial F_{x}}{\partial y}\right)\hat{\boldsymbol{z}}=\nabla\times\vec{F} $$ 

与上述二维情况的分析情况类似，我们可以得出矢量场的旋度与其线积分的关系，即，如果在空间某点附近取一个无穷小的闭合曲线 C，则  $ \vec{F} $ 在 C 上的线积分除以 C 所包围的曲面的面积，等于  $ \vec{F} $ 的旋度在该曲面的法向上的投影：