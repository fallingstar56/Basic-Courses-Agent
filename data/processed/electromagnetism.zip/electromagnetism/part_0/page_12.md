 $$ \iint_{S}\vec{D}\cdot\mathrm{d}\vec{S}=\iiint_{V}\rho_{0}\mathrm{d}V $$ 

 $$ \oint_{L}\vec{E}\cdot\mathrm{d}\vec{l}=-\iint_{S}\frac{\partial\vec{B}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

 $$ \iint_{S}\vec{B}\cdot\mathrm{d}\vec{S}=0 $$ 

 $$ \oint_{L}\vec{H}\cdot\mathrm{d}\vec{l}=\iint_{S}\vec{J}\cdot\mathrm{d}\vec{S}+\iint_{S}\frac{\partial\vec{D}}{\partial t}\cdot\mathrm{d}\vec{S} $$ 

在学习上述方程组之前，我们有必要先学习（或回顾）这个方程组里面涉及到的两个重要的数学工具，即场的线、面和体积分，以及场的梯度、散度和旋度。

### 1.2 线积分、面积分和体积分

#### 1.2.1 线积分

我们常见的形如  $ \int_{a}^{b} f(x) \, dx $ 是函数  $ f(x) $ 在实数区间  $ [a, b] $ 上的积分，计算积分时函数沿着从 a 到 b 的一维区间取值，对于我们即将讨论的线积分（line integral），它的积分函数的取值是沿着被称为积分路径的特定三维曲线  $ (C) $，因此线积分也叫路径积分（path integral）。线积分中，被积函数可以是标量场，也可以是矢量场：

1. 标量场： $ \int_C f(\vec{r}) \, \mathrm{d}s $，其中  $ f(\vec{r}) $ 是被积的标量场， $ ds = |\vec{d}r| $ 是在  $ \vec{r} $ 处曲线的切向向量的长度，也可以看成该点处的一段很小的弧长（也称为线元，line element）。

2. 矢量场： $ \int_C \vec{f}(\vec{r}) \cdot d\vec{r} $，其中  $ \vec{f}(\vec{r}) $ 是被积的矢量场， $ d\vec{r} $ 是在  $ \vec{r} $ 处曲线的切向向量（也称为矢量线元，vector line element）。

<div style="text-align: center;"><img src="imgs/img_in_image_box_245_1142_946_1345.jpg" alt="Image" width="58%" /></div>


我们知道，空间中的一条曲线的方程可以用参数方程来表示，比如下式:

 $$ \vec{r}=\vec{r}(t)=x(t)\hat{x}+y(t)\hat{y}+z(t)\hat{z} $$ 

174 表示的是曲线  $ \vec{r} : [t_{0}, t_{1}] \to C $，其中  $ \vec{r}(t_{0}) $ 和  $ \vec{r}(t_{1}) $ 分别是曲线 C 的两个端点。比如，在 z = 0