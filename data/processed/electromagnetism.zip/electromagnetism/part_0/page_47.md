650 其中，

 $$ a+R=\frac{(z+R)^{2}}{2z},a+R=\frac{(z-R)^{2}}{2z} $$ 

 $$ (a+R)^{3/2}-(a-R)^{3/2}=\frac{(z+R)^{3}-(z-R)^{3}}{2z\sqrt{2z}}=\frac{2(R^{3}+3z^{2}R)}{2z\sqrt{2z}} $$ 

 $$ \sqrt{a+R}-\sqrt{a-R}=\frac{2R}{\sqrt{2z}} $$ 

651 因此，

 $$ \begin{aligned}E&=\frac{\rho_{e}}{2\varepsilon_{0}}\frac{1}{\sqrt{2z}}\Big[\sqrt{2z}\cdot2R-\frac{2}{3}\cdot\frac{2(R^{3}+3z^{2}R)}{2z\sqrt{2z}}-2b\frac{2R}{\sqrt{2z}}\Big]\\&=\frac{\rho_{e}}{2\varepsilon_{0}}\frac{1}{\sqrt{2z}}\Big[\sqrt{2z}\cdot2R-\frac{2}{3}\cdot\frac{(R^{3}+3z^{2}R)}{z\sqrt{2z}}-\frac{z^{2}-R^{2}}{z}\frac{2R}{\sqrt{2z}}\Big]\\&=\frac{\rho_{e}}{2\varepsilon_{0}}\frac{1}{\sqrt{2z}}\frac{12z^{2}R-2(R^{3}+3z^{2}R)-6(z^{2}-R^{2})R}{3z\sqrt{2z}}\\&=\frac{\rho_{e}}{2\varepsilon_{0}}\frac{4R^{3}}{6z^{2}}\\&=\frac{\rho_{e}\cdot\frac{4}{3}\pi R^{3}}{4\pi\varepsilon_{0}z^{2}}\\&=\frac{q}{4\pi\varepsilon_{0}z^{2}}\\ \end{aligned} $$ 

652 从上面的结果可以看出，电荷量 q 的均匀带电球在球外的电场，等价于位于球心的电荷量为 q 的点电荷在球外产生的电场。

为了直观的显示电场的方向和大小，我们往往会使用电场线：电场线是一堆带箭头的曲线，这些曲线上每一点的切线方向和该点的电场强度方向一致，而且垂直电场线的横截面积上场线的条数（即电场线的“密度”）与电场强度的大小成正比。静电场的电场线是连续的，且从正电荷（或无穷远处）出发，进入负电荷（或无穷远处）；且由于电场力是保守力（我们接下来的章节会学习），我们还知道电场线是不闭合的。下面是常见带电体系的电场线示意图：（1）正电荷；（2）负电荷；（3）电偶极子。

<div style="text-align: center;"><img src="imgs/img_in_image_box_205_1220_362_1380.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;">(1)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_421_1220_581_1380.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;">(2)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_639_1134_984_1471.jpg" alt="Image" width="28%" /></div>


<div style="text-align: center;">(3)</div>
