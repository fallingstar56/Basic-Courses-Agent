679 以原点为中心，取半径为 r 的球，球面  $ \vec{S} $，dV 为球的体积，则由对称性可计算上面的面积分：

 $$ \begin{aligned}\nabla\cdot\frac{\vec{r}}{r^{3}}&=\lim_{\mathrm{d}V\rightarrow0}\frac{\oint_{\vec{S}}\frac{\vec{r}}{r^{3}}\cdot\mathrm{d}\vec{S}}{\mathrm{d}V}\\&=\lim_{r\rightarrow0}\frac{\frac{r}{r^{3}}4\pi r^{2}}{\frac{4}{3}\pi r^{3}}\\&=\lim_{r\rightarrow0}\frac{3}{r^{3}}\\&=\infty\end{aligned} $$ 

680 即：

 $$ \nabla\cdot\frac{\vec{r}}{r^{3}}=\begin{cases}0,&\vec{r}\neq0,\\\infty,&\vec{r}=0.\end{cases} $$ 

681 此外，根据矢量场的高斯定理（定理1.2），我们还有：

 $$ \iiint_{V}\nabla\cdot\frac{\vec{r}}{r^{3}}\mathrm{d}V=\iint_{\vec{S}}\frac{\vec{r}}{r^{3}}\mathrm{d}\vec{S} $$ 

682 令  $ \vec{S} $ 为以原点为球心的球面，则：

 $$ \iiint_{V}\nabla\cdot\frac{\vec{r}}{r^{3}}\mathrm{d}V=\frac{r}{r^{3}}4\pi r^{2}=4\pi $$ 

683 数学上，我们用 δ 函数来表达类似于 ∇· $ \frac{\vec{r}}{r^{3}} $ 的函数，三维空间中的 δ 函数定义如下：

 $$ \delta(\vec{\boldsymbol{r}})=\begin{cases}0,&\vec{\boldsymbol{r}}\neq0,\\\infty,&\vec{\boldsymbol{r}}=0.\end{cases} $$ 

684 且：

 $$ \iiint_{\mathrm{all-space}}\delta(\vec{\boldsymbol{r}})\mathrm{d}V=1 $$ 

685  $ \delta $ 函数还有一个筛分性，即：

 $$ \iiint_{\mathrm{all-space}}f(\vec{\boldsymbol{r}})\delta(\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}_{0})\mathrm{d}^{3}\vec{\boldsymbol{r}}=f(\vec{\boldsymbol{r}}_{0}) $$ 

686 因此， $ \nabla\cdot\frac{\vec{r}}{r^{3}} $ 也可以写成：

 $$ \nabla\cdot\frac{\vec{r}}{r^{3}}=4\pi\delta(\vec{r}) $$ 

687 现在，我们再回到电场的散度，即2.50式，该式可以写成：

 $$ \nabla\cdot\vec{E}(\vec{r})=\frac{1}{4\pi\varepsilon_{0}}\sum_{i=1}^{N}q_{i}\nabla\cdot\frac{\vec{r}-\vec{r}_{i}}{|\vec{r}-\vec{r}_{i}|^{3}}=\frac{1}{4\pi\varepsilon_{0}}\sum_{i=1}^{N}q_{i}4\pi\delta(\vec{r}-\vec{r}_{i})=\sum_{i=1}^{N}\frac{q_{i}}{\varepsilon_{0}}\delta(\vec{r}-\vec{r}_{i}) $$ 