394 1.9: 利用习题1.7得到的  $ \nabla $ 算符在球坐标系中的表达式，证明：在球坐标系中，标量场  $ \Phi $ 的梯度，矢量场  $ \vec{F} = F_r \hat{r} + F_\theta \hat{\theta} + F_\phi \hat{\phi} $ 的散度和旋度分别为：

 $$ \begin{aligned}\nabla\Phi&=\hat{\boldsymbol{r}}\frac{\partial\Phi}{\partial r}+\hat{\boldsymbol{\theta}}\frac{1}{r}\frac{\partial\Phi}{\partial\theta}+\hat{\phi}\frac{1}{r\sin\theta}\frac{\partial\Phi}{\partial\phi}\\\nabla\cdot\vec{\boldsymbol{F}}&=\frac{1}{r^{2}}\frac{\partial(r^{2}F_{r})}{\partial r}+\frac{1}{r\sin\theta}\frac{\partial(F_{\theta}\sin\theta)}{\partial\theta}+\frac{1}{r\sin\theta}\frac{\partial F_{\phi}}{\partial\phi}\\\nabla\times\vec{\boldsymbol{F}}&=\hat{\boldsymbol{r}}\frac{1}{r\sin\theta}\Big(\frac{\partial(F_{\phi}\sin\theta)}{\partial\theta}-\frac{\partial F_{\theta}}{\partial\phi}\Big)+\hat{\boldsymbol{\theta}}\frac{1}{r}\Big(\frac{1}{\sin\theta}\frac{\partial F_{r}}{\partial\phi}-\frac{\partial(rF_{\phi})}{\partial r}\Big)+\hat{\phi}\frac{1}{r}\Big(\frac{\partial(rF_{\theta})}{\partial r}-\frac{\partial F_{r}}{\partial\theta}\Big)\end{aligned} $$ 

396 1.10: 某标量场 U 在球坐标系下的表达式为： $ U(\vec{r})=\frac{1}{r} $

求： $ \nabla U, \nabla \times (\nabla U) \quad (r \neq 0) $

1.11: 某矢量场  $ \vec{F} $ 在柱坐标系下的表达式为： $ \vec{F}(\vec{r}) = \frac{\phi}{r} $

求： $ \nabla \cdot \vec{F} $， $ \nabla \times \vec{F} $ ( $ r \neq 0 $)

1.12: 某矢量场  $ \vec{F} $ 在直角坐标系下的表达式为： $ \vec{F}(x,y,z) = y\hat{x} - x\hat{y} $

画出  $ \vec{F} $ 在 x-y 平面上的场线，并求： $ \nabla \cdot \vec{F} $， $ \nabla \times (\vec{F}) $

1.13: 证明以下链式法则 ( $ \phi $ 为标量场):

 $$ \nabla\cdot(\phi\vec{\mathbf{a}})=\phi\nabla\cdot\vec{\mathbf{a}}+(\nabla\phi)\cdot\vec{\mathbf{a}} $$ 

 $$ \nabla\times(\phi\vec{\boldsymbol{a}})=(\nabla\phi)\times\vec{\boldsymbol{a}}+\phi(\nabla\times\vec{\boldsymbol{a}}) $$ 

1.14: 计算面积分  $ \iint_{S}(x-2y+z)dS $，其中 S 是曲面  $ z=4-x $ ( $ 0\leq x\leq4 $,  $ 0\leq y\leq3 $)。

1.15: 计算线积分  $ \int_{C}(y-x)\mathrm{d}x+(2x-y)\mathrm{d}y $，其中 C 是抛物线  $ y=x^{2}-2x\left(0\leq x\leq3\right) $。