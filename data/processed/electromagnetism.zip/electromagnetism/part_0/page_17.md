224 解:

如右图所示，可知  $ \vec{dS} $ 与  $ \vec{r} $ 相同，其大小为：



 $$ \mathrm{d}S=\left|\mathrm{d}\vec{r}_{1}\times\mathrm{d}\vec{r}_{2}\right|=(r\mathrm{d}\theta)(r\sin\theta\mathrm{d}\phi)=r^{2}\sin\theta\mathrm{d}\theta\mathrm{d}\phi $$ 

因此，球坐标系中的球面的面元为：

 $$ \mathrm{d}\vec{S}=\hat{\boldsymbol{r}}r^{2}\sin\theta\mathrm{d}\theta\mathrm{d}\phi $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_745_226_1046_502.jpg" alt="Image" width="25%" /></div>


此外，也可以直接通过球面的参数方程求解：首先，我们已知球面的参数方程为：

 $$ \vec{r}(\theta,\phi)=(r\sin\theta\cos\phi,r\sin\theta\sin\phi,r\cos\theta) $$ 

226 将  $ \vec{r} $ 对  $ \theta $ 和  $ \phi $ 求偏导，可得：

 $$ \frac{\partial\vec{r}}{\partial\theta}=\left(r\cos\theta\cos\phi,r\cos\theta\sin\phi,-r\sin\theta\right) $$ 

 $$ \frac{\partial\vec{\mathbf{r}}}{\partial\phi}=(-r\sin\theta\sin\phi,r\sin\theta\cos\phi,0) $$ 

227 因而：

 $$ \begin{aligned}\vec{\mathbf{S}}&=\frac{\partial\vec{\mathbf{r}}}{\partial\theta}\times\frac{\partial\vec{\mathbf{r}}}{\partial\phi}\mathrm{d}\theta\mathrm{d}\phi\\&=(r\cos\theta\cos\phi,r\cos\theta\sin\phi,-r\sin\theta)\times(-r\sin\theta\sin\phi,r\sin\theta\cos\phi,0)\mathrm{d}\theta\mathrm{d}\phi\\&=(r^{2}\sin^{2}\theta\cos\phi,r^{2}\sin^{2}\theta\sin\phi,r^{2}\sin\theta\cos\theta\cos^{2}\phi+r^{2}\sin\theta\cos\theta\sin^{2}\phi)\mathrm{d}\theta\mathrm{d}\phi\\&=r^{2}\sin\theta(\sin\theta\cos\phi,\sin\theta\sin\phi,\cos\theta)\mathrm{d}\theta\mathrm{d}\phi\\&=\hat{\mathbf{r}}r^{2}\sin\theta\mathrm{d}\theta\mathrm{d}\phi\\ \end{aligned} $$ 

228 面积分在物理学中有很多应用，以电磁学中常用的电流的概念为例：我们熟知的电流的定义是单位时间通过某一截面的总电荷量：

 $$ I=\frac{\mathrm{d}Q}{\mathrm{d}t} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_337_1346_861_1529.jpg" alt="Image" width="43%" /></div>
