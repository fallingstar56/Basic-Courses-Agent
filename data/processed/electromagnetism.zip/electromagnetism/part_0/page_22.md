283 我们再把  $ d\vec{r} $ 改成等势面的法线方向，那么我们知道：

 $$ \mathrm{d}U=\nabla U\cdot\mathrm{d}\vec{r}=|\nabla U||\mathrm{d}\vec{r}| $$ 

284 即：此时  $ |\nabla U| = \frac{\mathrm{d}U}{|\mathrm{d}\vec{r}|} $，也就是说， $ \nabla U $ 的大小，等于 U 在等势面法向方向的导数。

在第1.2节学习线积分的时候，我们提到了保守力的概念：即如果一个力对质点做的功与质点的运动路径无关，那么我们就把这个力称为保守力。保守力的概念可以延伸到一般的矢量场，即如果一个矢量场  $ \vec{F} $ 的线积分与从起点到终点的具体路径无关，那么我们把这种矢量场称为保守场。关于保守场，我们还有一个定理，即：

### 定理 1.1 梯度定理

如果一个矢量场  $ \vec{F} $ 可以写成一个标量场的梯度  $ \vec{F} = \nabla \Phi $，那么这个矢量场  $ \vec{F} $ 是保守场。

290 证明：

取空间中的任意两点 A 和 B，如果  $ \vec{F} $ 可以写成  $ \vec{F} = \nabla \Phi $，那么  $ \vec{F} $ 从 A 到 B 沿某一路径 C 的线积分为：

 $$ \int_{C}\vec{F}\cdot\mathrm{d}\vec{r}=\int_{C}\nabla\Phi\cdot\mathrm{d}\vec{r}=\int_{C}\mathrm{d}\Phi=\Phi(B)-\Phi(A) $$ 

293 可知，该线积分的值  $ \Phi(B) - \Phi(A) $ 只与 A 点和 B 点的  $ \Phi $ 值之差有关，与从 A 到 B 取哪条路径无关，因此  $ \vec{F} $ 是保守场。

实际上，上述定理反过来说也是成立的（梯度定理的逆定理），即：如果  $ \vec{F} $ 是一个保守场，那  $ \vec{F} $ 一定可以写成一个标量场的梯度的形式  $ \vec{F} = \nabla \Phi $。证明很简单，因为当  $ \vec{F} $ 是保守场时，我们可以这样定义  $ \Phi(\vec{r}) $：

 $$ \Phi(\vec{r})=\int_{C}\vec{F}\cdot\mathrm{d}\vec{r} $$ 

298 其中 C 是从原点到  $ \vec{r} $ 的任意一条曲线，由于  $ \vec{F} $ 是保守场，所以上述  $ \Phi(\vec{r}) $ 的值与具体路径无关，是唯一定义的。因此，根据积分的定义，我们有：

 $$ \mathrm{d}\Phi(\vec{r})=\vec{F}\cdot\mathrm{d}\vec{r} $$ 

300 同时，根据上面关于梯度的定义，我们有：

 $$ \mathrm{d}\Phi(\vec{r})=\nabla\Phi\cdot\mathrm{d}\vec{r} $$ 

301 结合上述两式，可知：

 $$ \vec{F}\cdot\mathrm{d}\vec{r}=\nabla\Phi\cdot\mathrm{d}\vec{r} $$ 

302 且上式对任意  $ d\vec{r} $ 都是成立的，因而  $ \vec{F} = \nabla \Phi $。