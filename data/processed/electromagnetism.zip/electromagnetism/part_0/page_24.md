321 以图中相对的两个面  $ \vec{S}_{1} $ 和  $ \vec{S}_{2} $ 为例， $ \vec{F} $ 在这两个面上的通量之和为：

 $$ \begin{aligned}\iint_{\vec{S}_{1}+\vec{S}_{2}}\vec{F}\cdot\mathrm{d}\vec{S}&=\vec{F}(x+\frac{\mathrm{d}x}{2},y,z)\cdot\vec{S}_{1}+\vec{F}(x-\frac{\mathrm{d}x}{2},y,z)\cdot\vec{S}_{2}\\&=F_{x}(x+\frac{\mathrm{d}x}{2},y,z)\mathrm{d}y\mathrm{d}z-F_{x}(x-\frac{\mathrm{d}x}{2},y,z)\mathrm{d}y\mathrm{d}z\\&=\left[F_{x}(x+\frac{\mathrm{d}x}{2},y,z)-F_{x}(x-\frac{\mathrm{d}x}{2},y,z)\right]\mathrm{d}y\mathrm{d}z\\&=\left[\frac{\partial F_{x}}{\partial x}\mathrm{d}x\right]\mathrm{d}y\mathrm{d}z\\&=\frac{\partial F_{x}}{\partial x}\mathrm{d}V\end{aligned} $$ 

322 同理可得，前后和上下两个面的  $ \vec{F} $ 的通量之和将分别为  $ \frac{\partial F_{y}}{\partial y}dV $ 和  $ \frac{\partial F_{z}}{\partial z}dV $，因此， $ \vec{F} $ 在该长方体的六个表面组成的闭合曲面 S 上的总通量为：

 $$ \begin{aligned}\oint_{S}\vec{F}\cdot\mathrm{d}\vec{S}&=\frac{\partial F_{x}}{\partial x}\mathrm{d}V+\frac{\partial F_{y}}{\partial y}\mathrm{d}V+\frac{\partial F_{z}}{\partial z}\mathrm{d}V\\&=\left(\frac{\partial F_{x}}{\partial x}+\frac{\partial F_{y}}{\partial y}+\frac{\partial F_{z}}{\partial z}\right)\mathrm{d}V\\&=(\nabla\cdot\vec{F})\mathrm{d}V\end{aligned} $$ 

324 因此，1.58式关于  $ \vec{F} $ 的散度的定义可以写成：

 $$ \begin{aligned}\mathrm{div}\vec{F}&=\lim_{\mathrm{d}V\rightarrow0}\frac{\oint_{S}\vec{F}\cdot\mathrm{d}\vec{S}}{\mathrm{d}V}\\&=\lim_{\mathrm{d}V\rightarrow0}\frac{(\nabla\cdot\vec{F})\mathrm{d}V}{\mathrm{d}V}\\&=\nabla\cdot\vec{F}\end{aligned} $$ 

325 这就得到了1.57式关于  $ \vec{F} $ 的散度的定义。

326 上面的关于散度的两种定义以及证明过程也告诉我们，对于足够小的体积 V 以及其外表面对应的闭合曲面 S，我们有下面等式：

 $$ \lim_{V\to0}\left(\iint_{S}\vec{F}\cdot\mathrm{d}\vec{S}-\iiint_{V}\nabla\cdot\vec{F}\mathrm{d}V\right)=0 $$ 

328 实际上，上面这个等式对于任意大小的体积及其外表面对应的闭合曲面都是成立的，而这一结论也被称为高斯定理：