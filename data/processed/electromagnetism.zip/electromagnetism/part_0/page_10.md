<div style="text-align: center;"><img src="imgs/img_in_image_box_237_150_592_475.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_616_151_954_455.jpg" alt="Image" width="28%" /></div>


在电磁学的计算中，很重要的一点是根据物理量分布的特征，选取相应的坐标系以及合适的原点，有时候利用对称性和相应的坐标系可以减少变量，方程从三维变成一维。比如，研究有球对称性的物理体系（如点电荷），显然使用球坐标系更为方便。

 $$ \vec{a}=r\hat{\mathbf{r}}+\theta\hat{\boldsymbol{\theta}}+\phi\hat{\boldsymbol{\phi}} $$ 

 $$ \vec{a}=r\hat{\mathbf{r}}+\phi\hat{\boldsymbol{\phi}}+z\hat{\mathbf{z}} $$ 

物理上矢量的计算法则和数学中的向量的计算法则是一致的，常用的有：

#### 1.1.2 常见矢量计算公式

1. 矢量  $ \vec{r} $ 的模： $ |\vec{r}| = r = \sqrt{r_{x}^{2} + r_{y}^{2} + r_{z}^{2}} $

2. 单位矢量:  $ \hat{r} = \frac{\vec{r}}{|\vec{r}|} $

3. 矢量的加法遵循平行四边形法则和三角形法则，满足交换律和结合律

4. 矢量的减法可以看成是一个矢量加上与另一个矢量方向相反的矢量

5. 矢量的点乘： $ \vec{a} \cdot \vec{b} = |\vec{a}||\vec{b}|\cos\theta = a_x b_x + a_y b_y + a_z b_z $，其中  $ |\vec{a}|\cos\theta $ 可以理解为矢量  $ \vec{a} $ 在矢量  $ \vec{b} $ 方向上的投影长度；点乘满足交换律和分配律

6. 矢量的叉乘： $ \vec{c} = \vec{a} \times \vec{b} $，叉乘的结果是一个矢量，其中  $ \vec{c} $ 的方向垂直于  $ \vec{a} $ 与  $ \vec{b} $ 所在的平面（右手定则）， $ \vec{c} $ 的大小可以理解为当  $ \vec{a} $ 和  $ \vec{b} $ 始于相同点时它们所张成的平行四边形的面积（ $ |\vec{c}| = |\vec{a}| |\vec{b}| \sin \theta $）；叉乘满足分配律；在正交的坐标系（如直角坐标系、柱坐标系、球坐标系）中矢量的叉乘计算方法如下（ $ \hat{i}, \hat{j}, \hat{k} = \hat{x}, \hat{y}, \hat{z}/\hat{r}, \hat{\phi}, \hat{z}/\hat{r}, \hat{\theta}, \hat{\phi} $）：

 $$ \hat{\boldsymbol{i}}\times\hat{\boldsymbol{j}}=\hat{\boldsymbol{k}},\hat{\boldsymbol{j}}\times\hat{\boldsymbol{k}}=\hat{\boldsymbol{i}},\hat{\boldsymbol{k}}\times\hat{\boldsymbol{i}}=\hat{\boldsymbol{j}} $$ 

 $$ \begin{aligned}\vec{c}&=\vec{a}\times\vec{b}=(a_{i}\hat{i}+a_{j}\hat{j}+a_{k}\hat{k})\times(b_{i}\hat{i}+b_{j}\hat{j}+b_{k}\hat{k})\\&=(a_{j}b_{k}-a_{k}b_{j})\hat{i}+(a_{k}b_{i}-a_{i}b_{k})\hat{j}+(a_{i}b_{j}-a_{j}b_{i})\hat{k}\end{aligned} $$ 

7. 三个矢量的混合积/三重积： $ \vec{a} \cdot (\vec{b} \times \vec{c}) $，其结果是一个标量，该值可以理解为  $ \vec{a} $、 $ \vec{b} $ 和