2. 柱坐标系：

 $$ \vec{r}=(r\cos\phi,r\sin\phi,z) $$ 

 $$ \frac{\partial\vec{\mathbf{r}}}{\partial r}=(\cos\phi,\sin\phi,0) $$ 

 $$ \frac{\partial\vec{r}}{\partial\phi}=(-r\sin\phi,r\cos\phi,0) $$ 

 $$ \frac{\partial\vec{\bf r}}{\partial z}=(0,0,1) $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_665_170_979_453.jpg" alt="Image" width="26%" /></div>


 $$ \begin{aligned}\mathrm{d}V=&\frac{\partial\vec{r}}{\partial r}\cdot\left(\frac{\partial\vec{r}}{\partial\phi}\times\frac{\partial\vec{r}}{\partial z}\right)\mathrm{d}r\mathrm{d}\phi\mathrm{d}z\\=&(\cos\phi,\sin\phi,0)\cdot\left((-r\sin\phi,r\cos\phi,0)\times(0,0,1)\right)\mathrm{d}r\mathrm{d}\phi\mathrm{d}z\\=&(\cos\phi,\sin\phi,0)\cdot(r\cos\phi,r\sin\phi,0)\mathrm{d}r\mathrm{d}\phi\mathrm{d}z\\=&r\mathrm{d}r\mathrm{d}\phi\mathrm{d}z\end{aligned} $$ 

260 当然我们也可以通过上面右侧的示意图直观地得出  $ dV = rdrd\phi dz $ 的结论。

### 3. 球坐标系：

<div style="text-align: center;"><img src="imgs/img_in_image_box_292_967_975_1257.jpg" alt="Image" width="57%" /></div>


 $$ \begin{aligned}\vec{r}=&(r\sin\theta\cos\phi,r\sin\theta\sin\phi,r\cos\theta)\\\frac{\partial\vec{r}}{\partial r}=&(\sin\theta\cos\phi,\sin\theta\sin\phi,\cos\theta)\\\frac{\partial\vec{r}}{\partial\theta}=&(r\cos\theta\cos\phi,r\cos\theta\sin\phi,-r\sin\theta)\\\frac{\partial\vec{r}}{\partial\phi}=&(-r\sin\theta\sin\phi,r\sin\theta\cos\phi,0)\end{aligned} $$ 

 $$ \begin{aligned}\mathrm{d}V=&\frac{\partial\vec{r}}{\partial r}\cdot\left(\frac{\partial\vec{r}}{\partial\theta}\times\frac{\partial\vec{r}}{\partial\phi}\right)\mathrm{d}r\mathrm{d}\theta\mathrm{d}\phi\\=&(\sin\theta\cos\phi,\sin\theta\sin\phi,\cos\theta)\cdot\\&\left((r\cos\theta\cos\phi,r\cos\theta\sin\phi,-r\sin\theta)\times(-r\sin\theta\sin\phi,r\sin\theta\cos\phi,0)\right)\mathrm{d}r\mathrm{d}\phi\mathrm{d}z\\=&r^{2}\sin\theta\mathrm{d}r\mathrm{d}\theta\mathrm{d}\phi\end{aligned} $$ 

同样的，我们也可以通过上面右侧的示意图直观地得出  $  \mathrm{d}V = r^2 \sin \theta \, \mathrm{d}r \, \mathrm{d}\theta \, \mathrm{d}\phi  $ 的结论。