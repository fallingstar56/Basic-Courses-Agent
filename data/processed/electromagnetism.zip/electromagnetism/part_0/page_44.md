615 根据上述结果可知，当  $ z \gg R $ 时，电场可以近似为：

 $$ E\approx\frac{q}{4\pi\varepsilon_{0}z^{2}} $$ 

616 即这种情况下变成了点电荷的电场。

617

### 例 2.7

求如图所示的均匀带电圆盘（半径 R，面电荷密度  $ \sigma_{e} $）在其轴线上任意一点  $ P(z) $ 处的电场强度。

<div style="text-align: center;"><img src="imgs/img_in_image_box_749_349_1031_518.jpg" alt="Image" width="23%" /></div>


解:

618 如图所示，可以将带电圆盘切成很多带电圆环，利用上一例题的结果，可知半径为 r 宽度为 dr 的圆环上的电荷在 P 点产生的电场强度为：

 $$ \begin{aligned}\mathrm{d}E&=\frac{z\mathrm{d}q}{4\pi\varepsilon_{0}(r^{2}+z^{2})^{3/2}}\\&=\frac{z\sigma_{e}2\pi r\mathrm{d}r}{4\pi\varepsilon_{0}(r^{2}+z^{2})^{3/2}}\\&=\frac{z\sigma_{e}r\mathrm{d}r}{2\varepsilon_{0}(r^{2}+z^{2})^{3/2}}\end{aligned} $$ 

620 因此，P 点的电场强度为：

 $$ \begin{aligned}E&=\frac{z\sigma_{e}}{2\varepsilon_{0}}\int_{0}^{R}\frac{r\mathrm{d}r}{(r^{2}+z^{2})^{3/2}}\\&=\frac{z\sigma_{e}}{2\varepsilon_{0}}\frac{-1}{\sqrt{r^{2}+z^{2}}}\bigg|_{0}^{R}\\&=\frac{\sigma_{e}}{2\varepsilon_{0}}\bigg(1-\frac{z}{\sqrt{z^{2}+R^{2}}}\bigg)\end{aligned} $$ 

621 由上述结果可知：

1. 当  $ z \ll R $ 时:

 $$ E\approx\frac{\sigma_{e}}{2\varepsilon_{0}} $$ 

这种情况相当于无穷大带电平板产生的电场，其电场强度与 z 无关（即： $ E \propto z^{0} $）。

2. 当  $ z \gg R $ 时:

 $$ E\approx\frac{\sigma_{e}}{2\varepsilon_{0}}\left[1-\left[1-\frac{1}{2}(\frac{R}{z})^{2}\right]\right]=\frac{\pi R^{2}\sigma_{e}}{4\pi\varepsilon_{0}z^{2}}=\frac{q}{4\pi\varepsilon_{0}z^{2}} $$ 

即这种情况下变成了点电荷的电场。