607 通过泰勒展开只保留 l/r 的一次项，可得：

 $$ \begin{aligned}\vec{E}(\vec{r})&=\frac{q\vec{l}}{4\pi\varepsilon_{0}r^{3}}\left[\frac{-1}{(1+\frac{l}{2r})^{3}}+\frac{1}{(1-\frac{l}{2r})^{3}}\right]\\&=\frac{q\vec{l}}{4\pi\varepsilon_{0}r^{3}}\left[-\left(1-\frac{3l}{2r}\right)+\left(1+\frac{3l}{2r}\right)\right]\\&=\frac{q\vec{l}}{4\pi\varepsilon_{0}r^{3}}\frac{3l}{r}\\&=\frac{3q l^{2}\hat{l}}{4\pi\varepsilon_{0}r^{4}}\end{aligned} $$ 

608 可见，电四极子产生的电场随空间成  $ r^{-4} $ 的速度衰减，比电偶极子的衰减更快。

609

例 2.6

求如图所示的均匀带电细圆环（半径 R，总电荷 q）在其轴线上任意一点  $ P(z) $ 处的电场强度。

<div style="text-align: center;"><img src="imgs/img_in_image_box_751_560_1031_717.jpg" alt="Image" width="23%" /></div>


解:

如图所示，把带电圆环分成无限多点电荷 dq，设 dq 在 P 点产生的电场强度为 dE。由对称性，所有的 dE⊥ 相互抵消，P 点的电场只剩下各 dE∥ 之和：



 $$ E=\int\mathrm{d}E_{||} $$ 

612 其中，

 $$ \begin{aligned}\mathrm{d}E_{\parallel}&=\mathrm{d}E\cos\theta\\&=\frac{1}{4\pi\varepsilon_{0}}\frac{\mathrm{d}q}{r^{2}}\frac{z}{r}\end{aligned} $$ 

613 定义线电荷密度  $ \lambda_{e}=\frac{q}{2\pi R} $，上式中  $ r=\sqrt{R^{2}+z^{2}} $，代入上式可得：

 $$ \mathrm{d}E_{\parallel}=\frac{1}{4\pi\varepsilon_{0}}\frac{\lambda_{e}\mathrm{d}l}{R^{2}+z^{2}}\frac{z}{\sqrt{R^{2}+z^{2}}} $$ 

614 因此，

 $$ \begin{aligned}E&=\int\mathrm{d}E_{\parallel}=\int_{0}^{2\pi R}\frac{1}{4\pi\varepsilon_{0}}\frac{\lambda_{e}}{R^{2}+z^{2}}\frac{z}{\sqrt{R^{2}+z^{2}}}\mathrm{d}l\\&=\frac{2\pi R\lambda_{e}z}{4\pi\varepsilon_{0}(R^{2}+z^{2})^{3/2}}\\&=\frac{qz}{4\pi\varepsilon_{0}(R^{2}+z^{2})^{3/2}}\\ \end{aligned} $$ 