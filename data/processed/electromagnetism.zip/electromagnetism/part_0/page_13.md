175 平面上的以原点为中心，半径为 1 的圆可以写成如下参数方程：

 $$ x=\cos(\theta),\quad y=\sin(\theta),\quad z=0;\quad\theta:[0,2\pi] $$ 

176 利用曲线的参数方程，上述线积分也可以写成关于参数 t 的一个普通积分，为此，我们可以将 177 切向向量  $ \vec{d}\vec{r} $ 写成：

 $$ \mathrm{d}\vec{\boldsymbol{r}}=\frac{\mathrm{d}\vec{\boldsymbol{r}}(t)}{\mathrm{d}t}\mathrm{d}t=\vec{\boldsymbol{r}}^{\prime}(t)\mathrm{d}t $$ 

 $$ \mathrm{d}s=|\mathrm{d}\vec{\boldsymbol{r}}|=|\vec{\boldsymbol{r}}^{\prime}(t)|\mathrm{d}t $$ 

178 因此，上述标量场和矢量场的线积分就可以写成如下关于参数 t 的普通积分：

 $$ \int_{C}f(\vec{\boldsymbol{r}})\mathrm{d}s=\int_{t_{0}}^{t_{1}}f(\vec{\boldsymbol{r}}(t))|\vec{\boldsymbol{r}}^{\prime}(t)|\mathrm{d}t $$ 

 $$ \int_{C}\vec{\pmb{f}}(\vec{\pmb{r}})\cdot\mathrm{d}\vec{\pmb{r}}=\int_{t_{0}}^{t_{1}}\vec{\pmb{f}}(\vec{\pmb{r}}(t))\cdot\vec{\pmb{r}}^{\prime}(t)\mathrm{d}t $$ 

179 矢量场的线积分在物理学中非常常见，比如已知质点受到的某个外力随空间的变化（即外力场） $ \vec{F}(\vec{r}) $，则当质点沿着某一特定曲线 C 运动时，外力  $ \vec{F}(\vec{r}) $ 做的功可以写成：

 $$ W=\int_{C}\vec{F}(\vec{r})\cdot\mathrm{d}\vec{r} $$ 

181 例 1.1

质点沿如下螺旋线 C 运动  $ (t:0\rightarrow1) $:

 $$ x(t)=\cos(t),\quad y(t)=\sin(t),\quad z(t)=t $$ 

183 质点受到的力  $ \vec{F} $ 在各个方向上的分量的大小为：

 $$ F_{x}=y,\quad F_{y}=x,\quad F_{z}=z $$ 

184 求在此过程中力  $ \vec{F} $ 做的功（上述物理量的单位全部取国际单位制）。