### 1.3 梯度、散度和旋度

在电磁学中，我们经常要分析场随时间和空间的变化，其中时间是个标量，场随时间的变化可以直接使用常见的对时间求微分来计算，比如，对于一个矢量场  $ \vec{f}(\vec{r},t) $，它对时间的微分为：

 $$ \frac{\mathrm{d}\vec{f}}{\mathrm{d}t}=\frac{\mathrm{d}f_{x}}{\mathrm{d}t}\hat{\boldsymbol{x}}+\frac{\mathrm{d}f_{y}}{\mathrm{d}t}\hat{\boldsymbol{y}}+\frac{\mathrm{d}f_{z}}{\mathrm{d}t}\hat{\boldsymbol{z}} $$ 

电磁学里更有趣的是场随空间的变化，由于三维空间有三个自由度 x, y, z，因此，需要分别研究场在三个不同方向  $ \hat{x}, \hat{y}, \hat{z} $ 的变化，接下来我们将讨论如何分析标量场和矢量场随着空间的变化情况。

#### 1.3.1 梯度

对于标量场  $ U(\vec{r}) $，如果我们把它在三个方向的变化放到一起组成一个矢量，则我们便可以定义一个新的量，我们称之为标量场  $ U(\vec{r}) $ 的梯度（gradient）：

 $$ \nabla U=\hat{\mathbf{x}}\frac{\partial U}{\partial x}+\hat{\mathbf{y}}\frac{\partial U}{\partial y}+\hat{z}\frac{\partial U}{\partial z} $$ 

其中  $ \nabla $ 为矢量算符 (Nabla 算符):

 $$ \nabla=(\frac{\partial}{\partial x},\frac{\partial}{\partial y},\frac{\partial}{\partial z}) $$ 

下面我们来分析一下梯度的物理含义，即它的大小和方向分别包含什么信息。通过微积分里的全微分（泰勒展开），我们知道，一个标量场 U 在  $ \vec{r} = (x, y, z) $ 处沿  $ \mathrm{d}\vec{r} = (\mathrm{d}x, \mathrm{d}y, \mathrm{d}z) $ 的变化（即  $ U(\vec{r} + \mathrm{d}\vec{r}) - U(\vec{r}) $）为：

 $$ \mathrm{d}U=\frac{\partial U}{\partial x}\mathrm{d}x+\frac{\partial U}{\partial y}\mathrm{d}y+\frac{\partial U}{\partial z}\mathrm{d}z $$ 

278 上式也可写成：

 $$ \begin{aligned}\mathrm{d}U&=(\frac{\partial U}{\partial x},\frac{\partial U}{\partial y},\frac{\partial U}{\partial z})\cdot(\mathrm{d}x,\mathrm{d}y,\mathrm{d}z)\\&=\nabla U\cdot\mathrm{d}\vec{r}\end{aligned} $$ 

79 我们不妨在标量场的等势面上（即  $ U(x,y,z) = \text{constant} $ 的点所组成的平面）处取一点  $ \vec{r} $ 以及该点沿着等势面的切线  $ \mathrm{d}\vec{r} $，由于  $ \mathrm{d}\vec{r} $ 沿着等势面的切线，因此 U 沿着  $ \mathrm{d}\vec{r} $ 的变化为 0，即  $ 81 \mathrm{~d}U = U(\vec{r} + \mathrm{d}\vec{r}) - U(r) = 0 $，从而有：

 $$ \nabla U\cdot\mathrm{d}\vec{r}=0 $$ 

282 也就是说，∇U 的方向与等势面的切线方向垂直，即：∇U 的方向平行于等势面的法向。现在，