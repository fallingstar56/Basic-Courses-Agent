595 代入2.18可得：

 $$ \begin{aligned}\vec{E}(\vec{r})&=\frac{q}{4\pi\varepsilon_{0}r^{3}}\bigg[\vec{r}_{+}\bigg(1+\frac{3}{2}\frac{\vec{r}\cdot\vec{l}}{r^{2}}\bigg)-\vec{r}_{-}\bigg(1-\frac{3}{2}\frac{\vec{r}\cdot\vec{l}}{r^{2}}\bigg)\bigg]\\&=\frac{q}{4\pi\varepsilon_{0}r^{3}}\bigg[(\vec{r}_{+}-\vec{r}_{-})+(\vec{r}_{+}+\vec{r}_{-})\frac{3}{2}\frac{\vec{r}\cdot\vec{l}}{r^{2}}\bigg]\end{aligned} $$ 

596 其中， $ \vec{r}_{+}-\vec{r}_{-}=-\vec{l},\vec{r}_{+}+\vec{r}_{-}=2\vec{r} $，因此：

 $$ \begin{aligned}\vec{E}(\vec{r})&=\frac{q}{4\pi\varepsilon_{0}r^{3}}\bigg[-\vec{l}+3(\frac{\vec{r}\cdot\vec{l}}{r^{2}})\vec{r}\bigg]\\&=\frac{-\vec{p}+3(\hat{\boldsymbol{r}}\cdot\vec{p})\hat{\boldsymbol{r}}}{4\pi\varepsilon_{0}r^{3}}\end{aligned} $$ 

上述结果分两部分，第一部分与  $ \vec{l} $ 平行，是横向场，第二部分与  $ \vec{r} $ 平行，是径向场。

• 当 P 点位于电偶极子的中垂线上时，径向场等于零，2.24式可化简为：

 $$ \vec{E}(\vec{r})=\frac{-\vec{p}}{4\pi\varepsilon_{0}r^{3}} $$ 

这与上一节中例2.3计算得出的结果是一致的。

• 当 P 点位于电偶极子的连线上时，2.24式可化简为

 $$ \vec{E}(\vec{r})=\frac{2\vec{p}}{4\pi\varepsilon_{0}r^{3}} $$ 

自然界中有很多带电体系都可以看成是电偶极子模型，比如有很多分子（或原子）的电子的重心与原子核并不重合，因而正负电荷中心不重合，这种情况下该分子（或原子）就可以看成一个电偶极子，它们会产生电偶极场，我们把它们称为有极分子（或有极原子），由于电偶极场的存在它们会更容易“亲和”（溶解）其他有极分子（或有极原子）。关于有极分子（或有极原子）在本书后面第四章我们还会进一步讨论。

606

### 例 2.5

求如图所示的电四极子在远点  $ P(\vec{r}) $ 处  $ (r \gg l) $ 产生的电场  $ \vec{E}(\vec{r}) $。

解:

该电四极子产生的电场可以看成是两个电偶极子产生的电场的矢量和，使用上一个例题的结论，可得：

 $$ \begin{aligned}\vec{E}(\vec{r})&=\vec{E}_{1}(\vec{r})+\vec{E}_{2}(\vec{r})\\&=\frac{1}{4\pi\varepsilon_{0}}\bigg[\frac{-q\vec{l}}{(r+\frac{l}{2})^{3}}+\frac{q\vec{l}}{(r-\frac{l}{2})^{3}}\bigg]\end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_836_1213_1032_1545.jpg" alt="Image" width="16%" /></div>
