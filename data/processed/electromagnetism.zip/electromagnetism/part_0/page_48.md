### 2.4 高斯定理

661

### 2.4 高斯定理

从上一节的几个例题我们可以看出，计算带电体系产生的电场往往需要用到复杂的积分，而对于一些存在对称性的电荷分布（比如上一节例题中计算过的带电球、无穷大面电荷、无穷长线电荷等）产生的电场，我们又发现其最终计算结果往往又非常简洁且具有很强的对称性。对于这种存在对称性分布的电荷体系，本节将讨论一种极为有效的计算方法，即利用静电场的高斯定理来计算。

本章中所学习的电场，是一个矢量场，它与我们在第一章学习的一般的矢量场一样，电场 $ \vec{E} $也有线积分、面积分（即电场的通量），以及散度和旋度。本节将讨论并计算电场的通量和散度以及它们的物理意义。

670 首先我们来看一下电场的散度，即  $ \nabla \cdot \vec{E} $，由于电场的叠加原理，以及计算散度时有  $ \nabla \cdot (\vec{E}_1 + \vec{E}_2) = \nabla \cdot \vec{E}_1 + \nabla \cdot \vec{E}_2 $ 这一分配律，因此我们只需要计算点电荷的电场的散度就可以计算出任意带电体系的电场的散度：

 $$ \nabla\cdot\vec{E}(\vec{r})=\nabla\cdot\sum_{i=1}^{N}\vec{E}_{i}(\vec{r})=\sum_{i=1}^{N}\nabla\cdot\vec{E}_{i}(\vec{r})=\frac{1}{4\pi\varepsilon_{0}}\sum_{i=1}^{N}q_{i}\nabla\cdot\frac{\vec{r}-\vec{r}_{i}}{|\vec{r}-\vec{r}_{i}|^{3}} $$ 

673 或者写成连续电荷分布的积分形式：

 $$ \nabla\cdot\vec{E}(\vec{r})=\frac{1}{4\pi\varepsilon_{0}}\nabla\cdot\iiint_{V}\rho(\vec{r}_{0})\frac{\vec{r}-\vec{r}_{0}}{|\vec{r}-\vec{r}_{0}|^{3}}\mathrm{d}^{3}\vec{r}_{0}=\frac{1}{4\pi\varepsilon_{0}}\iiint_{V}\rho(\vec{r}_{0})\nabla\cdot\frac{\vec{r}-\vec{r}_{0}}{|\vec{r}-\vec{r}_{0}|^{3}}\mathrm{d}^{3}\vec{r}_{0} $$ 

最终我们需要计算的，是形如  $ \frac{\vec{r}-\vec{r}_{i}}{|\vec{r}-\vec{r}_{i}|^{3}} $ 的矢量场的散度，由于矢量场的散度与坐标系的选取无关，因此这里可以选取以  $ \vec{r}_{i} $ 为原点的坐标系进行散度的计算，即

 $$ \nabla\cdot\frac{\vec{r}-\vec{r}_{i}}{|\vec{r}-\vec{r}_{i}|^{3}}=\nabla\cdot\frac{\vec{r}}{r^{3}} $$ 

676 利用上一章里习题1.9的结论，即散度在球坐标系中的表达式：

 $$ \nabla\cdot\vec{F}=\frac{1}{r^{2}}\frac{\partial(r^{2}F_{r})}{\partial r}+\frac{1}{r\sin\theta}\frac{\partial(F_{\theta}\sin\theta)}{\partial\theta}+\frac{1}{r\sin\theta}\frac{\partial F_{\phi}}{\partial\phi} $$ 

677 可得：

 $$ \nabla\cdot\frac{\vec{r}}{r^{3}}=\frac{1}{r^{2}}\frac{\partial(r^{2}\frac{1}{r^{2}})}{\partial r}+0+0=\frac{1}{r^{2}}\times0=0\qquad(\vec{r}\neq0) $$ 

678 需要注意的是，上式  $ \nabla \cdot \frac{\vec{r}}{r^3} = 0 $ 只对  $ \vec{r} \neq 0 $ 的点成立，因为，当  $ \vec{r} = 0 $ 时，根据散度的定义：

 $$ \nabla\cdot\frac{\vec{r}}{r^{3}}=\lim_{\mathrm{d}V\rightarrow0}\frac{\oint_{\vec{S}}\frac{\vec{r}}{r^{3}}\cdot\mathrm{d}\vec{S}}{\mathrm{d}V} $$ 