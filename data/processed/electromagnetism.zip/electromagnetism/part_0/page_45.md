626

### 例 2.8

求如图所示的均匀带电细线（长度 l，线电荷密度  $ \lambda_{e} $）在其中垂线上  $ P(r) $ 点产生的电场强度。

解:

如图，将电荷分成无限多点电荷  $ \lambda dx $ 。由对称性可知，P 点水平方向电场强度为 0，竖直方向的电场强度为：

 $$ \mathrm{d}E=2\mathrm{d}E_{1}\cos\theta=2\frac{\lambda_{e}\mathrm{d}x}{4\pi\varepsilon_{0}r^{\prime2}}\frac{r}{r^{\prime}} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_752_171_1028_514.jpg" alt="Image" width="23%" /></div>


其中， $ r'=\sqrt{r^{2}+x^{2}} $，因此：

 $$ E=\int\mathrm{d}E=\frac{2\lambda_{e}r}{4\pi\varepsilon_{0}}\int_{0}^{l/2}\frac{\mathrm{d}x}{(x^{2}+r^{2})^{3/2}} $$ 

令  $ x = r \tan \theta $，则  $ \mathrm{d}x = \frac{r \mathrm{d}\theta}{\cos^{2}\theta} $，上述积分可化为：

 $$ \begin{aligned}E&=\frac{2\lambda_{e}r}{4\pi\varepsilon_{0}}\int_{0}^{\arctan(l/2r)}\frac{r}{\cos^{2}\theta}\frac{\cos^{3}\theta}{r^{3}}\mathrm{d}\theta\\&=\frac{2\lambda_{e}r}{4\pi\varepsilon_{0}}\int_{0}^{\arctan(l/2r)}\frac{\cos\theta}{r^{2}}\mathrm{d}\theta\\&=\frac{2\lambda_{e}r}{4\pi\varepsilon_{0}}\frac{1}{r^{2}}\sin\theta\bigg|_{0}^{\arctan(l/2r)}\\&=\frac{2\lambda_{e}r}{4\pi\varepsilon_{0}}\frac{1}{r^{2}}\frac{l}{\sqrt{4r^{2}+l^{2}}}\\&=\frac{2\lambda_{e}}{4\pi\varepsilon_{0}r}\frac{l}{\sqrt{4r^{2}+l^{2}}}\\ \end{aligned} $$ 

628 由上述结果可知：

1. 当  $ r \ll l $ 时（即无限长线电荷）：

 $$ E\approx\frac{2\lambda_{e}}{4\pi\varepsilon_{0}r} $$ 

可知，此时  $ E \propto r^{-1} $，其随距离的衰减速度比点电荷要慢。

2. 当  $ r \gg l $ 时:

 $$ E\approx\frac{2\lambda_{e}}{4\pi\varepsilon_{0}r}\frac{l}{2r}=\frac{\lambda_{e}l}{4\pi\varepsilon_{0}r^{2}}=\frac{q}{4\pi\varepsilon_{0}r^{2}} $$ 

即这种情况下变成了点电荷的电场。

从上述几个例题中，我们可以总结出几种典型的带电体系产生的电场 E 随距离 r 的关系：

1. 无限大面电荷： $ E \propto r^{0} $

2. 无限长线电荷： $ E \propto r^{-1} $

3. 点电荷： $ E \propto r^{-2} $