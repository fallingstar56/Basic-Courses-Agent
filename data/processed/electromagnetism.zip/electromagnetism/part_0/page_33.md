
<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_299_156_378_283.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_469_160_556_275.jpg" alt="Image"" /></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>甲骨文</td><td style='text-align: center; word-wrap: break-word;'>金文</td></tr><tr><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_299_319_378_439.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_457_323_568_459.jpg" alt="Image"" /></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>篆文</td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

<div style="text-align: center;"><img src="imgs/img_in_image_box_617_148_943_470.jpg" alt="Image" width="27%" /></div>


现在我们知道，闪电的发生，是由于空气中电荷的累积在局部产生很高的电势差从而击穿空气，一般来说闪电里涉及到的累积电荷量和形成的电势差远高于我们日常生活中能接触到的电荷和电压值。事实上，除去闪电这种极端的电荷之间相互作用情形外，自然界中的电荷相互作用现象往往都非常微弱，大多数时候这些相互作用都是“无声”地存在万物之中。在古代，人们对于生活中的“可观测”的电现象的认识大多来源于摩擦起电现象，很长一段时间内物理学家们研究电现象的主要实验手段也是通过摩擦来产生电。

早在东汉时期，思想家和哲学家王充在其所著的《论衡》中就有关于摩擦起电的记载，该书中写道：“顿牟掇芥，磁石引针”，其中顿牟就是琥珀，意思是琥珀经过摩擦之后，会吸引像草芥一样的轻小的物体，并且他在这里还将这种起电现象跟磁石吸引铁针的现象做类比。在西方，公元前6世纪，希腊的哲学家泰勒斯（Thales of Miletus）就记载了摩擦起电的现象：当时人们发现，琥珀摩擦猫毛以后会吸引像羽毛一类的轻微物体。在希腊语中，琥珀这个词是elektron，这也是“电”的英文单词 electric 的来源。后来，人们观察到了更多的能够摩擦起电的物体，并且发现了下面这些规律：

1. 摩擦不同的物体产生的电荷不相同，共有两种电荷，一种是丝绸摩擦过的玻璃棒（“玻璃电”），另一种是毛皮摩擦过的橡胶棒或琥珀（“树脂电”）。

2. 两种电荷都会吸引微小的物体。

3. 电荷与电荷之间也会相互作用，但是不同电荷之间的相互作用的特点不一样，比如：“玻璃电”与“玻璃电”相互排斥，“玻璃电”与“树脂电”相互吸引，“树脂电”与“树脂电”也会相互排斥。

后来，人们认为上述提到的这两种电荷（“玻璃电”和“树脂电”）是两种不同的流体，通过摩擦的动作可以将这两种电分离，通过合并的动作可以相互中和对方。18世纪，美国科学家本杰明·富兰克林（Benjamin Franklin，1706-1790）提出了电的单流体学说，他认为电不能被创造，只能在物体间转移，摩擦起电就是由于两种物体相互摩擦使电从一个物体转移到了另一个物体上，导致一个物体带过量的电，另一个物体带不足的电，他把这两种情况分别称为带正电和带负电，并且规定丝绸摩擦过的玻璃棒是带正电的，而毛皮摩擦过的橡胶棒是带负电的，后来这一定义就被一直保留到了今天。富兰克林还通过实验发现了电荷守恒定律，即在一个孤立系统里面，电荷的总量是不变的。