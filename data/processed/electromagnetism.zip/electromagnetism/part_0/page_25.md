定理 1.2 高斯定理

矢量场  $ \vec{F} $ 在任意闭合曲面 S 上的总通量，等于该矢量场的散度  $ \nabla \cdot \vec{F} $ 在 S 所包围的体积 V 内的体积分：

 $$ \iint_{S}\vec{F}\cdot\mathrm{d}\vec{S}=\iiint_{V}\nabla\cdot\vec{F}\mathrm{d}V $$ 

## 331 证明：

如图所示，对一任意闭合曲面 S 及其包围的体积 V，用一个曲面  $ S' $ 将该体积分成两部分，将这两部分的体积分别记为  $ V_{A} $ 和  $ V_{B} $， $ S' $ 也同时将闭合曲面 S 分成了两部分  $ S_{A} $ 和  $ S_{B} $。于是，矢量场  $ \vec{F} $ 在闭合曲面 S 上的总通量可以写成：

 $$ \iint_{S}\vec{F}\cdot\mathrm{d}\vec{S}=\iint_{\vec{S}_{A}}\vec{F}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{B}}\vec{F}\cdot\mathrm{d}\vec{S} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_708_480_1041_731.jpg" alt="Image" width="27%" /></div>


333 曲面  $ S' $ 有两个方向相反的法向  $ (\vec{S}_{A}^{\prime} $ 和  $ \vec{S}_{B}^{\prime}) $，且有：

 $$ \iint_{\vec{S}_{A}^{\prime}}\vec{F}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{B}^{\prime}}\vec{F}\cdot\mathrm{d}\vec{S}=0 $$ 

334 因此，1.64式可以写成：

 $$ \begin{aligned}\oint_{S}\vec{F}\cdot\mathrm{d}\vec{S}&=\iint_{\vec{S}_{A}}\vec{F}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{B}}\vec{F}\cdot\mathrm{d}\vec{S}+\left(\iint_{\vec{S}_{A}^{\prime}}\vec{F}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{B}^{\prime}}\vec{F}\cdot\mathrm{d}\vec{S}\right)\\&=\left(\iint_{\vec{S}_{A}}\vec{F}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{A}^{\prime}}\vec{F}\cdot\mathrm{d}\vec{S}\right)+\left(\iint_{\vec{S}_{B}}\vec{F}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{B}^{\prime}}\vec{F}\cdot\mathrm{d}\vec{S}\right)\\&=\iint_{\vec{S}_{A}+\vec{S}_{A}^{\prime}}\vec{F}\cdot\mathrm{d}\vec{S}+\iint_{\vec{S}_{B}+\vec{S}_{B}^{\prime}}\vec{F}\cdot\mathrm{d}\vec{S}\end{aligned} $$ 

也就是说，我们把矢量场  $ \vec{F} $ 在体积 V 的外表面这个闭合曲面 S 的通量，写成了  $ \vec{F} $ 在两个子体积  $ V_{A} $ 和  $ V_{B} $ 各自的外表面的闭合曲面  $ S_{A} + S_{A}^{\prime} $ 和  $ S_{B} + S_{B}^{\prime} $ 的通量之和，我们可以用同样的方法，继续对这两个子体积进行细分，直到将 V 细分成多个足够小的体积  $ V_{i} $ ( $ i = 1, 2, 3, \ldots, N $) 之和，且对每个  $ V_{i} $，我们可以使用1.62式：

 $$ \begin{aligned}\iint_{S}\vec{F}\cdot\mathrm{d}\vec{S}&=\sum_{i=1}^{N}\iint_{S_{i}}\vec{F}\cdot\mathrm{d}\vec{S}\\&=\sum_{i=1}^{N}\iiint_{V_{i}}\nabla\cdot\vec{F}\mathrm{d}V\\&=\iiint_{V}\nabla\cdot\vec{F}\mathrm{d}V\end{aligned} $$ 

339 这就证明了上述高斯定理（1.63式）。