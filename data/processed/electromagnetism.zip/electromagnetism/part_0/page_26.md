由高斯定理我们知道，如果在闭合曲面内部矢量场的散度  $ \nabla \cdot \vec{F} $ 为 0（或者其体积分为 0），那么该矢量场在这个闭合曲面上的通量也为 0，也就是说从这个闭合曲面流出的场线和流入的场线是相同的，从这个角度来说，我们可以把散度  $ \nabla \cdot \vec{F} $ 理解为矢量场  $ \vec{F} $ 的“源”，即无源的地方场线既不会聚也不发散，有源的地方才存在场线的会聚或者发散。

#### 1.3.3 旋度

345 让我们再从数学上回到一个矢量场  $ \vec{F} $ 随空间的变化可能有的 9 个偏微分量：

 $$ \frac{\partial F_{x}}{\partial x},\quad\frac{\partial F_{x}}{\partial y},\quad\frac{\partial F_{x}}{\partial z} $$ 

 $$ \frac{\partial F_{y}}{\partial x},\quad\frac{\partial F_{y}}{\partial y},\quad\frac{\partial F_{y}}{\partial z} $$ 

 $$ \frac{\partial F_{z}}{\partial x},\quad\frac{\partial F_{z}}{\partial y},\quad\frac{\partial F_{z}}{\partial z} $$ 

346 在定义散度时，我们使用了上面对角线上的三个偏微分量  $ \frac{\partial F_{x}}{\partial x} $， $ \frac{\partial F_{y}}{\partial y} $， $ \frac{\partial F_{z}}{\partial z} $，这三个偏微分量表征的都是矢量场的各个分量在对应的分方向上的变化，最终得到的散度的定义物理上表示的也是矢量场的场线在空间中某点的发散（或会聚）程度。上述 9 个偏微分量中，除去  $ \frac{\partial F_{x}}{\partial x} $， $ \frac{\partial F_{y}}{\partial y} $， $ \frac{\partial F_{z}}{\partial z} $ 之外的剩下 6 个偏微分量描述的都是  $ \vec{F} $ 的各个分量在它们垂直方向上的变化，比如  $ \frac{\partial F_{x}}{\partial y} $ 描述的是  $ \vec{F} $ 的 x 方向上的分量在 y 方向的变化。

为了直观地理解矢量场的各个分量在其对应的垂直方向上发生变化时是怎样的物理图像，我们不妨考虑下面这样一个在 x-y 平面上的二维矢量场  $ \vec{F} $：如右图所示，假设  $ \frac{\partial F_{x}}{\partial y} > 0, \frac{\partial F_{y}}{\partial x} < 0 $，则从图中的 A 点沿着 B, C 到 D 点的这条路径上， $ F_{x} $ 逐渐增大， $ F_{y} $ 逐渐减小，而两者合成之后的矢量场  $ \vec{F} $ 的大小则基本上保持不变，但是  $ \vec{F} $ 的方向在发生变化，且其方向的变化使得  $ \vec{F} $ 看上去一直与从 A 到 D 的圆弧相切，即  $ \vec{F} $ 这个矢量场从 A 到 D 的变化像是沿顺时针方向在“旋转”。

事实上，在上面这种二维的情况下，如果我们定义一个量  $ A=\frac{\partial F_{y}}{\partial x}-\frac{\partial F_{x}}{\partial y} $，如果 A<0，那么  $ \vec{F} $ 在这一点的变化趋势就是类似于上面这个图像的顺时针旋转，反之，若 A>0，则  $ \vec{F} $ 的变化趋势就是逆时针旋转。如果我们进一步给 A 这个量加上一个方向，使得它沿着 z 轴的方向，把 +z 方向定义为逆时针旋转，把 -z 的方向定义为顺时针方向，那么矢量  $ \vec{A} $ 可以定义为：





<div style="text-align: center;"><img src="imgs/img_in_image_box_694_873_1033_1174.jpg" alt="Image" width="28%" /></div>


 $$ \vec{A}=\left(\frac{\partial F_{y}}{\partial x}-\frac{\partial F_{x}}{\partial y}\right)\hat{z} $$ 

356 这样我们就在二维的情况下利用矢量场  $ \vec{F} $ 的各个分量在其对应的垂直方向上的变化的偏微分量，定义了一个新的矢量  $ \vec{A} $， $ \vec{A} $ 能够表征  $ \vec{F} $ 随着空间的变化而“旋转”的情况。