1845 代入6.9可得：

 $$ \begin{aligned}\mathrm{d}F(I,\mathrm{d}l,r,\alpha)&=\left(\frac{\partial F}{\partial r}\frac{\mathrm{d}r}{\mathrm{d}l}+\frac{\partial F}{\partial\alpha}\frac{\mathrm{d}\alpha}{\mathrm{d}l}\right)\mathrm{d}l\\&=\left((-k\frac{I}{r^{2}}\tan\frac{\alpha}{2})(-\cos\alpha)+(k\frac{I}{2r}\frac{1}{\cos^{2}\frac{\alpha}{2}})(\frac{\sin\alpha}{r})\right)\mathrm{d}l\\&=k\frac{I}{r^{2}}(\tan\frac{\alpha}{2}\cos\alpha+\frac{\sin\alpha}{2\cos^{2}\frac{\alpha}{2}})\mathrm{d}l\\&=k\frac{I}{r^{2}}\sin\alpha\mathrm{d}l\end{aligned} $$ 

上式便是毕奥和萨伐尔通过实验和数学推导得到的电流元 Idl 产生的磁场对 P 点处的磁针的相互作用力的定量公式，通过该公式，便可以很容易通过积分求出任意形状的电流产生的磁场对磁针的作用力。

如右图所示，写成矢量的形式，上述6.12式便成为：

 $$ \mathrm{d}\vec{F}=k\frac{I\mathrm{d}\vec{l}\times\hat{\boldsymbol{r}}}{r^{2}} $$ 

1820 年 10 月，毕奥和萨伐尔在《法国科学院院刊》正式公布了上述实验结果。上述6.12式，也被称为毕奥-萨伐尔定律。

<div style="text-align: center;"><img src="imgs/img_in_image_box_879_624_1032_761.jpg" alt="Image" width="12%" /></div>


1850 对于这一作用力的本质，法国物理学家安培首先给出了分子电流的猜想，即磁针中存在有序排列的分子电流，磁针会受到导线中电流的作用力的本质是磁针中的分子电流受到了导线中的电流的作用力。安培在毕奥-萨伐尔定律的基础上，通过进一步实验和推导，得到了稳恒电流  $ I_{1} \mathrm{d} \vec{l}_{1} $ 对稳恒电流元  $ I_{2} \mathrm{d} \vec{l}_{2} $ 的作用力  $ \vec{F}_{12} $ 公式（也被称为安培力）：

 $$ \mathrm{d}\vec{F}_{12}=\frac{\mu_{0}I_{1}I_{2}\mathrm{d}\vec{l}_{2}\times(\mathrm{d}\vec{l}_{1}\times\hat{\boldsymbol{r}}_{12})}{4\pi r_{12}^{2}} $$ 

1854 其中， $ \mu_{0} $ 为真空磁导率，其值为  $ 4\pi \times 10^{-7} N/A^{2} $

现在我们知道，这一作用力的本质，是由于导线中的电流在其周围产生了磁场，而磁场中的另一个电流会受到磁场的作用力。与电场强度类似，我们定义磁感应强度  $ \vec{B} $ 这个物理量，其定义为：磁场对垂直于  $ \vec{B} $ 方向放置的电流元  $ I d \vec{l} $ 的作用力 dF 与  $ I d l $ 的比值：

 $$ B=\frac{\mathrm{d}F}{I\mathrm{d}l} $$ 

1858  $ \vec{B} $ 的单位在国际单位制中是特斯拉（Tesla），符号为 T，1 T = 1  $ \frac{N}{A \cdot m} $。通过这个定义，我们知道，上述安培力也可以写成：电流元  $ I d \vec{l} $ 在磁场  $ \vec{B} $ 中受到的力，等于  $ I d \vec{l} $ 与  $ \vec{B} $ 的叉乘：

 $$ \mathrm{d}\vec{F}=I\mathrm{d}\vec{l}\times\vec{B} $$ 

而毕奥-萨伐尔定律，也可以写成对应的磁感应强度的形式：