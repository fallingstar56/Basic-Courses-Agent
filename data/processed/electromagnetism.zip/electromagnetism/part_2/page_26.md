1927 再利用链式法则  $ \nabla \cdot (\phi \vec{a}) = \phi \nabla \cdot \vec{a} + (\nabla \phi) \cdot \vec{a} $，可得，

 $$ \nabla\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}=\frac{\nabla\cdot\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}+\vec{J}(\vec{r}^{\prime})\cdot\nabla\frac{1}{|\vec{r}-\vec{r}^{\prime}|} $$ 

1928 由于  $ \vec{J}(\vec{r}^{\prime}) $ 不含  $ \vec{r} $ 坐标，因此  $ \nabla \cdot \vec{J}(\vec{r}^{\prime}) = 0 $，可得：

 $$ \nabla\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}=\vec{J}(\vec{r}^{\prime})\cdot\nabla\frac{1}{|\vec{r}-\vec{r}^{\prime}|} $$ 

1929 再利用  $ \nabla\frac{1}{\left|\vec{r}-\vec{r}^{\prime}\right|}=-\nabla^{\prime}\frac{1}{\left|\vec{r}-\vec{r}^{\prime}\right|} $，其中  $ \nabla^{\prime} $ 表示对  $ \vec{r}^{\prime} $ 坐标求微分，可得，

 $$ \nabla\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}=-\vec{J}(\vec{r}^{\prime})\cdot\nabla^{\prime}\frac{1}{|\vec{r}-\vec{r}^{\prime}|} $$ 

1930 继续使用链式法则  $ \nabla \cdot (\phi \vec{a}) = \phi \nabla \cdot \vec{a} + (\nabla \phi) \cdot \vec{a} $，可得，

 $$ \nabla\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}=-\nabla^{\prime}\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}+\frac{\nabla^{\prime}\cdot\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|} $$ 

1931 由电荷守恒，有  $ \nabla' \cdot \vec{J} (\vec{r}') = -\frac{\partial \rho (\vec{r}')}{\partial t} $，因此，

 $$ \nabla\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}=-\nabla^{\prime}\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}-\frac{\partial}{\partial t}\frac{\rho(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|} $$ 

1932 代入6.53式，可得：

 $$ \begin{aligned}\nabla\times(\nabla\times\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|})&=-\nabla\bigg(\nabla^{\prime}\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}+\frac{\partial}{\partial t}\frac{\rho(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\bigg)+4\pi\delta(\vec{r}-\vec{r}^{\prime})\vec{J}(\vec{r}^{\prime})\\&=-\nabla\bigg(\nabla^{\prime}\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\bigg)-\frac{\partial}{\partial t}\rho(\vec{r}^{\prime})\nabla\frac{1}{|\vec{r}-\vec{r}^{\prime}|}+4\pi\delta(\vec{r}-\vec{r}^{\prime})\vec{J}(\vec{r}^{\prime})\\&=-\nabla\bigg(\nabla^{\prime}\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\bigg)+\frac{\partial}{\partial t}\rho(\vec{r}^{\prime})\frac{\vec{r}-\vec{r}^{\prime}}{|\vec{r}-\vec{r}^{\prime}|^{3}}+4\pi\delta(\vec{r}-\vec{r}^{\prime})\vec{J}(\vec{r}^{\prime})\end{aligned} $$ 

1933 因此，

 $$ \begin{aligned}\nabla\times\vec{B}(\vec{r})=&-\frac{\mu_{0}}{4\pi}\nabla\int_{V^{\prime}}\nabla^{\prime}\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime}+\frac{\mu_{0}}{4\pi}\int_{V^{\prime}}\frac{\partial}{\partial t}\rho(\vec{r}^{\prime})\frac{\vec{r}-\vec{r}^{\prime}}{|\vec{r}-\vec{r}^{\prime}|^{3}}\mathrm{d}V^{\prime}\\&+\frac{\mu_{0}}{4\pi}\int_{V^{\prime}}4\pi\delta(\vec{r}-\vec{r}^{\prime})\vec{J}(\vec{r}^{\prime})\mathrm{d}V^{\prime}\\=&-\frac{\mu_{0}}{4\pi}\nabla\iint_{S^{\prime}}\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\cdot\mathrm{d}\vec{S}^{\prime}+\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}(\vec{r})}{\partial t}+\mu_{0}\vec{J}(\vec{r})\end{aligned} $$ 