了介质中的极化电荷与电场的相互作用中。因此，我们只需要计算在搬运自由电荷的过程中克服自由电荷受到的电场力做的功，便能得出此时整个带电体系的总静电能。

假设在搬运自由电荷的过程中，某一时刻空间的电势分布为  $ U(\vec{r}) $ （该电势为自由电荷和极化电荷产生的总电势），此时，如果我们给这个体系增加自由电荷分布  $ \delta\rho_{0}(\vec{r}) $，则增加这部分自由电荷需要克服静电力做的功为：

 $$ \delta W=\iiint_{V}\delta\rho_{0}(\vec{r})U(\vec{r})\mathrm{d}V $$ 

1677 由上述5.34式，利用电位移矢量的高斯定理  $ \left(\rho_{0}=\nabla\cdot\boldsymbol{D}\right) $，并利用散度计算的乘积法则，可得：

 $$ \begin{aligned}\delta W&=\iiint_{V}(\nabla\cdot\delta\vec{D})U\mathrm{d}V\\&=\iiint_{V}(\nabla\cdot(U\delta\vec{D})-\delta\vec{D}\cdot(\nabla U))\mathrm{d}V\\&=\iiint_{V}\nabla\cdot(U\delta\vec{D})\mathrm{d}V-\iiint_{V}\delta\vec{D}\cdot(\nabla U)\mathrm{d}V\\&=\oint_{\vec{\mathbf{S}}}U\delta\vec{D}\cdot\mathrm{d}\vec{\mathbf{S}}+\iiint_{V}\delta\vec{D}\cdot\vec{E}\mathrm{d}V\\&=\lim_{r\rightarrow\infty}\frac{r^{2}}{r^{3}}+\frac{1}{2}\iiint_{V}\delta(\vec{D}\cdot\vec{E})\mathrm{d}V\\&=\frac{1}{2}\iiint_{V}\delta(\vec{D}\cdot\vec{E})\mathrm{d}V\end{aligned} $$ 

1679 因此，将所有的自由电荷从无穷远处搬运到最终所处位置需要克服静电力做的总功为：

 $$ W=\int\mathrm{d}W=\frac{1}{2}\iiint_{V}\vec{D}\cdot\vec{E}\mathrm{d}V $$ 

事实上，我们也可以证明，上述总静电能也可以写成如下电势和自由电荷密度积分的形式：

 $$ W=\frac{1}{2}\iiint_{V}\rho_{0}(\vec{r})U(\vec{r})\mathrm{d}V=\frac{1}{2}\iiint_{V}\vec{D}\cdot\vec{E}\mathrm{d}V $$ 