1828 用力的研究，其中，首次定量给出这种作用力的公式的，是法国物理学家让-巴蒂斯特·毕奥（Jean-Baptiste Biot）和费利克斯·萨伐尔（Félix Savart）。

1830 如右图 (a) 所示，毕奥和萨伐尔等人的目的，是定量地通过实验得出与 P 点相距为 r 、夹角为  $ \alpha $ 的电流元 Idl 对 P 点的磁针的作用力 dF 与 I, dl, r,  $ \alpha $ 之间的关系，即：



 $$ \mathrm{d}F=\mathrm{d}F(I,\mathrm{d}l,r,\alpha) $$ 

而现实中，足够小的孤立电流元往往不容易获取而且其对磁针的作用力也很微弱不容易测量。实际实验中我们能够测量的，往往是如右图 (b) 所示的一段近似于无限长的直线载流导线对 P 点的磁针的作用力  $ F(I, r) $。

那载流导线对磁针的作用力 F 具体是如何测量的呢？如右图 (c) 所示，假设在磁针处，磁针的 N 极受到来自电流的力  $ \vec{F} $ 方向向右，那么 S 极受到的力则方向向左。若一开始磁针已经处于水平方向，那它将保持静止不动，也就是说水平方向是磁针的平衡方向；如果一开始磁针的方向与水平方向有一个小的夹角  $ \theta $，那么在力  $ \vec{F} $ 的作用下，磁针将以水平方向为中心做周期运动，其周期运动的微分方程可以写成：

<div style="text-align: center;"><img src="imgs/img_in_image_box_895_274_1028_388.jpg" alt="Image" width="11%" /></div>


 $$ M=I\ddot{\theta} $$ 

其中，I 为磁针围绕其转轴的转动惯量，M 是磁针受到的力矩，设磁针的长度为 l，则：

<div style="text-align: center;">(a)</div>


<div style="text-align: center;">(b)</div>


 $$ M=-Fl\sin\theta\approx-Fl\theta $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_892_454_1031_665.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_875_721_1034_825.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;">(c)</div>


 $$ I\ddot{\theta}+Fl\theta=0 $$ 

1831 因此，

1832 求解该方程，可得磁针周期运动的角频率为：

 $$ \omega=\sqrt{\frac{lF}{I}} $$ 

1833 测量该角频率，便可求出对应的磁针受到的来自导线的作用力：

 $$ F=\frac{I}{l}\omega^{2} $$ 