<div style="text-align: center;"><img src="imgs/img_in_image_box_241_160_469_310.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;">a. 螺线管照片</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_505_163_762_306.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">b. 矩形电流环尺寸示意图</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_816_159_952_290.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;">c. 线圈截面示意图</div>


59 6.3: 一个半径为  $ R $ 的均匀带电球面，电荷面密度为  $ \sigma $，球面绕  $ z $ 轴旋转，角速度为  $ \omega $，求其在球内外各点产生的磁矢势  $ \vec{A}(\vec{r}) $，及在球面内部各点的磁感应强度  $ \vec{B}(\vec{r}) $。

161 6.4: 有两根平行的长直载流导线，电流分别为  $ I_{1} $ 和  $ I_{2} $ （方向相同），导线间的距离为 d，求空间任意一点的磁感应强度。

163 6.5: 有两根平行的长直载流导线，电流分别为  $ I_{1} $ 和  $ I_{2} $，导线间的距离为 d，分别求两电流方向相同和相反时，其中一根导线上单位长度的导线受到的另一根导线的作用力。

2165 6.6: 有三根共面且相互平行的等间距（d）分布的长直载流导线，每根导线载有大小和方向相同的电流 I，求：

2167 1) 空间中磁感应强度为零的位置；

2) 若将中间那根载流导线向两边的其中一根导线移动一个很小的距离 x，请问此时中间这根导线将怎样运动。

2170 6.7: 如图所示，载流直线导线有一段被弯成半圆形，圆的半径为 r，电流为 I，求圆心处的磁感应强度。

<div style="text-align: center;"><img src="imgs/img_in_image_box_377_998_815_1140.jpg" alt="Image" width="36%" /></div>


6.8: 有一无限长圆柱形带电球面，半径为 r，表面电荷密度为  $ \sigma $。现让该圆柱面绕其轴线以角速度  $ \omega $ 旋转，求空间磁感应强度分布。

2175 6.9: 有一无限长圆柱形电介质，半径为  $ R $，其内部任意一点的极化强度矢量为  $ \vec{P} = p_0 \vec{r} / 2 $，其中  $ \vec{r} $ 为从轴线到该点的位移矢量且  $ \vec{r} $ 垂直于轴线。求：

1) 电介质内部的体极化电荷密度  $ \rho_{e}^{\prime} $ 和介质表面的面极化电荷密度  $ \sigma_{e}^{\prime} $

2）若该圆柱绕其轴线以角速度  $ \omega $ 旋转，求空间磁感应强度分布。

2179 6.10: 有一半径为 R 的均匀带电圆盘，带电量为 q，圆盘绕着过其圆心且垂直于圆面的轴线以角速度  $ \omega $ 旋转，求：