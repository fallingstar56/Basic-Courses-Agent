1626

### 例 5.2

一半径为 R，带电量为 Q 的均匀带电球体，利用电场能量密度求其静电能。

<div style="text-align: center;"><img src="imgs/img_in_image_box_833_167_1035_365.jpg" alt="Image" width="16%" /></div>


解:

如图所示，任意一点电场的能量密度为：

 $$ w_{e}=\frac{1}{2}\varepsilon_{0}E^{2}=\begin{cases}\frac{1}{2}\varepsilon_{0}\left(\frac{Qr}{4\pi\varepsilon_{0}R^{3}}\right)^{2},&r<R,\\\frac{1}{2}\varepsilon_{0}\left(\frac{Q}{4\pi\varepsilon_{0}r^{2}}\right)^{2},&r\geq R.\end{cases} $$ 

1627 因此，总静电能为：

 $$ \begin{aligned}W&=\iiint_{V}w_{e}\mathrm{d}V\\&=\int_{0}^{R}\frac{1}{2}\varepsilon_{0}\left(\frac{Qr}{4\pi\varepsilon_{0}R^{3}}\right)^{2}4\pi r^{2}\mathrm{d}r+\int_{R}^{\infty}\frac{1}{2}\varepsilon_{0}\left(\frac{Q}{4\pi\varepsilon_{0}r^{2}}\right)^{2}4\pi r^{2}\mathrm{d}r\\&=\frac{Q^{2}}{8\pi\varepsilon_{0}}\Big(\int_{0}^{R}\frac{r^{4}}{R^{6}}\mathrm{d}r+\int_{R}^{\infty}\frac{1}{r^{2}}\mathrm{d}r\Big)\\&=\frac{Q^{2}}{8\pi\varepsilon_{0}}\Big(\frac{1}{5R}+\frac{1}{R}\Big)\\&=\frac{3Q^{2}}{20\pi\varepsilon_{0}R}\end{aligned} $$ 

1628 这与例5.1中通过  $ W = \frac{1}{2} \iiint_{V} U \rho \mathrm{d}V $ 计算得到的结果是一致的。

需要指出的是，无论是上一节讨论的能量储存在电荷体系的观点、还是本节里讨论的能量储存在电场中的观点，我们分析的都是相互作用能。我们并没有考虑一个孤立点电荷的静电能（也叫自能），或者把单个点电荷自身的静电能考虑到我们的静电能中，这是因为，讨论单个点电荷的静电能没有任何实际意义，因为没有与之对应的做功或者相互作用力，自然也就不存在功和能的转换。这一点，在5.8式中我们已经有所体现，即该式中的 $ U_i $是除 $ q_i $以外的其他电荷在 $ \vec{r}_i $产生的电势。事实上，如果我们不去除 $ q_i $本身在 $ \vec{r}_i $产生的电势，我们会发现对于理想点电荷（也就是体积无限小但是电荷有限大的电荷分布），其静电自能是无穷大的（其产生的电势 $ U $在其自身位置处为无穷大），或者说是发散的。

诸如点电荷这种带电体系静电自能为无穷大的本质原因，是因为点电荷这种理想带电体系在其自身所在的位置产生的电势为无穷大。只有当电荷体系在其自身电荷存在的位置产生的电势为有限值的时候，其静电自能才不会发散。例如，对于体电荷密度为  $ \rho $ 的球体，我们在例5.1时已经计算得出其电势在球内任意一点为有限值，因此，其静电自能不发散。事实上，在进行形如

 $$ W=\frac{1}{2}\iiint_{V}U(\vec{r})\rho(\vec{r})\mathrm{d}V $$ 

1641 的积分计算的时候，是否将电荷微元  $ \rho(\vec{r}) $ dV 自身产生的电势包含进  $ U(\vec{r}) $ 并不会影响  $ U(\vec{r}) $ 的