1681 证明如下：利用电位移矢量的高斯定理  $ (\rho_0 = \nabla \cdot \vec{D}) $，并利用散度计算的乘积法则，可得：

 $$ \begin{aligned}\frac{1}{2}\iiint_{V}\rho_{0}(\vec{r})U(\vec{r})\mathrm{d}V&=\frac{1}{2}\iiint_{V}(\nabla\cdot\vec{D})U\mathrm{d}V\\&=\frac{1}{2}\iiint_{V}(\nabla\cdot(U\vec{D})-\vec{D}\cdot(\nabla U))\mathrm{d}V\\&=\frac{1}{2}\iiint_{V}\nabla\cdot(U\vec{D})\mathrm{d}V-\frac{1}{2}\iiint_{V}\vec{D}\cdot(\nabla U)\mathrm{d}V\\&=\frac{1}{2}\iint_{\vec{S}}U\vec{D}\cdot\mathrm{d}\vec{S}+\frac{1}{2}\iiint_{V}\vec{D}\cdot\vec{E}\mathrm{d}V\\&=\lim_{r\rightarrow\infty}\frac{r^{2}}{r^{3}}+\frac{1}{2}\iiint_{V}\vec{D}\cdot\vec{E}\mathrm{d}V\\&=\frac{1}{2}\iiint_{V}\vec{D}\cdot\vec{E}\mathrm{d}V\end{aligned} $$ 

1682 利用  $ \vec{D} = \varepsilon_{0}\vec{E} + \vec{P} $，上式也可以写成：

 $$ W=\frac{1}{2}\iiint_{V}\vec{D}\cdot\vec{E}\mathrm{d}V=\iiint_{V}\frac{1}{2}\varepsilon_{0}E^{2}\mathrm{d}V+\iiint_{V}\frac{1}{2}\vec{P}\cdot\vec{E}\mathrm{d}V $$ 

1683

相对应的，有介质的情况下静电场的能量密度为：

 $$ w_{e}=\frac{1}{2}\vec{D}\cdot\vec{E}=\frac{1}{2}\varepsilon_{0}E^{2}+\frac{1}{2}\vec{P}\cdot\vec{E} $$ 

上式中，第一项  $ \frac{1}{2}\varepsilon_0E^2 $ 是纯电场的能量密度，储存在了电场本身之中；而第二项  $ \frac{1}{2}\vec{P} \cdot \vec{E} $ 储存在了极化电荷中，我们把它称为极化能密度，其本质是极化电荷与电场之间的相互作用。由于极化强度矢量  $ \vec{P} $ 是单位体积的电偶极矩，所以  $ \frac{1}{2}\vec{P} \cdot \vec{E} $ 这一极化能密度也表明介质中单个电偶极子  $ \vec{p} $ 在电场中储存的极化能为  $ \frac{1}{2}\vec{P} \cdot \vec{E} $。而这一结论，也可以直接从在外场建立的过程中（即前面说的逐渐搬运自由电荷的过程中，这一过程电场逐渐加大）电场对电偶极子做的功直接得到：

以位移极化为例，如下图所示，假设  $ t $ 时刻，电偶极子间距为  $ \vec{l} $，电场强度为  $ \vec{l} $；到  $ t + dt $ 时刻，电偶极子间距为  $ \vec{l} + d\vec{l} $，电场强度为  $ \vec{E} + d\vec{E} $。则  $ dt $ 这一时间段内，电场对电偶极子做的功为：

 $$ \mathrm{d}W=\vec{F}_{+}\cdot\mathrm{d}\vec{l}_{+}+\vec{F}_{-}\cdot\mathrm{d}\vec{l}_{-} $$ 

其中， $ \vec{d}\vec{l}_{+} $， $ \vec{d}\vec{l}_{-} $分别是 +q 和 -q 电荷在这一时间段内的位移，且  $ \vec{d}\vec{l}_{+}-\vec{d}\vec{l}_{-}=\vec{d}\vec{l} $； $ \vec{F}_{+}=1696\quad q\vec{E} $， $ \vec{F}_{-}=-q\vec{E} $ 分别为两个电荷受到的电场力。因此：

 $$ \begin{aligned}&\xrightarrow{\vec{E}}\\&-q\bullet\xrightarrow{\vec{l}}\bullet\bullet q\\&t 时刻 \end{aligned}\quad\begin{aligned}&\xrightarrow{\vec{E}+\mathrm{d}\vec{E}}\\&-q\bullet\xrightarrow{\vec{l}+\mathrm{d}\vec{l}}\bullet q\\&t+\mathrm{d}t 时刻 \end{aligned} $$ 

1697