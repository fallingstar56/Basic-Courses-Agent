2070 由于 P 点位于 xz 平面，且 P 点的  $ \vec{A} $ 只有 y 方向分量，这也意味着在球坐标系中 P 点的  $ \vec{A} $ 只有  $ \phi $ 方向分量，即：

 $$ A_{\phi}(r,\theta,\phi=0)=\frac{\mu_{0}IR^{2}\sin\theta}{4r^{2}} $$ 

2072 代入  $ \vec{B} = \nabla \times \vec{A} $，可得：

 $$ B_{r}=\frac{1}{r\sin\theta}\frac{\partial(\sin\theta A_{\phi})}{\partial\theta}=\frac{\mu_{0}IR^{2}\cos\theta}{2r^{3}} $$ 

 $$ B_{\theta}=-\frac{1}{r}\frac{\partial(r A_{\phi})}{\partial r}=\frac{\mu_{0}IR^{2}\sin\theta}{4r^{3}} $$ 

 $$ B_{\phi}=0 $$ 

2073 写成矢量形式， $ \vec{A} $ 和  $ \vec{B} $ 分别为：

 $$ \vec{A}=\frac{\mu_{0}}{4\pi}\frac{\vec{m}\times\vec{r}}{r^{3}} $$ 

 $$ \vec{B}=\frac{\mu_{0}}{4\pi}\frac{3(\vec{m}\cdot\hat{\boldsymbol{r}})\hat{\boldsymbol{r}}-\vec{m}}{r^{3}} $$ 

2075 上述磁偶极子在远处任意点产生的磁矢势和磁感应强度，与电偶极子在远处任意点产生的电势（2.117式）和电场强度（2.24式），形式上非常相似。

在静磁学中，磁矢势的意义主要在于数学上的计算的意义，其物理意义并不明显（历史上诸如赫兹等多位物理学家曾认为  $ \vec{A} $ 没有物理意义或者物理实在）， $ \vec{A} $ 通过  $ \vec{B} $ 间接体现其物理意义；但是，在量子力学以及量子场论中， $ \vec{A} $ 是电磁场量子化的基础，光子（电磁场的量子）与  $ \vec{A} $ 直接相关， $ \vec{A} $ 具有深刻的物理意义。

### 6.4 磁力、磁力矩

从本章介绍的静磁学的发展历程我们知道，人们对于磁现象的认识，最直接的手段便是观测与磁场相关的相互作用力，比如，毕奥-萨伐尔通过定量测量得出了电流元对磁针的相互作用力，后来，安培把这种作用力的本质解释为电流元与电流元之间的相互作用力，即认为磁针里面存在分子电流，磁针中的分子电流受到了导线中的电流产生的磁场的作用力，也就是我们在本章第1节学习的安培力公式：

 $$ \mathrm{d}\vec{F}=I\mathrm{d}\vec{l}\times\vec{B} $$ 

我们正是通过这一安培力，来定义磁感应强度矢量这一物理量。本节将在这一公式的基础上，具体分析常见的几种电流形式在磁场中的受力情况。

我们知道，电流的本质是运动的电荷，因此，电流在磁场中受力的本质是运动电荷在磁场中受力。根据电流的定义，上述6.123式也可以写成：

 $$ \mathrm{d}\vec{F}=\frac{\mathrm{d}Q}{\mathrm{d}t}\mathrm{d}\vec{l}\times\vec{B}=\mathrm{d}Q\frac{\mathrm{d}\vec{l}}{\mathrm{d}t}\times\vec{B}=\mathrm{d}Q\vec{v}\times\vec{B} $$ 

2091 其中 dQ 为电流元 Idī 中的总电荷，而 ∇ 为电流元中的电荷的运动速度。若电流元中只有一个