2024 由于  $ \vec{F}(\vec{r}^{\prime}) $ 不依赖于  $ \vec{r} $ 坐标，因此，

 $$ \vec{F}(\vec{r})=-\frac{1}{4\pi}\nabla^{2}\iiint_{V^{\prime}}\frac{\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

2025 利用矢量恒等式  $ \nabla \times (\nabla \times \vec{a}) = \nabla (\nabla \cdot \vec{a}) - \nabla^2 \vec{a} $，上式可写成：

 $$ \vec{F}(\vec{r})=-\frac{1}{4\pi}\nabla\iiint_{V^{\prime}}\nabla\cdot\frac{\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime}+\frac{1}{4\pi}\nabla\times\iiint_{V^{\prime}}\nabla\times\frac{\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

2026 由于  $ \vec{F}(\vec{r}') $ 不依赖与  $ \vec{r} $ 坐标，由链式法则  $ \nabla \cdot (\phi \vec{a}) = \phi \nabla \cdot \vec{a} + (\nabla \phi) \cdot \vec{a} $ 和  $ \nabla \times (\phi \vec{a}) = 2027 (\nabla \phi) \times \vec{a} + \phi (\nabla \times \vec{a}) $，我们可得，

 $$ \begin{aligned}\vec{F}(\vec{r})&=-\frac{1}{4\pi}\nabla\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\cdot\nabla\frac{1}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime}-\frac{1}{4\pi}\nabla\times\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\times\nabla\frac{1}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime}\\&=-\frac{1}{4\pi}\nabla\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\cdot\frac{\vec{r}-\vec{r}^{\prime}}{|\vec{r}-\vec{r}^{\prime}|^{3}}\mathrm{d}V^{\prime}-\frac{1}{4\pi}\nabla\times\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\times\frac{\vec{r}-\vec{r}^{\prime}}{|\vec{r}-\vec{r}^{\prime}|^{3}}\mathrm{d}V^{\prime}\end{aligned} $$ 

2028 由于积分空间  $ V' $ 为全空间，要想让上式两个积分在  $ r' \to \infty $ 时不发散，需要  $ F(\vec{r}') $ 的值在 2029  $ r' \to \infty $ 时趋于零，且衰减速度比  $ 1/r' $ 快；此时，可以根据上式定义定理所需要的  $ U(\vec{r}) $ 和 2030  $ \vec{A}(\vec{r}) $：

 $$ U(\vec{\mathbf{r}})=\frac{1}{4\pi}\iiint_{V^{\prime}}\vec{\mathbf{F}}(\vec{\mathbf{r}}^{\prime})\cdot\nabla\frac{1}{|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|}\mathrm{d}V^{\prime} $$ 

2031

 $$ \vec{A}(\vec{r})=-\frac{1}{4\pi}\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\times\nabla\frac{1}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

2032 利用  $ \nabla\frac{1}{|\vec{r}-\vec{r}^{\prime}|}=-\nabla^{\prime}\frac{1}{|\vec{r}-\vec{r}^{\prime}|} $，上述两式可以分别写成：

 $$ U(\vec{\mathbf{r}})=-\frac{1}{4\pi}\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\cdot\nabla^{\prime}\frac{1}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

 $$ \vec{A}(\vec{r})=\frac{1}{4\pi}\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\times\nabla^{\prime}\frac{1}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

2033 再利用链式法则  $ \nabla \cdot (\phi \vec{a}) = \phi \nabla \cdot \vec{a} + (\nabla \phi) \cdot \vec{a} $ 和  $ \nabla \times (\phi \vec{a}) = (\nabla \phi) \times \vec{a} + \phi (\nabla \times \vec{a}) $，上述两式

2034 可进一步写成：

 $$ U(\vec{\mathbf{r}})=\frac{1}{4\pi}\iiint_{V^{\prime}}\frac{\nabla^{\prime}\cdot\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime}-\frac{1}{4\pi}\iiint_{V^{\prime}}\nabla^{\prime}\cdot\frac{\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

 $$ \vec{A}(\vec{r})=\frac{1}{4\pi}\iiint_{V^{\prime}}\frac{\nabla^{\prime}\times\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime}-\frac{1}{4\pi}\iiint_{V^{\prime}}\nabla^{\prime}\times\frac{\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

2035 由高斯定理（包括习题1.2的叉乘形式的高斯定理），上述两式可写成：

 $$ U(\vec{\mathbf{r}})=\frac{1}{4\pi}\iiint_{V^{\prime}}\frac{\nabla^{\prime}\cdot\vec{F}(\vec{\mathbf{r}}^{\prime})}{|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|}\mathrm{d}V^{\prime}-\frac{1}{4\pi}\iiint_{\vec{S}^{\prime}}\frac{\vec{F}(\vec{\mathbf{r}}^{\prime})}{|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|}\cdot\mathrm{d}\vec{S}^{\prime} $$ 

 $$ \vec{A}(\vec{r})=\frac{1}{4\pi}\iiint_{V^{\prime}}\frac{\nabla^{\prime}\times\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime}+\frac{1}{4\pi}\iiint_{\vec{S}^{\prime}}\frac{\vec{F}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\times\mathrm{d}\vec{S}^{\prime} $$ 