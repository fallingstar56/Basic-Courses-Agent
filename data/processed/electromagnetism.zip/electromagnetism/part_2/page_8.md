1657 可得：

 $$ W_{i j}^{b}=\iiint_{V}\varepsilon_{0}q_{i}q_{j}\frac{\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}_{i}}{4\pi\varepsilon_{0}|\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}_{i}|^{3}}\cdot\frac{\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}_{j}}{4\pi\varepsilon_{0}|\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}_{j}|^{3}}\mathrm{d}^{3}\vec{\boldsymbol{r}} $$ 

令  $ \vec{a} = \vec{r}_{i} - \vec{r}_{j} $， $ \hat{a} $ 为  $ \vec{a} $ 的方向矢量，且令：

 $$ \vec{x}=\frac{\vec{r}-\vec{r}_{i}}{\left|\vec{r}_{i}-\vec{r}_{j}\right|}=\frac{\vec{r}-\vec{r}_{i}}{a} $$ 

1659 则，

 $$ \vec{r}-\vec{r}_{i}=a\vec{x},\quad\vec{r}-\vec{r}_{j}=a\vec{x}+\vec{r}_{i}-\vec{r}_{j}=a\vec{x}+\vec{a}=a(\vec{x}+\hat{a}) $$ 

1660 代入5.30式，可得

 $$ \begin{aligned}W_{ij}^{b}&=\iiint_{V}\varepsilon_{0}q_{i}q_{j}\frac{a\vec{x}}{4\pi\varepsilon_{0}a^{3}|\vec{x}|^{3}}\cdot\frac{a(\vec{x}+\hat{\mathbf{a}})}{4\pi\varepsilon_{0}a^{3}|\vec{x}+\hat{\mathbf{a}}|^{3}}a^{3}\mathrm{d}^{3}\vec{x}\\&=\frac{q_{i}q_{j}}{16\pi^{2}\varepsilon_{0}a}\iiint_{V}\frac{\vec{x}}{x^{3}}\cdot\frac{\vec{x}+\hat{\mathbf{a}}}{|\vec{x}+\hat{\mathbf{a}}|^{3}}\mathrm{d}^{3}\vec{x}\\&=-\frac{q_{i}q_{j}}{16\pi^{2}\varepsilon_{0}a}\iiint_{V}\frac{\vec{x}}{x^{3}}\cdot\nabla\frac{1}{|\vec{x}+\hat{\mathbf{a}}|}\mathrm{d}^{3}\vec{x}\\&=\frac{q_{i}q_{j}}{16\pi^{2}\varepsilon_{0}a}\iiint_{V}\Big(-\nabla\cdot\frac{\vec{x}}{x^{3}|\vec{x}+\hat{\mathbf{a}}|}+\frac{1}{|\vec{x}+\hat{\mathbf{a}}|}\nabla\cdot\frac{\vec{x}}{x^{3}}\Big)\mathrm{d}^{3}\vec{x}\\&=-\frac{q_{i}q_{j}}{16\pi^{2}\varepsilon_{0}a}\iint_{\vec{S}}\frac{\vec{x}}{x^{3}|\vec{x}+\hat{\mathbf{a}}|}\cdot\mathrm{d}\vec{S}+\frac{q_{i}q_{j}}{16\pi^{2}\varepsilon_{0}a}\iiint_{V}\frac{1}{|\vec{x}+\hat{\mathbf{a}}|}\nabla\cdot\frac{\vec{x}}{x^{3}}\mathrm{d}^{3}\vec{x}\\&=0+\frac{q_{i}q_{j}}{16\pi^{2}\varepsilon_{0}a}\iiint_{V}\frac{1}{|\vec{x}+\hat{\mathbf{a}}|}4\pi\delta^{3}(0)\mathrm{d}^{3}\vec{x}\\&=\frac{q_{i}q_{j}}{16\pi^{2}\varepsilon_{0}a}\frac{4\pi}{|0+\hat{\mathbf{a}}|}\\&=\frac{q_{i}q_{j}}{4\pi\varepsilon_{0}a}=\frac{q_{i}q_{j}}{4\pi\varepsilon_{0}|\vec{r}_{i}-\vec{r}_{j}|}\end{aligned} $$ 

1661 即  $ W_{ij}^{a} = W_{ij}^{b} $。因此，使用电场能量密度计算多个点电荷组成的带电体系的静电能时， $ \varepsilon_{0} \iiint_{V} \vec{E}_{i} \cdot \vec{E}_{j} \mathrm{d}V $ 项对应的便是点电荷  $ q_{i} $ 和  $ q_{j} $ 之间的相互作用能。

所幸的是，诸如点电荷这种带电体系是一个理想的电荷分布，真实世界的电荷都有一定的空间分布，其静电自能一般都为零，因而在使用诸如5.9式或者5.19式计算静电场的能量的时候我们一般都不必考虑是否要刻意去除静电自能。

1666

### 5.3 有介质存在时的静电能

当带电体系既存在自由电荷，又存在极化电荷时，我们依然可以用类似5.1节通过计算搬运电荷所做的功的办法来计算体系的静电能。此时，系统静电能为零的初始状态应该是所有自由电荷都在无穷远处，且互相间隔无穷远，介质所在的位置不存在外加电场；而后我们逐渐将自由电荷搬运到他们最终状态所属的位置。由能量守恒，我们整个过程搬运自由电荷需要对自由电荷做的功，便是这个体系的静电能。只不过由于介质的存在，这些静电能有一部分储存在