该电流产生的磁场可以看成是半径为 R、电流密度为  $ \vec{J} $ 的圆柱电流产生的磁场与半径为 r、电流密度为  $ -\vec{J} $ 的圆柱电流产生的磁场的矢量和。

由上一例题，圆柱形电流在其内部产生的磁场由6.69式给出，该式也可以写成：

 $$ \vec{B}=\frac{\mu_{0}}{2}\vec{J}\times\vec{r} $$ 

1963 因此，空腔内任意一点的磁场为：

 $$ \vec{B}=\vec{B}_{\vec{j}}+\vec{B}_{-\vec{j}}=\frac{\mu_{0}}{2}\vec{J}\times\vec{r}_{1}-\frac{\mu_{0}}{2}\vec{J}\times\vec{r}_{2}=\frac{\mu_{0}}{2}\vec{J}\times(\vec{r}_{1}-\vec{r}_{2})=\frac{\mu_{0}}{2}\vec{J}\times\vec{a} $$ 

1964 注意到上式给出的  $ \vec{B} $ 在空腔内部处处大小相等、方向相同，即在空腔中的磁场为均匀磁场。

例 6.8

如图所示为一个半径为 R、长度为 L 的密绕长直螺线管，其单位长度有 n 匝线圈，线圈中的电流为 I，求其中心点所在的横截面上任意一点的磁感应强度。

<div style="text-align: center;"><img src="imgs/img_in_image_box_785_560_1032_781.jpg" alt="Image" width="20%" /></div>


解:

由例6.4，该螺线管轴线中心点处的磁感应强度为：

 $$ \vec{B}_{0}=n\mu_{0}I\cos\theta\hat{z} $$ 

1967 其中， $ \theta=\arctan\frac{2R}{L} $

下面求横截面上其他各处的磁场。首先我们可以证明，该横截面上各处的磁感应强度都与该横截面垂直（即只有 z 方向分量），这是因为，截面两侧的电流元，均互相以截面为镜面存在镜面对称，而我们可以证明，镜面对称的电流系统在镜面处产生的磁感应强度与该镜面垂直。

为了证明上述结论，我们取如右图所示镜面对称的两个电流元  $ I_{d}\vec{l} $ 和  $ I_{d}\vec{l} $，镜面为与 x 轴垂直的一个平面，这两个电流元在镜面上任意一点 P 产生的磁场的矢量和为：

 $$ \begin{aligned}\vec{B}_{ 总 }&=\vec{B}+\vec{B}^{\prime}\\&=\frac{\mu_{0}I\mathrm{d}\vec{l}\times\vec{r}}{r^{3}}+\frac{\mu_{0}I\mathrm{d}\vec{l}^{\prime}\times\vec{r}^{\prime}}{r^{\prime3}}\\&=\frac{\mu_{0}I}{r^{3}}(\mathrm{d}\vec{l}\times\vec{r}+\mathrm{d}\vec{l}^{\prime}\times\vec{r}^{\prime})\end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_784_1119_1034_1376.jpg" alt="Image" width="20%" /></div>


令  $ \vec{d} = (\mathrm{d}l_{x}, \mathrm{d}l_{y}, \mathrm{d}l_{z}), \vec{r} = (r_{x}, r_{y}, r_{z}), $ 则  $ \vec{d} = (-\mathrm{d}l_{x}, \mathrm{d}l_{y}, \mathrm{d}l_{z}), \vec{r} = (-r_{x}, r_{y}, r_{z}), $ 因此：

 $$ \left.\mathrm{d}\vec{l}\times\vec{r}\right|_{x}=\left.\mathrm{d}\vec{l}^{\prime}\times\vec{r}^{\prime}\right|_{x},\quad\left.\mathrm{d}\vec{l}\times\vec{r}\right|_{y}=-\left.\mathrm{d}\vec{l}^{\prime}\times\vec{r}^{\prime}\right|_{y},\quad\left.\mathrm{d}\vec{l}\times\vec{r}\right|_{z}=-\left.\mathrm{d}\vec{l}^{\prime}\times\vec{r}^{\prime}\right|_{z} $$ 