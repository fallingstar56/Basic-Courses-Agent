### 定律 6.1 毕奥-萨伐尔定律

真空中，电流元  $ I d \vec{l} $ 在任意一点 P 产生的磁场的磁感应强度  $ d \vec{B} $ 为：

 $$ \mathrm{d}\vec{B}=\frac{\mu_{0}I\mathrm{d}\vec{l}\times\hat{\mathbf{r}}}{4\pi r^{2}} $$ 

其中， $ \vec{r} $ 为从电流元到 P 点的位移矢量。



与电场类似，磁场也满足叠加原理，即多个电流元产生的总磁场的磁感应强度，等于单个电流元产生的磁感应强度的矢量和。比如，对于细导线：

 $$ \vec{B}(\vec{r})=\int\mathrm{d}\vec{B}=\int\frac{\mu_{0}I\mathrm{d}\vec{l}^{\prime}\times(\vec{r}-\vec{r}^{\prime})}{4\pi|\vec{r}-\vec{r}^{\prime}|^{3}} $$ 

1865 而对于横截面上各处电流密度不同的粗导线： $ \int Id\vec{l} = \int (\int_S \vec{J} dS') d\vec{l} = \int_V \vec{J}(\vec{r}') dV' $

 $$ \vec{B}(\vec{r})=\int_{V^{\prime}}\frac{\mu_{0}\vec{J}(\vec{r}^{\prime})\times(\vec{r}-\vec{r}^{\prime})}{4\pi|\vec{r}-\vec{r}^{\prime}|^{3}}\mathrm{d}V^{\prime} $$ 

下面，我们通过几个例题，来利用毕奥-萨伐尔定律求解常见载流导线产生的磁场。

例 6.1

如右图所示，求有限长载流直线导体在 P 点产生的磁场。

解：

如图，由毕奥-萨伐尔定律，电流元  $ I d \bar{l} $ 在 P 点产生的磁感应强度为：

 $$ \mathrm{d}\vec{B}=\frac{\mu_{0}I\mathrm{d}\vec{l}\times\hat{\boldsymbol{r}}}{4\pi r^{2}} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_878_870_1035_1183.jpg" alt="Image" width="13%" /></div>


d $ \vec{B} $ 的方向为垂直纸面向里，大小为：

 $$ \mathrm{d}B=\frac{\mu_{0}I\mathrm{d}l\sin\theta}{4\pi r^{2}}=\frac{\mu_{0}I\mathrm{d}(-r_{0}/\tan\theta)\sin\theta}{4\pi(r_{0}/\sin\theta)^{2}}\mathrm{d}\theta=\frac{\mu_{0}I\sin\theta}{4\pi r_{0}}\mathrm{d}\theta $$ 

1868 因此，

 $$ B=\int\mathrm{d}B=\int_{\theta_{1}}^{\theta_{2}}\frac{\mu_{0}I\sin\theta}{4\pi r_{0}}\mathrm{d}\theta=\frac{\mu_{0}I}{4\pi r_{0}}(\cos\theta_{1}-\cos\theta_{2}) $$ 

1869 对于无限长直线电流， $ \theta_{1}=0,\quad\theta_{2}=\pi $，因而：

 $$ B=\frac{\mu_{0}I}{2\pi r_{0}} $$ 

1870 可见，无限长线电流产生的磁场与距离成反比，这与无限长线电荷产生的电场随距离的衰减速