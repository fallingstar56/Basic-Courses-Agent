2036 其中  $ \vec{S}' $ 为包围无穷大空间的闭合曲面。由于 F 衰减速度大于 1/r，因此在无穷远处上述两式中的面积分近似为：

 $$ \lim_{r\to\infty}\frac{F(r)}{r}r^{2}=0 $$ 

2038 因此，

 $$ U(\vec{\mathbf{r}})=\frac{1}{4\pi}\iiint_{V^{\prime}}\frac{\nabla^{\prime}\cdot\vec{\mathbf{F}}(\vec{\mathbf{r}}^{\prime})}{|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|}\mathrm{d}V^{\prime},\qquad\vec{A}(\vec{\mathbf{r}})=\frac{1}{4\pi}\iiint_{V^{\prime}}\frac{\nabla^{\prime}\times\vec{F}(\vec{\mathbf{r}}^{\prime})}{|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|}\mathrm{d}V^{\prime} $$ 

上述亥姆霍兹定理表明，静磁场  $ \vec{B} $ 一定可以写成如下形式：

 $$ \vec{B}=-\nabla U+\nabla\times\vec{A} $$ 

2041 而静磁场的基本定理要求：

 $$ 0=\nabla\cdot\vec{B}=-\nabla\cdot\nabla U+\nabla\cdot(\nabla\times\vec{A})=-\nabla\cdot\nabla U $$ 

2042 另一方面，我们还有恒等式：

 $$ \nabla\times\nabla U=0 $$ 

2043 也就是说，∇U 的散度和旋度都为零，那 ∇U 只能是常数且与无穷远处相等，而无穷远处  $ \vec{B}=0 $

2044 因而 ∇U=0，因此，任意静磁场都能写成如下形式：

 $$ \vec{B}=\nabla\times\vec{A} $$ 

2045 我们把  $ \vec{A} $ 称为磁场的矢量势，也称为磁矢势。

注意到，满足上述6.108式的  $ \vec{A} $ 理论上存在无穷多可能，因为假设某个  $ \vec{A} $ 使得  $ \vec{B} = \nabla \times \vec{A} $，那对  $ \vec{A} $ 加上任意标量场的梯度  $ \vec{A}' = \vec{A} + \nabla \Phi $（也被称为“规范变换”）依然不会改变磁场  $ \vec{B} $，即  $ \vec{B}' = \nabla \times \vec{A}' = \nabla \times \vec{A} + \nabla \times \nabla \Phi = \nabla \times \vec{A} = \vec{B} $。另一方面，数学上，只给出  $ \vec{A} $ 的旋度并不能唯一确定该矢量，还需要约束  $ \vec{A} $ 的散度，才能唯一确定  $ \vec{A} $。而最简单的约束是：

 $$ \nabla\cdot\vec{A}=0 $$ 

2050 这一约束也被称为库仑规范（Coulomb gauge）。由上述约束以及磁场的环路定理，我们有：

 $$ \mu_{0}\vec{J}=\nabla\times\vec{B}=\nabla\times\nabla\times\vec{A}=\nabla(\nabla\cdot\vec{A})-\nabla^{2}\vec{A}=-\nabla^{2}\vec{A} $$ 

2051 即，我们得到了  $ \vec{A} $ 满足的微分方程：

 $$ \nabla^{2}\vec{A}=-\mu_{0}\vec{J} $$ 

2052 这个微分方程跟静电场的电势所满足的微分方程（泊松方程）是一致的，只不过这是个矢量方程，每个分量的方程便是一个泊松方程，其解也跟静电场的电势类似：