由此，对于各向同性线性均匀介质，我们可以先根据传导电流分布求出磁场强度  $ \vec{H} $ 的分布，而后根据介质的磁导率得到对应的总磁感应强度分布，从而省去了上一节最后提到的通过  $ \vec{M} $ 求解方程组得到有介质存在时的磁场分布的繁琐过程。

2318

### 例 7.1

有一个无限长的半径为  $ R $ 的圆柱形磁介质，介质的相对磁导率为  $ \mu_r > 1 $；介质内有沿轴向（ $ z $ 轴）的均匀传导电流，传导电流密度为  $ \vec{J}_0 $，求圆柱内外的  $ \vec{B}, \vec{H}, \vec{M} $，以及圆柱内部的磁化体电流密度  $ \vec{J}' $ 和圆柱表面的磁化面电流密度  $ \vec{K}' $。

解:

由对称性，离轴线距离为 r 处的  $ \vec{H} $ 大小相等，且方向为该处的圆周的切线方向。由对半径为 r 的圆周应用  $ \vec{H} $ 的环路定理：

<div style="text-align: center;"><img src="imgs/img_in_image_box_842_298_1035_664.jpg" alt="Image" width="16%" /></div>


 $$ \oint_{L}\vec{H}\cdot\mathrm{d}\vec{l}=\sum I_{0}\qquad\Rightarrow\qquad H=\frac{\sum I_{0}}{2\pi r} $$ 

2319 因此，

 $$ H(\vec{r})=\begin{cases}\frac{\pi r^{2}J_{0}}{2\pi r}=\frac{J_{0}r}{2},&r<R,\\\frac{\pi R^{2}J_{0}}{2\pi r}=\frac{J_{0}R^{2}}{2r},&r>R.\end{cases} $$ 

2320 对应的：

 $$ M(\vec{\mathbf{r}})=\chi_{m}H=\begin{cases}(\mu_{r}-1)\frac{J_{0}r}{2},&r<R,\\0,&r>R.\end{cases} $$ 

2321

 $$ B(\vec{\mathbf{r}})=\mu H=\begin{cases}\mu_{0}\mu_{r}\frac{J_{0}r}{2},&r<R,\\\mu_{0}\frac{J_{0}R^{2}}{2r},&r>R.\end{cases} $$ 

2322 可见，由于顺磁介质的存在，圆柱内的磁感应强度被增加了，其值是真空情况下的磁感应强度的  $ \mu_{r} $ 倍；而圆柱外的磁感应强度与真空情况下是一样的。

介质内的体磁化电流密度和面磁化电流密度分别为:

 $$ \vec{\boldsymbol{J}}^{\prime}(\vec{\boldsymbol{r}})=\nabla\times\vec{\boldsymbol{M}}=\chi_{m}\nabla\times\vec{\boldsymbol{H}}=\chi_{m}\vec{\boldsymbol{J}}_{0}=\begin{cases}(\mu_{r}-1)\vec{\boldsymbol{J}}_{0},&r<R,\\0,&r>R.\end{cases} $$ 

 $$ \vec{K}^{\prime}=\vec{M}(r=R)\times\vec{n}=-(\mu_{r}-1)\frac{J_{0}R}{2}\hat{z} $$ 

2325 易知，介质内的总磁化电流为零，即：

 $$ I_{s u m}^{\prime}=\iiint\vec{\boldsymbol{J}}^{\prime}\mathrm{d}S+\oint\vec{\boldsymbol{K}}^{\prime}\mathrm{d}l=(\mu_{r}-1)J_{0}\pi R^{2}-(\mu_{r}-1)\frac{J_{0}R}{2}2\pi R=0 $$ 