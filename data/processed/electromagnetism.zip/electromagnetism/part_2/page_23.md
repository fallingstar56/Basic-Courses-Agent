1887

### 例 6.3

如右图所示为亥姆霍兹（Helmholtz）线圈示意图，它由一对间距等于半径的同轴载流圆线圈组成。求其轴线上的磁场，并分析该线圈产生的磁场在轴线中心附近的变化。

<div style="text-align: center;"><img src="imgs/img_in_image_box_832_169_1035_353.jpg" alt="Image" width="17%" /></div>


解:

该线圈在轴线上产生的磁场为两个圆形电流产生的磁场的叠加，由上一例题结果，可知：

 $$ B=B_{1}+B_{2}=\frac{\mu_{0}IR^{2}}{2[R^{2}+(x+\frac{a}{2})^{2}]^{3/2}}+\frac{\mu_{0}IR^{2}}{2[R^{2}+(x-\frac{a}{2})^{2}]^{3/2}} $$ 

1889 为分析其在轴线中心附近的变化情况，将 B 对 x 求导数：

 $$ \frac{\mathrm{d}B}{\mathrm{d}x}=-\frac{3\mu_{0}IR^{2}}{2}\left[\frac{x+\frac{a}{2}}{[R^{2}+(x+\frac{a}{2})^{2}]^{5/2}}+\frac{x-\frac{a}{2}}{[R^{2}+(x-\frac{a}{2})^{2}]^{5/2}}\right] $$ 

1890 将 x = 0 代入，可得：

 $$ \left(\frac{\mathrm{d}B}{\mathrm{d}x}\right)_{x=0}=0 $$ 

1891 二阶导数为：

 $$ \frac{\mathrm{d}^{2}B}{\mathrm{d}x^{2}}=-\frac{3\mu_{0}IR^{2}}{2}\bigg[\frac{R^{2}-4(x+\frac{a}{2})^{2}}{[R^{2}+(x+\frac{a}{2})^{2}]^{7/2}}+\frac{R^{2}-4(x-\frac{a}{2})^{2}}{[R^{2}+(x-\frac{a}{2})^{2}]^{7/2}}\bigg] $$ 

1892 将 x = 0 代入，可得：

 $$ \left(\frac{\mathrm{d}^{2}B}{\mathrm{d}x^{2}}\right)_{x=0}=-3\mu_{0}IR^{2}\frac{R^{2}-a^{2}}{(R^{2}+a^{2}/4)^{7/2}} $$ 

1893 注意到对亥姆霍兹线圈，a = R，因此：

 $$ \left(\frac{\mathrm{d}^{2}B}{\mathrm{d}x^{2}}\right)_{x=0}=0 $$ 

1894 三阶导数为：

 $$ \frac{\mathrm{d}^{3}B}{\mathrm{d}x^{3}}=\frac{3\mu_{0}IR^{2}}{2}\bigg[\frac{(x+\frac{a}{2})[15R^{2}-20(x+\frac{a}{2})^{2}]}{[R^{2}+(x+\frac{a}{2})^{2}]^{9/2}}+\frac{(x-\frac{a}{2})[15R^{2}-20(x-\frac{a}{2})^{2}]}{[R^{2}+(x-\frac{a}{2})^{2}]^{9/2}}\bigg] $$ 

1895 将 x = 0 代入，可得：

 $$ \left(\frac{\mathrm{d}^{3}B}{\mathrm{d}x^{3}}\right)_{x=0}=0 $$ 

1896 即  $ B(x) $ 的一、二、三阶导数在 x=0 处都为零，意味着  $ B(x) $ 在 x=0 处无极值，且其附近的磁场变化只有四阶以上高次项小量：

1897

 $$ B(x)=B(0)+\frac{x^{4}}{4!}\bigg(\frac{\mathrm{d}^{4}B}{\mathrm{d}x^{4}}\bigg)_{x=0} $$ 

1898 其变化的相对值非常小。实际计算后发现，我们可以用  $ (B(x)-B(0))/B(0)\sim-x^{4}/R^{4} $ 来近似计算四阶项的大小：当 x=R/2 时， $ (B(x)-B(0))/B(0)\sim-6\% $; 当 x=R/4 时， $ (B(x)-B(0))/B(0)\sim-6\% $;