1914 分、线积分)。

我们先来计算一下磁场  $ \vec{B} $ 的散度，由6.19式，我们有：

 $$ \nabla\cdot\vec{B}(\vec{r})=\nabla\cdot\int_{V^{\prime}}\frac{\mu_{0}\vec{J}(\vec{r}^{\prime})\times(\vec{r}-\vec{r}^{\prime})}{4\pi|\vec{r}-\vec{r}^{\prime}|^{3}}\mathrm{d}V^{\prime}=-\frac{\mu_{0}}{4\pi}\nabla\cdot\int_{V^{\prime}}\vec{J}(\vec{r}^{\prime})\times\nabla\frac{1}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

1916 利用旋度链式法则  $ \nabla \times (\phi \vec{a}) = (\nabla \phi) \times \vec{a} + \phi (\nabla \times \vec{a}) $ （见习题1.13），上式可写成：

 $$ \nabla\cdot\vec{B}(\vec{r})=\frac{\mu_{0}}{4\pi}\nabla\cdot\int_{V^{\prime}}\Big(\nabla\times\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}-\frac{\nabla\times\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\Big)\mathrm{d}V^{\prime}=\frac{\mu_{0}}{4\pi}\nabla\cdot\nabla\times\int_{V^{\prime}}\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

1917 由恒等式  $ \nabla \cdot \nabla \times \vec{a} = 0 $ （见习题1.1），可知：

 $$ \nabla\cdot\vec{B}=0 $$ 

1919 其对应的积分形式为：

 $$ \iint_{\vec{S}}\vec{B}\cdot\mathrm{d}\vec{S}=0 $$ 

1921 上述公式也被称为磁场的高斯定理。

1922 下面我们求磁场  $ \vec{B} $ 的旋度。由类似于上文6.46和6.47式的过程，我们有：

 $$ \nabla\times\vec{B}(\vec{r})=\frac{\mu_{0}}{4\pi}\nabla\times\int_{V^{\prime}}\nabla\times\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime}=\frac{\mu_{0}}{4\pi}\int_{V^{\prime}}\nabla\times(\nabla\times\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|})\mathrm{d}V^{\prime} $$ 

1923 利用矢量恒等式  $ \nabla \times (\nabla \times \vec{a}) = \nabla (\nabla \cdot \vec{a}) - \nabla^2 \vec{a} $ (见习题1.1) 及链式法则  $ \nabla \cdot (\phi \vec{a}) = \phi \nabla \cdot \vec{a} + (\nabla \phi) \cdot \vec{a} $ (见习题1.13)，可知：

 $$ \nabla\times(\nabla\times\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|})=\nabla(\nabla\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|})-\nabla^{2}\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|} $$ 

1925 由于  $ \vec{J}(\vec{r}^{\prime}) $ 不含  $ \vec{r} $ 坐标，因此，

 $$ \nabla\times(\nabla\times\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|})=\nabla(\nabla\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|})-\vec{J}(\vec{r}^{\prime})\nabla^{2}\frac{1}{|\vec{r}-\vec{r}^{\prime}|} $$ 

1926 再利用  $ \nabla^{2}\frac{1}{|\vec{r}-\vec{r}^{\prime}|}=-\nabla\cdot\frac{\vec{r}-\vec{r}^{\prime}}{|\vec{r}-\vec{r}^{\prime}|^{3}}=-4\pi\delta(\vec{r}-\vec{r}^{\prime}) $，可知，

 $$ \nabla\times(\nabla\times\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|})=\nabla(\nabla\cdot\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|})+4\pi\delta(\vec{r}-\vec{r}^{\prime})\vec{J}(\vec{r}^{\prime}) $$ 