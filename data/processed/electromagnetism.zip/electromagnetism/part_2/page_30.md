1973 因此， $ B_{总,y}=0,B_{总,z}=0 $，即镜面上任意一点的总磁场  $ \vec{B}_{总} $ 与镜面垂直。

根据上面这个结论，我们知道，所求横截面上任意一点的磁感应强度  $ \vec{B} $ 只有 z 方向的分量。下面，我们先来看在螺线管内部任意一点的  $ \vec{B} $ 的大小，为此，我们作如右图所示的矩形闭合曲线，其上下两边长度为 l，左右两边高度为 h，则由安培环路定理：

 $$ 0=\oint\vec{B}\cdot\mathrm{d}\vec{l}=B_{ 上 ,z}l-B_{ 下 ,z}l+B_{ 左 ,y}h-B_{ 右 ,y}h $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_786_216_1034_411.jpg" alt="Image" width="20%" /></div>


1975 其中， $ B_{左,y}=B_{右,y}=0 $，因此，

 $$ B_{ 上 ,z}=B_{ 下 ,z}\quad\Rightarrow\quad B_{ 上 }=B_{ 下 } $$ 

1976 因此，在所求横截面上，螺线管内部磁感应强度处处相等，均等于  $ \vec{B}_{0} $。

下面，我们再来看在螺线管外部任意一点的  $ \bar{B} $ 的大小，为此，我们作如右图所示的矩形闭合曲线，其上下两边长度为 l，左右两边高度为 h，则由安培环路定理：

 $$ \oint\vec{B}\cdot\mathrm{d}\vec{l}=B_{ 内 }l-B_{ 外 }l=n\mu_{0}I l $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_787_624_1035_814.jpg" alt="Image" width="20%" /></div>


1978 其中， $ B_{内}=B_{0}=n\mu_{0}I\cos\theta $，因此，

 $$ B_{ 外 }=n\mu_{0}I(\cos\theta-1) $$ 

1979 该值为负值，表示方向为指向 -z 轴方向。

综上所述，长直螺线管的中心横截面上各处的磁感应强度为：

 $$ \vec{B}_{ 内 }=n\mu_{0}I\cos\theta\hat{z},\quad\vec{B}_{ 外 }=n\mu_{0}I(\cos\theta-1)\hat{z} $$ 

1981 注意到，对于无限长直螺线管， $ \cos\theta=1 $，因此：

 $$ \vec{B}_{ 内 }=n\mu_{0}I\hat{z},\quad\vec{B}_{ 外 }=0 $$ 

2 且对无限长螺线管而言，任意一个横截面都可以看成是中心处的横截面（即上文说的镜面），也就是说，上式对无限长直螺线管内外任意一点的磁感应强度都适用，即内部为均匀场，B 的大小为  $ \mu_{0}nI $，外部磁感应强度为 0。

1985 对于一般情况，即不是无限长的螺线管，但是  $ L \gg R $ 的情况，我们可以计算一下螺线管内外的磁感应强度之比，由6.80式，我们有：

 $$ \frac{B_{ 外 }}{B_{ 内 }}=1-\frac{1}{\cos\theta}=1-\frac{\sqrt{R^{2}+(L/2)^{2}}}{L/2}\approx1-\left(1+\frac{1}{2}4\frac{R^{2}}{L^{2}}\right)=-2\frac{R^{2}}{L^{2}} $$ 