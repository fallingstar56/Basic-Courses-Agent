1934 其中， $ \vec{S}' $ 为无穷大空间的表面，当电流分布有界时， $ \vec{J}(\vec{r}') $ 在无穷远处为 0，因此，

 $$ \nabla\times\vec{B}(\vec{r})=\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}(\vec{r})}{\partial t}+\mu_{0}\vec{J}(\vec{r}) $$ 

1935 对静磁场，其产生的源为稳恒电流，对应的电场分布（或者电荷分布）不随时间变化，因此，

1936

 $$ \nabla\times\vec{B}=\mu_{0}\vec{J} $$ 

1937 对应的积分形式为：

 $$ \oint_{C}\vec{B}\cdot\mathrm{d}\vec{l}=\mu_{0}\iint_{\vec{S}}\vec{J}\cdot\mathrm{d}\vec{S}=\mu_{0}I $$ 

1938

其中，C 为任意闭合曲线，I 为穿过该闭合曲线所围的曲面  $ \bar{S} $ 的所有电流的代数和，I 的正值的方向与闭合路径成右手螺旋。上述公式也被称为安培环路定理。

至此，我们便从毕奥-萨伐尔定律和叠加原理出发，推导出了真空中静磁场的基本方程：

定理 6.1 真空中静磁场的基本定理（高斯定理 + 安培环路定理）

 $$ \nabla\cdot\vec{B}=0 $$ 

 $$ \iint_{\vec{S}}\vec{B}\cdot\mathrm{d}\vec{S}=0 $$ 

1942

 $$ \nabla\times\vec{B}=\mu_{0}\vec{J}(\vec{r})\quad\oint_{C}\vec{B}\cdot\mathrm{d}\vec{l}=\mu_{0}I $$ 

与静电场中的高斯定理和环路定理类似，在有对称性的情况下，利用静磁场的高斯定理和环路定理可以使很多磁场的计算变得简洁许多，下面我们将举几个常见的例子来进行分析。

1945

### 例 6.5

求无限大平面电流产生的磁场分布（面电流密度为  $ \vec{K} $）。

解:

如图所示，对空间中任意一点 P，过 P 做垂直于电流平面的直线，作为 x 轴，在电流平面上以垂直电流方向为 y 轴。在 y 轴上取关于 O 点对称的两个点  $ O_{1} $ 和  $ O_{2} $，则由无限长线电流产生的磁场的特征易知过  $ O_{1} $ 和  $ O_{2} $ 的两个线电流在 P 点产生的磁场  $ \vec{B}_{1} $ 和  $ \vec{B}_{2} $ 的矢量和沿 y 轴方向，即：

 $ B_{x}=B_{z}=0. $

由对称性， $ B_{y} $ 在电流平面两侧对称的位置应该大小相等，方向相反。如图取一个垂直于电流的矩形回路，该矩形回路关于电流平面对称，长为 l，高为 h，则由安培环路定理：

<div style="text-align: center;"><img src="imgs/img_in_image_box_748_1078_1033_1324.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_755_1336_1023_1544.jpg" alt="Image" width="22%" /></div>
