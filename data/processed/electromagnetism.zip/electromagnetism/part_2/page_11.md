 $$ \begin{aligned}\mathrm{d}W&=q\vec{E}\cdot\mathrm{d}\vec{l}_{+}-q\vec{E}\cdot\mathrm{d}\vec{l}_{-}\\&=q\vec{E}\cdot(\mathrm{d}\vec{l}_{+}-\mathrm{d}\vec{l}_{-})\\&=q\vec{E}\cdot\mathrm{d}\vec{l}\\&=\vec{E}\cdot\mathrm{d}\vec{p}\end{aligned} $$ 

其中， $ \mathrm{d}\vec{p}=q\mathrm{d}\vec{l} $ 为 dt 时间段内电偶极矩的变化，由极化率的定义  $ \vec{p}=\alpha\vec{E} $ 可知  $ \mathrm{d}\vec{p}=\alpha\mathrm{d}\vec{E} $，因此：

 $$ \mathrm{d}W=\alpha\vec{E}\cdot\mathrm{d}\vec{E} $$ 

1700 因此，在电场逐渐建立的过程中，电偶极子在外场中被极化获得的能量为：

 $$ W=\int\mathrm{d}W=\int\alpha\vec{E}\cdot\mathrm{d}\vec{E}=\frac{1}{2}\alpha\vec{E}\cdot\vec{E}=\frac{1}{2}\vec{p}\cdot\vec{E} $$ 

1701 这便是介质中单个电偶极子在电场中由于极化所储存的静电能。

事实上，如果用能量储存在电荷体系中的观点来表示有介质存在时的静电能，与5.39式对应的表达式为：

 $$ W=\iiint_{V}\frac{1}{2}\rho_{0}U\mathrm{d}V=\iiint_{v}\frac{1}{2}(\rho_{0}+\rho^{\prime})U\mathrm{d}V+\iiint_{V}\frac{1}{2}(-\rho^{\prime})U\mathrm{d}V $$ 

704 其中， $ \rho_{0} $， $ \rho' $ 分别为自由电荷密度和极化电荷密度，U 为所有电荷产生的电势。也可以很容易证明，上式的第一项和第二项分别对应的是纯电场的静电能和极化能。

1706

### 5.4 电容

通过本章前面几节的学习我们知道，将电荷从各处分散的无穷远处搬运到特定位置建立一个带电体系的过程，就是我们克服电场力做功将能量储存在电荷体系（或者电场中）的过程。由本章第5.1节我们知道，克服电场力做的功，不仅取决于搬运电荷的数量，还取决于电荷最终所在位置的电势，电势越高，我们搬运单位电荷所需要做的功也就越多，也就是说搬运电荷的难度也就越大。我们把能够储存电荷的容器称为电容器（capacitor），比如一个导体等。由库仑定律，我们知道，一个电容器上的电势正比于上面的电荷的数量。为了表征将电荷搬运到容器上的难易程度（或者说表征该容器储存电荷的能力），我们定义一个新的物理量，叫电容（capacitance），它等于电容器上储存的电荷与该容器上的电势的比值：

 $$ C=\frac{Q}{U} $$ 

16 电容的单位为法拉（Farad），简称 F，1F = 1C/V。电容越大，表示搬运单位电荷到该电容器上所需做功越少，或者说该电容器储存电荷的能力越强。反过来讲，对于相同的电势，电容越高，电容器上储存的电荷也就越多，因而电容器储存的静电能也越多。