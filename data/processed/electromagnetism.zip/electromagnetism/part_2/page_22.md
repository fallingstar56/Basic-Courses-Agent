1871 度一样。而对于半无限长直线电流， $ \theta_{1}=0,\quad\theta_{2}=\pi/2 $，因而：

 $$ B=\frac{\mu_{0}I}{4\pi r_{0}} $$ 

1872

例 6.2

如右图所示，求半径为 R 的圆形载流导线在其轴线上 P 点产生的磁场。

<div style="text-align: center;"><img src="imgs/img_in_image_box_832_292_1035_442.jpg" alt="Image" width="17%" /></div>


1873 解:

如图，电流元  $ I d\vec{l} $ 在 P 点产生的磁场为：

 $$ \mathrm{d}\vec{B}=\frac{\mu_{0}I\mathrm{d}\vec{l}\times\vec{r}}{4\pi r^{3}}=\mathrm{d}\vec{B}_{\perp}+\mathrm{d}\vec{B}_{\parallel}=\frac{\mu_{0}I\mathrm{d}\vec{l}\times\overrightarrow{O P}}{4\pi r^{3}}+\frac{\mu_{0}I\mathrm{d}\vec{l}\times\overrightarrow{Q O}}{4\pi r^{3}} $$ 

1875因而，

 $$ \vec{B}=\vec{B}_{\perp}+\vec{B}_{\parallel}=\int\mathrm{d}\vec{B}_{\perp}+\int\mathrm{d}\vec{B}_{\parallel} $$ 

1876 由对称性，垂直方向分量  $ d\vec{B}_{\perp} $ 在圆周上相对的两处互相取消，即  $ \vec{B}_{\perp} = \int d\vec{B}_{\perp} = 0 $，因此：

 $$ B=B_{\parallel}=\int\frac{\mu_{0}I\mathrm{d}\vec{l}\times\overrightarrow{Q\vec{O}}}{4\pi r^{3}}=\int\frac{\mu_{0}IR\mathrm{d}l}{4\pi r^{3}}=\frac{\mu_{0}IR^{2}}{2r^{3}}=\frac{\mu_{0}IR^{2}}{2(R^{2}+z^{2})^{3/2}} $$ 

1877  $ \vec{B} $ 的方向与 z 轴的方向相同（与电流方向成右手螺旋关系）。

1. 在圆电流的中心，即 z = 0 时，

 $$ B=\frac{\mu_{0}I}{2R} $$ 

2. 当  $ z \gg R $ 时，

 $$ B\approx\frac{\mu_{0}IR^{2}}{2z^{3}}=\frac{\mu_{0}IS}{2\pi z^{3}} $$ 

其中，S 为电流回路的面积。可见，圆形电流在远处产生的磁场与距离的三次方成反比。这与电偶极子产生的电场随距离的衰减速度一样。

我们把载有电流的圆形回路称为磁偶极子（magnetic dipole），与电偶极子的电偶极矩类似，对磁偶极子，我们也定义它的磁偶极矩（magnetic dipole moment），用符号  $ \vec{m} $（有时也用  $ \vec{p}_{m} $）表示：

 $$ \vec{m}=I\vec{S} $$ 

1885 其中  $ \vec{S} $ 为圆形回路的面积，其方向与电流的方向成右手螺旋关系。根据这一定义，磁偶极子在 1886 远处其中轴线上产生的磁场为：

 $$ \vec{B}=\frac{\mu_{0}\vec{m}}{2\pi z^{3}} $$ 