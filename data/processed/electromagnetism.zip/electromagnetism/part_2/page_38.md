时会相互吸引或排斥的原因（同极相斥、异极相吸）。感兴趣的读者，不妨分析一下两个同轴的圆形电流之间，其中一个圆形电流产生的磁场对另一个圆形电流的作用力。

矩形电流在均匀磁场中所受磁场的合力为零，是否意味着载有矩形电流的线圈在均匀磁场中就静止不动呢？为了分析这个问题，我们不妨以最简单的矩形线圈为例。如右图所示，假定矩形线圈 ABCD 的 BC 和 DA 两边与磁场垂直，另外两边与磁场方向在同一平面，则由安培力公式，可知各边受到的磁场力关系如下：

 $$ \vec{F}_{AB}=-\vec{F}_{CD},\qquad\vec{F}_{BC}=-\vec{F}_{DA} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_829_264_1035_498.jpg" alt="Image" width="17%" /></div>


取与磁场垂直的  $ OO' $ 轴，则由图可知， $ F_{AB} $ 和  $ F_{CD} $ 均与  $ OO' $ 平行，且它们在一条直线上，如果线圈是刚体的话，这一对力不会产生任何运动学作用。而  $ \vec{F}_{BC} $ 和  $ \vec{F}_{DA} $ 则均与  $ OO' $ 垂直，但是它们不在一条直线上，因此这一对力虽然合力为零，但是它们组成了一个绕  $ OO' $ 轴的力矩，使得线圈绕  $ OO' $ 轴做转动。设线圈所在平面与  $ \vec{B} $ 的夹角为  $ \theta $，则绕  $ OO' $ 轴的力矩的大小为：

 $$ M=F_{1}d_{1}\cos\theta+F_{2}d_{2}\cos\theta=IBh(d_{1}+d_{2})\cos\theta=IBhd\cos\theta $$ 

2126 注意到，上式对应的矢量形式的力矩刚好为：

 $$ \vec{M}=\vec{m}\times\vec{B} $$ 

2127 其中， $ \vec{m} $ 为线圈的磁偶极矩  $ (m = Ihd) $。

上面利用矩形线圈计算得出的闭合电流在均匀磁场中受到的力矩，对任意形状的平面线圈是否也适用呢？答案是肯定的。如右图所示，设有如图所示的任意形状的平面线圈。我们沿着  $ \vec{B} $ 的方向，将这个线圈切割成无数对电流元，选取其中的一对电流元 DA 和 BC，我们注意到，这两段电流元受到的磁场力的与  $ OO' $ 垂直方向的分量正好大小相等，方向相反，大小为：

 $$ \mathrm{d}F=IB\mathrm{d}h $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_830_927_1034_1165.jpg" alt="Image" width="17%" /></div>


2129 其中，dh 为 AB 至 DC 之间的距离。因此，这两段电流元受到的总力矩为：

 $$ \mathrm{d}M=\mathrm{d}F\mathrm{d}\cos\theta=IB\mathrm{d}\mathrm{d}h\cos\theta $$ 

2130 其中，d 为 AB 之间的距离，注意到  $ ddh = dS = S_{ABCD} $，因此，

 $$ \mathrm{d}M=IB\cos\theta\mathrm{d}S $$ 

2131 积分可得整个平面线圈受到的总力矩：

 $$ M=\int\mathrm{d}M=IBS\cos\theta $$ 