在解决了如何测量 F 的问题之后，我们再回到最初的那个问题，我们如何从测量长直导线给磁针的力  $ F(I,r) $，反推出电流元对磁针的力  $ \mathrm{d}F(I,\mathrm{d}l,r,\alpha) $ 呢？显然，这里最起码还需要角度这个变量，为了研究这个变量，毕奥和萨伐尔的做法是将无限长导线在其中间弯折。如右图所示，设弯折后任意一个导线与转折点到 P 点之间连线的夹角是  $ \alpha $，毕奥和萨伐尔通过控制变量法得到了这根弯折的导线对 P 点的磁针的作用力与 I,r, $ \alpha $ 之间的关系  $ F(I,r,\alpha) $：

<div style="text-align: center;"><img src="imgs/img_in_image_box_878_164_1040_332.jpg" alt="Image" width="13%" /></div>


1835 1. 改变 I，可得到 F 与 I 之间的关系，结果为： $ F \propto I $

2. 改变 r，可得到 F 与 r 之间的关系，结果为： $ F \propto \frac{1}{r} $

3. 改变  $ \alpha $，可得到 F 与  $ \alpha $ 之间的关系，结果为： $ F \propto \tan \frac{\alpha}{2} $

1838 综上，毕奥和萨伐尔的实验结果为：

 $$ F(I,r,\alpha)=k\frac{I}{r}\tan\frac{\alpha}{2} $$ 

1839 很显然，上面得到的弯折的导线对 P 点的磁针的作用力，可以分解成大小相等的上下两段半无限长的导线对 P 点的磁针的作用力，也就是说，夹角为  $ \alpha $ 的一个半无限长的导线对 P 点的磁针的作用力也遵循6.8式的关系。

1842 那么，得到了半无限长的导线产生的力  $ F(I,r,\alpha) $ 后，我们如何进一步推导出电流元 Idl 对 P 点的磁针产生的作用力  $ \mathrm{d}F(I,\mathrm{d}l,r,\alpha) $ 呢？如右图所示，我们不妨想象一下，给半无限长的导线加上一小段长度为  $ dl $ 的电流微元，则在加上这一小段电流微元之后，P 点的磁针受到的力的变化（也即我们最终想求解的加上的这一小段电流元对 P 点的磁针的作用力）为：



<div style="text-align: center;"><img src="imgs/img_in_image_box_832_901_1036_1051.jpg" alt="Image" width="17%" /></div>


 $$ \begin{aligned}\mathrm{d}F(I,\mathrm{d}l,r,\alpha)&=F(I,r+\mathrm{d}r,\alpha+\mathrm{d}\alpha)-F(I,r,\alpha)\\&=\frac{\partial F}{\partial r}\mathrm{d}r+\frac{\partial F}{\partial\alpha}\mathrm{d}\alpha\\&=\frac{\partial F}{\partial r}\frac{\mathrm{d}r}{\mathrm{d}l}\mathrm{d}l+\frac{\partial F}{\partial\alpha}\frac{\mathrm{d}\alpha}{\mathrm{d}l}\mathrm{d}l\\&=\left(\frac{\partial F}{\partial r}\frac{\mathrm{d}r}{\mathrm{d}l}+\frac{\partial F}{\partial\alpha}\frac{\mathrm{d}\alpha}{\mathrm{d}l}\right)\mathrm{d}l\end{aligned} $$ 

1843 其中，我们可以通过图中的几何关系得到  $ \frac{dr}{dl} $ 和  $ \frac{d\alpha}{dl} $ :

 $$ \mathrm{d}l\sin\alpha=(r+\mathrm{d}r)\sin(\mathrm{d}\alpha)\approx r\mathrm{d}\alpha\quad\Rightarrow\quad\frac{\mathrm{d}\alpha}{\mathrm{d}l}=\frac{\sin\alpha}{r} $$ 

1844

 $$ \mathrm{d}l\cos\alpha=r-(r+\mathrm{d}r)\cos(\mathrm{d}\alpha)\approx-\mathrm{d}r\quad\Rightarrow\quad\frac{\mathrm{d}r}{\mathrm{d}l}=-\cos\alpha $$ 