1642 计算结果，这是因为对于一个尺度为  $ \delta r $ 的电荷微元，其在自身处产生的电势为：

 $$ U_{self}\approx\frac{\delta q}{4\pi\varepsilon_{0}\delta r}\propto\frac{\rho(\delta r)^{3}}{4\pi\varepsilon_{0}\delta r}\propto(\delta r)^{2} $$ 

1643 当  $ \delta r \rightarrow 0 $ 的时候， $ U_{self} \rightarrow 0 $，因而

 $$ W_{self}=\frac{1}{2}\iiint_{V}U_{self}\rho(\vec{r})\mathrm{d}V=0 $$ 

同样的道理，对面电荷密度有限的面电荷体系，其静电自能也为零。而对于线电荷分布，其在自身电荷存在的地方电势为无穷大，例如，对于长度为 L、线电荷密度为  $ \lambda $ 的线电荷，其中心点的电势为：

 $$ U=\frac{2}{4}\pi\varepsilon_{0}\int_{0}^{L/2}\frac{\lambda\mathrm{d}x}{x}=\frac{2\lambda}{4\pi\varepsilon_{0}}\ln x\bigg|_{0}^{L/2}=\infty $$ 

1647 因而线电荷体系的静电自能也是发散的。

那么，对于点电荷这种静电自能发散的带电体系，我们能否用静电能储存在电场中这个观念得出的诸如5.19式来计算静电场的能量呢？很显然，对于孤立的点电荷，由5.19式计算得出的静电能为：

 $$ W=\iiint_{V}\frac{1}{2}\varepsilon_{0}E^{2}\mathrm{d}V=\int_{0}^{\infty}\frac{1}{2}\varepsilon_{0}\left(\frac{q}{4\pi\varepsilon_{0}r^{2}}\right)^{2}4\pi r^{2}\mathrm{d}r\propto\int_{0}^{\infty}\frac{1}{r^{2}}\mathrm{d}r=\infty $$ 

1651 即得到的能量也是发散的，这便是该孤立点电荷的静电自能。对于多个点电荷，由5.19式计算得出的静电能为：

 $$ \begin{aligned}W&=\iiint_{V}\frac{1}{2}\varepsilon_{0}\vec{E}\cdot\vec{E}\mathrm{d}V\\&=\frac{1}{2}\varepsilon_{0}\iiint_{V}(\sum_{i}\vec{E}_{i})\cdot(\sum_{i}\vec{E}_{i})\mathrm{d}V\\&=\frac{1}{2}\varepsilon_{0}\iiint_{V}\Big(\sum_{i}(\vec{E}_{i}\cdot\vec{E}_{i})+\sum_{i}\sum_{j\neq i}(\vec{E}_{i}\cdot\vec{E}_{j})\Big)\mathrm{d}V\\&=\sum_{i}\frac{1}{2}\varepsilon_{0}\iiint_{V}\vec{E}_{i}\cdot\vec{E}_{i}\mathrm{d}V+\sum_{i}\sum_{j\neq i}\frac{1}{2}\varepsilon_{0}\iiint_{V}\vec{E}_{i}\cdot\vec{E}_{j}\mathrm{d}V\\ \end{aligned} $$ 

其中， $ \vec{E}_i $ 表示电荷  $ q_i $ 产生的电场。很显然，上式中的  $ \frac{1}{2}\varepsilon_0\iiint_V \vec{E}_i \cdot \vec{E}_i \, \mathrm{d}V $ 项，是单个点电荷产生的电场的静电自能，是发散的；那么，剩下的  $ \varepsilon_0\iiint_V \vec{E}_i \cdot \vec{E}_j \, \mathrm{d}V $ 项，是否就跟  $ q_i U_{ji} $ 对应，是电荷  $ q_i $ 和  $ q_j $ 之间的相互作用能呢？为了回答这个问题，我们不妨令：

 $$ W_{ij}^{a}=q_{i}U_{ji}=\frac{q_{i}q_{j}}{4\pi\varepsilon_{0}\left|r_{i}-r_{j}\right|} $$ 

 $$ W_{ij}^{b}=\iiint_{V}\varepsilon_{0}\vec{E}_{i}\cdot\vec{E}_{j}\mathrm{d}V $$ 

1656 下面，我们来证明，上述两种方法计算得出的相互作用能，是相等的，即  $ W_{ij}^{a} = W_{ij}^{b} $ 。展开  $ W_{ij}^{b} $