 $$ \oint\vec{B}\cdot\mathrm{d}\vec{l}=2B_{y}l=\mu_{0}I=\mu_{0}K l\quad\Rightarrow\quad B_{y}=\frac{\mu_{0}K}{2} $$ 

1946 即：无限大平面电流在其两侧产生的磁场为均匀磁场，且在电流平面两侧大小相等，方向相反（± $ \hat{y} $方向），其值为：

 $$ B=\frac{\mu_{0}K}{2} $$ 

1948 例 6.6

求半径为 R 的无限长圆柱形导线产生的磁场（导线内为均匀电流，电流密度为  $ \vec{J} $）。

1950 解:

如图所示，在垂直于电流方向的截面上，取一以圆柱轴线所在位置为圆心的半径为 r 的圆，由对称性，导线内的电流产生的磁场在该圆上各点处处大小相等，且方向沿各点处的圆的切线方向。

<div style="text-align: center;"><img src="imgs/img_in_image_box_369_701_609_921.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_659_730_815_886.jpg" alt="Image" width="13%" /></div>


1954

1955 由安培环路定理：

 $$ \oint\vec{B}\cdot\mathrm{d}\vec{l}=2\pi r B=\mu_{0}I_{ 内 }\quad\Rightarrow\quad B=\frac{\mu_{0}I_{ 内 }}{2\pi r} $$ 

1956 当 r < R 时:

 $$ B=\frac{\mu_{0}I_{ 内 }}{2\pi r}=\frac{\mu_{0}J\pi r^{2}}{2\pi r}=\frac{\mu_{0}Jr}{2} $$ 

1957 当 r > R 时:

 $$ B=\frac{\mu_{0}I_{ 内 }}{2\pi r}=\frac{\mu_{0}J\pi R^{2}}{2\pi r}=\frac{\mu_{0}I}{2\pi r} $$ 

1958 这与例6.1中通过直接使用毕奥-萨伐尔定律积分得出的6.23式是一致的。

例 6.7

半径为 R 的无限长圆柱形导线其内部挖掉了一个半径为 r 的小圆柱空腔，如图所示为其截面示意图，导线内电流密度为  $ \vec{J} $ 。求空腔内的磁场分布。

<div style="text-align: center;"><img src="imgs/img_in_image_box_835_1312_1028_1500.jpg" alt="Image" width="16%" /></div>


解: