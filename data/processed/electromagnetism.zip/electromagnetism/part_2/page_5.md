1606

### 5.2 静电场的能量

上一节中我们讨论的静电能，其本质是电荷之间的相互作用的能量，也就是说这里的静电能存在的基础是电荷的存在，能量储存在了电荷体系中。这一观点，对于处理静电场是没有问题的，但是，这种观点在我们本书后续章节要学习的随时间变化的电场以及电磁波的传播时会失效，因为按照这种观点，在没有电荷的地方，是没有静电能的，因而能量自然也不会在没有电荷的空间进行传播，而这与我们后面将要学习到的电磁波中存在能量的流动是矛盾的。

另一种更加普适的观点，是认为能量储存在电场本身中，即有电场的地方就有电场能，其存在不依赖于电荷的存在与否，整个体系的总电场能等于全空间的电场的能量密度的积分。那么，假如我们认为静电能储存在电场中，对于上一节我们分析的源自于带电体系之间的相互作用的静电能，它所对应的电场的能量密度是怎样的形式呢？

我们不妨从5.9式出发，利用高斯定理 ( $ \rho = \varepsilon_0 \nabla \cdot \vec{E} $) 代替该式中的电荷密度  $ \rho $，可得：

 $$ \begin{aligned}W&=\frac{1}{2}\iiint_{V}U\rho\mathrm{d}V\\&=\frac{1}{2}\iiint_{V}U(\varepsilon_{0}\nabla\cdot\vec{E})\mathrm{d}V\\&=\frac{1}{2}\varepsilon_{0}\iiint_{V}U\nabla\cdot\vec{E}\mathrm{d}V\end{aligned} $$ 

1617 利用散度的乘积法则（即： $ \nabla \cdot (U \vec{E}) = U \nabla \cdot \vec{E} + (\nabla U) \cdot \vec{E} $）（见习题1.13），上式可写成：

 $$ W=\frac{1}{2}\varepsilon_{0}\iiint_{V}\nabla\cdot(U\vec{E})\mathrm{d}V-\frac{1}{2}\varepsilon_{0}\iiint_{V}(\nabla U)\cdot\vec{E}\mathrm{d}V $$ 

1618 利用高斯定理可以将上式的第一项写成面积分的形式：

 $$ W=\frac{1}{2}\varepsilon_{0}\iint_{\vec{S}}U\vec{E}\cdot\mathrm{d}\vec{S}-\frac{1}{2}\varepsilon_{0}\iiint_{V}\left(\nabla U\right)\cdot\vec{E}\mathrm{d}V $$ 

注意到上式积分的空间 V 是有电场存在的全空间，而  $ \bar{S} $ 则是全空间对应的闭合曲面，当电荷分布有界的时候，在  $ r \to \infty $ 时，

 $$ U(r)\propto\frac{1}{r},\quad E(r)\propto\frac{1}{r^{2}},\quad S\propto r^{2}\quad\Rightarrow\int_{\vec{S}}U\vec{E}\cdot\mathrm{d}\vec{S}\propto\frac{1}{r}\rightarrow0 $$ 

1621 因而，

 $$ W=-\frac{1}{2}\varepsilon_{0}\iiint_{V}\left(\nabla U\right)\cdot\vec{E}\mathrm{d}V=\frac{1}{2}\varepsilon_{0}\iiint_{V}\vec{E}\cdot\vec{E}\mathrm{d}V=\iiint_{V}\frac{1}{2}\varepsilon_{0}E^{2}\mathrm{d}V $$ 

即：若我们认为静电能储存在电场中，那么系统的总静电能为：

 $$ W=\iiint_{V}w_{e}\mathrm{d}V=\iiint_{V}\frac{1}{2}\varepsilon_{0}E^{2}\mathrm{d}V $$ 

其中， $ w_{e}=\frac{1}{2}\varepsilon_{0}E^{2} $ 为任意一点的电场能量密度。也就是说，电场强度越大的地方，能量密度也越大，这与我们的直觉是相符的。