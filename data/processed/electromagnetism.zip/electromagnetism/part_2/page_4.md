 $$ W=\frac{1}{2}\sum_{i=1}^{n}q_{i}U_{i} $$ 

对于连续分布的电荷体系，其静电能为：

 $$ W=\frac{1}{2}\int_{Q}U\mathrm{d}q=\frac{1}{2}\iiint_{V}U(\vec{\boldsymbol{r}})\rho(\vec{\boldsymbol{r}})\mathrm{d}V $$ 

00 其中，U 为电荷元 dq （或体积元 dV）处的电势，上式的积分范围为带电体系的所有电荷 Q （或全空间 V）。

1602

### 例 5.1

一半径为 R，带电量为 Q 的均匀带电球体，求其静电能。

解:

<div style="text-align: center;"><img src="imgs/img_in_image_box_832_565_1035_764.jpg" alt="Image" width="17%" /></div>


如图所示，将带电球体分成多个同心薄球壳，设半径为 r 处的电势为  $ U(r) $，内外半径为 r 和  $ r + dr $ 的球壳所带电荷为 dq，则该带电球体的静电能为：

 $$ W=\frac{1}{2}\iiint_{V}U(\vec{r})\rho(\vec{r})\mathrm{d}V $$ 

1603 下面我们来计算  $ U(r) $：由例2.10，我们知道，该均匀带电球产生的电场为：

 $$ \vec{E}(\vec{r})=\begin{cases}\frac{Qr}{4\pi\varepsilon_{0}R^{3}}\hat{\boldsymbol{r}},&r<R,\\\frac{Q}{4\pi\varepsilon_{0}r^{2}}\hat{\boldsymbol{r}},&r\geq R.\end{cases} $$ 

1604 因此，球内部半径为 r 处的电势为：

 $$ \begin{aligned}U(r)&=\int_{r}^{R}\vec{E}\cdot\mathrm{d}\vec{r}+\int_{R}^{\infty}\vec{E}\cdot\mathrm{d}\vec{r}\\&=\int_{r}^{R}\frac{Qr}{4\pi\varepsilon_{0}R^{3}}\mathrm{d}r+\int_{R}^{\infty}\frac{Q}{4\pi\varepsilon_{0}r^{2}}\mathrm{d}r\\&=\frac{Q(R^{2}-r^{2})}{8\pi\varepsilon_{0}R^{3}}+\frac{Q}{4\pi\varepsilon_{0}R}\\&=\frac{Q}{8\pi\varepsilon_{0}R^{3}}(3R^{2}-r^{2})\\ \end{aligned} $$ 

1605 代入5.10式可得：

 $$ \begin{aligned}W&=\frac{1}{2}\int_{0}^{R}\frac{Q}{8\pi\varepsilon_{0}R^{3}}(3R^{2}-r^{2})\frac{Q}{\frac{4}{3}\pi R^{3}}4\pi r^{2}\mathrm{d}r\\&=\frac{3Q^{2}}{20\pi\varepsilon_{0}R}\end{aligned} $$ 