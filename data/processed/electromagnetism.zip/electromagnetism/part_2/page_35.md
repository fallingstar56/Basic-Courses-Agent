 $$ \vec{A}(\vec{r})=\frac{\mu_{0}}{4\pi}\iiint_{V^{\prime}}\frac{\vec{J}(\vec{r}^{\prime})}{|\vec{r}-\vec{r}^{\prime}|}\mathrm{d}V^{\prime} $$ 

事实上，上式关于电流系统产生的磁场的矢量势的公式我们早在证明亥姆霍兹定理的时候就已经得到了，即由证明过程中得到的6.104式加上  $ \nabla \times \vec{B} = \mu_0 \vec{J} $ 便可得到上式。

有了磁矢势的定义，我们便可以通过电流分布先计算磁矢势，然后对磁矢势求旋度来计算磁感应强度分布。与毕奥-萨伐尔定律中需要先对两个矢量做叉乘再积分不同的是，通过电流元计算磁矢势只有单个矢量的体积分，在有些情况下有可能会给我们计算带来一定的简化。此外，由6.112式可知，电流体系产生的  $ \vec{A} $ 的方向趋向于与电流的方向一致，比如，直线电流的  $ \vec{A} $ 也为直线状，而环形电流的  $ \vec{A} $ 也为环形状……

2062

### 例 6.10

用磁矢势的方法，求电流环在远处任意一点产生的磁场。

解:

如图所示建立坐标系，其中，电流环位于 xy 平面，圆心位于坐标原点；P 点位于 xz 平面。则 P 点的  $ \vec{A} $ 为：

<div style="text-align: center;"><img src="imgs/img_in_image_box_745_568_1033_848.jpg" alt="Image" width="24%" /></div>


 $$ \vec{A}(\vec{r})=\frac{\mu_{0}}{4\pi}\iiint_{V^{\prime}}\frac{\vec{J}\mathrm{d}V^{\prime}}{|\vec{r}-\vec{r}^{\prime}|}=\frac{\mu_{0}I}{4\pi}\int_{\vec{r}^{\prime}}\frac{\mathrm{d}\vec{r}^{\prime}}{|\vec{r}-\vec{r}^{\prime}|} $$ 

2063 在直角坐标系中：

2064

 $$ \begin{aligned}\vec{\boldsymbol{r}}&=(r\sin\theta,0,r\cos\theta)\\\vec{\boldsymbol{r}}^{\prime}&=(R\cos\phi^{\prime},R\sin\phi^{\prime},0)\\|\vec{\boldsymbol{r}}-\vec{\boldsymbol{r}}^{\prime}|&=\sqrt{r^{2}+R^{2}-2rR\sin\theta\cos\phi^{\prime}}\\\mathrm{d}\vec{\boldsymbol{r}}^{\prime}&=(-\sin\phi^{\prime},\cos\phi^{\prime},0)R\mathrm{d}\phi^{\prime}\end{aligned} $$ 

2066

2067 因此，

 $$ A_{x}(\vec{r})=\frac{\mu_{0}IR}{4\pi}\int_{-\pi}^{\pi}\frac{-\sin\phi^{\prime}\mathrm{d}\phi^{\prime}}{\sqrt{r^{2}+R^{2}-2rR\sin\theta\cos\phi^{\prime}}} $$ 

2068 所积函数关于  $ \phi' $ 是奇函数，因此  $ A_{x}(\vec{r})=0 $，即  $ \vec{A}(\vec{r}) $ 只有 y 方向分量：

 $$ A_{y}(\vec{r})=\frac{\mu_{0}IR}{4\pi}\int_{-\pi}^{\pi}\frac{\cos\phi^{\prime}\mathrm{d}\phi^{\prime}}{\sqrt{r^{2}+R^{2}-2rR\sin\theta\cos\phi^{\prime}}} $$ 

2069 当  $ r \gg R $ 时，上式可以近似为：

 $$ \begin{aligned}A_{y}(\vec{r})&\approx\frac{\mu_{0}IR}{4\pi}\int_{-\pi}^{\pi}\frac{\cos\phi^{\prime}}{\sqrt{r^{2}+R^{2}}}(1+\frac{rR}{r^{2}+R^{2}}\sin\theta\cos\phi^{\prime})\mathrm{d}\phi^{\prime}\\&=\frac{\mu_{0}IR}{4\pi\sqrt{r^{2}+R^{2}}}(0+\frac{rR}{r^{2}+R^{2}}\pi\sin\theta)\\&\approx\frac{\mu_{0}IR^{2}\sin\theta}{4r^{2}}\end{aligned} $$ 