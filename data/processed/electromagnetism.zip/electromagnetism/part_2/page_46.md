2277 穿出这个面元。如上图所示，假设  $ \vec{m}_{z} $ 在  $ y + dy $ 处的值大于其在 y 处的值，则垂直纸面穿出这 2278 个面元的电流为：

 $$ I^{\prime}=K^{\prime}_{y}(y+\mathrm{d}y)\mathrm{d}z-K^{\prime}_{y}(y)\mathrm{d}z=(M_{z}(y+\mathrm{d}y)-M_{z}(y))\mathrm{d}z=\frac{\partial M_{z}}{\partial y}\mathrm{d}y\mathrm{d}z $$ 

类似的，对于 y 方向上的磁偶极矩  $ \vec{m}_{y} $ 对穿过这个面元的电流的贡献，我们可以看上图的右图的示意图，可知垂直纸面穿出这个面元的电流为：

 $$ I^{\prime}=K_{z}^{\prime}(z+\mathrm{d}z)\mathrm{d}y-K_{z}^{\prime}(z)\mathrm{d}y=(-M_{y}(z+\mathrm{d}z)+M_{y}(z))\mathrm{d}y=-\frac{\partial M_{y}}{\partial z}\mathrm{d}y\mathrm{d}z $$ 

2281 穿出面元 dydz 的总电流为  $ \vec{m}_{y} $ 和  $ \vec{m}_{z} $ 的贡献之和：

 $$ I^{\prime}=\frac{\partial M_{z}}{\partial y}\mathrm{d}y\mathrm{d}z-\frac{\partial M_{y}}{\partial z}\mathrm{d}y\mathrm{d}z=(\frac{\partial M_{z}}{\partial y}-\frac{\partial M_{y}}{\partial z})\mathrm{d}y\mathrm{d}z $$ 

2282 结合7.5式，可知：

 $$ J_{x}^{\prime}=\frac{\partial M_{z}}{\partial y}-\frac{\partial M_{y}}{\partial z} $$ 

2283 同样的方法，我们可以计算出 y, z 方向的体电流密度：

 $$ J^{\prime}_{y}=\frac{\partial M_{x}}{\partial z}-\frac{\partial M_{z}}{\partial x} $$ 

 $$ J_{z}^{\prime}=\frac{\partial M_{y}}{\partial x}-\frac{\partial M_{x}}{\partial y} $$ 

2284 写成矢量的形式为：

 $$ \vec{J}^{\prime}=\nabla\times\vec{M} $$ 

由此，我们便通过定义的磁化强度矢量 M，将微观层面的由外加磁场使物质内部磁化产生的磁偶极矩与宏观层面的磁化电流联系了起来。而且，与物质在电场中极化很类似的是，对于各向同性线性均匀介质，物质的磁化强度矢量  $ \vec{M} $ 将正比于总磁感应强度  $ \vec{B} $：

 $$ \vec{M}\propto\vec{B} $$ 

而且该比例系数为常数，且只与物质本身的性质有关（不受磁场等因素影响），因此，对于这类各向同性线性均匀介质，可以通过联合求解如下两个方程来计算有外加磁场存在的情况下（即给定传导电流分布  $ \vec{J}_{0} $）的磁场分布：

 $$ \nabla\times\vec{B}=\mu_{0}(\vec{J}_{0}+\vec{J}^{\prime})=\mu_{0}(\vec{J}_{0}+\nabla\times\vec{M}) $$ 

 $$ \vec{M}\propto\vec{B} $$ 