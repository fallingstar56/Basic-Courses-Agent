2007 系求出总电场：

 $$ \begin{aligned}&U(\vec{\mathbf{r}})=\iiint_{V^{\prime}}\frac{\rho(\vec{\mathbf{r}}^{\prime})\mathrm{d}V^{\prime}}{4\pi\varepsilon_{0}|\vec{\mathbf{r}}-\vec{\mathbf{r}}^{\prime}|}\\ &\vec{E}(\vec{\mathbf{r}})=-\nabla U(\vec{\mathbf{r}})\\ \end{aligned} $$ 

2008 那么，对于静磁场，是否存在于静电场类似的“磁势”呢？为了回答这个问题，我们不妨先回顾以下我们迄今总结出的磁场的基本定理：

 $$ \nabla\cdot\vec{B}=0,\qquad\nabla\times\vec{B}=\mu_{0}\vec{J}(\vec{r}) $$ 

2010 很显然，我们不能将  $ \vec{B} $ 写成某个标量的梯度（即形如  $ \vec{B} = \nabla U $ 的形式），否则由一下恒等 2011 式（见第一章习题1.1）：

 $$ \nabla\times\nabla\Phi=0 $$ 

2012 我们可知：

 $$ \nabla\times\vec{B}=\nabla\times\nabla U=0 $$ 

2013 这显然与上述6.87式矛盾。

2014 我们还注意到第一章习题1.1中的另一个恒等式：

 $$ \nabla\cdot(\nabla\times\vec{F})=0 $$ 

2015 此时，如果我们将  $ \vec{B} $ 写成某个矢量的旋度的形式（例如，令  $ \vec{B} = \nabla \times \vec{A} $），那上述恒等式正好与6.87式中的  $ \nabla \cdot \vec{B} = 0 $ 符合。

问题是，对任意的磁场  $ \vec{B} $，这样的矢量  $ \vec{A} $ 一定存在吗？

2018 答案是肯定的。不过，为了证明这一结论，我们有必要借助一下矢量分析中的一个常用定理，叫亥姆霍兹定理：

### 定理 6.2 亥姆霍兹定理

任意足够光滑、快速衰减（衰减速度大于  $ 1/r $）的三维矢量场  $ \vec{F}(\vec{r}) $ 可分解为一个标量场的梯度和一个矢量场的旋度的和：

 $$ \vec{F}(\vec{r})=-\nabla U(\vec{r})+\nabla\times\vec{A}(\vec{r}) $$ 

我们先来看一下如何证明上面这个定理。证明这个定理最直接的办法，就是从6.91式出发，去寻找一组能够满足定理中等式的  $ U(\vec{r}) $ 和  $ \vec{A}(\vec{r}) $。由于实际的  $ \vec{F}, U, \vec{A} $ 等场都涉及到空间的叠加，为此，我们不妨先用  $ \delta $ 函数把  $ \vec{F}(\vec{r}) $ 写成空间积分的形式：

 $$ \vec{F}(\vec{r})=\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\delta(\vec{r}-\vec{r}^{\prime})\mathrm{d}V^{\prime}=\iiint_{V^{\prime}}\vec{F}(\vec{r}^{\prime})\bigg(-\frac{1}{4\pi}\nabla^{2}\frac{1}{|\vec{r}-\vec{r}^{\prime}|}\bigg)\mathrm{d}V^{\prime} $$ 