5 What matrix E puts A into triangular form EA = U? Multiply by  $ E^{-1} = L $ to factor A into LU:

 $$ A=\begin{bmatrix}{{{2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{4}}}&{{{2}}} \\{{{6}}}&{{{3}}}&{{{5}}}\end{bmatrix}. $$ 

6 What two elimination matrices  $ E_{21} $ and  $ E_{32} $ put A into upper triangular form  $ E_{32}E_{21}A = U $? Multiply by  $ E_{32}^{-1} $ and  $ E_{21}^{-1} $ to factor A into  $ LU = E_{21}^{-1}E_{32}^{-1}U $:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{2}}}&{{{4}}}&{{{5}}} \\{{{0}}}&{{{4}}}&{{{0}}}\end{bmatrix}. $$ 

7 What three elimination matrices  $ E_{21}, E_{31}, E_{32} $ put A into its upper triangular form  $ E_{32}E_{31}E_{21}A = U $? Multiply by  $ E_{32}^{-1} $,  $ E_{31}^{-1} $ and  $ E_{21}^{-1} $ to factor A into L times U:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{1}}} \\{{{2}}}&{{{2}}}&{{{2}}} \\{{{3}}}&{{{4}}}&{{{5}}}\end{bmatrix}\quad\boldsymbol{L}=\boldsymbol{E}_{21}^{-1}\boldsymbol{E}_{31}^{-1}\boldsymbol{E}_{32}^{-1}. $$ 

8 This is the problem that shows how the inverses  $ E_{ij}^{-1} $ multiply to give L. You see this best when A is already lower triangular with 1's on the diagonal. Then  $ U = I! $

 $$ \boldsymbol{A}=\boldsymbol{L}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{a}}}&{{{1}}}&{{{0}}} \\{{{b}}}&{{{c}}}&{{{1}}}\end{bmatrix}. $$ 

The elimination matrices E21, E31, E32 contain -a then -b then -c.

(a) Multiply E32E31E21 to find the single matrix E that produces EA = I.

(b) Multiply  $ E_{21}^{-1} E_{31}^{-1} E_{32}^{-1} $ to bring back L.

The multipliers a, b, c are mixed up in E but perfect in L.

When zero appears in a pivot position, A = LU is not possible! (We are requiring nonzero pivots in U.) Show directly why these equations are both impossible:

 $$ \begin{bmatrix}{{{0}}}&{{{1}}} \\{{{2}}}&{{{3}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{\ell}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{d}}}&{{{e}}} \\{{{0}}}&{{{f}}}\end{bmatrix}\qquad\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{\ell}}}&{{{1}}} \\{{{m}}}&{{{n}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{d}}}&{{{e}}}&{{{g}}} \\{{{f}}}&{{{h}}} \\{{{i}}}\end{bmatrix}. $$ 

These matrices need a row exchange. That uses a “permutation matrix” P.

Which number  $ c $ leads to zero in the second pivot position? A row exchange is needed and  $ A = LU $ will not be possible. Which  $ c $ produces zero in the third pivot position? Then a row exchange can't help and elimination fails:

 $$ A=\begin{bmatrix}{{{1}}}&{{{c}}}&{{{0}}} \\{{{2}}}&{{{4}}}&{{{1}}} \\{{{3}}}&{{{5}}}&{{{1}}}\end{bmatrix}. $$ 