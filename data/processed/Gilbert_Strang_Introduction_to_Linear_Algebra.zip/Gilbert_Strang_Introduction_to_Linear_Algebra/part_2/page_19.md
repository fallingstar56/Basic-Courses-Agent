The serious questions are about the transpose of a product AB and an inverse  $ A^{-1} $:

Sum

 $$  The transpose of\quad A+B\quad is\quad A^{\mathrm{T}}+B^{\mathrm{T}}. $$ 

 $$ \begin{array}{r l r l r l}{{P r o d u c t}}&{{}}&{{T h e~t r a n s p o s e~o f}}&{{A B}}&{{i s}}&{{(A B)^{\mathrm{T}}=B^{\mathrm{T}}A^{\mathrm{T}},}}\end{array} $$ 

 $$ \begin{array}{r l r l r l}{\mathrm{I n v e r s e}}&{{}}&{\mathrm{T h e~t r a n s p o s e~o f~}}&{{}A^{-1}}&{{}\mathrm{i s}}&{{}(A^{-1})^{\mathrm{T}}=(A^{\mathrm{T}})^{-1}.}\end{array} $$ 

Notice especially how  $ B^{1}A $  $ \quad $  $ \

A x combines the columns of A while  $ x^{T}A^{T} $ combines the rows of  $ A^{T} $.

It is the same combination of the same vectors! In $A$ they are columns, in $A^\mathrm{T}$ they are rows. So the transpose of the column $A\boldsymbol{x}$ is the row $\boldsymbol{x}^\mathrm{T}A^\mathrm{T}$. That fits our formula $(A\boldsymbol{x})^\mathrm{T}=x^\mathrm{T}A^\mathrm{T}$. Now we can prove the formula $(AB)^\mathrm{T}=B^\mathrm{T}A^\mathrm{T}$, when $B$ has several columns.

If  $ B = [x_1 \quad x_2] $ has two columns, apply the same idea to each column. The columns of  $ AB $ are  $ A x_1 $ and  $ A x_2 $. Their transposes appear correctly in the rows of  $ B^T A^T $:

 $$ \begin{aligned}&Transposing\ AB=\begin{bmatrix}\\ &A\boldsymbol{x}_{1}\ A\boldsymbol{x}_{2}&\cdots\\ &\end{bmatrix}\quad gives\begin{bmatrix}\\ &\boldsymbol{x}_{1}^{\mathrm{T}}\boldsymbol{A}^{\mathrm{T}}\\&\boldsymbol{x}_{2}^{\mathrm{T}}\boldsymbol{A}^{\mathrm{T}}\\&\vdots\\ &\end{bmatrix}\quad which is\ B^{\mathrm{T}}\boldsymbol{A}^{\mathrm{T}}.\\ \end{aligned} $$ 

The right answer  $ B^{\mathrm{T}} A^{\mathrm{T}} $ comes out a row at a time. Here are numbers in  $ (AB)^{\mathrm{T}} = B^{\mathrm{T}} A^{\mathrm{T}} $:

 $$ \boldsymbol{A}\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{5}}}&{{{0}}} \\{{{4}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{5}}}&{{{0}}} \\{{{9}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{B}^{\mathrm{T}}\boldsymbol{A}^{\mathrm{T}}=\begin{bmatrix}{{{5}}}&{{{4}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{5}}}&{{{9}}} \\{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

The reverse order rule extends to three or more factors:  $ (ABC)^{\mathrm{T}} $ equals  $ C^{\mathrm{T}}B^{\mathrm{T}}A^{\mathrm{T}} $.

 $$ If A=LDU then A^{\mathrm{T}}=U^{\mathrm{T}}D^{\mathrm{T}}L^{\mathrm{T}},\quad The pivot matrix has D=D^{\mathrm{T}} $$ 

Now apply this product rule by transposing both sides of  $ A^{-1}A = I $. On one side,  $ I^{\mathrm{T}} $ is  $ I $. We confirm the rule that  $ (A^{-1})^{\mathrm{T}} $ is the inverse of  $ A^{\mathrm{T}} $. Their product is  $ I $:

Transpose of inverse

 $$ A^{-1}A=I\quad is transposed to\quad A^{\mathrm{T}}(A^{-1})^{\mathrm{T}}=I. $$ 

Similarly  $ AA^{-1} = I $ leads to  $ (A^{-1})^{\mathrm{T}} A^{\mathrm{T}} = I $. We can invert the transpose or we can transpose the inverse. Notice especially:  $ A^{\mathrm{T}} $ is invertible exactly when  $ A $ is invertible.

Example 1 The inverse of  $ A = \begin{bmatrix} 1 & 0 \\ 6 & 1 \end{bmatrix} $ is  $ A^{-1} = \begin{bmatrix} 1 & 0 \\ -6 & 1 \end{bmatrix} $. The transpose is  $ A^{\mathrm{T}} = \begin{bmatrix} 1 & 6 \\ 0 & 1 \end{bmatrix} $

 $$ \begin{array}{r l r}{(A^{-1})^{\mathrm{T}}}&{{}{~a n d}}&{(A^{\mathrm{T}})^{-1}\quad{~a r e~b o t h~e q u a l~t o~}\quad\left[\begin{matrix}{1}&{-6}\\ {0}&{1}\\ \end{matrix}\right].}\end{array} $$ 