Symmetric matrices

 $$ S=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{5}}}\end{bmatrix}=S^{\mathrm{T}}\quad and\quad D=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{10}}}\end{bmatrix}=D^{\mathrm{T}}. $$ 

The inverse of a symmetric matrix is also symmetric. The transpose of  $ S^{-1} $ is  $ (S^{-1})^{\mathrm{T}} = (S^{\mathrm{T}})^{-1} = S^{-1} $. That says  $ S^{-1} $ is symmetric (when  $ S $ is invertible):

Symmetric inverses

 $$ S^{-1}=\begin{bmatrix}{{{5}}}&{{{-2}}} \\{{{-2}}}&{{{1}}}\end{bmatrix}\quad and\quad D^{-1}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0.1}}}\end{bmatrix}. $$ 

Now we produce a symmetric matrix S by multiplying any matrix A by  $ A^{T} $.

Symmetric Products  $ A^{T}A $ and  $ AA^{T} $ and  $ LDL^{T} $

Choose any matrix  $ A $, probably rectangular. Multiply  $ A^{\mathrm{T}} $ times  $ A $. Then the product  $ S = A^{\mathrm{T}} A $ is automatically a square symmetric matrix:

The transpose of

 $$ \begin{array}{r l r l}{A^{\mathrm{T}}A}&{{i s}}&{A^{\mathrm{T}}(A^{\mathrm{T}})^{\mathrm{T}}}&{{w h i c h~i s}}&{{}A^{\mathrm{T}}A{~a g a i n.}}\end{array} $$ 

That is a quick proof of symmetry for  $ A^{T}A $. We could look at the  $ (i,j) $ entry of  $ A^{T}A $. It is the dot product of row  $ i $ of  $ A^{T} $ (column  $ i $ of  $ A $) with column  $ j $ of  $ A $. The  $ (j,i) $ entry is the same dot product, column  $ j $ with column  $ i $. So  $ A^{T}A $ is symmetric.

The matrix  $ AA^{\mathrm{T}} $ is also symmetric. (The shapes of A and  $ A^{\mathrm{T}} $ allow multiplication.) But  $ AA^{\mathrm{T}} $ is a different matrix from  $ A^{\mathrm{T}}A $. In our experience, most scientific problems that start with a rectangular matrix A end up with  $ A^{\mathrm{T}}A $ or  $ AA^{\mathrm{T}} $ or both. As in least squares.

Example 2 Multiply  $ A = \begin{bmatrix} -1 & 1 & 0 \\ 0 & -1 & 1 \end{bmatrix} $ and  $ A^{T} = \begin{bmatrix} -1 & 0 \\ 1 & -1 \\ 0 & 1 \end{bmatrix} $ in both orders.

$$A A^{\mathrm{T}}=\begin{bmatrix}2&-1\\ -1&2\end{bmatrix}\text{and}A^{\mathrm{T}}A=\begin{vmatrix}1&-1&0\\ -1&2&-1\\ 0&-1&1\end{vmatrix}$$ are both symmetric matrices.

The product  $ A^{\mathrm{T}}A $ is n by n. In the opposite order,  $ AA^{\mathrm{T}} $ is m by m. Both are symmetric, with positive diagonal (why?). But even if m = n, it is very likely that  $ A^{\mathrm{T}}A \neq AA^{\mathrm{T}} $. Equality can happen, but it is abnormal.

Symmetric matrices in elimination  $ S^{\mathrm{T}} = S $ makes elimination faster, because we can work with half the matrix (plus the diagonal). It is true that the upper triangular U is probably not symmetric. The symmetry is in the triple product  $ S = LDU $. Remember how the diagonal matrix  $ D $ of pivots can be divided out, to leave 1's on the diagonal of both  $ L $ and  $ U $:

 $$ \begin{aligned}\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{7}}}\end{bmatrix}&=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{2}}}&{{{1}}}\end{bmatrix}&\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{3}}}\end{bmatrix}\\ \end{aligned}L U misses the symmetry of S $$ 