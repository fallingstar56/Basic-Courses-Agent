Forward elimination is multiplication by  $ L^{-1} $. It produces the upper triangular system  $ Ux = c $. The solution x comes as always by back substitution, bottom to top:

 $$ \begin{array}{ccc}x_{1}+x_{2}+\ x_{3}+\ x_{4}=\ &1&x_{1}=+4\\x_{2}+2x_{3}+3x_{4}=-1&\\x_{3}+3x_{4}=\ &1&gives\quad x_{2}=-6\\x_{4}=-1&&x_{3}=+4\\\end{array} $$ 

I see a pattern in that x, but I don't know where it comes from. Try inv (pascal (4)).

### Problem Set 2.6

Problems 1–14 compute the factorization  $ A = LU $ (and also  $ A = LDU $).

1 (Important) Forward elimination changes  $ \left[\begin{array}{c}1\ 1\\ 1\ 2\end{array}\right]x = b $ to a triangular  $ \left[\begin{array}{c}1\ 1\\ 0\ 1\end{array}\right]x = c $:

 $$ \begin{array}{ccc} x+\quad y=5 & \longrightarrow &  x+\quad y=5 \\ x+2y=7 & &  y=2  \end{array} \quad \left[\begin{array}{ccc} 1 & 1 & 5 \\ 1 & 2 & 7 \end{array} \right] \quad \longrightarrow \quad \left[\begin{array}{ccc} 1 & 1 & 5 \\ 0 & 1 & 2 \end{array} \right] $$ 

That step subtracted  $ \ell_{21} = $ ___ times row 1 from row 2. The reverse step adds  $ \ell_{21} $ times row 1 to row 2. The matrix for that reverse step is  $ L = $ ___ . Multiply this  $ L $ times the triangular system  $ \left[\begin{array}{c} 1 \\ 0 \end{array}\right] \mathbf{x}_{1} = \left[\begin{array}{c} 5 \\ 2 \end{array}\right] $ to get ___ = ___ . In letters,  $ L $ multiplies  $ U \mathbf{x} = \mathbf{c} $ to give ___.

2 Write down the 2 by 2 triangular systems  $ Lc = b $ and  $ Ux = c $ from Problem 1. Check that  $ c = (5, 2) $ solves the first one. Find x that solves the second one.

3 (Move to 3 by 3) Forward elimination changes Ax = b to a triangular Ux = c:

 $$ \begin{array}{lllllllll} x&+&y&+&z=5& & &x&+&y&+&z=5\\x&+&2y&+&3z=7& & &y+2z=2& & &y+2z=2\\x&+&3y&+&6z=11& & &2y+5z=6& & &z=2 \end{array} $$ 

The equation  $ z = 2 $ in  $ Ux = c $ comes from the original  $ x + 3y + 6z = 11 $ in  $ Ax = b $ by subtracting  $ \ell_{31} = $ ___ times equation 1 and  $ \ell_{32} = $ ___ times the final equation 2. Reverse that to recover [1 3 6 11] in the last row of A and b from the final [1 1 1 5] and [0 1 2 2] and [0 0 1 2] in U and c:

Row 3 of  $ [A\ b] = (\ell_{31} \operatorname{Row} 1 + \ell_{32} \operatorname{Row} 2 + 1 \operatorname{Row} 3) $ of  $ [U\ c] $.

In matrix notation this is multiplication by L. So  $ A = LU $ and  $ b = Lc $.

4 What are the 3 by 3 triangular systems  $ Lc = b $ and  $ Ux = c $ from Problem 3? Check that  $ c = (5, 2, 2) $ solves the first one. Which x solves the second one?