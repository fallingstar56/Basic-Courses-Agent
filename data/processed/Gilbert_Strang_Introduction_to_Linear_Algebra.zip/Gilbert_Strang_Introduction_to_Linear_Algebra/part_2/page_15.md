11 What are L and D (the diagonal pivot matrix) for this matrix A? What is U in A = LU and what is the new U in A = LDU?

Already triangular

 $$ A=\begin{bmatrix}{{{2}}}&{{{4}}}&{{{8}}} \\{{{0}}}&{{{3}}}&{{{9}}} \\{{{0}}}&{{{0}}}&{{{7}}}\end{bmatrix}. $$ 

12 A and B are symmetric across the diagonal (because 4 = 4). Find their triple factorizations LDU and say how U is related to L for these symmetric matrices:

Symmetric

 $$ \boldsymbol{A}=\begin{bmatrix}{{{2}}}&{{{4}}} \\{{{4}}}&{{{11}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{4}}}&{{{0}}} \\{{{4}}}&{{{12}}}&{{{4}}} \\{{{0}}}&{{{4}}}&{{{0}}}\end{bmatrix}. $$ 

13 (Recommended) Compute L and U for the symmetric matrix A:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{a}}}&{{{a}}}&{{{a}}}&{{{a}}} \\{{{a}}}&{{{b}}}&{{{b}}}&{{{b}}} \\{{{a}}}&{{{b}}}&{{{c}}}&{{{c}}} \\{{{a}}}&{{{b}}}&{{{c}}}&{{{d}}}\end{bmatrix}. $$ 

Find four conditions on a, b, c, d to get A = LU with four pivots.

This nonsymmetric matrix will have the same L as in Problem 13:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{a}}}&{{{r}}}&{{{r}}}&{{{r}}} \\{{{a}}}&{{{b}}}&{{{s}}}&{{{s}}} \\{{{a}}}&{{{b}}}&{{{c}}}&{{{t}}} \\{{{a}}}&{{{b}}}&{{{c}}}&{{{d}}}\end{bmatrix}. $$ 

Find L and U for

Find the four conditions on a, b, c, d, r, s, t to get A = LU with four pivots.

Problems 15–16 use L and U (without needing A) to solve Ax = b.

15 Solve the triangular system  $ Lc = b $ to find c. Then solve  $ Ux = c $ to find x:

 $$ L=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{4}}}&{{{1}}}\end{bmatrix}\quad and\quad U=\begin{bmatrix}{{{2}}}&{{{4}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{b}=\begin{bmatrix}{{{2}}} \\{{{11}}}\end{bmatrix}. $$ 

For safety multiply LU and solve Ax = b as usual. Circle c when you see it.

16 Solve  $ Lc = b $ to find c. Then solve  $ Ux = c $ to find x. What was A?

 $$ \boldsymbol{L}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{U}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{b}=\begin{bmatrix}{{{4}}} \\{{{5}}} \\{{{6}}}\end{bmatrix}. $$ 