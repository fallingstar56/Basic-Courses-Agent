The space Z is zero-dimensional (by any reasonable definition of dimension). Z is the smallest possible vector space. We hesitate to call it  $ \mathbf{R}^0 $, which means no components—you might think there was no vector. The vector space Z contains exactly one vector (zero). No space can do without that zero vector. Each space has its own zero vector—the zero matrix, the zero function, the vector  $ (0,0,0) $ in  $ \mathbf{R}^3 $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_218_274_820_500.jpg" alt="Image" width="56%" /></div>


<div style="text-align: center;">Figure 3.1: “Four-dimensional” matrix space M. The “zero-dimensional” space Z.</div>


Subspaces

At different times, we will ask you to think of matrices and functions as vectors. But at all times, the vectors that we need most are ordinary column vectors. They are vectors with n components—but maybe not all of the vectors with n components. There are important vector spaces inside  $ \mathbf{R}^n $. Those are subspaces of  $ \mathbf{R}^n $.

Start with the usual three-dimensional space  $ \mathbf{R}^3 $. Choose a plane through the origin  $ (0,0,0) $. That plane is a vector space in its own right. If we add two vectors in the plane, their sum is in the plane. If we multiply an in-plane vector by 2 or -5, it is still in the plane. A plane in three-dimensional space is not  $ \mathbf{R}^2 $ (even if it looks like  $ \mathbf{R}^2 $). The vectors have three components and they belong to  $ \mathbf{R}^3 $. The plane is a vector space inside  $ \mathbf{R}^3 $.

This illustrates one of the most fundamental ideas in linear algebra. The plane going through  $ (0,0,0) $ is a subspace of the full vector space  $ R^3 $.

DEFINITION A subspace of a vector space is a set of vectors (including 0) that satisfies two requirements: If v and w are vectors in the subspace and c is any scalar, then

<div style="text-align: center;">(i)  $ v + w $ is in the subspace</div>


<div style="text-align: center;">(ii) cv is in the subspace.</div>
