Questions 22–24 are about the factorizations  $ PA = LU $ and  $ A = L_{1}P_{1}U_{1} $.

22 Find the PA = LU factorizations (and check them) for

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{1}}} \\{{{2}}}&{{{3}}}&{{{4}}}\end{bmatrix}\quad and\quad\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{0}}} \\{{{2}}}&{{{4}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix}. $$ 

Find a 4 by 4 permutation matrix (call it A) that needs 3 row exchanges to reach the end of elimination. For this matrix, what are its factors P, L, and U?

Factor the following matrix into PA = LU. Factor it also into  $ A = L_{1}P_{1}U_{1} $ (hold the exchange of row 3 until 3 times row 1 is subtracted from row 2):

 $$ A=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{2}}} \\{{{0}}}&{{{3}}}&{{{8}}} \\{{{2}}}&{{{1}}}&{{{1}}}\end{bmatrix}. $$ 

Prove that the identity matrix cannot be the product of three row exchanges (or five). It can be the product of two exchanges (or four).

(a) Choose  $ E_{21} $ to remove the 3 below the first pivot. Then multiply  $ E_{21}SE_{21}^{\mathrm{T}} $ to remove both 3's:

 $$ S=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{0}}} \\{{{3}}}&{{{11}}}&{{{4}}} \\{{{0}}}&{{{4}}}&{{{9}}}\end{bmatrix}\quad is going toward\quad D=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

(b) Choose  $ E_{32} $ to remove the 4 below the second pivot. Then S is reduced to D by  $ E_{32}E_{21}SE_{21}^{\mathrm{T}}E_{32}^{\mathrm{T}} = D $. Invert the  $ E' $s to find L in  $ S = LDL^{\mathrm{T}} $.

If every row of a 4 by 4 matrix contains the numbers 0, 1, 2, 3 in some order, can the matrix be symmetric?

28 Prove that no reordering of rows and reordering of columns can transpose a typical matrix. (Watch the diagonal entries.)

The next three questions are about applications of the identity (Ax)ᵀy = xᵀ(Aᵀy).

29 Wires go between Boston, Chicago, and Seattle. Those cities are at voltages  $ x_{B}, x_{C}, x_{S} $. With unit resistances between cities, the currents between cities are in u:

 $$ \begin{array}{r l}{\boldsymbol{y}=A\boldsymbol{x}}&{\mathrm{i s}\quad\left[\begin{matrix}{y_{B C}}\\ {y_{C S}}\\ {y_{B S}}\\ \end{matrix}\right]=\left[\begin{matrix}{1}&{-1}&{0}\\ {0}&{1}&{-1}\\ {1}&{0}&{-1}\\ \end{matrix}\right]\left[\begin{matrix}{x_{B}}\\ {x_{C}}\\ {x_{S}}\\ \end{matrix}\right].}\end{array} $$ 

(a) Find the total currents  $ A^{T}y $ out of the three cities.

(b) Verify that  $ (Ax)^{\mathrm{T}}y $ agrees with  $ \boldsymbol{x}^{\mathrm{T}}(A^{\mathrm{T}}\boldsymbol{y}) $—six terms in both.