Reduced form R

 $$ \boldsymbol{U}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{2}}}&{{{4}}} \\{{{0}}}&{{{2}}}&{{{0}}}&{{{4}}}\end{bmatrix}\qquad becomes\quad\boldsymbol{R}=\left[\begin{array}{cccc}{{{1}}}&{{{0}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{2}}}\end{array}\right].\quad\begin{aligned}&\uparrow\quad\uparrow\\ &\end{aligned} $$ 

I subtracted row 2 of U from row 1. Then I multiplied row 2 by  $ \frac{1}{2} $ to get pivot = 1.

Now (free column 3) = 2 (pivot column 1), so -2 appears in  $ s_1 = (-2, 0, 1, 0) $. The special solutions are much easier to find from the reduced system  $ Rx = 0 $. In each free column of  $ R $, I change all the signs to find  $ s $. Second special solution  $ s_2 = (0, -2, 0, 1) $.

Before moving to m by n matrices A and their nullspaces  $ N(A) $ and special solutions, allow me to repeat one comment. For many matrices, the only solution to  $ Ax = 0 $ is  $ x = 0 $. Their nullspaces  $ N(A) = Z $ contain only that zero vector: no special solutions. The only combination of the columns that produces  $ b = 0 $ is then the “zero combination”. The solution to  $ Ax = 0 $ is trivial (just  $ x = 0 $) but the idea is not trivial.

This case of a zero nullspace Z is of the greatest importance. It says that the columns of A are independent. No combination of columns gives the zero vector (except the zero combination). All columns have pivots, and no columns are free. You will see this idea of independence again...

Pivot Variables and Free Variables in the Echelon Matrix R

\[\boldsymbol{A}=\left[\begin{array}{c|c|c|c}{{{p}}}&{{{p}}}&{{{f}}}&{{{p}}}&{{{f}}} \\{{{\hline}}}&{{{\hline}}}&{{{\hline}}}&{{{\hline}}} \\{{{\hline}}}&{{{\hline}}}&{{{\hline}}}&{{{\hline}}} \\{{{\hline}}}&{{{\hline}}}&{{{\hline}}}&{{{\hline}}} \\{{{\hline}}}&

3 pivot columns p  

2 free columns f  

to be revealed by R

I in pivot columns

F in free columns

3 pivots: rank r = 3

special  $ Rs_{1}=0 $ and  $ Rs_{2}=0 $

take -a to -e from R

 $ R_{s}=0 $ means  $ A_{s}=0 $

 $ R $ shows clearly: column  $ 3 = a $ (column 1) +  $ b $ (column 2). The same must be true for  $ A $. The special solution  $ s_1 $ repeats that combination so  $ (-a, -b, 1, 0, 0) $ has  $ Rs_1 = 0 $. Nullspace of  $ A = $ Nullspace of  $ R = $ all combinations of  $ s_1 $ and  $ s_2 $.

Here are those steps for a 4 by 7 reduced row echelon matrix R with three pivots:

 $$ R=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{x}}}&{{{x}}}&{{{x}}}&{{{0}}}&{{{x}}} \\{{{0}}}&{{{1}}}&{{{x}}}&{{{x}}}&{{{x}}}&{{{0}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix} $$ 

Three pivot variables  $ x_{1}, x_{2}, x_{6} $

Four free variables  $ x_{3}, x_{4}, x_{5}, x_{7} $

Four special solutions s in N(R)

The pivot rows and columns contain I

Question What are the column space and the nullspace for this matrix R?