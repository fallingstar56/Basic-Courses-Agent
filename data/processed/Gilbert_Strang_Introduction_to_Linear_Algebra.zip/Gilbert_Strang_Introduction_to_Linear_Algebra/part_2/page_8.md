These LU examples are showing something extra, which is very important in practice. Assume no row exchanges. When can we predict zeros in L and U?

When a row of A starts with zeros, so does that row of L.

When a column of A starts with zeros, so does that column of U.

If a row starts with zero, we don't need an elimination step. L has a zero, which saves computer time. Similarly, zeros at the start of a column survive into U. But please realize: Zeros in the middle of a matrix are likely to be filled in, while elimination sweeps forward. We now explain why L has the multipliers  $ \ell_{ij} $ in position, with no mix-up.

The key reason why A equals LU: Ask yourself about the pivot rows that are subtracted from lower rows. Are they the original rows of A? No, elimination probably changed them. Are they rows of U? Yes, the pivot rows never change again. When computing the third row of U, we subtract multiples of earlier rows of U (not rows of A!):

 $$ \mathbf{R}\mathbf{o}w3\mathbf{o}f U=(\mathbf{R}\mathbf{o}w3\mathbf{o}f A)-\ell_{31}(\mathbf{R}\mathbf{o}w1\mathbf{o}f U)-\ell_{32}(\mathbf{R}\mathbf{o}w2\mathbf{o}f U). $$ 

Rewrite this equation to see that the row [ ℓ31 ℓ32 1 ] is multiplying the matrix U:

 $$ (\mathbf{R}\mathbf{o}w\;3\;\mathbf{o}f\;A)=\ell_{31}(\mathbf{R}\mathbf{o}w\;1\;\mathbf{o}f\;U)+\ell_{32}(\mathbf{R}\mathbf{o}w\;2\;\mathbf{o}f\;U)+1(\mathbf{R}\mathbf{o}w\;3\;\mathbf{o}f\;U). $$ 

This is exactly row 3 of A = LU. That row of L holds  $ \ell_{31} $,  $ \ell_{32} $, 1. All rows look like this, whatever the size of A. With no row exchanges, we have A = LU.

Better balance from LDU  $ A = LU $ is “unsymmetric” because U has the pivots on its diagonal where L has 1's. This is easy to change. Divide U by a diagonal matrix D that contains the pivots. That leaves a new triangular matrix with 1's on the diagonal:

 $$  Split U into\left[\begin{array}{cccc}d_{1}&&&\\ &d_{2}&&\\ &&\ddots&\\ &&&d_{n}\end{array}\right]\left[\begin{array}{cccc}1&u_{12}/d_{1}&u_{13}/d_{1}&\cdot\\ &1&u_{23}/d_{2}&\cdot\\ &&\ddots&\vdots\\ &&&1\end{array}\right]. $$ 

It is convenient (but a little confusing) to keep the same letter U for this new triangular matrix. It has 1's on the diagonal (like L). Instead of the normal LU, the new form has D in the middle: Lower triangular L times diagonal D times upper triangular U.

The triangular factorization can be written  $ A = LU $ or  $ A = LDU $.

Whenever you see LDU, it is understood that U has 1's on the diagonal. Each row is divided by its first nonzero entry—the pivot. Then L and U are treated evenly in LDU:

 $$ \begin{bmatrix}{{{1}}}&{{{0}}} \\{{{3}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{8}}} \\{{{0}}}&{{{5}}}\end{bmatrix}\quad splits further into\quad\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{3}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}} \\{{{5}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{4}}} \\{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

The pivots 2 and 5 went into D. Dividing the rows by 2 and 5 left the rows [1 4] and [0 1] in the new U with diagonal ones. The multiplier 3 is still in L.