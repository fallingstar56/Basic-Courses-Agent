## Challenge Problems

Which invertible matrices allow $A = LU$ (elimination without row exchanges)?

Good question! Look at each of the square upper left submatrices $A_{k}$ of $A$.

All upper left k by k submatrices  $ A_k $ must be invertible (sizes  $ k = 1, \ldots, n $).

Explain that answer:  $ A_{k} $ factors into ___ because  $ LU = \begin{bmatrix} L_{k} & 0 \\ * & * \end{bmatrix} \begin{bmatrix} U_{k} & * \\ 0 & * \end{bmatrix} $.

For the 6 by 6 second difference constant-diagonal matrix K, put the pivots and multipliers into K = LU. (L and U will have only two nonzero diagonals, because K has three.) Find a formula for the i,j entry of  $ L^{-1} $, by software like MATLAB using inv (L) or by looking for a nice pattern.

-1, 2, -1 matrix  $ K = \begin{bmatrix} 2 & -1 \\ -1 & \cdot & \cdot \\ & \cdot & \cdot & \cdot \\ & & \cdot & \cdot & \cdot \\ & & & \cdot & -1 \\ & & & & -1 & 2 \end{bmatrix} = \text{toeplitz}([2 \quad -1 \quad 0 \quad 0 \quad 0]) $

If you print $K^{-1}$, it doesn't look so good (6 by 6). But if you print $7K^{-1}$, that matrix looks wonderful. Write down $7K^{-1}$ by hand, following this pattern:

1 Row 1 and column 1 are  $ (6, 5, 4, 3, 2, 1) $.

2 On and above the main diagonal, row i is i times row 1.

3 On and below the main diagonal, column j is j times column 1.

Multiply K times that 7K−1 to produce 7I. Here is 4K−1 for n = 3:

3 by 3 case

The determinant  $ (K)(4K^{-1})=\begin{bmatrix}2&-1&0\\ -1&2&-1\\ 0&-1&2\end{bmatrix}\begin{bmatrix}3&2&1\\ 2&4&2\\ 1&2&3\end{bmatrix}=\begin{bmatrix}4&&\\ &4&\\ &&4\end{bmatrix} $.