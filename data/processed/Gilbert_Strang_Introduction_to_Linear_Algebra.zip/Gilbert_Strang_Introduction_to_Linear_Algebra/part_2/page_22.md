#### 2.7. Transposes and Permutations

When $S$ is symmetric, the usual form $A = LDU$ becomes $S = LDL^{\mathrm{T}}$. The final $U$ (with $1^{\prime}s$ on the diagonal) is the transpose of $L$ (also with $1^{\prime}s$ on the diagonal). The diagonal matrix $D$ containing the pivots is symmetric by itself.

If S = S^{T} is factored into LDU with no row exchanges, then U is exactly L^{T}.

The symmetric factorization of a symmetric matrix is  $ S = LDL^{T} $.

Notice that the transpose of  $ LDL^{\mathrm{T}} $ is automatically  $ (L^{\mathrm{T}})^{\mathrm{T}}D^{\mathrm{T}}L^{\mathrm{T}} $ which is  $ LDL^{\mathrm{T}} $ again. The work of elimination is cut in half, from  $ n^{3}/3 $ multiplications to  $ n^{3}/6 $. The storage is also cut essentially in half. We only keep L and D, not U which is just  $ L^{\mathrm{T}} $.

Permutation Matrices

The transpose plays a special role for a permutation matrix. This matrix  $ P $ has a single “1” in every row and every column. Then  $ P^\text{T} $ is also a permutation matrix—maybe the same as  $ P $ or maybe different. Any product  $ P_1P_2 $ is again a permutation matrix.

We now create every P from the identity matrix, by reordering the rows of I.

The simplest permutation matrix is  $ P = I $ (no exchanges). The next simplest are the row exchanges  $ P_{ij} $. Those are constructed by exchanging two rows i and j of I. Other permutations reorder more rows. By doing all possible row exchanges to I, we get all possible permutation matrices:

DEFINITION A permutation matrix P has the rows of the identity I in any order.

Example 3 There are six 3 by 3 permutation matrices. Here they are without the zeros:

 $$ \boldsymbol{I}=\begin{bmatrix}1&&\\ &1&\\ &&1\end{bmatrix}\qquad\boldsymbol{P}_{21}=\begin{bmatrix}1&&\\ &1&\\ &&1\end{bmatrix}\qquad\boldsymbol{P}_{32}\boldsymbol{P}_{21}=\begin{bmatrix}1&&\\ &1&\\ &&1\end{bmatrix} $$ 

 $$ P_{31}=\begin{bmatrix} \\{{{1}}} \\{{{1}}} \\{{{1}}} \\\end{bmatrix}\qquad P_{32}=\begin{bmatrix} \\{{{1}}} \\{{{1}}} \\{{{1}}} \\\end{bmatrix}\qquad P_{21}P_{32}=\begin{bmatrix} \\{{{1}}} \\{{{1}}} \\\end{bmatrix}. $$ 

There are  $ n! $ permutation matrices of order  $ n $. The symbol  $ n! $ means “ $ n $ factorial,” the product of the numbers  $ (1)(2)\cdots(n) $. Thus  $ 3! = (1)(2)(3) $ which is 6. There will be 24 permutation matrices of order  $ n = 4 $. And 120 permutations of order 5.

There are only two permutation matrices of order 2, namely  $ \left[\begin{array}{cc}1 & 0 \\ 0 & 1\end{array}\right] $ and  $ \left[\begin{array}{cc}0 & 1 \\ 1 & 0\end{array}\right] $.

Important:  $ P^{-1} $ is also a permutation matrix. Among the six 3 by 3  $ P' $s displayed above, the four matrices on the left are their own inverses. The two matrices on the right are inverses of each other. In all cases, a single row exchange is its own inverse. If we repeat the exchange we are back to I. But for  $ P_{32}P_{21} $, the inverses go in opposite order as always. The inverse is  $ P_{21}P_{32} $.