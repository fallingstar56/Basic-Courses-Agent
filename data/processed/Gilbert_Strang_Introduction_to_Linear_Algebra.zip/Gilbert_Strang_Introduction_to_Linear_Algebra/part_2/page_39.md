Solution We want to have  $ b_{1} $ and  $ b_{2} $ in the column space of A. Then  $ Ax = b_{1} $ and  $ Ax = b_{2} $ will be solvable. The quickest way is to make  $ b_{1} $ and  $ b_{2} $ the two columns of A. Then the solutions are  $ \boldsymbol{x} = (1, 0) $ and  $ \boldsymbol{x} = (0, 1) $.

Also, we don’t want  $ Ax = b_3 $ to be solvable. So don’t make the column space any larger! Keeping only the columns  $ b_1 $ and  $ b_2 $, the question is:

 $$ \begin{aligned}&Is\ Ax=\begin{bmatrix}\\ &b_{1}&b_{2}\\ &\end{bmatrix}\begin{bmatrix}\\ &x_{1}\\&x_{2}\\ &\end{bmatrix}=b_{3}solvable?\quad Is\ b_{3}a combination of b_{1}and b_{2}？\\ \end{aligned} $$ 

If the answer is no, we have the desired matrix  $ A $. If the answer is yes, then it is not possible to construct  $ A $. When the column space contains  $ b_1 $ and  $ b_2 $, it will have to contain all their linear combinations. So  $ b_3 $ would necessarily be in that column space and  $ Ax = b_3 $ would necessarily be solvable.

### 3.1 B Describe a subspace S of each vector space V, and then a subspace SS of S

 $$ \mathbf{V}_{1}=all combinations of(1,1,0,0)and(1,1,1,0)and(1,1,1,1) $$ 

 $$ \mathbf{V}_{2}=all vectors perpendicular to\boldsymbol{u}=(1,2,1),so\boldsymbol{u}\cdot\boldsymbol{v}=0 $$ 

 $$ \mathbf{V}_{3}=\mathrm{a l l~s y m m e t r i c~2~b y~2~m a t r i c e s~(a~s u b s p a c e~o f~\mathbf{M})~} $$ 

 $$ \mathbf{V}_{4}=all solutions to the equation d^{4}y/dx^{4}=0(a subspace of\mathbf{F}) $$ 

Describe each V two ways: “All combinations of …” “All solutions of the equations…”

Solution  $ V_{1} $ starts with three vectors. A subspace S comes from all combinations of the first two vectors  $ (1, 1, 0, 0) $ and  $ (1, 1, 1, 0) $. A subspace SS of S comes from all multiples  $ (c, c, 0, 0) $ of the first vector. So many possibilities.

A subspace S of  $ V_2 $ is the line through  $ (1, -1, 1) $. This line is perpendicular to  $ u $. The vector  $ x = (0, 0, 0) $ is in S and all its multiples  $ cx $ give the smallest subspace  $ SS = Z $.

The diagonal matrices are a subspace S of the symmetric matrices. The multiples cI are a subspace SS of the diagonal matrices.

 $ V_4 $ contains all cubic polynomials  $ y = a + bx + cx^2 + dx^3 $, with  $ d^4y/dx^4 = 0 $. The quadratic polynomials give a subspace S. The linear polynomials are one choice of SS. The constants could be SSS.

In all four parts we could take S = V itself, and SS = the zero subspace Z.

Each V can be described as all combinations of  $ \ldots $ and as all solutions of  $ \ldots $

 $$ \mathbf{V}_{1}=all combinations of the 3 vectors\qquad\mathbf{V}_{1}=all solutions of v_{1}-v_{2}=0 $$ 

 $$ \mathbf{V}_{2}=all combinations of(1,0,-1)and(1,-1,1)\mathbf{V}_{2}=all solutions of\boldsymbol{u}\cdot\boldsymbol{v}=0. $$ 

 $  \mathbf{V}_3 = \text{all combinations of } \left[ \begin{array}{c} 1 \\ 0 \end{array} \right], \left[ \begin{array}{c} 0 \\ 1 \end{array} \right], \left[ \begin{array}{c} 0 \\ 0 \end{array} \right]. \quad \mathbf{V}_3 = \text{all solutions } \left[ \begin{array}{c} \mathbf{a} \\ \mathbf{c} \end{array} \right] \text{of } b = c  $

 $$ \mathbf{V}_{4}=all combinations of1,x,x^{2},x^{3}\qquad\mathbf{V}_{4}=all solutions to d^{4}y/dx^{4}=0. $$ 