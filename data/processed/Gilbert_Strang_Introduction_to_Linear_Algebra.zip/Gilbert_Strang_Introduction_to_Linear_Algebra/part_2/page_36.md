#### 3.1. Spaces of Vectors

Is the matrix I a subspace by itself? Certainly not. Only the zero matrix is. Your mind will invent more subspaces of 2 by 2 matrices—write them down for Problem 5.

## The Column Space of A

The most important subspaces are tied directly to a matrix A. We are trying to solve  $ Ax = b $. If A is not invertible, the system is solvable for some b and not solvable for other b. We want to describe the good right sides b—the vectors that can be written as A times some vector x. Those b's form the "column space" of A.

Remember that Ax is a combination of the columns of A. To get every possible b, we use every possible x. Start with the columns of A and take all their linear combinations. This produces the column space of A. It is a vector space made up of column vectors.

 $ C(A) $ contains not just the n columns of A, but all their combinations Ax.

DEFINITION The column space consists of all linear combinations of the columns. The combinations are all possible vectors  $ A\boldsymbol{x} $. They fill the column space  $ C(A) $.

This column space is crucial to the whole book, and here is why. To solve Ax = b is to express b as a combination of the columns. The right side b has to be in the column space produced by A on the left side, or no solution!

The system Ax = b is solvable if and only if b is in the column space of A.

When $b$ is in the column space, it is a combination of the columns. The coefficients in that combination give us a solution $x$ to the system $Ax = b$.

Suppose A is an m by n matrix. Its columns have m components (not n). So the columns belong to  $ \mathbf{R}^m $. The column space of A is a subspace of  $ \mathbf{R}^m $ (not  $ \mathbf{R}^n $). The set of all column combinations Ax satisfies rules (i) and (ii) for a subspace: When we add linear combinations or multiply by scalars, we still produce combinations of the columns. The word “subspace” is justified by taking all linear combinations.

Here is a 3 by 2 matrix  $ A $, whose column space is a subspace of  $ \mathbf{R}^3 $. The column space of  $ A $ is a plane in Figure 3.2. With only 2 columns,  $ C(A) $ can't be all of  $ \mathbf{R}^3 $.

Example 4

 $$ \begin{array}{r l r}{A\boldsymbol{x}}&{{}\mathrm{i s}}&{\left[\begin{matrix}{1}&{0}\\ {4}&{3}\\ {2}&{3}\end{matrix}\right]\left[\begin{matrix}{x_{1}}\\ {x_{2}}\end{matrix}\right]\quad\mathrm{w h i c h~i s}\quad x_{1}\left[\begin{matrix}{1}\\ {4}\\ {2}\end{matrix}\right]+x_{2}\left[\begin{matrix}{0}\\ {3}\\ {3}\end{matrix}\right].}\end{array} $$ 

The column space of all combinations of the two columns fills up a plane in  $ \mathbf{R}^3 $. We drew one particular  $ \mathbf{b} $ (a combination of the columns). This  $ \mathbf{b} = \mathbf{A}\mathbf{x} $ lies on the plane. The plane has zero thickness, so most right sides  $ \mathbf{b} $ in  $ \mathbf{R}^3 $ are not in the column space. For most  $ \mathbf{b} $ there is no solution to our 3 equations in 2 unknowns.