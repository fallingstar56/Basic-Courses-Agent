Special solution  $ A s = 0 $ The nullspace of  $ A = \begin{bmatrix} 1 & 2 \\ 3 & 6 \end{bmatrix} $ contains all multiples of  $ s = \begin{bmatrix} -2 \\ 1 \end{bmatrix} $.

This is the best way to describe the nullspace, by computing special solutions to Ax = 0. The solution is special because we set the free variable to  $ x_{2} = 1 $.

The nullspace of A consists of all combinations of the special solutions to Ax = 0.

Example 2  $ x + 2y + 3z = 0 $ comes from the 1 by 3 matrix  $ A = [1 \quad 2 \quad 3] $. Then  $ Ax = 0 $ produces a plane. All vectors on the plane are perpendicular to  $ (1,2,3) $. The plane is the nullspace of  $ A $. There are two free variables  $ y $ and  $ z $: Set to 0 and 1.

 $$ \left[\begin{array}{l l l}{{{1}}}&{{{2}}}&{{{3}}}\end{array}\right]\left[\begin{array}{l}{{{x}}} \\{{{y}}} \\{{{z}}}\end{array}\right]=0has two special solutions s_{1}=\left[\begin{array}{c}{{{-2}}} \\{{{1}}} \\{{{0}}}\end{array}\right]and s_{2}=\left[\begin{array}{c}{{{-3}}} \\{{{0}}} \\{{{1}}}\end{array}\right]. $$ 

Those vectors  $ s_1 $ and  $ s_2 $ lie on the plane  $ x + 2y + 3z = 0 $. All vectors on the plane are combinations of  $ s_1 $ and  $ s_2 $.

Notice what is special about  $ s_{1} $ and  $ s_{2} $. The last two components are “free” and we choose them specially as 1, 0 and 0, 1. Then the first components -2 and -3 are determined by the equation  $ Ax = 0 $.

The solutions to  $ x + 2y + 3z = 6 $ also lie on a plane, but that plane is not a subspace. The vector  $ \boldsymbol{x} = \boldsymbol{0} $ is only a solution if  $ \boldsymbol{b} = \boldsymbol{0} $. Section 3.3 will show how the solutions to  $ A\boldsymbol{x} = \boldsymbol{b} $ (if there are any solutions) are shifted away from zero by one particular solution.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>The two key steps of this section are (1) reducing  $ A $ to its row echelon form  $ R $ (2) finding the special solutions to  $ Ax = 0 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>The display on page 138 shows 4 by 5 matrices  $ A $ and  $ R $, with 3 pivots.</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>The equations  $ Ax = 0 $ and also  $ Rx = 0 $ have 5 - 3 = 2 special solutions  $ s_1 $ and  $ s_2 $.</td></tr></table>

## Pivot Columns and Free Columns

The first column of  $ A = \begin{bmatrix} 1 & 2 & 3 \end{bmatrix} $ contains the only pivot, so the first component of x is not free. The free components correspond to columns with no pivots. The special choice (one or zero) is only for the free variables in the special solutions.

Example 3 Find the nullspaces of A, B, C and the two special solutions to Cx = 0.

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{3}}}&{{{8}}}\end{bmatrix}\quad\boldsymbol{B}=\begin{bmatrix}{{{A}}} \\{{{2A}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{3}}}&{{{8}}} \\{{{2}}}&{{{4}}} \\{{{6}}}&{{{16}}}\end{bmatrix}\quad\boldsymbol{C}=\begin{bmatrix}{{{A}}}&{{{2A}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{2}}}&{{{4}}} \\{{{3}}}&{{{8}}}&{{{6}}}&{{{16}}}\end{bmatrix}. $$ 