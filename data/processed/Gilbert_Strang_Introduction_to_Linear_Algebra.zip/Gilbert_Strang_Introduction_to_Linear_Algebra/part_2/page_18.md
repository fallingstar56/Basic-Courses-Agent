### 2.7 Transposes and Permutations

1 The transposes of $Ax$ and $AB$ and $A^{-1}$ are $\boldsymbol{x}^{\mathrm{T}}A^{\mathrm{T}}$ and $B^{\mathrm{T}}A^{\mathrm{T}}$ and $(A^{\mathrm{T}})^{-1}$.

2 The dot product (inner product) is $\boldsymbol{x} \cdot \boldsymbol{y} = \boldsymbol{x}^{\mathrm{T}} \boldsymbol{y}$. This is $(1 \times n)(n \times 1) = (1 \times 1)$.

The outer product is $\boldsymbol{x} \boldsymbol{y}^{\mathrm{T}} = \text{column times row} = (n \times 1)(1 \times n) = n \times n \text{ matrix}$.

3 The idea behind $A^{\mathrm{T}}$ is that $Ax \cdot y \text{ equals } x \cdot A^{\mathrm{T}}y \text{ because } (Ax)^{\mathrm{T}}y = x^{\mathrm{T}}A^{\mathrm{T}}y = x^{\mathrm{T}}(A^{\mathrm{T}}y)$.

4 A symmetric matrix has $S^{\mathrm{T}} = S$ (and the product $A^{\mathrm{T}}A$ is always symmetric).

5 An orthogonal matrix has $Q^{\mathrm{T}} = Q^{-1}$. The columns of $Q$ are orthogonal unit vectors.

6 A permutation matrix $P$ has the same rows as $I$ (in any order). There are $n$ ! different orders.

7 Then $Px$ puts the components $x_{1}, x_{2}, \ldots, x_{n}$ in that new order. And $P^{\mathrm{T}}$ equals $P^{-1}$.

We need one more matrix, and fortunately it is much simpler than the inverse. It is the “transpose” of A, which is denoted by  $ A^{\mathrm{T}} $. The columns of  $ A^{\mathrm{T}} $ are the rows of A.

When A is an m by n matrix, the transpose is n by m:

Transpose

 $$ \begin{aligned}If\quad A&=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{4}}}\end{bmatrix}\quad then\quad A^{\mathrm{T}}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{2}}}&{{{0}}} \\{{{3}}}&{{{4}}}\end{bmatrix}.\end{aligned} $$ 

You can write the rows of A into the columns of  $ A^{T} $. Or you can write the columns of A into the rows of  $ A^{T} $. The matrix “flips over” its main diagonal. The entry in row i, column j of  $ A^{T} $ comes from row j, column i of the original A:

Exchange rows and columns

 $$ (A^{\mathrm{T}})_{i j}=A_{j i}. $$ 

The transpose of a lower triangular matrix is upper triangular. (But the inverse is still lower triangular.) The transpose of  $ A^{T} $ is A.

Note MATLAB's symbol for the transpose of A is  $ A' $. Typing [1 2 3] gives a row vector and the column vector is  $ v = [1\ 2\ 3]' $. To enter a matrix M with second column  $ w = [4\ 5\ 6]' $ you could define  $ M = [v\ w] $. Quicker to enter by rows and then transpose the whole matrix:  $ M = [1\ 2\ 3;\ 4\ 5\ 6]' $.

The rules for transposes are very direct. We can transpose  $ A + B $ to get  $ (A + B)^{\mathrm{T}} $. Or we can transpose  $ A $ and  $ B $ separately, and then add  $ A^{\mathrm{T}} + B^{\mathrm{T}} $—with the same result.