Clearing out the first column needs  $ w^2 $ multiplications and subtractions ( $ w $ zeros to be produced below the pivot, each one using a pivot row of length  $ w $). Then clearing out all  $ n $ columns, to reach  $ U $, needs no more than  $ nw^2 $. This saves a lot of time:

Band matrix A to U  $ \frac{1}{3}n^{3} $ reduces to  $ nw^{2} $

Solve  $ n^{2} $ reduces to 2nw



A tridiagonal matrix (bandwidth w = 1) allows very fast computation. Don’t store zeros!

The book’s website has Teaching Codes to factor A into LU and to solve Ax = b. Professional codes will look down each column for the largest available pivot, to exchange rows and reduce roundoff error.

MATLAB's backslash command  $ x = A\backslash b $ combines Factor and Solve to reach  $ x $.

How long does it take to solve Ax = b? For a random matrix of order n = 1000, a typical time on a PC is 1 second. The time is multiplied by about 8 when n is multiplied by 2. For professional codes go to netlib.org.

According to this  $ n^{3} $ rule, matrices that are 10 times as large (order 10,000) will take a thousand seconds. Matrices of order 100,000 will take a million seconds. This is too expensive without a supercomputer, but remember that these matrices are full. Most matrices in practice are sparse (many zero entries). In that case  $ A = LU $ is much faster.

## ■ REVIEW OF THE KEY IDEAS

1. Gaussian elimination (with no row exchanges) factors A into L times U.

2. The lower triangular $L$ contains the numbers $\ell_{ij}$ that multiply pivot rows, going from $A$ to $U$. The product $LU$ adds those rows back to recover $A$.

3. On the right side we solve  $ Lc = b $ (forward) and  $ Ux = c $ (backward).

4. Factor : There are  $ \frac{1}{3}(n^{3}-n) $ multiplications and subtractions on the left side.

5. Solve: There are  $ n^{2} $ multiplications and subtractions on the right side.

6. For a band matrix, change  $ \frac{1}{3} n^3 $ to  $ n w^2 $ and change  $ n^2 $ to 2wn.

## WORKED EXAMPLES

2.6 A The lower triangular Pascal matrix L contains the famous “Pascal triangle”. Gauss-Jordan inverted L in the worked example 2.5 C. Here we factor Pascal.