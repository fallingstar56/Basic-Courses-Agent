(Recommended) Prove that $A$ is invertible if $a \neq 0$ and $a \neq b$ (find the pivots or $A^{-1}$). Then find three numbers $c$ so that $C$ is not invertible:

 $$ A=\begin{bmatrix}{{{a}}}&{{{b}}}&{{{b}}} \\{{{a}}}&{{{a}}}&{{{b}}} \\{{{a}}}&{{{a}}}&{{{a}}}\end{bmatrix}\quad C=\begin{bmatrix}{{{2}}}&{{{c}}}&{{{c}}} \\{{{c}}}&{{{c}}}&{{{c}}} \\{{{8}}}&{{{7}}}&{{{c}}}\end{bmatrix}. $$ 

This matrix has a remarkable inverse. Find  $ A^{-1} $ by elimination on [A I]. Extend to a 5 by 5 “alternating matrix” and guess its inverse; then multiply to confirm.

 $$ \operatorname{Invert}A=\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{1}}}&{{{-1}}} \\{{{0}}}&{{{1}}}&{{{-1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\text{and solve}A\boldsymbol{x}=(1,1,1,1). $$ 

Suppose the matrices P and Q have the same rows as I but in any order. They are “permutation matrices”. Show that P - Q is singular by solving  $ (P - Q)x = 0 $.

Find and check the inverses (assuming they exist) of these block matrices:

 $$ \begin{bmatrix}{{{I}}}&{{{0}}} \\{{{C}}}&{{{I}}}\end{bmatrix}\quad\begin{bmatrix}{{{A}}}&{{{0}}} \\{{{C}}}&{{{D}}}\end{bmatrix}\quad\begin{bmatrix}{{{0}}}&{{{I}}} \\{{{I}}}&{{{D}}}\end{bmatrix}. $$ 

Could a 4 by 4 matrix A be invertible if every row contains the numbers 0, 1, 2, 3 in some order? What if every row of B contains 0, 1, 2, -3 in some order?

In the Worked Example 2.5 C, the triangular Pascal matrix  $ L $ has  $ L^{-1} = DLD $, where the diagonal matrix  $ D $ has alternating entries 1, -1, 1, -1. Then  $ LDLD = I $, so what is the inverse of  $ LD = \text{pascal}(4, 1) $?

The Hilbert matrices have  $ H_{ij} = 1/(i + j - 1) $. Ask MATLAB for the exact 6 by 6 inverse invhilb (6). Then ask it to compute inv (hilb (6)). How can these be different, when the computer never makes mistakes?

(a) Use inv(P) to invert MATLAB's 4 by 4 symmetric matrix  $ P = \text{pascal}(4) $.

(b) Create Pascal's lower triangular  $ L = \text{abs}(\text{pascal}(4,1)) $ and test  $ P = LL^{\mathrm{T}} $.

If  $ A = \text{ones}(4) $ and  $ b = \text{rand}(4, 1) $, how does MATLAB tell you that  $ Ax = b $ has no solution? For the special  $ b = \text{ones}(4, 1) $, which solution to  $ Ax = b $ is found by  $ A \backslash b $?

## Challenge Problems

(Recommended) A is a 4 by 4 matrix with 1's on the diagonal and -a, -b, -c on the diagonal above. Find  $ A^{-1} $ for this bidiagonal matrix.