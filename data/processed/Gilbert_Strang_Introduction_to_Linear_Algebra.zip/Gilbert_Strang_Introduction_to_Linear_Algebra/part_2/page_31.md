## The Transpose of a Derivative

Will you allow me a little calculus? It is extremely important or I wouldn't leave linear algebra. (This is really linear algebra for functions  $ x(t) $.) The matrix changes to a derivative so  $ A = d/dt $. To find the transpose of this unusual  $ A $ we need to define the inner product between two functions  $ x(t) $ and  $ y(t) $.

The inner product changes from the sum of  $ x_{k}y_{k} $ to the integral of  $ x(t)y(t) $.

Inner product of functions

 $$ x^{\mathrm{T}}y=(x,y)=\int\limits_{-\infty}^{\infty}x(t)y(t)dt $$ 

From this inner product we know the requirement on  $ A^{T} $. The word “adjoint” is more correct than “transpose” when we are working with derivatives.

The transpose of a matrix has  $ (Ax)^{\mathrm{T}}y = x^{\mathrm{T}}(A^{\mathrm{T}}y) $. The adjoint of  $ A = \frac{d}{dt} $ has

 $$ \left(A\boldsymbol{x},\boldsymbol{y}\right)=\int\limits_{-\infty}^{\infty}\frac{d\boldsymbol{x}}{d t}\boldsymbol{y}(t)d t=\int\limits_{-\infty}^{\infty}\boldsymbol{x}(t)\left(-\frac{d\boldsymbol{y}}{d t}\right)d t=\left(\boldsymbol{x},\boldsymbol{A}^{\mathrm{T}}\boldsymbol{y}\right) $$ 

I hope you recognize integration by parts. The derivative moves from the first function  $ x(t) $ to the second function  $ y(t) $. During that move, a minus sign appears. This tells us that the transpose of the derivative is minus the derivative.

The derivative is antisymmetric:  $ A = d/dt $ and  $ A^{\mathrm{T}} = -d/dt $. Symmetric matrices have  $ S^{\mathrm{T}} = S $, antisymmetric matrices have  $ A^{\mathrm{T}} = -A $. Linear algebra includes derivatives and integrals in Chapter 8, because those are both linear.

This antisymmetry of the derivative applies also to centered difference matrices.

 $$ \boldsymbol{A}=\left[\begin{array}{cccc}{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{0}}}\end{array}\right]\quad transposes to\quad\boldsymbol{A}^{\mathrm{T}}=\left[\begin{array}{cccc}{{{0}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}\end{array}\right]=-A. $$ 

And a forward difference matrix transposes to a backward difference matrix, multiplied by -1. In differential equations, the second derivative (acceleration) is symmetric. The first derivative (damping proportional to velocity) is antisymmetric.