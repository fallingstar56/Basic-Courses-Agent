Answer The columns of $R$ have four components so they lie in $\mathbf{R}^4$. (Not in $\mathbf{R}^3!$)

The fourth component of every column is zero. Every combination of the columns—

every vector in the column space—has fourth component zero. The column space $\mathbf{C}(R)$

consists of all vectors of the form $(b_1, b_2, b_3, 0)$. For those vectors we can solve $R\mathbf{x} = \mathbf{b}$.

The nullspace  $ \mathbf{N}(R) $ is a subspace of  $ \mathbf{R}^7 $. The solutions to  $ R\mathbf{x} = \mathbf{0} $ are all the combinations of the four special solutions—one for each free variable:

1. Columns 3, 4, 5, 7 have no pivots. So the four free variables are  $ x_{3} $,  $ x_{4} $,  $ x_{5} $,  $ x_{7} $.

2. Set one free variable to 1 and set the other three free variables to zero.

3. To find s, solve Rx = 0 for the pivot variables  $ x_{1}, x_{2}, x_{6} $.

Counting the pivots leads to an extremely important theorem. Suppose A has more columns than rows. With n > m there is at least one free variable. The system Ax = 0 has at least one special solution. This solution is not zero!

Suppose Ax = 0 has more unknowns than equations (n > m, more columns than rows). There must be at least one free column. Then Ax = 0 has nonzero solutions.

A short wide matrix  $ (n > m) $ always has nonzero vectors in its nullspace. There must be at least  $ n - m $ free variables, since the number of pivots cannot exceed  $ m $. (The matrix only has  $ m $ rows, and a row never has two pivots.) Of course a row might have no pivot—which means an extra free variable. But here is the point: When there is a free variable, it can be set to 1. Then the equation  $ Ax = 0 $ has at least a line of nonzero solutions.

The nullspace is a subspace. Its “dimension” is the number of free variables. This central idea—the dimension of a subspace—is defined and explained in this chapter.

## The Rank of a Matrix

The numbers m and n give the size of a matrix—but not necessarily the true size of a linear system. An equation like 0 = 0 should not count. If there are two identical rows in A, the second one disappears in elimination. Also if row 3 is a combination of rows 1 and 2, then row 3 will become all zeros in the triangular U and the reduced echelon form R. We don't want to count rows of zeros. The true size of A is given by its rank.

### DEFINITION OF RANK The rank of A is the number of pivots. This number is r

That definition is computational, and I would like to say more about the rank r. The final matrix R will have r nonzero rows. Start with a 3 by 4 example of rank r = 2:

Four columns

Two pivots

 $$ \boldsymbol{A}=\left[\begin{array}{llll}{{{1}}}&{{{1}}}&{{{2}}}&{{{4}}} \\{{{1}}}&{{{2}}}&{{{2}}}&{{{5}}} \\{{{1}}}&{{{3}}}&{{{2}}}&{{{6}}}\end{array}\right]\qquad\boldsymbol{R}=\left[\begin{array}{llll}{{{1}}}&{{{0}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]. $$ 

The first two columns of A are  $ (1,1,1) $ and  $ (1,2,3) $, going in different directions. Those will be pivot columns (revealed by R). The third column  $ (2,2,2) $ is a multiple