2.7 C For a rectangular A, this saddle-point matrix S is symmetric and important:

Block matrix from least squares

 $$ \boldsymbol{S}=\begin{bmatrix}\boldsymbol{I}&\boldsymbol{A}\\ \boldsymbol{A}^{\mathrm{T}}&\boldsymbol{0}\end{bmatrix}=\boldsymbol{S}^{\mathrm{T}}has size m+n. $$ 

Apply block elimination to find a block factorization  $ S = LDL^{\mathrm{T}} $. Then test invertibility:

S is invertible  $ \iff $  $ A^{\mathrm{T}} A $ is invertible  $ \iff $  $ Ax \neq 0 $ whenever  $ x \neq 0 $

Solution The first block pivot is I. Subtract  $ A^{T} $ times row 1 from row 2:

Block elimination

 $ S = \begin{bmatrix} I & A \\ A^\mathrm{T} & 0 \end{bmatrix} \quad \text{goes to} \quad \begin{bmatrix} I & A \\ 0 & -A^\mathrm{T}A \end{bmatrix} $. This is  $ U $.

The block pivot matrix D contains I and  $ -A^{\mathrm{T}}A $. Then L and  $ L^{\mathrm{T}} $ contain  $ A^{\mathrm{T}} $ and A:

Block factorization  $ S = LDL^{\mathrm{T}} = \begin{bmatrix} I & 0 \\ A^{\mathrm{T}} & I \end{bmatrix} \begin{bmatrix} I & 0 \\ 0 & -A^{\mathrm{T}} A \end{bmatrix} \begin{bmatrix} I & A \\ 0 & I \end{bmatrix}. $

L is certainly invertible, with diagonal 1's. The inverse of the middle matrix involves  $ (A^{\mathrm{T}}A)^{-1} $. Section 4.2 answers a key question about the matrix  $ A^{\mathrm{T}}A $:

When is  $ A^{T}A $ invertible? Answer: A must have independent columns.

Then Ax = 0 only if x = 0. Otherwise Ax = 0 will lead to  $ A^{T}Ax = 0 $.

### Problem Set 2.7

Questions 1–7 are about the rules for transpose matrices.

1 Find  $ A^{T} $ and  $ A^{-1} $ and  $ (A^{-1})^{\mathrm{T}} $ and  $ (A^{\mathrm{T}})^{-1} $ for

 $$ A=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{9}}}&{{{3}}}\end{bmatrix}\quad and also\quad A=\begin{bmatrix}{{{1}}}&{{{c}}} \\{{{c}}}&{{{0}}}\end{bmatrix}. $$ 

2 Verify that  $ (AB)^{\mathrm{T}} $ equals  $ B^{\mathrm{T}}A^{\mathrm{T}} $ but those are different from  $ A^{\mathrm{T}}B^{\mathrm{T}} $:

 $$ A=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{2}}}&{{{1}}}\end{bmatrix}\qquad B=\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\qquad AB=\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{2}}}&{{{7}}}\end{bmatrix}. $$ 

Show also that  $ AA^{T} $ is different from  $ A^{T}A $. But both of those matrices are ___.

(a) The matrix  $ (AB)^{-1} $^{T} comes from  $ (A^{-1})^{T} $ and  $ (B^{-1})^{T} $. In what order?

(b) If $U$ is upper triangular then $(U^{-1})^{\mathrm{T}}$ is ___ triangular.

Show that  $ A^2 = 0 $ is possible but  $ A^\mathrm{T} A = 0 $ is not possible (unless  $ A = \text{zero matrix} $).