 $$ a_{i j}=r_{i}(L)\cdot j(u) $$ 

### 2.6 Elimination = Factorization: A = LU

1 Each elimination step Eij is inverted by Lij. Off the main diagonal change −ℓij to +ℓij.

2 The whole forward elimination process (with no row exchanges) is inverted by L:

 $$ \boldsymbol{L}=(L_{21}L_{31}\cdots L_{n1})(L_{32}\cdots L_{n2})(L_{43}\cdots L_{n3})\cdots(L_{n n-1}). $$ 

3 That product matrix L is still lower triangular. Every multiplier  $ \ell_{ij} $ is in row i, column j.

4 The original A is recovered from U by  $ A = LU = (\text{lower triangular})(\text{upper triangular}) $.

5 Elimination on Ax = b reaches Ux = c. Then back-substitution solves Ux = c.

6 Solving a triangular system takes n2/2 multiply-subtracts. Elimination to find U takes n3/3.

Students often say that mathematics courses are too theoretical. Well, not this section. It is almost purely practical. The goal is to describe Gaussian elimination in the most useful way. Many key ideas of linear algebra, when you look at them closely, are really factorizations of a matrix. The original matrix A becomes the product of two or three special matrices. The first factorization—also the most important in practice—comes now from elimination. The factors L and U are triangular matrices. The factorization that comes from elimination is A = LU.

We already know U, the upper triangular matrix with the pivots on its diagonal. The elimination steps take A to U. We will show how reversing those steps (taking U back to A) is achieved by a lower triangular L. The entries of L are exactly the multipliers  $ \ell_{ij} $—which multiplied the pivot row j when it was subtracted from row i.

Start with a 2 by 2 example. The matrix  $ A $ contains 2, 1, 6, 8. The number to eliminate is 6. Subtract 3 times row 1 from row 2. That step is  $ E_{21} $ in the forward direction with multiplier  $ \ell_{21} = 3 $. The return step from  $ U $ to  $ A $ is  $ L = E_{21}^{-1} $ (an addition using +3):

Forward from A to U :

 $$ E_{21}A=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{-3}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{6}}}&{{{8}}}\end{bmatrix}=\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{0}}}&{{{5}}}\end{bmatrix}=U $$ 

Back from U to A :

 $$ \begin{aligned}E_{21}^{-1}U&=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{3}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{0}}}&{{{5}}}\end{bmatrix}=\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{6}}}&{{{8}}}\end{bmatrix}\end{aligned}=A.\end{aligned} $$ 

The second line is our factorization  $ LU = A $. Instead of  $ E_{21}^{-1} $ we write L. Move now to larger matrices with many  $ E' $s. Then L will include all their inverses.

Each step from A to U multiplies by a matrix  $ E_{ij} $ to produce zero in the  $ (i,j) $ position. To keep this clear, we stay with the most frequent case—when no row exchanges are involved. If A is 3 by 3, we multiply by  $ E_{21} $ and  $ E_{31} $ and  $ E_{32} $. The multipliers  $ \ell_{ij} $ produce zeros in the  $ (2,1) $ and  $ (3,1) $ and  $ (3,2) $ positions—all below the diagonal. Elimination ends with the upper triangular U.