(a) The intersection of two planes through  $ (0,0,0) $ is probably a ___ in  $ R^{3} $ but it could be a ___. It can't be Z!

(b) The intersection of a plane through  $ (0,0,0) $ with a line through  $ (0,0,0) $ is probably a ___ but it could be a ___.

(c) If S and T are subspaces of  $ \mathbf{R}^5 $, prove that their intersection  $ \mathbf{S} \cap \mathbf{T} $ is a subspace of  $ \mathbf{R}^5 $. Here  $ \mathbf{S} \cap \mathbf{T} $ consists of the vectors that lie in both subspaces. Check that  $ \mathbf{x} + \mathbf{y} $ and  $ \mathbf{c}\mathbf{x} $ are in  $ \mathbf{S} \cap \mathbf{T} $ if  $ \mathbf{x} $ and  $ \mathbf{y} $ are in both spaces.

16 Suppose P is a plane through  $ (0,0,0) $ and L is a line through  $ (0,0,0) $. The smallest vector space containing both P and L is either ___ or ___.

(a) Show that the set of invertible matrices in M is not a subspace.

(b) Show that the set of singular matrices in M is not a subspace.

18 True or false (check addition in each case by an example):

(a) The symmetric matrices in M (with  $ A^{T} = A $) form a subspace.

(b) The skew-symmetric matrices in M (with  $ A^{T} = -A $) form a subspace.

(c) The unsymmetric matrices in M (with  $ A^{\mathrm{T}} \neq A $) form a subspace.

Questions 19–27 are about column spaces C(A) and the equation Ax = b.

19 Describe the column spaces (lines or planes) of these particular matrices:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{C}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{2}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

20 For which right sides (find a condition on  $ b_{1}, b_{2}, b_{3} $) are these systems solvable?

(a)

 $$ \begin{bmatrix} {1}&{4}&{2} \\ {2}&{8}&{4} \\ {-1}&{-4}&{-2} \end{bmatrix} \begin{bmatrix} {x_{1}} \\ {x_{2}} \\ {x_{3}} \end{bmatrix}=\begin{bmatrix} b_{1} \\ b_{2} \\ b_{3}\\ \end{bmatrix} $$ 

(b)

 $$ \begin{bmatrix} {1}&{4} \\ {2}&{9} \\ {-1}&{-4} \end{bmatrix} \begin{bmatrix} {x_{1}} \\ {x_{2}} \end{bmatrix}=\begin{bmatrix} b_{1} \\ b_{2} \\ b_{3}\\ \end{bmatrix}. $$ 

Adding row 1 of A to row 2 produces B. Adding column 1 to column 2 produces C. A combination of the columns of  $ (B \text{ or } C ?) $ is also a combination of the columns of A. Which two matrices have the same column ___?

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{4}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{3}}}&{{{6}}}\end{bmatrix}\quad and\quad C=\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{2}}}&{{{6}}}\end{bmatrix}. $$ 

22 For which vectors  $ (b_{1}, b_{2}, b_{3}) $ do these systems have a solution?

 $$ \begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{bmatrix}=\begin{bmatrix}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{bmatrix}=\begin{bmatrix}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{bmatrix} $$ 

and

 $$ \begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{bmatrix}=\begin{bmatrix}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{bmatrix}. $$ 