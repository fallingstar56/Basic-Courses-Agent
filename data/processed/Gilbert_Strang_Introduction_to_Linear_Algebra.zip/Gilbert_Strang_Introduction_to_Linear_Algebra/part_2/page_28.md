15 All row exchange matrices are symmetric:  $ P^{T} = P $. Then  $ P^{T}P = I $ becomes  $ P^{2} = I $. Other permutation matrices may or may not be symmetric.

(a) If P sends row 1 to row 4, then  $ P^{T} $ sends row ___ to row ___ When  $ P^{T} = P $ the row exchanges come in pairs with no overlap.

(b) Find a 4 by 4 example with  $ P^{T} = P $ that moves all four rows.

## Questions 16–21 are about symmetric matrices and their factorizations

16 If  $ A = A^{\mathrm{T}} $ and  $ B = B^{\mathrm{T}} $, which of these matrices are certainly symmetric?

(a)

 $$ A^{2}-B^{2} $$ 

 $$ \left(b\right)\left(A+B\right)\left(A-B\right) $$ 

(c) ABA

(d) ABAB.

17 Find 2 by 2 symmetric matrices  $ S = S^{T} $ with these properties:

(a) S is not invertible.

(b) S is invertible but cannot be factored into LU (row exchanges needed).

(c) S can be factored into  $ LDL^{T} $ but not into  $ LL^{T} $ (because of negative D).

18 (a) How many entries of S can be chosen independently, if  $ S = S^{T} $ is 5 by 5?

(b) How do L and D (still 5 by 5) give the same number of choices in LDL $ ^{T} $?

(c) How many entries can be chosen if A is skew-symmetric? (A^{T} = -A).

19 Suppose A is rectangular (m by n) and S is symmetric (m by m).

(a) Transpose  $ A^{T}SA $ to show its symmetry. What shape is this matrix?

(b) Show why  $ A^{T}A $ has no negative numbers on its diagonal.

20 Factor these symmetric matrices into  $ S = LDL^{\mathrm{T}} $. The pivot matrix D is diagonal:

 $$ S=\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{3}}}&{{{2}}}\end{bmatrix}\quad and\quad S=\begin{bmatrix}{{{1}}}&{{{b}}} \\{{{b}}}&{{{c}}}\end{bmatrix}\quad and\quad S=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}. $$ 

21 After elimination clears out column 1 below the first pivot, find the symmetric 2 by 2 matrix that appears in the lower right corner:

 $$ Start from S=\begin{bmatrix}{{{2}}}&{{{4}}}&{{{8}}} \\{{{4}}}&{{{3}}}&{{{9}}} \\{{{8}}}&{{{9}}}&{{{0}}}\end{bmatrix}\quad and\quad S=\begin{bmatrix}{{{1}}}&{{{b}}}&{{{c}}} \\{{{b}}}&{{{d}}}&{{{e}}} \\{{{c}}}&{{{e}}}&{{{f}}}\end{bmatrix}. $$ 