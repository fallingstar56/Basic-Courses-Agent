2.5 B Three of these matrices are invertible, and three are singular. Find the inverse when it exists. Give reasons for noninvertibility (zero determinant, too few pivots, nonzero solution to Ax = 0) for the other three. The matrices are in the order A, B, C, D, S, E:

 $$ \left[\begin{array}{l l}{{{4}}}&{{{3}}} \\{{{8}}}&{{{6}}}\end{array}\right]\quad\left[\begin{array}{l l}{{{4}}}&{{{3}}} \\{{{8}}}&{{{7}}}\end{array}\right]\quad\left[\begin{array}{l l}{{{6}}}&{{{6}}} \\{{{6}}}&{{{0}}}\end{array}\right]\quad\left[\begin{array}{l l}{{{6}}}&{{{6}}} \\{{{6}}}&{{{6}}}\end{array}\right]\quad\left[\begin{array}{l l l}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{array}\right]\quad\left[\begin{array}{l l l}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{array}\right] $$ 

Solution

 $$ \boldsymbol{B}^{-1}=\frac{1}{4}\left[\begin{array}{r r}{{{7}}}&{{{-3}}} \\{{{-8}}}&{{{4}}}\end{array}\right]\quad\boldsymbol{C}^{-1}=\frac{1}{36}\left[\begin{array}{r r}{{{0}}}&{{{6}}} \\{{{6}}}&{{{-6}}}\end{array}\right]\quad\boldsymbol{S}^{-1}=\left|\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right| $$ 

A is not invertible because its determinant is  $ 4 \cdot 6 - 3 \cdot 8 = 24 - 24 = 0 $. D is not invertible because there is only one pivot; the second row becomes zero when the first row is subtracted. E has two equal rows (and the second column minus the first column is zero). In other words  $ Ex = 0 $ has the solution  $ x = (-1, 1, 0) $.

Of course all three reasons for noninvertibility would apply to each of A, D, E.

2.5 C Apply the Gauss-Jordan method to invert this triangular “Pascal matrix” L. You see Pascal’s triangle—adding each entry to the entry on its left gives the entry below. The entries of L are “binomial coefficients”. The next row would be 1, 4, 6, 4, 1.

Triangular Pascal matrix

 $$ \boldsymbol{L}=\left[\begin{array}{cccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{3}}}&{{{3}}}&{{{1}}}\end{array}\right]=\mathrm{abs}(\mathrm{pascal}(4,1)) $$ 

Solution Gauss-Jordan starts with  $ [L\ I] $ and produces zeros by subtracting row 1:

 $$ \left[\boldsymbol{L}\boldsymbol{I}\right]=\left[\begin{array}{l l l l|l l l l}{1}&{0}&{0}&{0}&{1}&{0}&{0}&{0}\\ {1}&{1}&{0}&{0}&{0}&{1}&{0}&{0}\\ {1}&{2}&{1}&{0}&{0}&{0}&{1}&{0}\\ {1}&{3}&{3}&{1}&{0}&{0}&{0}&{1}\end{array}\right]\rightarrow\left[\begin{array}{l l l l|l l l l}{1}&{0}&{0}&{0}&{1}&{0}&{0}&{0}\\ {0}&{1}&{0}&{0}&{-1}&{1}&{0}&{0}\\ {0}&{2}&{1}&{0}&{-1}&{0}&{1}&{0}\\ {0}&{3}&{3}&{1}&{-1}&{0}&{0}&{1}\end{array}\right]. $$ 

The next stage creates zeros below the second pivot, using multipliers 2 and 3. Then the last stage subtracts 3 times the new row 3 from the new row 4:

 $$ \begin{aligned}\rightarrow\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{3}}}&{{{1}}}\end{bmatrix}\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{-2}}}&{{{1}}}&{{{0}}} \\{{{2}}}&{{{-3}}}&{{{0}}}&{{{1}}}\end{array}\}\rightarrow\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{-2}}}&{{{1}}}&{{{0}}} \\{{{-1}}}&{{{3}}}&{{{-3}}}&{{{1}}}\end{array}=\left[I\boldsymbol{L}^{-1}\right].\end{aligned} $$ 

All the pivots were 1! So we didn’t need to divide rows by pivots to get I. The inverse matrix  $ L^{-1} $ looks like L itself, except odd-numbered diagonals have minus signs.

The same pattern continues to n by n Pascal matrices.  $ L^{-1} $ has “alternating diagonals”.