The symmetric Pascal matrix  $ P $ is a product of triangular Pascal matrices  $ L $ and  $ U $. The symmetric  $ P $ has Pascal's triangle tilted, so each entry is the sum of the entry above and the entry to the left. The  $ n $ by  $ n $ symmetric  $ P $ is pascal $ (n) $ in MATLAB.

Problem: Establish the amazing lower-upper factorization P = LU.

 $$  pascal\left(4\right)=\left[\begin{array}{cccc}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}} \\{{{1}}}&{{{3}}}&{{{6}}}&{{{10}}} \\{{{1}}}&{{{4}}}&{{{10}}}&{{{20}}} \\\end{array}\right]=\left[\begin{array}{cccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{3}}}&{{{3}}}&{{{1}}} \\\end{array}\right]\left[\begin{array}{cccc}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}} \\\end{array}\right]=LU. $$ 

Then predict and check the next row and column for 5 by 5 Pascal matrices.

Solution You could multiply LU to get P. Better to start with the symmetric P and reach the upper triangular U by elimination:

 $$ P=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}} \\{{{1}}}&{{{3}}}&{{{6}}}&{{{10}}} \\{{{1}}}&{{{4}}}&{{{10}}}&{{{20}}}\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{2}}}&{{{5}}}&{{{9}}} \\{{{0}}}&{{{3}}}&{{{9}}}&{{{19}}}\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{3}}}&{{{10}}}\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}=U. $$ 

The multipliers  $ \ell_{ij} $ that entered these steps go perfectly into L. Then  $ P = LU $ is a particularly neat example. Notice that every pivot is 1 on the diagonal of U.

The next section will show how symmetry produces a special relationship between the triangular L and U. For Pascal, U is the “transpose” of L.

You might expect the MATLAB command lu(pascal(4)) to produce these L and U. That doesn't happen because the lu subroutine chooses the largest available pivot in each column. The second pivot will change from 1 to 3. But a “Cholesky factorization” does no row exchanges: U = chol(pascal(4))

The full proof of  $ P = LU $ for all Pascal sizes is quite fascinating. The paper “Pascal Matrices” is on the course web page web.mit.edu/18.06 which is also available through MIT’s OpenCourseWare at ocw.mit.edu. These Pascal matrices have so many remarkable properties—we will see them again.

2.6 B The problem is: Solve  $ Px = b = (1,0,0,0) $. This right side = column of I means that x will be the first column of  $ P^{-1} $. That is Gauss-Jordan, matching the columns of  $ PP^{-1} = I $. We already know the Pascal matrices L and U as factors of P:

Two triangular systems

 $$ Lc=b(forward)\qquad Ux=c(back). $$ 

Solution The lower triangular system  $ Lc = b $ is solved top to bottom:

 $$ \begin{array}{lll}c_{1}&=1&c_{1}=+1\\c_{1}+\quad c_{2}&=0&c_{2}=-1\\c_{1}+2c_{2}+\quad c_{3}&=0&c_{3}=+1\\c_{1}+3c_{2}+3c_{3}+c_{4}&=0&c_{4}=-1\\\end{array} $$ 