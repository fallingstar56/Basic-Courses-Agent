2.6. Elimination = Factorization: A = LU

 $ Lc = b $ The lower triangular system

 $$ \begin{bmatrix}{{{1}}}&{{{0}}} \\{{{4}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{c}}} \\\end{bmatrix}=\begin{bmatrix}{{{5}}} \\{{{21}}}\end{bmatrix}\quad gave\quad c=\begin{bmatrix}{{{5}}} \\{{{1}}}\end{bmatrix}. $$ 

 $ Ux = c $ The upper triangular system

 $$ \begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\\end{bmatrix}=\begin{bmatrix}{{{5}}} \\{{{1}}}\end{bmatrix}\quad gives\quad\boldsymbol{x}=\begin{bmatrix}{{{3}}} \\{{{1}}}\end{bmatrix}. $$ 

L and U can go into the  $ n^{2} $ storage locations that originally held A (now forgettable).

## The Cost of Elimination

A very practical question is cost—or computing time. We can solve 1000 equations on a PC. What if  $ n = 100,000 $ ? (Is A dense or sparse?) Large systems come up all the time in scientific computing, where a three-dimensional problem can easily lead to a million unknowns. We can let the calculation run overnight, but we can't leave it for 100 years.

The first stage of elimination produces zeros below the first pivot in column 1. To find each new entry below the pivot row requires one multiplication and one subtraction. We will count this first stage as  $ n^2 $ multiplications and  $ n^2 $ subtractions. It is actually less,  $ n^2 - n $, because row 1 does not change.

The next stage clears out the second column below the second pivot. The working matrix is now of size n-1. Estimate this stage by  $ (n-1)^2 $ multiplications and subtractions. The matrices are getting smaller as elimination goes forward. The rough count to reach U is the sum of squares  $ n^2 + (n-1)^2 + \cdots + 2^2 + 1^2 $.

There is an exact formula  $ \frac{1}{3}n\left(n+\frac{1}{2}\right)(n+1) $ for this sum of squares. When n is large, the  $ \frac{1}{2} $ and the 1 are not important. The number that matters is  $ \frac{1}{3}n^3 $. The sum of squares is like the integral of  $ x^2! $ The integral from 0 to n is  $ \frac{1}{3}n^3 $:

Elimination on A requires about  $ \frac{1}{3} n^{3} $ multiplications and  $ \frac{1}{3} n^{3} $ subtractions.

What about the right side $b$? Going forward, we subtract multiples of $b_{1}$ from the lower components $b_{2},\ldots,b_{n}$. This is $n-1$ steps. The second stage takes only $n-2$ steps, because $b_{1}$ is not involved. The last stage of forward elimination takes one step.

Now start back substitution. Computing  $ x_n $ uses one step (divide by the last pivot). The next unknown uses two steps. When we reach  $ x_1 $ it will require  $ n $ steps ( $ n - 1 $ substitutions of the other unknowns, then division by the first pivot). The total count on the right side, from  $ b $ to  $ c $ to  $ x $—forward to the bottom and back to the top—is exactly  $ n^2 $:

 $$ \left[(n-1)+(n-2)+\cdots+1\right]\;+\;\left[1+2+\cdots+(n-1)+n\right]=n^{2}. $$ 

To see that sum, pair off  $ (n-1) $ with 1 and  $ (n-2) $ with 2. The pairings leave n terms, each equal to n. That makes  $ n^2 $. The right side costs a lot less than the left side!

Solve Each right side needs n² multiplications and n² subtractions.

A band matrix B has only w nonzero diagonals below and above its main diagonal. The zero entries outside the band stay zero in elimination (they are zero in L and U).