Now move those E's onto the other side, where their inverses multiply U:

 $$ \begin{array}{r l r l r}{(E_{32}E_{31}E_{21})A=U}&{{}\mathrm{b e c o m e s}}&{}&{{}A=(E_{21}^{-1}E_{31}^{-1}E_{32}^{-1})U}&{{}}&{{}\mathrm{w h i c h~i s}}&{{}A=L U.}\end{array} $$ 

The inverses go in opposite order, as they must. That product of three inverses is L. We have reached A = LU. Now we stop to understand it.

Explanation and Examples

First point: Every inverse matrix  $ E^{-1} $ is lower triangular. Its off-diagonal entry is  $ \ell_{ij} $, to undo the subtraction produced by  $ -\ell_{ij} $. The main diagonals of  $ E $ and  $ E^{-1} $ contain 1's. Our example above had  $ \ell_{21} = 3 $ and  $ E = \begin{bmatrix} 1 & 0 \\ -3 & 1 \end{bmatrix} $ and  $ L = E^{-1} = \begin{bmatrix} 1 & 0 \\ 3 & 1 \end{bmatrix} $.

Second point: Equation (2) shows a lower triangular matrix (the product of the  $ E_{ij} $) multiplying A. It also shows all the  $ E_{ij}^{-1} $ multiplying U to bring back A. This lower triangular product of inverses is L.

One reason for working with the inverses is that we want to factor A, not U. The “inverse form” gives A = LU. Another reason is that we get something extra, almost more than we deserve. This is the third point, showing that L is exactly right.

Third point: Each multiplier  $ \ell_{ij} $ goes directly into its i,j position—unchanged—in the product of inverses which is L. Usually matrix multiplication will mix up all the numbers. Here that doesn’t happen. The order is right for the inverse matrices, to keep the  $ \ell $s unchanged. The reason is given below in equation (2).

Since each  $ E^{-1} $ has 1's down its diagonal, the final good point is that L does too.

This is elimination without row exchanges. The upper triangular U has the pivots on its diagonal. The lower triangular L has all 1's on its diagonal. The multipliers  $ \ell_{ij} $ are below the diagonal of L.

Example 1 Elimination subtracts  $ \frac{1}{2} $ times row 1 from row 2. The last step subtracts  $ \frac{2}{3} $ times row 2 from row 3. The lower triangular  $ L $ has  $ \ell_{21} = \frac{1}{2} $ and  $ \ell_{32} = \frac{2}{3} $. Multiplying  $ LU $ produces  $ A $:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{2}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{\frac{1}{2}}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{\frac{2}{3}}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{\frac{3}{2}}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{\frac{4}{3}}}}\end{bmatrix}=\boldsymbol{L}\boldsymbol{U}. $$ 

The (3, 1) multiplier is zero because the (3, 1) entry in A is zero. No operation needed.

Example 2 Change the top left entry from 2 in A to 1 in B. The pivots all become 1. The multipliers are all 1. That pattern continues when B is 4 by 4:

Special pattern

 $$ \boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{2}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}} \\{{{1}}} \\\end{bmatrix}. $$ 