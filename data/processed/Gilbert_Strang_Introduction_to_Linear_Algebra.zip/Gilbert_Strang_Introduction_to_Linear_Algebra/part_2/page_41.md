7 Which rule is broken if multiplying $f(x)$ by $c$ gives the function $f(cx)$? Keep the usual addition $f(x) + g(x)$.

8 If the sum of the “vectors”  $ f(x) $ and  $ g(x) $ is defined to be the function  $ f(g(x)) $, then the “zero vector” is  $ g(x) = x $. Keep the usual scalar multiplication  $ cf(x) $ and find two rules that are broken.

 $$ x+y $$ 

 $$ c\boldsymbol{x}+d\boldsymbol{y}) $$ 

9 One requirement can be met while the other fails. Show this by finding

(a) A set of vectors in  $ \mathbf{R}^2 $ for which  $ x + y $ stays in the set but  $ \frac{1}{2}x $ may be outside.

(b) A set of vectors in  $ \mathbf{R}^2 $ (other than two quarter-planes) for which every  $ c\mathbf{x} $ stays in the set but  $ \mathbf{x} + \mathbf{y} $ may be outside.

10 Which of the following subsets of  $ R^{3} $ are actually subspaces?

(a) The plane of vectors  $ (b_{1}, b_{2}, b_{3}) $ with  $ b_{1} = b_{2} $.

(b) The plane of vectors with  $ b_{1}=1 $.

(c) The vectors with  $ b_{1}b_{2}b_{3}=0 $.

(d) All linear combinations of  $  v = (1, 4, 0)  $ and  $  w = (2, 2, 2)  $.

(e) All vectors that satisfy  $ b_{1} + b_{2} + b_{3} = 0 $.

(f) All vectors with  $ b_1 \leq b_2 \leq b_3 $.

11 Describe the smallest subspace of the matrix space M that contains

(a)

 $$ \begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}and\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix} $$ 

(b)

 $$ \begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix} $$ 

(c)

 $$ \begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}and\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

Let $P$ be the plane in $\mathbf{R}^3$ with equation $x + y - 2z = 4$. The origin $(0,0,0)$ is not in $P$. Find two vectors in $P$ and check that their sum is not in $P$.

Let  $ P_0 $ be the plane through  $ (0,0,0) $ parallel to the previous plane  $ P $. What is the equation for  $ P_0 $? Find two vectors in  $ P_0 $ and check that their sum is in  $ P_0 $.

The subspaces of  $ R^{3} $ are planes, lines,  $ R^{3} $ itself, or Z containing only  $ (0,0,0) $.

(a) Describe the three types of subspaces of  $ \mathbf{R}^{2} $

(b) Describe all subspaces of D, the space of 2 by 2 diagonal matrices.