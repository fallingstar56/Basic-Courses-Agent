(Recommended) If we add an extra column $b$ to a matrix $A$, then the column space gets larger unless ____. Give an example where the column space gets larger and an example where it doesn't. Why is $A\boldsymbol{x}=\boldsymbol{b}$ solvable exactly when the column space doesn't get larger—it is the same for $A$ and $\left[\begin{array}{c}A\\ b\end{array}\right]$?

The columns of AB are combinations of the columns of A. This means: The column space of AB is contained in (possibly equal to) the column space of A. Give an example where the column spaces of A and AB are not equal.

Suppose  $ Ax = b $ and  $ Ay = b^* $ are both solvable. Then  $ Az = b + b^* $ is solvable. What is  $ z $? This translates into: If  $ b $ and  $ b^* $ are in the column space  $ C(A) $, then  $ b + b^* $ is in  $ C(A) $.

True or false (with a counterexample if false):

(b) If  $ C(A) $ contains only the zero vector, then A is the zero matrix.

If A is any 5 by 5 invertible matrix, then its column space is ___. Why?

(a) The vectors b that are not in the column space  $ C(A) $ form a subspace.

(c) The column space of 2A equals the column space of A.

Construct a 3 by 3 matrix whose column space contains  $ (1, 1, 0) $ and  $ (1, 0, 1) $ but not  $ (1, 1, 1) $. Construct a 3 by 3 matrix whose column space is only a line.

(d) The column space of A - I equals the column space of A (test this).

If the 9 by 12 system Ax = b is solvable for every b, then  $ C(A) = $ ___.

## Challenge Problems

Suppose S and T are two subspaces of a vector space V.

(a) Definition: The sum  $ S + T $ contains all sums  $ s + t $ of a vector  $ s $ in  $ S $ and a vector  $ t $ in  $ T $. Show that  $ S + T $ satisfies the requirements (addition and scalar multiplication) for a vector space.

(b) If S and T are lines in  $ \mathbf{R}^m $, what is the difference between  $ \mathbf{S} + \mathbf{T} $ and  $ \mathbf{S} \cup \mathbf{T} $? That union contains all vectors from S or T or both. Explain this statement: The span of  $ \mathbf{S} \cup \mathbf{T} $ is  $ \mathbf{S} + \mathbf{T} $. (Section 3.5 returns to this word “span”).

If S is the column space of A and T is  $ \mathbf{C}(B) $, then  $ \mathbf{S} + \mathbf{T} $ is the column space of what matrix  $ M $? The columns of A and B and M are all in  $ \mathbf{R}^m $. (I don’t think  $ A + B $ is always a correct  $ M $.)

Show that the matrices A and  $ [A\ AB] $ (with extra columns) have the same column space. But find a square matrix with  $ C(A^2) $ smaller than  $ C(A) $. Important point:

An n by n matrix has  $ C(A) = \mathbf{R}^n $ exactly when A is an ___ matrix.