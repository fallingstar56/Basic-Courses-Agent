Example 5 Describe the column spaces (they are subspaces of  $ \mathbf{R}^{2} $) for

 $$ I=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{4}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{4}}}\end{bmatrix}. $$ 

Solution The column space of $I$ is the whole space $\mathbf{R}^{2}$. Every vector is a combination of the columns of $I$. In vector space language, $C(I)$ is $\mathbf{R}^{2}$.

The column space of A is only a line. The second column  $ (2,4) $ is a multiple of the first column  $ (1,2) $. Those vectors are different, but our eye is on vector spaces. The column space contains  $ (1,2) $ and  $ (2,4) $ and all other vectors  $ (c,2c) $ along that line. The equation  $ Ax = b $ is only solvable when b is on the line.

For the third matrix (with three columns) the column space  $ \mathbf{C}(B) $ is all of  $ \mathbf{R}^2 $. Every  $ \mathbf{b} $ is attainable. The vector  $ \mathbf{b} = (5, 4) $ is column 2 plus column 3, so  $ \mathbf{x} $ can be  $ (0, 1, 1) $. The same vector  $ (5, 4) $ is also 2(column 1) + column 3, so another possible  $ \mathbf{x} $ is  $ (2, 0, 1) $. This matrix has the same column space as  $ \mathbf{I} $—any  $ \mathbf{b} $ is allowed. But now  $ \mathbf{x} $ has extra components and there are more solutions—more combinations that give  $ \mathbf{b} $.

The next section creates a vector space  $ \mathbf{N}(A) $, to describe all the solutions of  $ Ax = 0 $. This section created the column space  $ \mathbf{C}(A) $, to describe all the attainable right sides  $ b $.

## ■ REVIEW OF THE KEY IDEAS ■

1.  $ R^{n} $ contains all column vectors with n real components.

2. M (2 by 2 matrices) and F (functions) and Z (zero vector alone) are vector spaces.

3. A subspace containing v and w must contain all their combinations  $ cv + dw $.

4. The combinations of the columns of A form the column space  $ C(A) $. Then the column space is “spanned” by the columns.

5. Ax = b has a solution exactly when b is in the column space of A.

 $ C(A) = \text{all combinations of the columns} = \text{all vectors } Ax. $

## WORKED EXAMPLES

3.1 A We are given three different vectors  $ b_1 $,  $ b_2 $,  $ b_3 $. Construct a matrix so that the equations  $ Ax = b_1 $ and  $ Ax = b_2 $ are solvable, but  $ Ax = b_3 $ is not solvable. How can you decide if this is possible? How could you construct  $ A $?