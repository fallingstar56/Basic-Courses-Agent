In other words, the set of vectors is “closed” under addition  $ v + w $ and multiplication  $ cv $ (and  $ dw $). Those operations leave us in the subspace. We can also subtract, because  $ -w $ is in the subspace and its sum with  $ v $ is  $ v - w $. In short, all linear combinations stay in the subspace.

All these operations follow the rules of the host space, so the eight required conditions are automatic. We just have to check the linear combinations requirement for a subspace.

First fact: Every subspace contains the zero vector. The plane in  $ R^3 $ has to go through  $ (0, 0, 0) $. We mention this separately, for extra emphasis, but it follows directly from rule (ii). Choose  $ c = 0 $, and the rule requires  $ 0v $ to be in the subspace.

1. lames that don't contain the origin fail those tests. Those planes are not subspaces.

Lines through the origin are also subspaces. When we multiply by 5, or add two vectors on the line, we stay on the line. But the line must go through  $ (0, 0, 0) $.

Another subspace is all of  $ \mathbf{R}^{3} $. The whole space is a subspace (of itself). Here is a list of all the possible subspaces of  $ \mathbf{R}^{3} $:


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>(L) Any line through  $ (0,0,0) $</td><td style='text-align: center; word-wrap: break-word;'>(R $ ^{3} $) The whole space</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(P) Any plane through  $ (0,0,0) $</td><td style='text-align: center; word-wrap: break-word;'>(Z) The single vector  $ (0,0,0) $</td></tr></table>

If we try to keep only part of a plane or line, the requirements for a subspace don't hold. Look at these examples in  $ R^{2} $—they are not subspaces.

Example 1 Keep only the vectors  $ (x, y) $ whose components are positive or zero (this is a quarter-plane). The vector  $ (2, 3) $ is included but  $ (-2, -3) $ is not. So rule (ii) is violated when we try to multiply by  $ c = -1 $. The quarter-plane is not a subspace.

Example 2 Include also the vectors whose components are both negative. Now we have two quarter-planes. Requirement (ii) is satisfied; we can multiply by any c. But rule (i) now fails. The sum of  $ v = (2, 3) $ and  $ w = (-3, -2) $ is  $ (-1, 1) $, which is outside the quarter-planes. Two quarter-planes don't make a subspace.

Rules (i) and (ii) involve vector addition  $ v + w $ and multiplication by scalars c and d. The rules can be combined into a single requirement—the rule for subspaces:

A subspace containing v and w must contain all linear combinations cv + dw.

Example 3 Inside the vector space M of all 2 by 2 matrices, here are two subspaces:

(U) All upper triangular matrices  $ \begin{bmatrix} a & b \\ 0 & d \end{bmatrix} $ (D) All diagonal matrices  $ \begin{bmatrix} a & 0 \\ 0 & d \end{bmatrix} $.

Add any two matrices in U, and the sum is in U. Add diagonal matrices, and the sum is diagonal. In this case D is also a subspace of U! Of course the zero matrix is in these subspaces, when a, b, and d all equal zero. Z is always a subspace.

Multiples of the identity matrix also form a subspace.  $ 2I + 3I $ is in this subspace, and so is 3 times 4I. The matrices  $ cI $ form a “line of matrices” inside M and U and D.