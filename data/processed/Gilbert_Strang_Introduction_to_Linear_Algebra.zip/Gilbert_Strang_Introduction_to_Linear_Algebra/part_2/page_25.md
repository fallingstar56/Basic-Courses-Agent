## WORKED EXAMPLES

2.7 A Applying the permutation P to the rows of S destroys its symmetry:

 $$ P=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}\qquad S=\begin{bmatrix}{{{1}}}&{{{4}}}&{{{5}}} \\{{{4}}}&{{{2}}}&{{{6}}} \\{{{5}}}&{{{6}}}&{{{3}}}\end{bmatrix}\qquad PS=\begin{bmatrix}{{{4}}}&{{{2}}}&{{{6}}} \\{{{5}}}&{{{6}}}&{{{3}}} \\{{{1}}}&{{{4}}}&{{{5}}}\end{bmatrix} $$ 

What permutation Q applied to the columns of PS will recover symmetry in PSQ? The numbers 1, 2, 3 must come back to the main diagonal (not necessarily in order). Show that Q is  $ P^{\mathrm{T}} $, so that symmetry is saved by  $ PSP^{\mathrm{T}} $.

Solution To recover symmetry and put “2” back on the diagonal, column 2 of PS must move to column 1. Column 3 of PS (containing “3”) must move to column 2. Then the “1” moves to the 3, 3 position. The matrix that permits columns is Q:

 $$ PS={\left[\begin{array}{l l l}{4}&{2}&{6}\\ {5}&{6}&{3}\\ {1}&{4}&{5}\end{array}\right]} \qquad Q={\left[\begin{array}{l l l}{0}&{0}&{1}\\ {1}&{0}&{0}\\ {0}&{1}&{0}\end{array}\right]} \qquad PSQ={\left[\begin{array}{l l l}{2}&{6}&{4}\\ {6}&{3}&{5}\\ {4}&{5}&{1}\end{array}\right]} $$ 

is symmetric.

The matrix  $ Q $ is  $ P^\mathrm{T} $. This choice always recovers symmetry, because  $ PSP^\mathrm{T} $ is guaranteed to be symmetric. (Its transpose is again  $ PSP^\mathrm{T} $.) The matrix  $ Q $ is also  $ P^{-1} $, because the inverse of every permutation matrix is its transpose.

If $D$ is a diagonal matrix, we are finding that $PDP^{\mathrm{T}}$ is also diagonal. When $P$ moves row 1 down to row 3, $P^{\mathrm{T}}$ on the right will move column 1 to column 3. The $(1,1)$ entry moves down to $(3,1)$ and over to $(3,3)$.

2.7 B Find the symmetric factorization  $ S = LDL^{\mathrm{T}} $ for the matrix S above.

Solution To factor S into  $ LDL^{T} $ we eliminate as usual to reach U :

 $$ S=\begin{bmatrix}{{{1}}}&{{{4}}}&{{{5}}} \\{{{4}}}&{{{2}}}&{{{6}}} \\{{{5}}}&{{{6}}}&{{{3}}}\end{bmatrix}\longrightarrow\begin{bmatrix}{{{1}}}&{{{4}}}&{{{5}}} \\{{{0}}}&{{{-14}}}&{{{-14}}} \\{{{0}}}&{{{-14}}}&{{{-22}}}\end{bmatrix}\longrightarrow\begin{bmatrix}{{{1}}}&{{{4}}}&{{{5}}} \\{{{0}}}&{{{-14}}}&{{{-14}}} \\{{{0}}}&{{{0}}}&{{{-8}}}\end{bmatrix}=U. $$ 

The multipliers were  $ \ell_{21} = 4 $ and  $ \ell_{31} = 5 $ and  $ \ell_{32} = 1 $. The pivots 1, -14, -8 go into D. When we divide the rows of U by those pivots,  $ L^{\mathrm{T}} $ should appear:

Symmetric

factorization

when  $ S = S^{T} $

 $$ \boldsymbol{S}=\boldsymbol{L}\boldsymbol{D}\boldsymbol{L}^{\mathrm{T}}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{4}}}&{{{1}}}&{{{0}}} \\{{{5}}}&{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{-14}}} \\{{{-8}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{4}}}&{{{5}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

This matrix $S$ is invertible because it has three pivots. Its inverse is $(L^{\mathrm{T}})^{-1}D^{-1}L^{-1}$ and $S^{-1}$ is also symmetric. The numbers 14 and 8 will turn up in the denominators of $S^{-1}$. The “determinant” of $S$ is the product of the pivots (1)(-14)(-8) = 112.