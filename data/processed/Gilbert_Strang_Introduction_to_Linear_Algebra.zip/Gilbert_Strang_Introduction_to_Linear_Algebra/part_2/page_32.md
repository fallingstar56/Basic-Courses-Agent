# Chapter 3

# Vector Spaces and Subspaces

### 3.1 Spaces of Vectors

1 The standard $n$-dimensional space $\mathbf{R}^n$ contains all real column vectors with $n$ components.
2 If $v$ and $w$ are in a vector space $S$, every combination $cv + dw$ must be in $S$.
3 The “vectors” in $S$ can be matrices or functions of $x$. The 1-point space $Z$ consists of $x = 0$.
4 A subspace of $\mathbf{R}^n$ is a vector space inside $\mathbf{R}^n$. Example: The line $y = 3x$ inside $\mathbf{R}^2$.
5 The column space of $A$ contains all combinations of the columns of $A$: a subspace of $\mathbf{R}^m$.
6 The column space contains all the vectors $Ax$. So $Ax = b$ is solvable when $b$ is in $C(A)$.

To a newcomer, matrix calculations involve a lot of numbers. To you, they involve vectors. The columns of Ax and AB are linear combinations of n vectors—the columns of A. This chapter moves from numbers and vectors to a third level of understanding (the highest level). Instead of individual columns, we look at “spaces” of vectors. Without seeing vector spaces and especially their subspaces, you haven’t understood everything about Ax = b.

Since this chapter goes a little deeper, it may seem a little harder. That is natural. We are looking inside the calculations, to find the mathematics. The author’s job is to make it clear. The chapter ends with the “Fundamental Theorem of Linear Algebra”.

We begin with the most important vector spaces. They are denoted by  $ \mathbf{R}^1 $,  $ \mathbf{R}^2 $,  $ \mathbf{R}^3 $,  $ \mathbf{R}^4 $,  $ \ldots $. Each space  $ \mathbf{R}^n $ consists of a whole collection of vectors.  $ \mathbf{R}^5 $ contains all column vectors with five components. This is called “5-dimensional space”.

DEFINITION The space  $ R^{n} $ consists of all column vectors v with n components.