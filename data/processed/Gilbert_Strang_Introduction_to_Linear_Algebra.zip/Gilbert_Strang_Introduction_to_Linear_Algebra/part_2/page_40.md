### Problem Set 3.1

The first problems 1–8 are about vector spaces in general. The vectors in those spaces are not necessarily column vectors. In the definition of a vector space, vector addition  $ x + y $ and scalar multiplication  $ cx $ must obey the following eight rules:

(1)  $ x + y = y + x $

 $$ x+(y+z)=(x+y)+z $$ 

(3) There is a unique “zero vector” such that  $ x + 0 = x $ for all x

(4) For each x there is a unique vector  $ -x $ such that  $ x + (-x) = 0 $

(5) 1 times x equals x

(6)  $ (c_{1}c_{2})x = c_{1}(c_{2}x) $

(1) to (4) about  $ x + y $

(7)  $ c(x + y) = cx + cy $

(5) to (6) about  $ cx $

(8) $ (c_{1}+c_{2})x=c_{1}x+c_{2}x. $

(7) to (8) connects them

1 Suppose  $ (x_{1}, x_{2}) + (y_{1}, y_{2}) $ is defined to be  $ (x_{1} + y_{2}, x_{2} + y_{1}) $. With the usual multiplication  $ cx = (cx_{1}, cx_{2}) $, which of the eight conditions are not satisfied?

2 Suppose the multiplication $cx$ is defined to produce $(cx_1,0)$ instead of $(cx_1,cx_2)$. With the usual addition in $\mathbf{R}^2$, are the eight conditions satisfied?

3 (a) Which rules are broken if we keep only the positive numbers  $ x > 0 $ in  $ R^1 $? Every  $ c $ must be allowed. The half-line is not a subspace.

(b) The positive numbers with  $ x + y $ and  $ cx $ redefined to equal the usual  $ xy $ and  $ x^c $ do satisfy the eight rules. Test rule 7 when  $ c = 3 $,  $ x = 2 $,  $ y = 1 $. (Then  $ x + y = 2 $ and  $ cx = 8 $). Which number acts as the “zero vector”?

4 The matrix  $ A = \begin{bmatrix} 2 & -2 \\ 2 & -2 \end{bmatrix} $ is a “vector” in the space M of all 2 by 2 matrices. Write down the zero vector in this space, the vector  $ \frac{1}{2}A $, and the vector  $ -A $. What matrices are in the smallest subspace containing  $ A $?

5 (a) Describe a subspace of M that contains  $ A = \begin{bmatrix} 1 & 0 \\ 0 & 0 \end{bmatrix} $ but not  $ B = \begin{bmatrix} 0 & 0 \\ 0 & -1 \end{bmatrix} $.

(b) If a subspace of M does contain A and B, must it contain I?

(c) Describe a subspace of M that contains no nonzero diagonal matrices.

6 The functions  $ f(x) = x^2 $ and  $ g(x) = 5x $ are “vectors” in F. This is the vector space of all real functions. (The functions are defined for  $ -\infty < x < \infty $.) The combination  $ 3f(x) - 4g(x) $ is the function  $ h(x) = $ ___.