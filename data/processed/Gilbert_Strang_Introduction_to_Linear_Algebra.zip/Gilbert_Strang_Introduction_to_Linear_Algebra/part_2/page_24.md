We started with A and ended with U. The only requirement is invertibility of A.

If A is invertible, a permutation P will put its rows in the right order to factor PA = LU. There must be a full set of pivots after row exchanges for A to be invertible.

In MATLAB,  $ A([r\ k],:) = A([k\ r],:) $ exchanges row  $ k $ with row  $ r $ below it (where the  $ k $th pivot has been found). Then the  $ \mathbf{l}\mathbf{u} $ code updates  $ L $ and  $ P $ and the sign of  $ P $:

 $$ \begin{array}{l l l}{{{\mathrm{T h i s~i s~p a r t~o f}}}}&{{\quad}}&{{A\left([r\mathrm{~}k\mathrm{~}],:)\right.=A\left([k\mathrm{~}r\mathrm{~}],:;\right)}}\\ {{[L,U,P]={\bf l u}\left(A\right)}}&{{\quad}}&{{L\left([r\mathrm{~}k\mathrm{~}],1:k-1\right)=L\left([k\mathrm{~}r\mathrm{~}],1:k-1\right);}}\\ {{}}&{{\quad}}&{{P\left([r\mathrm{~}k\mathrm{~}],:)\right.=P\left([k\mathrm{~}r\mathrm{~}],:;\right)}}\\ {{}}&{{\quad}}&{{\mathrm{s i g n}=-\mathrm{s i g n}}}\end{array} $$ 

The “sign” of P tells whether the number of row exchanges is even (sign = +1). An odd number of row exchanges will produce sign = -1. At the start, P is I and sign = +1. When there is a row exchange, the sign is reversed. The final value of sign is the determinant of P and it does not depend on the order of the row exchanges.

For PA we get back to the familiar LU. In reality, a code like  $ \textbf{lu}(A) $ often does not use the first available pivot. Mathematically we can accept a small pivot— anything but zero. All good codes look down the column for the largest pivot.

Section 11.1 explains why this “partial pivoting” reduces the roundoff error. Then P may contain row exchanges that are not algebraically necessary. Still PA = LU.

Our advice is to understand permutations but let the computer do the work. Calculations of $A = LU$ are enough to do by hand, without $P$. The Teaching Code splu ($A$) factors $PA = LU$ and splv ($A, b$) solves $Ax = b$ for any invertible $A$. The program splu on the website stops if no pivot can be found in column $k$. Then $A$ is not invertible.

## ■ REVIEW OF THE KEY IDEAS

1. The transpose puts the rows of A into the columns of  $ A^{\mathrm{T}} $. Then  $ (A^{\mathrm{T}})_{ij} = A_{ji} $.

2. The transpose of AB is  $ B^{\mathrm{T}} A^{\mathrm{T}} $. The transpose of  $ A^{-1} $ is the inverse of  $ A^{\mathrm{T}} $.

3. The dot product is  $ \boldsymbol{x} \cdot \boldsymbol{y} = \boldsymbol{x}^{\mathrm{T}} \boldsymbol{y} $. Then  $ (Ax)^{\mathrm{T}} y $ equals the dot product  $ \boldsymbol{x}^{\mathrm{T}} (A^{\mathrm{T}} y) $.

4. When $S$ is symmetric ($S^{\mathrm{T}} = S$), its $LDU$ factorization is symmetric: $S = LDL^{\mathrm{T}}$.

5. A permutation matrix  $ P $ has a 1 in each row and column, and  $ P^\mathrm{T} = P^{-1} $.

6. There are n! permutation matrices of size n. Half even, half odd.

7. If A is invertible then a permutation P will reorder its rows for PA = LU.