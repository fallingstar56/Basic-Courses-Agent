(a) When you apply the usual elimination steps to L, what matrix do you reach?

 $$ L=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{\ell_{21}}}}&{{{1}}}&{{{0}}} \\{{{\ell_{31}}}}&{{{\ell_{32}}}}&{{{1}}}\end{bmatrix}. $$ 

(b) When you apply the same steps to I, what matrix do you get?

(c) When you apply the same steps to LU, what matrix do you get?

If $A = LDU$ and also $A = L_{1}D_{1}U_{1}$ with all factors invertible, then $L = L_{1}$ and $D = D_{1}$ and $U = U_{1}$. “The three factors are unique.”

Derive the equation  $ L_1^{-1} LD = D_1 U_1 U^{-1} $. Are the two sides triangular or diagonal?

Deduce  $ L = L_1 $ and  $ U = U_1 $ (they all have diagonal 1's). Then  $ D = D_1 $.

Tridiagonal matrices have zero entries except on the main diagonal and the two adjacent diagonals. Factor these into  $ A = LU $ and  $ A = LDL^{\mathrm{T}} $:

When T is tridiagonal, its L and U factors have only two nonzero diagonals. How would you take advantage of knowing the zeros in T, in a code for Gaussian elimination? Find L and U.

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}\end{bmatrix}\quad and\quad\boldsymbol{A}=\begin{bmatrix}{{{a}}}&{{{a}}}&{{{0}}} \\{{{a}}}&{{{a+b}}}&{{{b}}} \\{{{0}}}&{{{b}}}&{{{b+c}}}\end{bmatrix}. $$ 

Tridiagonal

 $$ T=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{0}}}&{{{0}}} \\{{{2}}}&{{{3}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{3}}}&{{{4}}}\end{bmatrix}. $$ 

If A and B have nonzeros in the positions marked by x, which zeros (marked by 0) stay zero in their factors L and U?

 $$ \boldsymbol{A}=\begin{bmatrix}{{{x}}}&{{{x}}}&{{{x}}}&{{{x}}} \\{{{x}}}&{{{x}}}&{{{x}}}&{{{0}}} \\{{{0}}}&{{{x}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{x}}}&{{{x}}}\end{bmatrix}\qquad\boldsymbol{B}=\begin{bmatrix}{{{x}}}&{{{x}}}&{{{x}}}&{{{0}}} \\{{{x}}}&{{{x}}}&{{{0}}}&{{{x}}} \\{{{x}}}&{{{0}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{x}}}&{{{x}}}&{{{x}}}\end{bmatrix}. $$ 

Suppose you eliminate upwards (almost unheard of). Use the last row to produce zeros in the last column (the pivot is 1). Then use the second row to produce zero above the second pivot. Find the factors in the unusual order A = UL.

Upper times lower

 $$ A=\begin{bmatrix}{{{5}}}&{{{3}}}&{{{1}}} \\{{{3}}}&{{{3}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix}. $$ 

Easy but important. If A has pivots 5, 9, 3 with no row exchanges, what are the pivots for the upper left 2 by 2 submatrix  $ A_{2} $ (without row 3 and column 3)?