More important:  $ P^{-1} $ is always the same as  $ P^{\mathrm{T}} $. The two matrices on the right are transposes—and inverses—of each other. When we multiply  $ PP^{\mathrm{T}} $, the “1” in the first row of  $ P $ hits the “1” in the first column of  $ P^{\mathrm{T}} $ (since the first row of  $ P $ is the first column of  $ P^{\mathrm{T}} $). It misses the ones in all the other columns. So  $ PP^{\mathrm{T}} = I $.

Another proof of  $ P^{\mathrm{T}} = P^{-1} $ looks at P as a product of row exchanges. Every row exchange is its own transpose and its own inverse.  $ P^{\mathrm{T}} $ and  $ P^{-1} $ both come from the product of row exchanges in reverse order. So  $ P^{\mathrm{T}} $ and  $ P^{-1} $ are the same.

Permutations (row exchanges before elimination) lead to PA = LU

## The PA = LU Factorization with Row Exchanges

We sure hope you remember  $ A = LU $. It started with  $ A = (E_{21}^{-1} \cdots E_{ij}^{-1} \cdots)U $. Every elimination step was carried out by an  $ E_{ij} $ and it was inverted by  $ E_{ij}^{-1} $. Those inverses were compressed into one matrix  $ L $. The lower triangular  $ L $ has 1's on the diagonal, and the result is  $ A = LU $.

This is a great factorization, but it doesn't always work. Sometimes row exchanges are needed to produce pivots. Then  $ A = (E^{-1} \cdots P^{-1} \cdots E^{-1} \cdots P^{-1} \cdots) U $. Every row exchange is carried out by a  $ P_{ij} $ and inverted by that  $ P_{ij} $. We now compress those row exchanges into a single permutation matrix  $ P $. This gives a factorization for every invertible matrix  $ A $—which we naturally want.

The main question is where to collect the  $ P_{ij} $'s. There are two good possibilities—do all the exchanges before elimination, or do them after the  $ E_{ij} $'s. The first way gives PA = LU. The second way has a permutation matrix  $ P_1 $ in the middle.

1. The row exchanges can be done in advance. Their product P puts the rows of A in the right order, so that no exchanges are needed for PA. Then PA = LU.

2. If we hold row exchanges until after elimination, the pivot rows are in a strange order.  $ P_{1} $ puts them in the correct triangular order in  $ U_{1} $. Then  $ A = L_{1}P_{1}U_{1} $.

PA = LU is constantly used in all computing. We will concentrate on this form.

The factorization  $ A = L_1 P_1 U_1 $ might be more elegant. If we mention both, it is because the difference is not well known. Probably you will not spend a long time on either one. Please don't. The most important case has  $ P = I $, when  $ A $ equals  $ L U $ with no exchanges.

This matrix A starts with  $ a_{11} = 0 $. Exchange rows 1 and 2 to bring the first pivot into its usual place. Then go through elimination on PA:

 $$ \begin{bmatrix}{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{2}}}&{{{7}}}&{{{9}}} \\\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{2}}}&{{{7}}}&{{{9}}} \\\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{3}}}&{{{7}}} \\\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{4}}} \\\end{bmatrix}. $$ 

The matrix PA has its rows in good order, and it factors as usual into LU:

 $$ \boldsymbol{P}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad\boldsymbol{P}\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{2}}}&{{{3}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{4}}}\end{bmatrix}=\boldsymbol{L}\boldsymbol{U}. $$ 