### 3.2 The Nullspace of A: Solving Ax = 0 and Rx = 0

(1) The nullspace  $ N(A) $ in  $ R^n $ contains all solutions  $ x $ to  $ Ax = 0 $. This includes  $ x = 0 $.

2 Elimination (from  $ A $ to  $ U $ to  $ R $) does not change the nullspace:  $ N(A) = N(U) = N(R) $.

3 The reduced row echelon form  $ R = \text{rref}(A) $ has all pivots = 1, with zeros above and below.

4 If column  $ j $ of  $ R $ is free (no pivot), there is a “special solution” to  $ Ax = 0 $ with  $ x_j = 1 $.

5 Number of pivots = number of nonzero rows in  $ R = \text{rank} r $. There are  $ n - r $ free columns.

6 Every matrix with  $ m < n $ has nonzero solutions to  $ Ax = 0 $ in its nullspace.

This section is about the subspace containing all solutions to  $ Ax = 0 $. The m by n matrix A can be square or rectangular. The right hand side is  $ \mathbf{b} = \mathbf{0} $. One immediate solution is  $ \mathbf{x} = \mathbf{0} $. For invertible matrices this is the only solution. For other matrices, not invertible, there are nonzero solutions to  $ Ax = \mathbf{0} $. Each solution x belongs to the nullspace of A.

Elimination will find all solutions and identify this very important subspace.

The nullspace  $ N(A) $ consists of all solutions to Ax = 0. These vectors x are in  $ R^{n} $.

Check that the solution vectors form a subspace. Suppose x and y are in the nullspace (this means Ax = 0 and Ay = 0). The rules of matrix multiplication give  $ A(x + y) = 0 + 0 $. The rules also give  $ A(cx) = c0 $. The right sides are still zero. Therefore  $ x + y $ and  $ cx $ are also in the nullspace  $ N(A) $. Since we can add and multiply without leaving the nullspace, it is a subspace.

To repeat: The solution vectors x have n components. They are vectors in  $ \mathbf{R}^n $, so the nullspace is a subspace of  $ \mathbf{R}^n $. The column space  $ C(A) $ is a subspace of  $ \mathbf{R}^m $.

Example 1 Describe the nullspace of  $ A = \begin{bmatrix} 1 & 2 \\ 3 & 6 \end{bmatrix} $. This matrix is singular!

Solution Apply elimination to the linear equations Ax = 0:

 $$ \begin{array}{ccc}x_{1}+2x_{2}=0& \quad \rightarrow & \quad x_{1}+2x_{2}=0\\3x_{1}+6x_{2}=0& \quad \rightarrow & \quad \mathbf{0}=\mathbf{0}\end{array} $$ 

There is really only one equation. The second equation is the first equation multiplied by 3. In the row picture, the line  $ x_1 + 2x_2 = 0 $ is the same as the line  $ 3x_1 + 6x_2 = 0 $. That line is the nullspace  $ \mathbf{N}(A) $. It contains all solutions  $ (x_1, x_2) $.

To describe the solutions to Ax = 0, here is an efficient way. Choose one point on the line (one “special solution”). Then all points on the line are multiples of this one. We choose the second component to be  $ x_2 = 1 $ (a special choice). From the equation  $ x_1 + 2x_2 = 0 $, the first component must be  $ x_1 = -2 $. The special solution is  $ s = (-2, 1) $.