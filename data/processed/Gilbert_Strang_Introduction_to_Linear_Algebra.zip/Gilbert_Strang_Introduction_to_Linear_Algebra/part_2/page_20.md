## The Meaning of Inner Products

We know the dot product (inner product) of x and y. It is the sum of numbers  $ x_{i}y_{i} $. Now we have a better way to write  $ x \cdot y $, without using that unprofessional dot. Use matrix notation instead:

T is inside The dot product or inner product is  $ x^{\mathrm{T}}y $  $ (1 \times n)(n \times 1) $

T is outside The rank one product or outer product is xyT  $ (n \times 1)(1 \times n) $

 $ x^{\mathrm{T}} y $ is a number,  $ xy^{\mathrm{T}} $ is a matrix. Quantum mechanics would write those as  $ < x | y > $ (inner) and  $  | x > < y |  $ (outer). Maybe the universe is governed by linear algebra. Here are three more examples where the inner product has meaning:

 $$ \begin{aligned}&From mechanics\quad&Work=(Movements)(Forces)=x^{T}f\\&From circuits\quad&Heat loss=(Voltage drops)(Currents)=e^{T}y\\&From economics\quad&Income=(Quantities)(Prices)=q^{T}p\end{aligned} $$ 

We are really close to the heart of applied mathematics, and there is one more point to emphasize. It is the deeper connection between inner products and the transpose of A.

We defined  $ A^{\mathrm{T}} $ by flipping the matrix across its main diagonal. That’s not mathematics. There is a better way to approach the transpose.  $ A^{\mathrm{T}} $ is the matrix that makes these two inner products equal for every x and y:

 $ (Ax)^{\mathrm{T}}y = x^{\mathrm{T}}(A^{\mathrm{T}}y) $ Inner product of Ax with y = Inner product of x with  $ A^{\mathrm{T}}y $

 $$ Start with A=\begin{bmatrix}{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{bmatrix}\qquad\boldsymbol{x}=\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{bmatrix}\qquad\boldsymbol{y}=\begin{bmatrix}{{{y_{1}}}} \\{{{y_{2}}}}\end{bmatrix} $$ 

On one side we have  $ Ax $ multiplying  $ \boldsymbol{y} $:  $ (x_2 - x_1)y_1 + (x_3 - x_2)y_2 $

That is the same as  $ x_1(-y_1) + x_2(y_1 - y_2) + x_3(y_2) $. Now  $ \boldsymbol{x} $ is multiplying  $ A^\mathrm{T}\boldsymbol{y} $.

 $$ \boldsymbol{A}^{\mathrm{T}}\boldsymbol{y}must be\begin{bmatrix}{{{-y_{1}}}} \\{{{y_{1}-y_{2}}}} \\{{{y_{2}}}}\end{bmatrix}which produces\quad\boldsymbol{A}^{\mathrm{T}}=\begin{bmatrix}{{{-1}}}&{{{0}}} \\{{{1}}}&{{{-1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}as expected. $$ 

Symmetric Matrices

For a symmetric matrix, transposing  $ A $ to  $ A^\top $ produces no change. Then  $ A^\top $ equals  $ A $. Its  $ (j, i) $ entry across the main diagonal equals its  $ (i, j) $ entry. In my opinion, these are the most important matrices of all. We give symmetric matrices the special letter  $ S $.

DEFINITION A symmetric matrix has  $ S^{\mathrm{T}} = S $. This means that  $ s_{ji} = s_{ij} $