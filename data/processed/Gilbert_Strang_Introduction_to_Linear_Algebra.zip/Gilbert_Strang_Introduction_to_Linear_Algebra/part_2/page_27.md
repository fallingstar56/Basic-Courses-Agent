(a) The row vector xT times A times the column y produces what number?

 $$ \boldsymbol{x}^{\mathrm{T}}\boldsymbol{A}\boldsymbol{y}=\begin{bmatrix}{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{4}}}&{{{5}}}&{{{6}}}\end{bmatrix}\begin{bmatrix}{{{0}}} \\{{{1}}} \\{{{0}}}\end{bmatrix}=\underline{\quad}. $$ 

(b) This is the row  $ x^{T}A = \_\_\_\_\_\_  $ times the column  $ y = (0,1,0) $.

(c) This is the row  $ x^T = [0\ 1] $ times the column  $ Ay = \_\_\_ $.

6 The transpose of a block matrix  $ M = \begin{bmatrix} A & B \\ C & D \end{bmatrix} $ is  $ M^{T} = \_\_\_ $. Test an example. Under what conditions on A, B, C, D is the block matrix symmetric?

7 True or false :

(a) The block matrix  $ \left[\begin{array}{cc}0 & A \\ A & 0\end{array}\right] $ is automatically symmetric.

(b) If A and B are symmetric then their product AB is symmetric.

(c) If A is not symmetric then  $ A^{-1} $ is not symmetric.

(d) When A, B, C are symmetric, the transpose of ABC is CBA.

Questions 8–15 are about permutation matrices.

8 Why are there n! permutation matrices of order n?

9 If $P_{1}$ and $P_{2}$ are permutation matrices, so is $P_{1}P_{2}$. This still has the rows of $I$ in some order. Give examples with $P_{1}P_{2} \neq P_{2}P_{1}$ and $P_{3}P_{4} = P_{4}P_{3}$.

There are 12 “even” permutations of  $ (1,2,3,4) $, with an even number of exchanges. Two of them are  $ (1,2,3,4) $ with no exchanges and  $ (4,3,2,1) $ with two exchanges. List the other ten. Instead of writing each 4 by 4 matrix, just order the numbers.

11 Which permutation makes PA upper triangular? Which permutations make  $ P_{1}AP_{2} $ lower triangular? Multiplying A on the right by  $ P_{2} $ exchanges the ___ of A.

 $$ A=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{6}}} \\{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{4}}}&{{{5}}}\end{bmatrix}. $$ 

12 Explain why the dot product of x and y equals the dot product of Px and Py. Then  $ (Px)^{\mathrm{T}}(Py) = x^{\mathrm{T}}y $ tells us that  $ P^{\mathrm{T}}P = I $ for any permutation. With  $ x = (1,2,3) $ and  $ y = (1,4,2) $ choose P to show that  $ Px \cdot y $ is not always  $ x \cdot Py $.

(a) Find a 3 by 3 permutation matrix with  $ P^{3} = I $ (but not P = I).

(b) Find a 4 by 4 permutation  $ \widehat{P} $ with  $ \widehat{P}^4 \neq I $.

If $P$ has 1's on the antidiagonal from $(1,n)$ to $(n,1)$, describe $PAP$. Note $P = P^{\mathrm{T}}$