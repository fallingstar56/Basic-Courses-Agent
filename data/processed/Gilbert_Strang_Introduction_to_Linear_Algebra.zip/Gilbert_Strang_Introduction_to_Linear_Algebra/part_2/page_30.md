Producing  $ x_1 $ trucks and  $ x_2 $ planes needs  $ x_1 + 50x_2 $ tons of steel,  $ 40x_1 + 1000x_2 $ pounds of rubber, and  $ 2x_1 + 50x_2 $ months of labor. If the unit costs  $ y_1, y_2, y_3 $ are 700 per ton, 3 per pound, and 3000 per month, what are the values of one truck and one plane? Those are the components of  $ A^\mathrm{T}y $.

Ax gives the amounts of steel, rubber, and labor to produce x in Problem 31. Find A. Then Ax  $ \cdot $ y is the ___ of inputs while x  $ \cdot $  $ A^{T}y $ is the value of ___.

The matrix $P$ that multiplies $(x,y,z)$ to give $(z,x,y)$ is also a rotation matrix. Find $P$ and $P^3$. The rotation axis $a = (1,1,1)$ doesn't move, it equals $P a$. What is the angle of rotation from $v = (2,3,-5)$ to $P v = (-5,2,3)?$

Write  $ A = \begin{bmatrix} 1 & 2 \\ 4 & 9 \end{bmatrix} $ as the product ES of an elementary row operation matrix E and a symmetric matrix S.

34 Here is a new factorization of A into LS : triangular (with 1's) times symmetric :

Start from $A = LDU$. Then $A$ equals $L\left(U^{\mathrm{T}}\right)^{-1}$ times $S = U^{\mathrm{T}}DU$.

Why is $L\left(U^{\mathrm{T}}\right)^{-1}$ triangular? Its diagonal is all $1^{\prime}$s. Why is $U^{\mathrm{T}}DU$ symmetric?

A group of matrices includes AB and  $ A^{-1} $ if it includes A and B. “Products and inverses stay in the group.” Which of these sets are groups?

Lower triangular matrices L with 1's on the diagonal, symmetric matrices S, positive matrices M, diagonal invertible matrices D, permutation matrices P, matrices with  $ Q^{\mathrm{T}} = Q^{-1} $. Invent two more matrix groups.

## Challenge Problems

A square northwest matrix $B$ is zero in the southeast corner, below the antidiagonal that connects $(1,n)$ to $(n,1)$. Will $B^{\mathrm{T}}$ and $B^{2}$ be northwest matrices? Will $B^{-1}$ be northwest or southeast? What is the shape of $BC = \text{northwest times southeast}$?

If you take powers of a permutation matrix, why is some  $ P^k $ eventually equal to  $ I $? Find a 5 by 5 permutation  $ P $ so that the smallest power to equal  $ I $ is  $ P^6 $.

(a) Write down any 3 by 3 matrix  $ M $. Split  $ M $ into  $ S + A $ where  $ S = S^{\mathrm{T}} $ is symmetric and  $ A = -A^{\mathrm{T}} $ is anti-symmetric.

(b) Find formulas for S and A involving M and  $ M^{T} $. We want  $ M = S + A $.

Suppose  $ Q^{\mathrm{T}} $ equals  $ Q^{-1} $ (transpose equals inverse, so  $ Q^{\mathrm{T}}Q = I $).

(a) Show that the columns  $ q_1, \ldots, q_n $ are unit vectors:  $ \|q_i\|^2 = 1 $.

(b) Show that every two columns of Q are perpendicular:  $ \boldsymbol{q}_{1}^{\mathrm{T}}\boldsymbol{q}_{2}=0 $.

(c) Find a 2 by 2 example with first entry  $ q_{11} = \cos \theta $.