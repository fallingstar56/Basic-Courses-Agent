10 Find the inverses (in any legal way) of

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{3}}}&{{{0}}} \\{{{0}}}&{{{4}}}&{{{0}}}&{{{0}}} \\{{{5}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{bmatrix}{{{3}}}&{{{2}}}&{{{0}}}&{{{0}}} \\{{{4}}}&{{{3}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{6}}}&{{{5}}} \\{{{0}}}&{{{0}}}&{{{7}}}&{{{6}}}\end{bmatrix}. $$ 

(a) Find invertible matrices A and B such that  $ A + B $ is not invertible.

(b) Find singular matrices A and B such that  $ A + B $ is invertible.

If the product  $ C = AB $ is invertible (A and B are square), then A itself is invertible. Find a formula for  $ A^{-1} $ that involves  $ C^{-1} $ and B.

If the product $M = ABC$ of three square matrices is invertible, then $B$ is invertible. (So are $A$ and $C$) Find a formula for $B^{-1}$ that involves $M^{-1}$ and $A$ and $C$.

14 If you add row 1 of A to row 2 to get B, how do you find  $ B^{-1} $ from  $ A^{-1} $?

Notice the order. The inverse of  $ B = \begin{bmatrix} 1 & 0 \\ 1 & 1 \end{bmatrix} \left[ \begin{array}{cc} A & \\ & \end{array} \right] $ is ___.

Prove that a matrix with a column of zeros cannot have an inverse.

Multiply  $ \begin{bmatrix} a & b \\ c & d \end{bmatrix} $ times  $ \begin{bmatrix} d & -b \\ -c & a \end{bmatrix} $. What is the inverse of each matrix if  $ ad \neq bc $?

(a) What 3 by 3 matrix E has the same effect as these three steps? Subtract row 1 from row 2, subtract row 1 from row 3, then subtract row 2 from row 3.

(b) What single matrix L has the same effect as these three reverse steps? Add row 2 to row 3, add row 1 to row 3, then add row 1 to row 2.

If B is the inverse of  $ A^{2} $, show that AB is the inverse of A.

Find the numbers $a$ and $b$ that give the inverse of $5 \times$ eye (4) – ones (4, 4):

 $$ \begin{bmatrix}{{{4}}}&{{{-1}}}&{{{-1}}}&{{{-1}}} \\{{{-1}}}&{{{4}}}&{{{-1}}}&{{{-1}}} \\{{{-1}}}&{{{-1}}}&{{{4}}}&{{{-1}}} \\{{{-1}}}&{{{-1}}}&{{{-1}}}&{{{4}}}\end{bmatrix}^{-1}=\begin{bmatrix}{{{a}}}&{{{b}}}&{{{b}}}&{{{b}}} \\{{{b}}}&{{{a}}}&{{{b}}}&{{{b}}} \\{{{b}}}&{{{b}}}&{{{a}}}&{{{b}}} \\{{{b}}}&{{{b}}}&{{{b}}}&{{{a}}}\end{bmatrix}. $$ 

What are a and b in the inverse of 6 * eye (5) – ones (5, 5)?

Show that  $ A = 4 \times \text{eye}(4) - \text{ones}(4, 4) $ is not invertible: Multiply  $ A \times \text{ones}(4, 1) $.

There are sixteen 2 by 2 matrices whose entries are 1's and 0's. How many of them are invertible?