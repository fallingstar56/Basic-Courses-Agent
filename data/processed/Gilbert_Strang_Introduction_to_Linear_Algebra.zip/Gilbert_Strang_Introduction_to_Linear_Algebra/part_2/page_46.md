Solution The equation  $ Ax = 0 $ has only the zero solution  $ x = 0 $. The nullspace is Z. It contains only the single point  $ x = 0 $ in  $ R^2 $. This fact comes from elimination:

 $$ \boldsymbol{A}\boldsymbol{x}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{3}}}&{{{8}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}}\end{bmatrix}\text{yields}\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{2}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}}\end{bmatrix}\text{and}\begin{bmatrix}{{{\boldsymbol{x}_{1}=\mathbf{0}}}} \\{{{\boldsymbol{x}_{2}=\mathbf{0}}}}\end{bmatrix}. $$ 

A is invertible. There are no special solutions. Both columns of this matrix have pivots.

The rectangular matrix $B$ has the same nullspace $\mathbf{Z}$. The first two equations in $Bx = 0$ again require $\boldsymbol{x} = 0$. The last two equations would also force $\boldsymbol{x} = 0$. When we add extra equations (giving extra rows), the nullspace certainly cannot become larger. The extra rows impose more conditions on the vectors $\boldsymbol{x}$ in the nullspace.

The rectangular matrix C is different. It has extra columns instead of extra rows. The solution vector x has four components. Elimination will produce pivots in the first two columns of C, but the last two columns of C and U are “free”. They don’t have pivots:

Subtract 3 (row 1) from row 2 of C

 $$ C=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{2}}}&{{{4}}} \\{{{3}}}&{{{8}}}&{{{6}}}&{{{16}}}\end{bmatrix}\text{becomes}U=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{2}}}&{{{4}}} \\{{{0}}}&{{{2}}}&{{{0}}}&{{{4}}} \\{{{\uparrow}}}&{{{\uparrow}}}&{{{\uparrow}}}&{{{\uparrow}}}\end{bmatrix} $$ 

pivot columns free columns

For the free variables  $ x_3 $ and  $ x_4 $, we make special choices of ones and zeros. First  $ x_3 = 1 $,  $ x_4 = 0 $ and second  $ x_3 = 0 $,  $ x_4 = 1 $. The pivot variables  $ x_1 $ and  $ x_2 $ are determined by the equation  $ U \boldsymbol{x} = \boldsymbol{0} $ (or  $ C \boldsymbol{x} = \boldsymbol{0} $ or eventually  $ R \boldsymbol{x} = \boldsymbol{0} $). We get two special solutions in the nullspace of  $ C $. This is also the nullspace of  $ U $: elimination doesn't change solutions.

 $$ \begin{array}{l} \text{Special} \\ \text{solutions} \\ C s=0 \\ U s=0 \end{array} \quad \begin{array}{l} s_{1}=\left[\begin{array}{r} -2 \\ 0 \\ 1 \\ 0 \end{array}\right] \quad \text{and} \quad s_{2}=\left[\begin{array}{r} 0 \\ -2 \\ 0 \\ 1 \end{array}\right] \quad \begin{array}{l} \leftarrow \text{pivot} \\ \leftarrow \text{variables} \\ \leftarrow \text{free} \\ \leftarrow \text{variables} \end{array} $$ 

## The Reduced Row Echelon Form R

When A is rectangular, elimination will not stop at the upper triangular U. We can continue to make this matrix simpler, in two ways. These steps bring us to the best matrix R:

1. Produce zeros above the pivots. Use pivot rows to eliminate upward in R.

2. Produce ones in the pivots.

Divide the whole pivot row by its pivot.



Those steps don’t change the zero vector on the right side of the equation. The nullspace stays the same:  $ \mathbf{N}(A) = \mathbf{N}(U) = \mathbf{N}(R) $. This nullspace becomes easiest to see when we reach the reduced row echelon form  $ R = \operatorname{rref}(A) $. The pivot columns of  $ R $ contain  $ I $.