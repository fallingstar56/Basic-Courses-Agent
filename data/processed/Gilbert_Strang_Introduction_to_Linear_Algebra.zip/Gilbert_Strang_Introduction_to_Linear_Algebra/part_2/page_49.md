of the first. We won't see a pivot in that third column. The fourth column  $ (4, 5, 6) $ is the sum of the first three. That fourth column will also have no pivot. The rank of A and R is 2.

Every “free column” is a combination of earlier pivot columns. It is the special solutions s that tell us those combinations:

 $$ \begin{array}{ll}Column3=2\left(column1\right)+0\left(column2\right)&s_{1}=\left(-2,-0,1,0\right)\\ Column4=3\left(column1\right)+1\left(column2\right)&s_{2}=\left(-3,-1,0,1\right)\end{array} $$ 

The numbers 2, 0 in column 3 of R show up in  $ s_{1} $ (with signs reversed). And the numbers 3, 1 in column 4 of R show up in  $ s_{2} $ (with signs reversed to -3, -1).

Rank One

Matrices of rank one have only one pivot. When elimination produces zero in the first column, it produces zero in all the columns. Every row is a multiple of the pivot row. At the same time, every column is a multiple of the pivot column!

Rank one matrix

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{10}}} \\{{{2}}}&{{{6}}}&{{{20}}} \\{{{3}}}&{{{9}}}&{{{30}}}\end{bmatrix}\quad\longrightarrow\quad\boldsymbol{R}=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{10}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

The column space of a rank one matrix is “one-dimensional”. Here all columns are on the line through  $ \boldsymbol{u} = (1, 2, 3) $. The columns of  $ A $ are  $ \boldsymbol{u} $ and  $ 3\boldsymbol{u} $ and  $ 10\boldsymbol{u} $. Put those numbers into the row  $ \boldsymbol{v}^{\mathrm{T}} = [1 \quad 3 \quad 10] $ and you have the special rank one form  $ A = \boldsymbol{u}\boldsymbol{v}^{\mathrm{T}} $:

 $$ \boldsymbol{A}=\operatorname{column}\operatorname{times}\operatorname{row}=\boldsymbol{u}\boldsymbol{v}^{\mathrm{T}}\quad\begin{aligned}\left[\begin{array}{lll}{{{1}}}&{{{3}}}&{{{10}}} \\{{{2}}}&{{{6}}}&{{{20}}} \\{{{3}}}&{{{9}}}&{{{30}}}\end{array}\right]&=\left[\begin{array}{lll}{{{1}}} \\{{{2}}} \\{{{3}}}\end{array}\right]\left[\begin{array}{lll}{{{1}}}&{{{3}}}&{{{10}}}\end{array}\right]\end{aligned} $$ 

With rank one,  $ Ax = 0 $ is easy to understand. That equation  $ \boldsymbol{u}(\boldsymbol{v}^{\mathrm{T}}\boldsymbol{x}) = 0 $ leads us to  $ \boldsymbol{v}^{\mathrm{T}}\boldsymbol{x} = 0 $. All vectors  $ \boldsymbol{x} $ in the nullspace must be orthogonal to  $ \boldsymbol{v} $ in the row space. This is the geometry when  $ r = 1 $: row space = line, nullspace = perpendicular plane.

Example 4 When all rows are multiples of one pivot row, the rank is r = 1:

 $$ \begin{bmatrix}{{{1}}}&{{{3}}}&{{{4}}} \\{{{2}}}&{{{6}}}&{{{8}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{0}}}&{{{3}}} \\{{{0}}}&{{{5}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{5}}} \\{{{2}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{6}}}\end{bmatrix}\quad all\quad have\quad rank\quad1. $$ 

For those matrices, the reduced row echelon  $ R = \mathbf{rref}(A) $ can be checked by eye:

 $$ R=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\mathrm{~and~}\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\mathrm{~and~}\begin{bmatrix}{{{1}}} \\{{{0}}}\end{bmatrix}\mathrm{~and~}\begin{bmatrix}{{{1}}}\end{bmatrix}\mathrm{~have~only~one~pivot}. $$ 

Our second definition of rank will be at a higher level. It deals with entire rows and entire columns—vectors and not just numbers. All three matrices A and U and R have r independent rows.