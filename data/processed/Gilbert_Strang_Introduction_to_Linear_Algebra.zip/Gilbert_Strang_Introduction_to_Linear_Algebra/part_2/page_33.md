The components of v are real numbers, which is the reason for the letter R. A vector whose n components are complex numbers lies in the space  $ C^n $.

The vector space  $ \mathbf{R}^2 $ is represented by the usual  $ xy $ plane. Each vector  $ \boldsymbol{v} $ in  $ \mathbf{R}^2 $ has two components. The word “space” asks us to think of all those vectors—the whole plane. Each vector gives the  $ x $ and  $ y $ coordinates of a point in the plane:  $ \boldsymbol{v} = (x, y) $.

Similarly the vectors in  $ \mathbf{R}^3 $ correspond to points  $ (x, y, z) $ in three-dimensional space. The one-dimensional space  $ \mathbf{R}^1 $ is a line (like the  $ x $ axis). As before, we print vectors as a column between brackets, or along a line using commas and parentheses:

 $$ \begin{bmatrix}4\\ \pi\end{bmatrix}\mathrm{~is~in~}\mathbf{R}^{2},\quad(1,1,0,1,1)\mathrm{~is~in~}\mathbf{R}^{5},\quad\begin{bmatrix}1+i\\ 1-i\end{bmatrix}\mathrm{~is~in~}\mathbf{C}^{2}. $$ 

The great thing about linear algebra is that it deals easily with five-dimensional space. We don’t draw the vectors, we just need the five numbers (or n numbers).

To multiply v by 7, multiply every component by 7. Here 7 is a “scalar”. To add vectors in  $ R^{5} $, add them a component at a time. The two essential vector operations go on inside the vector space, and they produce linear combinations:

We can add any vectors in  $ R^{n} $, and we can multiply any vector v by any scalar c.

“Inside the vector space” means that the result stays in the space. If $v$ is the vector in $\mathbf{R}^4$ with components 1, 0, 0, 1, then $2v$ is the vector in $\mathbf{R}^4$ with components 2, 0, 0, 2. (In this case 2 is the scalar.) A whole series of properties can be verified in $\mathbf{R}^n$. The commutative law is $v + w = w + v$; the distributive law is $c(v + w) = cv + cw$. There is a unique “zero vector” satisfying $\mathbf{0} + v = v$. Those are three of the eight conditions listed at the start of the problem set.

These eight conditions are required of every vector space. There are vectors other than column vectors, and there are vector spaces other than  $ \mathbf{R}^n $, and all vector spaces have to obey the eight reasonable rules.

A real vector space is a set of “vectors” together with rules for vector addition and for multiplication by real numbers. The addition and the multiplication must produce vectors that are in the space. And the eight conditions must be satisfied (which is usually no problem). Here are three vector spaces other than  $ \mathbf{R}^n $:

M The vector space of all real 2 by 2 matrices.

F The vector space of all real functions f(x).

Z The vector space that consists only of a zero vector.

In M the “vectors” are really matrices. In F the vectors are functions. In Z the only addition is  $ \mathbf{0} + \mathbf{0} = \mathbf{0} $. In each case we can add: matrices to matrices, functions to functions, zero vector to zero vector. We can multiply a matrix by 4 or a function by 4 or the zero vector by 4. The result is still in M or F or Z. The eight conditions are all easily checked.

The function space F is infinite-dimensional. A smaller function space is P, or  $ P_n $, containing all polynomials  $ a_0 + a_1 x + \cdots + a_n x^n $ of degree n.