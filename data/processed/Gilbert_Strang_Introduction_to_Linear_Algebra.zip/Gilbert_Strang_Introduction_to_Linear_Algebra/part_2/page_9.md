My own lectures sometimes stop at this point. I go forward to 2.7. The next paragraphs show how elimination codes are organized, and how long they take. If MATLAB (or any software) is available, you can measure the computing time by just counting the seconds.

## One Square System = Two Triangular Systems

The matrix L contains our memory of Gaussian elimination. It holds the numbers that multiplied the pivot rows, before subtracting them from lower rows. When do we need this record and how do we use it in solving Ax = b?

We need $L$ as soon as there is a right side $b$. The factors $L$ and $U$ were completely decided by the left side (the matrix $A$). On the right side of $A\boldsymbol{x} = \boldsymbol{b}$, we use $L^{-1}$ and then $U^{-1}$. That Solve step deals with two triangular matrices.

1 Factor (into L and U, by elimination on the left side matrix A).

2 Solve (forward elimination on b using L, then back substitution for x using U).

Earlier, we worked on A and b at the same time. No problem with that—just augment to  $ [A\ b] $. But most computer codes keep the two sides separate. The memory of elimination is held in L and U, to process b whenever we want to. The User's Guide to LAPACK remarks that "This situation is so common and the savings are so important that no provision has been made for solving a single system with just one subroutine."

How does Solve work on b? First, apply forward elimination to the right side (the multipliers are stored in L, use them now). This changes b to a new right side c. We are really solving Lc = b. Then back substitution solves  $ Ux = c $ as always. The original system  $ Ax = b $ is factored into two triangular systems:

Forward and backward Solve  $ Lc = b $ and then solve  $ Ux = c $.

To see that x is correct, multiply Ux = c by L. Then LUx = Lc is just Ax = b.

To emphasize: There is nothing new about those steps. This is exactly what we have done all along. We were really solving the triangular system  $ Lc = b $ as elimination went forward. Then back substitution produced x. An example shows what we actually did.

Example 3 Forward elimination (downward) on Ax = b ends at Ux = c:

 $$ Ax=b \qquad \begin{array}{l} u+2v=5 \\ 4u+9v=21 \end{array} \quad \begin{array}{l} becomes \\ \hline \end{array} \quad \begin{array}{r} u+2v=5 \\ v=1 \end{array} \quad Ux=c $$ 

The multiplier was 4, which is saved in L. The right side used that 4 to change 21 to 1: