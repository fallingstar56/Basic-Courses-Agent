Questions 22–28 are about the Gauss-Jordan method for calculating  $ A^{-1} $

22 Change I into  $ A^{-1} $ as you reduce A to I (by row operations):

 $$ \left[\begin{array}{l l}{{{A}}}&{{{I}}}\end{array}\right]=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{1}}}&{{{0}}} \\{{{2}}}&{{{7}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\left[\begin{array}{l l}{{{A}}}&{{{I}}}\end{array}\right]=\begin{bmatrix}{{{1}}}&{{{4}}}&{{{1}}}&{{{0}}} \\{{{3}}}&{{{9}}}&{{{0}}}&{{{1}}}\end{bmatrix} $$ 

Follow the 3 by 3 text example but with plus signs in A. Eliminate above and below the pivots to reduce  $ [A\ I] $ to  $ [I\ A^{-1}] $:

24 Use Gauss-Jordan elimination on [U I] to find the upper triangular U−1:

 $$ \left[\begin{array}{l l l l l l}{A}&{I}\end{array}\right]=\left[\begin{matrix}{2}&{1}&{0}&{1}&{0}&{0}\\ {1}&{2}&{1}&{0}&{1}&{0}\\ {0}&{1}&{2}&{0}&{0}&{1}\end{matrix}\right]. $$ 

 $$ \boldsymbol{U}\boldsymbol{U}^{-1}=\boldsymbol{I}\qquad\begin{bmatrix}{{{1}}}&{{{a}}}&{{{b}}} \\{{{0}}}&{{{1}}}&{{{c}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{\boldsymbol{x}_{1}}}}&{{{\boldsymbol{x}_{2}}}}&{{{\boldsymbol{x}_{3}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

25 Find  $ A^{-1} $ and  $ B^{-1} $ (if they exist) by elimination on  $ [A\ I] $ and  $ [B\ I] $:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{2}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{-1}}}&{{{2}}}\end{bmatrix}. $$ 

What three matrices  $ E_{21} $ and  $ E_{12} $ and  $ D^{-1} $ reduce  $ A = \begin{bmatrix} 1 & 2 \\ 2 & 6 \end{bmatrix} $ to the identity matrix? Multiply  $ D^{-1}E_{12}E_{21} $ to find  $ A^{-1} $.

Invert these matrices A by the Gauss-Jordan method starting with [A I]:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{2}}}&{{{1}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{3}}}\end{bmatrix}. $$ 

28 Exchange rows and continue with Gauss-Jordan to find  $ A^{-1} $

 $$ \left[\begin{matrix}{A}&{I}\\ \end{matrix}\right]=\left[\begin{matrix}{0}&{2}&{1}&{0}\\ {2}&{2}&{0}&{1}\\ \end{matrix}\right]. $$ 

29 True or false (with a counterexample if false and a reason if true):

(a) A 4 by 4 matrix with a row of zeros is not invertible.

(b) Every matrix with 1's down the main diagonal is invertible.

(c) If A is invertible then  $ A^{-1} $ and  $ A^{2} $ are invertible.