### Problem Set 2.5

1 Find the inverses (directly or from the 2 by 2 formula) of A, B, C:

 $$ A=\begin{bmatrix}{{{0}}}&{{{3}}} \\{{{4}}}&{{{0}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{2}}}&{{{0}}} \\{{{4}}}&{{{2}}}\end{bmatrix}\quad and\quad C=\begin{bmatrix}{{{3}}}&{{{4}}} \\{{{5}}}&{{{7}}}\end{bmatrix}. $$ 

2 For these “permutation matrices” find P−1 by trial and error (with 1’s and 0’s):

 $$ \boldsymbol{P}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{P}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

3 Solve for the first column  $ (x, y) $ and second column  $ (t, z) $ of  $ A^{-1} $:

 $$ \begin{bmatrix} {10}&{20} \\ {20}&{50} \end{bmatrix}\begin{bmatrix} {x} \\ {y} \end{bmatrix}=\begin{bmatrix} {1} \\ {0} \end{bmatrix} \quad and \quad \begin{bmatrix} {10}&{20} \\ {20}&{50} \end{bmatrix}\begin{bmatrix} {t} \\ {z} \end{bmatrix}=\begin{bmatrix} {0} \\ {1} \end{bmatrix}. $$ 

4 Show that  $ \left\lceil\frac{1}{3}\frac{2}{6}\right\rceil $ is not invertible by trying to solve  $ AA^{-1}=I $ for column 1 of  $ A^{-1} $.

 $$ \begin{bmatrix}1&2\\ 3&6\end{bmatrix}\begin{bmatrix}x\\ y\end{bmatrix}=\begin{bmatrix}1\\ 0\end{bmatrix}\qquad\begin{pmatrix}For a different A,could column 1 of A^{-1}\\ be possible to find but not column 2?\end{pmatrix} $$ 

5 Find an upper triangular $U$ (not diagonal) with $U^{2}=I$ which gives $U=U^{-1}$.

6 (a) If A is invertible and AB = AC, prove quickly that B = C.

(b) If  $ A = \left[\begin{array}{cc} 1 & 1 \\ 1 & 1 \end{array}\right] $, find two different matrices such that  $ AB = AC $.

7 (Important) If A has row 1 + row 2 = row 3, show that A is not invertible:

(a) Explain why Ax = (0, 0, 1) cannot have a solution. Add eqn 1 + eqn 2.

(b) Which right sides  $ (b_{1}, b_{2}, b_{3}) $ might allow a solution to Ax = b?

(c) In elimination, what happens to equation 3?

8 If A has column 1 + column 2 = column 3, show that A is not invertible:

(a) Find a nonzero solution x to Ax = 0. The matrix is 3 by 3.

(b) Elimination keeps column 1 + column 2 = column 3. Explain why there is no third pivot.

9 Suppose A is invertible and you exchange its first two rows to reach B. Is the new matrix B invertible? How would you find  $ B^{-1} $ from  $ A^{-1} $?