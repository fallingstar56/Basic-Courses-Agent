Suppose  $ E_1 $,  $ E_2 $,  $ E_3 $ are 4 by 4 identity matrices, except  $ E_1 $ has a, b, c in column 1 and  $ E_2 $ has d, e in column 2 and  $ E_3 $ has f in column 3 (below the 1's). Multiply  $ L = E_1 E_2 E_3 $ to show that all these nonzeros are copied into L.

 $ E_1E_2E_3 $ is in the opposite order from elimination (because  $ E_3 $ is acting first). But  $ E_1E_2E_3 = L $ is in the correct order to invert elimination and recover  $ A $.

Second difference matrices have beautiful inverses if they start with  $ T_{11} = 1 $ (instead of  $ K_{11} = 2 $). Here is the 3 by 3 tridiagonal matrix T and its inverse:

 $$ \boldsymbol{T}=\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}\qquad\boldsymbol{T}^{-1}=\begin{bmatrix}{{{3}}}&{{{2}}}&{{{1}}} \\{{{2}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix} $$ 

One approach is Gauss-Jordan elimination on  $ [T\ I] $. I would rather write T as the product of first differences L times U. The inverses of L and U in Worked Example 2.5 A are sum matrices, so here are  $ T = LU $ and  $ T^{-1} = U^{-1}L^{-1} $:

 $$ \boldsymbol{T}=\begin{bmatrix}{{{1}}} \\{{{-1}}}&{{{1}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{0}}} \\{{{1}}}&{{{-1}}} \\{{{1}}}\end{bmatrix}\qquad\boldsymbol{T}^{-1}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}} \\{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{bmatrix} $$ 

Question. (4 by 4) What are the pivots of  $ T $? What is its 4 by 4 inverse? The reverse order UL gives what matrix  $ T^{*} $? What is the inverse of  $ T^{*} $?

42 Here are two more difference matrices, both important. But are they invertible?

 $$ \mathbf{C y c l i c}\;C=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}\quad\mathbf{F r e e}\;\mathbf{e n d s}\;F=\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{1}}}\end{bmatrix}. $$ 

Elimination for a block matrix: When you multiply the first block row [A B] by  $ CA^{-1} $ and subtract from the second row [C D], the “Schur complement” S appears:

 $$ \begin{bmatrix}{{{I}}}&{{{0}}} \\{{{-CA^{-1}}}}&{{{I}}}\end{bmatrix}\begin{bmatrix}{{{A}}}&{{{B}}} \\{{{C}}}&{{{D}}}\end{bmatrix}=\begin{bmatrix}{{{A}}}&{{{B}}} \\{{{0}}}&{{{S}}}\end{bmatrix}\qquad\begin{array}{l}{{{A\text{and}D\text{are square}}}} \\{{{S=D-CA^{-1}B.}}}\end{array} $$ 

Multiply on the right to subtract  $ A^{-1}B $ times block column 1 from block column 2.

 $$ \begin{bmatrix}{{{A}}}&{{{B}}} \\{{{0}}}&{{{S}}}\end{bmatrix}\begin{bmatrix}{{{I}}}&{{{-A^{-1}B}}} \\{{{0}}}&{{{I}}}\end{bmatrix}=?\quad Find S for\quad\begin{bmatrix}{{{A}}}&{{{B}}} \\{{{C}}}&{{{I}}}\end{bmatrix}=\begin{bmatrix}{{{2}}}&{{{3}}}&{{{3}}} \\{{{4}}}&{{{1}}}&{{{0}}} \\{{{4}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

The block pivots are A and S. If they are invertible, so is [A B; C D].

How does the identity  $ A(I + BA) = (I + AB)A $ connect the inverses of  $ I + BA $ and  $ I + AB $? Those are both invertible or both singular: not obvious.