11 This fact still amazes me. If you do a row operation on A and then a column operation, the result is the same as if you did the column operation first. (Try it.) Why is this true?

12 (3 by 3 matrices) Choose the only B so that for every matrix A

(a)  $ BA = 4A $

(b)  $ BA = 4B $

(c) BA has rows 1 and 3 of A reversed and row 2 unchanged

(d) All rows of BA are the same as row 1 of A.

13 Suppose AB = BA and AC = CA for these two particular matrices B and C :

 $$ A=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}\quad commutes with\quad B=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad C=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Prove that $a = d$ and $b = c = 0$. Then $A$ is a multiple of $I$. The only matrices that commute with $B$ and $C$ and all other 2 by 2 matrices are $A = \text{multiple of } I$.

Which of the following matrices are guaranteed to equal  $ (A - B)^{2} $:  $ A^{2} - B^{2} $,  $ (B - A)^{2} $,  $ A^{2} - 2AB + B^{2} $,  $ A(A - B) - B(A - B) $,  $ A^{2} - AB - BA + B^{2} $?

15 True or false:

(a) If  $ A^{2} $ is defined then A is necessarily square.

(b) If AB and BA are defined then A and B are square.

(c) If AB and BA are defined then AB and BA are square.

(d) If AB = B then A = I.

16 If A is m by n, how many separate multiplications are involved when

(a) A multiplies a vector x with n components?

(b) A multiplies an n by p matrix B?

(c) A multiplies itself to produce  $ A^{2} $? Here m = n.

17 For  $ A = \begin{bmatrix} 2 & -1 \\ 3 & -2 \end{bmatrix} $ and  $ B = \begin{bmatrix} 1 & 0 & 4 \\ 1 & 0 & 6 \end{bmatrix} $, compute these answers and nothing more:

(a) column 2 of AB

(b) row 2 of AB

(c) row 2 of AA =  $ A^{2} $

(d) row 2 of AAA =  $ A^{3} $.