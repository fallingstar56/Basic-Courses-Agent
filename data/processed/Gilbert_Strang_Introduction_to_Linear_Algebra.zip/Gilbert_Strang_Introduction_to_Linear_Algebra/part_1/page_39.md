Problems 18–20 use  $ a_{ij} $ for the entry in row i, column j of A.

18 Write down the 3 by 3 matrix A whose entries are

(a)  $ a_{ij} = \text{minimum of } i \text{ and } j $

(b)  $ a_{ij} = (-1)^{i+j} $

(c)  $ a_{ij} = i/j. $

19 What words would you use to describe each of these classes of matrices? Give a 3 by 3 example in each class. Which matrix belongs to all four classes?

(a)  $ a_{ij} = 0 $ if  $ i \neq j $

(b)  $ a_{ij} = 0 $ if i < j

(c)  $ a_{ij} = a_{ji} $

(d)  $ a_{ij} = a_{1j}. $

20 The entries of A are  $ a_{ij} $. Assuming that zeros don't appear, what is

(a) the first pivot?

(b) the multiplier  $ \ell_{31} $ of row 1 to be subtracted from row 3?

(c) the new entry that replaces  $ a_{32} $ after that subtraction?

(d) the second pivot?

Problems 21–24 involve powers of A.

21 Compute  $ A^{2}, A^{3}, A^{4} $ and also Av,  $ A^{2}v, A^{3}v, A^{4}v $ for

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{2}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{v}=\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}} \\{{{t}}}\end{bmatrix}. $$ 

22 By trial and error find real nonzero 2 by 2 matrices such that

 $$ A^{2}=-I\qquad BC=0\qquad DE=-ED(not allowing DE=0). $$ 

(a) Find a nonzero matrix A for which  $ A^{2} = 0 $.

(b) Find a matrix that has  $ A^2 \neq 0 $ but  $ A^3 = 0 $.

24 By experiment with n = 2 and n = 3 predict  $ A^{n} $ for these matrices:

 $$ A_{1}=\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad A_{2}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\quad and\quad A_{3}=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 