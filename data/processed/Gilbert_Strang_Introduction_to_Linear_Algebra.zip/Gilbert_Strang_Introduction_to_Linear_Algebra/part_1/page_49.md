Reasoning. Take any nonzero vector x. Suppose its largest component is  $ |x_i| $. Then Ax = 0 is impossible, because row i of Ax = 0 would need

 $$ a_{i1}x_{1}+\cdots+a_{ii}x_{i}+\cdots+a_{in}x_{n}=0. $$ 

Those can’t add to zero when A is diagonally dominant! The size of  $ a_{ii}x_i $ (that one particular term) is greater than all the other terms combined:

 $ \text{All } |x_j| \leq |x_i| \quad \sum_{j \neq i} |a_{ij} x_j| \leq \sum_{j \neq i} |a_{ij}| |x_i| < |a_{ii}| |x_i| \quad \text{because } a_{ii} \text{ dominates} $

This shows that  $ Ax = 0 $ is only possible when  $ x = 0 $. So  $ A $ is invertible. The example  $ B $ was also invertible but not quite diagonally dominant: 2 is not larger than  $ 1 + 1 $.

## ■ REVIEW OF THE KEY IDEAS

1. The inverse matrix gives  $ AA^{-1} = I $ and  $ A^{-1}A = I $.

2. A is invertible if and only if it has n pivots (row exchanges allowed).

3. Important. If Ax = 0 for a nonzero vector x, then A has no inverse.

4. The inverse of AB is the reverse product  $ B^{-1}A^{-1} $. And  $ (ABC)^{-1}=C^{-1}B^{-1}A^{-1} $.

5. The Gauss-Jordan method solves  $ AA^{-1} = I $ to find the n columns of  $ A^{-1} $. The augmented matrix  $ [A \quad I] $ is row-reduced to  $ [I \quad A^{-1}] $.

6. Diagonally dominant matrices are invertible. Each  $ |a_{ii}| $ dominates its row.

## WORKED EXAMPLES

2.5 A The inverse of a triangular difference matrix A is a triangular sum matrix S:

 $$ \begin{aligned}\left[\boldsymbol{A}\quad\boldsymbol{I}\right]&=\left[\begin{array}{ccc|ccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}} \\\end{array}\right]\rightarrow\left[\begin{array}{ccc|ccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}} \\\end{array}\right]\\&\rightarrow\left[\begin{array}{ccc|ccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\\end{array}\right]=\left[\boldsymbol{I}\quad\boldsymbol{A}^{-1}\right]=\left[\boldsymbol{I}\quad sum matrix\right].\end{aligned} $$ 

If I change  $ a_{13} $ to -1, then all rows of A add to zero. The equation  $ Ax = 0 $ will now have the nonzero solution  $ x = (1, 1, 1) $. A clear signal: This new A can't be inverted.