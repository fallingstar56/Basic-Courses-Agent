If I multiply 2 by 2 matrices this column-row way, you will see that AB is correct.

 $$ \boldsymbol{A}\boldsymbol{B}=\left[\begin{array}{ll}\boldsymbol{a}&\boldsymbol{b}\\ \boldsymbol{c}&\boldsymbol{d}\end{array}\right]\left[\begin{array}{ll}\boldsymbol{E}&\boldsymbol{F}\\ \boldsymbol{G}&\boldsymbol{H}\end{array}\right]=\left[\begin{array}{ll}\boldsymbol{a}\boldsymbol{E}+\boldsymbol{b}\boldsymbol{G}&\boldsymbol{a}\boldsymbol{F}+\boldsymbol{b}\boldsymbol{H}\\ \boldsymbol{c}\boldsymbol{E}+\boldsymbol{d}\boldsymbol{G}&\boldsymbol{c}\boldsymbol{F}+\boldsymbol{d}\boldsymbol{H}\end{array}\right] $$ 

 $$ \begin{array}{l} Add columns of A\\times\text{times rows of}B\end{array}\begin{array}{l}AB=\begin{bmatrix}a\\ c\end{bmatrix}\begin{bmatrix}E&F\end{bmatrix}+\begin{bmatrix}b\\ d\end{bmatrix}\begin{bmatrix}G&H\end{bmatrix} $$ 

Column k of A multiplies row k of B. That gives a matrix (not just a number). Then you add those matrices for  $ k = 1, 2, \ldots, n $ to produce AB.

If AB is (m by n) (n by p) then n matrices will be (column) (row). They are all m by p. This uses the same mnp steps as in the dot products—but in a new order.

## The Laws for Matrix Operations

May I put on record six laws that matrices do obey, while emphasizing a rule they don’t obey? The matrices can be square or rectangular, and the laws involving  $ A + B $ are all simple and all obeyed. Here are three addition laws:

 $$ \begin{array}{ccc}A+B=B+A&(commutative law)\\c\left(A+B\right)=cA+cB&(distributive law)\\A+\left(B+C\right)=\left(A+B\right)+C&(associative law).\end{array} $$ 

Three more laws hold for multiplication, but  $ AB = BA $ is not one of them:

 $$ AB\neq BA\qquad(the commutative“law”is usually broken) $$ 

 $$ A\left(B+C\right)=AB+AC\quad(distributive law from the left) $$ 

 $$ \left(A+B\right)C=AC+BC\quad(distributive law from the right) $$ 

 $$ A\left(BC\right)=\left(AB\right)C\qquad(associative law for~ABC)\left(parentheses~not~needed\right). $$ 

When A and B are not square, AB is a different size from BA. These matrices can't be equal—even if both multiplications are allowed. For square matrices, almost any example shows that AB is different from BA:

 $$ \boldsymbol{A}\boldsymbol{B}=\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{0}}}&{{{\mathbf{1}}}}\end{bmatrix}\quad but\quad\boldsymbol{B}\boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{\mathbf{1}}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

It is true that AI = IA. All square matrices commute with I and also with cI. Only these matrices cI commute with all other matrices.

The law  $ A(B+C)=AB+AC $ is proved a column at a time. Start with  $ A(b+c)=Ab+Ac $ for the first column. That is the key to everything—linearity. Say no more.

The law  $ A(BC) = (AB)C $ means that you can multiply BC first or else AB first. The direct proof is sort of awkward (Problem 37) but this law is extremely useful. We highlighted it above; it is the key to the way we multiply matrices.