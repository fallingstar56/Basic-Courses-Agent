Suppose A is m by n and B is n by p. We can multiply. The product AB is m by p.

 $$ \begin{array}{r l}{(m\times n)(n\times p)=(m\times p)}&{{}\quad\left[\begin{matrix}{m\mathrm{~r o w s}}\\ {n\mathrm{~c o l u m n s}}\\ \end{matrix}\right]\left[\begin{matrix}{n\mathrm{~r o w s}}\\ {p\mathrm{~c o l u m n s}}\\ \end{matrix}\right]=\left[\begin{matrix}{m\mathrm{~r o w s}}\\ {p\mathrm{~c o l u m n s}}\\ \end{matrix}\right].}\end{array} $$ 

A row times a column is an extreme case. Then 1 by n multiplies n by 1. The result will be 1 by 1. That single number is the “dot product”.

In every case AB is filled with dot products. For the top corner, the  $ (1,1) $ entry of AB is  $ (row\ 1\ of\ A)\cdot(column\ 1\ of\ B) $. This is the first way, and the usual way, to multiply matrices. Take the dot product of each row of A with each column of B.

1. The entry in row i and column j of AB is  $ (row i of A) \cdot (column j of B) $

Figure 2.8 picks out the second row  $ (i = 2) $ of a 4 by 5 matrix A. It picks out the third column  $ (j = 3) $ of a 5 by 6 matrix B. Their dot product goes into row 2 and column 3 of AB. The matrix AB has as many rows as A (4 rows), and as many columns as B.

 $$ \begin{aligned}&\begin{bmatrix} \\{{{*}}} \\{{{a_{i1}}}}&{{{a_{i2}}}}&{{{\cdots}}}&{{{a_{i5}}}} \\{{{*}}} \\{{{*}}} \\{{{*}}} \\\end{bmatrix}\begin{bmatrix} \\{{{*}}}&{{{*}}}&{{{b_{1j}}}}&{{{*}}}&{{{*}}}&{{{*}}} \\{{{*}}}&{{{b_{2j}}}} \\{{{\vdots}}} \\{{{b_{5j}}}} \\\end{bmatrix}=\begin{bmatrix} \\{{{*}}} \\{{{*}}}&{{{(AB)_{ij}}}}&{{{*}}}&{{{*}}}&{{{*}}} \\{{{*}}} \\{{{*}}} \\{{{*}}} \\\end{bmatrix}\\ &A is 4 by 5\\ &B is 5 by 6\\ &AB is(4\times5)(5\times6)=4by6\\ \end{aligned} $$ 

<div style="text-align: center;">Figure 2.8: Here i=2 and j=3. Then  $ (AB)_{23} $ is  $ (row\ 2)\cdot(column\ 3) $ = sum of  $ a_{2k}b_{k3} $.</div>


Example 1 Square matrices can be multiplied if and only if they have the same size:

 $$ \begin{bmatrix}{{{1}}}&{{{1}}} \\{{{2}}}&{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{2}}} \\{{{3}}}&{{{4}}}\end{bmatrix}=\begin{bmatrix}{{{5}}}&{{{6}}} \\{{{1}}}&{{{0}}}\end{bmatrix}. $$ 

The first dot product is  $ 1 \cdot 2 + 1 \cdot 3 = 5 $. Three more dot products give 6, 1, and 0. Each dot product requires two multiplications—thus eight in all.

If $A$ and $B$ are $n$ by $n$, so is $AB$. It contains $n^2$ dot products, row of $A$ times column of $B$. Each dot product needs $n$ multiplications, so the computation of $AB$ uses $n^3$ separate multiplications. For $n = 100$ we multiply a million times. For $n = 2$ we have $n^3 = 8$.

Mathematicians thought until recently that  $ AB $ absolutely needed  $ 2^3 = 8 $ multiplications. Then somebody found a way to do it with 7 (and extra additions). By breaking  $ n $ by  $ n $ matrices into 2 by 2 blocks, this idea also reduced the count to multiply large matrices. Instead of  $ n^3 $ multiplications the count has now dropped to  $ n^{2.376} $. Maybe  $ n^2 $ is possible? But the algorithms are so awkward that scientific computing is done the regular  $ n^3 $ way.