Questions 26–28 review the row and column pictures in 2, 3, and 4 dimensions.

Draw the row and column pictures for the equations  $ x - 2y = 0 $,  $ x + y = 6 $.

For two linear equations in three unknowns x, y, z, the row picture will show (2 or 3) (lines or planes) in (2 or 3)-dimensional space. The column picture is in (2 or 3)-dimensional space. The solutions normally lie on a ___.

For four linear equations in two unknowns x and y, the row picture shows four ___. The column picture is in ___-dimensional space. The equations have no solution unless the vector on the right side is a combination of ___.

Start with the vector  $ u_{0} = (1, 0) $. Multiply again and again by the same “Markov matrix”  $ A = [.8 .3; .2 .7] $. The next three vectors are  $ u_{1}, u_{2}, u_{3} $:

 $$ u_{1}=\begin{bmatrix}.8&.3\\ .2&.7\end{bmatrix}\begin{bmatrix}1\\ 0\end{bmatrix}=\begin{bmatrix}.8\\ .2\end{bmatrix}\quad u_{2}=Au_{1}=\_\_\_u_{3}=Au_{2}=\_\_\_. $$ 

What property do you notice for all four vectors  $ u_{0}, u_{1}, u_{2}, u_{3} $?

## Challenge Problems

Continue Problem 29 from  $ u_0 = (1,0) $ to  $ u_7 $, and also from  $ v_0 = (0,1) $ to  $ v_7 $. What do you notice about  $ u_7 $ and  $ v_7 $? Here are two MATLAB codes, with while and for. They plot  $ u_0 $ to  $ u_7 $ and  $ v_0 $ to  $ v_7 $. You can use other languages:

 $$ \begin{array}{l} u=[1;0];A=[.8.3;.2.7];\quad v=[0;1];A=[.8.3;.2.7];\\ x=u;k=[0:7];\quad x=v;k=[0:7];\\ while size(x,2)\leq7\quad for j=1:7\\ \quad u=A*u;x=[x u];\quad v=A*v;x=[x v];\\ end\\ plot(k,x)\quad plot(k,x)\end{array} $$ 

The  $ u $'s and  $ v $'s are approaching a steady state vector  $ s $. Guess that vector and check that  $ As = s $. If you start with  $ s $, you stay with  $ s $.

Invent a 3 by 3 magic matrix  $ M_3 $ with entries 1, 2, ..., 9. All rows and columns and diagonals add to 15. The first row could be 8, 3, 4. What is  $ M_3 $ times (1, 1, 1)? What is  $ M_4 $ times (1, 1, 1, 1) if a 4 by 4 magic matrix has entries 1, ..., 16?

Suppose u and v are the first two columns of a 3 by 3 matrix A. Which third columns w would make this matrix singular? Describe a typical column picture of  $ Ax = b $ in that singular case, and a typical row picture (for a random b).