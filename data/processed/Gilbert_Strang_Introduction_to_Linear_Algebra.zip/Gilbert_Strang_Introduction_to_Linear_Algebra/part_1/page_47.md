 $$ \boldsymbol{A}^{-1}=\left[\begin{array}{ccc}{{{1}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right]^{-1}=\left[\begin{array}{ccc}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right]\quad\text{Columns}j=1\text{and}2\text{end}\quad\text{with}3-j=2\text{and}1\text{zeros}. $$ 

The code for  $ X = \text{inv}(A) $ can use  $ \text{rref} $, the reduced row echelon form from Chapter 3:

 $$ \begin{array}{l l}{I=\mathrm{e y e~(n)};}&{\mathrm{~\%~D e f i n e~t h e~}n\mathrm{~b y~}n\mathrm{~i d e n t i t y~m a t r i x}}\\ {R=\mathrm{r r e f~([A\quad I]);}}&{\mathrm{~\%~E l i m i n a t e~o n~t h e~a u g m e n t e d~m a t r i x~[A\quad I]}}\\ {X=R(:,n+1:n+n)}&{\mathrm{~\%~P i c k~}X=A^{-1}\mathrm{~f r o m~t h e~l a s t~}n\mathrm{~c o l u m n s~o f~}R}\\ \end{array} $$ 

A must be invertible, or elimination cannot reduce it to I (in the left half of R).

Gauss-Jordan shows why  $ A^{-1} $ is expensive. We solve  $ n $ equations for its  $ n $ columns. But all those equations involve the same matrix  $ A $ on the left side (where most of the work is done). The total cost for  $ A^{-1} $ is  $ n^3 $ multiplications and subtractions. To solve a single  $ A\boldsymbol{x} = \boldsymbol{b} $ that cost (see the next section) is  $ n^3/3 $.

To solve Ax = b without  $ A^{-1} $, we deal with one column b to find one column x.

Singular versus Invertible

We come back to the central question. Which matrices have inverses? The start of this section proposed the pivot test:  $ A^{-1} $ exists exactly when A has a full set of n pivots. (Row exchanges are allowed.) Now we can prove that by Gauss-Jordan elimination:

1. With $n$ pivots, elimination solves all the equations $Ax_i = e_i$. The columns $x_i$ go into $A^{-1}$. Then $AA^{-1} = I$ and $A^{-1}$ is at least a right-inverse.

2. Elimination is really a sequence of multiplications by  $ E^{\prime} $s and  $ P^{\prime} $s and  $ D^{-1} $:

Left-inverse C

 $$ CA=(D^{-1}\cdots E\cdots P\cdots E)A=I. $$ 

 $ D^{-1} $ divides by the pivots. The matrices E produce zeros below and above the pivots. P will exchange rows if needed (see Section 2.7). The product matrix in equation (9) is evidently a left-inverse of A. With n pivots we have reached  $ A^{-1}A = I $.

The right-inverse equals the left-inverse. That was Note 2 at the start of in this section. So a square matrix with a full set of pivots will always have a two-sided inverse.

Reasoning in reverse will now show that A must have n pivots if AC = I.

1. If A doesn't have n pivots, elimination will lead to a zero row.

2. Those elimination steps are taken by an invertible M. So a row of MA is zero.

3. If AC = I had been possible, then MAC = M. The zero row of MA, times C, gives a zero row of M itself.

4. An invertible matrix M can't have a zero row! A must have n pivots if AC = I.

That argument took four steps, but the outcome is short and important. C is A−1.