### Problem Set 2.1

Problems 1–8 are about the row and column pictures of Ax = b.

1 With $A = I$ (the identity matrix) draw the planes in the row picture. Three sides of a box meet at the solution $x = (x, y, z) = (2, 3, 4)$:

 $$ \begin{array}{l} 1x + 0y + 0z=2 \\ 0x + 1y + 0z=3 \\ 0x + 0y + 1z=4 \end{array}  \quad \mathrm{or} \quad \begin{bmatrix} 1 & 0 & 0 \\ 0 & 1 & 0 \\ 0 & 0 & 1 \end{bmatrix} \begin{bmatrix} x \\ y \\ z \end{bmatrix}=\begin{bmatrix} 2 \\ 3 \\ 4 \end{bmatrix}. $$ 

Draw the vectors in the column picture. Two times column 1 plus three times column 2 plus four times column 3 equals the right side b.

2 If the equations in Problem 1 are multiplied by 2, 3, 4 they become DX = B:

 $$ \begin{array}{l l l l l } 2x+0y+0z=4& &  \text{or} &  D X=\left[\begin{array}{lll}2&0&0\\0&3&0\\0&0&4\end{array}\right]\left[\begin{array}{l}x\\y\\z\end{array}\right]=\left[\begin{array}{l}4\\9\\16\end{array}\right]=B &\\0x+3y+0z=9& &  \end{array} $$ 

Why is the row picture the same? Is the solution X the same as x? What is changed in the column picture—the columns or the right combination to give B?

3 If equation 1 is added to equation 2, which of these are changed: the planes in the row picture, the vectors in the column picture, the coefficient matrix, the solution? The new equations in Problem 1 would be  $ x = 2 $,  $ x + y = 5 $,  $ z = 4 $.

4 Find a point with z = 2 on the intersection line of the planes  $ x + y + 3z = 6 $ and  $ x - y + z = 4 $. Find the point with z = 0. Find a third point halfway between.

5 The first of these equations plus the second equals the third:

 $$ x+y+z=2 $$ 

 $$ x+2y+\ z=3 $$ 

 $$ 2x+3y+2z=5. $$ 

The first two planes meet along a line. The third plane contains that line, because if x, y, z satisfy the first two equations then they also ___. The equations have infinitely many solutions (the whole line L). Find three solutions on L.

Move the third plane in Problem 5 to a parallel plane  $ 2x + 3y + 2z = 9 $. Now the three equations have no solution—why not? The first two planes meet along the line L, but the third plane doesn't ___ that line.

7 In Problem 5 the columns are  $ (1,1,2) $ and  $ (1,2,3) $ and  $ (1,1,2) $. This is a “singular case” because the third column is ___. Find two combinations of the columns that give  $ \boldsymbol{b}=(2,3,5) $. This is only possible for  $ \boldsymbol{b}=(4,6,c) $ if  $ c= $ ___.