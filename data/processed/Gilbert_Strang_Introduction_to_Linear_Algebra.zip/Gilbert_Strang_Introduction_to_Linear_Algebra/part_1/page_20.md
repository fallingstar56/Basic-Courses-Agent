What about the left side of Ax = b? Both sides will be multiplied by this  $ E_{31} $. The purpose of  $ E_{31} $ is to produce a zero in the  $ (3, 1) $ position of the matrix.

The notation fits this purpose. Start with A. Apply  $ E' $s to produce zeros below the pivots (the first  $ E $ is  $ E_{21} $). End with a triangular  $ U $. We now look in detail at those steps.

First a small point. The vector x stays the same. The solution x is not changed by elimination. (That may be more than a small point.) It is the coefficient matrix that is changed. When we start with Ax = b and multiply by E, the result is EAx = Eb. The new matrix EA is the result of multiplying E times A.

Confession The elimination matrices  $ E_{ij} $ are great examples, but you won’t see them later. They show how a matrix acts on rows. By taking several elimination steps, we will see how to multiply matrices (and the order of the E’s becomes important). Products and inverses are especially clear for E’s. It is those two ideas that the book will use.

Matrix Multiplication

The big question is: How do we multiply two matrices? When the first matrix is E, we know what to expect for EA. This particular E subtracts 2 times row 1 from row 2. The multiplier is  $ \ell = 2 $:

 $$ EA=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{4}}}&{{{-2}}} \\{{{4}}}&{{{9}}}&{{{-3}}} \\{{{-2}}}&{{{-3}}}&{{{7}}}\end{bmatrix}=\begin{bmatrix}{{{2}}}&{{{4}}}&{{{-2}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{-2}}}&{{{-3}}}&{{{7}}}\end{bmatrix}\quad(with the zero). $$ 

This step does not change rows 1 and 3 of A. Those rows are unchanged in EA—only row 2 is different. Twice the first row has been subtracted from the second row. Matrix multiplication agrees with elimination—and the new system of equations is  $ EAx = Eb $.

EAx is simple but it involves a subtle idea. Start with Ax = b. Multiplying both sides by E gives  $ E(Ax) = Eb $. With matrix multiplication, this is also  $ (EA)x = Eb $.

The first was E times Ax, the second is EA times x. They are the same.

Parentheses are not needed. We just write EAx.

That rule extends to a matrix $C$ with several column vectors. When multiplying $EAC$, you can do $AC$ first or $EA$ first. This is the point of an “associative law” like $3 \times (4 \times 5) = (3 \times 4) \times 5$. Multiply 3 times 20, or multiply 12 times 5. Both answers are 60. That law seems so clear that it is hard to imagine it could be false.

The “commutative law”  $ 3 \times 4 = 4 \times 3 $ looks even more obvious. But EA is usually different from AE. When E multiplies on the right, it acts on the columns of A—not the rows. AE actually subtracts 2 times column 2 from column 1. So  $ EA \neq AE $.

 $$ A(BC)=(AB)C $$ 

 $$ Often\ AB\ne BA $$ 