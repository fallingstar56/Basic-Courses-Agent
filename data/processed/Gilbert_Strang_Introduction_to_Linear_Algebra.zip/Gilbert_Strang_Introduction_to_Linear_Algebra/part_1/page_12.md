For the second system, subtract equation 1 from equation 2 as before. Add equation 1 to equation 3. This leaves zero in the 2, 2 entry and also below:

Failure

 $$ \begin{array}{r l}{x+y+z=}&{{}7\qquad\mathrm{T h e r e~i s~n o~p i v o t~i n~c o l u m n~2~(i t~w a s-c o l u m n~1)}}\\ {\mathbf{0}y-2z=-2}&{{}\mathrm{~A~f u r t h e~e l i m i n a t i o n~s t e p~g i v e s~}\mathbf{0}z=8}\\ {\mathbf{0}y+2z=}&{{}10\qquad\mathrm{T h e~t h r e~p l a n e s~d o n^{\prime}t~m e e t}}\end{array} $$ 

Plane 1 meets plane 2 in a line. Plane 1 meets plane 3 in a parallel line. No solution.

If we change the “3” in the original third equation to “−5” then elimination would lead to 0 = 0. There are infinitely many solutions! The three planes now meet along a whole line.

Changing 3 to -5 moved the third plane to meet the other two. The second equation gives z = 1. Then the first equation leaves  $ x + y = 6 $. No pivot in column 2 makes y free (free variables can have any value). Then x = 6 - y.

### Problem Set 2.2

Problems 1–10 are about elimination on 2 by 2 systems.

1 What multiple  $ \ell_{21} $ of equation 1 should be subtracted from equation 2?

 $$ 2x+3y=1 $$ 

 $$ 10x+9y=11. $$ 

After elimination, write down the upper triangular system and circle the two pivots. The numbers 1 and 11 don’t affect the pivots—use them now in back substitution.

2 Solve the triangular system of Problem 1 by back substitution, y before x. Verify that x times  $ (2, 10) $ plus y times  $ (3, 9) $ equals  $ (1, 11) $. If the right side changes to  $ (4, 44) $, what is the new solution?

3 What multiple of equation 1 should be subtracted from equation 2?

 $$ \begin{aligned}&2x-4y=6\\&-x+5y=0.\end{aligned} $$ 

After this elimination step, solve the triangular system. If the right side changes to  $ (-6, 0) $, what is the new solution?

4 What multiple  $ \ell $ of equation 1 should be subtracted from equation 2 to remove c?

 $$ \begin{aligned}&ax+by=f\\&cx+dy=g.\\ \end{aligned} $$ 

The first pivot is a (assumed nonzero). Elimination produces what formula for the second pivot? What is y? The second pivot is missing when  $ ad = bc $: singular.