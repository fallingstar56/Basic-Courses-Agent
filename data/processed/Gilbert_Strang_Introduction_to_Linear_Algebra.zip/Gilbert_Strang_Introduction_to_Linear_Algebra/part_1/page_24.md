Solution  $ E_{21} $ removes the 4 in column 1. But zero also appears in column 2:

 $$ \left[A\quad b\right]=\left[\begin{array}{l l l l}{{{1}}}&{{{2}}}&{{{2}}}&{{{1}}} \\{{{4}}}&{{{8}}}&{{{9}}}&{{{3}}} \\{{{0}}}&{{{3}}}&{{{2}}}&{{{1}}}\end{array}\right]\qquad and\qquad E_{21}[A\quad b]=\left[\begin{array}{l l l l}{{{1}}}&{{{2}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{-1}}} \\{{{0}}}&{{{3}}}&{{{2}}}&{{{1}}}\end{array}\right] $$ 

Now  $ P_{32} $ exchanges rows 2 and 3. Back substitution produces z then y and x.

 $$ P_{32}E_{21}[\boldsymbol{A}\quad\boldsymbol{b}]=\left[\begin{array}{cccc}{{{1}}}&{{{2}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{3}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{-1}}}\end{array}\right]\qquad and\qquad\left[\begin{matrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{matrix}\right]=\left[\begin{matrix}{{{1}}} \\{{{1}}} \\{{{-1}}}\end{matrix}\right] $$ 

For the matrix  $ P_{32} $  $ E_{21} $ that does both steps at once, apply  $ P_{32} $ to  $ E_{21} $.

One matrix

Both steps

 $$ \boldsymbol{P}_{32}\boldsymbol{E}_{21}=\text{exchange the rows of}\boldsymbol{E}_{21}=\left[\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{-4}}}&{{{1}}}&{{{0}}}\end{array}\right]. $$ 

2.3 C Multiply these matrices in two ways. First, rows of A times columns of B. Second, columns of A times rows of B. That unusual way produces two matrices that add to AB. How many separate ordinary multiplications are needed?

Both ways

 $$ \boldsymbol{A}\boldsymbol{B}=\begin{bmatrix}{{{3}}}&{{{4}}} \\{{{1}}}&{{{5}}} \\{{{2}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{4}}} \\{{{1}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{10}}}&{{{16}}} \\{{{7}}}&{{{9}}} \\{{{4}}}&{{{8}}}\end{bmatrix} $$ 

Solution Rows of A times columns of B are dot products of vectors:

 $$ \left(\operatorname{row}1\right)\cdot\left(\operatorname{column}1\right)=\begin{bmatrix}3&4\\ \end{bmatrix}\begin{bmatrix}2\\ 1\end{bmatrix}=10 $$ 

 $$ \left(\mathrm{row~2}\right)\cdot\left(\mathrm{column~1}\right)=\begin{bmatrix}{{{1}}}&{{{5}}} \\{{{\end{bmatrix}\begin{bmatrix}2}}} \\{{{1}}}\end{bmatrix}=\begin{array}{l l}{{{7}}}&{{{is the~(2,1)entry of~AB}}}\end{array} $$ 

We need 6 dot products, 2 multiplications each, 12 in all  $ (3 \cdot 2 \cdot 2) $. The same AB comes from columns of A times rows of B. A column times a row is a matrix.

 $$ AB=\begin{bmatrix}{{{3}}} \\{{{1}}} \\{{{2}}}\end{bmatrix}\quad\begin{bmatrix}{{{2}}}&{{{4}}} \\\end{bmatrix}+\begin{bmatrix}{{{4}}} \\{{{5}}} \\{{{0}}}\end{bmatrix}\quad\begin{bmatrix}{{{1}}}&{{{1}}} \\\end{bmatrix}=\begin{bmatrix}{{{6}}}&{{{12}}} \\{{{2}}}&{{{4}}} \\{{{4}}}&{{{8}}}\end{bmatrix}+\begin{bmatrix}{{{4}}}&{{{4}}} \\{{{5}}}&{{{5}}} \\{{{0}}}&{{{0}}}\end{bmatrix} $$ 