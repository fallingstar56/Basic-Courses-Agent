Which number $q$ makes this system singular and which right side $t$ gives it infinitely many solutions? Find the solution that has $z = 1$.

 $$ x+4y-2z=1 $$ 

 $$ x+7y-6z=6 $$ 

 $$ 3y+qz=t. $$ 

Three planes can fail to have an intersection point, even if no planes are parallel. The system is singular if row 3 of A is a ___ of the first two rows. Find a third equation that can't be solved together with  $ x + y + z = 0 $ and  $ x - 2y - z = 1 $.

Find the pivots and the solution for both systems  $ (Ax = b $ and  $ Kx = b) $:

 $$ \begin{array}{lllllll} 2x&+&y& & =0& & &2x&-&y& &=0\\x+2y&+&z& & =0& & -x+2y&-&z& &=0\\y+2z&+&t=0& & &-&y+2z&-&t=0\\z+2t&=5& & &-&z+2t&=5. \end{array} $$ 

If you extend Problem 21 following the 1, 2, 1 pattern or the -1, 2, -1 pattern, what is the fifth pivot? What is the nth pivot? K is my favorite matrix.

If elimination leads to  $ x + y = 1 $ and 2y = 3, find three possible original problems.

For which two numbers  $ a $ will elimination fail on  $ A = \begin{bmatrix} a & 2 \\ a & a \end{bmatrix} $?

For which three numbers a will elimination fail to give three pivots?

 $ A = \begin{bmatrix} a & 2 & 3 \\ a & a & 4 \\ a & a & a \end{bmatrix} $ is singular for three values of a.

Look for a matrix that has row sums 4 and 8, and column sums 2 and s:

 $$ \mathbf{M a t r i x}=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}\quad\begin{aligned}a+b&=4&a+c&=2\\ c+d&=8&b+d&=s\end{aligned} $$ 

The four equations are solvable only if $s = \underline{\qquad}$. Then find two different matrices that have the correct row and column sums. Extra credit: Write down the 4 by 4 system $Ax = b$ with $x = (a, b, c, d)$ and make $A$ triangular by elimination.

Elimination in the usual order gives what matrix U and what solution to this “lower triangular” system? We are really solving by forward substitution:

 $$ \begin{align*}\begin{array}{rcl}3x&&=3\\6x+2y&&=8\\9x-2y+z=9.\end{array}\end{align*} $$ 