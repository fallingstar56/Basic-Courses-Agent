Choose a right side which gives no solution and another right side which gives infinitely many solutions. What are two of those solutions?

Singular system

 $$ \begin{array}{l} 3x+2y=10\\6x+4y=\end{array} $$ 

Choose a coefficient b that makes this system singular. Then choose a right side g that makes it solvable. Find two solutions in that singular case.

 $$ 2x+by=16 $$ 

 $$ 4x+8y=g. $$ 

7 For which numbers a does elimination break down (1) permanently (2) temporarily?

 $$ ax+3y=-3 $$ 

 $$ 4x+6y=\quad6. $$ 

Solve for x and y after fixing the temporary breakdown by a row exchange.

8 For which three numbers k does elimination break down? Which is fixed by a row exchange? In each case, is the number of solutions 0 or 1 or ∞?

 $$ kx+3y=\quad6 $$ 

 $$ 3x+ky=-6. $$ 

9 What test on $b_{1}$ and $b_{2}$ decides whether these two equations allow a solution? How many solutions will they have? Draw the column picture for $b = (1, 2)$ and $(1, 0)$.

 $$ \begin{aligned}&3x-2y=b_{1}\\&6x-4y=b_{2}.\\ \end{aligned} $$ 

10 In the xy plane, draw the lines  $ x + y = 5 $ and  $ x + 2y = 6 $ and the equation  $ y = \_\_\_\_\_\_ $ that comes from elimination. The line  $ 5x - 4y = c $ will go through the solution of these equations if  $ c = \_\_\_\_\_\_ $.

## Problems 11–20 study elimination on 3 by 3 systems (and possible failure)

11 (Recommended) A system of linear equations can't have exactly two solutions. Why?

(a) If  $ (x, y, z) $ and  $ (X, Y, Z) $ are two solutions, what is another solution?

(b) If 25 planes meet at two points, where else do they meet?