Look at the special case when  $ A = B = C = \text{square matrix} $. Then  $ (A \text{ times } A^2) $ is equal to  $ (A^2 \text{ times } A) $. The product in either order is  $ A^3 $. The matrix powers  $ A^p $ follow the same rules as numbers:

 $$ A^{p}=AAA\cdots A(p factors)\qquad(A^{p})(A^{q})=A^{p+q}\qquad(A^{p})^{q}=A^{pq}. $$ 

Those are the ordinary laws for exponents.  $ A^3 $ times  $ A^4 $ is  $ A^7 $ (seven factors). But the fourth power of  $ A^3 $ is  $ A^{12} $ (twelve  $ A' $s). When  $ p $ and  $ q $ are zero or negative these rules still hold, provided  $ A $ has a “−1 power”—which is the inverse matrix  $ A^{-1} $. Then  $ A^0 = I $ is the identity matrix in analogy with  $ 2^0 = 1 $.

For a number,  $ a^{-1} $ is 1/a. For a matrix, the inverse is written  $ A^{-1} $. (It is not I/A, except in MATLAB.) Every number has an inverse except  $ a = 0 $. To decide when A has an inverse is a central problem in linear algebra. Section 2.5 will start on the answer. This section is a Bill of Rights for matrices, to say when A and B can be multiplied and how.

## Block Matrices and Block Multiplication

We have to say one more thing about matrices. They can be cut into blocks (which are smaller matrices). This often happens naturally. Here is a 4 by 6 matrix broken into blocks of size 2 by 2—in this example each block is just I:

4 by 6 matrix

2 by 2 blocks give

2 by 3 block matrix

 $$ \boldsymbol{A}=\left[\begin{array}{c c c|c c c|c c}{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{\hline1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}\end{array}\right]=\left[\begin{array}{c c c}{{{I}}}&{{{I}}}&{{{I}}} \\{{{I}}}&{{{I}}}&{{{I}}} \\{{{\hline I}}}&{{{I}}}&{{{I}}}\end{array}\right]. $$ 

If B is also 4 by 6 and the block sizes match, you can add  $ A + B $ a block at a time.

You have seen block matrices before. The right side vector  $ \boldsymbol{b} $ was placed next to A in the “augmented matrix”. Then  $ [A\ \boldsymbol{b}] $ has two blocks of different sizes. Multiplying by an elimination matrix gave  $ [EA\ \boldsymbol{Eb}] $. No problem to multiply blocks times blocks, when their shapes permit.

Block multiplication If blocks of A can multiply blocks of B, then block multiplication of AB is allowed. Cuts between columns of A match cuts between rows of B.

 $$ \begin{bmatrix}A_{11}&A_{12}\\ A_{21}&A_{22}\end{bmatrix}\begin{bmatrix}B_{11}\\ B_{21}\end{bmatrix}=\begin{bmatrix}A_{11}B_{11}+A_{12}B_{21}\\ A_{21}B_{11}+A_{22}B_{21}\end{bmatrix}. $$ 

This equation is the same as if the blocks were numbers (which are 1 by 1 blocks). We are careful to keep  $ A' $s in front of  $ B' $s, because  $ BA $ can be different.

Main point When matrices split into blocks, it is often simpler to see how they act. The block matrix of I's above is much clearer than the original 4 by 6 matrix A.