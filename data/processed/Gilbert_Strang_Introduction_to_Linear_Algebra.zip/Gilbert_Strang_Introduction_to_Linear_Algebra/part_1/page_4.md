### 33 Multiplication by A is a “linear transformation”. Those words mean:

If $w$ is a combination of $u$ and $v$, then $Aw$ is the same combination of $Au$ and $Av$.

It is this “linearity” $Aw = cAu + dAv$ that gives us the name “linear algebra”.

Problem: If $u = \begin{bmatrix} 1 \\ 0 \end{bmatrix}$ and $v = \begin{bmatrix} 0 \\ 1 \end{bmatrix}$ then $Au$ and $Av$ are the columns of $A$.

Combine $w = cu + dv$. If $w = \begin{bmatrix} 5 \\ 7 \end{bmatrix}$ how is $Aw$ connected to $Au$ and $Av$?

Start from the four equations  $ -x_{i+1} + 2x_i - x_{i-1} = i $ (for  $ i = 1, 2, 3, 4 $ with  $ x_0 = x_5 = 0 $). Write those equations in their matrix form  $ Ax = b $. Can you solve them for  $ x_1, x_2, x_3, x_4 $?

35 A 9 by 9 Sudoku matrix $S$ has the numbers $1,\ldots,9$ in every row and every column, and in every 3 by 3 block. For the all-ones vector $\boldsymbol{x}=(1,\ldots,1)$, what is $S\boldsymbol{x}$?

A better question is: Which row exchanges will produce another Sudoku matrix? Also, which exchanges of block rows give another Sudoku matrix?

Section 2.7 will look at all possible permutations (reorderings) of the rows. I can see 6 orders for the first 3 rows, all giving Sudoku matrices. Also 6 permutations of the next 3 rows, and of the last 3 rows. And 6 block permutations of the block rows?