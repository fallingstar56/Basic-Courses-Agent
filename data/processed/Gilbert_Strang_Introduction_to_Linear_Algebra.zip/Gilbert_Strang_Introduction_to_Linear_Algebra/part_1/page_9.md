lead to whole numbers and not fractions:

 $$ \begin{aligned}2x+4y-2z&=2\\4x+9y-3z&=8\\-2x-3y+7z&=10\end{aligned} $$ 

What are the steps? The first pivot is the boldface 2 (upper left). Below that pivot we want to eliminate the 4. The first multiplier is the ratio 4/2 = 2. Multiply the pivot equation by  $ \ell_{21} = 2 $ and subtract. Subtraction removes the 4x from the second equation:

Step 1 Subtract 2 times equation 1 from equation 2. This leaves  $ y + z = 4 $.

We also eliminate  $ -2x $ from equation 3—still using the first pivot. The quick way is to add equation 1 to equation 3. Then  $ 2x $ cancels  $ -2x $. We do exactly that, but the rule in this book is to subtract rather than add. The systematic pattern has multiplier  $ \ell_{31} = -2/2 = -1 $. Subtracting  $ -1 $ times an equation is the same as adding:

Step 2 Subtract -1 times equation 1 from equation 3. This leaves  $ y + 5z = 12 $.

The two new equations involve only y and z. The second pivot (in boldface) is 1:

x is eliminated

 $$ \begin{array}{l}1y+1z=4\\1y+5z=12\end{array} $$ 

We have reached a 2 by 2 system. The final step eliminates y to make it 1 by 1:

Step 3 Subtract equation 2new from 3new. The multiplier is 1/1 = 1. Then 4z = 8. The original Ax = b has been converted into an upper triangular Ux = c:

 $$ \begin{array}{l} 2x+4y-2z=2\\4x+9y-3z=8\\-2x-3y+7z=10 \end{array}  \quad \mathrm{A}x=b \quad \begin{array}{l} 2x+4y-2z=2\\1y+1z=4\\4z=8 \end{array} $$ 

The goal is achieved—forward elimination is complete from A to U. Notice the pivots 2, 1, 4 along the diagonal of U. The pivots 1 and 4 were hidden in the original system. Elimination brought them out.  $ Ux = c $ is ready for back substitution, which is quick:

 $$ \begin{pmatrix}4z=8&gives&z=2\end{pmatrix}\quad(y+z=4\quad gives\quad y=2)\quad(equation1gives\quad x=-1) $$ 

The solution is  $ (x, y, z) = (-1, 2, 2) $. The row picture has three planes from three equations. All the planes go through this solution. The original planes are sloping, but the last plane  $ 4z = 8 $ after elimination is horizontal.

The column picture shows a combination Ax of column vectors producing the right side b. The coefficients in that combination are -1, 2, 2 (the solution):

 $$ \boldsymbol{A}\boldsymbol{x}=\left(-\mathbf{1}\right)\begin{bmatrix}2\\ 4\\ -2\end{bmatrix}+\mathbf{2}\begin{bmatrix}4\\ 9\\ -3\end{bmatrix}+\mathbf{2}\begin{bmatrix}-2\\ -3\\ 7\end{bmatrix}equals\begin{bmatrix}2\\ 8\\ 10\end{bmatrix}=\boldsymbol{b}. $$ 

The numbers x, y, z multiply columns 1, 2, 3 in Ax = b and also in the triangular Ux = c.