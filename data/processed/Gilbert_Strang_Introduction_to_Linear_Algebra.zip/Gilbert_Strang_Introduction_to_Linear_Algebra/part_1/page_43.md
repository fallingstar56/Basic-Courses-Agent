Note 4 (Important) Suppose there is a nonzero vector x such that Ax = 0. Then A cannot have an inverse. No matrix can bring 0 back to x.

If A is invertible, then Ax = 0 can only have the zero solution  $ x = A^{-1}0 = 0 $.

Note 5 A 2 by 2 matrix is invertible if and only if ad - bc is not zero:

2 by 2 Inverse:

 $$ \begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}^{-1}=\frac{1}{ad-bc}\begin{bmatrix}{{{d}}}&{{{-b}}} \\{{{-c}}}&{{{a}}}\end{bmatrix}. $$ 

This number ad−bc is the determinant of A. A matrix is invertible if its determinant is not zero (Chapter 5). The test for n pivots is usually decided before the determinant appears.

Note 6 A diagonal matrix has an inverse provided no diagonal entries are zero :

 $$  If\quad A=\begin{bmatrix}d_{1}&&\\ &\ddots&\\ &&d_{n}\end{bmatrix}\quad then\quad A^{-1}=\begin{bmatrix}1/d_{1}&&\\ &\ddots&\\ &&1/d_{n}\end{bmatrix}. $$ 

Example 1 The 2 by 2 matrix  $ A = \begin{bmatrix} 1 & 2 \\ 1 & 2 \end{bmatrix} $ is not invertible. It fails the test in Note 5, because ad - bc equals 2 - 2 = 0. It fails the test in Note 3, because Ax = 0 when  $ \boldsymbol{x} = (2, -1) $. It fails to have two pivots as required by Note 1.

Elimination turns the second row of this matrix A into a zero row.

## The Inverse of a Product AB

For two nonzero numbers $a$ and $b$, the sum $a + b$ might or might not be invertible. The numbers $a = 3$ and $b = -3$ have inverses $\frac{1}{3}$ and $-\frac{1}{3}$. Their sum $a + b = 0$ has no inverse. But the product $ab = -9$ does have an inverse, which is $\frac{1}{3}$ times $-\frac{1}{3}$.

For two matrices A and B, the situation is similar. It is hard to say much about the invertibility of  $ A + B $. But the product AB has an inverse, if and only if the two factors A and B are separately invertible (and the same size). The important point is that  $ A^{-1} $ and  $ B^{-1} $ come in reverse order:

If A and B are invertible then so is AB. The inverse of a product AB is

 $$ (A B)^{-1}=B^{-1}A^{-1}. $$ 

To see why the order is reversed, multiply AB times  $ B^{-1}A^{-1} $. Inside that is  $ BB^{-1}=I $:

Inverse of AB

 $$ (A B)(B^{-1}A^{-1})=A I A^{-1}=A A^{-1}=I. $$ 

We moved parentheses to multiply BB−1 first. Similarly B−1A−1 times AB equals I.