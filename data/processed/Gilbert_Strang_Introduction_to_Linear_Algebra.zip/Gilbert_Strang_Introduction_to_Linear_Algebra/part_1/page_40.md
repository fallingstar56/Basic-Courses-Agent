Problems 25–31 use column-row multiplication and block multiplication.

Multiply A times I using columns of A (3 by 3) times rows of I.

26 Multiply AB using columns times rows:

 $$ \boldsymbol{A}\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{2}}}&{{{4}}} \\{{{2}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{3}}}&{{{3}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{2}}} \\{{{2}}}\end{bmatrix}\begin{bmatrix}{{{3}}}&{{{3}}}&{{{0}}}\end{bmatrix}+\_\_\_=\_\_\_. $$ 

27 Show that the product of upper triangular matrices is always upper triangular:

 $$ \boldsymbol{A}\boldsymbol{B}=\begin{bmatrix}{{{x}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{x}}}\end{bmatrix}\begin{bmatrix}{{{x}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{x}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Proof using dot products (Row times column) (Row 2 of A) · (column 1 of B) = 0.

Which other dot products give zeros?

Proof using full matrices (Column times row) Draw  $ x' $s and  $ 0' $s in (column 2 of A) times (row 2 of B). Also show (column 3 of A) times (row 3 of B).

Draw the cuts in A (2 by 3) and B (3 by 4) and AB to show how each of the four multiplication rules is really a block multiplication:

(1) Matrix A times columns of B. Columns of AB

(2) Rows of A times the matrix B. Rows of AB

(3) Rows of A times columns of B. Inner products (numbers in AB)

(4) Columns of A times rows of B. Outer products (matrices add to AB)

Which matrices  $ E_{21} $ and  $ E_{31} $ produce zeros in the  $ (2, 1) $ and  $ (3, 1) $ positions of  $ E_{21}A $ and  $ E_{31}A $?

 $$ \boldsymbol{A}=\begin{bmatrix}{{{2}}}&{{{1}}}&{{{0}}} \\{{{-2}}}&{{{0}}}&{{{1}}} \\{{{8}}}&{{{5}}}&{{{3}}}\end{bmatrix}. $$ 

Find the single matrix E = E_{31}E_{21} that produces both zeros at once. Multiply EA.

Block multiplication says that column 1 is eliminated by

 $$ E A=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{-c/a}}}&{{{I}}}\end{bmatrix}\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{D}}}\end{bmatrix}=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{0}}}&{{{D-c b/a}}}\end{bmatrix}. $$ 

In Problem 29, what numbers go into c and D and what is  $ D - cb/a $?

With $i^{2} = -1$, the product of $(A + iB)$ and $(x + iy)$ is $Ax + iBx + iAy - By$. Use blocks to separate the real part without $i$ from the imaginary part that multiplies $i$:

 $$ \begin{aligned}\left[\begin{array}{cc}\boldsymbol{A}&-\boldsymbol{B}\\\boldsymbol{?}&?\end{array}\right]\begin{bmatrix}\boldsymbol{x}\\\boldsymbol{y}\end{bmatrix}=\left[\begin{array}{c}\boldsymbol{A}\boldsymbol{x}-\boldsymbol{B}\boldsymbol{y}\\\boldsymbol{?}\end{array}\right]\end{aligned}real part\begin{aligned}imaginary part\end{aligned} $$ 