Create a MATLAB command  $ A(2, :) = \ldots $ for the new row 2, to subtract 3 times row 1 from the existing row 2 if the matrix A is already known.

## Challenge Problems

Find experimentally the average 1st and 2nd and 3rd pivot sizes from MATLAB's  $ [L, U] = \mathbf{lu}(\mathbf{rand}(3)) $. The average size  $ \mathbf{abs}(U(1,1)) $ is above  $ \frac{1}{2} $ because  $ \mathbf{lu} $ picks the largest available pivot in column 1. Here  $ A = \mathbf{rand}(3) $ has random entries between 0 and 1.

If the last corner entry is  $ A(5,5) = 11 $ and the last pivot of A is  $ U(5,5) = 4 $, what different entry  $ A(5,5) $ would have made A singular?

Suppose elimination takes A to U without row exchanges. Then row j of U is a combination of which rows of A? If Ax = 0, is Ux = 0? If Ax = b, is Ux = b? If A starts out lower triangular, what is the upper triangular U?

Start with 100 equations  $ Ax = 0 $ for 100 unknowns  $ \boldsymbol{x} = (x_1, \ldots, x_{100}) $. Suppose elimination reduces the 100th equation to 0 = 0, so the system is “singular”.

(a) Elimination takes linear combinations of the rows. So this singular system has the singular property: Some linear combination of the 100 rows is ___.

(b) Singular systems Ax = 0 have infinitely many solutions. This means that some linear combination of the 100 columns is ___.

(c) Invent a 100 by 100 singular matrix with no zero entries.

(d) For your matrix, describe in words the row picture and the column picture of Ax = 0. Not necessary to draw 100-dimensional space.