8 Normally 4 “planes” in 4-dimensional space meet at a ___. Normally 4 column vectors in 4-dimensional space can combine to produce b. What combination of  $ (1,0,0,0) $,  $ (1,1,0,0) $,  $ (1,1,1,0) $,  $ (1,1,1,1) $ produces  $ b = (3,3,3,2) $? What 4 equations for x, y, z, t are you solving?

Problems 9–14 are about multiplying matrices and vectors.

9 Compute each Ax by dot products of the rows with the column vector:

(a)

 $$ \begin{bmatrix}{{{1}}}&{{{2}}}&{{{4}}} \\{{{-2}}}&{{{3}}}&{{{1}}} \\{{{-4}}}&{{{1}}}&{{{2}}}\end{bmatrix}\begin{bmatrix}{{{2}}} \\{{{2}}} \\{{{3}}}\end{bmatrix} $$ 

(b)

 $$ \begin{bmatrix}{{{2}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{2}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{1}}} \\{{{1}}} \\{{{2}}}\end{bmatrix} $$ 

10 Compute each Ax in Problem 9 as a combination of the columns:

9(a) becomes

 $$ \boldsymbol{A}\boldsymbol{x}=2\begin{bmatrix}1\\ -2\\ -4\end{bmatrix}+2\begin{bmatrix}2\\ 3\\ 1\end{bmatrix}+3\begin{bmatrix}4\\ 1\\ 2\end{bmatrix}=\begin{bmatrix}\\ \end{bmatrix}. $$ 

How many separate multiplications for Ax, when the matrix is “3 by 3”?

11 Find the two components of Ax by rows or by columns:

 $$ \begin{bmatrix}{{{2}}}&{{{3}}} \\{{{5}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{4}}} \\{{{2}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{3}}}&{{{6}}} \\{{{6}}}&{{{12}}}\end{bmatrix}\begin{bmatrix}{{{2}}} \\{{{-1}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{1}}}&{{{2}}}&{{{4}}} \\{{{2}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{3}}} \\{{{1}}} \\{{{1}}}\end{bmatrix}. $$ 

12 Multiply A times x to find three components of Ax:

 $$ \begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{2}}}&{{{1}}}&{{{3}}} \\{{{1}}}&{{{2}}}&{{{3}}} \\{{{3}}}&{{{3}}}&{{{6}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{1}}} \\{{{-1}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{1}}}&{{{2}}} \\{{{3}}}&{{{3}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{1}}}\end{bmatrix}. $$ 

13 (a) A matrix with m rows and n columns multiplies a vector with ___ components to produce a vector with ___ components.

(b) The planes from the m equations Ax = b are in ___ -dimensional space. The combination of the columns of A is in ___ -dimensional space.

14 Write  $ 2x + 3y + z + 5t = 8 $ as a matrix  $ A $ (how many rows?) multiplying the column vector  $ \boldsymbol{x} = (x, y, z, t) $ to produce  $ b $. The solutions  $ x $ fill a plane or “hyperplane” in 4-dimensional space. The plane is 3-dimensional with no 4D volume.

Problems 15–22 ask for matrices that act in special ways on vectors.

15 (a) What is the 2 by 2 identity matrix? I times  $ \left[\begin{array}{c} x \\ y \end{array}\right] $ equals  $ \left[\begin{array}{c} x \\ y \end{array}\right] $.

(b) What is the 2 by 2 exchange matrix? P times  $ \left[\begin{array}{c} \mathbf{x} \\ \mathbf{y} \end{array}\right] $ equals  $ \left[\begin{array}{c} \mathbf{y} \\ \mathbf{x} \end{array}\right] $.