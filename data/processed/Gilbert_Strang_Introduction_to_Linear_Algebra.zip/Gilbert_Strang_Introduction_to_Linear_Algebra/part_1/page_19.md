## The Matrix Form of One Elimination Step

 $ Ax = b $ is a convenient form for the original equation. What about the elimination steps? In this example, 2 times the first equation is subtracted from the second equation. On the right side, 2 times the first component of b is subtracted from the second component.

First step

 $$ \mathbf{b}=\begin{bmatrix}2\\ 8\\ 10\end{bmatrix}\quad changes to\quad\mathbf{b}_{new}=\begin{bmatrix}2\\ 4\\ 10\end{bmatrix}. $$ 

We want to do that subtraction with a matrix! The same result  $ b_{\text{new}} = Eb $ is achieved when we multiply an “elimination matrix”  $ E $ times  $ b $. It subtracts  $ 2b_1 $ from  $ b_2 $:

The elimination matrix is

 $$ \boldsymbol{E}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

Multiplication by E subtracts 2 times row 1 from row 2. Rows 1 and 3 stay the same:

 $$ \begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}} \\{{{8}}} \\{{{10}}}\end{bmatrix}=\begin{bmatrix}{{{2}}} \\{{{4}}} \\{{{10}}}\end{bmatrix}\quad\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{bmatrix}=\begin{bmatrix}{{{b_{1}}}} \\{{{b_{2}-2b_{1}}}} \\{{{b_{3}}}}\end{bmatrix} $$ 

The first and third rows of E come from the identity matrix I. They don’t change the first and third numbers (2 and 10). The new second component is the number 4 that appeared after the elimination step. This is  $ b_2 - 2b_1 $.

It is easy to describe the “elementary matrices” or “elimination matrices” like this E. Start with the identity matrix I. Change one of its zeros to the multiplier  $ -\ell $:

The identity matrix has 1's on the diagonal and otherwise 0's. Then  $ I_b = b $ for all  $ b $. The elementary matrix or elimination matrix  $ E_{ij} $ has the extra nonzero entry  $ -\ell $ in the  $ i,j $ position. Then  $ E_{ij} $ subtracts a multiple  $ \ell $ of row  $ j $ from row  $ i $.

Example 2 The matrix  $ E_{31} $ has  $ -\ell $ in the 3, 1 position:

Identity

 $$ \boldsymbol{I}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix} $$ 

Elimination

 $$ E_{31}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{-\ell}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

When you multiply $I$ times $b$, you get $b$. But $E_{31}$ subtracts $\ell$ times the first component from the third component. With $\ell = 4$ this example gives $9 - 4 = 5$:

 $$ \boldsymbol{I}\boldsymbol{b}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{3}}} \\{{{9}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{3}}} \\{{{9}}}\end{bmatrix}\quad and\quad\boldsymbol{E}\boldsymbol{b}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{-4}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{3}}} \\{{{9}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{3}}} \\{{{5}}}\end{bmatrix}. $$ 