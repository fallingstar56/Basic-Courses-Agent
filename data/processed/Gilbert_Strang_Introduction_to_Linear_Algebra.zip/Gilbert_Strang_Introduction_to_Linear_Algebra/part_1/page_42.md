### 2.5 Inverse Matrices

1 If the square matrix A has an inverse, then both A−1A = I and AA−1 = I.

2 The algorithm to test invertibility is elimination: A must have n (nonzero) pivots.

3 The algebra test for invertibility is the determinant of A: det A must not be zero.

4 The equation that tests for invertibility is Ax = 0: x = 0 must be the only solution.

5 If A and B (same size) are invertible then so is AB:  $ \left| (AB)^{-1} = B^{-1}A^{-1} \right| $

6  $ AA^{-1} = I $ is n equations for n columns of  $ A^{-1} $. Gauss-Jordan eliminates  $ [A\,I] $ to  $ [I\,A^{-1}] $.

7 The last page of the book gives 14 equivalent conditions for a square A to be invertible.

Suppose A is a square matrix. We look for an “inverse matrix”  $ A^{-1} $ of the same size, such that  $ A^{-1} $ times A equals I. Whatever A does,  $ A^{-1} $ undoes. Their product is the identity matrix—which does nothing to a vector, so  $ A^{-1}Ax = x $. But  $ A^{-1} $ might not exist.

What a matrix mostly does is to multiply a vector  $ x $. Multiplying  $ Ax = b $ by  $ A^{-1} $ gives  $ A^{-1}Ax = A^{-1}b $. This is  $ x = A^{-1}b $. The product  $ A^{-1}A $ is like multiplying by a number and then dividing by that number. A number has an inverse if it is not zero—matrices are more complicated and more interesting. The matrix  $ A^{-1} $ is called “A inverse.”

DEFINITION The matrix A is invertible if there exists a matrix A^{-1} that “inverts” A:

Two-sided inverse

 $$ A^{-1}A=I\quad and\quad AA^{-1}=I. $$ 

Not all matrices have inverses. This is the first question we ask about a square matrix: Is A invertible? We don’t mean that we immediately calculate  $ A^{-1} $. In most problems we never compute it! Here are six “notes” about  $ A^{-1} $.

Note 1 The inverse exists if and only if elimination produces n pivots (row exchanges are allowed). Elimination solves Ax = b without explicitly using the matrix  $ A^{-1} $.

Note 2 The matrix A cannot have two different inverses. Suppose BA = I and also AC = I. Then B = C, according to this “proof by parentheses”:

 $$ B(AC)=(BA)C\quad gives\quad BI=IC\quad or\quad B=C. $$ 

This shows that a left-inverse $B$ (multiplying from the left) and a right-inverse $C$ (multiplying $A$ from the right to give $AC = I$) must be the same matrix.

Note 3 If A is invertible, the one and only solution to Ax = b is  $ x = A^{-1}b $:

 $$ \begin{array}{l}Multi p l y\quad Ax=b\quad by\quad A^{-1}.\quad Then\quad x=A^{-1}Ax=A^{-1}b.\end{array} $$ 