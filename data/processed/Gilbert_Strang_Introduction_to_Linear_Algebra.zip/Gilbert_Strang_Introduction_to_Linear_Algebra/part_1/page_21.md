There is another requirement on matrix multiplication. Suppose B has only one column (this column is b). The matrix-matrix law for EB should agree with the matrix-vector law for Eb. Even more, we should be able to multiply matrices EB a column at a time:

If B has several columns b₁, b₂, b₃, then the columns of EB are Eb₁, Eb₂, Eb₃.

Matrix multiplication

 $$ AB=A\left[b_{1}b_{2}b_{3}\right]=\left[Ab_{1}Ab_{2}Ab_{3}\right]. $$ 

This holds true for the matrix multiplication in (3). If you multiply column 3 of A by E, you correctly get column 3 of EA:

 $$ \begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{-2}}} \\{{{-3}}} \\{{{7}}}\end{bmatrix}=\begin{bmatrix}{{{-2}}} \\{{{1}}} \\{{{7}}}\end{bmatrix}\quad E(column j of A)=column j of EA. $$ 

This requirement deals with columns, while elimination is applied to rows. The next section describes each entry of every product AB. The beauty of matrix multiplication is that all three approaches (rows, columns, whole matrices) come out right.

## The Matrix  $ P_{ij} $ for a Row Exchange

To subtract row j from row i we use  $ E_{ij} $. To exchange or “permute” those rows we use another matrix  $ P_{ij} $ (a permutation matrix). A row exchange is needed when zero is in the pivot position. Lower down, that pivot column may contain a nonzero. By exchanging the two rows, we have a pivot and elimination goes forward.

What matrix  $ P_{23} $ exchanges row 2 with row 3? We can find it by exchanging rows of the identity matrix I:

Permutation matrix

 $$ \begin{align*}P_{23}=\begin{bmatrix}1&0&0\\ 0&0&1\\ 0&1&0\end{bmatrix}.\end{align*} $$ 

This is a row exchange matrix. Multiplying by  $ P_{23} $ exchanges components 2 and 3 of any column vector. Therefore it also exchanges rows 2 and 3 of any matrix:

 $$ \begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{3}}} \\{{{5}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{5}}} \\{{{3}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{4}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{3}}} \\{{{0}}}&{{{6}}}&{{{5}}}\end{bmatrix}=\begin{bmatrix}{{{2}}}&{{{4}}}&{{{1}}} \\{{{0}}}&{{{6}}}&{{{5}}} \\{{{0}}}&{{{0}}}&{{{3}}}\end{bmatrix}. $$ 

On the right,  $ P_{23} $ is doing what it was created for. With zero in the second pivot position and “6” below it, the exchange puts 6 into the pivot.