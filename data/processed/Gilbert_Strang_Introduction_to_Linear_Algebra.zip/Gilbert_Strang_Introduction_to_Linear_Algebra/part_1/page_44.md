 $ B^{-1}A^{-1} $ illustrates a basic rule of mathematics: Inverses come in reverse order. It is also common sense: If you put on socks and then shoes, the first to be taken off are the ___. The same reverse order applies to three or more matrices:

Reverse order

 $$ (A B C)^{-1}=C^{-1}B^{-1}A^{-1}. $$ 

Example 2 Inverse of an elimination matrix. If E subtracts 5 times row 1 from row 2, then  $ E^{-1} $ adds 5 times row 1 to row 2:

 $ E^{subtracts} $

 $ E^{-1} $ adds

 $$ \boldsymbol{E}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-5}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{E}^{-1}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{5}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

Multiply  $ EE^{-1} $ to get the identity matrix I. Also multiply  $ E^{-1}E $ to get I. We are adding and subtracting the same 5 times row 1. If  $ AC = I $ then automatically  $ CA = I $.

For square matrices, an inverse on one side is automatically an inverse on the other side.

Example 3 Suppose $F$ subtracts 4 times row 2 from row 3, and $F^{-1}$ adds it back:

 $$ \boldsymbol{F}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-4}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{F}^{-1}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{4}}}&{{{1}}}\end{bmatrix}. $$ 

Now multiply $F$ by the matrix $E$ in Example 2 to find $FE$. Also multiply $E^{-1}$ times $F^{-1}$ to find $(FE)^{-1}$. Notice the orders $FE$ and $E^{-1}F^{-1}$!

 $$ FE=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-5}}}&{{{1}}}&{{{0}}} \\{{{20}}}&{{{-4}}}&{{{1}}}\end{bmatrix}\quad is inverted by\quad E^{-1}F^{-1}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{5}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{4}}}&{{{1}}}\end{bmatrix}. $$ 

The result is beautiful and correct. The product FE contains “20” but its inverse doesn’t. E subtracts 5 times row 1 from row 2. Then F subtracts 4 times the new row 2 (changed by row 1) from row 3. In this order FE, row 3 feels an effect from row 1.

In the order  $ E^{-1}F^{-1} $, that effect does not happen. First  $ F^{-1} $ adds 4 times row 2 to row 3. After that,  $ E^{-1} $ adds 5 times row 1 to row 2. There is no 20, because row 3 doesn't change again. In this order  $ E^{-1}F^{-1} $, row 3 feels no effect from row 1.

This is why the next section chooses A = LU, to go back from the triangular U to A. The multipliers fall into place perfectly in the lower triangular L.

In elimination order F follows E. In reverse order  $ E^{-1} $ follows  $ F^{-1} $.  $ E^{-1}F^{-1} $ is quick. The multipliers 5, 4 fall into place below the diagonal of 1's.