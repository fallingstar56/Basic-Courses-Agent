### 2.2 The Idea of Elimination

1 For $m = n = 3$, there are three equations $Ax = b$ and three unknowns $x_{1}, x_{2}, x_{3}$.

2 The first two equations are $a_{11}x_{1} + \cdots = b_{1}$ and $a_{21}x_{1} + \cdots = b_{2}$.

3 Multiply the first equation by $a_{21}/a_{11}$ and subtract from the second: then $x_{1}$ is eliminated.

4 The corner entry $a_{11}$ is the first “pivot” and the ratio $a_{21}/a_{11}$ is the first “multiplier.”

5 Eliminate $x_{1}$ from every remaining equation $i$ by subtracting $a_{i1}/a_{11}$ times the first equation.

6 Now the last $n - 1$ equations contain $n - 1$ unknowns $x_{2}, \ldots, x_{n}$. Repeat to eliminate $x_{2}$.

7 Elimination breaks down if zero appears in the pivot. Exchanging two equations may save it.

This chapter explains a systematic way to solve linear equations. The method is called “elimination”, and you can see it immediately in our 2 by 2 example. Before elimination, x and y appear in both equations. After elimination, the first unknown x has disappeared from the second equation  $ 8y = 8 $:

Before

 $$ \begin{array}{ccc} x-2y=1 &  \text{After} &  x-2y=1 \\ 3x+2y=11 & &  8y=8  \end{array} \quad \begin{array}{cc}  (multiply equation 1 by 3) &  (subtract to eliminate 3x) \end{array} $$ 

The new equation  $ 8y = 8 $ instantly gives  $ y = 1 $. Substituting  $ y = 1 $ back into the first equation leaves  $ x - 2 = 1 $. Therefore  $ x = 3 $ and the solution  $ (x, y) \doteq (3, 1) $ is complete.

Elimination produces an upper triangular system—this is the goal. The nonzero coefficients 1, -2, 8 form a triangle. That system is solved from the bottom upwards—first y = 1 and then x = 3. This quick process is called back substitution. It is used for upper triangular systems of any size, after elimination gives a triangle.

Important point: The original equations have the same solution x = 3 and y = 1. Figure 2.5 shows each system as a pair of lines, intersecting at the solution point  $ (3, 1) $. After elimination, the lines still meet at the same point. Every step worked with correct equations.

How did we get from the first pair of lines to the second pair? We subtracted 3 times the first equation from the second equation. The step that eliminates x from equation 2 is the fundamental operation in this chapter. We use it so often that we look at it closely:

To eliminate x: Subtract a multiple of equation 1 from equation 2.

Three times  $ x - 2y = 1 $ gives  $ 3x - 6y = 3 $. When this is subtracted from  $ 3x + 2y = 11 $, the right side becomes 8. The main point is that  $ 3x $ cancels  $ 3x $. What remains on the left side is  $ 2y - (-6y) $ or  $ 8y $, and  $ x $ is eliminated. The system became triangular.