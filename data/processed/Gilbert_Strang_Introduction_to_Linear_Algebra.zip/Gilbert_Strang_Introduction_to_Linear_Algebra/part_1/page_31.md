Example 2 Suppose A is a row vector (1 by 3) and B is a column vector (3 by 1). Then AB is 1 by 1 (only one entry, the dot product). On the other hand B times A (a column times a row) is a full 3 by 3 matrix. This multiplication is allowed!

Column times row

 $$ (n\times1)(1\times n)=(n\times n) $$ 

 $$ \begin{bmatrix}{{{0}}} \\{{{1}}} \\{{{2}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{4}}}&{{{6}}}\end{bmatrix}. $$ 

A row times a column is an “inner” product—that is another name for dot product. A column times a row is an “outer” product. These are extreme cases of matrix multiplication.

## The Second and Third Ways: Rows and Columns

In the big picture, A multiplies each column of B. The result is a column of AB. In that column, we are combining the columns of A. Each column of AB is a combination of the columns of A. That is the column picture of matrix multiplication:

2. Matrix A times every column of B

 $$ A\left[b_{1}\cdots b_{p}\right]=\left[A b_{1}\cdots A b_{p}\right]. $$ 

The row picture is reversed. Each row of A multiplies the whole matrix B. The result is a row of AB. Every row of AB is a combination of the rows of B:

3. Every row of A times matrix B

 $$ \left[\mathbf{row}\;i\;\mathbf{of}\;A\right]\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{4}}}&{{{5}}}&{{{6}}} \\{{{7}}}&{{{8}}}&{{{9}}}\end{bmatrix}=\left[\mathbf{row}\;i\;\mathbf{of}\;AB\right]. $$ 

We see row operations in elimination (E times A). Soon we see columns in  $ AA^{-1} = I $. The “row-column picture” has the dot products of rows with columns. Dot products are the usual way to multiply matrices by hand:  $ mnp $ separate steps of multiply/add.

 $$ AB=(m\times n)(n\times p)=(m\times p)\quad mp dot products with n steps each\quad(2) $$ 

## The Fourth Way: Columns Multiply Rows

There is a fourth way to multiply matrices. Not many people realize how important this is. I feel like a magician explaining a trick. Magicians won't do it but mathematicians try. The fourth way was in previous editions of this book, but I didn't emphasize it enough.

4. Multiply columns 1 to n of A times rows 1 to n of B. Add those matrices.

Column 1 of A multiplies row 1 of B. Columns 2 and 3 multiply rows 2 and 3. Then add:

 $$ \begin{aligned}\left[\begin{array}{ccc}{{{\mathbf{col}1}}}&{{{\mathbf{col}2}}}&{{{\mathbf{col}3}}} \\{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}} \\{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}} \\\end{array}\right]\left[\begin{array}{ccc}{{{\mathbf{row}1}}}&{{{\cdot}}}&{{{\cdot}}} \\{{{\mathbf{row}2}}}&{{{\cdot}}}&{{{\cdot}}} \\{{{\mathbf{row}3}}}&{{{\cdot}}}&{{{\cdot}}} \\\end{array}\right]=(\mathbf{col}1)\left(\mathbf{row}1)+(\mathbf{col}2)\left(\mathbf{row}2\right)+(\mathbf{col}3)\left(\mathbf{row}3\right).\end{aligned} $$ 