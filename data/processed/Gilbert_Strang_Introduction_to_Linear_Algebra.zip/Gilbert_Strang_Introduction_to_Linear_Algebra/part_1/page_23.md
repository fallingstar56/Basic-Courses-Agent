Notice again that word “acts.” This is essential. Matrices do something ! The matrix A acts on x to produce b. The matrix E operates on A to give EA. The whole process of elimination is a sequence of row operations, alias matrix multiplications. A goes to  $ E_{21}A $ which goes to  $ E_{31}E_{21}A $. Finally  $ E_{32}E_{31}E_{21}A $ is a triangular matrix.

The right side is included in the augmented matrix. The end result is a triangular system of equations. We stop for exercises on multiplication by E, before writing down the rules for all matrix multiplications (including block multiplication).

## ■ REVIEW OF THE KEY IDEAS

1.  $ Ax = x_1 $ times column  $ 1 + \cdots + x_n $ times column  $ n $. And  $ (Ax)_i = \sum_{j=1}^n a_{ij}x_j $.

2. Identity matrix = I, elimination matrix =  $ E_{ij} $ using  $ \ell_{ij} $, exchange matrix =  $ P_{ij} $.

3. Multiplying Ax = b by  $ E_{21} $ subtracts a multiple  $ \ell_{21} $ of equation 1 from equation 2. The number  $ -\ell_{21} $ is the  $ (2, 1) $ entry of the elimination matrix  $ E_{21} $.

4. For the augmented matrix  $ [A\ b] $, that elimination step gives  $ [E_{21}A\ E_{21}b] $.

5. When A multiplies any matrix B, it multiplies each column of B separately.

## WORKED EXAMPLES

2.3 A What 3 by 3 matrix  $ E_{21} $ subtracts 4 times row 1 from row 2? What matrix  $ P_{32} $ exchanges row 2 and row 3? If you multiply A on the right instead of the left, describe the results  $ AE_{21} $ and  $ AP_{32} $.

Solution By doing those operations on the identity matrix I, we find

 $$ E_{21}=\left[\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-4}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right]\qquad and\qquad P_{32}=\left[\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}}\end{array}\right]. $$ 

Multiplying by  $ E_{21} $ on the right side will subtract 4 times column 2 from column 1. Multiplying by  $ P_{32} $ on the right will exchange columns 2 and 3.

2.3 B Write down the augmented matrix  $ [A\ b] $ with an extra column:

 $$ \begin{array}{r} x+2y+2z=1 \\ 4x+8y+9z=3 \\ 3y+2z=1 \end{array} $$ 

Apply  $ E_{21} $ and then  $ P_{32} $ to reach a triangular system. Solve by back substitution. What combined matrix  $ P_{32}E_{21} $ will do both steps at once?