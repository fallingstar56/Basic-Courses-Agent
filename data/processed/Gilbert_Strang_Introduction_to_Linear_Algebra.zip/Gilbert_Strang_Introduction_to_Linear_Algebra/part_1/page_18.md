Matrices times Vectors and Ax = b

The 3 by 3 example in the previous section has the short form Ax = b:

 $$ \begin{array}{l l l l l } 2x_{1}+4x_{2}-2x_{3}=&2& & &\left[\begin{array}{ccc}2&4&-2\\4&9&-3\\-2&-3&7\end{array}\right]\left[\begin{array}{l}x_{1}\\x_{2}\\x_{3}\end{array}\right]=\left[\begin{array}{c}2\\8\\10\end{array}\right]. \end{array} $$ 

The nine numbers on the left go into the matrix A. That matrix not only sits beside x. A multiplies x. The rule for “A times x” is exactly chosen to yield the three equations.

Review of A times x. A matrix times a vector gives a vector. The matrix is square when the number of equations (three) matches the number of unknowns (three). Our matrix is 3 by 3. A general square matrix is n by n. Then the vector x is in n-dimensional space.

 $$ \begin{aligned}The unknown is\quad x&=\begin{bmatrix}x_{1}\\ x_{2}\\ x_{3}\end{bmatrix}\quad and the solution is\quad x&=\begin{bmatrix}-1\\ 2\\ 2\end{bmatrix}.\end{aligned} $$ 

Key point:  $ Ax = b $ represents the row form and also the column form of the equations.

Column form

 $$ \boldsymbol{A}\boldsymbol{x}=\left(-1\right)\begin{bmatrix}2\\ 4\\ -2\end{bmatrix}+2\begin{bmatrix}4\\ 9\\ -3\end{bmatrix}+2\begin{bmatrix}-2\\ -3\\ 7\end{bmatrix}=\begin{bmatrix}2\\ 8\\ 10\end{bmatrix}=\boldsymbol{b}. $$ 

Ax is a combination of the columns of A. To compute each component of Ax, we use the row form of matrix multiplication. Components of Ax are dot products with rows of A. The short formula for that dot product with x uses “sigma notation”.

The first component of Ax above is  $ (-1)(2)+(2)(4)+(2)(-2) $.

The ith component of Ax is  $ (row\,i) \cdot x = a_{i1}x_{1} + a_{i2}x_{2} + \cdots + a_{in}x_{n} $.

This is sometimes written with the sigma symbol as

∑ is an instruction to add. Start with j = 1 and stop with j = n. The sum begins with  $ a_{i1}x_1 $ and ends with  $ a_{in}x_n $. That produces the dot product (row i) · x.

One point to repeat about matrix notation: The entry in row 1, column 1 (the top left corner) is  $ a_{11} $. The entry in row 1, column 3 is  $ a_{13} $. The entry in row 3, column 1 is  $ a_{31} $. (Row number comes before column number.) The word “entry” for a matrix corresponds to “component” for a vector. General rule:  $ a_{ij} = A(i, j) $ is in row i, column j.

Example 1 This matrix has  $ a_{ij} = 2i + j $. Then  $ a_{11} = 3 $. Also  $ a_{12} = 4 $ and  $ a_{21} = 5 $. Here is Ax by rows with numbers and letters:

 $$ \begin{bmatrix}3&4\\ 5&6\end{bmatrix}\begin{bmatrix}2\\ 1\end{bmatrix}=\begin{bmatrix}3\cdot2+4\cdot1\\ 5\cdot2+6\cdot1\end{bmatrix}\qquad\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}x_{1}\\ x_{2}\end{bmatrix}=\begin{bmatrix}a_{11}x_{1}+a_{12}x_{2}\\ a_{21}x_{1}+a_{22}x_{2}\end{bmatrix}. $$ 

A row times a column gives a dot product.

 $ ^{1} $Einstein shortened this even more by omitting the  $ \sum $. The repeated  $ j $ in  $ a_{ij}x_j $ automatically meant addition. He also wrote the sum as  $ a_i^j x_j $. Not being Einstein, we include the  $ \sum $.