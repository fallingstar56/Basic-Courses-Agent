27 Choose the numbers a, b, c, d in this augmented matrix so that there is (a) no solution (b) infinitely many solutions.

 $$ \left[\begin{array}{l l l l}{{{A}}}&{{{b}}}\end{array}\right]=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}}&{{{a}}} \\{{{0}}}&{{{4}}}&{{{5}}}&{{{b}}} \\{{{0}}}&{{{0}}}&{{{d}}}&{{{c}}}\end{bmatrix} $$ 

Which of the numbers a, b, c, or d have no effect on the solvability?

If AB = I and BC = I use the associative law to prove A = C.

## Challenge Problems

Find the triangular matrix E that reduces “Pascal’s matrix” to a smaller Pascal:

Elimination on column 1

 $$ \boldsymbol{E}\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{3}}}&{{{3}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{1}}}\end{bmatrix}. $$ 

Which matrix  $ M $ (multiplying several  $ E' $s) reduces Pascal all the way to  $ I $?

Pascal's triangular matrix is exceptional, all of its multipliers are  $ \ell_{ij} = 1 $.

Write  $ M = \begin{bmatrix} 3 & 4 \\ 5 & 7 \end{bmatrix} $ as a product of many factors  $ A = \begin{bmatrix} 1 & 0 \\ 1 & 1 \end{bmatrix} $ and  $ B = \begin{bmatrix} 1 & 1 \\ 0 & 1 \end{bmatrix} $.

(a) What matrix E subtracts row 1 from row 2 to make row 2 of EM smaller?

(b) What matrix F subtracts row 2 of EM from row 1 to reduce row 1 of FEM?

(c) Continue E's and F''s until (many E''s and F''s) times (M) is (A or B).

(d) E and F are the inverses of A and B! Moving all E's and F's to the right side will give you the desired result  $ M = \text{product of } A's \text{ and } B's $.

This is possible for integer matrices  $ M = \begin{bmatrix} a & b \\ c & d \end{bmatrix} > 0 $ that have  $ ad - bc = 1 $.

Find elimination matrices  $ E_{21} $ then  $ E_{32} $ then  $ E_{43} $ to change K into U:

 $$ E_{43}\;E_{32}\;E_{21}\;\left[\begin{array}{c c c c}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{-a}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{-b}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{-c}}}&{{{1}}}\end{array}\right]=I. $$ 

Apply those three steps to the identity matrix I, to multiply  $ E_{43}E_{32}E_{21} $