## ■ REVIEW OF THE KEY IDEAS

1. The  $ (i,j) $ entry of AB is (row i of A)  $ \cdot $ (column j of B).

2. An m by n matrix times an n by p matrix uses mnp separate multiplications.

3. A times BC equals AB times C (surprisingly important).

4. AB is also the sum of these n matrices: (column j of A) times (row j of B).

5. Block multiplication is allowed when the block shapes match correctly.

6. Block elimination produces the Schur complement  $ D - CA^{-1}B $.

## WORKED EXAMPLES

2.4 A graph or a network has n nodes. Its adjacency matrix S is n by n. This is a 0-1 matrix with  $ s_{ij} = 1 $ when nodes i and j are connected by an edge.

<div style="text-align: center;"><img src="imgs/img_in_image_box_186_614_463_776.jpg" alt="Image" width="25%" /></div>


Adjacency matrix Square and symmetric for undirected graphs Edges go both ways

 $$ \boldsymbol{S}=\left[\begin{array}{cccc}{{{0}}}&{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}}&{{{0}}}\end{array}\right] $$ 

The matrix  $ S^2 $ has a useful interpretation.  $ (S^2)_{ij} $ counts the walks of length 2 between node  $ i $ and node  $ j $. Between nodes 2 and 3 the graph has two walks: go via 1 or go via 4. From node 1 to node 1, there are also two walks: 1–2–1 and 1–3–1.

 $$ S^{2}=\left[\begin{array}{cccc}{{{2}}}&{{{1}}}&{{{1}}}&{{{2}}} \\{{{1}}}&{{{3}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{1}}} \\{{{2}}}&{{{1}}}&{{{1}}}&{{{2}}} \\\end{array}\right]\qquad S^{3}=\left[\begin{array}{cccc}{{{2}}}&{{{5}}}&{{{5}}}&{{{2}}} \\{{{5}}}&{{{4}}}&{{{5}}}&{{{5}}} \\{{{5}}}&{{{5}}}&{{{4}}}&{{{5}}} \\{{{2}}}&{{{5}}}&{{{5}}}&{{{2}}} \\\end{array}\right] $$ 

Can you find 5 walks of length 3 between nodes 1 and 2?

The real question is why  $ S^N $ counts all the  $ N $-step paths between pairs of nodes. Start with  $ S^2 $ and look at matrix multiplication by dot products:

 $$ (S^{2})_{i j}=(\mathrm{r o w~}i\mathrm{~o f~}S)\cdot(\mathrm{c o l u m n~}j\mathrm{~o f~}S)=s_{i1}s_{1j}+s_{i2}s_{2j}+s_{i3}s_{3j}+s_{i4}s_{4j}. $$ 

If there is a 2-step path  $ i \to 1 \to j $, the first multiplication gives  $ s_{i1}s_{1j} = (1)(1) = 1 $. If  $ i \to 1 \to j $ is not a path, then either  $ i \to 1 $ is missing or  $ 1 \to j $ is missing. So the multiplication gives  $ s_{i1}s_{1j} = 0 $ in that case.