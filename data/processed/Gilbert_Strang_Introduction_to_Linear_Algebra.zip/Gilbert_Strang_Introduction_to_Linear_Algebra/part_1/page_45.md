## Calculating  $ A^{-1} $ by Gauss-Jordan Elimination

I hinted that  $ A^{-1} $ might not be explicitly needed. The equation  $ Ax = b $ is solved by  $ x = A^{-1}b $. But it is not necessary or efficient to compute  $ A^{-1} $ and multiply it times  $ b $. Elimination goes directly to  $ x $. And elimination is also the way to calculate  $ A^{-1} $, as we now show. The Gauss-Jordan idea is to solve  $ AA^{-1} = I $, finding each column of  $ A^{-1} $.

A multiplies the first column of  $ A^{-1} $ (call that  $ x_1 $) to give the first column of  $ I $ (call that  $ e_1 $). This is our equation  $ Ax_1 = e_1 = (1, 0, 0) $. There will be two more equations. Each of the columns  $ x_1 $,  $ x_2 $,  $ x_3 $ of  $ A^{-1} $ is multiplied by  $ A $ to produce a column of  $ I $:

3 columns of  $ A^{-1} $

 $$ A A^{-1}=A\begin{bmatrix}x_{1}&x_{2}&x_{3}\end{bmatrix}=\begin{bmatrix}e_{1}&e_{2}&e_{3}\end{bmatrix}=I. $$ 

To invert a 3 by 3 matrix  $ A $, we have to solve three systems of equations:  $ Ax_1 = e_1 $ and  $ Ax_2 = e_2 = (0, 1, 0) $ and  $ Ax_3 = e_3 = (0, 0, 1) $. Gauss-Jordan finds  $ A^{-1} $ this way.

The Gauss-Jordan method computes  $ A^{-1} $ by solving all  $ n $ equations together. Usually the “augmented matrix” [A b] has one extra column  $ b $. Now we have three right sides  $ e_1, e_2, e_3 $ (when  $ A $ is 3 by 3). They are the columns of  $ I $, so the augmented matrix is really the block matrix [A I]. I take this chance to invert my favorite matrix  $ K $, with  $ 2's $ on the main diagonal and  $ -1's $ next to the  $ 2's $:

Start Gauss-Jordan on K

 $$ \begin{aligned}\left[\begin{array}{lll}{{{K}}}&{{{e_{1}}}}&{{{e_{2}}}} \\{{{e_{3}}}}\end{array}\right]&=\left[\begin{array}{ccccc}{{{2}}}&{{{-1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right]\quad Start Gauss\text{。}\\&\rightarrow\left[\begin{array}{ccccc}{{{2}}}&{{{-1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{\frac{3}{2}}}}&{{{-1}}}&{{{\frac{1}{2}}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right]\quad(\frac{1}{2}row1+row2)\\&\rightarrow\left[\begin{array}{ccccc}{{{2}}}&{{{-1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{\frac{3}{2}}}}&{{{-1}}}&{{{\frac{1}{2}}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{\frac{4}{3}}}}&{{{\frac{1}{3}}}}&{{{\frac{2}{3}}}}&{{{1}}}\end{array}\right]\quad(\frac{2}{3}row2+row3)\end{aligned} $$ 

We are halfway to  $ K^{-1} $. The matrix in the first three columns is  $ U $ (upper triangular). The pivots  $ 2, \frac{3}{2}, \frac{4}{3} $ are on its diagonal. Gauss would finish by back substitution. The contribution of Jordan is to continue with elimination! He goes all the way to the reduced echelon form  $ R = I $. Rows are added to rows above them, to produce zeros above the pivots:

 $$ \begin{array}{r l}{\left(\begin{array}{l}{{{\mathrm{Z e r o~a b o v e}}}} \\{{{\mathrm{t h i r d~p i v o t}}}}\end{array}\right)}&{\rightarrow\left[\begin{array}{l l l l l}{{{2}}}&{{{-1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{\frac{3}{2}}}}&{{{0}}}&{{{\frac{3}{4}}}}&{{{\frac{3}{2}}}}&{{{\frac{3}{4}}}} \\{{{0}}}&{{{0}}}&{{{\frac{4}{3}}}}&{{{\frac{1}{3}}}}&{{{\frac{2}{3}}}}&{{{1}}}\end{array}\right]\qquad\left(\frac{3}{4}\;r o w\;3+r o w\;2\right)}\\ {\left(\begin{array}{l}{{{\mathrm{Z e r o~a b o v e}}}} \\{{{\mathrm{s e c o n d~p i v o t}}}}\end{array}\right)}&{\rightarrow\left[\begin{array}{l l l l l l}{{{2}}}&{{{0}}}&{{{0}}}&{{{\frac{3}{2}}}}&{{{1}}}&{{{\frac{1}{2}}}} \\{{{0}}}&{{{\frac{3}{2}}}}&{{{0}}}&{{{\frac{3}{4}}}}&{{{\frac{3}{2}}}}&{{{\frac{3}{4}}}} \\{{{0}}}&{{{0}}}&{{{\frac{4}{3}}}}&{{{\frac{1}{3}}}}&{{{\frac{2}{3}}}}&{{{1}}}\end{array}\right]\qquad\left(\frac{2}{3}\;r o w\;2+r o w\;1\right)}\end{array} $$ 

The final Gauss-Jordan step is to divide each row by its pivot. The new pivots are all 1.