10 (a) What 3 by 3 matrix  $ E_{13} $ will add row 3 to row 1?

(b) What matrix adds row 1 to row 3 and at the same time row 3 to row 1?

(c) What matrix adds row 1 to row 3 and then adds row 3 to row 1?

Create a matrix that has  $ a_{11} = a_{22} = a_{33} = 1 $ but elimination produces two negative pivots without row exchanges. (The first pivot is 1.)

12 Multiply these matrices:

 $$ \begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{-1}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{1}}}&{{{3}}}&{{{1}}} \\{{{1}}}&{{{4}}}&{{{0}}}\end{bmatrix}. $$ 

Explain these facts. If the third column of B is all zero, the third column of EB is all zero (for any E). If the third row of B is all zero, the third row of EB might not be zero.

14 This 4 by 4 matrix will need elimination matrices  $ E_{21} $ and  $ E_{32} $ and  $ E_{43} $. What are those matrices?

 $$ \boldsymbol{A}=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}. $$ 

15 Write down the 3 by 3 matrix that has  $ a_{ij} = 2i - 3j $. This matrix has  $ a_{32} = 0 $, but elimination still needs  $ E_{32} $ to produce a zero in the 3, 2 position. Which previous step destroys the original zero and what is  $ E_{32} $?

Problems 16–23 are about creating and multiplying matrices.

16 Write these ancient problems in a 2 by 2 matrix form Ax = b and solve them:

(a) X is twice as old as Y and their ages add to 33.

(b)  $ (x,y)=(2,5) $ and  $ (3,7) $ lie on the line  $ y=mx+c $. Find m and c.

The parabola  $ y = a + bx + cx^2 $ goes through the points  $ (x, y) = (1, 4) $ and  $ (2, 8) $ and  $ (3, 14) $. Find and solve a matrix equation for the unknowns  $ (a, b, c) $.

18 Multiply these matrices in the orders EF and FE:

 $$ \boldsymbol{E}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{a}}}&{{{1}}}&{{{0}}} \\{{{b}}}&{{{0}}}&{{{1}}}\end{bmatrix}\qquad\boldsymbol{F}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{c}}}&{{{1}}}\end{bmatrix}. $$ 

Also compute  $ E^{2} = EE $ and  $ F^{3} = FFF $. You can guess  $ F^{100} $.