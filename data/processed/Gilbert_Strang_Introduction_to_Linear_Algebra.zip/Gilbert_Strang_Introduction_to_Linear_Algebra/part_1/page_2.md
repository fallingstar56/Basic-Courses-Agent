(a) What 2 by 2 matrix $R$ rotates every vector by $90^\circ$? $R$ times $\begin{bmatrix} x \\ y \end{bmatrix}$ is $\begin{bmatrix} y \\ -x \end{bmatrix}$

(b) What 2 by 2 matrix  $ R^{2} $ rotates every vector by  $ 180^{\circ} $?

Find the matrix P that multiplies  $ (x, y, z) $ to give  $ (y, z, x) $. Find the matrix Q that multiplies  $ (y, z, x) $ to bring back  $ (x, y, z) $.

What 2 by 2 matrix E subtracts the first component from the second component?

What 3 by 3 matrix does the same?

What 3 by 3 matrix E multiplies $(x,y,z)$ to give $(x,y,z+x)$? What matrix $E^{-1}$ multiplies $(x,y,z)$ to give $(x,y,z-x)$? If you multiply $(3,4,5)$ by $E$ and then multiply by $E^{-1}$, the two results are (____) and (____).

 $$ \boldsymbol{E}\begin{bmatrix}3\\ 5\end{bmatrix}=\begin{bmatrix}3\\ 2\end{bmatrix}\qquad and\qquad\boldsymbol{E}\begin{bmatrix}3\\ 5\\ 7\end{bmatrix}=\begin{bmatrix}3\\ 2\\ 7\end{bmatrix}. $$ 

What 2 by 2 matrix  $ P_{1} $ projects the vector  $ (x, y) $ onto the x axis to produce  $ (x, 0) $? What matrix  $ P_{2} $ projects onto the y axis to produce  $ (0, y) $? If you multiply  $ (5, 7) $ by  $ P_{1} $ and then multiply by  $ P_{2} $, you get (____) and (____).

21 What 2 by 2 matrix $R$ rotates every vector through $45^{\circ}$? The vector $(1,0)$ goes to $(\sqrt{2}/2,\sqrt{2}/2)$. The vector $(0,1)$ goes to $(-\sqrt{2}/2,\sqrt{2}/2)$. Those determine the matrix. Draw these particular vectors in the $xy$ plane and find $R$.

Write the dot product of  $ (1, 4, 5) $ and  $ (x, y, z) $ as a matrix multiplication Ax. The matrix A has one row. The solutions to Ax = 0 lie on a ___ perpendicular to the vector ___. The columns of A are only in ___ -dimensional space.

In MATLAB notation, write the commands that define this matrix A and the column vectors x and b. What command would test whether or not Ax = b?

 $$ A={\left[\begin{array}{l l}{1}&{2}\\ {3}&{4}\end{array}\right]}\qquad\qquad x={\left[\begin{array}{l}{5}\\ {-2}\end{array}\right]}\qquad\qquad b={\left[\begin{array}{l}{1}\\ {7}\end{array}\right]} $$ 

The MATLAB commands A = eye(3) and v = [3:5]' produce the 3 by 3 identity matrix and the column vector (3, 4, 5). What are the outputs from A*v and v'*v? (Computer not needed!) If you ask for v*A, what happens?

25 If you multiply the 4 by 4 all-ones matrix A = ones(4) and the column v = ones(4,1), what is A*v? (Computer not needed.) If you multiply B = eye(4) + ones(4) times w = zeros(4,1) + 2*ones(4,1), what is B*w?