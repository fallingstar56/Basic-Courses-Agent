Example 3 (Important special case) Let the blocks of A be its n columns. Let the blocks of B be its n rows. Then block multiplication AB adds up columns times rows:

Columns

times

rows

 $$ \begin{bmatrix}\vert&&&\\ a_{1}&\cdots&a_{n}\\ \vert&&&\vert\end{bmatrix}\begin{bmatrix}-\quad b_{1}&-\\\vdots\\\vert&b_{n}&-\end{bmatrix}=\begin{bmatrix}\\ a_{1}b_{1}+\cdots+a_{n}b_{n}\\ \end{bmatrix}. $$ 

This is Rule 4 to multiply matrices. Here is a numerical example:

 $$ \begin{bmatrix}{{{1}}}&{{{4}}} \\{{{1}}}&{{{5}}}\end{bmatrix}\begin{bmatrix}{{{3}}}&{{{2}}} \\{{{1}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{1}}}\end{bmatrix}\begin{bmatrix}{{{3}}}&{{{2}}}\end{bmatrix}+\begin{bmatrix}{{{4}}} \\{{{5}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{3}}}&{{{2}}} \\{{{3}}}&{{{2}}}\end{bmatrix}+\begin{bmatrix}{{{4}}}&{{{0}}} \\{{{5}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{7}}}&{{{2}}} \\{{{8}}}&{{{2}}}\end{bmatrix}. $$ 

Summary The usual way, rows times columns, gives four dot products (8 multiplications). The new way, columns times rows, gives two full matrices (the same 8 multiplications).

Example 4 (Elimination by blocks) Suppose the first column of A contains 1, 3, 4. To change 3 and 4 to 0 and 0, multiply the pivot row by 3 and 4 and subtract. Those row operations are really multiplications by elimination matrices  $ E_{21} $ and  $ E_{31} $:

One at a time

 $$ E_{21}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-3}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad E_{31}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{-4}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

The “block idea” is to do both eliminations with one matrix E. That matrix clears out the whole first column of A below the pivot a = 1:

 $$ \boldsymbol{E}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-3}}}&{{{1}}}&{{{0}}} \\{{{-4}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad multiplies\quad\begin{bmatrix}{{{\mathbf{1}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}} \\{{{\mathbf{3}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}} \\{{{\mathbf{4}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}}\end{bmatrix}\quad to give\quad\boldsymbol{E}\boldsymbol{A}=\begin{bmatrix}{{{\mathbf{1}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}} \\{{{\mathbf{0}}}}&{{{\boldsymbol{y}}}}&{{{\boldsymbol{y}}}} \\{{{\mathbf{0}}}}&{{{\boldsymbol{z}}}}&{{{\boldsymbol{z}}}}\end{bmatrix}. $$ 

Using inverse matrices, a block matrix E can do elimination on a whole (block) column. Suppose a matrix has four blocks A, B, C, D. Watch how E eliminates C by blocks:

Block elimination

 $$ \left[\frac{\boldsymbol{I}}{\boldsymbol{-C}\boldsymbol{A}^{-1}}\left|\begin{array}{c}\boldsymbol{0}\\\boldsymbol{I}\end{array}\right.\right]\left[\frac{\boldsymbol{A}}{\boldsymbol{C}}\left|\begin{array}{c}\boldsymbol{B}\\\boldsymbol{D}\end{array}\right.\right]=\left[\frac{\boldsymbol{A}}{\boldsymbol{0}}\left|\begin{array}{c}\boldsymbol{B}\\\boldsymbol{D}-\boldsymbol{C}\boldsymbol{A}^{-1}\boldsymbol{B}\end{array}\right.\right]. $$ 

Elimination multiplies the first row  $ [A\ B] $ by  $ CA^{-1} $ (previously  $ c/a $). It subtracts from  $ C $ to get a zero block in the first column. It subtracts from  $ D $ to get  $ S = D - CA^{-1}B $.

This is ordinary elimination, a column at a time—using blocks. The pivot block is A. That final block is  $ D - CA^{-1}B $, just like  $ d - cb/a $. This is called the Schur complement.