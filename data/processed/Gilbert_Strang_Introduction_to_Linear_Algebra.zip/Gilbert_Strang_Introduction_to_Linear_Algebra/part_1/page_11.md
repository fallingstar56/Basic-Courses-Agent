## WORKED EXAMPLES

2.2 A When elimination is applied to this matrix A, what are the first and second pivots? What is the multiplier  $ \ell_{21} $ in the first step ( $ \ell_{21} $ times row 1 is subtracted from row 2)?

 $$ \boldsymbol{A}=\left[\begin{array}{lll}{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}\end{array}\right]\longrightarrow\left[\begin{array}{lll}{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}\end{array}\right]\longrightarrow\left[\begin{array}{lll}{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right]=\boldsymbol{U}. $$ 

What entry in the 2, 2 position (instead of 2) would force an exchange of rows 2 and 3? Why is the lower left multiplier  $ \ell_{31} = 0 $, subtracting zero times row 1 from row 3? If you change the corner entry from  $ a_{33} = 2 $ to  $ a_{33} = 1 $, why does elimination fail?

Solution The first pivot is 1. The multiplier  $ \ell_{21} $ is 1, 1. When 1 times row 1 is subtracted from row 2, the second pivot is revealed as another 1. If the original middle entry had been 1 instead of 2, that would have forced a row exchange.

The multiplier  $ \ell_{31} $ is zero because  $ a_{31} = 0 $. A zero at the start of a row needs no elimination. This A is a “band matrix”. Everything stays zero outside the band.

The last pivot is also 1. So if the original corner entry  $ a_{33} = 2 $ reduced by 1, elimination would produce 0. No third pivot, elimination fails.

2.2 B Suppose A is already a triangular matrix (upper triangular or lower triangular). Where do you see its pivots? When does Ax = b have exactly one solution for every b?

Solution The pivots of a triangular matrix are already set along the main diagonal. Elimination succeeds when all those numbers are nonzero. Use back substitution when A is upper triangular, go forward when A is lower triangular.

2.2 C Use elimination to reach upper triangular matrices U. Solve by back substitution or explain why this is impossible. What are the pivots (never zero)? Exchange equations when necessary. The only difference is the -x in the last equation.

Success

 $$ \begin{aligned}&x+y+z=7\\&x+y-z=5\\&x-y+z=3\\ \end{aligned} $$ 

Failure

 $$ \begin{aligned}x+y+z&=7\\x+y-z&=5\\-x-y+z&=3\end{aligned} $$ 

Solution For the first system, subtract equation 1 from equations 2 and 3 (the multipliers are  $ \ell_{21}=1 $ and  $ \ell_{31}=1 $). The 2, 2 entry becomes zero, so exchange equations 2 and 3:

Success

 $$ \begin{array}{llll} x+y+z= & 7 & & x+y+z= \quad 7 \\ \mathbf{0}y-2z=-2 &  \text{exchanges into} & -2y+0z=-4 \\ -2y+0z=-4 & & -2z=-2 \end{array} $$ 

Then back substitution gives z = 1 and y = 2 and x = 4. The pivots are 1, -2, -2.