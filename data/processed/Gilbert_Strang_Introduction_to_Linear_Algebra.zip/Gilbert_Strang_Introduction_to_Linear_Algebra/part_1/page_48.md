Elimination gives a complete test for invertibility of a square matrix.  $ A^{-1} $ exists (and Gauss-Jordan finds it) exactly when A has n pivots. The argument above shows more:

 $$  If\quad AC=I\quad then\quad CA=I\quad and\quad C=A^{-1} $$ 

Example 6 If L is lower triangular with l's on the diagonal, so is  $ L^{-1} $.

A triangular matrix is invertible if and only if no diagonal entries are zero.

Here $L$ has $1$'s so $L^{-1}$ also has $1$'s. Use the Gauss-Jordan method to construct $L^{-1}$ from $E_{32}, E_{31}, E_{21}$. Notice how $L^{-1}$ contains the strange entry 11, from 3 times 5 minus 4.

Gauss-Jordan on triangular L

 $$ \begin{aligned}&\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{3}}}&{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{4}}}&{{{5}}}&{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{L}}}&{{{I}}}\end{bmatrix}\\&\rightarrow\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{-3}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{5}}}&{{{1}}}&{{{-4}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad(3times row1 from row2)\\&\rightarrow\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}}&{{{-3}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{5}}}&{{{1}}}&{{{-4}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad(4times row1 from row3)\\\end{aligned} $$ 

The inverse is still triangular

 $$ \begin{aligned}&\rightarrow\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{\mathbf{0}}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{-3}}}&{{{1}}}&{{{\mathbf{0}}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{\mathbf{11}}}}&{{{-5}}}&{{{\mathbf{1}}}}\end{bmatrix}=\begin{bmatrix}{{{I}}}&{{{\boldsymbol{L}^{-1}}}}\end{bmatrix}.\\ \end{aligned} $$ 

## Recognizing an Invertible Matrix

Normally, it takes work to decide if a matrix is invertible. The usual way is to find a full set of nonzero pivots in elimination. (Then the nonzero determinant comes from multiplying those pivots.) But for some matrices you can see quickly that they are invertible because every number  $ a_{ii} $ on their main diagonal dominates the off-diagonal part of that row i.

Diagonally dominant matrices are invertible. Each  $ a_{ii} $ on the diagonal is larger than the total sum along the rest of row i. On every row,

 $$ |a_{ii}|>\sum_{j\neq i}|a_{ij}|\quad means that\quad|a_{ii}|>|a_{i1}|+\cdots(skip|a_{ii}|)\cdots+|a_{in}|. $$ 

Examples. A is diagonally dominant (3 > 2). B is not (but still invertible). C is singular.

 $$ \boldsymbol{A}=\left[\begin{array}{lll}{{{3}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{3}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{3}}}\end{array}\right]\qquad\boldsymbol{B}=\left[\begin{array}{lll}{{{2}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{3}}}\end{array}\right]\qquad\boldsymbol{C}=\left[\begin{array}{lll}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{3}}}\end{array}\right] $$ 