<div style="text-align: center;"><img src="imgs/img_in_image_box_160_123_863_418.jpg" alt="Image" width="65%" /></div>


<div style="text-align: center;">Figure 2.7: Row and column pictures for Example 2: infinitely many solutions.</div>


Failure For n equations we do not get n pivots

Elimination leads to an equation  $ 0 \neq 0 $ (no solution) or  $ 0 = 0 $ (many solutions)

Success comes with n pivots. But we may have to exchange the n equations.

Elimination can go wrong in a third way—but this time it can be fixed. Suppose the first pivot position contains zero. We refuse to allow zero as a pivot. When the first equation has no term involving x, we can exchange it with an equation below:

Example 3 Temporary failure (zero in pivot). A row exchange produces two pivots:

Permutation

 $$ \begin{aligned}&0x+2y=4\quad&Exchange the\quad&3x-2y=5\\&3x-2y=5\quad&two equations\quad&2y=4.\\ \end{aligned} $$ 

The new system is already triangular. This small example is ready for back substitution. The last equation gives y = 2, and then the first equation gives x = 3. The row picture is normal (two intersecting lines). The column picture is also normal (column vectors not in the same direction). The pivots 3 and 2 are normal—but a row exchange was required.

Examples 1 and 2 are singular—there is no second pivot. Example 3 is nonsingular—there is a full set of pivots and exactly one solution. Singular equations have no solution or infinitely many solutions. Pivots must be nonzero because we have to divide by them.

## Three Equations in Three Unknowns

To understand Gaussian elimination, you have to go beyond 2 by 2 systems. Three by three is enough to see the pattern. For now the matrices are square—an equal number of rows and columns. Here is a 3 by 3 system, specially constructed so that all elimination steps