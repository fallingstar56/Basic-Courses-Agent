#### 2.5. Inverse Matrices

We have reached I in the first half of the matrix, because K is invertible. The three columns of  $ K^{-1} $ are in the second half of  $ [I K^{-1}] $:

(divide by 2)

(divide by  $ \frac{3}{2} $)

(divide by  $ \frac{4}{3} $)

 $$ \begin{aligned}&\begin{bmatrix} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{\frac{3}{4}}}}&{{{\frac{1}{2}}}}&{{{\frac{1}{4}}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{\frac{1}{2}}}}&{{{1}}}&{{{\frac{1}{2}}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{\frac{1}{4}}}}&{{{\frac{1}{2}}}}&{{{\frac{3}{4}}}} \\\end{bmatrix}=\begin{bmatrix}{{{I}}}&{{{x_{1}}}}&{{{x_{2}}}}&{{{x_{3}}}}\end{bmatrix}=\begin{bmatrix}{{{I}}}&{{{K^{-1}}}}\end{bmatrix}.\\ \end{aligned} $$ 

Starting from the 3 by 6 matrix  $ [K\ I] $, we ended with  $ [I\ K^{-1}] $. Here is the whole Gauss-Jordan process on one line for any invertible matrix  $ A $:

Gauss-Jordan

Multiply

 $$ [\begin{array}{r l}{A}&{{}I\end{array}]\quad{b y}\quad A^{-1}\quad{t o~g e t}\quad[\begin{array}{r l}{I}&{{}A^{-1}\end{array}]. $$ 

The elimination steps create the inverse matrix while changing A to I. For large matrices, we probably don't want  $ A^{-1} $ at all. But for small matrices, it can be very worthwhile to know the inverse. We add three observations about  $ K^{-1} $: an important example.

1. K is symmetric across its main diagonal. Then  $ K^{-1} $ is also symmetric.

2. K is tridiagonal (only three nonzero diagonals). But  $ K^{-1} $ is a dense matrix with no zeros. That is another reason we don’t often compute inverse matrices. The inverse of a band matrix is generally a dense matrix.

3. The product of pivots is 2  $ \left(\frac{3}{2}\right)\left(\frac{4}{3}\right)=4 $. This number 4 is the determinant of K.

 $ K^{-1} $ involves division by the determinant of K

 $$ K^{-1}=\frac{1}{4}\begin{bmatrix}{{{3}}}&{{{2}}}&{{{1}}} \\{{{2}}}&{{{4}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{3}}}\end{bmatrix}. $$ 

This is why an invertible matrix cannot have a zero determinant: we need to divide.

Example 4 Find  $ A^{-1} $ by Gauss-Jordan elimination starting from  $ A = \begin{bmatrix} 2 & 3 \\ 4 & 7 \end{bmatrix} $.

 $$ \begin{aligned}\left[\begin{array}{cc}{{{A}}}&{{{I}}} \\\end{array}\right]&=\begin{bmatrix}{{{2}}}&{{{3}}}&{{{1}}}&{{{0}}} \\{{{4}}}&{{{7}}}&{{{0}}}&{{{1}}} \\\end{bmatrix}\rightarrow\begin{bmatrix}{{{2}}}&{{{3}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{-2}}}&{{{1}}} \\\end{bmatrix}&\left(this is\left[\begin{array}{cc}{{{U}}}&{{{L^{-1}}}} \\\end{array}\right]\right)\\&\rightarrow\begin{bmatrix}{{{2}}}&{{{0}}}&{{{7}}}&{{{-3}}} \\{{{0}}}&{{{1}}}&{{{-2}}}&{{{1}}} \\\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{0}}}&{{{\frac{7}{2}}}}&{{{-\frac{3}{2}}}} \\{{{0}}}&{{{1}}}&{{{-2}}}&{{{1}}} \\\end{bmatrix}&\left(this is\left[\begin{array}{cc}{{{I}}}&{{{A^{-1}}}} \\\end{array}\right]\right).\end{aligned} $$ 

Example 5 If A is invertible and upper triangular, so is A^{-1}. Start with AA^{-1} = I.

1 A times column j of  $ A^{-1} $ equals column j of I, ending with n - j zeros.

2 Back substitution keeps those n - j zeros at the end of column j of  $ A^{-1} $

3 Put those columns  $ [* \ldots * 0 \ldots 0]^{T} $ into  $ A^{-1} $ and that matrix is upper triangular!