12 Reduce this system to upper triangular form by two row operations:

 $$ \begin{aligned}2x+3y&+z=8\\4x+7y+5z&=20\\-2y+2z&=0.\end{aligned} $$ 

Circle the pivots. Solve by back substitution for z, y, x.

 $$ \begin{aligned}&2x-3y&=3\\&4x-5y+z&=7\\&2x-y-3z&=5.\\ \end{aligned} $$ 

Apply elimination (circle the pivots) and back substitution to solve

Which number $d$ forces a row exchange, and what is the triangular system (not singular) for that $d$? Which $d$ makes this system singular (no third pivot)?

List the three row operations: Subtract ___ times row ___ from row ___.

 $$ \begin{aligned}2x+5y+z&=0\\4x+dy+z&=2\\y-z&=3.\end{aligned} $$ 

Which number $b$ leads later to a row exchange? Which $b$ leads to a missing pivot? In that singular case find a nonzero solution $x, y, z$.

 $$ x+by\quad=0 $$ 

 $$ x-2y-z=0 $$ 

 $$ y+z=0. $$ 

(a) Construct a 3 by 3 system that needs two row exchanges to reach a triangular form and a solution.

(b) Construct a 3 by 3 system that needs a row exchange to keep going, but breaks down later.

If rows 1 and 2 are the same, how far can you get with elimination (allowing row exchange)? If columns 1 and 2 are the same, which pivot is missing?

Equal  $ 2x - y + z = 0 $  $ 2x + 2y + z = 0 $ Equal rows  $ 2x - y + z = 0 $  $ 4x + 4y + z = 0 $ columns  $ 4x + y + z = 2 $  $ 6x + 6y + z = 2. $

Construct a 3 by 3 example that has 9 different coefficients on the left side, but rows 2 and 3 become zero in elimination. How many solutions to your system with  $ \boldsymbol{b} = (1, 10, 100) $ and how many with  $ \boldsymbol{b} = (0, 0, 0) $?