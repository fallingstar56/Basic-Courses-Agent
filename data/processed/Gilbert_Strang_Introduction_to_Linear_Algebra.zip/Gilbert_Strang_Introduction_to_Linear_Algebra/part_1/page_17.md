### 2.3 Elimination Using Matrices

(1) The first step multiplies the equations  $ Ax = b $ by a matrix  $ E_{21} $ to produce  $ E_{21}Ax = E_{21}b $.

2) That matrix  $ E_{21}A $ has a zero in row 2, column 1 because  $ x_1 $ is eliminated from equation 2.

3)  $ E_{21} $ is the identity matrix (diagonal of 1's) minus the multiplier  $ a_{21}/a_{11} $ in row 2, column 1.

4) Matrix-matrix multiplication is  $ n $ matrix-vector multiplications:  $ EA = [Ea_1 \ldots Ea_n] $.

5) We must also multiply  $ Eb! $ So  $ E $ is multiplying the augmented matrix  $ [Ab] = [a_1 \ldots a_n b] $.

6) Elimination multiplies  $ Ax = b $ by  $ E_{21}, E_{31}, \ldots, E_{n1} $, then  $ E_{32}, E_{42}, \ldots, E_{n2} $, and onward.

7) The row exchange matrix is not  $ E_{ij} $ but  $ P_{ij} $. To find  $ P_{ij} $, exchange rows  $ i $ and  $ j $ of  $ I $.

This section gives our first examples of matrix multiplication. Naturally we start with matrices that contain many zeros. Our goal is to see that matrices do something. E acts on a vector b or a matrix A to produce a new vector Eb or a new matrix EA.

Our first examples will be “elimination matrices.” They execute the elimination steps. Multiply the  $ j^{th} $ equation by  $ \ell_{ij} $ and subtract from the  $ i^{th} $ equation. (This eliminates  $ x_{j} $ from equation i.) We need a lot of these simple matrices  $ E_{ij} $, one for every nonzero to be eliminated below the main diagonal.

Fortunately we won’t see all these matrices  $ E_{ij} $ in later chapters. They are good examples to start with, but there are too many. They can combine into one overall matrix E that takes all steps at once. The nearest way is to combine all their inverses  $ (E_{ij})^{-1} $ into one overall matrix  $ L = E^{-1} $. Here is the purpose of the next pages.

1. To see how each step is a matrix multiplication.

2. To assemble all those steps  $ E_{ij} $ into one elimination matrix E.

3. To see how each  $ E_{ij} $ is inverted by its inverse matrix  $ E_{ij}^{-1} $

4. To assemble all those inverses  $ E_{ij}^{-1} $ (in the right order) into L.

The special property of $L$ is that all the multipliers $\ell_{ij}$ fall into place. Those numbers are mixed up in $E$ (forward elimination from $A$ to $U$). They are perfect in $L$ (undoing elimination, returning from $U$ to $A$). Inverting puts the steps and their matrices $E_{ij}^{-1}$ in the opposite order and that prevents the mixup.

This section finds the matrices  $ E_{ij} $. Section 2.4 presents four ways to multiply matrices. Section 2.5 inverts every step. (For elimination matrices we can already see  $ E_{ij}^{-1} $ here.) Then those inverses go into L.