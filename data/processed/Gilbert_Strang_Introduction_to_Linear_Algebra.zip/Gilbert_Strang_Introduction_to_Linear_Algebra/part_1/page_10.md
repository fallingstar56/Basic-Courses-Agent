Elimination from A to U

For a 4 by 4 problem, or an n by n problem, elimination proceeds in the same way. Here is the whole idea, column by column from A to U, when Gaussian elimination succeeds.

Column 1. Use the first equation to create zeros below the first pivot.

Column 2. Use the new equation 2 to create zeros below the second pivot.

Columns 3 to n. Keep going to find all n pivots and the upper triangular U.

After column 2 we have

 $$ \left[\begin{array}{c c c c}{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}} \\{{{0}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}} \\{{{0}}}&{{{0}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}} \\{{{0}}}&{{{0}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}}\end{array}\right]\quad.\quad\mathrm{W e~w a n t}\quad\left[\begin{array}{c c c c}{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}} \\{{{x}}}&{{{\boldsymbol{x}}}}&{{{\boldsymbol{x}}}} \\{{{x}}}&{{{\boldsymbol{x}}}} \\{{{x}}}\end{array}\right], $$ 

The result of forward elimination is an upper triangular system. It is nonsingular if there is a full set of $n$ pivots (never zero!). Question: Which $x$ on the left won't be changed in elimination because the pivot is known? Here is a final example to show the original $Ax = b$, the triangular system $Ux = c$, and the solution $(x, y, z)$ from back substitution:

 $$ \begin{array}{ccc}x+y+z=6&x+y+z=6& \left[\begin{array}{c}x\\ y\end{array}\right]=\left[\begin{array}{c}3\\ 2\\ 1\end{array}\right]\quad\text{Back} \\ x+2y+2z=9\quad\text{Forward}\quad&y+z=3& \\ x+2y+3z=10\quad\text{Forward}\quad&z=1& \end{array} $$ 

All multipliers are 1. All pivots are 1. All planes meet at the solution  $ (3, 2, 1) $. The columns of A combine with 3, 2, 1 to give  $ \boldsymbol{b} = (6, 9, 10) $. The triangle shows  $ U\boldsymbol{x} = \boldsymbol{c} = (6, 3, 1) $.

## ■ REVIEW OF THE KEY IDEAS

1. A linear system  $ (Ax = b) $ becomes upper triangular  $ (Ux = c) $ after elimination.

2. We subtract  $ \ell_{ij} $ times equation j from equation i, to make the  $ (i,j) $ entry zero.

3. The multiplier is  $ \ell_{ij} = \frac{\text{entry to eliminate in row } i}{\text{pivot in row } j} $. Pivots can not be zero!

4. When zero is in the pivot position, exchange rows if there is a nonzero below it.

5. The upper triangular  $ Ux = c $ is solved by back substitution (starting at the bottom).

6. When breakdown is permanent, Ax = b has no solution or infinitely many.