<div style="text-align: center;"><img src="imgs/img_in_image_box_185_118_872_380.jpg" alt="Image" width="64%" /></div>


<div style="text-align: center;">Figure 2.6: Row picture and column picture for Example 1: no solution.</div>


Example 1 Permanent failure with no solution. Elimination makes this clear:

 $$ \begin{aligned}&x-2y=1\quad&Subtract3times\quad&x-2y=1\\&3x-6y=11\quad&eqn.1from eqn.2\quad&0y=8.\\ \end{aligned} $$ 

There is no solution to 0y = 8. Normally we divide the right side 8 by the second pivot, but this system has no second pivot. (Zero is never allowed as a pivot!) The row and column pictures in Figure 2.6 show why failure was unavoidable. If there is no solution, elimination will discover that fact by reaching an equation like 0y = 8.

The row picture of failure shows parallel lines—which never meet. A solution must lie on both lines. With no meeting point, the equations have no solution.

The column picture shows the two columns  $ (1,3) $ and  $ (-2,-6) $ in the same direction. All combinations of the columns lie along a line. But the column from the right side is in a different direction  $ (1,11) $. No combination of the columns can produce this right side—therefore no solution.

When we change the right side to  $ (1, 3) $, failure shows as a whole line of solution points. Instead of no solution, next comes Example 2 with infinitely many.

Example 2 Failure with infinitely many solutions. Change  $ b = (1, 11) $ to  $ (1, 3) $.

 $$ \begin{array}{ccc}x-2y=1&\text{Subtract 3 times}&\quad x-2y=1\quad\text{Still only}\\3x-6y=3&\text{eqn.1 from eqn.2}&\quad0y=0.\quad\text{one pivot}.\end{array} $$ 

Every y satisfies 0y = 0. There is really only one equation x - 2y = 1. The unknown y is “free”. After y is freely chosen, x is determined as x = 1 + 2y.

In the row picture, the parallel lines have become the same line. Every point on that line satisfies both equations. We have a whole line of solutions in Figure 2.7.

In the column picture,  $ \boldsymbol{b} = (1, 3) $ is now the same as column 1. So we can choose  $ x = 1 $ and  $ y = 0 $. We can also choose  $ x = 0 $ and  $ y = -\frac{1}{2} $; column 2 times  $ -\frac{1}{2} $ equals  $ \boldsymbol{b} $. Every  $ (x, y) $ that solves the row problem also solves the column problem.