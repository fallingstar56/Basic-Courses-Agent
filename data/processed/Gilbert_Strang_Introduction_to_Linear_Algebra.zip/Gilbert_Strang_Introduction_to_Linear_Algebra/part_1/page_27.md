Multiply these row exchange matrices in the orders PQ and QP and  $ P^{2} $:

 $$ \boldsymbol{P}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{Q}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Find another non-diagonal matrix whose square is  $ M^{2}=I $.

(a) Suppose all columns of B are the same. Then all columns of EB are the same, because each one is E times ___.

(b) Suppose all rows of B are  $ [1\quad2\quad4] $. Show by example that all rows of EB are not  $ [1\quad2\quad4] $. It is true that those rows are ___.

If $E$ adds row 1 to row 2 and $F$ adds row 2 to row 1, does $EF$ equal $FE$?

The entries of $A$ and $x$ are $a_{ij}$ and $x_{j}$. So the first component of $Ax$ is $\sum a_{1j}x_{j} = a_{11}x_{1} + \cdots + a_{1n}x_{n}$. If $E_{21}$ subtracts row 1 from row 2, write a formula for

(a) the third component of Ax

(b) the  $ (2,1) $ entry of  $ E_{21}A $

(c) the  $ (2,1) $ entry of  $ E_{21}(E_{21}A) $

(d) the first component of  $ E_{21}Ax $.

23 The elimination matrix  $ E = \begin{bmatrix} 1 & 0 \\ -2 & 1 \end{bmatrix} $ subtracts 2 times row 1 of A from row 2 of A. The result is EA. What is the effect of  $ E(EA) $? In the opposite order AE, we are subtracting 2 times ___ of A from ___. (Do examples.)

Problems 24–27 include the column b in the augmented matrix [A b].

24 Apply elimination to the 2 by 3 augmented matrix  $ [A\ b] $. What is the triangular system  $ Ux = c $? What is the solution  $ x $?

 $$ A\boldsymbol{x}=\begin{bmatrix}{{{2}}}&{{{3}}} \\{{{4}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{17}}}\end{bmatrix}. $$ 

Apply elimination to the 3 by 4 augmented matrix [A b]. How do you know this system has no solution? Change the last number 6 so there is a solution.

 $$ \boldsymbol{A}\boldsymbol{x}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{3}}}&{{{4}}} \\{{{3}}}&{{{5}}}&{{{7}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{2}}} \\{{{6}}}\end{bmatrix}. $$ 

The equations  $ Ax = b $ and  $ Ax^* = b^* $ have the same matrix  $ A $. What double augmented matrix should you use in elimination to solve both equations at once?

Solve both of these equations by working on a 2 by 4 matrix :

 $$ \begin{bmatrix}{{{1}}}&{{{4}}} \\{{{2}}}&{{{7}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{0}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{1}}}&{{{4}}} \\{{{2}}}&{{{7}}}\end{bmatrix}\begin{bmatrix}{{{u}}} \\{{{v}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{1}}}\end{bmatrix}. $$ 