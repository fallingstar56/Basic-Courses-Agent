### Problem Set 2.3

## Problems 1–15 are about elimination matrices

1 Write down the 3 by 3 matrices that produce these elimination steps:

(a)  $ E_{21} $ subtracts 5 times row 1 from row 2.

(b)  $ E_{32} $ subtracts -7 times row 2 from row 3.

(c) P exchanges rows 1 and 2, then rows 2 and 3.

2 In Problem 1, applying  $ E_{21} $ and then  $ E_{32} $ to  $ \boldsymbol{b} = (1, 0, 0) $ gives  $ E_{32}E_{21}\boldsymbol{b} = \_\_\_ $. Applying  $ E_{32} $ before  $ E_{21} $ gives  $ E_{21}E_{32}\boldsymbol{b} = \_\_\_ $. When  $ E_{32} $ comes first, row \_\_\_ $ feels no effect from row \_\_\_ $.

3 Which three matrices  $ E_{21}, E_{31}, E_{32} $ put A into triangular form U?

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{4}}}&{{{6}}}&{{{1}}} \\{{{-2}}}&{{{2}}}&{{{0}}}\end{bmatrix}\quad and\quad E_{32}E_{31}E_{21}\boldsymbol{A}=\boldsymbol{U}. $$ 

Multiply those E's to get one matrix M that does elimination: MA = U.

4 Include  $ b = (1, 0, 0) $ as a fourth column in Problem 3 to produce  $ [A\ b] $. Carry out the elimination steps on this augmented matrix to solve Ax = b.

5 Suppose  $ a_{33} = 7 $ and the third pivot is 5. If you change  $ a_{33} $ to 11, the third pivot is ___. If you change  $ a_{33} $ to ___, there is no third pivot.

6 If every column of A is a multiple of  $ (1,1,1) $, then Ax is always a multiple of  $ (1,1,1) $. Do a 3 by 3 example. How many pivots are produced by elimination?

7 Suppose E subtracts 7 times row 1 from row 3.

(a) To invert that step you should ___ 7 times row ___ to row ___.

(b) What “inverse matrix”  $ E^{-1} $ takes that reverse step (so  $ E^{-1}E = I $?)

(c) If the reverse step is applied first (and then E) show that  $ EE^{-1} = I $.

The determinant of  $ M = \begin{bmatrix} a & b \\ c & d \end{bmatrix} $ is det  $ M = ad - bc $. Subtract  $ \ell $ times row 1 from row 2 to produce a new  $ M^* $. Show that det  $ M^* = \det M $ for every  $ \ell $. When  $ \ell = c/a $, the product of pivots equals the determinant:  $ (a)(d - \ell b) $ equals ad - bc.

9 (a)  $ E_{21} $ subtracts row 1 from row 2 and then  $ P_{23} $ exchanges rows 2 and 3. What matrix  $ M = P_{23}E_{21} $ does both steps at once?

(b)  $ P_{23} $ exchanges rows 2 and 3 and then  $ E_{31} $ subtracts row 1 from row 3. What matrix  $ M = E_{31}P_{23} $ does both steps at once? Explain why the  $ M $'s are the same but the  $ E $'s are different.