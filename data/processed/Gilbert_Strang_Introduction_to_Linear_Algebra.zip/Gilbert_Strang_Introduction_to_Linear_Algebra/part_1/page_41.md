(Very important) Suppose you solve Ax = b for three special right sides b:

 $$ \boldsymbol{A}\boldsymbol{x}_{1}=\begin{bmatrix}1\\ 0\\ 0\end{bmatrix}\quad and\quad\boldsymbol{A}\boldsymbol{x}_{2}=\begin{bmatrix}0\\ 1\\ 0\end{bmatrix}\quad and\quad\boldsymbol{A}\boldsymbol{x}_{3}=\begin{bmatrix}0\\ 0\\ 1\end{bmatrix}. $$ 

If the three solutions  $ x_1 $,  $ x_2 $,  $ x_3 $ are the columns of a matrix  $ X $, what is  $ A $ times  $ X $?

If the three solutions in Question 32 are  $ x_1 = (1, 1, 1) $ and  $ x_2 = (0, 1, 1) $ and  $ x_3 = (0, 0, 1) $, solve  $ Ax = b $ when  $ b = (3, 5, 8) $. Challenge problem: What is  $ A $?

Find all matrices  $ A = \begin{bmatrix} a & b \\ c & d \end{bmatrix} $ that satisfy  $ A\begin{bmatrix} 1 & 1 \\ 1 & 1 \end{bmatrix} = \begin{bmatrix} 1 & 1 \\ 1 & 1 \end{bmatrix}A $.

Suppose a “circle graph” has 4 nodes connected (in both directions) by edges around a circle. What is its adjacency matrix $S$ from Worked Example 2.4 $\mathbf{A}$? What is $S^{2}$? Find all the 2-step paths predicted by $S^{2}$.

## Challenge Problems

Practical question Suppose A is m by n, B is n by p, and C is p by q. Then the multiplication count is  $ mnp $ for  $ AB + mpq $ for  $ (AB)C $. The same matrix comes from A times BC with  $ mnq + npq $ separate multiplications. Notice npq for BC.

(a) If A is 2 by 4, B is 4 by 7, and C is 7 by 10, do you prefer (AB) C or A (BC)?

(b) With N-component vectors, would you choose  $ (u^{\mathrm{T}}v)w^{\mathrm{T}} $ or  $ u^{\mathrm{T}}(vw^{\mathrm{T}}) $?

(c) Divide by mnpq to show that (AB) C is faster when  $ n^{-1} + q^{-1} < m^{-1} + p^{-1} $.

To prove that  $ (AB)C = A(BC) $, use the column vectors  $ b_1, \ldots, b_n $ of  $ B $. First suppose that  $ C $ has only one column  $ c $ with entries  $ c_1, \ldots, c_n $:

AB has columns  $ Ab_{1}, \ldots, Ab_{n} $ and then  $ (AB)c $ equals  $ c_{1}Ab_{1} + \cdots + c_{n}Ab_{n} $.

 $ Bc $ has one column  $ c_{1}b_{1}+\cdots+c_{n}b_{n} $ and then  $ A(Bc) $ equals  $ A(c_{1}b_{1}+\cdots+c_{n}b_{n}) $.

Linearity gives equality of those two sums. This proves  $ (AB)c = A(Bc) $. The same is true for all other ___ of C. Therefore  $ (AB)C = A(BC) $. Apply to inverses:

If BA = I and AC = I, prove that the left-inverse B equals the right-inverse C.

(a) Suppose A has rows  $ a_{1}^{\mathrm{T}}, \ldots, a_{m}^{\mathrm{T}} $. Why does  $ A^{\mathrm{T}} A $ equal  $ a_{1} a_{1}^{\mathrm{T}} + \cdots + a_{m} a_{m}^{\mathrm{T}} $?

(b) If $C$ is a diagonal matrix with $c_1, \ldots, c_m$ on its diagonal, find a similar sum of columns times rows for $A^\mathrm{T}CA$. First do an example with $m = n = 2$.