 $ (S^2)_{ij} $ is adding up 1's for all the 2-step paths  $ i \to k \to j $. So it counts those paths. In the same way  $ S^{N-1}S $ will count N-step paths, because those are  $ (N-1) $-step paths from  $ i $ to  $ k $ followed by one step from  $ k $ to  $ j $. Matrix multiplication is exactly suited to counting paths on a graph—channels of communication between employees in a company.

2.4 B For these matrices, when does AB = BA? When does BC = CB? When does A times BC equal AB times C? Give the conditions on their entries p, q, r, z:

 $$ A=\begin{bmatrix}{{{p}}}&{{{0}}} \\{{{q}}}&{{{r}}}\end{bmatrix}\qquad B=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\qquad C=\begin{bmatrix}{{{0}}}&{{{z}}} \\{{{0}}}&{{{0}}}\end{bmatrix} $$ 

If p, q, r, 1, z are 4 by 4 blocks instead of numbers, do the answers change?

Solution First of all, A times BC always equals AB times C. Parentheses are not needed in  $ A(BC) = (AB)C = ABC $. But we must keep the matrices in this order:

Usually

 $$ \boldsymbol{A}\boldsymbol{B}\neq\boldsymbol{B}\boldsymbol{A}\qquad\boldsymbol{A}\boldsymbol{B}=\begin{bmatrix}{{{p}}}&{{{p}}} \\{{{q}}}&{{{q+r}}}\end{bmatrix}\qquad\quad\boldsymbol{B}\boldsymbol{A}=\begin{bmatrix}{{{p+q}}}&{{{r}}} \\{{{q}}}&{{{r}}}\end{bmatrix}. $$ 

By chance BC = CB

 $$ \boldsymbol{B}\boldsymbol{C}=\begin{bmatrix}{{{0}}}&{{{z}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\qquad\boldsymbol{C}\boldsymbol{B}=\begin{bmatrix}{{{0}}}&{{{z}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

B and C happen to commute. Part of the explanation is that the diagonal of B is I, which commutes with all 2 by 2 matrices. When p, q, r, z are 4 by 4 blocks and 1 changes to I, all these products remain correct. So the answers are the same.

### Problem Set 2.4

## Problems 1–16 are about the laws of matrix multiplication

1 A is 3 by 5, B is 5 by 3, C is 5 by 1, and D is 3 by 1. All entries are 1. Which of these matrix operations are allowed, and what are the results?

BA AB ABD DC A(B+C).

2 What rows or columns or matrices do you multiply to find

(a) the second column of AB?

(b) the first row of AB?

(c) the entry in row 3, column 5 of AB?

(d) the entry in row 1, column 1 of CDE?

3 Add AB to AC and compare with  $ A(B + C) $:

 $$ A=\begin{bmatrix}{{{1}}}&{{{5}}} \\{{{2}}}&{{{3}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{0}}}&{{{2}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad C=\begin{bmatrix}{{{3}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

4 In Problem 3, multiply A times BC. Then multiply AB times C.