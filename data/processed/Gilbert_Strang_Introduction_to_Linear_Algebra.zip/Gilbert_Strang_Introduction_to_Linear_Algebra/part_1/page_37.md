Compute  $ A^{2} $ and  $ A^{3} $. Make a prediction for  $ A^{5} $ and  $ A^{n} $:

 $$ A=\begin{bmatrix}{{{1}}}&{{{b}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{2}}}&{{{2}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Show that  $ (A + B)^{2} $ is different from  $ A^{2} + 2AB + B^{2} $, when

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{3}}}&{{{0}}}\end{bmatrix}. $$ 

Write down the correct rule for  $ (A + B)(A + B) = A^2 + \_\_\_\_ + B^2 $.

True or false. Give a specific example when false:

(a) If columns 1 and 3 of B are the same, so are columns 1 and 3 of AB.

(b) If rows 1 and 3 of B are the same, so are rows 1 and 3 of AB.

(c) If rows 1 and 3 of A are the same, so are rows 1 and 3 of ABC.

(d)  $ (AB)^{2}=A^{2}B^{2} $

8 How is each row of DA and EA related to the rows of A, when

 $$ D=\begin{bmatrix}{{{3}}}&{{{0}}} \\{{{0}}}&{{{5}}}\end{bmatrix}\quad and\quad E=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}？ $$ 

How is each column of AD and AE related to the columns of A?

Row 1 of A is added to row 2. This gives EA below. Then column 1 of EA is added to column 2 to produce  $ (EA)F $:

 $$ E A=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{a+c}}}&{{{b+d}}}\end{bmatrix} $$ 

 $$  and\quad(EA)F=(EA)\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{a}}}&{{{a+b}}} \\{{{a+c}}}&{{{a+c+b+d}}}\end{bmatrix}. $$ 

(a) Do those steps in the opposite order. First add column 1 of A to column 2 by AF, then add row 1 of AF to row 2 by  $ E(AF) $.

(b) Compare with  $ (EA)F $. What law is obeyed by matrix multiplication?

Row 1 of A is again added to row 2 to produce EA. Then F adds row 2 of EA to row 1. The result is  $ F(EA) $:

 $$ F(EA)=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{a+c}}}&{{{b+d}}}\end{bmatrix}=\begin{bmatrix}{{{2a+c}}}&{{{2b+d}}} \\{{{a+c}}}&{{{b+d}}}\end{bmatrix}. $$ 

(a) Do those steps in the opposite order: first add row 2 to row 1 by FA, then add row 1 of FA to row 2.

(b) What law is or is not obeyed by matrix multiplication?