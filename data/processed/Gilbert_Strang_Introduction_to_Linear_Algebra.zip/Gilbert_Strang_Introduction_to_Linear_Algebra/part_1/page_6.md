Ask yourself how that multiplier  $ \ell = 3 $ was found. The first equation contains 1x. So the first pivot was 1 (the coefficient of x). The second equation contains 3x, so the multiplier was 3. Then subtraction 3x - 3x produced the zero and the triangle.

You will see the multiplier rule if I change the first equation to  $ 4x - 8y = 4 $. (Same straight line but the first pivot becomes 4.) The correct multiplier is now  $ \ell = \frac{3}{4} $. To find the multiplier, divide the coefficient “3” to be eliminated by the pivot “4”:

 $$ \begin{array}{l}4x-8y=4\\3x+2y=11\\\end{array}\quad\begin{array}{l}Multiply equation 1 by\frac{3}{4}\quad\begin{array}{l}4x-8y=4\\8y=8.\end{array}\\\text{Subtract from equation 2} $$ 

The final system is triangular and the last equation still gives $y = 1$. Back substitution produces $4x - 8 = 4$ and $4x = 12$ and $x = 3$. We changed the numbers but not the lines or the solution. Divide by the pivot to find that multiplier $\ell = \frac{3}{4}$:

 $$ \begin{array}{r c l}{{P i v o t}}&{{=}}&{{f i r s t~n o n z e r o~i n~t h e~r o w~t h a t~d o e s~t h e~e l i m i n a t i o n}}\\ {{M u l t i p l i e r}}&{{=}}&{{(e n t r y~t o~e l i m i n a t e)~d i v i d e d~b y~(p i v o t)~=\frac{3}{4}.}}\end{array} $$ 

The new second equation starts with the second pivot, which is 8. We would use it to eliminate y from the third equation if there were one. To solve n equations we want n pivots. The pivots are on the diagonal of the triangle after elimination.

You could have solved those equations for x and y without reading this book. It is an extremely humble problem, but we stay with it a little longer. Even for a 2 by 2 system, elimination might break down. By understanding the possible breakdown (when we can't find a full set of pivots), you will understand the whole process of elimination.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_153_724_482_918.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_520_723_853_917.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">Figure 2.5: Eliminating x makes the second line horizontal. Then 8y = 8 gives y = 1.</div>


## Breakdown of Elimination

Normally, elimination produces the pivots that take us to the solution. But failure is possible. At some point, the method might ask us to divide by zero. We can't do it. The process has to stop. There might be a way to adjust and continue—or failure may be unavoidable.

Example 1 fails with no solution to 0y = 8. Example 2 fails with too many solutions to 0y = 0. Example 3 succeeds by exchanging the equations.