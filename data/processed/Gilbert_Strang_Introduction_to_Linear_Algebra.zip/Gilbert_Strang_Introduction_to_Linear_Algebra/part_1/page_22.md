Matrices act. They don't just sit there. We will soon meet other permutation matrices, which can change the order of several rows. Rows 1, 2, 3 can be moved to 3, 1, 2. Our  $ P_{23} $ is one particular permutation matrix—it exchanges rows 2 and 3.

Row Exchange Matrix  $ P_{ij} $ is the identity matrix with rows i and j reversed. When this “permutation matrix”  $ P_{ij} $ multiplies a matrix, it exchanges rows i and j.

To exchange equations 1 and 3 multiply by

 $$ P_{13}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Usually row exchanges are not required. The odds are good that elimination uses only the  $ E_{ij} $. But the  $ P_{ij} $ are ready if needed, to move a pivot up to the diagonal.

The Augmented Matrix

This book eventually goes far beyond elimination. Matrices have all kinds of practical applications, in which they are multiplied. Our best starting point was a square E times a square A, because we met this in elimination—and we know what answer to expect for EA. The next step is to allow a rectangular matrix. It still comes from our original equations, but now it includes the right side b.

Key idea: Elimination does the same row operations to A and to b. We can include b as an extra column and follow it through elimination. The matrix A is enlarged or “augmented” by the extra column b:

Augmented matrix

 $$ \begin{align*}\begin{bmatrix}A&b\end{bmatrix}=\begin{bmatrix}2&4&-2&2\\ 4&9&-3&8\\ -2&-3&7&10\end{bmatrix}.\end{align*} $$ 

Elimination acts on whole rows of this matrix. The left side and right side are both multiplied by E, to subtract 2 times equation 1 from equation 2. With  $ [A\ b] $ those steps happen together:

 $$ \begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{4}}}&{{{-2}}}&{{{\mathbf{2}}}} \\{{{4}}}&{{{9}}}&{{{-3}}}&{{{8}}} \\{{{-2}}}&{{{-3}}}&{{{7}}}&{{{\mathbf{10}}}}\end{bmatrix}=\begin{bmatrix}{{{2}}}&{{{4}}}&{{{-2}}}&{{{\mathbf{2}}}} \\{{{0}}}&{{{1}}}&{{{1}}}&{{{4}}} \\{{{-2}}}&{{{-3}}}&{{{7}}}&{{{\mathbf{10}}}}\end{bmatrix}. $$ 

The new second row contains 0, 1, 1, 4. The new second equation is  $ x_{2} + x_{3} = 4 $. Matrix multiplication works by rows and at the same time by columns:

ROWS Each row of E acts on [A b] to give a row of [EA Eb].

COLUMNS E acts on each column of [A b] to give a column of [EA Eb].