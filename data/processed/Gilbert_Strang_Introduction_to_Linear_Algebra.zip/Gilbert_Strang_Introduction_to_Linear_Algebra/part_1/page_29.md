### 2.4 Rules for Matrix Operations

1 Matrices A with n columns multiply matrices B with n rows:  $ A_{m \times n} B_{n \times p} = C_{m \times p} $.

2 Each entry in AB = C is a dot product:  $ C_{ij} = (\text{row } i \text{ of } A) \cdot (\text{column } j \text{ of } B) $.

3 This rule is chosen so that AB times C equals A times BC. And  $ (AB)x = A(Bx) $.

4 More ways to compute AB: (A times columns of B) (rows of A times B) (columns times rows).

5 It is not usually true that AB = BA. In most cases A doesn't commute with B.

6 Matrices can be multiplied by blocks:  $ A = [A_1 \ A_2] $ times  $ B = \left[\begin{array}{c} B_1 \\ B_2 \end{array}\right] $ is  $ A_1 B_1 + A_2 B_2 $.

I will start with basic facts. A matrix is a rectangular array of numbers or “entries”. When A has m rows and n columns, it is an “m by n” matrix. Matrices can be added if their shapes are the same. They can be multiplied by any constant c. Here are examples of  $ A + B $ and 2A, for 3 by 2 matrices:

 $$ \begin{bmatrix}{{{1}}}&{{{2}}} \\{{{3}}}&{{{4}}} \\{{{0}}}&{{{0}}}\end{bmatrix}+\begin{bmatrix}{{{2}}}&{{{2}}} \\{{{4}}}&{{{4}}} \\{{{9}}}&{{{9}}}\end{bmatrix}=\begin{bmatrix}{{{3}}}&{{{4}}} \\{{{7}}}&{{{8}}} \\{{{9}}}&{{{9}}}\end{bmatrix}\quad and\quad2\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{3}}}&{{{4}}} \\{{{0}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{2}}}&{{{4}}} \\{{{6}}}&{{{8}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Matrices are added exactly as vectors are—one entry at a time. We could even regard a column vector as a matrix with only one column (so n = 1). The matrix -A comes from multiplication by c = -1 (reversing all the signs). Adding A to -A leaves the zero matrix, with all entries zero. All this is only common sense.

The entry in row $i$ and column $j$ is called $a_{ij}$ or $A(i,j)$. The $n$ entries along the first row are $a_{11}, a_{12}, \ldots, a_{1n}$. The lower left entry in the matrix is $a_{m1}$ and the lower right is $a_{mn}$. The row number $i$ goes from 1 to $m$. The column number $j$ goes from 1 to $n$.

Matrix addition is easy. The serious question is matrix multiplication. When can we multiply A times B, and what is the product AB? This section gives 4 ways to find AB. But we cannot multiply when A and B are 3 by 2. They don't pass the following test:

To multiply AB: If A has n columns, B must have n rows.

When A is 3 by 2, the matrix B can be 2 by 1 (a vector) or 2 by 2 (square) or 2 by 20. Every column of B is multiplied by A. I will begin matrix multiplication the dot product way, and return to this column way: A times columns of B. Both ways follow this rule:

Fundamental Law of Matrix Multiplication AB times C equals A times BC

The parentheses can move safely in  $ (AB)C = A(BC) $. Linear algebra depends on this law.