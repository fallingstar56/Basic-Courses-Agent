Suppose you know the average  $ \widehat{x}_{\text{old}} $ of  $ b_1, b_2, \ldots, b_{999} $. When  $ b_{1000} $ arrives, check that the new average is a combination of  $ \widehat{x}_{\text{old}} $ and the mismatch  $ b_{1000} - \widehat{x}_{\text{old}} $:

 $$ \widehat{\boldsymbol{x}}_{\mathrm{new}}=\frac{b_{1}+\cdots+b_{1000}}{1000}=\frac{b_{1}+\cdots+b_{999}}{999}+\frac{1}{1000}\left(b_{1000}-\frac{b_{1}+\cdots+b_{999}}{999}\right) $$ 

This is a “Kalman filter”  $ \widehat{x}_{\text{new}} = \widehat{x}_{\text{old}} + \frac{1}{1000} (b_{1000} - \widehat{x}_{\text{old}}) $ with gain matrix  $ \frac{1}{1000} $. The last page of the book extends the Kalman filter to matrix updates.

(2017) Suppose $P_1$ and $P_2$ are projection matrices $(P_i^2 = P_i = P_i^\mathrm{T})$. Prove this fact: $P_1 P_2$ is a projection matrix if and only if $P_1 P_2 = P_2 P_1$.