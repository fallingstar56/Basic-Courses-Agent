8 In Figure 4.3, how do we know that  $ Ax_r $ is equal to  $ Ax $? How do we know that this vector is in the column space? If  $ A = \begin{bmatrix} 1 & 1 \\ 1 & 1 \end{bmatrix} $ and  $ x = \begin{bmatrix} 1 \\ 0 \end{bmatrix} $ what is  $ x_r $?

9 If  $ A^{\mathrm{T}}Ax = 0 $ then Ax = 0. Reason: Ax is in the nullspace of  $ A^{\mathrm{T}} $ and also in the ___ of A and those spaces are ___. Conclusion:  $ A^{\mathrm{T}}A $ has the same nullspace as A. This key fact is repeated in the next section.

10 Suppose A is a symmetric matrix  $ (A^{\mathrm{T}} = A) $.

(a) Why is its column space perpendicular to its nullspace?

(b) If Ax = 0 and Az = 5z, which subspaces contain these “eigenvectors” x and z? Symmetric matrices have perpendicular eigenvectors  $ x^{T}z = 0 $.

11 (Recommended) Draw Figure 4.2 to show each subspace correctly for

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{3}}}&{{{6}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{3}}}&{{{0}}}\end{bmatrix}. $$ 

12 Find the pieces  $ x_{r} $ and  $ x_{n} $ and draw Figure 4.3 properly if

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{-1}}} \\{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{x}=\begin{bmatrix}{{{2}}} \\{{{0}}}\end{bmatrix}. $$ 

## Questions 13–23 are about orthogonal subspaces

13 Put bases for the subspaces V and W into the columns of matrices V and W. Explain why the test for orthogonal subspaces can be written  $ V^{\mathrm{T}}W = \text{zero matrix} $. This matches  $ v^{\mathrm{T}}w = 0 $ for orthogonal vectors.

14 The floor V and the wall W are not orthogonal subspaces, because they share a nonzero vector (along the line where they meet). No planes V and W in  $ R^{3} $ can be orthogonal! Find a vector in the column spaces of both matrices:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{1}}}&{{{3}}} \\{{{1}}}&{{{2}}}\end{bmatrix}\qquad and\qquad\boldsymbol{B}=\begin{bmatrix}{{{5}}}&{{{4}}} \\{{{6}}}&{{{3}}} \\{{{5}}}&{{{1}}}\end{bmatrix} $$ 

This will be a vector Ax and also B̂x. Think 3 by 4 with the matrix [A B].

Extend Problem 14 to a p-dimensional subspace V and a q-dimensional subspace W of  $ \mathbf{R}^n $. What inequality on  $ p + q $ guarantees that V intersects W in a nonzero vector? These subspaces cannot be orthogonal.

Prove that every y in  $ N(A^{\mathrm{T}}) $ is perpendicular to every Ax in the column space, using the matrix shorthand of equation (2). Start from  $ A^{\mathrm{T}}y = 0 $.