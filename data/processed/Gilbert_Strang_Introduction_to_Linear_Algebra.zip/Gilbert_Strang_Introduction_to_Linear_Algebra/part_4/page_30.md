Figure 4.6b shows the same problem in 3-dimensional space (bp e space). The vector b is not in the column space of A. That is why we could not solve Ax = b. No line goes through the three points. The smallest possible error is the perpendicular vector e. This is e = b - A $ \widehat{x} $, the vector of errors  $ (1, -2, 1) $ in the three equations. Those are the distances from the best line. Behind both figures is the fundamental equation  $ A^{\mathrm{T}}A\widehat{x} = A^{\mathrm{T}}b $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_157_257_878_628.jpg" alt="Image" width="67%" /></div>


<div style="text-align: center;">Figure 4.6: Best line and projection: Two pictures, same problem. The line has heights  $ p = (5, 2, -1) $ with errors  $ e = (1, -2, 1) $. The equations  $ A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b $ give  $ \widehat{x} = (5, -3) $. Same answer! The best line is  $ b = 5 - 3t $ and the closest point is  $ p = 5a_1 - 3a_2 $.</div>


Notice that the errors 1, -2, 1 add to zero. Reason: The error  $ e = (e_1, e_2, e_3) $ is perpendicular to the first column  $ (1, 1, 1) $ in A. The dot product gives  $ e_1 + e_2 + e_3 = 0 $.

By calculus Most functions are minimized by calculus! The graph bottoms out and the derivative in every direction is zero. Here the error function E to be minimized is a sum of squares  $ e_1^2 + e_2^2 + e_3^2 $ (the square of the error in each equation):

 $$ E=\left\|A\boldsymbol{x}-\boldsymbol{b}\right\|^{2}=(C+D\cdot0-6)^{2}+(C+D\cdot1)^{2}+(C+D\cdot2)^{2}. $$ 

The unknowns are C and D. With two unknowns there are two derivatives—both zero at the minimum. They are “partial derivatives” because  $ \partial E/\partial C $ treats D as constant and  $ \partial E/\partial D $ treats C as constant:

 $$ \begin{aligned}\partial E/\partial C&=2(C+D\cdot0-6)&+2(C+D\cdot1)&+2(C+D\cdot2)&=0\\\partial E/\partial D&=2(C+D\cdot0-6)(\mathbf{0})+2(C+D\cdot1)(\mathbf{1})+2(C+D\cdot2)(\mathbf{2})=0.\end{aligned} $$ 

 $ \partial E/\partial D $ contains the extra factors 0, 1, 2 from the chain rule. (The last derivative from  $ (C + 2D)^2 $ was 2 times  $ C + 2D $ times that extra 2.) Those factors are just 1, 1, 1 in  $ \partial E/\partial C $.