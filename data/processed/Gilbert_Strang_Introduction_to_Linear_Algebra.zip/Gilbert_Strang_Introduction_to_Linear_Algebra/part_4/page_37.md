## WORKED EXAMPLES

4.3 A Start with nine measurements  $ b_1 $ to  $ b_9 $, all zero, at times  $ t = 1, \ldots, 9 $. The tenth measurement  $ b_{10} = 40 $ is an outlier. Find the best horizontal line  $ y = C $ to fit the ten points  $ (1,0), (2,0), \ldots, (9,0), (10,40) $ using three options for the error  $ E $:

(1) Least squares  $ E_2 = e_1^2 + \cdots + e_{10}^2 $ (then the normal equation for  $ C $ is linear)

(2) Least maximum error  $ E_\infty = |e_{\max}| $ (3) Least sum of errors  $ E_1 = |e_1| + \cdots + |e_{10}| $.

Solution (1) The least squares fit to 0,0,...,0,40 by a horizontal line is C = 4:

 $$ \begin{aligned}\boldsymbol{A}&=column of1^{\prime}s\quad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=10\quad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{b}=sum of b_{i}=40.\quad So10\boldsymbol{C}=40.\end{aligned} $$ 

(2) The least maximum error requires C = 20, halfway between 0 and 40.

(3) The least sum requires  $ C = 0 $ (!!). The sum of errors  $ 9|C| + |40 - C| $ would increase if  $ C $ moves up from zero.

The least sum comes from the median measurement (the median of 0, ..., 0, 40 is zero). Many statisticians feel that the least squares solution is too heavily influenced by outliers like  $ b_{10} = 40 $, and they prefer least sum. But the equations become nonlinear.

Now find the least squares line  $ C + Dt $ through those ten points  $ (1,0) $ to  $ (10,40) $:

 $$ \boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\begin{bmatrix}10&\sum t_{i}\\ \sum t_{i}&\sum t_{i}^{2}\end{bmatrix}=\begin{bmatrix}10&55\\ 55&385\end{bmatrix}\qquad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{b}=\begin{bmatrix}\sum b_{i}\\ \sum t_{i}b_{i}\end{bmatrix}=\begin{bmatrix}40\\ 400\end{bmatrix} $$ 

Those come from equation (8). Then  $ A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b $ gives  $ C = -8 $ and  $ D = 24/11 $.

What happens to C and D if you multiply  $ \mathbf{b} = (0, 0, \ldots, 40) $ by 3 and then add 30 to get  $ \mathbf{b}_{\text{new}} = (30, 30, \ldots, 150) $? Linearity allows us to rescale  $ \mathbf{b} $. Multiplying  $ \mathbf{b} $ by 3 will multiply C and D by 3. Adding 30 to all  $ b_i $ will add 30 to C.

4.3 B Find the parabola  $ C + Dt + Et^2 $ that comes closest (least squares error) to the values  $ b = (0, 0, 1, 0, 0) $ at the times  $ t = -2, -1, 0, 1, 2 $. First write down the five equations  $ Ax = b $ in three unknowns  $ \boldsymbol{x} = (C, D, E) $ for a parabola to go through the five points. No solution because no such parabola exists. Solve  $ A^\mathrm{T} A \widehat{\boldsymbol{x}} = A^\mathrm{T} \boldsymbol{b} $.

I would predict $D = 0$. Why should the best parabola be symmetric around $t = 0$? In $A^\mathrm{T} A \widehat{x} = A^\mathrm{T} b$, equation 2 for $D$ should uncouple from equations 1 and 3.

Solution The five equations Ax = b have a rectangular Vandermonde matrix A:

 $$ \begin{array}{l}{{{C+D\left(-2\right)+E\left(-2\right)^{2}=0}}} \\{{{C+D\left(-1\right)+E\left(-1\right)^{2}=0}}} \\{{{C+D\quad(0)+E\quad(0)^{2}=1}}} \\{{{C+D\quad(1)+E\quad(1)^{2}=0}}} \\{{{C+D\quad(2)+E\quad(2)^{2}=0}}}\end{array}\quad\boldsymbol{A}=\left[\begin{array}{ccc}{{{1}}}&{{{-2}}}&{{{4}}} \\{{{1}}}&{{{-1}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{4}}}\end{array}\right]\quad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\left[\begin{array}{ccc}{{{5}}}&{{{0}}}&{{{10}}} \\{{{0}}}&{{{10}}}&{{{0}}} \\{{{10}}}&{{{0}}}&{{{34}}}\end{array}\right] $$ 