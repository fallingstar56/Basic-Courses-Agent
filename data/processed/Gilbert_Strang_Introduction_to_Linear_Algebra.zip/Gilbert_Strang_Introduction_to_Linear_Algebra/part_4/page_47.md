Subtract the

projection p

to get B = b - p

<div style="text-align: center;"><img src="imgs/img_in_image_box_267_144_859_377.jpg" alt="Image" width="55%" /></div>


<div style="text-align: center;">Figure 4.11: First project $b$ onto the line through $a$ and find the orthogonal $B$ as $b - p$. Then project $c$ onto the $AB$ plane and find $C$ as $c - p$. Divide by $\|A\|$, $\|B\|$, $\|C\|$.</div>


At the end, or immediately when each one is found, divide the orthogonal vectors  $ A, B, C, D $ by their lengths. The resulting vectors  $ q_{1}, q_{2}, q_{3}, q_{4} $ are orthonormal.

Example of Gram-Schmidt Suppose the independent non-orthogonal vectors a, b, c are

 $$ \boldsymbol{a}=\begin{bmatrix}1\\ -1\\ 0\end{bmatrix}\quad and\quad\boldsymbol{b}=\begin{bmatrix}2\\ 0\\ -2\end{bmatrix}\quad and\quad\boldsymbol{c}=\begin{bmatrix}3\\ -3\\ 3\end{bmatrix}. $$ 

Then  $ A = a $ has  $ A^{\mathrm{T}}A = 2 $ and  $ A^{\mathrm{T}}b = 2 $. Subtract from b its projection p along  $ A $:

First step

 $$ \boldsymbol{B}=\boldsymbol{b}-\frac{\boldsymbol{A}^{\mathrm{T}}\boldsymbol{b}}{\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}}\boldsymbol{A}=\boldsymbol{b}-\frac{2}{2}\boldsymbol{A}=\begin{bmatrix}1\\ 1\\ -2\end{bmatrix}. $$ 

Check:  $ A^{T}B = 0 $ as required. Now subtract the projections of c on A and B to get C:

Next step

 $$ \boldsymbol{C}=\boldsymbol{c}-\frac{\boldsymbol{A}^{\mathrm{T}}\boldsymbol{c}}{\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}}\boldsymbol{A}-\frac{\boldsymbol{B}^{\mathrm{T}}\boldsymbol{c}}{\boldsymbol{B}^{\mathrm{T}}\boldsymbol{B}}\boldsymbol{B}=\boldsymbol{c}-\frac{6}{2}\boldsymbol{A}+\frac{6}{6}\boldsymbol{B}=\begin{bmatrix}1\\ 1\\ 1\end{bmatrix}. $$ 

Check:  $ C = (1, 1, 1) $ is perpendicular to both A and B. Finally convert A, B, C to unit vectors (length 1, orthonormal). The lengths of A, B, C are  $ \sqrt{2} $ and  $ \sqrt{6} $ and  $ \sqrt{3} $. Divide by those lengths, for an orthonormal basis:

 $$ q_{1}=\frac{1}{\sqrt{2}}\begin{bmatrix}1\\ -1\\ 0\end{bmatrix}\quad and\quad q_{2}=\frac{1}{\sqrt{6}}\begin{bmatrix}1\\ 1\\ -2\end{bmatrix}\quad and\quad q_{3}=\frac{1}{\sqrt{3}}\begin{bmatrix}1\\ 1\\ 1\end{bmatrix}. $$ 

Usually A, B, C contain fractions. Almost always  $ q_{1}, q_{2}, q_{3} $ contain square roots.