Fundamental Theorem of Linear Algebra, Part 2

 $ N(A) $ is the orthogonal complement of the row space  $ C(A^{\mathrm{T}}) $ (in  $ \mathbf{R}^{n} $).

 $ N(A^{\mathrm{T}}) $ is the orthogonal complement of the column space  $ C(A) $ (in  $ \mathbf{R}^{m} $).

Part 1 gave the dimensions of the subspaces. Part 2 gives the  $ 90^\circ $ angles between them. The point of “complements” is that every x can be split into a row space component  $ x_r $ and a nullspace component  $ x_n $. When  $ A $ multiplies  $ x = x_r + x_n $, Figure 4.3 shows what happens to  $ Ax = Ax_r + Ax_n $:

The nullspace component goes to zero:  $ Ax_{n}=0 $.

The row space component goes to the column space:  $ Ax_{r} = Ax $.

Every vector goes to the column space! Multiplying by $A$ cannot do anything else. More than that: Every vector $b$ in the column space comes from one and only one vector $\mathbf{x}_r$ in the row space. Proof: If $A\mathbf{x}_r = A\mathbf{x}_r',$ the difference $\mathbf{x}_r - \mathbf{x}_r' $ is in the nullspace. It is also in the row space, where $\mathbf{x}_r$ and $\mathbf{x}_r'$ came from. This difference must be the zero vector, because the nullspace and row space are perpendicular. Therefore $\mathbf{x}_r = \mathbf{x}_r'.$

There is an r by r invertible matrix hiding inside A, if we throw away the two nullspaces. From the row space to the column space, A is invertible. The “pseudoinverse” will invert that part of A in Section 7.4.

Example 4 Every matrix of rank r has an r by r invertible submatrix:

 $$ A=\begin{bmatrix}{{{3}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{5}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad contains the submatrix\quad\begin{bmatrix}{{{3}}}&{{{0}}} \\{{{0}}}&{{{5}}}\end{bmatrix}. $$ 

The other eleven zeros are responsible for the nullspaces. The rank of B is also r = 2:

 $$ \boldsymbol{B}=\left[\begin{array}{l l l l l}{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}}&{{{5}}} \\{{{1}}}&{{{2}}}&{{{4}}}&{{{5}}}&{{{6}}} \\{{{1}}}&{{{2}}}&{{{4}}}&{{{5}}}&{{{6}}}\end{array}\right]\text{contains}\left[\begin{array}{l l}{{{1}}}&{{{3}}} \\{{{1}}}&{{{4}}}\end{array}\right]\text{in the pivot rows and columns.} $$ 

Every matrix can be diagonalized, when we choose the right bases for  $ \mathbf{R}^n $ and  $ \mathbf{R}^m $. This Singular Value Decomposition has become extremely important in applications.

Let me repeat one clear fact. A row of A can't be in the nullspace of A (except for a zero row). The only vector in two orthogonal subspaces is the zero vector.

If a vector v is orthogonal to itself then v is the zero vector.