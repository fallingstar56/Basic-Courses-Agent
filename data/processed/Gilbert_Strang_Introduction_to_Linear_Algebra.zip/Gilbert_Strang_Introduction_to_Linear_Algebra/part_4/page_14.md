## Challenge Problems

Suppose A is 3 by 4 and B is 4 by 5 and AB = 0. So  $ N(A) $ contains  $ C(B) $ Prove from the dimensions of  $ N(A) $ and  $ C(B) $ that  $ \operatorname{rank}(A) + \operatorname{rank}(B) \leq 4 $.

The command  $ N = \text{null}(A) $ will produce a basis for the nullspace of A. Then the command  $ B = \text{null}(N') $ will produce a basis for the ___ of A.

32 Suppose I give you four nonzero vectors r, n, c, l in R2.

(a) What are the conditions for those to be bases for the four fundamental subspaces  $ C(A^{\mathrm{T}}), N(A), C(A), N(A^{\mathrm{T}}) $ of a 2 by 2 matrix?

(b) What is one possible matrix  $ A_{?} $

33 Suppose I give you eight vectors r1, r2, n1, n2, c1, c2, l1, l2 in R4.

(a) What are the conditions for those pairs to be bases for the four fundamental subspaces of a 4 by 4 matrix?

(b) What is one possible matrix  $ A_{?} $