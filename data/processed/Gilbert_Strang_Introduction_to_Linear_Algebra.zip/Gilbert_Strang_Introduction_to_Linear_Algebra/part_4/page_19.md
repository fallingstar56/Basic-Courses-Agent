The matrix I−P should be a projection too. It produces the other side e of the triangle—the perpendicular part of b. Note that  $ (I-P)b $ equals b−p which is e in the left nullspace.

When P projects onto one subspace, I – P projects onto the perpendicular subspace. Here I – P projects onto the plane perpendicular to a.

Now we move beyond projection onto a line. Projecting onto an $n$-dimensional subspace of $\mathbf{R}^m$ takes more effort. The crucial formulas will be collected in equations (5)–(6)–(7). Basically you need to remember those three equations.

## Projection Onto a Subspace

Start with n vectors  $ a_{1}, \ldots, a_{n} $ in  $ R^{m} $. Assume that these  $ a' $s are linearly independent.

Problem: Find the combination  $ p = \hat{x}_1 a_1 + \cdots + \hat{x}_n a_n $ closest to a given vector  $ b $. We are projecting each  $ b $ in  $ \mathbf{R}^m $ onto the subspace spanned by the  $ a $'s.

With $n = 1$ (one vector $a_1$) this is projection onto a line. The line is the column space of $A$, which has just one column. In general the matrix $A$ has $n$ columns $a_1, \ldots, a_n$.

The combinations in  $ \mathbf{R}^m $ are the vectors  $ A\boldsymbol{x} $ in the column space. We are looking for the particular combination  $ \boldsymbol{p} = A\widehat{\boldsymbol{x}} $ (the projection) that is closest to  $ \boldsymbol{b} $. The hat over  $ \widehat{\boldsymbol{x}} $ indicates the best choice  $ \widehat{\boldsymbol{x}} $, to give the closest vector in the column space. That choice is  $ \widehat{\boldsymbol{x}} = \boldsymbol{a}^\mathrm{T} \boldsymbol{b} / \boldsymbol{a}^\mathrm{T} \boldsymbol{a} $ when  $ n = 1 $. For  $ n > 1 $, the best  $ \widehat{\boldsymbol{x}} = (\widehat{\boldsymbol{x}}_1, \ldots, \widehat{\boldsymbol{x}}_n) $ is to be found now.

We compute projections onto $n$-dimensional subspaces in three steps as before: Find the vector $\hat{x}$, find the projection $p = A\hat{x}$, find the projection matrix $P$.

The key is in the geometry! The dotted line in Figure 4.6 goes from $b$ to the nearest point $A\widehat{x}$ in the subspace. This error vector $b - A\widehat{x}$ is perpendicular to the subspace. The error $b - A\widehat{x}$ makes a right angle with all the vectors $a_{1},\ldots,a_{n}$ in the base. The $n$ right angles give the $n$ equations for $\widehat{x}$:

 $$ \begin{array}{ccc}a_{1}^{\mathrm{T}}(\boldsymbol{b}-A\widehat{\boldsymbol{x}})=0&&-\boldsymbol{a}_{1}^{\mathrm{T}}-\\\vdots&\text{or}&\left[\begin{array}{c}-\boldsymbol{a}_{1}^{\mathrm{T}}-\\\vdots\\\boldsymbol{a}_{n}^{\mathrm{T}}-\end{array}\right]\left[\begin{array}{c}\boldsymbol{b}-A\widehat{\boldsymbol{x}}\\-\boldsymbol{a}_{n}^{\mathrm{T}}-\end{array}\right]=\left[\begin{array}{c}\boldsymbol{0}\end{array}\right].\end{array} $$ 

The matrix with those rows a i ^T is A ^T. The n equations are exactly A ^T(b − Âx) = 0.

Rewrite  $ A^{\mathrm{T}}(b - A\widehat{x}) = 0 $ in its famous form  $ A^{\mathrm{T}}A\widehat{x} = A^{\mathrm{T}}b $. This is the equation for  $ \widehat{x} $, and the coefficient matrix is  $ A^{\mathrm{T}}A $. Now we can find  $ \widehat{x} $ and  $ p $ and  $ P $, in that order.