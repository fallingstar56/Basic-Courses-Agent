Least squares

 $$ \boldsymbol{R}^{\mathrm{T}}\boldsymbol{R}\widehat{\boldsymbol{x}}=\boldsymbol{R}^{\mathrm{T}}\boldsymbol{Q}^{\mathrm{T}}\boldsymbol{b}\mathrm{~o r~}\boldsymbol{R}\widehat{\boldsymbol{x}}=\boldsymbol{Q}^{\mathrm{T}}\boldsymbol{b}\mathrm{~o r~}\widehat{\boldsymbol{x}}=\boldsymbol{R}^{-1}\boldsymbol{Q}^{\mathrm{T}}\boldsymbol{b} $$ 

Instead of solving Ax = b, which is impossible, we solve  $ R\widehat{x} = Q^{\mathrm{T}}b $ by back substitution—which is very fast. The real cost is the  $ mn^2 $ multiplications in the Gram-Schmidt process, which are needed to construct the orthogonal Q and the triangular R with A = QR.

Below is an informal code. It executes equations (11) for  $ j = 1 $ then  $ j = 2 $ and eventually  $ j = n $. The important lines 4-5 subtract from  $ v = a_j $ its projection onto each  $ q_i $,  $ i < j $. The last line of that code normalizes  $ v $ (divides by  $ r_{jj} = ||v|| $) to get the unit vector  $ q_j $:

 $$ r_{kj}=\sum_{i=1}^{m}q_{ik}v_{ij}\mathrm{\ and\ }v_{ij}=v_{ij}-q_{ik}r_{kj}\mathrm{\ and\ }r_{jj}=\left(\sum_{i=1}^{m}v_{ij}^{2}\right)^{1/2}\mathrm{\ and\ }q_{ij}=\frac{v_{ij}}{r_{jj}}. $$ 

Starting from a, b, c = a1, a2, a3 this code will construct q1, then B, q2, then C, q3:

 $$ \boldsymbol{q}_{1}=\boldsymbol{a}_{1}/\|\boldsymbol{a}_{1}\|\quad\boldsymbol{B}=\boldsymbol{a}_{2}-(\boldsymbol{q}_{1}^{\mathrm{T}}\boldsymbol{a}_{2})\boldsymbol{q}_{1}\quad\boldsymbol{q}_{2}=\boldsymbol{B}/\|\boldsymbol{B}\| $$ 

 $$ \boldsymbol{C}^{*}=\boldsymbol{a}_{3}-(\boldsymbol{q}_{1}^{\mathrm{T}}\boldsymbol{a}_{3})\boldsymbol{q}_{1}\quad\boldsymbol{C}=\boldsymbol{C}^{*}-(\boldsymbol{q}_{2}^{\mathrm{T}}\boldsymbol{C}^{*})\boldsymbol{q}_{2}\quad\boldsymbol{q}_{3}=\boldsymbol{C}/||\boldsymbol{C}|| $$ 

Equation (11) subtracts one projection at a time as in  $ C^{*} $ and C. That change is called modified Gram-Schmidt. This code is numerically more stable than equation (8) which subtracts all projections at once.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>for j = 1:n</td><td style='text-align: center; word-wrap: break-word;'>% modified Gram-Schmidt</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>v = A(:, j);</td><td style='text-align: center; word-wrap: break-word;'>% v begins as column j of the original A</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>for i = 1:j-1</td><td style='text-align: center; word-wrap: break-word;'>% columns  $ q_{1} $ to  $ q_{j-1} $ are already settled in Q</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>R(i, j) = Q(:, i)&#x27;*v;</td><td style='text-align: center; word-wrap: break-word;'>% compute  $ R_{ij} $ =  $ q_{i}^{T} a_{j} $ which is  $ q_{i}^{T} v $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>v = v - R(i, j)*Q(:, i);</td><td style='text-align: center; word-wrap: break-word;'>% subtract the projection ( $ q_{i}^{T} v $)  $ q_{i} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>end</td><td style='text-align: center; word-wrap: break-word;'>% v is now perpendicular to all of  $ q_{1}, \ldots, q_{j-1} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>R(j, j) = norm(v);</td><td style='text-align: center; word-wrap: break-word;'>% the diagonal entries  $ R_{jj} $ are lengths</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Q(:, j) = v/R(j, j);</td><td style='text-align: center; word-wrap: break-word;'>% divide v by its length to get the next  $ q_{j} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>end</td><td style='text-align: center; word-wrap: break-word;'>% the “for  $ j $ = 1 : m loop” produces all of the  $ q_{j} $</td></tr></table>

To recover column j of A, undo the last step and the middle steps of the code:

 $$ R(j,j)q_{j}=(v\ minus its projections)=(\mathrm{column}j\ of A)-\sum_{i=1}^{j-1}R(i,j)q_{i}. $$ 

Moving the sum to the far left, this is column j in the multiplication QR = A.