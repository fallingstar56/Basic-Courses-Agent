What does this mean for projection? The matrix has three columns, which span the whole space  $ \mathbf{R}^3 $. The projection matrix is the identity. The projection of  $ \mathbf{b} $ is  $ \mathbf{b} $. The error is zero. We didn’t need  $ A^\mathrm{T} A \widehat{\mathbf{x}} = A^\mathrm{T} \mathbf{b} $, because we solved  $ Ax = \mathbf{b} $. Of course we could multiply by  $ A^\mathrm{T} $, but there is no reason to do it.

Figure 4.8 also shows a fourth point  $ b_4 $ at time  $ t_4 $. If that falls on the parabola, the new  $ Ax = b $ (four equations) is still solvable. When the fourth point is not on the parabola, we turn to  $ A^\mathrm{T} A \widehat{x} = A^\mathrm{T} b $. Will the least squares parabola stay the same, with all the error at the fourth point? Not likely!

Least squares balances the four errors to get three equations for C, D, E.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_214_363_486_604.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_580_367_810_595.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">Figure 4.8: An exact fit of the parabola at $t = 0, 1, 2$ means that $p = b$ and $e = 0$. The fourth point $\textcircled{x}$ off the parabola makes $m > n$ and we need least squares: project $b$ on $C(A)$. The figure on the right shows $b$—not a combination of the three columns of $A$.</div>


## ■ REVIEW OF THE KEY IDEAS

1. The least squares solution  $ \hat{x} $ minimizes  $ \|Ax - b\|^2 = \boldsymbol{x}^\mathrm{T} A^\mathrm{T} A \boldsymbol{x} - 2 \boldsymbol{x}^\mathrm{T} A^\mathrm{T} \boldsymbol{b} + \boldsymbol{b}^\mathrm{T} \boldsymbol{b} $. This is  $ E $, the sum of squares of the errors in the  $ m $ equations ( $ m > n $).

2. The best  $ \hat{x} $ comes from the normal equations  $ A^{\mathrm{T}} A \hat{x} = A^{\mathrm{T}} b $. E is a minimum.

3. To fit m points by a line  $ b = C + Dt $, the normal equations give C and D.

4. The heights of the best line are  $ \boldsymbol{p} = (p_{1}, \ldots, p_{m}) $. The vertical distances to the data points are the errors  $ e = (e_{1}, \ldots, e_{m}) $. A key equation is  $ A^{T} e = 0 $.

5. If we try to fit m points by a combination of  $ n < m $ functions, the m equations  $ Ax = b $ are generally unsolvable. The n equations  $ A^T A \widehat{x} = A^T b $ give the least squares solution—the combination with smallest MSE (mean square error).