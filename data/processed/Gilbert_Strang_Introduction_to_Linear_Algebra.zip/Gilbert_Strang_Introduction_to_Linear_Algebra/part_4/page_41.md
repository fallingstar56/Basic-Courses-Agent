Find the plane that gives the best fit to the 4 values  $ b = (0, 1, 3, 4) $ at the corners  $ (1, 0) $ and  $ (0, 1) $ and  $ (-1, 0) $ and  $ (0, -1) $ of a square. The equations  $ C + Dx + Ey = b $ at those 4 points are  $ Ax = b $ with 3 unknowns  $ x = (C, D, E) $. What is  $ A $? At the center  $ (0, 0) $ of the square, show that  $ C + Dx + Ey = average $ of the b's.

(Distance between lines) The points  $ P = (x, x, x) $ and  $ Q = (y, 3y, -1) $ are on two lines in space that don't meet. Choose x and y to minimize the squared distance  $ \|P - Q\|^2 $. The line connecting the closest P and Q is perpendicular to ___.

Suppose the columns of A are not independent. How could you find a matrix B so that  $ P = B(B^{\mathrm{T}}B)^{-1}B^{\mathrm{T}} $ does give the projection onto the column space of A? (The usual formula will fail when  $ A^{\mathrm{T}}A $ is not invertible.)

Usually there will be exactly one hyperplane in  $ \mathbf{R}^n $ that contains the  $ n $ given points  $ \mathbf{x} = \mathbf{0}, a_1, \ldots, a_{n-1} $. (Example for  $ n = 3 $: There will be one plane containing  $ 0, a_1, a_2 $ unless ___) What is the test to have exactly one plane in  $ \mathbf{R}^n $?

Example 2 shifted the times  $ t_i $ to make them add to zero. We subtracted away the average time  $ \widehat{t} = (t_1 + \cdots + t_m) / m $ to get  $ T_i = t_i - \widehat{t} $. Those  $ T_i $ add to zero.

With the columns  $ (1, \ldots, 1) $ and  $ (T_1, \ldots, T_m) $ now orthogonal,  $ A^T A $ is diagonal. Its entries are  $ m $ and  $ T_1^2 + \cdots + T_m^2 $. Show that the best  $ C $ and  $ D $ have direct formulas:

 $$ \begin{array}{r l r l r}{T\textbf{i s}t-\widehat{t}}&{{}}&{C=\frac{b_{1}+\dots+b_{m}}{m}.}&{{}}&{\mathrm{a n d}}&{{}}&{D=\frac{b_{1}T_{1}+\dots+b_{m}T_{m}}{T_{1}^{2}+\dots+T_{m}^{2}}.}\end{array} $$ 

The best line is  $ C + DT $ or  $ C + D(t - \widehat{t}) $. The time shift that makes  $ A^{\mathrm{T}}A $ diagonal is an example of the Gram-Schmidt process: orthogonalize the columns of A in advance.