Inverse = transpose:

 $$ \begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{\boldsymbol{y}}}} \\{{{z}}} \\{{{x}}}\end{bmatrix}=\begin{bmatrix}{{{\boldsymbol{x}}}} \\{{{\boldsymbol{y}}}} \\{{{z}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{\boldsymbol{y}}}} \\{{{\boldsymbol{x}}}}\end{bmatrix}=\begin{bmatrix}{{{\boldsymbol{x}}}} \\{{{\boldsymbol{y}}}}\end{bmatrix}. $$ 

Every permutation matrix is an orthogonal matrix.

Example 3 (Reflection) If  $ u $ is any unit vector, set  $ Q = I - 2uu^\mathrm{T} $. Notice that  $ uu^\mathrm{T} $ is a matrix while  $ u^\mathrm{T}u $ is the number  $ \|u\|^2 = 1 $. Then  $ Q^\mathrm{T} $ and  $ Q^{-1} $ both equal  $ Q $:

 $$ \mathbf{Q}^{\mathrm{T}}=\mathbf{I}-2\mathbf{u}\mathbf{u}^{\mathrm{T}}=\mathbf{Q}\quad\mathrm{a n d}\quad\mathbf{Q}^{\mathrm{T}}\mathbf{Q}=\mathbf{I}-4\mathbf{u}\mathbf{u}^{\mathrm{T}}+4\mathbf{u}\mathbf{u}^{\mathrm{T}}\mathbf{u}\mathbf{u}^{\mathrm{T}}=\mathbf{I}. $$ 

Reflection matrices  $ I - 2uu^{\mathrm{T}} $ are symmetric and also orthogonal. If you square them, you get the identity matrix:  $ Q^{2} = Q^{\mathrm{T}}Q = I $. Reflecting twice through a mirror brings back the original, like  $ (-1)^{2} = 1 $. Notice  $ u^{\mathrm{T}}u = 1 $ inside  $ 4uu^{\mathrm{T}}uu^{\mathrm{T}} $ in equation (2).

<div style="text-align: center;"><img src="imgs/img_in_image_box_169_538_853_683.jpg" alt="Image" width="64%" /></div>


Figure 4.10: Rotation by  $ Q = \begin{bmatrix} c & -s \\ s & c \end{bmatrix} $ and reflection across  $ 45^{\circ} $ by  $ Q = \begin{bmatrix} 0 & 1 \\ 1 & 0 \end{bmatrix} $.

As example choose the direction  $ \boldsymbol{u} = (-1/\sqrt{2}, 1/\sqrt{2}) $. Compute  $ 2uu^\mathrm{T} $ (column times row) and subtract from I to get the reflection matrix Q in the direction of  $ \boldsymbol{u} $:

Reflection

 $$ Q=I-2\begin{bmatrix}{{{.5}}}&{{{-.5}}} \\{{{-.5}}}&{{{.5}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}}\end{bmatrix}=\begin{bmatrix}{{{y}}} \\{{{x}}}\end{bmatrix}. $$ 

When  $ (x,y) $ goes to  $ (y,x) $, a vector like  $ (3,3) $ doesn't move. It is on the mirror line.

Rotations preserve the length of every vector. So do reflections. So do permutations. So does multiplication by any orthogonal matrix Q—lengths and angles don't change.

Proof  $ \|Qx\|^2 $ equals  $ \|x\|^2 $ because  $ (Qx)^\mathrm{T}(Qx) = x^\mathrm{T}Q^\mathrm{T}Qx = x^\mathrm{T}Ix = x^\mathrm{T}x. $

If Q has orthonormal columns (Q^T Q = I), it leaves lengths unchanged:

Same length for Qx

 $$ \left\|Q x\right\|=\left\|x\right\|for every vector x. $$ 

Q also preserves dot products:  $ (Qx)^{\mathrm{T}}(Qy) = x^{\mathrm{T}}Q^{\mathrm{T}}Qy = x^{\mathrm{T}}y. $ Just use  $ Q^{\mathrm{T}}Q = I! $