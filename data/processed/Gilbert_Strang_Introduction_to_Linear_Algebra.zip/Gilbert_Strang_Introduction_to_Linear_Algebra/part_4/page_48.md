## The Factorization A = QR

We started with a matrix $A$, whose columns were $a, b, c$. We ended with a matrix $Q$, whose columns are $q_{1}, q_{2}, q_{3}$. How are those matrices related? Since the vectors $a, b, c$ are combinations of the $q$'s (and vice versa), there must be a third matrix connecting $A$ to $Q$. This third matrix is the triangular $R$ in $A = QR$.

The first step was  $ q_1 = a / \|a\| $ (other vectors not involved). The second step was equation (7), where  $ b $ is a combination of  $ A $ and  $ B $. At that stage  $ C $ and  $ q_3 $ were not involved. This non-involvement of later vectors is the key point of Gram-Schmidt:

• The vectors a and A and  $ q_{1} $ are all along a single line.

• The vectors a, b and A, B and  $ q_{1}, q_{2} $ are all in the same plane.

• The vectors a, b, c and A, B, C and q1, q2, q3 are in one subspace (dimension 3).

At every step  $ a_1, \ldots, a_k $ are combinations of  $ q_1, \ldots, q_k $. Later  $ q' $s are not involved. The connecting matrix  $ R $ is triangular, and we have  $ A = QR $:

 $$ \begin{bmatrix} \\{{{a}}}&{{{b}}}&{{{c}}} \\\end{bmatrix}=\begin{bmatrix} \\{{{q_{1}}}}&{{{q_{2}}}}&{{{q_{3}}}} \\\end{bmatrix}\begin{bmatrix} \\{{{q_{1}^{\mathrm{T}}a}}}&{{{q_{1}^{\mathrm{T}}b}}}&{{{q_{1}^{\mathrm{T}}c}}} \\{{{q_{2}^{\mathrm{T}}b}}}&{{{q_{2}^{\mathrm{T}}c}}} \\{{{q_{3}^{\mathrm{T}}c}}} \\\end{bmatrix}\quad or\quad A=QR. $$ 

A = QR is Gram-Schmidt in a nutshell. Multiply by  $ Q^{\mathrm{T}} $ to recognize  $ R = Q^{\mathrm{T}} A $ above.

(Gram-Schmidt) From independent vectors  $ a_1, \ldots, a_n $, Gram-Schmidt constructs orthonormal vectors  $ q_1, \ldots, q_n $. The matrices with these columns satisfy  $ A = QR $. Then  $ R = Q^\mathrm{T} A $ is upper triangular because later  $ q' $s are orthogonal to earlier  $ a' $s.

Here are the original $a$'s and the final $q$'s from the example. The $i,j$ entry of $R = Q^{\mathrm{T}} A$ is row $i$ of $Q^{\mathrm{T}}$ times column $j$ of $A$. The dot products $q_{i}^{\mathrm{T}} a_{j}$ go into $R$. Then $A = QR$:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{-1}}}&{{{0}}}&{{{-3}}} \\{{{0}}}&{{{-2}}}&{{{3}}}\end{bmatrix}=\begin{bmatrix}{{{1/\sqrt{2}}}}&{{{1/\sqrt{6}}}}&{{{1/\sqrt{3}}}} \\{{{-1/\sqrt{2}}}}&{{{1/\sqrt{6}}}}&{{{1/\sqrt{3}}}} \\{{{0}}}&{{{-2/\sqrt{6}}}}&{{{1/\sqrt{3}}}}\end{bmatrix}\begin{bmatrix}{{{\sqrt{2}}}}&{{{\sqrt{2}}}}&{{{\sqrt{18}}}} \\{{{\mathbf{0}}}}&{{{\sqrt{6}}}}&{{{-\sqrt{6}}}} \\{{{\mathbf{0}}}}&{{{\mathbf{0}}}}&{{{\sqrt{3}}}}\end{bmatrix}=\boldsymbol{Q}\boldsymbol{R}. $$ 

Look closely at Q and R. The lengths of A, B, C are  $ \sqrt{2} $,  $ \sqrt{6} $,  $ \sqrt{3} $ on the diagonal of R. The columns of Q are orthonormal. Because of the square roots, QR might look harder than LU. Both factorizations are absolutely central to calculations in linear algebra.

Any $m$ by $n$ matrix $A$ with independent columns can be factored into $A = QR$. The $m$ by $n$ matrix $Q$ has orthonormal columns, and the square matrix $R$ is upper triangular with positive diagonal. We must not forget why this is useful for least squares: $A^{\mathrm{T}}A = (QR)^{\mathrm{T}}QR = R^{\mathrm{T}}Q^{\mathrm{T}}QR = R^{\mathrm{T}}R$. The least squares equation $A^{\mathrm{T}}A\hat{x} = A^{\mathrm{T}}b$ simplifies to $R^{\mathrm{T}}R\hat{x} = R^{\mathrm{T}}Q^{\mathrm{T}}b$. Then finally we reach $R\hat{x} = Q^{\mathrm{T}}b$: good.