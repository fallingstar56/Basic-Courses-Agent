## Fitting by a Parabola

If we throw a ball, it would be crazy to fit the path by a straight line. A parabola  $ b = C + Dt + Et^{2} $ allows the ball to go up and come down again (b is the height at time t). The actual path is not a perfect parabola, but the whole theory of projectiles starts with that approximation.

When Galileo dropped a stone from the Leaning Tower of Pisa, it accelerated. The distance contains a quadratic term  $ \frac{1}{2}gt^2 $. (Galileo’s point was that the stone’s mass is not involved.) Without that  $ t^2 $ term we could never send a satellite into its orbit. But even with a nonlinear function like  $ t^2 $, the unknowns  $ C, D, E $ still appear linearly! Fitting points by the best parabola is still a problem in linear algebra.

Problem Fit heights  $ b_{1}, \ldots, b_{m} $ at times  $ t_{1}, \ldots, t_{m} $ by a parabola  $ C + Dt + Et^{2} $.

Solution With m > 3 points, the m equations for an exact fit are generally unsolvable:

 $$ \begin{array}{r l}{C+D t_{1}+E t_{1}^{2}=b_{1}}&{{}}\\ {\vdots}&{{}\qquad\mathrm{i s~A\boldsymbol{x}=\boldsymbol{b}~w i t h}}\\ {C+D t_{m}+E t_{m}^{2}=b_{m}}&{{}}\end{array}\qquad A=\left[\begin{matrix}{1}&{t_{1}}&{t_{1}^{2}}\\ {\vdots}&{\vdots}&{\vdots}\\ {1}&{t_{m}}&{t_{m}^{2}}\\ \end{matrix}\right]. $$ 

Least squares The closest parabola  $ C + Dt + Et^2 $ chooses  $ \hat{x} = (C, D, E) $ to satisfy the three normal equations  $ A^\mathrm{T} A \hat{x} = A^\mathrm{T} b $.

May I ask you to convert this to a problem of projection? The column space of $A$ has dimension ___. The projection of $b$ is $p = A\widehat{x}$, which combines the three columns using the coefficients $C, D, E$. The error at the first data point is $e_1 = b_1 - C - D t_1 - E t_1^2$. The total squared error is $e_1^2 + \_\_\_\_.$ If you prefer to minimize by calculus, take the partial derivatives of $E$ with respect to ___, ___, ___. These three derivatives will be zero when $\widehat{x} = (C, D, E)$ solves the 3 by 3 system of equations $A^T A\widehat{x} = A^T b$.

Section 10.5 has more least squares applications. The big one is Fourier series—approximating functions instead of vectors. The function to be minimized changes from a sum of squared errors  $ e_1^2 + \cdots + e_m^2 $ to an integral of the squared error.

Example 3 For a parabola  $ b = C + Dt + Et^{2} $ to go through the three heights  $ b = 6, 0, 0 $ when  $ t = 0, 1, 2 $, the equations for C, D, E are

 $$ \begin{aligned}&C+D\cdot0+E\cdot0^{2}=6\\&C+D\cdot1+E\cdot1^{2}=0\\&C+D\cdot2+E\cdot2^{2}=0.\\ \end{aligned} $$ 

This is $Ax = b$. We can solve it exactly. Three data points give three equations and a square matrix. The solution is $x = (C, D, E) = (6, -9, 3)$. The parabola through the three points in Figure 4.8a is $b = 6 - 9t + 3t^2$.