This 3 by 2 system has no solution:  $ \boldsymbol{b} = (6, 0, 0) $ is not a combination of the columns  $ (1, 1, 1) $ and  $ (0, 1, 2) $. Read off A, x, and b from those equations:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}\end{bmatrix}\quad\boldsymbol{x}=\begin{bmatrix}{{{C}}} \\{{{D}}}\end{bmatrix}\quad\boldsymbol{b}=\begin{bmatrix}{{{6}}} \\{{{0}}} \\{{{0}}}\end{bmatrix}\quad\boldsymbol{A}\boldsymbol{x}=\boldsymbol{b}is not solvable. $$ 

The same numbers were in Example 3 in the last section. We computed  $ \widehat{x} = (5, -3) $. Those numbers are the best  $ C $ and  $ D $, so  $ 5 - 3t $ will be the best line for the 3 points. We must connect projections to least squares, by explaining why  $ A^\mathrm{T} A \widehat{x} = A^\mathrm{T} b $.

In practical problems, there could easily be m = 100 points instead of m = 3. They don't exactly match any straight line  $ C + Dt $. Our numbers 6, 0, 0 exaggerate the error so you can see  $ e_1, e_2 $, and  $ e_3 $ in Figure 4.6.

Minimizing the Error

How do we make the error  $ e = b - Ax $ as small as possible? This is an important question with a beautiful answer. The best  $ x $ (called  $ \hat{x} $) can be found by geometry (the error  $ e $ meets the column space of  $ A $ at  $ 90^\circ $) and by algebra:  $ A^\mathrm{T}A\hat{x} = A^\mathrm{T}b $. Calculus gives the same  $ \hat{x} $: the derivative of the error  $ \|Ax - b\|^2 $ is zero at  $ \hat{x} $.

By geometry Every Ax lies in the plane of the columns  $ (1,1,1) $ and  $ (0,1,2) $. In that plane, we look for the point closest to b. The nearest point is the projection p.

The best choice for  $ A\widehat{x} $ is p. The smallest possible error is  $ e = b - p $, perpendicular to the columns. The three points at heights  $ (p_1, p_2, p_3) $ do lie on a line, because p is in the column space of A. In fitting a straight line,  $ \widehat{x} $ is the best choice for  $ (C, D) $.

By algebra Every vector $b$ splits into two parts. The part in the column space is $p$. The perpendicular part is $e$. There is an equation we cannot solve ($Ax = b$). There is an equation $A\widehat{x} = p$ we can and do solve (by removing $e$ and solving $A^{\mathrm{T}}A\widehat{x} = A^{\mathrm{T}}b$):

 $$ \begin{array}{l}Ax=b=p+e\quad is impossible\quad A\widehat{x}=p\quad is solvable\quad\widehat{x}\quad is\left(A^{\mathrm{T}}A\right)^{-1}A^{\mathrm{T}}b.\end{array} $$ 

The solution to  $ A\widehat{x} = p $ leaves the least possible error (which is e):

Squared length for any x

 $$ \|A\boldsymbol{x}-\boldsymbol{b}\|^{2}=\|A\boldsymbol{x}-\boldsymbol{p}\|^{2}+\|\boldsymbol{e}\|^{2}. $$ 

This is the law  $ c^2 = a^2 + b^2 $ for a right triangle. The vector  $ Ax - p $ in the column space is perpendicular to  $ e $ in the left nullspace. We reduce  $ Ax - p $ to  $ \textbf{zero} $ by choosing  $ \boldsymbol{x} = \hat{\boldsymbol{x}} $. That leaves the smallest possible error  $ e = (e_1, e_2, e_3) $ which we can't reduce.

Notice what “smallest” means. The squared length of Ax - b is minimized:

The least squares solution  $ \hat{x} $ makes  $ E = \|Ax - b\|^2 $ as small as possible.

Figure 4.6a shows the closest line. It misses by distances  $ e_{1}, e_{2}, e_{3} = 1, -2, 1 $. Those are vertical distances. The least squares line minimizes  $ E = e_{1}^{2} + e_{2}^{2} + e_{3}^{2} $.