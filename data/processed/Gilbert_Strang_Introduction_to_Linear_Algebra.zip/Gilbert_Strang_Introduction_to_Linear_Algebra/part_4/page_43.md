A matrix Q with orthonormal columns satisfies  $ Q^{\mathrm{T}}Q = I $

 $$ \boldsymbol{Q}^{\mathrm{T}}\boldsymbol{Q}=\left[\begin{array}{c}{{{-q_{1}^{\mathrm{T}}-}}} \\{{{-q_{2}^{\mathrm{T}}-}}} \\{{{-q_{n}^{\mathrm{T}}-}}}\end{array}\right]\begin{bmatrix}{{{|}}}&{{{|}}}&{{{0}}} \\{{{q_{1}}}}&{{{q_{2}}}}&{{{q_{n}}}} \\{{{|}}}&{{{|}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{\cdots}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{\cdots}}}&{{{0}}} \\{{{\vdots}}}&{{{\vdots}}}&{{{\ddots}}}&{{{\vdots}}} \\{{{0}}}&{{{0}}}&{{{\cdots}}}&{{{1}}}\end{bmatrix}=\boldsymbol{I}. $$ 

When row $i$ of $Q^\mathrm{T}$ multiplies column $j$ of $Q$, the dot product is $q_i^\mathrm{T} q_j$. Off the diagonal $(i \neq j)$ that dot product is zero by orthogonality. On the diagonal $(i = j)$ the unit vectors give $q_i^\mathrm{T} q_i = \| q_i \|^2 = 1$. Often $Q$ is rectangular $(m > n)$. Sometimes $m = n$.

When Q is square,  $ Q^{\mathrm{T}}Q = I $ means that  $ Q^{\mathrm{T}} = Q^{-1} $: transpose = inverse.

If the columns are only orthogonal (not unit vectors), dot products still give a diagonal matrix (not the identity matrix). This diagonal matrix is almost as good as I. The important thing is orthogonality—then it is easy to produce unit vectors.

To repeat:  $ Q^{\mathrm{T}}Q = I $ even when  $ Q $ is rectangular. In that case  $ Q^{\mathrm{T}} $ is only an inverse from the left. For square matrices we also have  $ QQ^{\mathrm{T}} = I $, so  $ Q^{\mathrm{T}} $ is the two-sided inverse of  $ Q $. The rows of a square  $ Q $ are orthonormal like the columns. The inverse is the transpose. In this square case we call  $ Q $ an orthogonal matrix. $ ^{1} $

Here are three examples of orthogonal matrices—rotation and permutation and reflection. The quickest test is to check  $ Q^{\mathrm{T}}Q = I $.

Example 1 (Rotation)  $ Q $ rotates every vector in the plane by the angle  $ \theta $:

 $$ \boldsymbol{Q}=\begin{bmatrix}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{bmatrix}\quad and\quad\boldsymbol{Q}^{\mathrm{T}}=\boldsymbol{Q}^{-1}=\begin{bmatrix}\cos\theta&\sin\theta\\ -\sin\theta&\cos\theta\end{bmatrix}. $$ 

The columns of $Q$ are orthogonal (take their dot product). They are unit vectors because $\sin^2\theta + \cos^2\theta = 1$. Those columns give an orthonormal basis for the plane $\mathbf{R}^2$.

The standard basis vectors $i$ and $j$ are rotated through $\theta$ (see Figure 4.10a). $Q^{-1}$ rotates vectors back through $-\theta$. It agrees with $Q^{\mathrm{T}}$, because the cosine of $-\theta$ equals the cosine of $\theta$, and $\sin(-\theta) = -\sin\theta$. We have $Q^{\mathrm{T}}Q = I$ and $QQ^{\mathrm{T}} = I$.

Example 2 (Permutation) These matrices change the order to  $ (y, z, x) $ and  $ (y, x) $:

 $$ \begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{y}}} \\{{{z}}} \\{{{x}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}}\end{bmatrix}=\begin{bmatrix}{{{y}}} \\{{{x}}}\end{bmatrix}. $$ 

All columns of these  $ Q' $s are unit vectors (their lengths are obviously 1). They are also orthogonal (the 1's appear in different places). The inverse of a permutation matrix is its transpose:  $ Q^{-1} = Q^{\mathrm{T}} $. The inverse puts the components back into their original order: