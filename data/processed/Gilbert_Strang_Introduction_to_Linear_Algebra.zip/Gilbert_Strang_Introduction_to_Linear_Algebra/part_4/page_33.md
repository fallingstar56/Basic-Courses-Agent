The line  $ C + Dt $ minimizes  $ e_1^2 + \cdots + e_m^2 = \|Ax - b\|^2 $ when  $ A^\mathrm{T}A\hat{x} = A^\mathrm{T}b $:

 $$ A^{\mathrm{T}}A\widehat{\boldsymbol{x}}=A^{\mathrm{T}}\boldsymbol{b}\qquad\quad\begin{bmatrix}m&\sum t_{i}\\ \sum t_{i}&\sum t_{i}^{2}\end{bmatrix}\begin{bmatrix}C\\ D\end{bmatrix}=\begin{bmatrix}\sum b_{i}\\ \sum t_{i}b_{i}\end{bmatrix}. $$ 

The vertical errors at the $m$ points on the line are the components of $e = b - p$. This error vector (the residual) $\mathbf{b} - A\widehat{\mathbf{x}}$ is perpendicular to the columns of $A$ (geometry). The error is in the nullspace of $A^\mathrm{T}$ (linear algebra). The best $\widehat{\mathbf{x}} = (C, D)$ minimizes the total error $E$, the sum of squares (calculus):

 $$ E(\boldsymbol{x})=\left\|\boldsymbol{A}\boldsymbol{x}-\boldsymbol{b}\right\|^{2}=(C+Dt_{1}-b_{1})^{2}+\cdots+(C+Dt_{m}-b_{m})^{2}. $$ 

Calculus sets the derivatives  $ \partial E/\partial C $ and  $ \partial E/\partial D $ to zero, and produces  $ A^{\mathrm{T}}A\widehat{x}=A^{\mathrm{T}}b $.

Other least squares problems have more than two unknowns. Fitting by the best parabola has  $ n = 3 $ coefficients  $ C, D, E $ (see below). In general we are fitting  $ m $ data points by  $ n $ parameters  $ x_1, \ldots, x_n $. The matrix  $ A $ has  $ n $ columns and  $ n < m $. The derivatives of  $ \|Ax - b\|^2 $ give the  $ n $ equations  $ A^\mathrm{T}A\hat{x} = A^\mathrm{T}b $. The derivative of a square is linear. This is why the method of least squares is so popular.

## Example 2 A has orthogonal columns when the measurement times  $ t_{i} $ add to zero

Suppose $b=1,2,4$ at times $t=-2,0,2$. Those times add to zero. The columns of $A$ have zero dot product: $(1,1,1)$ is orthogonal to $(-2,0,2)$:

 $$ \begin{array}{l}C+D(-2)=1\\ C+\quad D(0)=2\\ C+\quad D(2)=4\end{array}\quad\mathrm{or}\quad\begin{array}{l}Ax=\begin{bmatrix}1&-2\\ 1&0\\ 1&2\end{bmatrix}\begin{bmatrix}C\\ D\end{bmatrix}=\begin{bmatrix}1\\ 2\\ 4\end{bmatrix}. $$ 

When the columns of A are orthogonal,  $ A^{T}A $ will be a diagonal matrix:

 $$ \begin{array}{r l r l}&{A^{\mathrm{T}}A\widehat{\boldsymbol{x}}=A^{\mathrm{T}}\boldsymbol{b}}&&{\mathrm{i s}\qquad\left[\begin{matrix}{3}&{\mathbf{0}}\\ {\mathbf{0}}&{8}\end{matrix}\right]\left[\begin{matrix}{C}\\ {D}\end{matrix}\right]=\left[\begin{matrix}{7}\\ {6}\end{matrix}\right].}\end{array} $$ 

Main point: Since  $ A^{\mathrm{T}}A $ is diagonal, we can solve separately for  $ C = \frac{7}{3} $ and  $ D = \frac{6}{8} $. The zeros in  $ A^{\mathrm{T}}A $ are dot products of perpendicular columns in  $ A $. The diagonal matrix  $ A^{\mathrm{T}}A $, with entries  $ m = 3 $ and  $ t_1^2 + t_2^2 + t_3^2 = 8 $, is virtually as good as the identity matrix.

Orthogonal columns are so helpful that it is worth shifting the times by subtracting the average time  $ \widehat{t} = (t_1 + \cdots + t_m)/m $. If the original times were 1, 3, 5 then their average is  $ \widehat{t} = 3 $. The shifted times  $ T = t - \widehat{t} = t - 3 $ add up to zero!

 $$ \begin{array}{l}T_{1}=1-3=-2\\T_{2}=3-3=\quad0\\T_{3}=5-3=\quad2\\\end{array}\qquad\begin{array}{l}A_{\mathrm{new}}=\begin{bmatrix}1&T_{1}\\1&T_{2}\\1&T_{3}\\\end{bmatrix}\qquad\begin{array}{l}A_{\mathrm{new}}^{\mathrm{T}}A_{\mathrm{new}}=\begin{bmatrix}3&\mathbf{0}\\\mathbf{0}&8\\\end{bmatrix}.\end{array} $$ 

Now $C$ and $D$ come from the easy equation (9). Then the best straight line uses $C + DT$ which is $C + D(t - \widehat{t}) = C + D(t - 3)$. Problem 30 even gives a formula for $C$ and $D$.