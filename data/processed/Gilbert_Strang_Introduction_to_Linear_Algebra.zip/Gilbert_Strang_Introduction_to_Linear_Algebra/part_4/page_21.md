Now solve the normal equation  $ A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b $ to find  $ \widehat{x} $:

 $$ \begin{bmatrix}3&3\\ 3&5\end{bmatrix}\begin{bmatrix}\widehat{x}_{1}\\ \widehat{x}_{2}\end{bmatrix}=\begin{bmatrix}6\\ 0\end{bmatrix}\quad gives\quad\widehat{\boldsymbol{x}}=\begin{bmatrix}\widehat{x}_{1}\\ \widehat{x}_{2}\end{bmatrix}=\begin{bmatrix}5\\ -3\end{bmatrix}. $$ 

The combination  $ p = A\widehat{x} $ is the projection of  $ b $ onto the column space of  $ A $:

 $$ \boldsymbol{p}=5\begin{bmatrix}1\\ 1\\ 1\end{bmatrix}-3\begin{bmatrix}0\\ 1\\ 2\end{bmatrix}=\begin{bmatrix}5\\ 2\\ -1\end{bmatrix}.\quad\mathrm{The~error~is}\quad\boldsymbol{e}=\boldsymbol{b}-\boldsymbol{p}=\begin{bmatrix}1\\ -2\\ 1\end{bmatrix}. $$ 

Two checks on the calculation. First, the error  $ e = (1, -2, 1) $ is perpendicular to both columns  $ (1, 1, 1) $ and  $ (0, 1, 2) $. Second, the matrix P times  $ \mathbf{b} = (6, 0, 0) $ correctly gives  $ \mathbf{p} = (5, 2, -1) $. That solves the problem for one particular  $ \mathbf{b} $, as soon as we find P.

The projection matrix is  $ P = A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}} $. The determinant of  $ A^{\mathrm{T}}A $ is 15 - 9 = 6; then  $ (A^{\mathrm{T}}A)^{-1} $ is easy. Multiply  $ A $ times  $ (A^{\mathrm{T}}A)^{-1} $ times  $ A^{\mathrm{T}} $ to reach  $ P $:

 $$ \left(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}\right)^{-1}=\frac{1}{6}\begin{bmatrix}{{{5}}}&{{{-3}}} \\{{{-3}}}&{{{3}}}\end{bmatrix}\quad and\quad\boldsymbol{P}=\frac{1}{6}\begin{bmatrix}{{{5}}}&{{{2}}}&{{{-1}}} \\{{{2}}}&{{{2}}}&{{{2}}} \\{{{-1}}}&{{{2}}}&{{{5}}}\end{bmatrix}. $$ 

We must have  $ P^{2}=P $, because a second projection doesn't change the first projection.

Warning The matrix  $ P = A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}} $ is deceptive. You might try to split  $ (A^{\mathrm{T}}A)^{-1} $ into  $ A^{-1} $ times  $ (A^{\mathrm{T}})^{-1} $. If you make that mistake, and substitute it into  $ P $, you will find  $ P = AA^{-1}(A^{\mathrm{T}})^{-1}A^{\mathrm{T}} $. Apparently everything cancels. This looks like  $ P = I $, the identity matrix. We want to say why this is wrong.

The matrix A is rectangular. It has no inverse matrix. We cannot split  $ (A^{\mathrm{T}}A)^{-1} $ into  $ A^{-1} $ times  $ (A^{\mathrm{T}})^{-1} $ because there is no  $ A^{-1} $ in the first place.

In our experience, a problem that involves a rectangular matrix almost always leads to  $ A^{T}A $. When A has independent columns,  $ A^{T}A $ is invertible. This fact is so crucial that we state it clearly and give a proof.

 $ A^{T}A $ is invertible if and only if A has linearly independent columns.

Proof $A^{\mathrm{T}}A$ is a square matrix ($n$ by $n$). For every matrix $A$, we will now show that $A^{\mathrm{T}}A$ has the same nullspace as $A$. When the columns of $A$ are linearly independent, its nullspace contains only the zero vector. Then $A^{\mathrm{T}}A$, with this same nullspace, is invertible.

Let $A$ be any matrix. If $x$ is in its nullspace, then $Ax = 0$. Multiplying by $A^\mathrm{T}$ gives $A^\mathrm{T}Ax = 0$. So $x$ is also in the nullspace of $A^\mathrm{T}A$.

Now start with the nullspace of  $ A^{\mathrm{T}}A $. From  $ A^{\mathrm{T}}Ax = 0 $ we must prove Ax = 0. We can't multiply by  $ (A^{\mathrm{T}})^{-1} $, which generally doesn't exist. Just multiply by  $ x^{\mathrm{T}} $:

 $$ (\boldsymbol{x}^{\mathrm{T}})\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}\boldsymbol{x}=0\quad\mathrm{o r}\quad(\boldsymbol{A}\boldsymbol{x})^{\mathrm{T}}(\boldsymbol{A}\boldsymbol{x})=0\quad\mathrm{o r}\quad\|\boldsymbol{A}\boldsymbol{x}\|^{2}=0. $$ 

We have shown: If  $ A^\top A x = 0 $ then  $ A x $ has length zero. Therefore  $ A x = 0 $. Every vector  $ x $ in one nullspace is in the other nullspace. If  $ A^\top A $ has dependent columns, so has  $ A $. If  $ A^\top A $ has independent columns, so has  $ A $. This is the good case:  $ A^\top A $ is invertible.