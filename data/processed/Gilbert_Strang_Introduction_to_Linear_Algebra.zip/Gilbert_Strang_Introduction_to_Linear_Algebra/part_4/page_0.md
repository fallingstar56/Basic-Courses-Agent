8 What are the dimensions of the four subspaces for A, B, and C, if I is the 3 by 3 identity matrix and 0 is the 3 by 2 zero matrix?

 $$ A=\begin{bmatrix}{{{I}}}&{{{0}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{I}}}&{{{I}}} \\{{{0^{\mathrm{T}}}}}&{{{0^{\mathrm{T}}}}}\end{bmatrix}\quad and\quad C=\begin{bmatrix}{{{0}}}\end{bmatrix}. $$ 

9 Which subspaces are the same for these matrices of different sizes?

(a)

 $$ \left[A\right]\text{and}\left[\begin{aligned}A\\ A\end{aligned}\right] $$ 

 $$ \begin{bmatrix}{{{A}}} \\{{{A}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{A}}}&{{{A}}} \\{{{A}}}&{{{A}}}\end{bmatrix}. $$ 

Prove that all three of those matrices have the same rank r.

If the entries of a 3 by 3 matrix are chosen randomly between 0 and 1, what are the most likely dimensions of the four subspaces? What if the random matrix is 3 by 5?

11 (Important) A is an m by n matrix of rank r. Suppose there are right sides b for which Ax = b has no solution.

(a) What are all inequalities (< or ≤) that must be true between m, n, and r?

(b) How do you know that  $ A^{T}y = 0 $ has solutions other than y = 0?

Construct a matrix with  $ (1,0,1) $ and  $ (1,2,0) $ as a basis for its row space and its column space. Why can't this be a basis for the row space and nullspace?

13 True or false (with a reason or a counterexample):

(a) If m = n then the row space of A equals the column space.

(b) The matrices A and -A share the same four subspaces.

(c) If A and B share the same four subspaces then A is a multiple of B.

14 Without computing A, find bases for its four fundamental subspaces:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{6}}}&{{{1}}}&{{{0}}} \\{{{9}}}&{{{8}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{2}}}\end{bmatrix}. $$ 

If you exchange the first two rows of A, which of the four subspaces stay the same? If  $ v = (1, 2, 3, 4) $ is in the left nullspace of A, write down a vector in the left nullspace of the new matrix after the row exchange.

16 Explain why  $  v = (1, 0, -1)  $ cannot be a row of A and also in the nullspace.

17 Describe the four subspaces of  $ R^{3} $ associated with

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{I}+\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 