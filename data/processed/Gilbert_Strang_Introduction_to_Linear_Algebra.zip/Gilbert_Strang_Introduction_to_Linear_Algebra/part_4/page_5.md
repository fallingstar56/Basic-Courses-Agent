Every vector x in the nullspace is perpendicular to every row of A, because Ax = 0. The nullspace N(A) and the row space C(A^{T}) are orthogonal subspaces of R^{n}.

To see why x is perpendicular to the rows, look at Ax = 0. Each row multiplies x:

 $$ \begin{aligned}&Ax=\begin{bmatrix}\\ &row1&&\\&\vdots&\\&row m&\\ &\end{bmatrix}\begin{bmatrix}\\ &x\\ &\end{bmatrix}=\begin{bmatrix}\\ &0\\ \vdots\\ &0\\ &\end{bmatrix}\quad\begin{aligned}\\ &\longleftarrow&(row1)\cdot x is zero\\&\longleftarrow&(row m)\cdot x is zero\\ &\end{aligned}\\ \end{aligned} $$ 

The first equation says that row 1 is perpendicular to x. The last equation says that row m is perpendicular to x. Every row has a zero dot product with x. Then x is also perpendicular to every combination of the rows. The whole row space  $ C(A^{\mathrm{T}}) $ is orthogonal to  $ N(A) $.

Here is a second proof of that orthogonality for readers who like matrix shorthand. The vectors in the row space are combinations  $ A^{\mathrm{T}}y $ of the rows. Take the dot product of  $ A^{\mathrm{T}}y $ with any x in the nullspace. These vectors are perpendicular:

Nullspace orthogonal to row space

 $$ \boldsymbol{x}^{\mathrm{T}}(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{y})=(\boldsymbol{A}\boldsymbol{x})^{\mathrm{T}}\boldsymbol{y}=\mathbf{0}^{\mathrm{T}}\boldsymbol{y}=0. $$ 

We like the first proof. You can see those rows of A multiplying x to produce zeros in equation (1). The second proof shows why A and  $ A^{T} $ are both in the Fundamental Theorem.

Example 3 The rows of A are perpendicular to  $ \boldsymbol{x} = (1, 1, -1) $ in the nullspace:

 $$ \boldsymbol{A}\boldsymbol{x}=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{4}}} \\{{{5}}}&{{{2}}}&{{{7}}}\end{bmatrix}\begin{vmatrix}{{{1}}} \\{{{1}}} \\{{{-1}}}\end{vmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}}\end{bmatrix}\quad gives the dot products\quad1+3-4=0\quad5+2-7=0 $$ 

Now we turn to the other two subspaces. In this example, the column space is all of  $ \mathbf{R}^2 $. The nullspace of  $ \mathbf{A}^\top $ is only the zero vector (orthogonal to every vector). The column space of  $ \mathbf{A} $ and the nullspace of  $ \mathbf{A}^\top $ are always orthogonal subspaces.

Every vector y in the nullspace of  $ A^{T} $ is perpendicular to every column of A. The left nullspace  $ N(A^{T}) $ and the column space  $ C(A) $ are orthogonal in  $ R^{m} $.

Apply the original proof to  $ A^{T} $. The nullspace of  $ A^{T} $ is orthogonal to the row space of  $ A^{T} $—and the row space of  $ A^{T} $ is the column space of A. Q.E.D.

For a visual proof, look at  $ A^{\mathrm{T}}y = 0 $. Each column of A multiplies y to give 0:

 $$ C(\boldsymbol{A})\perp\boldsymbol{N}(\boldsymbol{A}^{\mathrm{T}}) $$ 

 $$ \boldsymbol{A}^{\mathrm{T}}\boldsymbol{y}=\left[\begin{array}{c}(\mathbf{c o l u m n}\mathbf{1})^{\mathrm{T}}\\ \cdots\\ (\mathbf{c o l u m n}\mathbf{n})^{\mathrm{T}}\end{array}\right]\left[\begin{array}{l}\boldsymbol{y}\\ \end{array}\right]=\left[\begin{array}{l}0\\ \cdot\\ 0\end{array}\right]. $$ 

The dot product of y with every column of A is zero. Then y in the left nullspace is perpendicular to each column of A—and to the whole column space.