### 4.3 Least Squares Approximations

1 Solving  $ \boxed{A^{\mathrm{T}}A\widehat{x}=A^{\mathrm{T}}b} $ gives the projection  $ p=A\widehat{x} $ of  $ b $ onto the column space of  $ A $.

2 When  $ Ax=b $ has no solution,  $ \widehat{x} $ is the “least-squares solution”:  $ \|b-A\widehat{x}\|^2= $ minimum.

3 Setting partial derivatives of  $ E=||Ax-b||^2 $ to zero  $ \left(\frac{\partial E}{\partial x_i}=0\right) $ also produces  $ A^{\mathrm{T}}A\widehat{x}=A^{\mathrm{T}}b $.

4 To fit points  $ (t_1,b_1),\ldots,(t_m,b_m) $ by a straight line,  $ A $ has columns  $ (1,\ldots,1) $ and  $ (t_1,\ldots,t_m) $.

5 In that case  $ A^{\mathrm{T}}A $ is the 2 by 2 matrix  $ \left[\begin{array}{cc}m&\sum t_i\\ \sum t_i&\sum t_i^2\end{array}\right] $ and  $ A^{\mathrm{T}}b $ is the vector  $ \left[\begin{array}{c}\sum b_i\\ \sum t_i b_i\end{array}\right] $.

It often happens that  $ Ax = b $ has no solution. The usual reason is: too many equations. The matrix A has more rows than columns. There are more equations than unknowns (m is greater than n). The n columns span a small part of m-dimensional space. Unless all measurements are perfect, b is outside that column space of A. Elimination reaches an impossible equation and stops. But we can't stop just because measurements include noise!

To repeat: We cannot always get the error  $ e = b - Ax $ down to zero. When  $ e $ is zero,  $ x $ is an exact solution to  $ Ax = b $. When the length of  $ e $ is as small as possible,  $ \widehat{x} $ is a least squares solution. Our goal in this section is to compute  $ \widehat{x} $ and use it. These are real problems and they need an answer.

The previous section emphasized $p$ (the projection). This section emphasizes $\widehat{x}$ (the least squares solution). They are connected by $p = A\widehat{x}$. The fundamental equation is still $A^{\mathrm{T}}A\widehat{x} = A^{\mathrm{T}}b$. Here is a short unofficial way to reach this “normal equation”:

When Ax = b has no solution, multiply by  $ A^{T} $ and solve  $ A^{T}Ax = A^{T}b $.

Example 1 A crucial application of least squares is fitting a straight line to m points. Start with three points: Find the closest line to the points  $ (0,6) $,  $ (1,0) $, and  $ (2,0) $.

No straight line  $ b = C + Dt $ goes through those three points. We are asking for two numbers C and D that satisfy three equations: n = 2 and m = 3. Here are the three equations at t = 0, 1, 2 to match the given values b = 6, 0, 0:

 $$ t=0\qquad\mathrm{T h e~f i r s t~p o i n t~i s~o n~t h e~l i n e~}b=C+D t\mathrm{~i f~}\qquad C+D\cdot0=6 $$ 

 $$ \text{ⅰ}he second point is on the line b=C+Dt if\qquad C+D\cdot1=0 $$ 

 $$ t=2\qquad\mathrm{T h e~t h i r d~p o i n t~i s~o n~t h e~l i n e~}b=C+D t\mathrm{~i f~}\qquad C+D\cdot2=0. $$ 