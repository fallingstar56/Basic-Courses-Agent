2 Draw the projection of b onto a and also compute it from  $ p = \hat{x}a $:

 $$ \begin{aligned}a)b=\begin{bmatrix}\cos\theta\\ \sin\theta\end{bmatrix}\quad and\quad a=\begin{bmatrix}1\\ 0\end{bmatrix}\quad&(b)\quad b=\begin{bmatrix}1\\ 1\end{bmatrix}\quad and\quad a=\begin{bmatrix}1\\ -1\end{bmatrix}.\end{aligned} $$ 

3 In Problem 1, find the projection matrix  $ P = aa^{\mathrm{T}} / a^{\mathrm{T}} a $ onto the line through each vector  $ a $. Verify in both cases that  $ P^{2} = P $. Multiply  $ Pb $ in each case to compute the projection  $ p $.

4 Construct the projection matrices  $ P_1 $ and  $ P_2 $ onto the lines through the  $ a $'s in Problem 2. Is it true that  $ (P_1 + P_2)^2 = P_1 + P_2 $? This would be true if  $ P_1P_2 = 0 $.

5 Compute the projection matrices  $ a\boldsymbol{a}^{\mathrm{T}}/\boldsymbol{a}^{\mathrm{T}}\boldsymbol{a} $ onto the lines through  $ \boldsymbol{a}_{1}=(-1,2,2) $ and  $ \boldsymbol{a}_{2}=(2,2,-1) $. Multiply those projection matrices and explain why their product  $ P_{1}P_{2} $ is what it is.

6 Project  $ b = (1, 0, 0) $ onto the lines through  $ a_{1} $ and  $ a_{2} $ in Problem 5 and also onto  $ a_{3} = (2, -1, 2) $. Add up the three projections  $ p_{1} + p_{2} + p_{3} $.

7 Continuing Problems 5–6, find the projection matrix  $ P_3 $ onto  $ a_3 = (2, -1, 2) $. Verify that  $ P_1 + P_2 + P_3 = I $. This is because the basis  $ a_1, a_2, a_3 $ is orthogonal!

<div style="text-align: center;"><img src="imgs/img_in_image_box_205_599_534_840.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_615_606_840_834.jpg" alt="Image" width="21%" /></div>


Questions 5–6–7: orthogonal

Questions 8–9–10: not orthogonal

8 Project the vector  $ b = (1, 1) $ onto the lines through  $ a_1 = (1, 0) $ and  $ a_2 = (1, 2) $. Draw the projections  $ p_1 $ and  $ p_2 $ and add  $ p_1 + p_2 $. The projections do not add to  $ b $ because the  $ a $'s are not orthogonal.

9 In Problem 8, the projection of $b$ onto the plane of $a_1$ and $a_2$ will equal $b$. Find $P = A(A^\mathrm{T}A)^{-1}A^\mathrm{T}$ for $A = \begin{bmatrix} a_1 & a_2 \end{bmatrix} = \begin{bmatrix} 1 & 1 \\ 0 & 2 \end{bmatrix} = \text{invertible matrix}$.

Project $a_{1} = (1, 0)$ onto $a_{2} = (1, 2)$. Then project the result back onto $a_{1}$. Draw these projections and multiply the projection matrices $P_{1}P_{2}$: Is this a projection?