The separate projections of  $  b = (0, 0, 1)  $ onto  $  q_1  $ and  $  q_2  $ and  $  q_3  $ are  $  p_1  $ and  $  p_2  $ and  $  p_3  $:

 $$ \boldsymbol{q}_{1}(\boldsymbol{q}_{1}^{\mathrm{T}}\boldsymbol{b})=\frac{2}{3}\boldsymbol{q}_{1}\quad\mathrm{a n d}\quad\boldsymbol{q}_{2}(\boldsymbol{q}_{2}^{\mathrm{T}}\boldsymbol{b})=\frac{2}{3}\boldsymbol{q}_{2}\quad\mathrm{a n d}\quad\boldsymbol{q}_{3}(\boldsymbol{q}_{3}^{\mathrm{T}}\boldsymbol{b})=-\frac{1}{3}\boldsymbol{q}_{3}. $$ 

The sum of the first two is the projection of $b$ onto the plane of $q_{1}$ and $q_{2}$. The sum of all three is the projection of $b$ onto the whole space—which is $p_{1} + p_{2} + p_{3} = b$ itself:

 $$ \begin{aligned}\mathbf{Reconstruct}\boldsymbol{b}\quad&\quad\frac{2}{3}\boldsymbol{q}_{1}+\frac{2}{3}\boldsymbol{q}_{2}-\frac{1}{3}\boldsymbol{q}_{3}=\frac{1}{9}\begin{bmatrix}-2+4-2\\ 4-2-2\\ 4+4+1\end{bmatrix}=\begin{bmatrix}0\\ 0\\ 1\end{bmatrix}=\boldsymbol{b}.\end{aligned} $$ 

## The Gram-Schmidt Process

The point of this section is that “orthogonal is good”. Projections and least squares always involve  $ A^{\mathrm{T}}A $. When this matrix becomes  $ Q^{\mathrm{T}}Q = I $, the inverse is no problem. The one-dimensional projections are uncoupled. The best  $ \hat{x} $ is  $ Q^{\mathrm{T}}b $ (just  $ n $ separate dot products). For this to be true, we had to say “If the vectors are orthonormal”. Now we explain the “Gram-Schmidt way” to create orthonormal vectors.

Start with three independent vectors  $ a, b, c $. We intend to construct three orthogonal vectors  $ A, B, C $. Then (at the end may be easiest) we divide  $ A, B, C $ by their lengths. That produces three orthonormal vectors  $ q_1 = A / \| A \| $,  $ q_2 = B / \| B \| $,  $ q_3 = C / \| C \| $.

Gram-Schmidt Begin by choosing A = a. This first direction is accepted as it comes. The next direction B must be perpendicular to A. Start with b and subtract its projection along A. This leaves the perpendicular part, which is the orthogonal vector B:

First Gram-Schmidt step

 $$ \boldsymbol{B}=\boldsymbol{b}-\frac{\boldsymbol{A}^{\mathrm{T}}\boldsymbol{b}}{\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}}\boldsymbol{A}. $$ 

A and B are orthogonal in Figure 4.11. Multiply equation (7) by  $ A^{\mathrm{T}} $ to verify that  $ A^{\mathrm{T}}B = A^{\mathrm{T}}b - A^{\mathrm{T}}b = 0 $. This vector B is what we have called the error vector e, perpendicular to A. Notice that B in equation (7) is not zero (otherwise a and b would be dependent). The directions A and B are now set.

The third direction starts with c. This is not a combination of A and B (because c is not a combination of a and b). But most likely c is not perpendicular to A and B. So subtract off its components in those two directions to get a perpendicular direction C:

Next Gram-Schmidt step

 $$ C=c-\frac{A^{\mathrm{T}}c}{A^{\mathrm{T}}A}A-\frac{B^{\mathrm{T}}c}{B^{\mathrm{T}}B}B. $$ 

This is the one and only idea of the Gram-Schmidt process. Subtract from every new vector its projections in the directions already set. That idea is repeated at every step. $ ^{2} $ If we had a fourth vector d, we would subtract three projections onto A, B, C to get D.