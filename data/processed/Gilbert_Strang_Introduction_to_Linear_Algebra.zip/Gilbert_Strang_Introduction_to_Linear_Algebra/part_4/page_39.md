Project $b = (0, 8, 8, 20)$ onto the line through $a = (1, 1, 1, 1)$. Find $\widehat{x} = a^{\mathrm{T}}b/a^{\mathrm{T}}a$ and the projection $p = \widehat{x}a$. Check that $e = b - p$ is perpendicular to $a$, and find the shortest distance $\|e\|$ from $b$ to the line through $a$.

7 Find the closest line $b = Dt$, through the origin, to the same four points. An exact fit would solve $D \cdot 0 = 0$, $D \cdot 1 = 8$, $D \cdot 3 = 8$, $D \cdot 4 = 20$. Find the 4 by 1 matrix and solve $A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b$. Redraw Figure 4.9a showing the best line $b = Dt$ and the $e's$.

8 Project $b = (0, 8, 8, 20)$ onto the line through $a = (0, 1, 3, 4)$. Find $\widehat{x} = D$ and $p = \widehat{x}a$. The best $C$ in Problems 5–6 and the best $D$ in Problems 7–8 do not agree with the best $(C, D)$ in Problems 1–4. That is because $(1, 1, 1, 1)$ and $(0, 1, 3, 4)$ are ___ perpendicular.

9 For the closest parabola $b = C + Dt + Et^{2}$ to the same four points, write down the unsolvable equations $Ax = b$ in three unknowns $x = (C, D, E)$. Set up the three normal equations $A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b$ (solution not required). In Figure 4.9a you are now fitting a parabola to 4 points—what is happening in Figure 4.9b?

10 For the closest cubic $b = C + Dt + Et^{2} + Ft^{3}$ to the same four points, write down the four equations $Ax = b$. Solve them by elimination. In Figure 4.9a this cubic now goes exactly through the points. What are $p$ and $e$?

11 The average of the four times is  $ \widehat{t} = \frac{1}{4}(0 + 1 + 3 + 4) = 2 $. The average of the four b's is  $ \widehat{b} = \frac{1}{4}(0 + 8 + 8 + 20) = 9 $.

(a) Verify that the best line goes through the center point  $ \widehat{t}, \widehat{b} = (2, 9) $.

(b) Explain why  $ C + D\widehat{t} = \widehat{b} $ comes from the first equation in  $ A^{\mathrm{T}} A\widehat{x} = A^{\mathrm{T}} b $.

## Questions 12–16 introduce basic ideas of statistics—the foundation for least squares

12 (Recommended) This problem projects  $ b = (b_{1}, \ldots, b_{m}) $ onto the line through  $ a = (1, \ldots, 1) $. We solve m equations  $ a x = b $ in 1 unknown (by least squares).

(a) Solve  $ a^{\mathrm{T}}a\hat{x}=a^{\mathrm{T}}b $ to show that  $ \hat{x} $ is the mean (the average) of the  $ b $'s.

(b) Find  $ e = b - a\widehat{x} $ and the variance  $ \|e\|^2 $ and the standard deviation  $ \|e\| $.

(c) The horizontal line  $ \hat{b} = 3 $ is closest to  $ b = (1, 2, 6) $. Check that  $ p = (3, 3, 3) $ is perpendicular to e and find the 3 by 3 projection matrix P.

First assumption behind least squares:  $ Ax = b - (noise\ e\ with\ mean\ zero) $. Multiply the error vectors  $ e = b - Ax $ by  $ (A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}} $ to get  $ \widehat{x} - x $ on the right. The estimation errors  $ \widehat{x} - x $ also average to zero. The estimate  $ \widehat{x} $ is unbiased.

Second assumption behind least squares: The $m$ errors $e_i$ are independent with variance $\sigma^2$, so the average of $(b - Ax)(b - Ax)^\mathrm{T}$ is $\sigma^2 I$. Multiply on the left by $(A^\mathrm{T} A)^{-1} A^\mathrm{T}$ and on the right by $A(A^\mathrm{T} A)^{-1}$ to show that the average matrix $(\widehat{x} - x)(\widehat{x} - x)^\mathrm{T}$ is $\sigma^2(A^\mathrm{T} A)^{-1}$. This is the covariance matrix $W$ in Section 10.2.