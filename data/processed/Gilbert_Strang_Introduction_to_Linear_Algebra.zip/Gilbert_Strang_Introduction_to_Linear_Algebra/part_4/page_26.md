23 If $A$ is square and invertible, the warning against splitting $(A^{\mathrm{T}}A)^{-1}$ does not apply. It is true that $AA^{-1}(A^{\mathrm{T}})^{-1}A^{\mathrm{T}} = I$. When $A$ is invertible, why is $P = I$? What is the error $e$?

24 The nullspace of  $ A^{\mathrm{T}} $ is ___ to the column space  $ \boldsymbol{C}(A) $. So if  $ A^{\mathrm{T}}b = 0 $, the projection of b onto  $ \boldsymbol{C}(A) $ should be  $ p = \_\_\_\_\_ $. Check that  $ P = A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}} $ gives this answer.

25 The projection matrix P onto an $n$-dimensional subspace of $\mathbf{R}^m$ has rank $r = n$. Reason: The projections $Pb$ fill the subspace $S$. So $S$ is the ___ of $P$.

If an m by m matrix has  $ A^{2} = A $ and its rank is m, prove that A = I.

The important fact that ends the section is this: If  $ A^{T}Ax = 0 $ then  $ Ax = 0 $. New Proof: The vector  $ Ax $ is in the nullspace of ___.  $ Ax $ is always in the column space of ___. To be in both of those perpendicular spaces,  $ Ax $ must be zero.

Use  $ P^{T} = P $ and  $ P^{2} = P $ to prove that the length squared of column 2 always equals the diagonal entry  $ P_{22} $. This number is  $ \frac{2}{6} = \frac{4}{36} + \frac{4}{36} + \frac{4}{36} $ for

 $$ P=\frac{1}{6}\begin{bmatrix}{{{5}}}&{{{2}}}&{{{-1}}} \\{{{2}}}&{{{2}}}&{{{2}}} \\{{{-1}}}&{{{2}}}&{{{5}}}\end{bmatrix}. $$ 

If $B$ has rank $m$ (full row rank, independent rows) show that $BB^{\mathrm{T}}$ is invertible.

## Challenge Problems

(a) Find the projection matrix  $ P_{C} $ onto the column space of A (after looking closely at the matrix!)

 $$ \boldsymbol{A}=\left[\begin{array}{lll}{{{3}}}&{{{6}}}&{{{6}}} \\{{{4}}}&{{{8}}}&{{{8}}}\end{array}\right] $$ 

(b) Find the 3 by 3 projection matrix  $ P_R $ onto the row space of  $ A $. Multiply  $ B = P_CAP_R $. Your answer  $ B $ should be a little surprising—can you explain it?

In  $ \mathbf{R}^m $, suppose I give you  $ b $ and also a combination  $ p $ of  $ a_1, \ldots, a_n $. How would you test to see if  $ p $ is the projection of  $ b $ onto the subspace spanned by the  $ a $'s?

Suppose  $ P_1 $ is the projection matrix onto the 1-dimensional subspace spanned by the first column of  $ A $. Suppose  $ P_2 $ is the projection matrix onto the 2-dimensional column space of  $ A $. After thinking a little, compute the product  $ P_2P_1 $.

 $$ \boldsymbol{A}=\left[\begin{array}{ll}{{{1}}}&{{{0}}} \\{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{array}\right]. $$ 