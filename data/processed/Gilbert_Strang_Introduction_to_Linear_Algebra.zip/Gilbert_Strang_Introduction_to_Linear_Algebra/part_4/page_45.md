## Projections Using Orthonormal Bases: Q Replaces A

Orthogonal matrices are excellent for computations—numbers can never grow too large when lengths of vectors are fixed. Stable computer codes use Q's as much as possible.

For projections onto subspaces, all formulas involve  $ A^T A $. The entries of  $ A^T A $ are the dot products  $ a_i^T a_j $ of the basis vectors  $ a_1, \ldots, a_n $.

Suppose the basis vectors are actually orthonormal. The $a$'s become the $q$'s. Then $A^{\mathrm{T}}A$ simplifies to $Q^{\mathrm{T}}Q = I$. Look at the improvements in $\widehat{x}$ and $p$ and $P$. Instead of $Q^{\mathrm{T}}Q$ we print a blank for the identity matrix:

 $$ \underline{\quad}\widehat{\boldsymbol{x}}=\boldsymbol{Q}^{\mathrm{T}}\boldsymbol{b}\quad\mathrm{a n d}\quad\boldsymbol{p}=\boldsymbol{Q}\widehat{\boldsymbol{x}}\quad\mathrm{a n d}\quad\boldsymbol{P}=\boldsymbol{Q}\underline{\quad}\boldsymbol{Q}^{\mathrm{T}}. $$ 

The least squares solution of  $ Qx = b $ is  $ \hat{x} = Q^{\mathrm{T}}b $. The projection matrix is  $ QQ^{\mathrm{T}} $.

There are no matrices to invert. This is the point of an orthonormal basis. The best  $ \widehat{x} = Q^{\mathrm{T}}b $ just has dot products of  $ q_1, \ldots, q_n $ with  $ b $. We have 1-dimensional projections! The “coupling matrix” or “correlation matrix”  $ A^{\mathrm{T}}A $ is now  $ Q^{\mathrm{T}}Q = I $. There is no coupling. When  $ A $ is  $ Q $, with orthonormal columns, here is  $ p = Q\widehat{x} = QQ^{\mathrm{T}}b $:

Projection onto q's

 $$ \boldsymbol{p}=\begin{bmatrix}|\quad&\quad|\quad\\ q_{1}&\cdots&q_{n}\\\end{bmatrix}\begin{bmatrix}\boldsymbol{q}_{1}^{\mathrm{T}}\boldsymbol{b}\\\vdots\\\boldsymbol{q}_{n}^{\mathrm{T}}\boldsymbol{b}\\\end{bmatrix}=\boldsymbol{q}_{1}(\boldsymbol{q}_{1}^{\mathrm{T}}\boldsymbol{b})+\cdots+\boldsymbol{q}_{n}(\boldsymbol{q}_{n}^{\mathrm{T}}\boldsymbol{b}). $$ 

Important case: When $Q$ is square and $m = n$, the subspace is the whole space. Then $Q^{\mathrm{T}} = Q^{-1}$ and $\widehat{x} = Q^{\mathrm{T}}b$ is the same as $x = Q^{-1}b$. The solution is exact! The projection of $b$ onto the whole space is $b$ itself. In this case $p = b$ and $P = QQ^{\mathrm{T}} = I$.

You may think that projection onto the whole space is not worth mentioning. But when $p = b$, our formula assembles $b$ out of its 1-dimensional projections. If $q_1, \ldots, q_n$ is an orthonormal basis for the whole space, then $Q$ is square. Every $b = QQ^\mathrm{T}b$ is the sum of its components along the $q$'s:

 $$ \boldsymbol{b}=\boldsymbol{q}_{1}(\boldsymbol{q}_{1}^{\mathrm{T}}\boldsymbol{b})+\boldsymbol{q}_{2}(\boldsymbol{q}_{2}^{\mathrm{T}}\boldsymbol{b})+\cdots+\boldsymbol{q}_{n}(\boldsymbol{q}_{n}^{\mathrm{T}}\boldsymbol{b}). $$ 

Transforms  $ QQ^{\mathrm{T}} = I $ is the foundation of Fourier series and all the great “transforms” of applied mathematics. They break vectors  $ \boldsymbol{b} $ or functions  $ f(x) $ into perpendicular pieces. Then by adding the pieces in (6), the inverse transform puts  $ \boldsymbol{b} $ and  $ f(x) $ back together.

Example 4 The columns of this orthogonal Q are orthonormal vectors  $ q_{1}, q_{2}, q_{3} $:

 $$ \boldsymbol{m}=\boldsymbol{n}=\mathbf{3}\qquad\boldsymbol{Q}=\frac{1}{3}\begin{bmatrix}{{{-1}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{-1}}}&{{{2}}} \\{{{2}}}&{{{2}}}&{{{-1}}}\end{bmatrix}\quad has\quad\boldsymbol{Q}^{\mathrm{T}}\boldsymbol{Q}=\boldsymbol{Q}\boldsymbol{Q}^{\mathrm{T}}=\boldsymbol{I}. $$ 