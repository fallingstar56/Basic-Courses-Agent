#### 4.2. Projections

The combination  $ p = \widehat{x}_1 a_1 + \cdots + \widehat{x}_n a_n = A\widehat{x} $ that is closest to  $ b $ comes from  $ \widehat{x} $:

Find

 $$ \hat{x}\left(n\times1\right) $$ 

 $$ (n\times1)\quad A^{\mathrm{T}}(\boldsymbol{b}-A\widehat{\boldsymbol{x}})=\mathbf{0}\quad or\quad A^{\mathrm{T}}A\widehat{\boldsymbol{x}}=A^{\mathrm{T}}\boldsymbol{b}. $$ 

This symmetric matrix  $ A^{\mathrm{T}}A $ is n by n. It is invertible if the  $ a $'s are independent. The solution is  $ \widehat{x} = (A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}}b $. The projection of b onto the subspace is p:

Find  $ p(m \times 1) $

 $$ \boldsymbol{p}=A\widehat{\boldsymbol{x}}=A(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A})^{-1}\boldsymbol{A}^{\mathrm{T}}\boldsymbol{b}. $$ 

The next formula picks out the projection matrix that is multiplying b in (6):

Find  $ P(m \times m) $

 $$ \boldsymbol{P}=\boldsymbol{A}(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A})^{-1}\boldsymbol{A}^{\mathrm{T}}. $$ 

Compare with projection onto a line, when A has only one column: A^{T}A is a^{T}a.

 $$ \mathrm{For~}n=1\qquad\widehat{x}=\frac{a^{\mathrm{T}}b}{a^{\mathrm{T}}a}\quad\mathrm{and}\quad p=a\frac{a^{\mathrm{T}}b}{a^{\mathrm{T}}a}\quad\mathrm{and}\quad P=\frac{a a^{\mathrm{T}}}{a^{\mathrm{T}}a}. $$ 

Those formulas are identical with (5) and (6) and (7). The number  $ a^{\mathrm{T}}a $ becomes the matrix  $ A^{\mathrm{T}}A $. When it is a number, we divide by it. When it is a matrix, we invert it. The new formulas contain  $ (A^{\mathrm{T}}A)^{-1} $ instead of  $ 1/a^{\mathrm{T}}a $. The linear independence of the columns  $ a_{1},\ldots,a_{n} $ will guarantee that this inverse matrix exists.

The key step was  $ A^\mathrm{T}(b - A\widehat{x}) = 0 $. We used geometry (e is orthogonal to each  $ \boldsymbol{a} $). Linear algebra gives this “normal equation” too, in a very quick and beautiful way:

1. Our subspace is the column space of A.

2. The error vector  $ b - A\hat{x} $ is perpendicular to that column space.

3. Therefore  $ b - A\widehat{x} $ is in the nullspace of  $ A^{\mathrm{T}} $! This means  $ A^{\mathrm{T}}(b - A\widehat{x}) = 0 $.

The left nullspace is important in projections. That nullspace of  $ A^{\mathrm{T}} $ contains the error vector  $ e = b - A\hat{x} $. The vector  $ b $ is being split into the projection  $ p $ and the error  $ e = b - p $. Projection produces a right triangle with sides  $ p, e $, and  $ b $.

Example 3 If  $ A = \begin{bmatrix} 1 & 0 \\ 1 & 1 \\ 1 & 2 \end{bmatrix} $ and  $ b = \begin{bmatrix} 6 \\ 0 \\ 0 \end{bmatrix} $ find  $ \hat{x} $ and  $ p $ and  $ P $.

Solution Compute the square matrix  $ A^{T}A $ and also the vector  $ A^{T}b $:

 $$ \boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}\end{bmatrix}=\begin{bmatrix}{{{3}}}&{{{3}}} \\{{{3}}}&{{{5}}}\end{bmatrix}\quad and\quad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{b}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{2}}}\end{bmatrix}\begin{bmatrix}{{{6}}} \\{{{0}}} \\{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{6}}} \\{{{0}}}\end{bmatrix}. $$ 