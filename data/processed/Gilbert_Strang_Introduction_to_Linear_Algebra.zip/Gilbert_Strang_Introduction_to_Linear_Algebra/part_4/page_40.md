15 A doctor takes 4 readings of your heart rate. The best solution to  $ x = b_1, \ldots, x = b_4 $ is the average  $ \widehat{x} $ of  $ b_1, \ldots, b_4 $. The matrix  $ A $ is a column of  $ 1 $'s. Problem 14 gives the expected error  $ (\widehat{x} - x)^2 $ as  $ \sigma^2(A^\mathrm{T}A)^{-1} = $ ___. By averaging, the variance drops from  $ \sigma^2 $ to  $ \sigma^2/4 $.

16 If you know the average  $ \widehat{x}_{9} $ of 9 numbers  $ b_{1}, \ldots, b_{9} $, how can you quickly find the average  $ \widehat{x}_{10} $ with one more number  $ b_{10} $? The idea of recursive least squares is to avoid adding 10 numbers. What number multiplies  $ \widehat{x}_{9} $ in computing  $ \widehat{x}_{10} $?

 $$ \widehat{x}_{10}=\frac{1}{10}b_{10}+\underline{\quad}\widehat{x}_{9}=\frac{1}{10}(b_{1}+\cdots+b_{10})\quad as in Worked Example 4.2 C. $$ 

## Questions 17–24 give more practice with  $ \hat{x} $ and p and e

17 Write down three equations for the line $b = C + Dt$ to go through $b = 7$ at $t = -1$, $b = 7$ at $t = 1$, and $b = 21$ at $t = 2$. Find the least squares solution $\hat{x} = (C, D)$ and draw the closest line.

18 Find the projection  $ p = A\widehat{x} $ in Problem 17. This gives the three heights of the closest line. Show that the error vector is  $ \boldsymbol{e} = (2, -6, 4) $. Why is  $ Pe = 0 $?

19 Suppose the measurements at $t = -1, 1, 2$ are the errors $2, -6, 4$ in Problem 18. Compute $\hat{x}$ and the closest line to these new measurements. Explain the answer: $b = (2, -6, 4)$ is perpendicular to ___ so the projection is $p = 0$.

20 Suppose the measurements at $t = -1, 1, 2$ are $b = (5, 13, 17)$. Compute $\hat{x}$ and the closest line and $e$. The error is $e = 0$ because this $b$ is ___.

21 Which of the four subspaces contains the error vector e? Which contains p? Which contains  $ \hat{x} $? What is the nullspace of A?

22 Find the best line  $ C + Dt $ to fit b = 4, 2, -1, 0, 0 at times t = -2, -1, 0, 1, 2.

Is the error vector $e$ orthogonal to $b$ or $p$ or $e$ or $\hat{x}$? Show that $\|e\|^{2}$ equals $e^{\mathrm{T}}b$ which equals $b^{\mathrm{T}}b - p^{\mathrm{T}}b$. This is the smallest total error $E$.

24 The partial derivatives of  $ \|Ax\|^2 $ with respect to  $ x_1, \ldots, x_n $ fill the vector  $ 2A^\mathrm{T}Ax $. The derivatives of  $ 2b^\mathrm{T}Ax $ fill the vector  $ 2A^\mathrm{T}b $. So the derivatives of  $ \|Ax - b\|^2 $ are zero when ___.

## Challenge Problems

What condition on $(t_{1}, b_{1}), (t_{2}, b_{2}), (t_{3}, b_{3})$ puts those three points onto a straight line? A column space answer is: $(b_{1}, b_{2}, b_{3})$ must be a combination of $(1, 1, 1)$ and $(t_{1}, t_{2}, t_{3})$. Try to reach a specific equation connecting the $t$'s and $b$'s. I should have thought of this question sooner!