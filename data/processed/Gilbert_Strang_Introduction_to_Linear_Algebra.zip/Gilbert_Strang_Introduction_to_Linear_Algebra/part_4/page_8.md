<div style="text-align: center;"><img src="imgs/img_in_image_box_157_123_853_550.jpg" alt="Image" width="65%" /></div>


<div style="text-align: center;">Figure 4.3: This update of Figure 4.2 shows the true action of A on  $ \boldsymbol{x} = \boldsymbol{x}_r + \boldsymbol{x}_n $. Row space vector  $ \boldsymbol{x}_r $ to column space, nullspace vector  $ \boldsymbol{x}_n $ to zero.</div>


## Drawing the Big Picture

I don’t know the best way to draw the four subspaces in Figures 4.2 and 4.3. This big picture has to show the orthogonality of those subspaces. I can see a possible way to do it when a line meets a plane—maybe Figure 4.4 also shows that those spaces are infinite, more clearly than the rectangles in Figure 4.3. But how do I draw a pair of two-dimensional subspaces in  $ R^{4} $, to show they are orthogonal to each other? Good ideas are welcome.

<div style="text-align: center;"><img src="imgs/img_in_image_box_174_841_813_1075.jpg" alt="Image" width="59%" /></div>


<div style="text-align: center;">Figure 4.4: Row space of A = plane. Nullspace = orthogonal line. Dimensions  $ 2 + 1 = 3 $.</div>
