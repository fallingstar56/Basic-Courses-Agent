(Left nullspace) Add the extra column b and reduce A to echelon form:

 $$ \begin{aligned}\left[\begin{array}{l l}{{{A}}}&{{{b}}}\end{array}\right]&=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}}&{{{b_{1}}}} \\{{{4}}}&{{{5}}}&{{{6}}}&{{{b_{2}}}} \\{{{7}}}&{{{8}}}&{{{9}}}&{{{b_{3}}}}\end{bmatrix}&\rightarrow&\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}}&{{{b_{1}}}} \\{{{0}}}&{{{-3}}}&{{{-6}}}&{{{b_{2}-4b_{1}}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{b_{3}-2b_{2}+b_{1}}}}\end{bmatrix}.\end{aligned} $$ 

A combination of the rows of A has produced the zero row. What combination is it? (Look at  $ b_3 - 2b_2 + b_1 $ on the right side.) Which vectors are in the nullspace of  $ A^\mathrm{T} $ and which vectors are in the nullspace of  $ A $?

(a)

Following the method of Problem 18, reduce A to echelon form and look at zero rows. The b column tells which combinations you have taken of the rows:

 $$ \begin{bmatrix}1&2&b_{1}\\ 3&4&b_{2}\\ 4&6&b_{3}\end{bmatrix} $$ 

(b)

 $$ \begin{bmatrix} {1}&{2}&{b_{1}} \\ {2}&{3}&{b_{2}} \\ {2}&{4}&{b_{3}} \\ {2}&{5}&{b_{4}} \end{bmatrix} $$ 

From the $b$ column after elimination, read off $m-r$ basis vectors in the left nullspace. Those $y$'s are combinations of rows that give zero rows in the echelon form.

(a) Check that the solutions to Ax = 0 are perpendicular to the rows of A:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{2}}}&{{{1}}}&{{{0}}} \\{{{3}}}&{{{4}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{4}}}&{{{2}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}=\boldsymbol{E}\boldsymbol{R}. $$ 

(b) How many independent solutions to  $ A^\mathrm{T} \boldsymbol{y} = \boldsymbol{0} $? Why does  $ \boldsymbol{y}^\mathrm{T} = \text{row } 3 $ of  $ E^{-1} $?

Suppose  $ A $ is the sum of two matrices of rank one:  $ A = \boldsymbol{u} \boldsymbol{v}^\mathrm{T} + \boldsymbol{w} \boldsymbol{z}^\mathrm{T} $.

(a) Which vectors span the column space of A?

(b) Which vectors span the row space of  $ A_{?} $

(c) The rank is less than 2 if ___ or if ___.

(d) Compute A and its rank if  $ u = z = (10, 0) $ and  $ v = w = (0, 1) $.

Construct  $ A = \boldsymbol{u}\boldsymbol{v}^{\mathrm{T}} + \boldsymbol{w}\boldsymbol{z}^{\mathrm{T}} $ whose column space has basis (12,4), (22,1) and whose row space has basis (10), (11). Write A as (3 by 2) times (2 by 2).

Without multiplying matrices, find bases for the row and column spaces of A:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{4}}}&{{{5}}} \\{{{2}}}&{{{7}}}\end{bmatrix}\begin{bmatrix}{{{3}}}&{{{0}}}&{{{3}}} \\{{{1}}}&{{{1}}}&{{{2}}}\end{bmatrix}. $$ 

How do you know from these shapes that A cannot be invertible?

(Important)  $ A^{\mathrm{T}}y = d $ is solvable when  $ d $ is in which of the four subspaces? The solution  $ y $ is unique when the ___ contains only the zero vector.