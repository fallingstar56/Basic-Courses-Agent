### 4.4 Orthonormal Bases and Gram-Schmidt

1 The columns  $ q_1, \ldots, q_n $ are orthonormal if  $ q_i^\mathrm{T} q_j = \left\{ \begin{array}{l} 0 \text{ for } i \neq j \\ 1 \text{ for } i = j \end{array} \right\} $. Then  $ \boxed{Q^\mathrm{T} Q = I} $.

2 If  $ Q $ is also square, then  $ QQ^\mathrm{T} = I $ and  $ \boxed{Q^\mathrm{T} = Q^{-1}} $.  $ Q $ is an “orthogonal matrix”.

3 The least squares solution to  $ Q x = b $ is  $ \hat{x} = Q^\mathrm{T} b $. Projection of  $ b: p = Q Q^\mathrm{T} b = P b $.

4 The Gram-Schmidt process takes independent  $ a_i $ to orthonormal  $ q_i $. Start with  $ q_1 = a_1 / \| a_1 \| $.

5  $ q_i $ is  $ (a_i - \text{projection } p_i) / \| a_i - p_i \| $; projection  $ p_i = (a_i^\mathrm{T} q_1) q_1 + \cdots + (a_i^\mathrm{T} q_{i-1}) q_{i-1} $.

6 Each  $ a_i $ will be a combination of  $ q_1 $ to  $ q_i $. Then  $ A = QR $: orthogonal  $ Q $ and triangular  $ R $.

This section has two goals, why and how. The first is to see why orthogonality is good. Dot products are zero, so  $ A^{T}A $ will be diagonal. It becomes so easy to find  $ \widehat{x} $ and  $ p = A\widehat{x} $. The second goal is to construct orthogonal vectors. You will see how Gram-Schmidt chooses combinations of the original basis vectors to produce right angles. Those original vectors are the columns of A, probably not orthogonal. The orthonormal basis vectors will be the columns of a new matrix Q.

From Chapter 3, a basis consists of independent vectors that span the space. The basis vectors could meet at any angle (except  $ 0^{\circ} $ and  $ 180^{\circ} $). But every time we visualize axes, they are perpendicular. In our imagination, the coordinate axes are practically always orthogonal. This simplifies the picture and it greatly simplifies the computations.

The vectors  $ q_1, \ldots, q_n $ are orthogonal when their dot products  $ q_i \cdot q_j $ are zero. More exactly  $ q_i^T q_j = 0 $ whenever  $ i \neq j $. With one more step—just divide each vector by its length—the vectors become orthogonal unit vectors. Their lengths are all 1 (normal). Then the basis is called orthonormal.

DEFINITION The vectors  $ q_{1}, \ldots, q_{n} $ are orthonormal if

 $$ \boldsymbol{q}_{i}^{\mathrm{T}}\boldsymbol{q}_{j}=\begin{cases}0&when i\neq j\quad(orthogonal vectors)\\1&when i=j\quad(unit vectors:\|\boldsymbol{q}_{i}\|=1)\end{cases} $$ 

A matrix with orthonormal columns is assigned the special letter Q.

The matrix Q is easy to work with because  $ Q^{\mathrm{T}}Q = I $. This repeats in matrix language that the columns  $ q_1, \ldots, q_n $ are orthonormal. Q is not required to be square.