#### 4.2. Projections

When A has independent columns,  $ A^{T}A $ is square, symmetric, and invertible.

To repeat for emphasis:  $ A^{\mathrm{T}}A $ is  $ (n \text{ by } m) $ times  $ (m \text{ by } n) $. Then  $ A^{\mathrm{T}}A $ is square  $ (n \text{ by } n) $. It is symmetric, because its transpose is  $ (A^{\mathrm{T}}A)^{\mathrm{T}} = A^{\mathrm{T}}(A^{\mathrm{T}})^{\mathrm{T}} $ which equals  $ A^{\mathrm{T}}A $. We just proved that  $ A^{\mathrm{T}}A $ is invertible—provided  $ A $ has independent columns. Watch the difference between dependent and independent columns:

 $$ \begin{array}{r} \left[\begin{array}{ccc} A^{\mathrm{T}} & A & A^{\mathrm{T}}A \\ 1 & 1 & 0 \\ 2 & 2 & 0 \end{array} \right]  \left[\begin{array}{cc} 1 & 2 \\ 1 & 2 \\ 0 & 0  \end{array} \right]=\left[\begin{array}{cc} 2 & 4 \\ 4 & 8 \end{array} \right] \quad \left[\begin{array}{ccc} 1 & 1 & 0 \\ 2 & 2 & 1 \end{array} \right]  \left[\begin{array}{c} 1 & 2 \\ 1 & 2 \\ 0 & 1 \end{array} \right]=\left[\begin{array}{cc} 2 & 4 \\ 4 & 9 \end{array} \right] \\  dependent\quad singular\quad indep.\quad invertible \end{array} $$ 

Very brief summary To find the projection  $ p = \widehat{x}_1 a_1 + \cdots + \widehat{x}_n a_n $, solve  $ A^\mathrm{T} A \widehat{x} = A^\mathrm{T} b $. This gives  $ \widehat{x} $. The projection is  $ p = A \widehat{x} $ and the error is  $ e = b - p = b - A \widehat{x} $. The projection matrix  $ P = A (A^\mathrm{T} A)^{-1} A^\mathrm{T} $ gives  $ p = Pb $.

This matrix satisfies  $ P^2 = P $. The distance from b to the subspace  $ C(A) $ is  $ \|e\| $.

## ■ REVIEW OF THE KEY IDEAS

1. The projection of  $ b $ onto the line through  $ a $ is  $ p = a\hat{x} = a(a^{\mathrm{T}}b/a^{\mathrm{T}}a) $.

2. The rank one projection matrix  $ P = aa^{\mathrm{T}} / a^{\mathrm{T}} a $ multiplies b to produce p.

3. Projecting $b$ onto a subspace leaves $e = b - p$ perpendicular to the subspace.

4. When $A$ has full rank $n$, the equation $A^{\mathrm{T}}A\widehat{x}=A^{\mathrm{T}}b$ leads to $\widehat{x}$ and $p=A\widehat{x}$.

5. The projection matrix  $ P = A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}} $ has  $ P^{\mathrm{T}} = P $ and  $ P^{2} = P $ and  $ Pb = p $.

## WORKED EXAMPLES

4.2 A Project the vector  $ \boldsymbol{b} = (3, 4, 4) $ onto the line through  $ \boldsymbol{a} = (2, 2, 1) $ and then onto the plane that also contains  $ \boldsymbol{a}^{*} = (1, 0, 0) $. Check that the first error vector  $ \boldsymbol{b} - \boldsymbol{p} $ is perpendicular to  $ \boldsymbol{a} $, and the second error vector  $ \boldsymbol{e}^{*} = \boldsymbol{b} - \boldsymbol{p}^{*} $ is also perpendicular to  $ \boldsymbol{a}^{*} $.

Find the 3 by 3 projection matrix P onto that plane of a and  $ a^{*} $. Find a vector whose projection onto the plane is the zero vector. Why is it exactly the error  $ e^{*} $?