## ■ REVIEW OF THE KEY IDEAS

1. Subspaces V and W are orthogonal if every v in V is orthogonal to every w in W.

2. V and W are “orthogonal complements” if W contains all vectors perpendicular to V (and vice versa). Inside  $ R^n $, the dimensions of complements V and W add to n.

3. The nullspace  $ \mathbf{N}(A) $ and the row space  $ \mathbf{C}(A^{\mathrm{T}}) $ are orthogonal complements, with dimensions  $ (n-r)+r=n $. Similarly  $ \mathbf{N}(A^{\mathrm{T}}) $ and  $ \mathbf{C}(A) $ are orthogonal complements with  $ (m-r)+r=m $.

4. Any $n$ independent vectors in $\mathbf{R}^{n}$ span $\mathbf{R}^{n}$. Any $n$ spanning vectors are independent.

## WORKED EXAMPLES

4.1 A Suppose S is a six-dimensional subspace of nine-dimensional space  $ R^{9} $.

(a) What are the possible dimensions of subspaces orthogonal to  $ S_{?} $

(b) What are the possible dimensions of the orthogonal complement  $ S^{\perp} $ of  $ S? $

(c) What is the smallest possible size of a matrix A that has row space S?

(d) What is the smallest possible size of a matrix B that has nullspace  $ S^{\perp} $?

## Solution

(a) If S is six-dimensional in  $ \mathbf{R}^{9} $, subspaces orthogonal to S can have dimensions 0, 1, 2, 3.

(b) The complement  $ S^{\perp} $ is the largest orthogonal subspace, with dimension 3.

(c) The smallest matrix A is 6 by 9 (its six rows will be a basis for S).

(d) This is the same as question (c)!

If a new row 7 of B is a combination of the six rows of A, then B has the same row space as A. It also has the same nullspace. The special solutions  $ s_1, s_2, s_3 $ to  $ Ax = 0 $, will be the same for  $ Bx = 0 $. Elimination will change row 7 of B to all zeros.

4.1 B The equation  $ x - 3y - 4z = 0 $ describes a plane  $ P $ in  $ \mathbf{R}^3 $ (actually a subspace).

(a) The plane P is the nullspace  $ \mathbf{N}(A) $ of what 1 by 3 matrix A? Ans:  $ A = [1 - 3 - 4] $.

(b) Find a basis  $ s_1 $,  $ s_2 $ of special solutions of  $ x - 3y - 4z = 0 $ (these would be the columns of the nullspace matrix  $ N $). Answer:  $ s_1 = (3, 1, 0) $ and  $ s_2 = (4, 0, 1) $.

(c) Find a basis for the line  $ P^{\perp} $ that is perpendicular to P. Answer:  $ (1,-3,-4) $!