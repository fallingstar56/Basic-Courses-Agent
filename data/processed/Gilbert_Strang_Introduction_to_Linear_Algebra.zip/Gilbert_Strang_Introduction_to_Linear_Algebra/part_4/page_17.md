The projection $p$ will be some multiple of $a$. Call it $p = \hat{x}a = \hat{x}$ at times $a$. Computing this number $\hat{x}$ will give the vector $p$. Then from the formula for $p$, we will read off the projection matrix $P$. These three steps will lead to all projection matrices: find $\hat{x}$, then find the vector $p$, then find the matrix $P$.

The dotted line  $ b - p $ is the “error”  $ e = b - \hat{x}a $. It is perpendicular to  $ a $—this will determine  $ \hat{x} $. Use the fact that  $ b - \hat{x}a $ is perpendicular to  $ a $ when their dot product is zero:

 $$ \begin{aligned}&Projecting b onto a with error e=b-\widehat{x}a\\&a\cdot(b-\widehat{x}a)=0\quad or\quad a\cdot b-\widehat{x}a\cdot a=0\\ \end{aligned} $$ 

 $$ \widehat{x}=\frac{a\cdot b}{a\cdot a}=\frac{a^{\mathrm{T}}b}{a^{\mathrm{T}}a}. $$ 

The multiplication  $ a^{\mathrm{T}}b $ is the same as  $ a \cdot b $. Using the transpose is better, because it applies also to matrices. Our formula  $ \hat{x} = a^{\mathrm{T}}b / a^{\mathrm{T}}a $ gives the projection  $ p = \hat{x}a $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_160_480_469_658.jpg" alt="Image" width="28%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_507_482_911_685.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;">Figure 4.6: The projection p of b onto a line and onto S = column space of A.</div>


The projection of $b$ onto the line through $a$ is the vector $p = \hat{x}a = \frac{a^\top b}{a^\top a}a$.

Special case 1: If  $ b = a $ then  $ \widehat{x} = 1 $. The projection of  $ a $ onto  $ a $ is itself.  $ Pa = a $.

Special case 2: If $b$ is perpendicular to $a$ then $a^{\mathrm{T}}b = 0$. The projection is $p = 0$.

Example 1 Project $b=\left[\begin{array}{c}1\\ 1\\ 1\end{array}\right]$ onto $a=\left[\begin{array}{c}1\\ 2\\ 2\end{array}\right]$ to find $p=\widehat{x}a$ in Figure 4.6.

Solution The number  $ \hat{x} $ is the ratio of  $ a^{\mathrm{T}}b = 5 $ to  $ a^{\mathrm{T}}a = 9 $. So the projection is  $ p = \frac{5}{9}a $.