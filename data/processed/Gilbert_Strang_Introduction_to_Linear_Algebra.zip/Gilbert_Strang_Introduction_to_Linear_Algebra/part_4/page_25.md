Questions 11–20 ask for projections, and projection matrices, onto subspaces.

11 Project $b$ onto the column space of $A$ by solving $A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b$ and $p = A \widehat{x}$:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{b}=\begin{bmatrix}{{{2}}} \\{{{3}}} \\{{{4}}}\end{bmatrix} $$ 

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{b}=\begin{bmatrix}{{{4}}} \\{{{4}}} \\{{{6}}}\end{bmatrix}. $$ 

Find e = b - p. It should be perpendicular to the columns of A.

Compute the projection matrices  $ P_1 $ and  $ P_2 $ onto the column spaces in Problem 11. Verify that  $ P_1b $ gives the first projection  $ p_1 $. Also verify  $ P_2^2 = P_2 $.

(Quick and Recommended) Suppose A is the 4 by 4 identity matrix with its last column removed. A is 4 by 3. Project  $ \boldsymbol{b} = (1, 2, 3, 4) $ onto the column space of A. What shape is the projection matrix P and what is P?

14 Suppose $b$ equals 2 times the first column of $A$. What is the projection of $b$ onto the column space of $A$? Is $P = I$ for sure in this case? Compute $p$ and $P$ when $b = (0, 2, 4)$ and the columns of $A$ are $(0, 1, 2)$ and $(1, 2, 0)$.

If $A$ is doubled, then $P = 2A(4A^{\mathrm{T}}A)^{-1}2A^{\mathrm{T}}$. This is the same as $A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}}$. The column space of $2A$ is the same as ___. Is $\widehat{x}$ the same for $A$ and $2A$?

What linear combination of  $ (1, 2, -1) $ and  $ (1, 0, 1) $ is closest to  $ b = (2, 1, 1) $?

(Important) If  $ P^{2} = P $ show that  $ (I - P)^{2} = I - P $. When P projects onto the column space of A, I - P projects onto the ___.

(a) If P is the 2 by 2 projection matrix onto the line through  $ (1,1) $, then I - P is the projection matrix onto ___.

(b) If P is the 3 by 3 projection matrix onto the line through  $ (1,1,1) $, then I - P is the projection matrix onto ___.

19 To find the projection matrix onto the plane  $ x - y - 2z = 0 $, choose two vectors in that plane and make them the columns of A. The plane will be the column space of  $ A! $. Then compute  $ P = A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}} $.

20 To find the projection matrix P onto the same plane  $ x - y - 2z = 0 $, write down a vector  $ e $ that is perpendicular to that plane. Compute the projection  $ Q = ee^\mathrm{T}/e^\mathrm{T}e $ and then  $ P = I - Q $.

Questions 21–26 show that projection matrices satisfy  $ P^2 = P $ and  $ P^\mathrm{T} = P $.

21 Multiply the matrix  $ P = A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}} $ by itself. Cancel to prove that  $ P^{2} = P $. Explain why  $ P(Pb) $ always equals Pb: The vector Pb is in the column space of A so its projection onto that column space is ___.

22 Prove that  $ P = A(A^{\mathrm{T}} A)^{-1} A^{\mathrm{T}} $ is symmetric by computing  $ P^{\mathrm{T}} $. Remember that the inverse of a symmetric matrix is symmetric.