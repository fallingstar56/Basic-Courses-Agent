In this case the projections  $ p_{1} $ and  $ p_{2} $ are perpendicular. The xy plane and the z axis are orthogonal subspaces, like the floor of a room and the line between two walls.

<div style="text-align: center;"><img src="imgs/img_in_image_box_261_227_751_449.jpg" alt="Image" width="45%" /></div>


<div style="text-align: center;">Figure 4.5: The projections  $ p_{1}=P_{1}b $ and  $ p_{2}=P_{2}b $ onto the  $ z $ axis and the  $ xy $ plane.</div>


More than just orthogonal, the line and plane are orthogonal complements. Their dimensions add to  $ 1 + 2 = 3 $. Every vector b in the whole space is the sum of its parts in the two subspaces. The projections  $ p_1 $ and  $ p_2 $ are exactly those two parts of b:

 $$  The vectors give p_{1}+p_{2}=b.\qquad The matrices give P_{1}+P_{2}=I. $$ 

This is perfect. Our goal is reached—for this example. We have the same goal for any line and any plane and any n-dimensional subspace. The object is to find the part p in each subspace, and the projection matrix P that produces that part p = Pb. Every subspace of  $ \mathbf{R}^m $ has its own m by m projection matrix. To compute P, we absolutely need a good description of the subspace that it projects onto.

The best description of a subspace is a basis. We put the basis vectors into the columns of A. Now we are projecting onto the column space of A! Certainly the z axis is the column space of the 3 by 1 matrix  $ A_1 $. The xy plane is the column space of  $ A_2 $. That plane is also the column space of  $ A_3 $ (a subspace has many bases). So  $ p_2 = p_3 $ and  $ P_2 = P_3 $.

 $$ A_{1}=\begin{bmatrix}{{{0}}} \\{{{0}}} \\{{{1}}}\end{bmatrix}\quad and\quad A_{2}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad A_{3}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Our problem is to project any b onto the column space of any m by n matrix. Start with a line (dimension n = 1). The matrix A will have only one column. Call it a.

Projection Onto a Line

A line goes through the origin in the direction of  $ \boldsymbol{a} = (a_{1}, \ldots, a_{m}) $. Along that line, we want the point  $ p $ closest to  $ \boldsymbol{b} = (b_{1}, \ldots, b_{m}) $. The key to projection is orthogonality: The line from  $ b $ to  $ p $ is perpendicular to the vector  $ \boldsymbol{a} $. This is the dotted line marked  $ e = \boldsymbol{b} - \boldsymbol{p} $ for the error on the left side of Figure 4.6. We now compute  $ p $ by algebra.