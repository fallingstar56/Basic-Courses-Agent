It is no accident that those factors 1, 1, 1 and 0, 1, 2 in the derivatives of  $ \|Ax - b\|^2 $ are the columns of A. Now cancel 2 from every term and collect all  $ C' $s and all  $ D' $s:

The $C$ derivative is zero: $3C + 3D = 6$

The $D$ derivative is zero: $3C + 5D = 0$

This matrix $\left[\begin{array}{cc}3 & 3 \\ 3 & 5\end{array}\right]$ is $A^{\mathrm{T}}A$

These equations are identical with  $ A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b $. The best C and D are the components of  $ \widehat{x} $. The equations from calculus are the same as the “normal equations” from linear algebra. These are the key equations of least squares:

 $$ \begin{array}{r}{T h e\;p a r t i a l\;d e r i v a t i v e s\;o f\|\mathbf{A}\mathbf{x}-\mathbf{b}\|^{2}\;a r e\;z e r o\;w h e n\;\mathbf{A}^{\mathrm{T}}\mathbf{A}\widehat{\mathbf{x}}=\mathbf{A}^{\mathrm{T}}\mathbf{b}.}\end{array} $$ 

The solution is $C = 5$ and $D = -3$. Therefore $b = 5 - 3t$ is the best line—it comes closest to the three points. At $t = 0, 1, 2$ this line goes through $p = 5, 2, -1$. It could not go through $b = 6, 0, 0$. The errors are $1, -2, 1$. This is the vector $e$.

The Big Picture for Least Squares

The key figure of this book shows the four subspaces and the true action of a matrix. The vector x on the left side of Figure 4.3 went to b = Ax on the right side. In that figure x was split into  $ x_r + x_n $. There were many solutions to Ax = b.

In this section the situation is just the opposite. There are no solutions to  $ Ax = b $. Instead of splitting up  $ x $ we are splitting up  $ b = p + e $. Figure 4.7 shows the big picture for least squares. Instead of  $ Ax = b $ we solve  $ A\widehat{x} = p $. The error  $ e = b - p $ is unavoidable.

<div style="text-align: center;"><img src="imgs/img_in_image_box_186_690_893_1045.jpg" alt="Image" width="66%" /></div>


<div style="text-align: center;">Figure 4.7: The projection  $ p = A\widehat{x} $ is closest to  $ b $, so  $ \widehat{x} $ minimizes  $ E = \|b - Ax\|^2 $.</div>


Notice how the nullspace  $ N(A) $ is very small—just one point. With independent columns, the only solution to  $ Ax = 0 $ is  $ x = 0 $. Then  $ A^T A $ is invertible. The equation  $ A^T A \widehat{x} = A^T b $ fully determines the best vector  $ \widehat{x} $. The error has  $ A^T e = 0 $.