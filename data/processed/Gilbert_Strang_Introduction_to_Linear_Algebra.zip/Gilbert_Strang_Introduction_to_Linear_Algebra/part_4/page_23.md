Solution The projection of  $  b = (3, 4, 4)  $ onto the line through  $  a = (2, 2, 1)  $ is  $  p = 2a  $:

Onto a line

 $$ p=\frac{\boldsymbol{a}^{\mathrm{T}}\boldsymbol{b}}{\boldsymbol{a}^{\mathrm{T}}\boldsymbol{a}}\boldsymbol{a}=\frac{18}{9}(2,2,1)=(4,4,2)=2\boldsymbol{a}. $$ 

The error vector  $ e = b - p = (-1, 0, 2) $ is perpendicular to  $ a = (2, 2, 1) $. So p is correct.

The plane of  $ \boldsymbol{a} = (2, 2, 1) $ and  $ \boldsymbol{a}^{*} = (1, 0, 0) $ is the column space of  $ A = [\boldsymbol{a} \boldsymbol{a}^{*}] $:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{2}}}&{{{0}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\quad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\begin{bmatrix}{{{9}}}&{{{2}}} \\{{{2}}}&{{{1}}}\end{bmatrix}\quad(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A})^{-1}=\frac{1}{5}\begin{bmatrix}{{{1}}}&{{{-2}}} \\{{{-2}}}&{{{9}}}\end{bmatrix}\quad\boldsymbol{P}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{.8}}}&{{{.4}}} \\{{{0}}}&{{{.4}}}&{{{.2}}}\end{bmatrix} $$ 

Now  $ p^* = Pb = (3, 4.8, 2.4) $. The error  $ e^* = b - p^* = (0, -0.8, 1.6) $ is perpendicular to  $ a $ and  $ a^* $. This  $ e^* $ is in the nullspace of  $ P $ and its projection is zero! Note  $ P^2 = P = P^\mathrm{T} $.

4.2 B Suppose your pulse is measured at  $ x = 70 $ beats per minute, then at  $ x = 80 $, then at  $ x = 120 $. Those three equations  $ Ax = b $ in one unknown have  $ A^{\mathrm{T}} = [1\ 1\ 1] $ and  $ b = (70, 80, 120) $. The best  $ \hat{x} $ is the ___ of 70, 80, 120. Use calculus and projection:

1. Minimize E = (x − 70)2 + (x − 80)2 + (x − 120)2 by solving dE/dx = 0.

2. Project  $  b = (70, 80, 120)  $ onto  $  \boldsymbol{a} = (1, 1, 1)  $ to find  $  \widehat{x} = \boldsymbol{a}^{\mathrm{T}} \boldsymbol{b} / \boldsymbol{a}^{\mathrm{T}} \boldsymbol{a}  $.

Solution The closest horizontal line to the heights 70, 80, 120 is the average  $ \widehat{x} = 90 $:

 $$ \frac{dE}{dx}=2(x-70)+2(x-80)+2(x-120)=0\quad gives\quad\widehat{x}=\frac{70+80+120}{3}=90. $$ 

Also by projection :

 $ \widehat{x}=\frac{a^{\mathrm{T}}b}{a^{\mathrm{T}}a}=\frac{(1,1,1)^{\mathrm{T}}(70,80,120)}{(1,1,1)^{\mathrm{T}}(1,1,1)}=\frac{70+80+120}{3}=90. $

In recursive least squares, a fourth measurement 130 changes the average  $ \widehat{x}_{\text{old}} = 90 $ to  $ \widehat{x}_{\text{new}} = 100 $. Verify the update formula  $ \widehat{x}_{\text{new}} = \widehat{x}_{\text{old}} + \frac{1}{4}(130 - \widehat{x}_{\text{old}}) $. When a new measurement arrives, we don't have to average all the old measurements again!

### Problem Set 4.2

Questions 1–9 ask for projections p onto lines. Also errors  $ e = b - p $ and matrices P.

1 Project the vector b onto the line through a. Check that e is perpendicular to a:

 $$ \begin{aligned}(a)b&=\begin{bmatrix}1\\ 2\\ 2\end{bmatrix}\quad and\quad a=\begin{bmatrix}1\\ 1\\ 1\end{bmatrix}\quad&(b)\quad b=\begin{bmatrix}1\\ 3\\ 1\end{bmatrix}\quad and\quad a=\begin{bmatrix}-1\\ -3\\ -1\end{bmatrix}.\end{aligned} $$ 