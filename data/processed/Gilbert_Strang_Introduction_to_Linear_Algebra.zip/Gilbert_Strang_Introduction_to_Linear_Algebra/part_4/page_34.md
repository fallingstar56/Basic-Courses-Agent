That was a perfect example of the “Gram-Schmidt idea” coming in the next section: Make the columns orthogonal in advance. Then  $ A_{\text{new}}^{\text{T}} A_{\text{new}} $ is diagonal and  $ \widehat{x}_{\text{new}} $ is easy.

## Dependent Columns in A: What is  $ \hat{x} $?

From the start, this chapter has assumed independent columns in  $ A $. Then  $ A^{\mathrm{T}}A $ is invertible. Then  $ A^{\mathrm{T}}A\widehat{x} = A^{\mathrm{T}}b $ produces the least squares solution to  $ Ax = b $.

Which  $ \hat{x} $ is best if A has dependent columns? Here is a specific example.

\[\begin{aligned}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}}\end{bmatrix}&=\begin{bmatrix}{{{3}}} \\{{{1}}}\end{bmatrix}=b\quad&\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{\widehat{x}_{1}}}} \\{{{\widehat{x}_{2}}}}\end{bmatrix}&=\begin{bmatrix}{{{2}}} \\{{{2}}}\end{bmatrix}=p\quad&\begin{aligned}\\ &b_{1}=3\quad&\quad\quad\quad\quad\

The measurements  $ b_1 = 3 $ and  $ b_2 = 1 $ are at the same time  $ T! $. A straight line  $ C + Dt $ cannot go through both points. I think we are right to project  $ \boldsymbol{b} = (3, 1) $ to  $ \boldsymbol{p} = (2, 2) $ in the column space of  $ A $. That changes the equation  $ Ax = b $ to the equation  $ A\widehat{\boldsymbol{x}} = \boldsymbol{p} $. An equation with no solution has become an equation with infinitely many solutions. The problem is that  $ A $ has dependent columns and  $ (1, -1) $ is in its nullspace.

Which solution  $ \hat{x} $ should we choose? All the dashed lines in the figure have the same two errors 1 and -1 at time T. Those errors  $ (1,-1)=e=b-p $ are as small as possible. But this doesn’t tell us which dashed line is best.

My instinct is to go for the horizontal line at height 2. If the equation for the best line is $b = C + Dt$, then my choice will have $\widehat{x}_1 = C = 2$ and $\widehat{x}_2 = D = 0$. But what if the line had been written as $b = ct + d?$ This is equally correct (just reversing $C$ and $D$). Now the horizontal line has $\widehat{x}_1 = c = 0$ and $\widehat{x}_2 = d = 2$. I don’t see any way out.

In Section 7.4, the “pseudoinverse” of A will choose the shortest solution to  $ A\widehat{x} = p $. Here, that shortest solution will be  $ \boldsymbol{x}^+ $ = (1, 1). This is the particular solution in the row space of A, and  $ \boldsymbol{x}^+ $ has length  $ \sqrt{2} $. (Both solutions  $ \widehat{\boldsymbol{x}} = (2, 0) $ and  $ (0, 2) $ have length 2.) We are arbitrarily choosing the nullspace component of the solution  $ \boldsymbol{x}^+ $ to be zero.

When $A$ has independent columns, the nullspace only contains the zero vector and the pseudoinverse is our usual left inverse $L = (A^\mathrm{T} A)^{-1} A^\mathrm{T}$. When $I$ write it that way, the pseudoinverse sounds like the best way to choose $\boldsymbol{x}$.

Comment MATLAB experiments with singular matrices produced either Inf or NaN (Not a Number) or 10^{16} (a bad number). There is a warning in every case! I believe that Inf and NaN and 10^{16} come from the possibilities 0x = b and 0x = 0 and 10^{-16} x = 1.

Those are three small examples of three big difficulties: singular with no solution, singular with many solutions, and very close to singular.