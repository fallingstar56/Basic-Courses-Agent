### Problem Set 4.1

Questions 1–12 grow out of Figures 4.2 and 4.3 with four subspaces.

1 Construct any 2 by 3 matrix of rank one. Copy Figure 4.2 and put one vector in each subspace (and put two in the nullspace). Which vectors are orthogonal?

2 Redraw Figure 4.3 for a 3 by 2 matrix of rank  $ r = 2 $. Which subspace is  $ \mathbf{Z} $ (zero vector only)? The nullspace part of any vector  $ \mathbf{x} $ in  $ \mathbf{R}^2 $ is  $ \mathbf{x}_n = \_\_\_\_\_\_ $.

3 Construct a matrix with the required property or say why that is impossible:

(a) Column space contains  $ \begin{bmatrix} 1 \\ 2 \\ -3 \end{bmatrix} $ and  $ \begin{bmatrix} 2 \\ -3 \\ 5 \end{bmatrix} $, nullspace contains  $ \begin{bmatrix} 1 \\ 1 \\ 1 \end{bmatrix} $

(b) Row space contains  $ \begin{bmatrix} 1 \\ 2 \\ -3 \end{bmatrix} $ and  $ \begin{bmatrix} 2 \\ -3 \\ 5 \end{bmatrix} $, nullspace contains  $ \begin{bmatrix} 1 \\ 1 \end{bmatrix} $

(c)  $ Ax = \begin{bmatrix} 1 \\ 1 \\ 1 \end{bmatrix} $ has a solution and  $ A^{\mathrm{T}} \begin{bmatrix} 1 \\ 0 \\ 0 \end{bmatrix} = \begin{bmatrix} 0 \\ 0 \end{bmatrix} $

(d) Every row is orthogonal to every column (A is not the zero matrix)

(e) Columns add up to a column of zeros, rows add to a row of 1's.

4 If AB = 0 then the columns of B are in the  $ \underline{\text{}} $ of A. The rows of A are in the  $ \underline{\text{}} $ of B. With AB = 0, why can't A and B be 3 by 3 matrices of rank 2?

5 (a) If  $ Ax = b $ has a solution and  $ A^{\mathrm{T}}y = 0 $, is  $ (y^{\mathrm{T}}x = 0) $ or  $ (y^{\mathrm{T}}b = 0) $?

(b) If  $ A^{\mathrm{T}}y = (1, 1, 1) $ has a solution and  $ Ax = 0 $, then ___.

6 This system of equations Ax = b has no solution (they lead to 0 = 1):

 $$ x+2y+2z\quad=\quad5 $$ 

 $$ 2x+2y+3z\quad=\quad5 $$ 

 $$ 3x+4y+5z=9 $$ 

Find numbers  $ y_1, y_2, y_3 $ to multiply the equations so they add to  $ 0 = 1 $. You have found a vector  $ y $ in which subspace? Its dot product  $ y^\mathrm{T}b $ is 1, so no solution  $ x $.

7 Every system with no solution is like the one in Problem 6. There are numbers  $ y_{1}, \ldots, y_{m} $ that multiply the m equations so they add up to 0 = 1. This is called Fredholm's Alternative:

Exactly one of these problems has a solution

 $$ \begin{array}{r l}{A\boldsymbol{x}=\boldsymbol{b}}&{{}\textbf{O R}\quad A^{\mathrm{T}}\boldsymbol{y}=\mathbf{0}\quad\mathrm{w i t h}\quad\boldsymbol{y}^{\mathrm{T}}\boldsymbol{b}=1.}\end{array} $$ 

If $b$ is not in the column space of $A$, it is not orthogonal to the nullspace of $A^\top$. Multiply the equations $x_1 - x_2 = 1$ and $x_2 - x_3 = 1$ and $x_1 - x_3 = 1$ by numbers $y_1, y_2, y_3$ chosen so that the equations add up to $0 = 1$.