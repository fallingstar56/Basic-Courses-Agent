The error vector between b and p is  $ e = b - p $. Those vectors p and e will add to  $ b = (1, 1, 1) $:

 $$ p=\frac{5}{9}a=\left(\frac{5}{9},\frac{10}{9},\frac{10}{9}\right)\quad and\quad e=b-p=\left(\frac{4}{9},-\frac{1}{9},-\frac{1}{9}\right). $$ 

The error e should be perpendicular to  $ \boldsymbol{a} = (\ \boldsymbol{D}, 2)  $ and it is:  $ e^{\mathrm{T}} \boldsymbol{a} = \frac{4}{9} - \frac{2}{9} - \frac{2}{9} = 0. $

Look at the right triangle of $b$, $p$, and $e$. The vector $b$ is split into two parts—its component along the line is $p$, its perpendicular part is $e$. Those two sides $p$ and $e$ have length $\|p\| = \|b\|\cos\theta$ and $\|e\| = \|b\|\sin\theta$. Trigonometry matches the dot product:

 $$ p=\frac{a^{\mathrm{T}}b}{a^{\mathrm{T}}a}\quad has length\quad\|p\|=\frac{\|a\|\|b\|\cos\theta}{\|a\|^{2}}\|a\|=\quad\|b\|\cos\theta. $$ 

The dot product is a lot simpler than getting involved with  $ \cos\theta $ and the length of  $ b $. The example has square roots in  $ \cos\theta = 5/3\sqrt{3} $ and  $ \|b\| = \sqrt{3} $. There are no square roots in the projection  $ p = 5a/9 $. The good way to  $ 5/9 $ is  $ \boldsymbol{a}^\mathrm{T}\boldsymbol{b}/\boldsymbol{a}^\mathrm{T}\boldsymbol{a} $.

Now comes the projection matrix. In the formula for p, what matrix is multiplying b? You can see the matrix better if the number  $ \hat{x} $ is on the right side of a:

Projection matrix P

 $$ p=a\widehat{x}=a\frac{a^{\mathrm{T}}b}{a^{\mathrm{T}}a}=Pb $$ 

when the matrix is

 $$ P=\frac{a\boldsymbol{a}^{\mathrm{T}}}{\boldsymbol{a}^{\mathrm{T}}\boldsymbol{a}} $$ 

P is a column times a row! The column is a, the row is  $ a^{\mathrm{T}} $. Then divide by the number  $ a^{\mathrm{T}}a $. The projection matrix P is m by m, but its rank is one. We are projecting onto a one-dimensional subspace, the line through a. That line is the column space of P.

Example 2 Find the projection matrix  $ P = \frac{aa^\top}{a^\top a} $ onto the line through  $ a = \begin{bmatrix} 1 \\ 2 \end{bmatrix} $.

Solution Multiply column a times row  $ a^{\mathrm{T}} $ and divide by  $ a^{\mathrm{T}}a = 9 $:

Projection matrix

 $$ \boldsymbol{P}=\frac{\boldsymbol{a}\boldsymbol{a}^{\mathrm{T}}}{\boldsymbol{a}^{\mathrm{T}}\boldsymbol{a}}=\frac{1}{9}\begin{bmatrix}{{{1}}} \\{{{2}}} \\{{{2}}}\end{bmatrix}\left[\begin{array}{lll}{{{1}}}&{{{2}}}&{{{2}}}\end{array}\right]=\frac{1}{9}\begin{bmatrix}{{{1}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{4}}}&{{{4}}} \\{{{2}}}&{{{4}}}&{{{4}}}\end{bmatrix}. $$ 

This matrix projects any vector b onto a. Check  $ p = Pb $ for  $ b = (\quad\llcorner, 1) $ in Example 1:

 $$ \boldsymbol{p}=\boldsymbol{P}\boldsymbol{b}=\frac{1}{9}\begin{bmatrix}{{{1}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{4}}}&{{{4}}} \\{{{2}}}&{{{4}}}&{{{4}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{1}}} \\{{{1}}}\end{bmatrix}=\frac{1}{9}\begin{bmatrix}{{{5}}} \\{{{10}}} \\{{{10}}}\end{bmatrix} $$ 

which is correct.

If the vector $a$ is doubled, the matrix $P$ stays the same! It still projects onto the same line. If the matrix is squared, $P^2$ equals $P$. Projecting $a$ second time doesn't change anything, so $P^2 = P$. The diagonal entries of $P$ add up to $\frac{1}{9}(\underline{\underline{\underline{\underline