Those zeros in  $ A^{\mathrm{T}}A $ mean that column 2 of A is orthogonal to columns 1 and 3. We see this directly in  $ A $ (the times  $ -2,-1,0,1,2 $ are symmetric). The best  $ C,D,E $ in the parabola  $ C+Dt+Et^{2} $ come from  $ A^{\mathrm{T}}A\widehat{x}=A^{\mathrm{T}}b $, and  $ D $ is uncoupled from  $ C $ and  $ E $:

 $$ \left[\begin{array}{ccc}{{{5}}}&{{{0}}}&{{{10}}} \\{{{0}}}&{{{10}}}&{{{0}}} \\{{{10}}}&{{{0}}}&{{{34}}} \\\end{array}\right]\left[\begin{array}{c}{{{C}}} \\{{{D}}} \\{{{E}}} \\\end{array}\right]=\left[\begin{array}{c}{{{1}}} \\{{{0}}} \\{{{0}}} \\\end{array}\right]\quad leads to\quad\begin{array}{l}{{{C=34/70}}} \\{{{D=0\quad as predicted}}} \\{{{E=-10/70}}} \\\end{array} $$ 

### Problem Set 4.3

Problems 1–11 use four data points  $ b = (0, 8, 8, 20) $ to bring out the key ideas.

<div style="text-align: center;"><img src="imgs/img_in_image_box_158_406_885_701.jpg" alt="Image" width="68%" /></div>


<div style="text-align: center;">Figure 4.9: Problems 1–11: The closest line C + Dt matches Ca1 + Da2 in R4.</div>


1 With $b = 0, 8, 8, 20$ at $t = 0, 1, 3, 4$, set up and solve the normal equations $A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b$. For the best straight line in Figure 4.9a, find its four heights $p_i$ and four errors $e_i$. What is the minimum value $E = e_1^2 + e_2^2 + e_3^2 + e_4^2?$

2 (Line  $ C + Dt $ does go through  $ p's $) With  $ b = 0, 8, 8, 20 $ at times  $ t = 0, 1, 3, 4 $, write down the four equations  $ Ax = b $ (unsolvable). Change the measurements to  $ p = 1, 5, 13, 17 $ and find an exact solution to  $ A\widehat{x} = p $.

3 Check that  $ e = b - p = (-1, 3, -5, 3) $ is perpendicular to both columns of the same matrix A. What is the shortest distance  $ \|e\| $ from b to the column space of A?

4 (By calculus) Write down  $ E = \|Ax - b\|^2 $ as a sum of four squares—the last one is  $ (C + 4D - 20)^2 $. Find the derivative equations  $ \partial E/\partial C = 0 $ and  $ \partial E/\partial D = 0 $. Divide by 2 to obtain the normal equations  $ A^\mathrm{T}A\hat{x} = A^\mathrm{T}b $.

5 Find the height $C$ of the best horizontal line to fit $\boldsymbol{b} = (0, 8, 8, 20)$. An exact fit would solve the unsolvable equations $C = 0$, $C = 8$, $C = 8$, $C = 20$. Find the 4 by 1 matrix $A$ in these equations and solve $A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} \boldsymbol{b}$. Draw the horizontal line at height $\widehat{x} = C$ and the four errors in $e$.