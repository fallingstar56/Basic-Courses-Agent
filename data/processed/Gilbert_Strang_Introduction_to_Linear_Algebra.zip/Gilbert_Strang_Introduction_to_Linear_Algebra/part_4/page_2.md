25 True or false (with a reason or a counterexample):

(a) A and  $ A^{T} $ have the same number of pivots.

(b) A and  $ A^{T} $ have the same left nullspace.

(c) If the row space equals the column space then  $ A^{T} = A $.

(d) If  $ A^{T} = -A $ then the row space of A equals the column space.

If $a,b,c$ are given with $a \neq 0$, how would you choose $d$ so that $\begin{bmatrix} a & b \\ c & d \end{bmatrix}$ has rank 1?

Find a basis for the row space and nullspace. Show they are perpendicular!

27 Find the ranks of the 8 by 8 checkerboard matrix B and the chess matrix C:

 $$ B=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad C=\begin{bmatrix}{{{r}}}&{{{n}}}&{{{b}}}&{{{q}}}&{{{k}}}&{{{b}}}&{{{n}}}&{{{r}}} \\{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}} \\{{{\text{four zero rows}}}} \\{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}}&{{{p}}} \\{{{r}}}&{{{n}}}&{{{b}}}&{{{q}}}&{{{k}}}&{{{b}}}&{{{n}}}&{{{r}}}\end{bmatrix} $$ 

The numbers r, n, b, q, k, p are all different. Find bases for the row space and left nullspace of B and C. Challenge problem: Find a basis for the nullspace of C.

Can tic-tac-toe be completed (5 ones and 4 zeros in A) so that rank (A) = 2 but neither side passed up a winning move?

## Challenge Problems

If  $ A = \boldsymbol{u} \boldsymbol{v}^{\mathrm{T}} $ is a 2 by 2 matrix of rank 1, redraw Figure 3.5 to show clearly the Four Fundamental Subspaces. If  $ B $ produces those same four subspaces, what is the exact relation of  $ B $ to  $ A $?

30 M is the space of 3 by 3 matrices. Multiply every matrix X in M by

 $$ \boldsymbol{A}=\left[\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{-1}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right].\quad\mathrm{N o t i c e:}\boldsymbol{A}\left[\begin{aligned}{{{1}}} \\{{{1}}} \\{{{1}}}\end{aligned}\right]=\left[\begin{aligned}{{{0}}} \\{{{0}}} \\{{{0}}}\end{aligned}\right]. $$ 

(a) Which matrices X lead to AX = zero matrix?

(b) Which matrices have the form AX for some matrix X?

(a) finds the “nullspace” of that operation AX and (b) finds the “column space”. What are the dimensions of those two subspaces of M? Why do the dimensions add to  $ (n - r) + r = 9 $?

Suppose the m by n matrices A and B have the same four subspaces. If they are both in row reduced echelon form, prove that F must equal G:

 $$ \boldsymbol{A}=\left[\begin{array}{cc}\boldsymbol{I}&\boldsymbol{F}\\0&0\end{array}\right]\qquad\boldsymbol{B}=\left[\begin{array}{cc}\boldsymbol{I}&\boldsymbol{G}\\0&0\end{array}\right]. $$ 