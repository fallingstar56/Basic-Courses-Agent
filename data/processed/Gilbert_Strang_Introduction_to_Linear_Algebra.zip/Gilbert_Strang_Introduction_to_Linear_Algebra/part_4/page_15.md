### 4.2 Projections

1 The projection of a vector b onto the line through a is the closest point p = a(aT b / aT a).

2 The error  $ e = b - p $ is perpendicular to  $ a $: Right triangle  $ bpe $ has  $ \|p\|^2 + \|e\|^2 = \|b\|^2 $.

3 The projection of $b$ onto a subspace $S$ is the closest vector $p$ in $S$; $b - p$ is orthogonal to $S$.

 $ A^{\mathrm{T}} A $ is invertible (and symmetric) only if  $ A $ has independent columns:  $ \mathbf{N}(A^{\mathrm{T}} A) = \mathbf{N}(A) $.

5 Then the projection of $b$ onto the column space of $A$ is the vector $p = A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}}b$.

6 The projection matrix onto $C(A)$ is $\boxed{P = A(A^{\mathrm{T}}A)^{-1}A^{\mathrm{T}}}$. It has $p = Pb$ and $P^{2} = P = P^{\mathrm{T}}$.

May we start this section with two questions? (In addition to that one.) The first question aims to show that projections are easy to visualize. The second question is about “projection matrices”—symmetric matrices with  $ P^2 = P $. The projection of b is Pb.

1 What are the projections of  $ b = (2, 3, 4) $ onto the  $ z $ axis and the  $ xy $ plane?

2 What matrices  $ P_{1} $ and  $ P_{2} $ produce those projections onto a line and a plane?

When b is projected onto a line, its projection p is the part of b along that line. If b is projected onto a plane, p is the part in that plane. The projection p is Pb.

The projection matrix P multiplies b to give p. This section finds p and also P.

The projection onto the $z$ axis we call $p_1$. The second projection drops straight down to the $xy$ plane. The picture in your mind should be Figure 4.5. Start with $b = (2, 3, 4)$. The projection across gives $p_1 = (0, 0, 4)$. The projection down gives $p_2 = (2, 3, 0)$. Those are the parts of $b$ along the $z$ axis and in the $xy$ plane.

The projection matrices  $ P_1 $ and  $ P_2 $ are 3 by 3. They multiply b with 3 components to produce p with 3 components. Projection onto a line comes from a rank one matrix. Projection onto a plane comes from a rank two matrix:

Projection matrix

Onto the z axis:

 $$ \boldsymbol{P}_{1}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix} $$ 

Onto the xy plane:

 $$ P_{2}=\begin{bmatrix}{{{\mathbf{1}}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{\mathbf{1}}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

 $ P_{1} $ picks out the z component of every vector.  $ P_{2} $ picks out the x and y components. To find the projections  $ p_{1} $ and  $ p_{2} $ of b, multiply b by  $ P_{1} $ and  $ P_{2} $ (small p for the vector, capital P for the matrix that produces it):

 $$ \boldsymbol{p}_{1}=\boldsymbol{P}_{1}\boldsymbol{b}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{\mathbf{0}}}} \\{{{\mathbf{0}}}} \\{{{z}}}\end{bmatrix}\quad\boldsymbol{p}_{2}=\boldsymbol{P}_{2}\boldsymbol{b}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{\boldsymbol{x}}}} \\{{{\boldsymbol{y}}}} \\{{{\mathbf{0}}}}\end{bmatrix}. $$ 