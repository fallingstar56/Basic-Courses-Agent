7 If $S$ is the subspace of $\mathbf{R}^3$ containing only the zero vector, what is $S^\perp$? If $S$ is spanned by $(1,1,1)$, what is $S^\perp$? If $S$ is spanned by $(1,1,1)$ and $(1,1,-1)$, what is a basis for $S^\perp$?

18 Suppose $S$ only contains two vectors $(1,5,1)$ and $(2,2,2)$ (not a subspace). Then $S^{\perp}$ is the nullspace of the matrix $A = \underline{\quad}$. $S^{\perp}$ is a subspace even if $S$ is not.

19 Suppose $L$ is a one-dimensional subspace (a line) in $\mathbf{R}^3$. Its orthogonal complement $L^\perp$ is the ___ perpendicular to $L$. Then $(L^\perp)^\perp$ is a ___ perpendicular to $L^\perp$. In fact $(L^\perp)^\perp$ is the same as ___.

20 Suppose V is the whole space  $ R^{4} $. Then  $ V^{\perp} $ contains only the vector ___. Then  $ (V^{\perp})^{\perp} $ is ___. So  $ (V^{\perp})^{\perp} $ is the same as ___.

21 Suppose $S$ is spanned by the vectors $(1,2,2,3)$ and $(1,3,3,2)$. Find two vectors that span $S^{\perp}$. This is the same as solving $Ax = 0$ for which $A?$

22 If $P$ is the plane of vectors in $\mathbf{R}^4$ satisfying $x_1 + x_2 + x_3 + x_4 = 0$, write a basis for $P^\perp$. Construct a matrix that has $P$ as its nullspace.

23 If a subspace S is contained in a subspace V, prove that  $ S^{\perp} $ contains  $ V^{\perp} $.

Questions 24–30 are about perpendicular columns and rows.

24 Suppose an n by n matrix is invertible:  $ AA^{-1} = I $. Then the first column of  $ A^{-1} $ is orthogonal to the space spanned by which rows of A?

25 Find  $ A^{T}A $ if the columns of A are unit vectors, all mutually perpendicular.

26 Construct a 3 by 3 matrix A with no zero entries whose columns are mutually perpendicular. Compute  $ A^{T}A $. Why is it a diagonal matrix?

27 The lines  $ 3x + y = b_{1} $ and  $ 6x + 2y = b_{2} $ are ___. They are the same line if ___.

In that case  $ (b_{1}, b_{2}) $ is perpendicular to the vector ___. The nullspace of the matrix is the line  $ 3x + y = \_\_\_\_\_\_ $. One particular vector in that nullspace is ___.

(a)  $ (1,1,1) $ is perpendicular to  $ (1,1,-2) $ so the planes  $ x+y+z=0 $ and  $ x+y-2z=0 $ are orthogonal subspaces.

28 Why is each of these statements false?

(b) The subspace spanned by  $ (1,1,0,0,0) $ and  $ (0,0,0,1,1) $ is the orthogonal complement of the subspace spanned by  $ (1,-1,0,0,0) $ and  $ (2,-2,3,4,-4) $.

(c) Two subspaces that meet only in the zero vector are orthogonal.

29 Find a matrix with  $ v = (1, 2, 3) $ in the row space and column space. Find another matrix with v in the nullspace and column space. Which pairs of subspaces can v not be in?