Chapter 7 will have the complete picture—all four subspaces included. Every x splits into  $ x_r + x_n $, and every b splits into  $ p + e $. The best solution is  $ \widehat{x} = \widehat{x}_r $ in the row space. We can't help e and we don't want  $ x_n $ from the nullspace—this leaves  $ A\widehat{x} = p $.

## Fitting a Straight Line

Fitting a line is the clearest application of least squares. It starts with $m > 2$ points, hopefully near a straight line. At times $t_1, \ldots, t_m$ those $m$ points are at heights $b_1, \ldots, b_m$. The best line $C + Dt$ misses the points by vertical distances $e_1, \ldots, e_m$. No line is perfect, and the least squares line minimizes $E = e_1^2 + \cdots + e_m^2$.

The first example in this section had three points in Figure 4.6. Now we allow m points (and m can be large). The two components of  $ \hat{x} $ are still C and D.

A line goes through the m points when we exactly solve Ax = b. Generally we can't do it. Two unknowns C and D determine a line, so A has only n = 2 columns. To fit the m points, we are trying to solve m equations (and we only have two unknowns!).

 $$ \boldsymbol{A}\boldsymbol{x}=\boldsymbol{b}\quad is\quad\begin{array}{c}\boldsymbol{C}+\boldsymbol{D}t_{1}=b_{1}\\\boldsymbol{C}+\boldsymbol{D}t_{2}=b_{2}\\\vdots\\\boldsymbol{C}+\boldsymbol{D}t_{m}=b_{m}\end{array}\quad with\quad\boldsymbol{A}=\begin{bmatrix}1&t_{1}\\1&t_{2}\\\vdots&\vdots\\1&t_{m}\end{bmatrix}. $$ 

The column space is so thin that almost certainly $b$ is outside of it. When $b$ happens to lie in the column space, the points happen to lie on a line. In that case $b = p$. Then $Ax = b$ is solvable and the errors are $e = (0, \ldots, 0)$.

The closest line  $ C + Dt $ has heights  $ p_1, \ldots, p_m $ with errors  $ e_1, \ldots, e_m $.

 $$ \begin{array}{r l}&{{S o l v e~A^{\mathrm{T}}A\widehat{x}=A^{\mathrm{T}}b\quad f o r~\widehat{x}=(C,D).~T h e~e r r o r s~a r e~e_{i}=b_{i}-C-D t_{i}.}\end{array} $$ 

Fitting points by a straight line is so important that we give the two equations  $ A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b $, once and for all. The two columns of  $ A $ are independent (unless all times  $ t_i $ are the same). So we turn to least squares and solve  $ A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b $.

Dot-product matrix

 $$ \boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{\cdots}}}&{{{1}}} \\{{{t_{1}}}}&{{{\cdots}}}&{{{t_{m}}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{t_{1}}}} \\{{{\vdots}}}&{{{\vdots}}} \\{{{1}}}&{{{t_{m}}}}\end{bmatrix}=\begin{bmatrix}{{{m}}}&{{{\sum t_{i}}}} \\{{{\sum t_{i}}}}&{{{\sum t_{i}^{2}}}}\end{bmatrix}. $$ 

On the right side of the normal equation is the 2 by 1 vector  $ A^{T}b $:

 $$ \begin{align*}A^{\mathrm{T}}\boldsymbol{b}=\begin{bmatrix}1&\cdots&1\\t_{1}&\cdots&t_{m}\end{bmatrix}\begin{bmatrix}b_{1}\\ \vdots\\ b_{m}\end{bmatrix}=\begin{bmatrix}\sum b_{i}\\ \sum t_{i}b_{i}\end{bmatrix}.\end{align*} $$ 

In a specific problem, these numbers are given. The best  $ \widehat{x} = (C, D) $ is  $ (A^{\mathrm{T}} A)^{-1} A^{\mathrm{T}} b $.