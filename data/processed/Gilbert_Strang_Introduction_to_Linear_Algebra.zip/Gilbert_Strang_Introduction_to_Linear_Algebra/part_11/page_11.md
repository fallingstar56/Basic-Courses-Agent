The Correlation  $ \rho $

Correlation  $ \rho_{xy} $ is closely related to covariance  $ \sigma_{xy} $. They both measure dependence or independence. Start by rescaling or “standardizing” the random variables  $ x $ and  $ y $ The new  $ X = x/\sigma_x $ and  $ Y = y/\sigma_y $ have variance  $ \sigma_X^2 = \sigma_Y^2 = 1 $. This is just like dividing a vector  $ v $ by its length to produce a unit vector  $ v/||v|| $ of length 1.

The correlation of x and y is the covariance of X and Y. If the original covariance of x and y was  $ \sigma_{xy} $, then rescaling to X and Y will divide by  $ \sigma_{x} $ and  $ \sigma_{y} $:

 $$ \begin{aligned}&\boxed{Correlation\rho_{xy}=\frac{\sigma_{xy}}{\sigma_{x}\sigma_{y}}=covariance of\frac{x}{\sigma_{x}}and\frac{y}{\sigma_{y}}\quad\text{Always}-1\leq\rho_{xy}\leq1}\end{aligned} $$ 

Zero covariance gives zero correlation. Independent random variables produce  $ \rho_{xy}=0 $.

We know that always  $ \sigma_{xy}^2 \leq \sigma_x^2 \sigma_y^2 $ (the covariance matrix  $ V $ is at least positive semidefinite). Then  $ \rho_{xy}^2 \leq 1 $. Correlation near  $ \rho = +1 $ means strong dependence in the same direction: often voting the same. Negative correlation means that  $ y $ tends to be below its mean when  $ x $ is above its mean: Voting in opposite directions.

Example 3 Suppose that $y$ is just $-x$. A coin flip has outputs $x = 0$ or $1$. The same flip has outputs $y = 0$ or $-1$. The mean $m_x$ is $\frac{1}{2}$ for a fair coin, and $m_y$ is $-\frac{1}{2}$. The covariance is $\sigma_{xy} = -\sigma_x \sigma_y$. The correlation divides by $\sigma_x \sigma_y$ to get $\rho_{xy} = -1$. In this case the correlation matrix $R$ has determinant zero (singular and only semidefinite):

Correlation matrix  $ R = \left[\begin{array}{cc} 1 & \rho_{xy} \\ \rho_{xy} & 1 \end{array}\right] $  $ R = \left[\begin{array}{cc} 1 & -1 \\ -1 & 1 \end{array}\right] $ when y = -x

R always has 1's on the diagonal because we normalized to  $ \sigma_X = \sigma_Y = 1 $. R is the correlation matrix for x and y, and the covariance matrix for  $ X = x/\sigma_x $ and  $ Y = y/\sigma_y $.

That number  $ \rho_{xy} $ is also called the Pearson coefficient.

Example 4 Suppose the random variables x, y, z are independent. What matrix is R?

Answer R is the identity matrix. All three correlations  $ \rho_{xx} $,  $ \rho_{yy} $,  $ \rho_{zz} $ are 1 by definition. All three cross-correlations  $ \rho_{xy} $,  $ \rho_{xz} $,  $ \rho_{yz} $ are zero by independence.

The correlation matrix R comes from the covariance matrix V, when we rescale every row and every column. Divide each row i and column i by the ith standard deviation  $ \sigma_{i} $.

(a)  $  R = DVD  $ for the diagonal matrix  $  D = \text{diag}[1/\sigma_1, \ldots, 1/\sigma_M]  $.

(b) If covariance V is positive definite, correlation R = DVD is also positive definite.