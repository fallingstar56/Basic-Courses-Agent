## Change in  $ A^{-1} $ from a Change in A

This final page connects the beginning of the book (inverses and rank one matrices) with the end of the book (dynamic least squares and filters). Begin with this basic formula:

The inverse of  $ M = I - uv^{\mathrm{T}} $ is  $ M^{-1} = I + \frac{uv^{\mathrm{T}}}{1 - v^{\mathrm{T}}u} $

The quickest proof is  $ MM^{-1} = I - uv^T + (1 - uv^T) \frac{uv^T}{1 - v^T u} = I - uv^T + uv^T = I $.

 $ M $ is not invertible if  $ v^T u = 1 $ (then  $ Mu = 0 $). Here  $ v^T = u^T = \begin{bmatrix} 1 & 1 & 1 \end{bmatrix} $:

Example The inverse of  $ M = I - \left[\begin{array}{c} 1\ 1\ 1 \\ 1\ 1\ 1 \\ 1\ 1\ 1 \end{array}\right] $ is  $ M^{-1} = I + \frac{1}{1 - 3} \left[\begin{array}{c} 1\ 1\ 1 \\ 1\ 1\ 1 \\ 1\ 1\ 1 \end{array}\right] $

But we don’t always start from the identity matrix. Many applications need to invert  $ M = A - u v^{\mathrm{T}} $. After we solve  $ Ax = b $ we expect a rank one change to give  $ My = b $. The division by  $ 1 - v^{\mathrm{T}} u $ above will become a division by  $ c = 1 - v^{\mathrm{T}} A^{-1} u = 1 - v^{\mathrm{T}} z $.

Step 1 Solve Az = u and compute  $ c = 1 - v^{\mathrm{T}}z $.

 $$ \begin{array}{r l}{\mathrm{S t e p~2}}&{{}\mathrm{I f~}c\neq0\mathrm{~t h e n~}M^{-1}b\mathrm{~i s~}y=x+\frac{v^{\mathrm{T}}x}{c}z.}\end{array} $$ 

Suppose A is easy to work with. A might already be factored into LU by elimination. Then this Sherman-Woodbury-Morrison formula is the fast way to solve My = b. Here are three problems to end the book!

9 Take Steps 1–2 to find y when A = I and  $ \boldsymbol{u}^{\mathrm{T}} = \boldsymbol{v}^{\mathrm{T}} = [1\ 2\ 3] $ and  $ \boldsymbol{b}^{\mathrm{T}} = [2\ 1\ 4] $.

10 Step 2 in this “update formula” claims that  $ My = (A - uv^\mathrm{T}) \left(x + \frac{v^\mathrm{T} x}{c} z\right) = b $.

Simplify this to  $ \frac{uv^\mathrm{T} x}{c} [1 - c - v^\mathrm{T} z] = 0 $. This is true since  $ c = 1 - v^\mathrm{T} z $.

11 When A has a new row  $ v^{T} $,  $ A^{T}A $ in the least squares equation changes to M :

 $$ \boldsymbol{M}=\left[\begin{array}{ll}\boldsymbol{A}^{\mathrm{T}}&\boldsymbol{v}\end{array}\right]\left|\begin{array}{l}\boldsymbol{A}\\ \boldsymbol{v}^{\mathrm{T}}\end{array}\right|=\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}+\boldsymbol{v}\boldsymbol{v}^{\mathrm{T}}=\text{rank one change in }\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}. $$ 

Why is that multiplication correct? The updated  $ \widehat{x}_{new} $ comes from Steps 1 and 2. For reference here are four formulas for  $ M^{-1} $. The first two were given above, when the change was  $ uv^{T} $. Formulas 3 and 4 go beyond rank one to allow matrices  $ U, V, W $.

 $$ \begin{array}{r l r l r l r l r}{{1}}&{{M=I-{\bf u}{\bf v}^{\mathrm{T}}}}\quad}&{}&{{\mathrm{a n d}}}&{{M^{-1}=I+{\bf u}{\bf v}^{\mathrm{T}}/(\mathrm{~1-}{\bf v}^{\mathrm{T}}{\bf u})}}&{{(r a n k1c h a n g e)}}\end{array} $$ 

 $$ \begin{array}{r l r l r l}{{2}}&{{}M=A-u v^{\mathrm{T}}}&{}&{{\mathrm{a n d}}}&{{}M^{-1}=A^{-1}+A^{-1}u v^{\mathrm{T}}A^{-1}/(1-v^{\mathrm{T}}A^{-1}u)}\end{array} $$ 

 $$ M=I-U V\qquad\quad and\quad M^{-1}=I_{n}+U(I_{m}-V U)^{-1}V $$ 

 $$ 4\quad M=A-U W^{-1}V\quad and\quad M^{-1}=A^{-1}+A^{-1}U(W-VA^{-1}U)^{-1}VA^{-1} $$ 

Formula 4 is the “matrix inversion lemma” in engineering. Not seen until now! The Kalman filter for solving block tridiagonal systems uses formula 4 at each step.