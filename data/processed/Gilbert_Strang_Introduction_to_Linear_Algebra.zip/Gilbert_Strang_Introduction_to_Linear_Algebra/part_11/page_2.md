The binomial theorem in Problem 8 tells us the center probability  $ p_{N/2} $ for any even N:

 $$ \begin{array}{r l r}{\mathrm{T h e~c e n t e r~p r o b a b i l i t y~}\left(\frac{N}{2}\mathrm{~h e a d s,~}\frac{N}{2}\mathrm{~t a i l s}\right)\mathrm{~i s~}}&{{}\frac{1}{2^{N}}\frac{N!}{(N/2)!(N/2)!}}\end{array} $$ 

For $N = 4$, those factorials produce $4!/2! 2! = 24/4 = 6$. For large $N$, Stirling's formula $\sqrt{2\pi N}(N/e)^N$ is a close approximation to $N!$. Use Stirling for $N$ and twice for $N/2$:

Limit of coin-flip Center probability

 $$ p_{N/2}\approx\frac{1}{2^{N}}\frac{\sqrt{2\pi N(N/e)^{N}}}{\pi N(N/2e)^{N}}=\frac{\sqrt{2}}{\sqrt{\pi N}}=\frac{1}{\sqrt{2\pi}\sigma}. $$ 

At that last step we used the variance  $ \sigma^2 = N/4 $ for the coin-tossing problem. The result  $ 1/\sqrt{2\pi}\sigma $ matches the center value (above) for the Gaussian. The Central Limit Theorem is true: The “binomial distribution” approaches the normal distribution as  $ N \to \infty $.

## Monte Carlo Estimation Methods

Scientific computing has to work with errors in the data. Financial computing has to work with unsure numbers and uncertain predictions. All of applied mathematics has moved to accepting uncertainty in the inputs and estimating the variance in the outputs.

How to estimate that variance? Often probability distributions  $ p(x) $ are not known. What we can do is to try different inputs b and compute the outputs x and take an average. This is the simplest form of a Monte Carlo method (named after the gambling palace on the Riviera, where I once saw a fight about whether the bet was placed in time). Monte Carlo approximates an expected value  $ E[x] $ by a sample average  $ (x_1 + \cdots + x_N)/N $.

Please understand that every  $ x_k $ can be expensive to compute. We are not just flipping coins. Each sample comes from a set of data  $ b_k $. Monte Carlo randomly chooses this data  $ b_k $, it computes the outputs  $ x_k $, and then it averages those  $ x' $s. Decent accuracy for  $ \mathbb{E}[x] $ often requires many samples  $ b $ and huge computing cost. The error in approximating  $ \mathbb{E}[x] $ by  $ (x_1 + \cdots + x_N)/N $ is normally of order  $ 1/\sqrt{N} $. Slow improvement as  $ N $ increases.

That  $ 1/\sqrt{N} $ estimate came for coin flips in equation (11). Averaging  $ N $ independent samples  $ x_k $ of variance  $ \sigma^2 $ reduces the variance to  $ \sigma^2/N $.

“Quasi-Monte Carlo” can sometimes reduce this variance to  $ \sigma^2/N^2 $: a big difference! The inputs  $ b_k $ are selected very carefully—not just randomly. This QMC approach is surveyed in the journal Acta Numerica 2013. The newer idea of “Multilevel Monte Carlo” is outlined by Michael Giles in Acta Numerica 2015. Here is how it works.

Suppose it is much simpler to simulate another variable  $ y(b) $ close to  $ x(b) $. Then use  $ N $ computations of  $ y(b_k) $ and only  $ N^* < N $ computations of  $ x(b_k) $ to estimate  $ \mathbf{E}[x] $.

2-level Monte Carlo

 $$ \mathbf{E}[x]\approx\frac{1}{N}\sum_{1}^{N}y(b_{k})+\frac{1}{N^{*}}\sum_{1}^{N^{*}}\left[x(b_{k})-y(b_{k})\right]. $$ 