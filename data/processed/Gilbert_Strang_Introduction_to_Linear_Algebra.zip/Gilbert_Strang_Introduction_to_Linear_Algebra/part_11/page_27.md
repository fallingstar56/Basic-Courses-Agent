Functions, 122, 124

Fundamental Theorem of Algebra, 445

Fundamental Theorem of Calculus, 405

Fundamental Theorem of Linear Algebra, 181, 185, 198

## G

Gain matrix, 560

Galileo, 226

Gambling, 485

Gauss, 51, 557, 559

Gauss-Jordan, 86, 87, 94, 149, 161

Gauss-Seidel method, 524, 526, 527, 531

Gaussian, 540, 542, 555

Gaussian elimination, 51, 508

General (complete) solution, 159

Generalized eigenvector, 421, 422

Geometric mean, 16

Geometric series, 479

Geometry of  $ A = U \Sigma V^{T} $, 392

Gershgorin circles, 297

Giles, 543, 544

Givens rotation, 514, 517

Glued coins, 546, 547, 548, 554

GMRES, 528

Golden mean, 309

Golub-Van Loan, 528

Google, 387, 477

GPS, 553

GPU, 509

Gram-Schmidt, 232, 237, 239, 240, 428, 51

Graph, 76, 186, 187, 452

Graph Laplacian matrix, 457

Grayscale, 364

Greece, 369

Grounded node, 458

Group, 121, 362

Growth factor, 321, 327, 337, 478

## H

Hadamard matrix, 241, 285, 313

Half-plane, 7, 15

Heat equation, 330

Heisenberg, 296, 303

Hermitian matrix, 347, 430, 438, 440

Hessenberg matrix, 265, 530, 534

Hessian matrix, 356

High Definition TV, 365

Hilbert matrix, 95, 257, 357, 368, 426, 516

Hilbert space, 490, 492, 493

Hill Cipher, 504, 505

HITS algorithm, 388

Homogeneous coordinates, 496, 497, 500

Homogeneous solution, 159

Hooke's Law, 467, 468

House matrix, 406, 409

Householder, 241, 513, 515

Hypercube, 285

Hyperplane, 33, 232



## I

Identity matrix, 37

Ill-conditioned, 516

Image processing, 364

Imaginary eigenvalues, 294

Incidence matrix, 186, 452, 456, 459

Incomplete L U, 524

Independent columns, 153

Independent eigenvectors, 305, 306

Independent random variables, 555, 557

Independent vectors, 27, 164, 547

Infinite dimensions, 490

Inner product, 11, 111, 122, 426, 439, 491

Input basis, 411, 412, 421

Integral, 404, 413, 545

Integration by parts, 122

Interior point method, 488

Interlacing, 349

Interpolation, 447

Intersection, 133, 179

Inverse formula, 275, 284

Inverse matrix, 24, 83, 255, 408

Inverse power method, 530, 532

Invertible matrix, 27, 88, 89

Isometric, 416

Iteration, 524

## J

Jacobi's method, 524, 526, 527

Jacobian matrix, 279