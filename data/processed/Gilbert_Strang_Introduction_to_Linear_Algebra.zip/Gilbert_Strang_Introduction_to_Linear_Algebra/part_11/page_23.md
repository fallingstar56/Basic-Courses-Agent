9. A = BJB−1 = (generalized eigenvectors in B) (Jordan blocks in J) (B−1).

Requirements: A is any square matrix. This Jordan form J has a block for each independent eigenvector of A. Every block has only one eigenvalue.

 $$ \mathbf{10}.\ A=U\boldsymbol{\Sigma}V^{\mathrm{T}}=\left(\begin{array}{c}\mathrm{orthogonal}\\ U\mathrm{is}\ m\times m\end{array}\right)\left(\begin{array}{c}m\times n\mathrm{singular}\ value\ matrix\\ \sigma_{1},\ldots,\sigma_{r}\mathrm{on}\ its\ diagonal\end{array}\right)\left(\begin{array}{c}\mathrm{orthogonal}\\ V\mathrm{is}\ n\times n\end{array}\right). $$ 

Requirements: None. This Singular Value Decomposition (SVD) has the eigenvectors of  $ AA^{\mathrm{T}} $ in U and eigenvectors of  $ A^{\mathrm{T}}A $ in V;  $ \sigma_{i} = \sqrt{\lambda_{i}(A^{\mathrm{T}}A)} = \overline{\sqrt{\lambda_{i}(AA^{\mathrm{T}})}} $. Those singular values are  $ \sigma_{1} \geq \sigma_{2} \geq \cdots \geq \sigma_{r} > 0 $. By column-row multiplication

 $$ \begin{array}{r}{A=U\boldsymbol{\Sigma}\boldsymbol{V}^{\mathbf{T}}=\sigma_{1}\boldsymbol{u}_{1}\boldsymbol{v}_{1}^{\mathrm{T}}+\cdots+\sigma_{r}\boldsymbol{u}_{r}\boldsymbol{v}_{r}^{\mathrm{T}}.}\end{array} $$ 

If $S$ is symmetric positive definite then $U = V = Q$ and $\Sigma = \Lambda$ and $S = Q\Lambda Q^{\mathrm{T}}$.

 $$ \boldsymbol{A}^{+}=\boldsymbol{V}\boldsymbol{\Sigma}^{+}\boldsymbol{U}^{\mathrm{T}}=\begin{pmatrix}\operatorname{orthogonal}\\ n\times n\end{pmatrix}\begin{pmatrix}n\times m\text{pseudo inverse of }\boldsymbol{\Sigma}\\ 1/\sigma_{1},\ldots,1/\sigma_{r}\text{on diagonal}\end{pmatrix}\begin{pmatrix}\operatorname{orthogonal}\\ m\times m\end{pmatrix}. $$ 

Requirements: None. The pseudoinverse  $ A^{+} $ has  $ A^{+}A = \text{projection onto row space} $ of  $ A $ and  $ AA^{+} = \text{projection onto column space} $.  $ A^{+} = A^{-1} $ if  $ A $ is invertible. The shortest least-squares solution to  $ Ax = b $ is  $ x^{+} = A^{+}b $. This solves  $ A^{\mathrm{T}}Ax^{+} = A^{\mathrm{T}}b $.

12.  $ A = QS = (\text{orthogonal matrix } Q) $ (symmetric positive definite matrix  $ S $).

Requirements: A is invertible. This polar decomposition has  $ S^{2} = A^{\mathrm{T}} A $. The factor S is semidefinite if A is singular. The reverse polar decomposition A = KQ has  $ K^{2} = AA^{\mathrm{T}} $. Both have  $ Q = UV^{\mathrm{T}} $ from the SVD.

13.  $ A = U \Lambda U^{-1} = (\text{unitary } U) \text{(eigenvalue matrix } \Lambda \text{)} (U^{-1} \text{ which is } U^{\text{H}} = \overline{U}^{\text{T}}) $.

Requirements: A is normal:  $ A^{\mathrm{H}}A = AA^{\mathrm{H}} $. Its orthonormal (and possibly complex) eigenvectors are the columns of U. Complex  $ \lambda $’s unless  $ S = S^{\mathrm{H}} $: Hermitian case.

14.  $ A = QTQ^{-1} = (\text{unitary } Q) $ (triangular  $ T $ with  $ \lambda $'s on diagonal)  $ (Q^{-1} = Q^{\mathrm{H}}) $.

Requirements: Schur triangularization of any square A. There is a matrix Q with orthonormal columns that makes  $ Q^{-1}AQ $ triangular: Section 6.4.

 $$ 15.\ F_{n}=\begin{bmatrix}{{{I}}}&{{{D}}} \\{{{I}}}&{{{-D}}}\end{bmatrix}\begin{bmatrix}{{{F_{n/2}}}} \\{{{F_{n/2}}}}\end{bmatrix}\begin{bmatrix}{{{even-odd}}} \\{{{permutation}}}\end{bmatrix}=one step of the recursive FFT. $$ 

Requirements:  $ F_n = \text{Fourier matrix with entries } w^{jk} \text{ where } w^n = 1: F_n \overline{F}_n = nI $.  $ D \text{ has } 1, w, \ldots, w^{n/2-1} \text{ on its diagonal. For } n = 2^\ell \text{ the Fast Fourier Transform will compute } F_n \boldsymbol{x} \text{ with only } \frac{1}{2} n \ell = \frac{1}{2} n \log_2 n \text{ multiplications from } \ell \text{ stages of } D' \text{ s.}}  $