Dual problem, 485, 489

Duality, 485, 486

Dynamic least squares, 559

## E

Echelon matrix, 138

Economics, 479, 482

Edges, 365

Eigenfaces, 386

Eigenvalue, 248, 288, 289, 292

Eigenvalue computations, 377, 530

Eigenvalue instability, 375

Eigenvalue matrix  $ \Lambda $, 304, 314

Eigenvalues of  $ A^{-1} $, 299

Eigenvalues of  $ A^{T}A $, 378

Eigenvalues of  $ A^{2} $, 289, 304

Eigenvalues of AB, 295, 318

Eigenvalues of  $ e^{At} $, 328

Eigenvalues of permutation, 302

Eigenvector, 288, 289

Eigenvector basis, 416, 421

Eigenvector matrix X, 304, 314

Eigenvector of  $ A^{T}A $, 380

Eight vector space rules, 131

Eigshow, 303, 380

Einstein, 59

Elementary matrix, 60

Elimination, 46, 99, 149, 250, 511

Elimination matrix, 28, 58, 60, 61, 97

Ellipse, 354, 356, 381, 392, 399, 410

Encryption, 505

Energy, 351, 352

Engineering, 462, 463, 465, 466, 468, 470

Enigma, 504

Entry, 37, 59, 70

Equal rows, 250, 275

Error, 208, 220, 525

Error equation, 520, 524, 526

Euler's formula, 434, 456, 460

Even permutation, 118, 248, 267

Even-odd permutation, 448

Exascale, 509

Exchange equations, 49, 508

Existence of solution, 151, 154, 200

Expected value, 536, 544, 545, 548

Exponential matrix, 326, 331

Exponential series, 327, 334

Exponential solution, 319, 320

## F

Face recognition, 386

Face space, 386, 387

Factorial, 113, 543

Factorization, 97, 99, 104, 121, 147, 448

Failure of elimination, 49, 53

False proof, 346

Fast Fourier Transform, 424, 445, 448

Favorite matrix, 86, 264, 357

Feasible set, 483, 484

Fermat's Last Theorem, 502

Fibonacci, 265, 268, 271, 287, 308, 315, 380

Field, 502, 505, 506

Fill-in, 513, 527

Finite element, 473

First order system, 333

Fixed-free, 466, 467, 470

Flag, 366, 369, 370

Flip across diagonal, 111

Flows in networks, 456

Formula for  $ \pi $, 493

Formula for  $ A^{-1} $, 275

Forward difference, 30, 463

Forward Euler, 324

Forward substitution, 56

Four Fundamental Subspaces, 181, 184, 196, 371, 443

Four numbers determine A, 400

Four possible ranks, 155, 161

Fourier coefficient, 427, 493

Fourier matrix, 421, 424, 425, 442, 446

Fourier series, 427, 429, 491, 493

Framework for applications, 467

Fredholm Alternative, 202

Free column, 137, 138, 140

Free variables, 48, 138, 151

Frequency space, 445, 447

Frobenius, 518

Full column rank, 153, 160, 166

Full row rank, 154

Function space, 172, 178, 421, 426, 491, 492