## Non-independent x and y

We are ready to give up independence. The exponent (5) with  $ V^{-1} $ is still correct when V is no longer a diagonal matrix. Now the Gaussian depends on a vector m and a matrix V.

When $M = 2$, the first variable $x$ may give partial information about the second variable $y$ (and vice versa). Maybe part of $y$ is decided by $x$ and part is truly independent. It is the $M$ by $M$ covariance matrix $V$ that accounts for dependencies between the $M$ variables $\boldsymbol{x} = x_1, \ldots, x_M$. Its inverse $V^{-1}$ goes into $p(\boldsymbol{x})$:

Multivariate Gaussian probability distribution

 $$ \left|p(x)=\frac{1}{(\sqrt{2\pi})^{M}\sqrt{\det V}}e^{-(x-m)^{\mathrm{T}}V^{-1}(x-m)/2}\right| $$ 

The vectors  $ \boldsymbol{x} = (x_1, \ldots, x_M) $ and  $ \boldsymbol{m} = (m_1, \ldots, m_M) $ contain the random variables and their means. The  $ M $ square roots of  $ 2\pi $ and the determinant of  $ V $ are included to make the total probability equal to 1. Let me check that by linear algebra. I use the eigenvalues  $ \lambda $ and orthonormal eigenvectors  $ q $ of the symmetric matrix  $ V = Q\Lambda Q^\mathrm{T} $. So  $ V^{-1} = Q\Lambda^{-1}Q^\mathrm{T} $:

 $$ \begin{array}{r l}{X=x-m}&{{}\quad(x-m)^{\mathrm{T}}V^{-1}(x-m)=X^{\mathrm{T}}Q\Lambda^{-1}Q^{\mathrm{T}}X=Y^{\mathrm{T}}\Lambda^{-1}Y}\end{array} $$ 

Notice! The combinations  $ Y = Q^{\mathrm{T}}X = Q^{\mathrm{T}}(x - m) $ are statistically independent. Their covariance matrix  $ \Lambda $ is diagonal.

This step of diagonalizing V by its eigenvector matrix Q is the same as “uncorrelating” the random variables. Covariances are zero for the new variables  $ X_{1}, \ldots, X_{m} $. This is the point where linear algebra helps calculus to compute multidimensional integrals.

The integral of  $  p(\boldsymbol{x})  $ is not changed when we center the variable  $ x $ by subtracting  $ m $ to reach  $ X $, and rotate that variable to reach  $ Y = Q^T X $. The matrix  $ \Lambda $ is diagonal! So the integral we want splits into  $ M $ separate one-dimensional integrals that we know:

 $$ \begin{align*}\int\cdots\int e^{-Y^{\mathrm{T}}\Lambda^{-}\mathbf{1}Y/2}dY&=\left(\int\limits_{-\infty}^{\infty}e^{-y_{1}^{2}/2\lambda_{1}}dy_{1}\right)\cdots\left(\int\limits_{-\infty}^{\infty}e^{-y_{M}^{2}/2\lambda_{M}}dy_{M}\right)\\&=\left(\sqrt{2\pi\lambda_{1}}\right)\cdots\left(\sqrt{2\pi\lambda_{M}}\right)=\left(\sqrt{2\pi}\right)^{M}\sqrt{\det V}.&\quad(7)\end{align*} $$ 

The determinant of V (also the determinant of  $ \Lambda $) is the product  $ (\lambda_1)\ldots(\lambda_M) $ of the eigenvalues. Then (7) gives the correct number to divide by so that  $ p(x_1,\ldots,x_M) $ in equation (6) has integral = 1 as desired.

The mean and variance of  $ p(\boldsymbol{x}) $ are also M-dimensional integrals. The same idea of diagonalizing V by its eigenvectors and introducing  $ Y = Q^{T}X $ will find those integrals:

Vector m of means

 $$ \int\cdots\int x p(x)d x=(m_{1},m_{2},\cdots)=m $$ 

Covariance matrix V

 $$ \int\cdots\int\left(\boldsymbol{x}-\boldsymbol{m}\right)\boldsymbol{p}(\boldsymbol{x})(\boldsymbol{x}-\boldsymbol{m})^{\mathrm{T}}\boldsymbol{d}\boldsymbol{x}=\boldsymbol{V}. $$ 

Conclusion: Formula (6) for the probability density  $ p(\boldsymbol{x}) $ has all the properties we want.