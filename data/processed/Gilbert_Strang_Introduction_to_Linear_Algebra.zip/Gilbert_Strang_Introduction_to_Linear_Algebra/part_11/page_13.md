### Problem Set 12.2

1 (a) Compute the variance  $ \sigma^{2} $ when the coin flip probabilities are p and 1 - p (tails = 0, heads = 1).

(b) The sum of $N$ independent flips (0 or 1) is the count of heads after $N$ tries. The rule (16-17-18) for the variance of a sum gives $\sigma^2 = \underline{\qquad}$ .

2 What is the covariance  $ \sigma_{kl} $ between the results  $ x_1, \ldots, x_n $ of Experiment 3 and the results  $ y_1, \ldots, y_n $ of Experiment 5? Your formula will look like  $ \sigma_{12} $ in equation (2). Then the (3, 5) and (5, 3) entries of the covariance matrix V are  $ \sigma_{35} = \sigma_{53} $.

3 For $M = 3$ experiments, the variance-covariance matrix $V$ will be 3 by 3. There will be a probability $p_{ijk}$ that the three outputs are $x_i$ and $y_j$ and $z_k$. Write down a formula like equation (7) for the matrix $V$.

4 What is the covariance matrix V for M = 3 independent experiments with means  $ m_{1}, m_{2}, m_{3} $ and variances  $ \sigma_{1}^{2}, \sigma_{2}^{2}, \sigma_{3}^{2} $?

Problems 5–9 are about the conditional probability that  $ Y = y_j $ when we know  $ X = x_i $

Notation:  $ \mathbf{Prob}(Y = y_j | X = x_i) = \text{probability of the outcome } y_j \text{ given that } X = x_i $.

Example 1 Coin 1 is glued to coin 2. Then Prob(Y = heads when X = heads) is 1.

Example 2 Independent coin flips: X gives no information about Y. Useless to know X.

Then Prob (Y = heads | X = heads) is the same as Prob (Y = heads).

5 Explain the sum rule of conditional probability :

 $$  Prob\left(Y=y_{j}\right)=\  sum over all outputs x_{i} of Prob\left(Y=y_{j}|X=x_{i}\right). $$ 

6 The n by n matrix P contains joint probabilities  $ p_{ij} = \text{Prob}(X = x_i \text{ and } Y = y_j) $.

Explain why the conditional Prob  $ (Y = y_j | X = x_i) $ equals  $ \frac{p_{ij}}{p_{i1} + \cdots + p_{in}} = \frac{p_{ij}}{p_i} $.

7 For this joint probability matrix with Prob (x1, y2) = 0.3, find Prob (y2|x1) and Prob (x1).

 $$ \boldsymbol{P}=\left[\begin{array}{ll}p_{11}&p_{12}\\ p_{21}&p_{22}\end{array}\right]=\left[\begin{array}{ll}0.1&0.3\\ 0.2&0.4\end{array}\right] $$ 

The entries  $ p_{ij} $ add to 1. Some i, j must happen.

8 Explain the product rule of conditional probability:

pij = Prob (X = xi and Y = yj) equals Prob (Y = yj|X = xi) times Prob (X = xi).

9 Derive this Bayes Theorem for  $ p_{ij} $ from the product rule in Problem 8:

 $$ \mathrm{Prob}\left(Y=y_{j}\ \mathbf{and}\ X=x_{i}\right)=\frac{\mathrm{Prob}\left(X=x_{i}|Y=y_{j}\right)\mathrm{Prob}\left(Y=y_{j}\right)}{\mathrm{Prob}\left(X=x_{i}\right)} $$ 