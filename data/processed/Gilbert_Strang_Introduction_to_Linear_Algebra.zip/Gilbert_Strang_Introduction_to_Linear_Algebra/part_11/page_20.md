3 If $x$ and $y$ are independent with probabilities $p_{1}(x)$ and $p_{2}(y)$, then $p(x,y) = p_{1}(x)p_{2}(y)$. By separating double integrals into products of single integrals $(-\infty$ to $\infty)$ show that

 $$ \iint p(x,y)dx dy=\mathbf{1}\qquad and\qquad\iint(x+y)p(x,y)dx dy=m_{\mathbf{1}}+m_{\mathbf{2}}. $$ 

Continue Problem 3 for independent x, y to show that  $ p(x, y) = p_{1}(x) p_{2}(y) $ has

 $$ \begin{aligned}\iint(x-m_{1})^{2}p(x,y)dx dy=\sigma_{1}^{2}\quad\iint(x-m_{1})(y-m_{2})p(x,y)dx dy=\mathbf{0}.\end{aligned} $$ 

So the 2 by 2 covariance matrix V is diagonal and its entries are ___.

5 Show that the inverse of a 2 by 2 covariance matrix V is

 $$ V^{-1}=\begin{bmatrix}\sigma_{1}^{2}&\sigma_{12}\\ \sigma_{12}&\sigma_{2}^{2}\end{bmatrix}^{-1}=\frac{1}{1-\rho^{2}}\begin{bmatrix}1/\sigma_{1}^{2}&-\rho/\sigma_{1}\sigma_{2}\\ -\rho/\sigma_{1}\sigma_{2}&1/\sigma_{2}^{2}\end{bmatrix}\quad with correlation\quad\rho=\sigma_{12}/\sigma_{1}\sigma_{2}. $$ 

This produces the exponent  $ -(x - m)^{\mathrm{T}} V^{-1}(x - m) $ in a 2-variable Gaussian.

Suppose  $ \widehat{x}_{k} $ is the average of  $ b_{1}, \ldots, b_{k} $. A new measurement  $ b_{k+1} $ arrives and we want the new average  $ \widehat{x}_{k+1} $. The Kalman update equation (17) is

New average

 $$ \widehat{x}_{k+1}=\widehat{x}_{k}+\frac{1}{k+1}\left(b_{k+1}-\widehat{x}_{k}\right). $$ 

Verify that  $ \widehat{x}_{k+1} $ is the correct average of  $ b_{1}\ldots,b_{k+1} $.

Also check the update equation (18) for the variance  $ W_{k+1} = \sigma^2/(k+1) $ of this average  $ \widehat{x} $ assuming that  $ W_k = \sigma^2/k $ and  $ b_{k+1} $ has variance  $ V = \sigma^2 $.

(Steady model) Problems 6–7 were static least squares. All the sample averages  $ \widehat{x}_{k} $ were estimates of the same x. To make the Kalman filter dynamic, include also a state equation  $ x_{k+1} = Fx_{k} $ with its own error variance  $ s^{2} $. The dynamic least squares problem allows x to “drift” as k increases:

 $$ \left[\begin{array}{c c}{1}&{}\\ {-F}&{1}\\ {}&{1}\\ \end{array}\right]\quad\left[\begin{matrix}{x_{0}}\\ {x_{1}}\\ \end{matrix}\right]\quad=\left[\begin{array}{c}{b_{0}}\\ {0}\\ {b_{1}}\\ \end{array}\right]\mathrm{~w i t h~v a r i a n c e s~}\quad\left[\begin{array}{c}{\sigma^{2}}\\ {s^{2}}\\ {\sigma^{2}}\\ \end{array}\right]. $$ 

With $F = 1$, divide both sides of those three equations by $\sigma$, $s$, and $\sigma$. Find $\widehat{x_0}$ and $\widehat{x_1}$ by least squares, which gives more weight to the recent $b_1$. The Kalman filter is developed in Algorithms for Global Positioning (Borre and Strang, Wellesley-Cambridge Press).