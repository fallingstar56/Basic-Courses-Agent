## Weighted Least Squares

In Chapter 4, least squares started from an unsolvable system  $ Ax = b $. We chose  $ \widehat{x} $ to minimize the error  $ \|b - Ax\|^2 $. That led us to the least squares equation  $ A^\mathrm{T}A\widehat{x} = A^\mathrm{T}b $. The best  $ A\widehat{x} $ is the projection of  $ b $ onto the column space of  $ A $. But is this squared distance  $ E = \|b - Ax\|^2 $ the right error measure to minimize?

If the measurement errors in $b$ are independent random variables, with mean $m = 0$ and variance $\sigma^2 = 1$ and a normal distribution, Gauss would say $\mathbf{yes}$: Use least squares. If the errors are not independent or their variances are not equal, Gauss would say $\mathbf{no}$: Use weighted least squares. This section will show that the good measure of error is $E = (b - Ax)^\mathrm{T}V^{-1}(b - Ax)$. The equation for the best $\widehat{\mathbf{x}}$ uses the covariance matrix $V$:

Weighted least squares

 $$ A^{\mathrm{T}}V^{-1}A\widehat{x}=A^{\mathrm{T}}V^{-1}b. $$ 

The most important examples have m independent errors in b. Those errors have variances  $ \sigma_1^2, \ldots, \sigma_m^2 $. By independence, V is a diagonal matrix. The good weights  $ 1/\sigma_1^2, \ldots, 1/\sigma_m^2 $ come from  $ V^{-1} $. We are weighting the errors in b to have  $ \text{variance} = 1 $:

Weighted least squares

Independent errors in b

Minimize



 $$ \begin{array}{r}{E=\displaystyle\sum_{i=1}^{m}\frac{(\pmb{b}-A\pmb{x})_{i}^{2}}{\sigma_{i}^{2}}}\end{array} $$ 

By weighting the errors, we are “whitening” the noise. White noise is a quick description of independent errors based on the standard Gaussian  $ \mathbf{N}(0,1) $ with mean zero and  $ \sigma^{2}=1 $.

Let me write down the steps to equations (10) and (11) for the best 🔊:

Start with Ax = b (m equations, n unknowns, m > n, no solution)

Each right side  $ b_i $ has mean zero and variance  $ \sigma_i^2 $. The  $ b_i $ are independent.

Divide the ith equation by  $ \sigma_i $ to have variance = 1 for every  $ b_i/\sigma_i $

That division turns Ax = b into V−1/2Ax = V−1/2b with V−1/2 = diag (1/σ1, …, 1/σm)

Ordinary least squares on those weighted equations has  $ A \rightarrow V^{-1/2} A $ and  $ b \rightarrow V^{-1/2} b $

 $$ (V^{-1/2}A)^{\mathrm{T}}(V^{-1/2}A)\widehat{\boldsymbol{x}}=(V^{-1/2}A)^{\mathrm{T}}V^{-1/2}\boldsymbol{b}\quad\mathrm{i s}\quad A^{\mathrm{T}}V^{-1}A\widehat{\boldsymbol{x}}=A^{\mathrm{T}}V^{-1}\boldsymbol{b}. $$ 

Because of  $ 1/\sigma^2 $ in  $ V^{-1} $, more reliable equations (smaller  $ \sigma $) get heavier weights. This is the main point of weighted least squares.

Those diagonal weightings (uncoupled equations) are the most frequent and the simplest. They apply to independent errors in the  $ b_{i} $. When these measurement errors are not independent, V is no longer diagonal—but (12) is still the correct weighted equation.

In practice, finding all the covariances can be serious work. Diagonal V is simpler.