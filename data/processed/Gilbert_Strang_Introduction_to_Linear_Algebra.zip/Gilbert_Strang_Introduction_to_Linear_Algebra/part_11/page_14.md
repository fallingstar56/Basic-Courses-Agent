### 12.3 Multivariate Gaussian and Weighted Least Squares

The normal probability density  $ p(x) $ (the Gaussian) depends on only two numbers:

Mean m and variance  $ \sigma^{2} $

 $$ p(x)=\frac{1}{\sqrt{2\pi}\sigma}e^{-(x-m)^{2}/2\sigma^{2}}. $$ 

The graph of  $ p(x) $ is a bell-shaped curve centered at  $ x = m $. The continuous variable  $ x $ can be anywhere between  $ -\infty $ and  $ \infty $. With probability close to  $ \frac{2}{3} $, that random  $ x $ will lie between  $ m - \sigma $ and  $ m + \sigma $ (less than one standard deviation  $ \sigma $ from its mean value  $ m $).

 $$ \begin{array}{r l}{\displaystyle\int_{-\infty}^{\infty}p(x)d x=1}&{{}\mathrm{~a n d~}\quad\displaystyle\int_{m-\sigma}^{m+\sigma}p(x)d x=\frac{1}{\sqrt{2\pi}}\displaystyle\int_{-1}^{1}e^{-X^{2}/2}d X\approx\frac{2}{3}.}\end{array} $$ 

That integral has a change of variables from $x$ to $X = (x - m)/\sigma$. This simplifies the exponent to $-X^2/2$ and it simplifies the limits of integration to $-1$ and $1$. Even the $1/\sigma$ from $p$ disappears outside the integral because $dX$ equals $dx/\sigma$. Every Gaussian turns into a standard Gaussian $p(X)$ with mean $m = 0$ and variance $\sigma^2 = 1$. Just call it $p(x)$:

The standard normal distribution N(0,1) has  $  p(x) = \frac{1}{\sqrt{2\pi}} e^{-x^2/2}  $

Integrating $p(x)$ from $-\infty$ to $x$ gives the cumulative distribution $F(x)$: the probability that a random sample is below $x$. That probability will be $F = \frac{1}{\sigma}$ at $x = 0$ (the mean).

## Two-dimensional Gaussians

Now we have  $ M = 2 $ Gaussian random variables  $ x $ and  $ y $. They have means  $ m_1 $ and  $ m_2 $. They have variances  $ \sigma_1^2 $ and  $ \sigma_2^2 $. If they are independent, then their probability density  $ p(x, y) $ is just  $ p_1(x) $ times  $ p_2(y) $. Multiply probabilities when variables are independent:

Independent x and y

 $$ p(x,y)=\frac{1}{2\pi\sigma_{1}\sigma_{2}}\ e^{-(x-m_{1})^{2}/2\sigma_{1}^{2}}e^{-(y-m_{2})^{2}/2\sigma_{2}^{2}} $$ 

The covariance of $x$ and $y$ will be $\sigma_{12} = 0$. The covariance matrix $V$ will be diagonal. The variances $\sigma_{1}^{2}$ and $\sigma_{2}^{2}$ are always on the main diagonal of $V$. The exponent in $p(x, y)$ is just the sum of the $x$-exponent and the $y$-exponent. Good to notice that the two exponents can be combined into $-\frac{1}{2}(x - m)^{\mathrm{T}} V^{-1}(x - m)$ with $V^{-1}$ in the middle:

 $$ -\frac{(x-m_{1})^{2}}{2\sigma_{1}^{2}}-\frac{(y-m_{2})^{2}}{2\sigma_{2}^{2}}=-\frac{1}{2}\left[x-m_{1}\quad y-m_{2}\right]\begin{bmatrix}{{{\sigma_{1}^{2}}}}&{{{0}}} \\{{{0}}}&{{{\sigma_{2}^{2}}}}\end{bmatrix}^{-1}\begin{bmatrix}{{{x-m_{1}}}} \\{{{y-m_{2}}}}\end{bmatrix} $$ 