## The Covariance Matrix V is Positive Semidefinite

Come back to the expected covariance  $ \sigma_{12} $ between two experiments 1 and 2 (two coins):

 $$ \begin{aligned}\sigma_{12}&=\text{expected value of}\left[\left(output1-mean1\right)\text{times}\left(output2-mean2\right)\right]\\&=\sum\sum p_{ij}\left(x_{i}-m_{1}\right)\left(y_{j}-m_{2}\right).\\&\quad\text{all}i,j\end{aligned} $$ 

 $ p_{ij} \geq 0 $ is the probability of seeing output  $ x_i $ in experiment 1 and  $ y_j $ in experiment 2. Some pair of outputs must appear. Therefore the  $ N^2 $ probabilities  $ p_{ij} $ add to 1.

Total probability (all pairs) is 1

 $$ \sum_{all}\sum_{i,j}p_{ij}=1. $$ 

Here is another fact we need. Fix on one particular output  $ x_i $ in experiment 1. Allow all outputs  $ y_j $ in experiment 2. Add the probabilities of  $ (x_i, y_1), (x_i, y_2), \ldots, (x_i, y_n) $:

 $$ \begin{array}{c} Row sum p_{i} of P\quad\sum\limits_{j=1}^{n}p_{ij}=probability p_{i} of x_{i} in experiment1.\end{array} $$ 

Some  $ y_j $ must happen in experiment 2! Whether the two coins are completely separate or glued together, we still get  $ \frac{1}{2} $ for the probability  $ p_H = p_{HH} + p_{HT} $ that coin 1 is heads:

 $$ \left(separate\right)P_{HH}+P_{HT}=\frac{1}{4}+\frac{1}{4}=\frac{1}{2}\qquad\left(glued\right)P_{HH}+P_{HT}=\frac{1}{2}+0=\frac{1}{2}. $$ 

That basic reasoning allows us to write one matrix formula that includes the covariance  $ \sigma_{12} $ along with the separate variances  $ \sigma_{1}^{2} $ and  $ \sigma_{2}^{2} $ for experiment 1 and experiment 2. We get the whole covariance matrix V by adding the matrices  $ V_{ij} $ for each pair  $ (i,j) $:

 $$ \begin{array}{r l}{\left|\begin{array}{l l}{\mathbf{C o v a r i a n c e}\mathbf{m a t r i x}}\\ {V=\boldsymbol{\Sigma}\boldsymbol{\Sigma}V_{i j}}&{V=\displaystyle\sum_{\mathrm{a l l}}\displaystyle\sum_{i,j}p_{i j}\left[\begin{matrix}{(x_{i}-m_{1})^{2}}&{(x_{i}-m_{1})(y_{j}-m_{2})}\\ {(x_{i}-m_{1})(y_{j}-m_{2})}&{(y_{j}-m_{2})^{2}}\end{matrix}\right]}\end{array}\right|}\end{array} $$ 

Off the diagonal, this is equation (2) for the covariance  $ \sigma_{12} $. On the diagonal, we are getting the ordinary variances  $ \sigma_{1}^{2} $ and  $ \sigma_{2}^{2} $. I will show in detail how we get  $ V_{11} = \sigma_{1}^{2} $ by using equation (6). Allowing all j just leaves the probability  $ p_{i} $ of  $ x_{i} $ in experiment 1:

 $$ V_{11}=\sum_{\mathrm{all}}\sum_{i,j}p_{ij}(x_{i}-m_{1})^{2}=\sum_{\mathrm{all}i}(\mathrm{probability of}x_{i})(x_{i}-m_{1})^{2}=\sigma_{1}^{2}. $$ 

Please look at that twice. It is the key to producing the whole covariance matrix by one formula (7). The beauty of that formula is that it combines 2 by 2 matrices  $ V_{ij} $. And the matrix  $ V_{ij} $ in (7) for each pair of outcomes i, j is positive semidefinite:

 $$ V_{i j}\mathrm{~h a s~d i a g o n a l~e n t r i e s~}p_{i j}(x_{i}-m_{1})^{2}\geq0\mathrm{~a n d~}p_{i j}(y_{j}-m_{2})^{2}\geq0\mathrm{~a n d~}\operatorname*{d e t}(V_{i j})=0. $$ 