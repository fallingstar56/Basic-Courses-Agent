5 (a little tricky) Sample again from 1 to 1000 with equal probabilities and let $x$ be the first digit ($x = 1$ if the number is 15). What are the probabilities $p_1$ to $p_9$ (adding to 1) of $x = 1, \ldots, 9$? What are the mean and variance of $x$?

6 Suppose you have N = 4 samples 157, 312, 696, 602 in Problem 5. What are the first digits  $ x_1 $ to  $ x_4 $ of the squares? What is the sample mean  $ \mu $? What is the sample variance  $ S^2 $? Remember to divide by N - 1 = 3 and not N = 4.

7 Equation (4) gave a second equivalent form for $S^{2}$ (the variance using samples):

 $$ S^{2}=\frac{1}{N-1}\operatorname{s u m}\operatorname{o f}\left(x_{i}-m\right)^{2}=\frac{1}{N-1}\left[\left(\operatorname{s u m}\operatorname{o f}x_{i}^{2}\right)-N m^{2}\right]. $$ 

Verify the matching identity for the expected variance σ² (using m = ∑pᵢ xᵢ):

 $$ \sigma^{2}=\mathrm{s u m~o f~}p_{i}\left(x_{i}-m\right)^{2}=\left(\mathrm{s u m~o f~}p_{i}x_{i}^{2}\right)-m^{2}. $$ 

8 If all 24 samples from a population produce the same age x = 20, what are the sample mean  $ \mu $ and the sample variance  $ S^{2} $? What if x = 20 or 21, 12 times each?

9 Computer experiment as on page 541: Find the average  $ A_{1000000} $ of a million random 0-1 samples! What is  $ X = \left(A_{N} - \frac{1}{2}\right)/2\sqrt{N} $?

10 The probability  $ p_i $ to get  $ i $ heads in  $ N $ coin flips is the binomial number  $ b_i = \binom{N}{i} $ divided by  $ 2^N $. The  $ b_i $ add to  $ (1 + 1)^N = 2^N $ so the probabilities  $ p_i $ add to 1.

 $$ p_{0}+\cdots+p_{N}=\left(\frac{1}{2}+\frac{1}{2}\right)^{N}=\frac{1}{2^{N}}(b_{0}+\cdots+b_{N})with b_{i}=\frac{N!}{i!(N-i)!} $$ 

 $$ N=4leads to b_{0}=\frac{24}{24},b_{1}=\frac{24}{(1)(6)}=4,b_{2}=\frac{24}{(2)(2)}=6,p_{i}=\frac{1}{16}(1,4,6,4,1). $$ 

Notice bᵢ = bₙ₋ᵢ. Problem: Confirm that the mean m = 0p₀ + · · + Npₙ equals  $ \frac{N}{2} $.

For any function $f(x)$ the expected value is $\mathrm{E}[f] = \sum p_i f(x_i)$ or $\int p(x) \, f(x) \, dx$ (discrete probability or continuous probability). Suppose the mean is $\mathrm{E}[x] = m$ and the variance is $\mathrm{E}[(x - m)^2] = \sigma^2$. What is $\mathrm{E}[x^2]$?

Show that the standard normal distribution $p(x)$ has total probability $\int p(x) \, dx = 1$ as required. A famous trick multiplies $\int p(x) \, dx$ by $\int p(y) \, dy$ and computes the integral over all $x$ and all $y$ ($-\infty$ to $\infty$). The trick is to replace $dx \, dy$ in that double integral by $r \, dr \, d\theta$ (polar coordinates with $x^2 + y^2 = r^2$). Explain each step:

 $$ 2\pi\int\limits_{-\infty}^{\infty}p(x)dx\int\limits_{-\infty}^{\infty}p(y)dy=\iint\limits_{-\infty}^{\infty}e^{-(x^{2}+y^{2})/2}dx dy=\int\limits_{\theta=0}^{2\pi}\int\limits_{r=0}^{\infty}e^{-r^{2}/2}r dr d\theta=2\pi. $$ 