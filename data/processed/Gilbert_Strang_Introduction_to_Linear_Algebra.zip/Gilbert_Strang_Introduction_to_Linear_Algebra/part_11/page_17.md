## The Variance in the Estimated  $ \hat{x} $

One more point: Often the important question is not the best  $ \hat{x} $ for one particular set of measurements b. This is only one sample! The real goal is to know the reliability of the whole experiment. That is measured (as reliability always is) by the variance in the estimate  $ \hat{x} $. First, zero mean in b gives zero mean in  $ \hat{x} $. Then the formula connecting variance V in the inputs b to variance W in the outputs  $ \hat{x} $ turns out to be beautiful:

Variance-covariance matrix W for  $ \hat{x} $

 $$ \mathrm{E}[(\widehat{x}-x)(\widehat{x}-x)^{\mathrm{T}}]=(A^{\mathrm{T}}V^{-1}A)^{-1}. $$ 

That smallest possible variance comes from the best possible weighting, which is V−1.

This key formula is a perfect application of Section 12.2. If $b$ has covariance matrix $V$, then $\widehat{x} = Lb$ has covariance matrix $LVL^\mathrm{T}$. Equation (12) above tells us that $L$ is $(A^\mathrm{T}V^{-1}A)^{-1}A^\mathrm{T}V^{-1}$. Now substitute this into $LVL^\mathrm{T}$ and watch equation (13) appear:

 $$ \boldsymbol{L}\boldsymbol{V}\boldsymbol{L}^{\mathrm{T}}=(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{V}^{-1}\boldsymbol{A})^{-1}\boldsymbol{A}^{\mathrm{T}}\boldsymbol{V}^{-1}\quad\boldsymbol{V}\quad\boldsymbol{V}^{-1}\boldsymbol{A}\left(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{V}^{-1}\boldsymbol{A}\right)^{-1}=\left(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{V}^{-1}\boldsymbol{A}\right)^{-1}. $$ 

This is the covariance W of the output, our best estimate  $ \hat{x} $. It is time for examples.

Example 1 Suppose a doctor measures your heart rate x three times  $  (m = 3, n = 1)  $:

 $$ \begin{array}{l}{{{x=b\quad.}}} \\{{{x=b_{2}\quad\mathrm{i s}\quad A x=b\quad\mathrm{w i t h}\quad A=\left[\begin{array}{l l l}1}}} \\{{{1}}} \\{{{1}}}\end{array}\right]\quad\mathrm{a n d}\quad V=\left[\begin{array}{c c c}{{{\sigma_{1}^{2}}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{\sigma_{2}^{2}}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{\sigma_{3}^{2}}}}\end{array}\right]\end{array} $$ 

The variances could be  $ \sigma_1^2 $ · /9 and  $ \sigma_2^2 = 1/4 $ and  $ \sigma_3^2 = 1 $. You are getting more nervous as measurements are taken: ; is less reliable than  $ b_2 $ and  $ b_1 $. All three measurements contain some information, so they all go into the best (weighted) estimate  $ \widehat{x} $:

 $$ V^{-1/2}A\widehat{\boldsymbol{x}}=V^{-1/2}\boldsymbol{b}\quad is\quad\begin{array}{l}3x=3b_{1}\\ 2x=2b_{2}\\ 1x=1b_{3}\end{array}\quad leading to\quad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{V}^{-1}\boldsymbol{A}\widehat{\boldsymbol{x}}=\boldsymbol{A}^{\mathrm{T}}\boldsymbol{V}^{-1}\boldsymbol{b} $$ 

 $$ \left[\begin{array}{l l l}{{{1}}}&{{{1}}}&{{{1}}} \\\end{array}\right]\left[\begin{array}{l l l}{{{9}}} \\{{{4}}} \\{{{1}}} \\\end{array}\right]\left[\begin{array}{l l l}{{{1}}} \\{{{1}}} \\{{{1}}} \\\end{array}\right]\widehat{\boldsymbol{x}}=\left[\begin{array}{l l l}{{{1}}}&{{{1}}}&{{{1}}} \\\end{array}\right]\left[\begin{array}{l l l}{{{9}}} \\{{{4}}} \\{{{1}}} \\\end{array}\right]\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}} \\\end{array}\right] $$ 

 $$ \left|\begin{array}{c c}{\hat{x}=\frac{9b_{1}+4b_{2}+b_{3}}{14}}&{\mathrm{i s~a~w e i g h t e d~a v e r a g e~o f~}b_{1},b_{2},b_{3}}\\ \end{array}\right. $$ 