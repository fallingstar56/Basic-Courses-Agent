dependence or independence of x and y doesn't matter. Expected values still add :

 $$ \mathbf{E}[\boldsymbol{x}+\boldsymbol{y}]=\sum_{i}\sum_{j}p_{ij}(x_{i}+y_{j})=\sum_{i}\sum_{j}p_{ij}x_{i}+\sum_{i}\sum_{j}p_{ij}y_{j}. $$ 

All the sums go from 1 to N. We can add in any order. For the first term on the right side, add the  $ p_{ij} $ along row i of the probability matrix P to get  $ p_i $. That double sum gives E[x]:

 $$ \sum_{i}\sum_{j}p_{ij}x_{i}=\sum_{i}(p_{i1}+\cdots+p_{iN})x_{i}=\sum_{i}p_{i}x_{i}=\mathrm{E}[x]. $$ 

For the last term, add  $ p_{ij} $ down column j of the matrix to get the probability  $ P_{j} $ of  $ y_{j} $. Those pairs  $ (x_{1},y_{j}) $ and  $ (x_{2},y_{j}) $ and  $ \ldots $ and  $ (x_{N},y_{j}) $ are all the ways to produce  $ y_{j} $:

 $$ \sum_{i}\sum_{j}p_{ij}y_{j}=\sum_{j}(p_{1j}+\cdots+p_{Nj})y_{j}=\sum_{j}P_{j}y_{j}=\mathbf{E}[y]. $$ 

Now equation (15) says that  $ \mathrm{E}[x + y] = \mathrm{E}[x] + \mathrm{E}[y] $.

What about the variance of  $ z = x + y $? The joint probabilities  $ p_{ij} $ and the covariance  $ \sigma_{xy} $ will be involved. Let me separate the variance of  $ x + y $ into three simple pieces:

 $$ \begin{aligned}\sigma_{z}^{2}&=\sum\sum p_{ij}(x_{i}+y_{j}-m_{x}-m_{y})^{2}\\&=\sum\sum p_{ij}(x_{i}-m_{x})^{2}+\sum\sum p_{ij}(y_{j}-m_{y})^{2}+2\sum\sum p_{ij}(x_{i}-m_{x})(y_{j}-m_{y})\end{aligned} $$ 

The first piece is  $ \sigma_{x}^{2} $. The second piece is  $ \sigma_{y}^{2} $. The last piece is  $ 2\sigma_{xy} $.

The variance of  $ z = x + y $ is  $ \sigma_{z}^{2} = \sigma_{x}^{2} + \sigma_{y}^{2} + 2\sigma_{xy} $.

## The Covariance Matrix for Z = AX

Here is a good way to see  $ \sigma_z^2 $ when  $ z = x + y $. Think of  $ (x, y) $ as a column vector  $ X $. Think of the 1 by 2 matrix  $ A = \begin{bmatrix} 1 & 1 \end{bmatrix} $ multiplying that vector  $ X $. Then  $ AX $ is the sum  $ z = x + y $. The variance  $ \sigma_z^2 $ in equation (16) goes into matrix notation as

 $$ \sigma_{z}^{2}=\left[\begin{array}{cc}{{{1}}}&{{{1}}} \\\end{array}\right]\left[\begin{array}{cc}{{{\sigma_{x}^{2}}}}&{{{\sigma_{xy}}}} \\{{{\sigma_{xy}}}}&{{{\sigma_{y}^{2}}}} \\\end{array}\right]\left[\begin{array}{c}{{{1}}} \\{{{1}}} \\\end{array}\right]\quad which is\quad\sigma_{z}^{2}=A V A^{\mathrm{T}}. $$ 

You can see that  $ \sigma_{z}^{2} = AVA^{\mathrm{T}} $ in (17) agrees with  $ \sigma_{x}^{2} + \sigma_{y}^{2} + 2\sigma_{xy} $ in (16).

Now for the main point. The vector X could have M components coming from M experiments (instead of only 2). Those experiments will have an M by M covariance matrix  $ V_X $. The matrix A could be K by M. Then AX is a vector with K combinations of the M outputs (instead of 1 combination  $ x + y $ of 2 outputs).

That vector  $ \mathbf{Z} = A\mathbf{X} $ of length  $ K $ has a  $ K $ by  $ K $ covariance matrix  $ V_{\mathbf{Z}} $. Then the great rule for covariance matrices—of which equation (17) was only a 1 by 2 example—is this beautiful formula: Covariance matrix of  $ A\mathbf{X} $ is  $ A $ (covariance matrix of  $ \mathbf{X} $)  $ A^{\mathrm{T}} $:

The covariance matrix of

 $$ \mathbf{Z}=\mathbf{A}\mathbf{X}\textbf{i s}\mathbf{\nabla}V_{\mathbf{Z}}=\mathbf{A}V_{\mathbf{X}}\mathbf{A}^{\mathrm{T}} $$ 

To me, this neat formula shows the beauty of matrix multiplication. I won’t prove this formula, just admire it. It is constantly used in applications—coming in Section 12.3.