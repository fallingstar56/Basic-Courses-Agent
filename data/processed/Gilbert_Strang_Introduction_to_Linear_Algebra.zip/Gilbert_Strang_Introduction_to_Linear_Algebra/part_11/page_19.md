 $$ \begin{array}{r l}{\left[\begin{array}{l l}{A_{0}^{\mathrm{T}}}&{A_{1}^{\mathrm{T}}}\end{array}\right]\left[\begin{matrix}{V_{0}^{-1}}\\ {V_{1}^{-1}}\end{matrix}\right]\left[\begin{matrix}{A_{0}}\\ {A_{1}}\end{matrix}\right]\widehat{\boldsymbol{x}}_{1}=}&{\left[\begin{array}{l l}{A_{0}^{\mathrm{T}}}&{A_{1}^{\mathrm{T}}}\end{array}\right]\left[\begin{matrix}{V_{0}^{-1}}\\ {V_{1}^{-1}}\end{matrix}\right]\left[\begin{matrix}{b_{0}}\\ {b_{1}}\end{matrix}\right].}\end{array} $$ 

Yes, we could just solve that new problem and forget the old one. But the old solution  $ \hat{x}_0 $ needed work that we hope to reuse in  $ \hat{x}_1 $. What we look for is an update to  $ \hat{x}_0 $:

Kalman update gives  $ \hat{x}_{1} $ from  $ \hat{x}_{0} $

 $$ \widehat{x}_{1}=\widehat{x}_{0}+K_{1}(b_{1}-A_{1}\widehat{x}_{0}). $$ 

The update correction is the mismatch  $ b_1 - A_1 \widehat{x}_0 $ between the old state  $ \widehat{x}_0 $ and the new measurements  $ b_1 $—multiplied by the Kalman gain matrix  $ K_1 $. The formula for  $ K_1 $ comes from comparing the solutions  $ \widehat{x}_1 $ and  $ \widehat{x}_0 $ to (15) and (16). And when we update  $ \widehat{x}_0 $ to  $ \widehat{x}_1 $ based on new data  $ b_1 $, we also update the covariance matrix  $ W_0 $ to  $ W_1 $. Remember  $ W_0 = (A_0^\mathrm{T} V_0^{-1} A_0)^{-1} $ from equation (13). Update its inverse to  $ W_1^{-1} $:

Covariance  $ W_{1} $ of errors in  $ \hat{x}_{1} $

 $$ W_{1}^{-1}=W_{0}^{-1}+A_{1}^{\mathrm{T}}V_{1}^{-1}A_{1} $$ 

Kalman gain matrix  $ K_{1} $

 $$ K_{1}=W_{1}A_{1}^{\mathrm{T}}V_{1}^{-1} $$ 

This is the heart of the Kalman filter. Notice the importance of the  $ W_k $. Those matrices measure the reliability of the whole process, where the vector  $ \widehat{x}_k $ estimates the current state based on the particular measurements  $ b_0 $ to  $ b_k $.

Whole chapters and whole books are written to explain the dynamic Kalman filter, when the states  $ x_{k} $ are also changing (based on the matrices  $ F_{k} $). There is a prediction of  $ x_{k} $ using F, followed by a correction using the new data b. Perhaps best to stop here.

This page was about recursive least squares: adding new data  $ b_{k} $ and updating both  $ \hat{x} $ and W: the best current estimate based on all the data, and its covariance matrix.

### Problem Set 12.3

Two measurements of the same variable $x$ give two equations $x = b_1$ and $x = b_2$. Suppose the means are zero and the variances are $\sigma_1^2$ and $\sigma_2^2$, with independent errors: $V$ is diagonal with entries $\sigma_1^2$ and $\sigma_2^2$. Write the two equations as $Ax = b$ ($A$ is 2 by 1). As in the text Example 1, find this best estimate $\hat{x}$ based on $b_1$ and $b_2$:

 $$ \widehat{\boldsymbol{x}}=\frac{b_{1}/\sigma_{1}^{2}+b_{2}/\sigma_{2}^{2}}{1/\sigma_{1}^{2}+1/\sigma_{2}^{2}}\qquad\mathrm{E}\left[\widehat{\boldsymbol{x}}\widehat{\boldsymbol{x}}^{\mathrm{T}}\right]=\left(\frac{1}{\sigma_{1}^{2}}+\frac{1}{\sigma_{2}^{2}}\right)^{-1}. $$ 

2 (a) In Problem 1, suppose the second measurement $b_{2}$ becomes super-exact and its variance $\sigma_{2} \to 0$. What is the best estimate $\widehat{x}$ when $\sigma_{2}$ reaches zero?

(b) The opposite case has  $ \sigma_2 \to \infty $ and no information in  $ b_2 $. What is now the best estimate  $ \hat{x} $ based on  $ b_1 $ and  $ b_2 $?