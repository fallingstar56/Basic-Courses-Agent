Stirling's formula, 543

Straight line, 223, 231

Stretching, 279, 392, 394

Stripes on flag, 369

Submatrix, 38, 146, 263

Subspace, 123, 125, 126, 130, 132

Sum matrix, 29, 90, 276

Sum of eigenvalues, 294, 300

Sum of errors, 228

Sum of spaces, 179

Sum of squares, 353

Super Bowl, 387

Supercomputer, 509

SVD, 364, 370, 372, 392

Symmetric factorization, 116

Symmetric matrix, 87, 111, 338

## T

Table of eigenvalues, 363

Test, 350, 359

Test for minimum, 356, 361

Three-dimensional space, 4

Tic-tac-toe, 193

Time to maturity, 389

TOP500, 509

Total least squares, 384

Total variance, 383, 389

Trace, 294, 300, 316, 325, 380, 383

Training set, 386

Transform, 236

Transformation, 401, 402

Translation matrix, 496

Transpose matrix, 109, 117, 122, 417

Transpose of inverse, 110

Trapezoidal, 336

Tree, 187, 314, 453

Trefethen-Bau, 528

Triangle area, 276

Triangle inequality, 16, 17, 20, 393, 523

Triangular matrix, 52, 89, 100, 251

Tridiagonal matrix, 87, 107, 268, 363, 377

Triple product, 112, 281, 286

Turing, 504

Two-dimensional Gaussian, 555

## u

U.S. Treasury, 389

Uncertainty principle, 296, 303

Underdamping, 337

Underdetermined, 154

Uniform distribution, 537, 539

Unique solution, 153, 168, 200

Unit circle, 432

Unit vector, 13, 14

Unitary matrix, 430, 441, 446

Unsquared errors, 559

Update, 214, 218, 559, 560, 562

Upper left submatrix, 259, 352

Upper triangular, 46, 87

## V

Vandermonde, 256, 269, 447

Variance, 230, 535, 537, 539, 545, 551

Variance in  $ \widehat{x} $, 558

Vector addition, 2, 32

Vector space, 123, 124

Vertical distances, 220, 384

Voltage, 187, 454, 457

Volume, 42, 278

## W

Wall, 203

Wave equation, 330

Wavelets, 245

Web matrix, 387

Weight function, 426

Weighted least squares, 557

White noise, 557

## Y

Yield curve, 389, 390

## Z

Zero determinant, 247

Zero nullspace, 138

Zero vector, 2, 3, 166, 167