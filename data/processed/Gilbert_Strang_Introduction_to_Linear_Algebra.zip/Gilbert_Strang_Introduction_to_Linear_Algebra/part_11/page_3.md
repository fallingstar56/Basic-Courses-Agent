The idea is that $x - y$ has a smaller variance $\sigma^{*}$ than the original $x$. Therefore $N^{*}$ can be smaller than $N$, with the same accuracy for $\mathrm{E}[x]$. We do $N$ cheap simulations to find the $y$'s. Those cost $C$ each. We only do $N^{*}$ expensive simulations involving $x$'s. Those cost $C^{*}$ each. The total computing cost is $NC + N^{*}C^{*}$.

Calculus minimizes the overall variance for a fixed total cost. The optimal ratio  $ N^{*}/N $ is  $ \sqrt{C/C^{*}} \sigma^{*}/\sigma $. Three-level Monte Carlo would simulate x, y, and z:

 $$ \mathrm{E}[x]\approx\frac{1}{N}\sum_{1}^{N}z(b_{k})+\frac{1}{N^{*}}\sum_{1}^{N^{*}}\left[y(b_{k})-z(b_{k})\right]+\frac{1}{N^{**}}\sum_{1}^{N^{**}}\left[x(b_{k})-y(b_{k})\right]. $$ 

Giles optimizes  $ N, N^{*}, N^{**}, \ldots $ to keep  $ E[x] \leq \text{fixed } E_0 $, and provides a MATLAB code.

## Review: Three Formulas for the Mean and the Variance

The formulas for $m$ and $\sigma^{2}$ are the starting point for all of probability and statistics. There are three different cases to keep straight: sample values $X_{i}$, expected values (discrete $p_{i}$), and a range of expected values (continuous $p(x)$). Here are the mean and the variance:

 $$  Samples X_{1}to X_{N}\qquad m=\frac{X_{1}+\cdots+X_{N}}{N}\ S^{2}=\frac{(X_{1}-m)^{2}+\cdots+(X_{N}-m)^{2}}{N-1} $$ 

 $$ m=\sum_{1}^{n}p_{i}x_{i}\quad 閑 \quad\sigma^{2}=\sum_{1}^{n}p_{i}(x_{i}-m)^{2} $$ 

 $$ \boldsymbol{m}=\int x\ p(x)d x\qquad\quad\boldsymbol{\sigma}^{2}=\int(x-m)^{2}p(x)d x $$ 

A natural question: Why are there no probabilities $p$ on the first line? How can these formulas be parallel? Answer: We expect a fraction $p_i$ of the samples to be $X = x_i$. If this is exactly true, $X = x_i$ is repeated $p_i N$ times. Then lines 1 and 2 give the same $m$.

When we work with samples, we don’t know the  $ p_{i} $. We just include each output X as often as it comes. We get the “empirical” mean instead of the expected mean.

### Problem Set 12.1

1 Add 7 to every output x. What happens to the mean and the variance? What are the new sample mean, the new expected mean, and the new variance?

2 We know:  $ \frac{1}{3} $ of all integers are divisible by 3 and  $ \frac{1}{7} $ of integers are divisible by 7. What fraction of integers will be divisible by 3 or 7 or both?

3 Suppose you sample from the numbers 1 to 1000 with equal probabilities 1/1000. What are the probabilities  $ p_0 $ to  $ p_9 $ that the last digit of your sample is 0, ..., 9? What is the expected mean  $ m $ of that last digit? What is its variance  $ \sigma^2 $?

4 Sample again from 1 to 1000 but look at the last digit of the sample squared. That square could end with $x = 0, 1, 4, 5, 6, \text{or } 9$. What are the probabilities $p_0, p_1, p_4, p_5$, $p_6, p_9$? What are the (expected) mean $m$ and variance $\sigma^2$ of that number $x?$