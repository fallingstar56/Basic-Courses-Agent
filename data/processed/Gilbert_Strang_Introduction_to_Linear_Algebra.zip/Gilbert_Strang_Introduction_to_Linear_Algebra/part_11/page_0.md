## Example 2 Suppose x is 1 or -1 with equal probabilities  $ p_1 = p_{-1} = \frac{1}{2} $

The mean value is  $ m = \frac{1}{2}(1) + \frac{1}{2}(-1) = 0 $. The variance is  $ \sigma^2 = \frac{1}{2}(1)^2 + \frac{1}{2}(-1)^2 = 1 $. The key question is the average  $ A_N = (x_1 + \cdots + x_N)/N $. The independent  $ x_i $ are  $ \pm 1 $ and we are dividing their sum by  $ N $. The expected mean of  $ A_N $ is still zero. The law of large numbers says that this sample average approaches zero with probability 1. How fast does  $ A_N $ approach zero? What is its variance  $ \sigma_N^2 $?

By linearity  $ \sigma_{N}^{2}=\frac{\sigma^{2}}{N^{2}}+\frac{\sigma^{2}}{N^{2}}+\cdots+\frac{\sigma^{2}}{N^{2}}=N\frac{\sigma^{2}}{N^{2}}=\frac{1}{N} $ since  $ \sigma^{2}=1 $.

Example 3 Change outputs from 1 or -1 to x = 1 or x = 0. Keep  $ p_1 = p_0 = \frac{1}{2} $. The new mean value  $ m = \frac{1}{2} $ falls halfway between 0 and 1. The variance moves to  $ \sigma^2 = \frac{1}{4} $

 $$ \boldsymbol{m}=\frac{1}{2}(1)+\frac{1}{2}(0)=\frac{1}{2}\quad and\quad\boldsymbol{\sigma}^{2}=\frac{1}{2}\left(1-\frac{1}{2}\right)^{2}+\frac{1}{2}\left(0-\frac{1}{2}\right)^{2}=\frac{1}{4}. $$ 

The average  $ A_N $ now has mean  $ \frac{1}{2} $ and variance  $ \frac{1}{4N^2} + \cdots + \frac{1}{4N^2} = \frac{1}{4N} = \sigma_N^2 $.

This  $ \sigma_N $ is half the size of  $ \sigma_N $ in Example 2. This must be correct because the new range 0 to 1 is half as long as -1 to 1. Examples 2-3 are showing a law of linearity.

The new 0 - 1 variable  $ x_{\text{new}} $ is  $ \frac{1}{2} x_{\text{old}} + \frac{1}{2} $. So the mean  $ m $ is increased to  $ \frac{1}{2} $ and the variance is multiplied by  $ \left(\frac{1}{2}\right)^2 $. A shift changes  $ m $ and the rescaling changes  $ \sigma^2 $.

Linearity  $ x_{\text{new}} = ax_{\text{old}} + b $ has  $ m_{\text{new}} = am_{\text{old}} + b $ and  $ \sigma_{\text{new}}^2 = a^2 \sigma_{\text{old}}^2 $.

Here are the results from three numerical tests: random 0 or 1 averaged over N trials.

[48 1's from N = 100] [5035 1's from N = 10000] [19967 1's from N = 40000].

The standardized  $ X = (x - m)/\sigma = (A_N - \frac{1}{2}) / 2\sqrt{N} $ was  $ [-0.40] [0.70] [-0.33] $.

The Central Limit Theorem says that the average of many coin flips will approach a normal distribution. Let us begin to see how that happens: binomial approaches normal.

For each flip, the probability of heads is  $ \frac{1}{2} $. For  $ N = 3 $ flips, the probability of heads all three times is  $ \left(\frac{1}{2}\right)^3 = \frac{1}{8} $. The probability of heads twice and tails once is  $ \frac{3}{8} $, from three sequences HHT and HTH and THH. These numbers  $ \frac{1}{8} $ and  $ \frac{3}{8} $ are pieces of  $ \left(\frac{1}{2} + \frac{1}{2}\right)^3 = \frac{1}{8} + \frac{3}{8} + \frac{3}{8} + \frac{1}{8} = 1 $. The average number of heads in 3 flips is 1.5.

Mean  $ m = (3 \text{ heads}) \frac{1}{8} + (2 \text{ heads}) \frac{3}{8} + (1 \text{ head}) \frac{3}{8} + 0 = \frac{3}{8} + \frac{6}{8} + \frac{3}{8} = 1.5 \text{ heads} $