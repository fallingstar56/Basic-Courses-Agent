## MATRIX FACTORIZATIONS

 $$ \begin{array}{l}1.\quad A=L U=\left(\begin{array}{c}lower triangular L\\1^{\prime}s on the diagonal\end{array}\right)\left(\begin{array}{c}upper triangular U\\pivots on the diagonal\end{array}\right)\end{array} $$ 

Requirements: No row exchanges as Gaussian elimination reduces square A to U.

 $$ 2.\quad A=L D U=\left(\begin{array}{c}lower triangular L\\1^{\prime}s on the diagonal\end{array}\right)\left(\begin{array}{c}p i v o t matrix\\D is diagonal\end{array}\right)\left(\begin{array}{c}upper triangular U\\1^{\prime}s on the diagonal\end{array}\right) $$ 

Requirements: No row exchanges. The pivots in $D$ are divided out to leave 1's on the diagonal of $U$. If $A$ is symmetric then $U$ is $L^{\mathrm{T}}$ and $A = LDL^{\mathrm{T}}$.

3.  $ PA = LU $ (permutation matrix P to avoid zeros in the pivot positions).

Requirements: A is invertible. Then $P, L, U$ are invertible. $P$ does all of the row exchanges on $A$ in advance, to allow normal $LU$. Alternative: $A = L_{1}P_{1}U_{1}$.

4.  $ EA = R $ (m by m invertible  $ E $) (any m by n matrix  $ A $) = rref( $ A $).

Requirements: None! The reduced row echelon form R has r pivot rows and pivot columns, containing the identity matrix. The last m - r rows of E are a basis for the left nullspace of A; they multiply A to give m - r zero rows in R. The first r columns of  $ E^{-1} $ are a basis for the column space of A.

5.  $ S = C^{\mathrm{T}} C = (\text{lower triangular}) (\text{upper triangular}) \text{ with } \sqrt{D} \text{ on both diagonals} $

Requirements: $S$ is symmetric and positive definite (all $n$ pivots in $D$ are positive). This Cholesky factorization $C = \text{chol}(S)$ has $C^\text{T} = L\sqrt{D}$, so $S = C^\text{T}C = LDL^\text{T}$.

6.  $ A = QR = (\text{orthonormal columns in } Q) $ (upper triangular  $ R $).

Requirements: A has independent columns. Those are orthogonalized in Q by the Gram-Schmidt or Householder process. If A is square then  $ Q^{-1} = Q^{\mathrm{T}} $.

7.  $ A = X \Lambda X^{-1} = (\text{eigenvectors in } X) (\text{eigenvalues in } \Lambda) (\text{left eigenvectors in } X^{-1}) $.

Requirements: A must have n linearly independent eigenvectors.

8.  $  S = Q \Lambda Q^{\mathrm{T}} = (\text{orthogonal matrix } Q)  $ (real eigenvalue matrix  $ \Lambda $) ( $ Q^{\mathrm{T}} $ is  $ Q^{-1} $).

Requirements:  $  S  $ is real and symmetric:  $  S^{\mathrm{T}} = S  $. This is the Spectral Theorem.