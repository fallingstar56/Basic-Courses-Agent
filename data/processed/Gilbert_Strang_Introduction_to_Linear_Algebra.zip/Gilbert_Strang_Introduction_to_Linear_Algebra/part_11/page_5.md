### 12.2 Covariance Matrices and Joint Probabilities

Linear algebra enters when we run $M$ different experiments at once. We might measure age and height and weight ($M = 3$ measurements of $N$ people). Each experiment has its own mean value. So we have a vector $\boldsymbol{m} = (m_{1}, m_{2}, m_{3})$ containing the $M$ mean values. Those could be sample means of age and height and weight. Or $m_{1}, m_{2}, m_{3}$ could be expected values of age, height, weight based on known probabilities.

A matrix becomes involved when we look at variances. Each experiment will have a sample variance  $ S_i^2 $ or an expected  $ \sigma_i^2 = \mathrm{E}\left[(x_i - m_i)^2\right] $ based on the squared distance from its mean. Those  $ M $ numbers  $ \sigma_1^2, \ldots, \sigma_M^2 $ will go on the main diagonal of the matrix. So far we have made no connection between the  $ M $ parallel experiments. They measure  $ M $ different random variables, but the experiments are not necessarily independent!

If we measure age and height and weight  $ (a, h, w) $ for children, the results will be strongly correlated. Older children are generally taller and heavier. Suppose the means  $ m_a $,  $ m_h $,  $ m_w $ are known. Then  $ \sigma_a^2 $,  $ \sigma_h^2 $,  $ \sigma_w^2 $ are the separate variances in age, height, weight. The new numbers are the covariances like  $ \sigma_{ah} $, where age multiplies height.

 $$ \begin{array}{r l}{\mathrm{C o v a r i a n c e}}&{{}\sigma_{a h}=\mathrm{E}\left[\left(\mathrm{a g e}-\mathrm{m e a n a g e}\right)(\mathrm{h e i g h t}-\mathrm{m e a n h e i g h t})\right].}\end{array} $$ 

This definition needs a close look. To compute  $ \sigma_{ah} $, it is not enough to know the probability of each age and the probability of each height. We have to know the joint probability of each pair (age and height). This is because age is connected to height.

 $ p_{ah} = $ probability that a random child has age = a and height = h: both at once

 $ p_{ij} = \text{probability that experiment 1 produces } x_i \text{ and experiment 2 produces } y_j $

Suppose experiment 1 (age) has mean  $ m_{1} $. Experiment 2 (height) has mean  $ m_{2} $. The covariance in (1) between experiments 1 and 2 looks at all pairs of ages  $ x_{i} $, heights  $ y_{j} $:

Covariance

 $$ \left.\sigma_{12}=\sum\sum_{all}p_{ij}(x_{i}-m_{1})(y_{j}-m_{2})\right| $$ 

To capture this idea of “joint probability  $ p_{ij} $” we begin with two small examples.

Example 1 Flip two coins separately. With 1 for heads and 0 for tails, the results can be  $ (1,1) $ or  $ (1,0) $ or  $ (0,1) $ or  $ (0,0) $. Those four outcomes all have probability  $ p_{11} = p_{10} = p_{01} = p_{00} = \frac{1}{4} $. Independent experiments have Prob of  $ (i,j) = (\text{Prob of } i) $ (Prob of j).

Example 2 Glue the coins together, facing the same way. The only possibilities are  $ (1,1) $ and  $ (0,0) $. Those have probabilities  $ \frac{1}{2} $ and  $ \frac{1}{2} $. The probabilities  $ p_{10} $ and  $ p_{01} $ are zero.  $ (1,0) $ and  $ (0,1) $ won't happen because the coins stick together: both heads or both tails.

Probability matrices for Examples 1 and 2

 $$ \boldsymbol{P}=\left[\begin{array}{ll}{{{p_{11}}}}&{{{p_{12}}}} \\{{{p_{21}}}}&{{{p_{22}}}}\end{array}\right]=\left[\begin{array}{cc}{{{\frac{1}{4}}}}&{{{\frac{1}{4}}}} \\{{{\frac{1}{4}}}}&{{{\frac{1}{4}}}}\end{array}\right]\qquad\boldsymbol{P}=\left[\begin{array}{cc}{{{\frac{1}{2}}}}&{{{0}}} \\{{{0}}}&{{{\frac{1}{2}}}}\end{array}\right]. $$ 