Normal matrix, 348, 444

Not diagonalizable, 306, 312, 429

Nullspace, 135, 147

Nullspace of  $ A^{T}A $, 203, 212, 217

## O

Odd permutation, 249, 261

Ohm's Law, 189, 458

One at a time, 376

Operation count, 511

Optimal solution, 483

Order of importance, 371

Orthogonal columns, 224, 447

Orthogonal complement, 197, 198

Orthogonal eigenvectors, 340, 440

Orthogonal matrix, 234, 241, 242, 295, 494

Orthogonal subspaces, 195, 196, 203

Orthogonal vectors, 194, 233, 430

Orthonormal basis, 371, 492

Orthonormal columns, 234, 236, 441

Orthonormal eigenvectors, 338, 348

Orthonormal vectors, 233, 237

Outer product (see columns times rows), 81

Output basis, 411, 412, 413

## P

P-value, 385

PageRank, 388

Parabola, 226, 227, 464

Paradox, 347

Parallel plane, 41, 483

Parallelogram, 3, 8, 277

Parentheses, 61, 73, 83

Partial pivoting, 115, 508, 510, 516

Particular solution, 151, 153, 334, 462

Pascal matrix, 91, 103, 271, 357

PCA, 382, 383, 389

Permutation matrix, 49, 62, 63, 109, 113, 116, 179, 303, 424

Perpendicular, 11

Perpendicular distances, 384

Perron-Frobenius theorem, 477, 482

Pivot, 46, 47, 88, 137, 378, 508, 510

Pivot columns, 137, 138, 169

Pivot formula, 258

Pivot matrix, 106

Pivot variables, 138, 151

Pixel, 364, 499

Plane, 1, 5, 128

Plane rotation, 498

Polar decomposition, 392, 394

Polar form, 285, 430, 433

Population, 384, 478

Positive definite, 350, 469, 547, 549

Positive definite matrix, 352, 359

Positive matrix, 474, 477

Positive semidefinite, 350, 354

Power method, 388, 529, 532

Powers of A, 121, 305, 307, 310, 315, 525

Preconditioner, 524, 528

Primal problem, 489

Prime number, 503

Principal axis theorem, 339

Principal Component Analysis, 382, 389

Probability, 535, 538

Probability density (pdf), 538, 544, 555

Probability matrix, 547, 554

Probability vector, 475

Product inequality, 393

Product of eigenvalues, 294, 300, 342

Product of pivots, 248, 342

Product rule, 252, 266, 273, 554

Projection, 206, 208, 236, 395, 496, 498

Projection matrix, 206, 209, 211, 216, 236, 291, 415, 501

Pseudoinverse, 198, 225, 392, 395, 399, 404

Pythagoras, 13, 14, 20, 194

## Q

Quadratic formula, 309, 437

Quantum mechanics, 111, 296

## R

Random matrix, 57, 541

rank(AB), 147

Range, 402, 405

Rank, 139, 146, 155, 171, 181, 190, 366, 369

Rank one matrix, 140, 188, 318, 372, 400

Rank one update, 562

Rayleigh quotient, 376, 519