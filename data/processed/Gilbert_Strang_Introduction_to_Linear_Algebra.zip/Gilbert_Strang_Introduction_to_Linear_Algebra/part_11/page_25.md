Cofactor, 263, 264, 267

Cofactor matrix, 275, 284

Coin flip, 536, 541, 543, 546, 554

Column at a time, 22, 38

Column picture, 31, 32, 34, 36

Column rank, 150, 152

Column space, 127, 156, 182

Column vector, 4, 123

Columns times rows, 65, 72, 140, 147

Combination (linear), 9

Combination of basis vectors, 168

Combination of columns, 22, 127

Combination of eigenvectors, 310, 321

Commutative law, 61

Commuting matrices, 317

Companion matrix, 301, 322

Complement, 197, 207

Complete graph, 453, 461

Complete solution, 151, 153, 154, 463

Complex conjugate, 341, 430, 432, 436

Complex eigenvalues, 341

Complex inner product, 426

Complex number, 430, 431

Complex plane, 431, 432

Complex symmetry, 346

Components, 2

Compression, 365, 368

Computational science, 472, 473

Computer graphics, 402, 496

Condition number, 379, 509, 520, 521, 522

Conditional probability, 554

Conductance, 458

Conductance matrix, 469

Confounding, 385

Congruent, 349, 502

Conjugate gradient method, 509, 528, 533

Conjugate transpose, 438, 439

Conservation, 455

Constant coefficients, 319, 322

Constant diagonals, 425

Constraint, 483

Consumption matrix, 478, 479, 480

Convergence, 480, 525

Corner, 484, 486

Corner submatrix, 259

Correlation matrix, 384, 552

Cosine, 11, 15, 16, 17, 490

Cosine Law, 20

Cosine matrix, 336, 344

Cost vector, 483, 484

Counting Theorem, 142, 179, 185, 404

Covariance, 383, 546, 547

Covariance matrix, 230, 547, 549, 553, 556

Cramer's Rule, 273, 274, 282, 283

Cross product, 279, 280

Cryptography, 502, 503, 505, 507

Cube, 8, 10, 501

Cumulative distribution, 537, 540

Current Law (Kirchhoff), 145, 455, 456

Cyclic, 25, 30, 425

Cyclic matrix, 363

## D

Data matrix, 382

Delta function, 492, 495

Dense matrix, 101

Dependent, 27, 164, 165, 175

Dependent columns, 225, 354, 396

Derivative, 122, 404, 413

Determinant, 84, 87, 115, 247, 249, 352

Determinant of  $ A - \lambda I $, 292, 293

Determinant of  $ A^{T} $ and  $ A^{-1} $ and  $ AB $, 252

Diagonal matrix, 84, 304, 384

Diagonalizable, 311, 327

Diagonalization, 304, 305, 339, 371

Diagonally dominant, 89, 297

Difference coding, 365

Difference equation, 310, 323

Difference matrix, 23, 90, 96, 108

Differential equation, 319, 337, 422, 462

Diffusion, 473

Dimension, 141, 164, 171, 181, 184, 201

Discrete Fourier Transform (DFT), 344, 424, 435, 442

Distance to subspace, 213

Domain, 402

Dot product, 11, 15, 17, 23, 71, 111

Dot product matrix, 223, 426

Double angle, 415, 434