Confession I am not entirely happy with that proof based on  $ c^{\mathrm{T}}Vc \geq 0 $. The expectation symbol E is burying the key idea of joint probability. Allow me to show directly that V is positive semidefinite (at least for the age-height-weight example). The proof is simply that V is the sum of the joint probability  $ p_{ahw} $ of each combination (age, height, weight) times the positive semidefinite matrix  $ UU^{\mathrm{T}} $. Here U is  $ X - \overline{X} $:

 $$ \begin{array}{r}{\boldsymbol{V}=\displaystyle\sum_{\mathrm{a l l}a,h,w}p_{a h w}\boldsymbol{U}\boldsymbol{U}^{\mathrm{T}}\quad\mathrm{w i t h}\quad\boldsymbol{U}=\left[\begin{array}{l}{\mathrm{a g e}}\\ {\mathrm{h e i g h t}}\\ {\mathrm{w e i g h t}}\end{array}\right]-\left[\begin{array}{l}{\mathrm{m e a n a g e}}\\ {\mathrm{m e a n h e i g h t}}\\ {\mathrm{m e a n w e i g h t}}\end{array}\right].}\end{array} $$ 

This is exactly like the 2 by 2 coin flip matrix V in equation (7). Now M = 3.

The value of the expectation symbol E is that it also allows pdf’s (probability density functions like  $ p(x, y, z) $ for continuous random variables x and y and z). If we allow all numbers as ages and heights and weights, instead of age  $ i = 0, 1, 2, 3, \ldots $, then we need  $ p(x, y, z) $ instead of  $ p_{ijk} $. The sums in this section of the book would all change to integrals. But we still have  $ V = E \left[ U U^{\mathrm{T}} \right] $:

 $$ \mathbf{Covariance matrix~V}=\iiint p(x,y,z)\mathbf{U}\mathbf{U}^{\mathrm{T}}dx dy dz\quad with\quad\mathbf{U}=\begin{bmatrix}x-\overline{x}\\ y-\overline{y}\\ z-\overline{z}\end{bmatrix}. $$ 

Always ∫∫f p = 1. Examples 1–2 emphasized how p can give diagonal V or singular V:

Independent variables x, y, z  $ p(x, y, z) = p_{1}(x) p_{2}(y) p_{3}(z) $.

Dependent variables  $ x, y, z $  $ p(x, y, z) = 0 $ except when  $ cx + dy + ez = 0 $.

## The Mean and Variance of z = x + y

Start with the sample mean. We have $N$ samples of $x$. Their mean (= average) is $m_{x}$. We also have $N$ samples of $y$ and their mean is $m_{y}$. The sample mean of $z = x + y$ is clearly $m_{z} = m_{x} + m_{y}$:

 $$ \mathrm{Mean~of~sum~=~Sum~of~means~}\quad\frac{1}{N}\sum_{1}^{N}(x_{i}+y_{i})=\frac{1}{N}\sum_{1}^{N}x_{i}+\frac{1}{N}\sum_{1}^{N}y_{i}. $$ 

Nice to see something that simple. The expected mean of  $ z = x + y $ doesn't look so simple, but it must come out as  $ \mathbf{E}[z] = \mathbf{E}[x] + \mathbf{E}[y] $. Here is one way to see this.

The joint probability of the pair  $ (x_{i}, y_{j}) $ is  $ p_{ij} $. Its value depends on whether the experiments are independent, which we don’t know. But for the mean of the sum  $ z = x + y $,