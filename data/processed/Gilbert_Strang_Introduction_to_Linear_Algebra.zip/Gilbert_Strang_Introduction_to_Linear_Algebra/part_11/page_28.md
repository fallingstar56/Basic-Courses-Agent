Joint probability, 546, 550, 554

Jordan form, 308, 421, 423, 429, 525

Jordan matrix, 422, 423

JPEG, 344

## K

Kalman filter, 218, 559, 560, 561

Kernel, 405

Kirchhoff's Laws, 145, 187, 189, 455

Krylov space, 533

## L

Lagrange multiplier, 488

Lanczos method, 533, 534

Laplace transform, 337

Largest ratio, 393

Law of Inertia, 349

Law of large numbers, 536

Lax, 317, 348

Leapfrog method, 324, 325, 336

Least squares, 220, 226, 239, 240, 396

Left eigenvectors, 318

Left inverse, 83, 148, 397

Left nullspace, 181, 183, 185

Legendre polynomial, 428, 494

Length, 11, 438, 490, 491

Line, 5

Line of springs, 467

Linear combination, 1, 3, 9, 33

Linear independence, 164, 165, 167, 175

Linear programming, 483, 485

Linear transformation, 401, 402, 407, 411

Linearity, 45, 403, 411, 541

Loadings, 390

Loop, 187, 314, 453, 456

Lower triangular, 98

Lucas numbers, 312

## M

Magic matrix, 44

Map of Europe, 385

Markov equation, 332, 481

Markov matrix, 290, 301, 387, 474, 476, 480

Mass matrix, 324

Matching signs, 342

Mathematical finance, 473

Matrix, 7, 22, 37

Matrix exponential, 326

Matrix for transformation, 413

Matrix inversion lemma, 562

Matrix multiplication, 58, 62, 70, 414

Matrix powers, 74, 80

Matrix space, 125, 126, 171, 172, 178, 409

Max = min, 485

Maximum ratio, 376

Mean, 230, 535, 538

Mean square error, 227

Mechanical engineering, 462, 463, 465, 468

Median, 228

Medical genetics, 385

Minimum of function, 356, 361, 381

Minimum cost, 483, 485, 486

Minor, 263

Model Order Reduction, 387

Modified Gram-Schmidt, 240

Modular arithmetic, 502, 504

Monte Carlo, 543

Moore's Law, 509

Multigrid, 528

Multiplication, 71, 72, 74, 414

Multiplication by rows/columns, 36, 37, 72

Multiplication count, 71, 82, 101

Multiplicity of eigenvalues, 311

Multiplier, 46, 47, 51, 85, 97, 105, 508

Multiply pivots, 251

Multivariate Gaussian, 556



## N

Nearest singular matrix, 395

Network, 76, 458, 469

No solution, 26, 40, 48, 220

Nodes, 187, 454

Noise, 219, 230, 427

Nondiagonalizable matrix, 306, 311

Nonnegative Factorization, 386

Nonnegative matrix, 479

Nonzero solution, 139

Norm, 393, 394, 518, 519

Normal distribution, 537, 539, 540

Normal equation, 211, 219