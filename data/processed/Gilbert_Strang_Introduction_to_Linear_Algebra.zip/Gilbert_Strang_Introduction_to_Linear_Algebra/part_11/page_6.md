Let me stay longer with $P$, to show it in good matrix notation. The matrix shows the probability $p_{ij}$ of each pair $(x_i, y_j)$—starting with $(x_1, y_1) = (\text{heads}, \text{heads})$ and $(x_1, y_2) = (\text{heads}, \text{tails})$. Notice the row sums $p_i$ and column sums $P_j$ and the total sum = 1.

Probability matrix

 $$ P=\left[\begin{array}{l l}p_{11}&p_{12}\\ p_{21}&p_{22}\end{array}\right]\quad\begin{array}{l}p_{11}+p_{12}=p_{1}\\ p_{21}+p_{22}=p_{2}\end{array}\left(\begin{array}{l}\text{first}\\ \text{coin}\end{array}\right) $$ 

 $$ (\mathrm{second~coin}) column~sums\quad P_{1}\quad P_{2}\quad\quad4\mathrm{~entries~add~to~}1 $$ 

Those numbers  $ p_{1}, p_{2} $ and  $ P_{1}, P_{2} $ are called the marginals of the matrix P:

 $$ p_{1}=p_{11}+p_{12}=chance of heads from coin1(coin2 can be heads or tails) $$ 

 $$ P_{1}=p_{11}+p_{21}=chance of heads from coin2(coin1 can be heads or tails) $$ 

Example 1 showed independent variables. Every probability  $ p_{ij} $ equals  $ p_i $ times  $ p_j $ ( $ \frac{1}{2} $ times  $ \frac{1}{2} $ gave  $ p_{ij} = \frac{1}{4} $ in that example). In this case the covariance  $ \sigma_{12} $ will be zero. Heads or tails from the first coin gave no information about the second coin.

Zero covariance  $ \sigma_{12} $ for independent trials

 $$ V=\left[\begin{array}{c c}{{{\sigma_{1}^{2}}}}&{{{0}}} \\{{{0}}}&{{{\sigma_{2}^{2}}}}\end{array}\right]=\mathrm{d i a g o n a l c o v a r i a n c e}\mathrm{m a t r i x.} $$ 

Independent experiments have  $ \sigma_{12} = 0 $ because every  $ p_{ij} = (p_i)(p_j) $ in equation (2):

 $$ \sigma_{12}=\sum_{i}\sum_{j}(p_{i})(p_{j})(x_{i}-m_{1})(y_{j}-m_{2})=\left[\sum_{i}(p_{i})(x_{i}-m_{1})\right]\left[\sum_{j}(p_{j})(y_{j}-m_{2})\right]=[\mathbf{0}][\mathbf{0}]. $$ 

The glued coins show perfect correlation. Heads on one means heads on the other. The covariance  $ \sigma_{12} $ moves from 0 to  $ \sigma_{1}\sigma_{2} = \frac{1}{4} $—this is the largest possible value of  $ \sigma_{12} $:

 $$ \mathrm{Means}=\frac{1}{2}\qquad\sigma_{12}=\frac{1}{2}\left(1-\frac{1}{2}\right)\left(1-\frac{1}{2}\right)+\mathbf{0}+\mathbf{0}+\frac{1}{2}\left(0-\frac{1}{2}\right)\left(0-\frac{1}{2}\right)=\frac{1}{4} $$ 

Heads or tails from coin 1 gives complete information about heads or tails from coin 2:

Glued coins give largest possible covariances

Singular covariance matrix: determinant = 0

 $$ V_{\mathrm{g l u e}}=\left[\begin{array}{c c}\sigma_{1}^{2}&\sigma_{1}\sigma_{2}\\ \sigma_{1}\sigma_{2}&\sigma_{2}^{2}\end{array}\right] $$ 

Always  $ \sigma_1^2 \sigma_2^2 \geq \sigma_{12}^2 $. Thus  $ \sigma_{12} $ is between  $ -\sigma_1 \sigma_2 $ and  $ \sigma_1 \sigma_2 $. The covariance matrix  $ V $ is positive definite (or in this singular case of glued coins,  $ V $ is positive semidefinite). That is an important fact about  $ M $ by  $ M $ covariance matrices for  $ M $ experiments.

Note that the sample covariance matrix $S$ from $N$ trials is certainly semidefinite. Every new sample $X = (\text{age}, \text{height}, \text{weight})$ contributes to the sample mean $\overline{X}$ and to $S$. Each term $(X_i - \overline{X})(X_i - \overline{X})^\text{T}$ is positive semidefinite and we just add to reach $S$:

 $$ \overline{\mathbf{X}}=\frac{\overline{X}_{1}+\cdots+\overline{X}_{N}}{N}\quad\boldsymbol{S}=\frac{(\overline{X}_{1}-\overline{X})(\overline{X}_{1}-\overline{X})^{\mathrm{T}}+\cdots+(\overline{X}_{N}-\overline{X})(\overline{X}_{N}-\overline{X})^{\mathrm{T}}}{N-1}(3) $$ 