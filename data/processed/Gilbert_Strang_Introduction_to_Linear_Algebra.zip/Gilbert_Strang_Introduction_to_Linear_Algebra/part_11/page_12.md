## WORKED EXAMPLES

12.2 A Suppose x and y are independent random variables with mean 0 and variance 1. Then the covariance matrix  $ V_X $ for  $ X = (x, y) $ is the 2 by 2 identity matrix. What are the mean  $ m_Z $ and the covariance matrix  $ V_Z $ for the 3-component vector  $ Z = (x, y, ax + by) $?

Solution

Z is connected to X by A

 $$ \begin{aligned}\mathbf{Z}&=\left[\begin{array}{c}{{{x}}} \\{{{y}}} \\{{{ax+by}}}\end{array}\right]=\left[\begin{array}{cc}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}} \\{{{a}}}&{{{b}}}\end{array}\right]\left[\begin{array}{c}{{{x}}} \\{{{y}}}\end{array}\right]=A\mathbf{X}.\end{aligned} $$ 

The vector  $ m_X $ contains the means of the  $ M $ components of  $ X $. The vector  $ m_Z $ contains the means of the  $ K $ components of  $ Z = A X $. The matrix connection between the means of  $ X $ and  $ Z $ has to be linear:  $ m_Z = A m_X $. The mean of  $ ax + by $ is  $ am_x + b m_y $.

The covariance matrix for  $ Z $ is  $ V_Z = AA^\top $, when  $ V_X $ is the 2 by 2 identity matrix:

 $$ V_{Z}=\begin{array}{c}{{{\mathrm{covariance matrix for}}}} \\{{{Z=(x,y,a x+b y)}}}\end{array}=\left[\begin{array}{c c}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}} \\{{{a}}}&{{{b}}}\end{array}\right]\left[\begin{array}{l l l}{{{1}}}&{{{0}}}&{{{a}}} \\{{{0}}}&{{{1}}}&{{{b}}}\end{array}\right]=\left[\begin{array}{c c c}{{{1}}}&{{{0}}}&{{{a}}} \\{{{0}}}&{{{1}}}&{{{b}}} \\{{{a}}}&{{{b}}}&{{{a^{2}+b^{2}}}}\end{array}\right]. $$ 

Interpretation: x and y are independent so  $ \sigma_{xy} = 0 $. Then the covariance of x with  $ ax + by $ is a and the covariance of y with  $ ax + by $ is b. Those just come from the two independent parts of  $ ax + by $. Finally, equation (18) gives the variance of  $ ax + by $:

 $$ \begin{array}{r l}{\mathbf{U s e}\;V_{Z}=A V_{X}A^{\mathrm{T}}}&{{}\quad\sigma_{a x+b y}^{2}=\sigma_{a x}^{2}+\sigma_{b y}^{2}+2\sigma_{a x,b y}=a^{2}+b^{2}+0.}\end{array} $$ 

The 3 by 3 matrix  $ V_Z $ is singular. Its determinant is  $ a^2 + b^2 - a^2 - b^2 = 0 $. The third component  $ z = ax + by $ is completely dependent on  $ x $ and  $ y $. The rank of  $ V_Z $ is only 2.

GPS Example The signal from a GPS satellite includes its departure time. The receiver clock gives the arrival time. The receiver multiplies the travel time by the speed of light. Then it knows the distance from that satellite. Distances from four or more satellites pinpoint the receiver position (using least squares!).

One problem: The speed of light changes in the ionosphere. But the correction will be almost the same for all nearby receivers. If one receiver stays in a known position, we can take differences from that position. Differential GPS reduces the error variance:

 $$ \begin{aligned}\begin{array}{l l l l}\text{Difference matrix}&\text{Covariance matrix}&&\\A=\left[\begin{array}{l l}1&-1\end{array}\right]&V_{Z}=A V_{X}A^{\mathrm{T}}&V_{Z}&=\left[\begin{array}{l l}1&-1\end{array}\right]\left[\begin{array}{c c}\sigma_{1}^{2}&\sigma_{12}\\ \sigma_{12}&\sigma_{2}^{2}\end{array}\right]\left[\begin{array}{c}1\\ -1\end{array}\right]\\&&=\sigma_{1}^{2}-2\sigma_{12}+\sigma_{2}^{2}\end{array}\end{aligned} $$ 

Errors in the speed of light are gone. Then centimeter positioning accuracy is achievable. (The key ideas are on page 320 of Algorithms for Global Positioning by Borre and Strang.) The GPS world is all about time and space and amazing accuracy.