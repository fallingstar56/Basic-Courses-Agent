Real eigenvalues, 339, 440

Recursive, 214, 218, 231, 449, 560

Reduced row echelon form, 86, 137, 138

Reflection matrix, 235, 241, 291, 499, 514

Repeated eigenvalue, 311, 327, 333

Rescaling, 496, 552

Residual, 224, 524

Reverse order, 84, 85, 110

Right hand rule, 278, 280

Right inverse, 83, 397, 448

Right triangle, 13, 14, 194, 220

Roots of 1, 435, 442, 445

Rotation, 15, 392, 394, 496

Rotation matrix, 294, 414

Roundoff error, 510, 520

Row at a time, 22, 23, 38

Row exchange, 49, 58, 63, 115, 247, 256

Row picture, 31, 32, 34

Row rank, 150

Row space, 168, 182, 443

Rules for vector spaces, 131

Rules for determinant, 249, 254

Runge-Kutta, 337

## S

Saddle point, 117, 358, 361

Same eigenvalues, 308, 318

Same length, 235

Sample covariance matrix, 382, 547

Sample mean, 535, 547, 550

Sample value, 535, 544

Sample variance, 382, 536

Scalar, 2, 32, 124

Schur, 343, 363

Schur complement, 75, 96, 270, 357

Schwarz inequality, 11, 16, 20, 393, 490

Scree plot, 389

Second derivative matrix, 356, 361

Second difference, 344, 357, 464

Second eigenvalue, 477

Second order equation, 322, 333

Semidefinite matrix, 354

Sensitivity, 478, 482

Sherman-Woodbury-Morrison, 562

Shift by  $ u_{0} $, 402

Short wide matrix, 139, 171

Shortage of eigenvectors, 329

Shortest solution, 225, 397, 400

Sigma notation, 59

Signal processing, 435, 445, 450

Similar matrix, 307, 318, 416, 421, 429

Simplex method, 486

Simulation, 472

Sine matrix, 344

Singular matrix, 27, 88, 225, 251

Singular value, 367, 368, 371, 520 (see SVD)

Singular value matrix, 416

Singular vector, 367, 371, 416

Skew-symmetric matrix, 119, 295, 334, 437

Slope, 19, 31

Snapshot, 387

SNP, 384, 385

Solvable, 127, 130

SOR, 527, 532

Span, 128, 134, 164, 167, 200

Spanning tree, 314

Sparse matrix, 101, 508, 513, 559

Spatial statistics, 385

Special solution, 135, 137, 140, 149, 158

Spectral radius, 522, 525, 534

Spectral Theorem, 339, 340, 343

Spiral, 323

Splitting, 200, 222, 260, 524, 531

Spread, 536

Spreadsheet, 12, 375

Square root matrix, 353

Square wave, 492, 494

Squashed, 410

Stoichiometric matrix, 461

Stability, 307, 319, 325, 326, 375

Standard basis, 169, 415, 421

Standard deviation, 536

Standard normal (Gaussian), 545, 555

Standardize, 541, 542, 552

State equations, 559

Statistics, 38, 230, 384

Steady model, 561

Steady state, 290, 332, 474, 476

Stiffness matrix, 324, 462, 469