## Index of Symbols and Computer Codes

A = LDU, 99

 $$ A=LU,99,114,378 $$ 

 $$ (AB)^{-1}=B^{-1}A^{-1},84 $$ 

 $$ A=QR,239,240,378 $$ 

chebfun, 428

 $$ A=Q S and KQ,394 $$ 

Fortran, 39

Julia, 16, 38, 39

 $$ A=U\Sigma V^{\mathrm{T}},372,378 $$ 

 $$ A=u v^{\mathrm{T}},140 $$ 

LAPACK, 100, 378, 509,

 $ (AB)C = A(BC), 70 $

 $ [A\ b] $ and  $ [A\ I], 149 $

 $ \det(A - \lambda I) = 0, 292, 293 $

 $ C(A) $ and  $ C(A^{\mathrm{T}}), 128 $

 $ N(A) $ and  $ N(A^{\mathrm{T}}), 135 $

 $ C^{n}, 430, 444 $

 $ R^{n}, 123, 430 $

 $ S \cup T, 134 $

 $ S + T, 134, 179 $

 $ S \cap T, 133, 179 $

 $ V^{\perp}, 197, 204 $

 $ Z, 123, 125, 137, 173 $

 $ l^{1} $ and  $ l^{\infty}, 523 $

 $ i, j, k, 13, 169, 280 $

 $ u \times v, 279 $

 $ x^{+} = A^{+} b, 397 $

 $ N(0,1), 555 $

mod p, 502, 503

 $ NaN, 225 $

-1, 2, -1 matrix, 259, 368, 523

3 by 3 determinant, 271

Computer Packages

ARPACK, 531

BLAS, 509

 $$ A=BCB^{-1},308 $$ 

515,529

 $$ A=BJB^{-1},422,423 $$ 

Maple, 38

 $$ A=QR,239,513,530,532 $$ 

Mathematica, 38

 $$ A=QTQ^{-1},343 $$ 

MATLAB, 16, 38, 43, 88,

115, 240, 303

 $$ A=X\Lambda X^{-1},304,310 $$ 

MINRES, 528

 $$ A^{k}=X\Lambda^{k}X^{-1},307,310 $$ 

Python, 16, 38, 39

 $$ A^{+}=V\Sigma^{+}U^{\mathrm{T}},395 $$ 

R, 38, 39

 $$ A^{\mathrm{T}}A,112,203,212,372 $$ 

 $$ A^{\mathrm{T}}A\widehat{\boldsymbol{x}}=A^{\mathrm{T}}\boldsymbol{b},219 $$ 

 $$ A^{\mathrm{T}}CA,362,459,467 $$ 

Code Names

 $$ \boldsymbol{P}=\boldsymbol{A}(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A})^{-1}\boldsymbol{A}^{\mathrm{T}},211 $$ 

amd, 513

 $$ PA=LU,114 $$ 

chol, 353

 $$ Q^{\mathrm{T}}Q=I,234 $$ 

eig, 293

eigshow, 303, 380

 $$ S=A^{\mathrm{T}}A,352,372 $$ 

 $$ S=LDL^{\mathrm{T}},342 $$ 

lu, 103

norm, 17, 392, 518

pascal, 95

plot2d, 406, 410

 $$ e^{At}=Xe^{\Lambda t}X^{-1},327 $$ 

 $$ (A-\lambda I)x=0,292 $$ 

qr, 241, 246

rand, 370

 $$ (A\boldsymbol{x})^{\mathrm{T}}\boldsymbol{y}=\boldsymbol{x}^{\mathrm{T}}\left(A^{\mathrm{T}}\boldsymbol{y}\right),111 $$ 

 $$ (AB)^{\mathrm{T}}=B^{\mathrm{T}}A^{\mathrm{T}},110 $$ 

rref, 88, 137

svd, 378

toeplitz, 108

Linear Algebra Websites and Email Address

math.mit.edu/linearalgebra Dedicated to readers and teachers working with this book

ocw.mit.edu MIT's OpenCourseWare site including video lectures in 18.06 and 18.085-6

web.mit.edu/18.06 Current and past exams and homeworks with extra materials

wellesleycambridge.com Ordering information for books by Gilbert Strang

linearalgebrabook@gmail.com Direct email contact about this book