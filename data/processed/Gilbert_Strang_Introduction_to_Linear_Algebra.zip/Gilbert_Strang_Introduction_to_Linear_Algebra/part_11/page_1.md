With N flips, Example 3 (or common sense) gives a mean of  $ m = \Sigma x_i p_i = \frac{1}{2} N $ heads.

The variance  $ \sigma^2 $ is based on the squared distance from this mean  $ N/2 $. With  $ N = 3 $ the variance is  $ \sigma^2 = \frac{3}{4} $ (which is  $ N/4 $). To find  $ \sigma^2 $ we add  $ (x_i - m)^2 p_i $ with  $ m = 1.5 $:

 $$ \sigma^{2}=\left(3-1.5\right)^{2}\frac{1}{8}+\left(2-1.5\right)^{2}\frac{3}{8}+\left(1-1.5\right)^{2}\frac{3}{8}+\left(0-1.5\right)^{2}\frac{1}{8}=\frac{9+3+3+9}{32}=\frac{3}{4}. $$ 

For any N, the variance is  $ \sigma_{N}^{2}=N/4 $. Then  $ \sigma_{N}=\sqrt{N}/2 $.

Figure 12.3 shows how the probabilities of 0, 1, 2, 3, 4 heads in N = 4 flips come close to a bell-shaped Gaussian. That Gaussian is centered at the mean value  $ N/2 = 2 $. To reach the standard Gaussian (mean 0 and variance 1) we shift and rescale that graph. If x is the number of heads in N flips—the average of N zero-one outcomes—then x is shifted by its mean m = N/2 and rescaled by  $ \sigma = \sqrt{N}/2 $ to produce the standard X:

Shifted and scaled

 $$ X=\frac{x-m}{\sigma}=\frac{x-\frac{1}{2}N}{\sqrt{N}/2}\qquad(N=4has X=x-2) $$ 

Subtracting m is “centering” or “detrending”. The mean of X is zero.

Dividing by  $ \sigma $ is “normalizing” or “standardizing”. The variance of X is 1.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_185_644_884_848.jpg" alt="Image" width="65%" /></div>


<div style="text-align: center;">Figure 12.3: The probabilities  $ p = (1, 4, 6, 4, 1)/16 $ for the number of heads in 4 flips. These  $ p_i $ approach a Gaussian distribution with variance  $ \sigma^2 = N/4 $ centered at  $ m = N/2 $. For  $ X $, the Central Limit Theorem gives convergence to the normal distribution  $ \mathbf{N}(0,1) $.</div>


It is fun to see the Central Limit Theorem giving the right answer at the center point $X = 0$. At that point, the factor $e^{-X^{2}/2}$ equals 1. We know that the variance for $N$ coin flips is $\sigma^{2} = N/4$. The center of the bell-shaped curve has height $1/\sqrt{2\pi\sigma^{2}} = \sqrt{2/N\pi}$.

What is the height at the center of the coin-flip distribution  $ p_0 $ to  $ p_N $ (the binomial distribution)? For  $ N = 4 $, the probabilities for 0, 1, 2, 3, 4 heads come from  $ \left(\frac{1}{2} + \frac{1}{2}\right)^4 $.

Center probability

 $$ \frac{6}{16}\qquad\left(\frac{1}{2}+\frac{1}{2}\right)^{4}=\frac{1}{16}+\frac{4}{16}+\frac{6}{16}+\frac{4}{16}+\frac{1}{16}=1. $$ 