## Index

## A

Absolute value, 430, 433, 436

Add angles, 434

Add vectors, 2, 3

Adjacency matrix, 76

Adjoint, 439

Affine, 402, 410, 497, 498

All combinations, 5, 130

Angle, 11, 14, 15

Antisymmetric matrix, 122, 328, 349

Applied mathematics, 455, 468

Area, 276, 277, 284

Arnoldi iteration, 531, 533

Arrow, 3, 4

Associative law, 61, 73, 82

Augmented matrix, 58, 63, 86, 134, 150

Average value, 231, 493

Axes of ellipse, 355, 392

## B

Back substitution, 34, 46, 50

Backslash, 102

Backward difference, 325

Balance equation, 189, 455, 468

Band matrix, 52, 101, 102, 512

Basis, 164, 168, 170, 200, 403

Bayes Theorem, 554

Bell-shaped curve, 539, 555

Bidagonal matrix, 377, 512

Big formula, 248, 258, 260, 261, 266

Big Picture, 149, 184, 197, 199, 222

Binomial, 541, 542, 545

Bit-reversed order, 450, 451

Bits per second, 365

Black-Scholes, 473

Block determinants, 270

Block elimination, 75, 117

Block factorization, 117

Block matrix, 74, 96, 400, 509

Block multiplication, 74, 81

BLUE theorem, 559

BlueGene, 509

Boundary conditions, 462

Bowl, 361

Box, 278, 285

Breakdown, 47, 51

Butterflies in FFT, 449



## C

Calculus, 24, 25, 122, 221, 257, 270, 286, 404, 405

Cauchy-Binet, 287

Cayley-Hamilton Theorem, 317

Center the data, 382, 391

Centered difference, 25, 28

Central Limit Theorem, 539, 541, 542

Change of basis matrix, 174, 412, 419

Change signs, 249

Characteristic polynomial, 292

Chebyshev basis, 427, 428

Chemical engineering, 473

Chemistry, 461

Chess matrix, 193

Cholesky, 353, 360

Circulant matrix, 363, 425

Civil engineering, 462

Clock, 9

Closest line, 219, 223, 229, 383

Code, 240, 245, 504

Coefficient matrix, 33, 36