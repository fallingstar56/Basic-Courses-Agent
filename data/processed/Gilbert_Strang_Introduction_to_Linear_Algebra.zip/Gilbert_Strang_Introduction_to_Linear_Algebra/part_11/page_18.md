Most weight is on $b_1$ since its variance $\sigma_1$ is smallest. The variance of $\widehat{x}$ has the beautiful formula $W = (A^\mathrm{T}V^{-1}A)^{-1} = 1/14$:

Variance of  $ \hat{x} $

 $$ \left(\begin{array}{c c c c}{\left[\begin{array}{l l l}{1}&{1}&{1}\end{array}\right]}&{\left[\begin{array}{c c c c}{9}&{}&{}&{}\\ {}&{4}&{}&{}\\ {}&{}&{1}\end{array}\right]}&{\left[\begin{array}{l}{1}\\ {1}\\ {1}\end{array}\right]}\end{array}\right)^{-1}=\frac{1}{14}\quad i s s m a l l e r t h a n $$ 

The BLUE theorem of Gauss (proved on the website) says that our  $ \hat{x} = Lb $ is the best linear unbiased estimate of the solution to  $ Ax = b $. Any other unbiased choice  $ x^* = L^*b $ has greater variance than  $ \hat{x} $. All unbiased choices have  $ L^*A = I $ so that an exact  $ Ax = b $ will produce the right answer  $ x = L^*b = L^*Ax $.

Note. I must add that there are reasons not to minimize squared errors in the first place. One reason: This  $ \hat{x} $ often has many small components. The squares of small numbers are very small, and they appear when we minimize. It is easier to make sense of sparse vectors—only a few nonzeros. Statisticians often prefer to minimize unsquared errors: the sum of  $ |(\mathbf{b} - \mathbf{A}\mathbf{x})_i| $. This error measure is  $ L^1 $ instead of  $ L^2 $. Because of the absolute values, the equation for  $ \hat{x} $ becomes nonlinear (it is actually piecewise linear).

Fast new algorithms are computing a sparse  $ \hat{x} $ quickly and the future may belong to  $ L^{1} $

## The Kalman Filter

The “Kalman filter” is the great algorithm in dynamic least squares. That word dynamic means that new measurements  $ b_k $ keep coming. So the best estimate  $ \widehat{x}_k $ keeps changing (based on all of  $ b_0, \ldots, b_k $). More than that, the matrix  $ A $ is also changing. So  $ \widehat{x}_2 $ will be our best least squares estimate of the latest solution  $ x_k $ to the whole history of observation equations and update equations (state equations) up to time 2:

 $$ A_{0}\boldsymbol{x}_{0}=\boldsymbol{b}_{0}\qquad\boldsymbol{x}_{1}=F_{0}\boldsymbol{x}_{0}\qquad A_{1}\boldsymbol{x}_{1}=\boldsymbol{b}_{1}\qquad\boldsymbol{x}_{2}=F_{1}\boldsymbol{x}_{1}\qquad A_{2}\boldsymbol{x}_{2}=\boldsymbol{b}_{2} $$ 

The Kalman idea is to introduce one equation at a time. There will be errors in each equation. With every new equation, we update the best estimate  $ \widehat{x}_k $ for the current  $ x_k $. But history is not forgotten! This new estimate  $ \widehat{x}_k $ uses all the past observations  $ b_0 $ to  $ b_{k-1} $ and all the state equations  $ x_{\text{new}} = F_{\text{old}} x_{\text{old}} $. A large and growing least squares problem.

One more important point. Each least squares equation is weighted using the covariance matrix  $ V_k $ for the error in  $ b_k $. There is even a covariance matrix  $ C_k $ for errors in the update equations  $ x_{k+1} = F_k x_k $. The best  $ \hat{x}_2 $ then depends on  $ b_0, b_1, b_2 $ and  $ V_0, V_1, V_2 $ and  $ C_1, C_2 $. The good way to write  $ \hat{x}_k $ is as an update to the previous  $ \hat{x}_{k-1} $.

Let me concentrate on a simplified problem, without the matrices  $ F_k $ and the covariances  $ C_k $. We are estimating the same true  $ x $ at every step. How do we get  $ \hat{x}_1 $ from  $ \hat{x}_0 $?

OLD  $ A_0 x_0 = b_0 $ leads to the weighted equation  $ A_0^T V_0^{-1} A_0 \hat{x}_0 = A_0^T V_0^{-1} b_0 $.

NEW  $ \begin{bmatrix} A_0 \\ A_1 \end{bmatrix} \widehat{x}_1 = \begin{bmatrix} b_0 \\ b_1 \end{bmatrix} $ leads to the following weighted equation for  $ \widehat{x}_1 $: