## Six Great Theorems of Linear Algebra

Dimension Theorem All bases for a vector space have the same number of vectors.

Counting Theorem Dimension of column space + dimension of nullspace = number of columns.

Rank Theorem Dimension of column space = dimension of row space. This is the rank.

Fundamental Theorem The row space and nullspace of $A$ are orthogonal complements in $\mathbf{R}^{n}$.

SVD There are orthonormal bases ($v$'s and $u$'s for the row and column spaces) so that $Av_{i} = \sigma_{i}u_{i}$.

Spectral Theorem If $A^{\mathrm{T}} = A$ there are orthonormal $q$'s so that $Aq_{i} = \lambda_{i}q_{i}$ and $A = Q\Lambda Q^{\mathrm{T}}$.

## LINEAR ALGEBRA IN A NUTSHELL ((The matrix A is n by n))

Nonsingular

A is invertible

The columns are independent

The rows are independent

The determinant is not zero

Ax = 0 has one solution x = 0

Ax = b has one solution x = A^{-1}b

A has n (nonzero) pivots

A has full rank r = n

The reduced row echelon form is R = I

The column space is all of R^{n}

The row space is all of R^{n}

All eigenvalues are nonzero

A^{T}A is symmetric positive definite

A has n (positive) singular values

Singular

A is not invertible

The columns are dependent

The rows are dependent

The determinant is zero

Ax = 0 has infinitely many solutions

Ax = b has no solution or infinitely many

A has r < n pivots

A has rank r < n

R has at least one zero row

The column space has dimension r < n

The row space has dimension r < n

Zero is an eigenvalue of A

A^{T}A is only semidefinite

A has r < n singular values

