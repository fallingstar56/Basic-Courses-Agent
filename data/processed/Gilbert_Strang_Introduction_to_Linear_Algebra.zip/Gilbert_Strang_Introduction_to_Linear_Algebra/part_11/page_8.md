That matrix Vij has rank 1. Equation (7) multiplies piij times column U times row UT:

 $$ \begin{bmatrix}(x_{i}-m_{1})^{2}&(x_{i}-m_{1})(y_{j}-m_{2})\\ (x_{i}-m_{1})(y_{j}-m_{2})&(y_{j}-m_{2})^{2}\end{bmatrix}=\begin{bmatrix}x_{i}-m_{1}\\ y_{j}-m_{2}\end{bmatrix}\begin{bmatrix}x_{i}-m_{1}&y_{j}-m_{2}\end{bmatrix} $$ 

Every matrix  $ UU^{\mathrm{T}} $ is positive semidefinite. So the whole matrix  $ V $ (combining these matrices  $ UU^{\mathrm{T}} $ with weights  $ p_{ij} \geq 0 $) is at least semidefinite—and probably  $ V $ is definite.

The covariance matrix V is positive definite unless the experiments are dependent.

Now we move from two variables x and y to M variables like age-height-weight. The output from each trial is a vector X with M components. (Each child has an age-height-weight vector with 3 components.) The covariance matrix V is now M by M. V is created from the output vectors X and their average  $ \overline{X} = \mathbf{E}[\mathbf{X}] $;

Covariance matrix

 $$ \boldsymbol{V}=\mathbf{E}\left[\left(\boldsymbol{X}-\overline{\boldsymbol{X}}\right)\left(\boldsymbol{X}-\overline{\boldsymbol{X}}\right)^{\mathrm{T}}\right] $$ 

Remember that XXT and  $ \overline{XX} $ = (column) (row) are M by M matrices.

For $M = 1$ (one variable) you see that $\overline{X}$ is the mean $m$ and $V$ is $\sigma^{2}$ (Section 12.1). For $M = 2$ (two coins) you see that $\overline{X}$ is $(m_{1}, m_{2})$ and $V$ matches equation (10). The expectation $E$ always adds up outputs times their probabilities. For age-height-weight the output could be $X = (5\text{ years}, 31\text{ inches}, 48\text{ pounds})$ and its probability is $p_{5,31,48}$.

Now comes a new idea. Take any linear combination  $ \boldsymbol{c}^{\mathrm{T}}\boldsymbol{X}=c_{1}X_{1}+\cdots+c_{M}X_{M} $. With  $ c=(6,2,5) $ this would be  $ \boldsymbol{c}^{\mathrm{T}}\boldsymbol{X}=6\left(\text{age}\right)+2\left(\text{height}\right)+5\left(\text{weight}\right) $. By linearity we know that its expected value  $ \mathrm{E}\left[\boldsymbol{c}^{\mathrm{T}}\boldsymbol{X}\right] $ is  $ \boldsymbol{c}^{\mathrm{T}}\mathrm{E}\left[\boldsymbol{X}\right]=\boldsymbol{c}^{\mathrm{T}}\overline{\boldsymbol{X}} $.

 $ \mathbf{E}\left[\boldsymbol{c}^{\mathrm{T}}\boldsymbol{X}\right]=\boldsymbol{c}^{\mathrm{T}}\mathbf{E}\left[\boldsymbol{X}\right]=6\left(\text{expected age}\right)+2\left(\text{expected height}\right)+5\left(\text{expected weight}\right). $

More than that, we also know the variance  $ \sigma^{2} $ of that number  $ c^{T}X $:

 $$ \begin{aligned}\operatorname{Variance of}\ \boldsymbol{c}^{\mathrm{T}}\boldsymbol{X}&=\mathrm{E}\left[\left(\boldsymbol{c}^{\mathrm{T}}\boldsymbol{X}-\boldsymbol{c}^{\mathrm{T}}\overline{\boldsymbol{X}}\right)\left(\boldsymbol{c}^{\mathrm{T}}\boldsymbol{X}-\boldsymbol{c}^{\mathrm{T}}\overline{\boldsymbol{X}}\right)^{\mathrm{T}}\right]\\&=\boldsymbol{c}^{\mathrm{T}}\mathrm{E}\left[\left(\boldsymbol{X}-\overline{\boldsymbol{X}}\right)\left(\boldsymbol{X}-\overline{\boldsymbol{X}}\right)^{\mathrm{T}}\right]\boldsymbol{c}=\boldsymbol{c}^{\mathrm{T}}\boldsymbol{V}\boldsymbol{c}！\end{aligned} $$ 

Now the key point: The variance of  $ c^{\mathrm{T}}X $ can never be negative. So  $ c^{\mathrm{T}}Vc \geq 0 $. The covariance matrix  $ V $ is therefore positive semidefinite by the energy test  $ c^{\mathrm{T}}Vc \geq 0 $. Covariance matrices  $ V $ open up the link between probability and linear algebra:  $ V $ equals  $ Q\Lambda Q^{\mathrm{T}} $ with eigenvalues  $ \lambda_i \geq 0 $ and orthonormal eigenvectors  $ q_1 $ to  $ q_M $.

Diagonalizing the covariance matrix means finding M independent experiments as combinations of the original M experiments.