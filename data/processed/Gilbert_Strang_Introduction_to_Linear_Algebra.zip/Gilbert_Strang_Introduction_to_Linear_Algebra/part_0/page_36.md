All three vectors  $ \boldsymbol{u}, \boldsymbol{v}, \boldsymbol{w}^{*} $ have components adding to zero. Then all their combinations will have  $ b_1 + b_2 + b_3 = 0 $ (as we saw above, by adding the three equations). This is the equation for the plane containing all combinations of  $ \boldsymbol{u} $ and  $ \boldsymbol{v} $. By including  $ \boldsymbol{w}^{*} $ we get no new vectors because  $ \boldsymbol{w}^{*} $ is already on that plane.

The original  $ w = (0, 0, 1) $ is not on the plane:  $ 0 + 0 + 1 \neq 0 $. The combinations of  $ u, v, w $ fill the whole three-dimensional space. We know this already, because the solution  $ x = A^{-1}b $ in equation (6) gave the right combination to produce any  $ b $.

The two matrices A and C, with third columns w and  $ w^{*} $, allowed me to mention two key words of linear algebra: independence and dependence. The first half of the course will develop these ideas much further—I am happy if you see them early in the two examples:

u, v, w are independent. No combination except 0u + 0v + 0w = 0 gives b = 0.

u, v, w* are dependent. Other combinations like u + v + w* give b = 0.

You can picture this in three dimensions. The three vectors lie in a plane or they don't. Chapter 2 has n vectors in n-dimensional space. Independence or dependence is the key point. The vectors go into the columns of an n by n matrix:

Independent columns: Ax = 0 has one solution. A is an invertible matrix.

Dependent columns:  $ Cx = 0 $ has many solutions.  $ C $ is a singular matrix.

Eventually we will have n vectors in m-dimensional space. The matrix A with those n columns is now rectangular (m by n). Understanding Ax = b is the problem of Chapter 3.

## ■ REVIEW OF THE KEY IDEAS

1. Matrix times vector:  $ Ax = \text{combination of the columns of } A $.

2. The solution to Ax = b is  $ x = A^{-1}b $, when A is an invertible matrix.

3. The cyclic matrix C has no inverse. Its three columns lie in the same plane. Those dependent columns add to the zero vector.  $ Cx = 0 $ has many solutions.

4. This section is looking ahead to key ideas, not fully explained yet.

## WORKED EXAMPLES

1.3 A Change the southwest entry  $ a_{31} $ of A (row 3, column 1) to  $ a_{31} = 1 $:

 $$ \boldsymbol{A}\boldsymbol{x}=\boldsymbol{b}\quad 鳥 \quad\left[\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{-1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{x_{1}}}} \\{{{-x_{1}+x_{2}}}} \\{{{x_{1}-x_{2}+x_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{array}\right]. $$ 

Find the solution x for any b. From  $ x = A^{-1}b $ read off the inverse matrix  $ A^{-1} $.