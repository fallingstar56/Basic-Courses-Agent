In three dimensions,  $ v + w $ is still found a component at a time. The sum has components  $ v_1 + w_1 $ and  $ v_2 + w_2 $ and  $ v_3 + w_3 $. You see how to add vectors in 4 or 5 or n dimensions. When w starts at the end of v, the third side is  $ v + w $. The other way around the parallelogram is  $ w + v $. Question: Do the four sides all lie in the same plane? Yes. And the sum  $ v + w - v - w $ goes completely around to produce the ___ vector.

A typical linear combination of three vectors in three dimensions is  $ u + 4v - 2w $:

Linear combination Multiply by 1, 4, -2 Then add

 $$ \begin{bmatrix}1\\ 0\\ 3\end{bmatrix}+4\begin{bmatrix}1\\ 2\\ 1\end{bmatrix}-2\begin{bmatrix}2\\ 3\\ -1\end{bmatrix}=\begin{bmatrix}1\\ 2\\ 9\end{bmatrix}. $$ 

## The Important Questions

For one vector u, the only linear combinations are the multiples  $ c_u $. For two vectors, the combinations are  $ c_u + dv $. For three vectors, the combinations are  $ c_u + dv + ew $. Will you take the big step from one combination to all combinations? Every c and d and e are allowed. Suppose the vectors  $ u $,  $ v $,  $ w $ are in three-dimensional space:

1. What is the picture of all combinations  $ cu_{i} $?

2. What is the picture of all combinations  $ cu + dv $?

3. What is the picture of all combinations  $ cu + dv + ew $?

The answers depend on the particular vectors u, v, and w. If they were zero vectors (a very extreme case), then every combination would be zero. If they are typical nonzero vectors (components chosen at random), here are the three answers. This is the key to our subject:

1. The combinations cu fill a line through  $ (0,0,0) $.

2. The combinations  $ cu + dv $ fill a plane through  $ (0, 0, 0) $.

3. The combinations  $ cu + dv + ew $ fill three-dimensional space.

The zero vector  $ (0, 0, 0) $ is on the line because c can be zero. It is on the plane because c and d could both be zero. The line of vectors  $ cu $ is infinitely long (forward and backward). It is the plane of all  $ cu + dv $ (combining two vectors in three-dimensional space) that I especially ask you to think about.

Adding all cu on one line to all dv on the other line fills in the plane in Figure 1.3.

When we include a third vector w, the multiples ew give a third line. Suppose that third line is not in the plane of u and v. Then combining all ew with all  $ cu + dv $ fills up the whole three-dimensional space.

This is the typical situation! Line, then plane, then space. But other possibilities exist. When w happens to be  $ cu + dv $, that third vector w is in the plane of the first two. The combinations of u, v, w will not go outside that uv plane. We do not get the full three-dimensional space. Please think about the special cases in Problem 1.