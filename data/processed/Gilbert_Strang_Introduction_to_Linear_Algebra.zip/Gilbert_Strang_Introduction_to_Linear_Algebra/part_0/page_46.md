Multiplication by columns

 $$ \begin{aligned}&Ax is a combination of column vectors:\\ &\begin{aligned}\\ &Ax=x(column1)+y(column2)+z(column3).\quad(7)\\ &\end{aligned}\\ \end{aligned} $$ 

When we substitute the solution  $ x = (0, 0, 2) $, the multiplication Ax produces b:

 $$ \left[\begin{array}{r r r}{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{5}}}&{{{2}}} \\{{{6}}}&{{{-3}}}&{{{1}}}\end{array}\right]\left[\begin{array}{r}{{{0}}} \\{{{0}}} \\{{{2}}}\end{array}\right]=2\text{times column}3=\left[\begin{array}{r}{{{6}}} \\{{{4}}} \\{{{2}}}\end{array}\right]. $$ 

The dot product from the first row is  $ (1,2,3)\cdot(0,0,2)=6 $. The other rows give dot products 4 and 2. This book sees Ax as a combination of the columns of A.

Example 1 Here are 3 by 3 matrices A and I = identity, with three 1's and six 0's:

 $$ \boldsymbol{A}\boldsymbol{x}=\left[\begin{array}{lll}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{array}\right]\left[\begin{array}{l}{{{4}}} \\{{{5}}} \\{{{6}}}\end{array}\right]=\left[\begin{array}{l}{{{4}}} \\{{{4}}} \\{{{4}}}\end{array}\right]\qquad\boldsymbol{I}\boldsymbol{x}=\left[\begin{array}{lll}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{4}}} \\{{{5}}} \\{{{6}}}\end{array}\right]=\left[\begin{array}{l}{{{4}}} \\{{{5}}} \\{{{6}}}\end{array}\right] $$ 

If you are a row person, the dot product of  $ (1,0,0) $ with  $ (4,5,6) $ is 4. If you are a column person, the linear combination Ax is 4 times the first column  $ (1,1,1) $. In that matrix A, the second and third columns are zero vectors.

The other matrix I is special. It has ones on the “main diagonal”. Whatever vector this matrix multiplies, that vector is not changed. This is like multiplication by 1, but for matrices and vectors. The exceptional matrix in this example is the 3 by 3 identity matrix :

 $$ \boldsymbol{I}=\left[\begin{array}{lll}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right] $$ 

always yields the multiplication  $ Ix = x $

Matrix Notation

The first row of a 2 by 2 matrix contains  $ a_{11} $ and  $ a_{12} $. The second row contains  $ a_{21} $ and  $ a_{22} $. The first index gives the row number, so that  $ a_{ij} $ is an entry in row i. The second index  $ j $ gives the column number. But those subscripts are not very convenient on a keyboard! Instead of  $ a_{ij} $ we type  $ A(i,j) $. The entry  $ a_{57} = A(5,7) $ would be in row 5, column 7.

 $$ \boldsymbol{A}=\left[\begin{array}{ll}a_{11}&a_{12}\\ a_{21}&a_{22}\end{array}\right]=\left[\begin{array}{ll}A(1,1)&A(1,2)\\ A(2,1)&A(2,2)\end{array}\right]. $$ 

For an m by n matrix, the row index i goes from 1 to m. The column index j stops at n. There are mn entries  $ a_{ij} = A(i,j) $. A square matrix of order n has  $ n^2 $ entries.