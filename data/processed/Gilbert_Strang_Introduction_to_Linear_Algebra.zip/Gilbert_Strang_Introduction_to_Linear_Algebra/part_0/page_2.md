## Table of Contents

1 Introduction to Vectors 1  
1.1 Vectors and Linear Combinations 2  
1.2 Lengths and Dot Products 11  
1.3 Matrices 22  
  
2 Solving Linear Equations 31  
2.1 Vectors and Linear Equations 31  
2.2 The Idea of Elimination 46  
2.3 Elimination Using Matrices 58  
2.4 Rules for Matrix Operations 70  
2.5 Inverse Matrices 83  
2.6 Elimination = Factorization:  $ A = LU $ 97  
2.7 Transposes and Permutations 109  
  
3 Vector Spaces and Subspaces 123  
3.1 Spaces of Vectors 123  
3.2 The Nullspace of  $ A $: Solving  $ Ax = 0 $ and  $ Rx = 0 $ 135  
3.3 The Complete Solution to  $ Ax = b $ 150  
3.4 Independence, Basis and Dimension 164  
3.5 Dimensions of the Four Subspaces 181  
  
4 Orthogonality 194  
4.1 Orthogonality of the Four Subspaces 194  
4.2 Projections 206  
4.3 Least Squares Approximations 219  
4.4 Orthonormal Bases and Gram-Schmidt 233  
  
5 Determinants 247  
5.1 The Properties of Determinants 247  
5.2 Permutations and Cofactors 258  
5.3 Cramers' Rule, Inverses, and Volumes 273