
<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td rowspan="3">Equations\n $ Ax = b $</td><td style='text-align: center; word-wrap: break-word;'>$ x_1 $</td><td style='text-align: center; word-wrap: break-word;'>$ = b_1 $</td><td rowspan="3">Solution\n $ x = A^{-1}b $</td><td style='text-align: center; word-wrap: break-word;'>$ x_1 = b_1 $</td><td rowspan="3">(6)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ -x_1 + x_2 $</td><td rowspan="2">$ = b_2 $</td><td style='text-align: center; word-wrap: break-word;'>$ x_2 = b_1 + b_2 $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ -x_2 + x_3 = b_3 $</td><td style='text-align: center; word-wrap: break-word;'>$ x_3 = b_1 + b_2 + b_3 $.</td></tr></table>

Let me admit right away—most linear systems are not so easy to solve. In this example, the first equation decided  $ x_1 = b_1 $. Then the second equation produced  $ x_2 = b_1 + b_2 $. The equations can be solved in order (top to bottom) because  $ A $ is a triangular matrix.

Look at two specific choices 0, 0, 0 and 1, 3, 5 of the right sides  $ b_{1}, b_{2}, b_{3} $:

 $$ \boldsymbol{b}=\begin{bmatrix}0\\ 0\\ 0\end{bmatrix}\text{gives}\boldsymbol{x}=\begin{bmatrix}0\\ 0\\ 0\end{bmatrix}\qquad\boldsymbol{b}=\begin{bmatrix}1\\ 3\\ 5\end{bmatrix}\text{gives}\boldsymbol{x}=\begin{bmatrix}1\\ 1+3\\ 1+3+5\end{bmatrix}=\begin{bmatrix}1\\ 4\\ 9\end{bmatrix}. $$ 

The first solution (all zeros) is more important than it looks. In words: If the output is  $ \boldsymbol{b} = \mathbf{0} $, then the input must be  $ \boldsymbol{x} = \mathbf{0} $. That statement is true for this matrix A. It is not true for all matrices. Our second example will show (for a different matrix C) how we can have  $ C\boldsymbol{x} = \mathbf{0} $ when  $ C \neq 0 $ and  $ \boldsymbol{x} \neq \mathbf{0} $.

This matrix A is “invertible”. From b we can recover x. We write x as A^{-1} b.

The Inverse Matrix

Let me repeat the solution x in equation (6). A sum matrix will appear!

 $$ \boldsymbol{A}\boldsymbol{x}=\boldsymbol{b}is solved by\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{1}+b_{2}}}} \\{{{b_{1}+b_{2}+b_{3}}}}\end{array}\right]=\left[\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{array}\right]. $$ 

If the differences of the $x$'s are the $b$'s, the sums of the $b$'s are the $x$'s. That was true for the odd numbers $b = (1, 3, 5)$ and the squares $x = (1, 4, 9)$. It is true for all vectors. The sum matrix in equation (7) is the inverse $A^{-1}$ of the difference matrix $A$.

Example: The differences of  $ x = (1, 2, 3) $ are  $ b = (1, 1, 1) $. So  $ b = Ax $ and  $ x = A^{-1}b $:

 $$ \boldsymbol{A}\boldsymbol{x}=\left[\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{c}{{{1}}} \\{{{2}}} \\{{{3}}}\end{array}\right]=\left[\begin{array}{c}{{{1}}} \\{{{1}}} \\{{{1}}}\end{array}\right]\qquad\boldsymbol{A}^{-1}\boldsymbol{b}=\left[\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{c}{{{1}}} \\{{{1}}} \\{{{1}}}\end{array}\right]=\left[\begin{array}{c}{{{1}}} \\{{{2}}} \\{{{3}}}\end{array}\right] $$ 

Equation (7) for the solution vector  $ \boldsymbol{x} = (x_{1}, x_{2}, x_{3}) $ tells us two important facts:

1. For every $b$ there is one solution to $Ax = b$. 2. The matrix $A^{-1}$ produces $x = A^{-1}b$.

The next chapters ask about other equations Ax = b. Is there a solution? How to find it?

Note on calculus. Let me connect these special matrices to calculus. The vector x changes to a function  $ x(t) $. The differences  $ Ax $ become the derivative  $ dx/dt = b(t) $. In the inverse direction, the sums  $ A^{-1}b $ become the integral of  $ b(t) $. Sums of differences are like integrals of derivatives.