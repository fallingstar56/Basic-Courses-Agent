<div style="text-align: center;"><img src="imgs/img_in_image_box_190_129_841_482.jpg" alt="Image" width="61%" /></div>


<div style="text-align: center;">Figure 2.2: Column picture: A combination of columns produces the right side (1, 11).</div>


To repeat: The left side of the vector equation is a linear combination of the columns. The problem is to find the right coefficients x = 3 and y = 1. We are combining scalar multiplication and vector addition into one step. That step is crucially important, because it contains both of the basic operations: Multiply by 3 and 1, then add.

Linear combination

 $$ \begin{align*}3\left[\begin{array}{c}1\\ 3\end{array}\right]+\left[\begin{array}{c}-2\\ 2\end{array}\right]=\left[\begin{array}{c}1\\ 11\end{array}\right].\end{align*} $$ 

Of course the solution  $ x = 3, y = 1 $ is the same as in the row picture. I don’t know which picture you prefer! I suspect that the two intersecting lines are more familiar at first. You may like the row picture better, but only for one day. My own preference is to combine column vectors. It is a lot easier to see a combination of four vectors in four-dimensional space, than to visualize how four hyperplanes might possibly meet at a point. (Even one hyperplane is hard enough...)

The coefficient matrix on the left side of the equations is the 2 by 2 matrix A:

Coefficient matrix

 $$ \boldsymbol{A}=\left[\begin{array}{cc}1&-2\\ 3&2\end{array}\right]. $$ 

This is very typical of linear algebra, to look at a matrix by rows and by columns. Its rows give the row picture and its columns give the column picture. Same numbers, different pictures, same equations. We combine those equations into a matrix problem Ax = b:

Matrix equation

Ax = b

 $$ \left[\begin{array}{c c}{{{1}}}&{{{-2}}} \\{{{3}}}&{{{2}}}\end{array}\right]\left[\begin{array}{l}{{{x}}} \\{{{y}}}\end{array}\right]=\left[\begin{array}{c}{{{1}}} \\{{{11}}}\end{array}\right]. $$ 