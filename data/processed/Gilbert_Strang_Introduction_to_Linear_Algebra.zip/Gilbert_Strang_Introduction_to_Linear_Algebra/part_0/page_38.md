### Problem Set 1.3

1 Find the linear combination  $ 3s_1 + 4s_2 + 5s_3 = b $. Then write  $ b $ as a matrix-vector multiplication  $ Sx $, with  $ 3, 4, 5 $ in  $ x $. Compute the three dot products (row of  $ S $) $ \cdot $  $ x $:

 $$ s_{1}=\begin{bmatrix}1\\ 1\\ 1\end{bmatrix}\quad s_{2}=\begin{bmatrix}0\\ 1\\ 1\end{bmatrix}\quad s_{3}=\begin{bmatrix}0\\ 0\\ 1\end{bmatrix}go into the columns of S. $$ 

2 Solve these equations  $ S_{y} = b $ with  $ s_{1}, s_{2}, s_{3} $ in the columns of S:

 $$ \begin{aligned}\left[\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\\end{array}\right]\left[\begin{array}{c}{{{y_{1}}}} \\{{{y_{2}}}} \\{{{y_{3}}}} \\\end{array}\right]&=\left[\begin{array}{c}{{{1}}} \\{{{1}}} \\{{{1}}} \\\end{array}\right]\text{and}\left[\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\\end{array}\right]\left[\begin{array}{c}{{{y_{1}}}} \\{{{y_{2}}}} \\{{{y_{3}}}} \\\end{array}\right]&=\left[\begin{array}{c}{{{1}}} \\{{{4}}} \\{{{9}}} \\\end{array}\right],\end{aligned} $$ 

S is a sum matrix. The sum of the first 5 odd numbers is ___.

3 Solve these three equations for y1, y2, y3 in terms of c1, c2, c3:

 $$ \begin{align*}S\boldsymbol{y}=\boldsymbol{c}\qquad\quad\left[\begin{array}{ccc}1&0&0\\1&1&0\\1&1&1\end{array}\right]\left[\begin{array}{c}y_1\\y_2\\y_3\end{array}\right]=\left[\begin{array}{c}c_1\\c_2\\c_3\end{array}\right].\end{align*} $$ 

Write the solution y as a matrix  $ A = S^{-1} $ times the vector c. Are the columns of S independent or dependent?

4 Find a combination  $ x_{1}w_{1} + x_{2}w_{2} + x_{3}w_{3} $ that gives the zero vector with  $ x_{1} = 1 $:

 $$ w_{1}=\left[\begin{array}{l}1\\ 2\\ 3\end{array}\right]\qquad w_{2}=\left[\begin{array}{l}4\\ 5\\ 6\end{array}\right]\qquad w_{3}=\left[\begin{array}{l}7\\ 8\\ 9\end{array}\right]. $$ 

Those vectors are (independent) (dependent). The three vectors lie in a ___.

The matrix W with those three columns is not invertible.

5 The rows of that matrix W produce three vectors (I write them as columns):

 $$ r_{1}=\left[\begin{array}{l}1\\ 4\\ 7\end{array}\right]\qquad r_{2}=\left[\begin{array}{l}2\\ 5\\ 8\end{array}\right]\qquad r_{3}=\left[\begin{array}{l}3\\ 6\\ 9\end{array}\right]. $$ 

Linear algebra says that these vectors must also lie in a plane. There must be many combinations with  $ y_1 \boldsymbol{r}_1 + y_2 \boldsymbol{r}_2 + y_3 \boldsymbol{r}_3 = \boldsymbol{0} $. Find two sets of  $ y' $s.

6 Which numbers c give dependent columns so a combination of columns equals zero?

 $$ \begin{bmatrix}{{{c}}}&{{{c}}}&{{{c}}} \\{{{2}}}&{{{1}}}&{{{5}}} \\{{{3}}}&{{{3}}}&{{{6}}}\end{bmatrix}\quad\begin{array}{l}maybe\\ always\\ independent for c\neq0?\end{array} $$ 