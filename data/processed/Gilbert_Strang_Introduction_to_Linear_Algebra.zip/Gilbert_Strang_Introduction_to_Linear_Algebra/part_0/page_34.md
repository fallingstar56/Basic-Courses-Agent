The Fundamental Theorem of Calculus says: integration is the inverse of differentiation.

 $$ Ax=b and x=A^{-1}b\qquad\frac{dx}{dt}=b and x(t)=\int_{0}^{t}b dt. $$ 

The differences of squares 0, 1, 4, 9 are odd numbers 1, 3, 5. The derivative of  $ x(t) = t^2 $ is 2t. A perfect analogy would have produced the even numbers  $ b = 2, 4, 6 $ at times  $ t = 1, 2, 3 $. But differences are not the same as derivatives, and our matrix  $ A $ produces not 2t but  $ 2t - 1 $:

Backward

 $$ x(t)-x(t-1)=t^{2}-(t-1)^{2}=t^{2}-(t^{2}-2t+1)=2t-1. $$ 

The Problem Set will follow up to show that “forward differences” produce  $ 2t + 1 $. The best choice (not always seen in calculus courses) is a centered difference that uses  $ x(t + 1) - x(t - 1) $. Divide that  $ \Delta x $ by the distance  $ \Delta t $ from  $ t - 1 $ to  $ t + 1 $, which is 2:

Centered difference of  $ x(t) = t^{2} $  $ \frac{(t+1)^{2}-(t-1)^{2}}{2} = 2t $ exactly. (10)

Difference matrices are great. Centered is the best. Our second example is not invertible.

Cyclic Differences

This example keeps the same columns u and v but changes w to a new vector w*:

Second example

 $$ \boldsymbol{u}=\left[\begin{array}{r}1\\ -1\\ 0\end{array}\right]\quad\boldsymbol{v}=\left[\begin{array}{r}0\\ 1\\ -1\end{array}\right]\quad\boldsymbol{w}^{*}=\left[\begin{array}{r}-1\\ 0\\ 1\end{array}\right]. $$ 

Now the linear combinations of u, v, w* lead to a cyclic difference matrix C:

Cyclic

 $$ \boldsymbol{C}\boldsymbol{x}=\left[\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{-1}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{x_{1}-x_{3}}}} \\{{{x_{2}-x_{1}}}} \\{{{x_{3}-x_{2}}}}\end{array}\right]=\boldsymbol{b}. $$ 

This matrix $C$ is not triangular. It is not so simple to solve for $x$ when we are given $b$. Actually it is impossible to find the solution to $Cx = b$, because the three equations either have infinitely many solutions (sometimes) or else no solution (usually):

 $$ \begin{array}{r l}{C x=0}&{{}\quad\left[\begin{array}{l}{x_{1}-x_{3}}\\ {x_{2}-x_{1}}\\ {x_{3}-x_{2}}\end{array}\right]=\left[\begin{array}{l}{0}\\ {0}\\ {0}\end{array}\right]\mathrm{~i s~s o l v e d~b y~a l l~v e c t o r s~}\left[\begin{array}{l}{x_{1}}\\ {x_{2}}\\ {x_{3}}\end{array}\right]=\left[\begin{array}{l}{c}\\ {c}\\ {c}\end{array}\right].}\end{array} $$ 

Every constant vector like  $ \boldsymbol{x} = (3, 3, 3) $ has zero differences when we go cyclically. The undetermined constant c is exactly like the  $ +C $ that we add to integrals. The cyclic differences cycle around to  $ x_1 - x_3 $ in the first component, instead of starting from  $ x_0 = 0 $.