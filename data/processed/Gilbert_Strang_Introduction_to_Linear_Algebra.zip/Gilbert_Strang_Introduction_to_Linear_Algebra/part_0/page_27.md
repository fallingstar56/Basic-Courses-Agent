1.2 B Find a unit vector u in the direction of  $ v = (3, 4) $. Find a unit vector U that is perpendicular to u. How many possibilities for U?

Solution For a unit vector  $ \boldsymbol{u} $, divide  $ \boldsymbol{v} $ by its length  $ \|\boldsymbol{v}\| = 5 $. For a perpendicular vector  $ \boldsymbol{V} $ we can choose  $ (-4, 3) $ since the dot product  $ \boldsymbol{v} \cdot \boldsymbol{V} $ is  $ (3)(-4) + (4)(3) = 0 $. For a unit vector perpendicular to  $ \boldsymbol{u} $, divide  $ \boldsymbol{V} $ by its length  $ \|\boldsymbol{V}\| $:

 $$ \boldsymbol{u}=\frac{\boldsymbol{v}}{\|\boldsymbol{v}\|}=\left(\frac{3}{5},\frac{4}{5}\right)\quad\boldsymbol{U}=\frac{\boldsymbol{V}}{\|\boldsymbol{V}\|}=\left(-\frac{4}{5},\frac{3}{5}\right)\quad\boldsymbol{u}\cdot\boldsymbol{U}=0 $$ 

The only other perpendicular unit vector would be  $ -\boldsymbol{U} = \left(\frac{4}{5}, -\frac{3}{5}\right) $.

1.2 C Find a vector  $ \boldsymbol{x} = (c, d) $ that has dot products  $ \boldsymbol{x} \cdot \boldsymbol{r} = 1 $ and  $ \boldsymbol{x} \cdot \boldsymbol{s} = 0 $ with two given vectors  $ \boldsymbol{r} = (2, -1) $ and  $ \boldsymbol{s} = (-1, 2) $.

Solution Those two dot products give linear equations for c and d. Then  $ \boldsymbol{x} = (c, d) $.

 $$ \begin{array}{r l r l r l}{x\cdot r=1}&{{}}&{\mathrm{i s}}&{{}}&{2c-\ d=1}&{{}}&{\mathrm{T h e~s a m e~e q u a t i o n s~a s}}\\ {x\cdot s=0}&{{}}&{\mathrm{i s}}&{{}}&{-c+2d=0}&{{}}&{\mathrm{i n~W o r k e d~E x a m p l e~1.1~C~}}\end{array} $$ 

Comment on n equations for  $ \boldsymbol{x} = (x_{1}, \ldots, x_{n}) $ in n-dimensional space

Section 1.1 would start with columns  $ v_j $. The goal is to produce  $ x_1 v_1 + \cdots + x_n v_n = b $. This section would start from rows  $ r_i $. Now the goal is to find  $ x $ with  $ x \cdot r_i = b_i $.

Soon the v's will be the columns of a matrix A, and the r's will be the rows of A. Then the (one and only) problem will be to solve Ax = b.

### Problem Set 1.2

1 Calculate the dot products  $ u \cdot v $ and  $ u \cdot w $ and  $ u \cdot (v + w) $ and  $ w \cdot v $:

 $$ \boldsymbol{u}=\begin{bmatrix}-.6\\ .8\end{bmatrix}\qquad\boldsymbol{v}=\begin{bmatrix}4\\ 3\end{bmatrix}\qquad\boldsymbol{w}=\begin{bmatrix}1\\ 2\end{bmatrix}. $$ 

2 Compute the lengths  $ \|u\| $ and  $ \|v\| $ and  $ \|w\| $ of those vectors. Check the Schwarz inequalities  $ |u \cdot v| \leq \|u\|\|v\| $ and  $ |v \cdot w| \leq \|v\|\|w\| $.

3 Find unit vectors in the directions of v and w in Problem 1, and the cosine of the angle  $ \theta $. Choose vectors a, b, c that make  $ 0^\circ $,  $ 90^\circ $, and  $ 180^\circ $ angles with w.

4 For any unit vectors v and w, find the dot products (actual numbers) of

(a) v and -v

 $$ \begin{array}{r l}{\mathrm{(b)}}&{{}v+w\mathrm{a n d}v-w}\end{array} $$ 

 $$ (\mathrm{c})\quad v-2w and v+2w $$ 

5 Find unit vectors  $ u_{1} $ and  $ u_{2} $ in the directions of  $ v = (1, 3) $ and  $ w = (2, 1, 2) $. Find unit vectors  $ U_{1} $ and  $ U_{2} $ that are perpendicular to  $ u_{1} $ and  $ u_{2} $.