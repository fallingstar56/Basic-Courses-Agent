What if  $ v $ and  $ w $ are not unit vectors? Divide by their lengths to get  $ \boldsymbol{u} = \boldsymbol{v}/\|v\| $ and  $ \boldsymbol{U} = \boldsymbol{w}/\|w\| $. Then the dot product of those unit vectors  $ \boldsymbol{u} $ and  $ \boldsymbol{U} $ gives  $ \cos\theta $.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>COSINE FORMULA</td><td style='text-align: center; word-wrap: break-word;'>If  $ v $ and  $ w $ are nonzero vectors then</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{v \cdot w}{\|v\| \|w\|} = \cos \theta. $</td><td style='text-align: center; word-wrap: break-word;'>(5)</td></tr></table>

Whatever the angle, this dot product of  $ v \cdot \|v\| $ with  $ w \cdot \|w\| $ never exceeds one. That is the “Schwarz inequality”  $ |v \cdot w| \leq \|v\|\|w\| $ for dot products—or more correctly the Cauchy-Schwarz-Buniakowsky inequality. It was found in France and Germany and Russia (and maybe elsewhere—it is the most important inequality in mathematics).

Since  $ |\cos\theta| $ never exceeds 1, the cosine formula gives two great inequalities:


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>SCHWARZ INEQUALITYTRIANGLE INEQUALITY</td><td style='text-align: center; word-wrap: break-word;'>$ |v \cdot w| \leq \|v\|\|w\|\|v + w\| \leq \|v\| + \|w\| $</td></tr></table>

Example 5 Find  $ \cos \theta $ for  $ v = \begin{bmatrix} 2 \\ 1 \end{bmatrix} $ and  $ w = \begin{bmatrix} 1 \\ 2 \end{bmatrix} $ and check both inequalities.

Solution The dot product is  $ v \cdot w = 4 $. Both  $ v $ and  $ w $ have length  $ \sqrt{5} $. The cosine is 4/5.

 $$ \cos\theta=\frac{v\cdot w}{\left\|v\right\|\left\|w\right\|}=\frac{4}{\sqrt{5}\sqrt{5}}=\frac{4}{5}. $$ 

By the Schwarz inequality,  $ v \cdot w = 4 $ is less than  $ \|v\|\|w\| = 5 $. By the triangle inequality, side  $ 3 = \|v + w\| $ is less than side  $ 1 + \text{side } 2 $. For  $ v + w = (3, 3) $ the three sides are  $ \sqrt{18} < \sqrt{5} + \sqrt{5} $. Square this triangle inequality to get  $ 18 < 20 $.

Example 6 The dot product of  $ v = (a, b) $ and  $ w = (b, a) $ is 2ab. Both lengths are  $ \sqrt{a^2 + b^2} $. The Schwarz inequality  $ v \cdot w \leq ||v|| ||w| $ says that  $ 2ab \leq a^2 + b^2 $.

This is more famous if we write  $ x = a^2 $ and  $ y = b^2 $. The “geometric mean”  $ \sqrt{xy} $ is not larger than the “arithmetic mean” = average  $ \frac{1}{2}(x + y) $.

 $$ \begin{array}{c c c c c}{\mathrm{G e o m e t r i c}}&{\leq}&{\mathrm{A r i t h m e t r i c}}&{a b\leq\frac{a^{2}+b^{2}}{2}}&{\mathrm{b e c o m e s}}&{\sqrt{x y}\leq\frac{x+y}{2}.}\\ {\mathrm{m e a n}}&{}&{\mathrm{m e a n}}&{}&{}&{}\\ \end{array} $$ 

Example 5 had a = 2 and b = 1. So x = 4 and y = 1. The geometric mean  $ \sqrt{xy} = 2 $ is below the arithmetic mean  $ \frac{1}{2}(1 + 4) = 2.5 $.

Notes on Computing

MATLAB, Python and Julia work directly with whole vectors, not their components. When v and w have been defined,  $ v + w $ is immediately understood. Input v and w as rows—the prime ' transposes them to columns.  $ 2v + 3w $ becomes  $ 2 * v + 3 * w $. The result will be printed unless the line ends in a semicolon.