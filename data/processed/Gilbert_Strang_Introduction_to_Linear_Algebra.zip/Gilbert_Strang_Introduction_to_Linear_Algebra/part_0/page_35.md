The more likely possibility for  $ Cx = b $ is no solution x at all:

 $$ \begin{align*}Cx=b\qquad\left[\begin{array}{c}x_1-x_3\\ x_2-x_1\\ x_3-x_2\end{array}\right]=\left[\begin{array}{c}1\\ 3\\ 5\end{array}\right]\end{align*} $$ 

Left sides add to 0

Right sides add to 9

No solution  $ x_{1}, x_{2}, x_{3} $

Look at this example geometrically. No combination of u, v, and  $ w^* $ will produce the vector  $ \boldsymbol{b} = (1, 3, 5) $. The combinations don't fill the whole three-dimensional space. The right sides must have  $ b_1 + b_2 + b_3 = 0 $ to allow a solution to  $ C\boldsymbol{x} = \boldsymbol{b} $, because the left sides  $ x_1 - x_3, x_2 - x_1 $, and  $ x_3 - x_2 $ always add to zero. Put that in different words:

All linear combinations  $ x_{1}u + x_{2}v + x_{3}w^{*} $ lie on the plane given by  $ b_{1} + b_{2} + b_{3} = 0 $.

This subject is suddenly connecting algebra with geometry. Linear combinations can fill all of space, or only a plane. We need a picture to show the crucial difference between u, v, w (the first example) and u, v, w* (all in the same plane).

<div style="text-align: center;"><img src="imgs/img_in_image_box_194_577_914_785.jpg" alt="Image" width="67%" /></div>


<div style="text-align: center;">Figure 1.10: Independent vectors u, v, w. Dependent vectors u, v, w in a plane.</div>


## Independence and Dependence

Figure 1.10 shows those column vectors, first of the matrix A and then of C. The first two columns u and v are the same in both pictures. If we only look at the combinations of those two vectors, we will get a two-dimensional plane. The key question is whether the third vector is in that plane:

Independence w is not in the plane of u and v.

Dependence  $ w^{*} $ is in the plane of u and v.

The important point is that the new vector  $ w^{*} $ is a linear combination of u and v:

 $$ \boldsymbol{u}+\boldsymbol{v}+\boldsymbol{w}^{*}=0\qquad\quad\boldsymbol{w}^{*}=\left[\begin{array}{r}-1\\0\\1\end{array}\right]=-\boldsymbol{u}-\boldsymbol{v}. $$ 