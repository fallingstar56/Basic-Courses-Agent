## The Variety of Linear Algebra

Calculus is mostly about one special operation (the derivative) and its inverse (the integral). Of course I admit that calculus could be important . . . . But so many applications of mathematics are discrete rather than continuous, digital rather than analog. The century of data has begun! You will find a light-hearted essay called “Too Much Calculus” on my website. The truth is that vectors and matrices have become the language to know.

Part of that language is the wonderful variety of matrices. Let me give three examples:

Symmetric matrix

 $$ \begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix} $$ 

Orthogonal matrix

 $$ \frac{1}{2}\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{-1}}}&{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}&{{{-1}}}&{{{-1}}} \\{{{1}}}&{{{-1}}}&{{{-1}}}&{{{1}}}\end{bmatrix} $$ 

Triangular matrix

 $$ \begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix} $$ 

A key goal is learning to “read” a matrix. You need to see the meaning in the numbers. This is really the essence of mathematics—patterns and their meaning.

I have used italics and boldface to pick out the key words on each page. I know there are times when you want to read quickly, looking for the important lines.

May 1 end with this thought for professors. You might feel that the direction is right, and wonder if your students are ready. Just give them a chance! Literally thousands of students have written to me, frequently with suggestions and surprisingly often with thanks. They know this course has a purpose, because the professor and the book are on their side. Linear algebra is a fantastic subject, enjoy it.

## Help With This Book

The greatest encouragement of all is the feeling that you are doing something worthwhile with your life. Hundreds of generous readers have sent ideas and examples and corrections (and favorite matrices) that appear in this book. Thank you all.

One person has helped with every word in this book. He is Ashley C. Fernandes, who prepared the LIFEX files. It is now six books that he has allowed me to write and rewrite, aiming for accuracy and also for life. Working with friends is a happy way to live.

Friends inside and outside the MIT math department have been wonderful. Alan Edelman for Julia and much more, Alex Townsend for the flag examples in 7.1, and Peter Kempthorne for the finance example in 7.3: those stand out. Don Spickler's website on cryptography is simply excellent. I thank Jon Bloom, Jack Dongarra, Hilary Finucane, Pavel Grinfeld, Randy LeVeque, David Vogan, Liang Wang, and Karen Willcox. The "eigenfaces" in 7.3 came from Matthew Turk and Jeff Jauregui. And the big step to singular values was accelerated by Raj Rao's great course at Michigan.

This book owes so much to my happy sabbatical in Oxford. Thank you, Nick Trefethen and everyone. Especially you the reader! Best wishes in your work.