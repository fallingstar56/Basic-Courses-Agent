### 1.1 Vectors and Linear Combinations

1 3v + 5w is a typical linear combination cv + dw of the vectors v and w.

2 For  $ v = \begin{bmatrix} 1 \\ 1 \end{bmatrix} $ and  $ w = \begin{bmatrix} 2 \\ 3 \end{bmatrix} $ that combination is  $ 3\begin{bmatrix} 1 \\ 1 \end{bmatrix} + 5\begin{bmatrix} 2 \\ 3 \end{bmatrix} = \begin{bmatrix} 3 + 10 \\ 3 + 15 \end{bmatrix} = \begin{bmatrix} 13 \\ 18 \end{bmatrix} $.

3 The vector  $ \left[\begin{array}{c}2\\ 3\end{array}\right]=\left[\begin{array}{c}2\\ 0\end{array}\right]+\left[\begin{array}{c}0\\ 3\end{array}\right] $ goes across to x = 2 and up to y = 3 in the xy plane.

4 The combinations $c\left[\begin{array}{c}1\\ 1\end{array}\right]+d\left[\begin{array}{c}2\\ 3\end{array}\right]$ fill the whole xy plane. They produce every $\left[\begin{array}{c}x\\ y\end{array}\right].$

5 The combinations $c\left[\begin{array}{c}1\\ 1\\ 1\end{array}\right]+d\left[\begin{array}{c}2\\ 3\\ 4\end{array}\right]$ fill a plane in xyz space. Same plane for $\left[\begin{array}{c}1\\ 1\\ 1\end{array}\right],\left[\begin{array}{c}3\\ 4\\ 5\end{array}\right].$

6 But $c+3d=0$ has no solution because its right side $\left[\begin{array}{c}1\\ 0\\ 0\end{array}\right]$ is not on that plane.

$c+4d=0$

“You can’t add apples and oranges.” In a strange way, this is the reason for vectors. We have two separate numbers  $ v_{1} $ and  $ v_{2} $. That pair produces a two-dimensional vector v:

Column vector v

 $$ \boldsymbol{v}=\left[\begin{array}{l}v_{1}\\ v_{2}\end{array}\right]\quad\begin{array}{l}v_{1}=first component of\boldsymbol{v}\\ v_{2}=second component of\boldsymbol{v}\end{array} $$ 

We write v as a column, not as a row. The main point so far is to have a single letter v (in boldface italic) for this pair of numbers  $ v_{1} $ and  $ v_{2} $ (in lightface italic).

Even if we don't add  $ v_{1} $ to  $ v_{2} $, we do add vectors. The first components of v and w stay separate from the second components:

VECTOR ADDITION

 $$ \boldsymbol{v}=\left[\begin{array}{l}v_{1}\\ v_{2}\end{array}\right]\quad and\quad\boldsymbol{w}=\left[\begin{array}{l}w_{1}\\ w_{2}\end{array}\right]\quad add to\quad\boldsymbol{v}+\boldsymbol{w}=\left[\begin{array}{l}v_{1}+w_{1}\\ v_{2}+w_{2}\end{array}\right]. $$ 

Subtraction follows the same idea: The components of v − w are v1 − w1 and v2 − w2.

The other basic operation is scalar multiplication. Vectors can be multiplied by 2 or by -1 or by any number c. To find 2v, multiply each component of v by 2:

SCALAR

SCALAR

MULTIPLICATION

 $$ 2\boldsymbol{v}=\left[\begin{array}{l}2v_{1}\\ 2v_{2}\end{array}\right]=\boldsymbol{v}+\boldsymbol{v}\quad-\boldsymbol{v}=\left[\begin{array}{l}-v_{1}\\ -v_{2}\end{array}\right]. $$ 

The components of cv are cv1 and cv2. The number c is called a “scalar”.

Notice that the sum of  $ -v $ and  $ v $ is the zero vector. This is 0, which is not the same as the number zero! The vector 0 has components 0 and 0. Forgive me for hammering away at the difference between a vector and its components. Linear algebra is built on these operations  $ v + w $ and  $ cv $ and  $ dw $—adding vectors and multiplying by scalars.