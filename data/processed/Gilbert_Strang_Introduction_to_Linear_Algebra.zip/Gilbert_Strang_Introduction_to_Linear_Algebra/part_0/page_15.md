Line containing all cu

<div style="text-align: center;"><img src="imgs/img_in_image_box_297_217_471_304.jpg" alt="Image" width="16%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_563_117_712_315.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;">(a)</div>


Plane from all  $ cu + dv $

<div style="text-align: center;">(b)</div>


<div style="text-align: center;">Figure 1.3: (a) Line through u. (b) The plane containing the lines through u and v.</div>


■ REVIEW OF THE KEY IDEAS ■

1. A vector v in two-dimensional space has two components  $ v_{1} $ and  $ v_{2} $.

2.  $ v + w = (v_{1} + w_{1}, v_{2} + w_{2}) $ and  $ cv = (cv_{1}, cv_{2}) $ are found a component at a time.

3. A linear combination of three vectors u and v and w is  $ cu + dv + ew $.

4. Take all linear combinations of u, or u and v, or u, v, w. In three dimensions, those combinations typically fill a line, then a plane, then the whole space  $ R^3 $.

## WORKED EXAMPLES

1.1 A The linear combinations of  $ v = (1, 1, 0) $ and  $ w = (0, 1, 1) $ fill a plane in  $ R^3 $. Describe that plane. Find a vector that is not a combination of  $ v $ and  $ w $—not on the plane.

Solution The plane of v and w contains all combinations  $ cv + dw $. The vectors in that plane allow any c and d. The plane of Figure 1.3 fills in between the two lines.

Combinations

 $$ \boldsymbol{c}\boldsymbol{v}+d\boldsymbol{w}=c\left[\begin{array}{l}1\\ 1\\ 0\end{array}\right]+d\left[\begin{array}{l}0\\ 1\\ 1\end{array}\right]=\left[\begin{array}{c}c\\ c+d\\ d\end{array}\right] $$ 

fill a plane.

Four vectors in that plane are  $ (0,0,0) $ and  $ (2,3,1) $ and  $ (5,7,2) $ and  $ (\pi,2\pi,\pi) $. The second component  $ c + d $ is always the sum of the first and third components. Like most vectors,  $ (1,2,3) $ is not in the plane, because  $ 2 \neq 1 + 3 $.

Another description of this plane through  $ (0,0,0) $ is to know that  $ \boldsymbol{n} = (1,-1,1) $ is perpendicular to the plane. Section 1.2 will confirm that  $ 90^{\circ} $ angle by testing dot products:  $ v \cdot n = 0 $ and  $ w \cdot n = 0 $. Perpendicular vectors have zero dot products.