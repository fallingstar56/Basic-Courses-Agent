In two dimensions the length is  $ \sqrt{v_{1}^{2} + v_{2}^{2}} $. In three dimensions it is  $ \sqrt{v_{1}^{2} + v_{2}^{2} + v_{3}^{2}} $. By the calculation above, the length of  $ v = (1, 2, 3) $ is  $ \|v\| = \sqrt{14} $.

Here  $ \|v\| = \sqrt{v \cdot v} $ is just the ordinary length of the arrow that represents the vector. If the components are 1 and 2, the arrow is the third side of a right triangle (Figure 1.6). The Pythagoras formula  $ a^2 + b^2 = c^2 $ connects the three sides:  $ 1^2 + 2^2 = \|v\|^2 $.

For the length of  $ v = (1, 2, 3) $, we used the right triangle formula twice. The vector  $ (1, 2, 0) $ in the base has length  $ \sqrt{5} $. This base vector is perpendicular to  $ (0, 0, 3) $ that goes straight up. So the diagonal of the box has length  $ \|v\| = \sqrt{5 + 9} = \sqrt{14} $.

The length of a four-dimensional vector would be  $ \sqrt{v_1^2 + v_2^2 + v_3^2 + v_4^2} $. Thus the vector  $ (1,1,1,1) $ has length  $ \sqrt{1^2 + 1^2 + 1^2 + 1^2} = 2 $. This is the diagonal through a unit cube in four-dimensional space. That diagonal in  $ n $ dimensions has length  $ \sqrt{n} $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_165_441_877_703.jpg" alt="Image" width="66%" /></div>


 $$ v\cdot v=v_{1}^{2}+v_{2}^{2}+v_{3}^{2} $$ 

 $$ 5=1^{2}+2^{2} $$ 

 $$ 14=1^{2}+2^{2}+3^{2} $$ 

<div style="text-align: center;">Figure 1.6: The length  $ \sqrt{v \cdot v} $ of two-dimensional and three-dimensional vectors.</div>


The word “unit” is always indicating that some measurement equals “one”. The unit price is the price for one item. A unit cube has sides of length one. A unit circle is a circle with radius one. Now we see the meaning of a “unit vector”.

DEFINITION A unit vector u is a vector whose length equals one. Then  $ u \cdot u = 1 $

An example in four dimensions is  $ \boldsymbol{u} = \left(\frac{1}{2}, \frac{1}{2}, \frac{1}{2}, \frac{1}{2}\right) $. Then  $ \boldsymbol{u} \cdot \boldsymbol{u} $ is  $ \frac{1}{4} + \frac{1}{4} + \frac{1}{4} + \frac{1}{4} = 1 $. We divided  $ \boldsymbol{v} = (1, 1, 1, 1) $ by its length  $ \|\boldsymbol{v}\| = 2 $ to get this unit vector.

Example 4 The standard unit vectors along the x and y axes are written i and j. In the xy plane, the unit vector that makes an angle “theta” with the x axis is  $ (\cos\theta, \sin\theta) $:

Unit vectors

 $$ \boldsymbol{i}=\begin{bmatrix}1\\ 0\end{bmatrix}\quad and\quad\boldsymbol{j}=\begin{bmatrix}0\\ 1\end{bmatrix}\quad and\quad\boldsymbol{u}=\begin{bmatrix}\cos\theta\\ \sin\theta\end{bmatrix}. $$ 

When  $ \theta = 0 $, the horizontal vector  $ \boldsymbol{u} $ is i. When  $ \theta = 90^\circ $ (or  $ \frac{\pi}{2} $ radians), the vertical vector is j. At any angle, the components  $ \cos\theta $ and  $ \sin\theta $ produce  $ \boldsymbol{u} \cdot \boldsymbol{u} = 1 $ because