## WORKED EXAMPLES

2.1 A Describe the column picture of these three equations Ax = b. Solve by careful inspection of the columns (instead of elimination):

 $$ \begin{align*}x+3y+2z&=-3\\2x+2y+2z&=-2\\3x+5y+6z&=-5\end{align*}\quad which is \quad\begin{bmatrix}1&3&2\\2&2&2\\3&5&6\end{bmatrix}\begin{bmatrix}x\\y\\z\end{bmatrix}=\begin{bmatrix}-3\\-2\\-5\end{bmatrix}.\end{align*} $$ 

Solution The column picture asks for a linear combination that produces $b$ from the three columns of $A$. In this example $b$ is minus the second column. So the solution is $x = 0, y = -1, z = 0$. To show that $(0, -1, 0)$ is the only solution we have to know that “$A$ is invertible” and “the columns are independent” and “the determinant isn’t zero.”

Those words are not yet defined but the test comes from elimination: We need (and for this matrix we find) a full set of three nonzero pivots.

Suppose the right side changes to  $ \boldsymbol{b} = (4, 4, 8) = \text{sum of the first two columns} $. Then the good combination has  $ x = 1, y = 1, z = 0 $. The solution becomes  $ \boldsymbol{x} = (1, 1, 0) $.

2.1 B This system has no solution. The planes in the row picture don't meet at a point. No combination of the three columns produces b. How to show this?

 $$ \begin{array}{l} x+3y+5z=4 \\ x+2y-3z=5 \\ 2x+5y+2z=8 \end{array} \quad \left[\begin{array}{ccc} 1 & 3 & 5 \\ 1 & 2 & -3 \\ 2 & 5 & 2 \end{array} \right] \left[\begin{array}{c} x \\ y \\ z \end{array} \right]  =\left[\begin{array}{c} 4 \\ 5 \\ 8 \end{array}\right]=b $$ 

Idea Add (equation 1) + (equation 2) - (equation 3). The result is 0 = 1. This system cannot have a solution. We could say: The vector  $ (1,1,-1) $ is orthogonal to all three columns of A but not orthogonal to b.

(1) Are any two of the three planes parallel? What are the equations of planes parallel to  $ x + 3y + 5z = 4 $?

(2) Take the dot product of each column of A (and also b) with  $ \boldsymbol{y} = (1, 1, -1) $. How do those dot products show that no combination of columns equals b?

(3) Find three different right side vectors  $ b^{*} $ and  $ b^{**} $ and  $ b^{***} $ that do allow solutions.

## Solution

(1) The planes don’t meet at a point, even though no two planes are parallel. For a plane parallel to  $ x + 3y + 5z = 4 $, change the “4”. The parallel plane  $ x + 3y + 5z = 0 $ goes through the origin  $ (0, 0, 0) $. And the equation multiplied by any nonzero constant still gives the same plane, as in  $ 2x + 6y + 10z = 8 $.

(2) The dot product of each column of A with  $ \boldsymbol{y} = (1, 1, -1) $ is zero. On the right side,  $ \boldsymbol{y} \cdot \boldsymbol{b} = (1, 1, -1) \cdot (4, 5, 8) = \mathbf{1} $ is not zero.  $ A\boldsymbol{x} = \boldsymbol{b} $ led to 0 = 1: no solution.

(3) There is a solution when $b$ is a combination of the columns. These three choices of $b$ have solutions including $x^{*} = (1, 0, 0)$ and $x^{**} = (1, 1, 1)$ and $x^{***} = (0, 0, 0)$:

 $$ \boldsymbol{b}^{*}=\begin{bmatrix}1\\ 1\\ 2\end{bmatrix}=\text{first column}\quad\boldsymbol{b}^{**}=\begin{bmatrix}9\\ 0\\ 9\end{bmatrix}=\text{sum of columns}\quad\boldsymbol{b}^{***}=\begin{bmatrix}0\\ 0\\ 0\end{bmatrix} $$ 