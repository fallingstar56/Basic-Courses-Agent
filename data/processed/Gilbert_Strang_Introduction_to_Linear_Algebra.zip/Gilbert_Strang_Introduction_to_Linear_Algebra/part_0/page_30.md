24 One-line proof of the inequality  $ \left|u \cdot U\right| \leq 1 $ for unit vectors  $ (u_1, u_2) $ and  $ (U_1, U_2) $

 $$ \left|\boldsymbol{u}\cdot\boldsymbol{U}\right|\leq\left|u_{1}\right|\left|U_{1}\right|+\left|u_{2}\right|\left|U_{2}\right|\leq\frac{u_{1}^{2}+U_{1}^{2}}{2}+\frac{u_{2}^{2}+U_{2}^{2}}{2}=1. $$ 

Put  $ (u_{1}, u_{2}) = (.6, .8) $ and  $ (U_{1}, U_{2}) = (.8, .6) $ in that whole line and find  $ \cos \theta $.

Why is  $ |\cos\theta| $ never greater than 1 in the first place?

(Recommended) Draw a parallelogram

Parallelogram with two sides v and w. Show that the squared diagonal lengths  $ \|v + w\|^2 + \|v - w\|^2 $ add to the sum of four squared side lengths  $ 2\|v\|^2 + 2\|w\|^2 $.

If $v = (1, 2)$ draw all vectors $w = (x, y)$ in the $xy$ plane with $v \cdot w = x + 2y = 5$. Why do those $w$'s lie along a line? Which is the shortest $w$?

(Recommended) If  $ \|v\| = 5 $ and  $ \|w\| = 3 $, what are the smallest and largest possible values of  $ \|v - w\| $? What are the smallest and largest possible values of  $ v \cdot w $?

## Challenge Problems

Can three vectors in the xy plane have  $ u \cdot v < 0 $ and  $ v \cdot w < 0 $ and  $ u \cdot w < 0 $? I don’t know how many vectors in xyz space can have all negative dot products. (Four of those vectors in the plane would certainly be impossible ...).

1 Pick any numbers that add to  $ x + y + z = 0 $. Find the angle between your vector  $ \boldsymbol{v} = (x, y, z) $ and the vector  $ \boldsymbol{w} = (z, x, y) $. Challenge question: Explain why  $ \boldsymbol{v} \cdot \boldsymbol{w} / \| \boldsymbol{v} \| \| \boldsymbol{w} \| $ is always  $ -\frac{1}{2} $.

How could you prove  $ \sqrt[3]{xyz} \leq \frac{1}{3}(x + y + z) $ (geometric mean  $ \leq $ arithmetic mean)?

Find 4 perpendicular unit vectors of the form  $ (\pm\frac{1}{2},\pm\frac{1}{2},\pm\frac{1}{2},\pm\frac{1}{2}) $: Choose + or −.

Using  $ v = \text{randn}(3, 1) $ in MATLAB, create a random unit vector  $ u = v / \|v\| $. Using  $ V = \text{randn}(3, 30) $ create 30 more random unit vectors  $ U_j $. What is the average size of the dot products  $ |u \cdot U_j| $? In calculus, the average is  $ \int_0^\pi |\cos\theta| d\theta/\pi = 2/\pi $.