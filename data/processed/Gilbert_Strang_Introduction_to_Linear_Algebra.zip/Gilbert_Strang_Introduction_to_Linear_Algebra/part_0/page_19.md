Problems 20–25 deal with u, v, w in three-dimensional space (see Figure 1.5b).

20 Locate  $ \frac{1}{3}u + \frac{1}{3}v + \frac{1}{3}w $ and  $ \frac{1}{2}u + \frac{1}{2}w $ in Figure 1.5b. Challenge problem: Under what restrictions on c, d, e, will the combinations  $ cu + dv + ew $ fill in the dashed triangle? To stay in the triangle, one requirement is  $ c \geq 0 $,  $ d \geq 0 $,  $ e \geq 0 $.

21 The three sides of the dashed triangle are $v-u$ and $w-v$ and $u-w$. Their sum is ___. Draw the head-to-tail addition around a plane triangle of $(3,1)$ plus $(-1,1)$ plus $(-2,-2)$.

22 Shade in the pyramid of combinations  $ cu + dv + ew $ with  $ c \geq 0 $,  $ d \geq 0 $,  $ e \geq 0 $ and  $ c + d + e \leq 1 $. Mark the vector  $ \frac{1}{2}(u + v + w) $ as inside or outside this pyramid.

23 If you look at all combinations of those u, v, and w, is there any vector that can't be produced from cu + dv + ew? Different answer if u, v, w are all in ___.

24 Which vectors are combinations of u and v, and also combinations of v and w?

25 Draw vectors u, v, w so that their combinations  $ cu + dv + ew $ fill only a line. Find vectors u, v, w so that their combinations  $ cu + dv + ew $ fill only a plane.

26 What combination $c\begin{bmatrix}1\\ 2\end{bmatrix}+d\begin{bmatrix}3\\ 1\end{bmatrix}$ produces $\begin{bmatrix}14\\ 8\end{bmatrix}$? Express this question as two equations for the coefficients $c$ and $d$ in the linear combination.

## Challenge Problems

How many corners does a cube have in 4 dimensions? How many 3D faces? How many edges? A typical corner is  $ (0,0,1,0) $. A typical edge goes to  $ (0,1,0,0) $.

Find vectors $v$ and $w$ so that $v + w = (4, 5, 6)$ and $v - w = (2, 5, 8)$. This is a question with ___ unknown numbers, and an equal number of equations to find those numbers.

29 Find two different combinations of the three vectors  $ \boldsymbol{u} = (1, 3) $ and  $ \boldsymbol{v} = (2, 7) $ and  $ \boldsymbol{w} = (1, 5) $ that produce  $ \boldsymbol{b} = (0, 1) $. Slightly delicate question: If I take any three vectors  $ \boldsymbol{u}, \boldsymbol{v}, \boldsymbol{w} $ in the plane, will there always be two different combinations that produce  $ \boldsymbol{b} = (0, 1) $?

The linear combinations of $v = (a, b)$ and $w = (c, d)$ fill the plane unless ___.

Find four vectors $u$, $v$, $w$, $z$ with four components each so that their combinations $cu + dv + ew + fz$ produce all vectors $(b_{1}, b_{2}, b_{3}, b_{4})$ in four-dimensional space.

Write down three equations for $c, d, e$ so that $cu + dv + ew = b$. Can you somehow find $c, d, e$ for this $b$?

 $$ \boldsymbol{u}=\left[\begin{array}{r}2\\ -1\\ 0\end{array}\right]\quad\boldsymbol{v}=\left[\begin{array}{r}-1\\ 2\\ -1\end{array}\right]\quad\boldsymbol{w}=\left[\begin{array}{r}0\\ -1\\ 2\end{array}\right]\quad\boldsymbol{b}=\left[\begin{array}{l}1\\ 0\\ 0\end{array}\right]. $$ 