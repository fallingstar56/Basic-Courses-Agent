If the columns combine into Ax = 0 then each of the rows has  $ r \cdot x = 0 $:

 $$ \left[\begin{array}{l l l}a_{1}&a_{2}&a_{3}\end{array}\right]\left[\begin{array}{l}x_{1}\\ x_{2}\\ x_{3}\end{array}\right]=\left[\begin{array}{l}0\\ 0\\ 0\end{array}\right]\qquad\mathbf{B}\mathbf{y}\mathbf{r}\mathbf{o}\mathbf{w}\mathbf{s}\left[\begin{array}{l}r_{1}\cdot\mathbf{x}\\ r_{2}\cdot\mathbf{x}\\ r_{3}\cdot\mathbf{x}\end{array}\right]=\left[\begin{array}{l}0\\ 0\\ 0\end{array}\right]. $$ 

The three rows also lie in a plane. Why is that plane perpendicular to x?

Moving to a 4 by 4 difference equation  $ Ax = b $, find the four components  $ x_1, x_2, x_3, x_4 $. Then write this solution as  $ x = A^{-1}b $ to find the inverse matrix:

What is the cyclic 4 by 4 difference matrix $C$? It will have 1 and -1 in each row and each column. Find all solutions $x = (x_1, x_2, x_3, x_4)$ to $Cx = 0$. The four columns of $C$ lie in a “three-dimensional hyperplane” inside four-dimensional space.

 $$ \boldsymbol{A}\boldsymbol{x}=\left[\begin{array}{cccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}} \\{{{x_{4}}}}\end{array}\right]=\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}} \\{{{b_{4}}}}\end{array}\right]=\boldsymbol{b}. $$ 

10 A forward difference matrix  $ \Delta $ is upper triangular:

 $$ \Delta z=\left[\begin{array}{r r r}{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}\end{array}\right]\cdot\left[\begin{array}{l}{{{z_{1}}}} \\{{{z_{2}}}} \\{{{z_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{z_{2}-z_{1}}}} \\{{{z_{3}-z_{2}}}} \\{{{0-z_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{array}\right]=b. $$ 

Find  $ z_1 $,  $ z_2 $,  $ z_3 $ from  $ b_1 $,  $ b_2 $,  $ b_3 $. What is the inverse matrix in  $ z = \Delta^{-1} b $?

Show that the forward differences  $ (t + 1)^2 - t^2 $ are  $ 2t + 1 = odd\text{ numbers} $. As in calculus, the difference  $ (t + 1)^n - t^n $ will begin with the derivative of  $ t^n $, which is ___.

The last lines of the Worked Example say that the 4 by 4 centered difference matrix in (16) is invertible. Solve  $ Cx = (b_1, b_2, b_3, b_4) $ to find its inverse in  $ x = C^{-1}b $.

## Challenge Problems

The very last words say that the 5 by 5 centered difference matrix is not invertible. Write down the 5 equations  $ Cx = b $. Find a combination of left sides that gives zero. What combination of  $ b_1, b_2, b_3, b_4, b_5 $ must be zero? (The 5 columns lie on a “4-dimensional hyperplane” in 5-dimensional space. Hard to visualize.)

If  $ (a,b) $ is a multiple of  $ (c,d) $ with  $ abcd \neq 0 $, show that  $ (a,c) $ is a multiple of  $ (b,d) $. This is surprisingly important; two columns are falling on one line. You could use numbers first to see how  $ a $,  $ b $,  $ c $,  $ d $ are related. The question will lead to:

If  $ \left[\begin{array}{cc}a & b \\ c & d\end{array}\right] $ has dependent rows, then it also has dependent columns.