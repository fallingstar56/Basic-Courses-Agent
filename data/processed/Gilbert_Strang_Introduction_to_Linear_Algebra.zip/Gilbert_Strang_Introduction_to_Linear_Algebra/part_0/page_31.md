### 1.3 Matrices

1 A =  $ \begin{bmatrix} 1 & 2 \\ 3 & 4 \\ 5 & 6 \end{bmatrix} $ is a 3 by 2 matrix: m = 3 rows and n = 2 columns.

2 Ax =  $ \left[\begin{array}{cc}1 & 2 \\ 3 & 4 \\ 5 & 6\end{array}\right]\left[\begin{array}{c}x_{1} \\ x_{2}\end{array}\right] $ is a combination of the columns

 $$ \boldsymbol{A}\boldsymbol{x}=x_{1}\left[\begin{array}{l}1\\ 3\\ 5\end{array}\right]+x_{2}\left[\begin{array}{l}2\\ 4\\ 6\end{array}\right]. $$ 

3 The 3 components of Ax are dot products of the 3 rows of A with the vector x:

Row at a time

 $$ \left[\begin{array}{cc}{{{1}}}&{{{2}}} \\{{{3}}}&{{{4}}} \\{{{5}}}&{{{6}}}\end{array}\right]\left[\begin{array}{c}{{{7}}} \\{{{8}}}\end{array}\right]=\left[\begin{array}{l}{{{1\cdot7+2\cdot8}}} \\{{{3\cdot7+4\cdot8}}} \\{{{5\cdot7+6\cdot8}}}\end{array}\right]=\left[\begin{array}{c}{{{23}}} \\{{{53}}} \\{{{83}}}\end{array}\right]. $$ 

4 Equations in matrix form  $ Ax = b $:  $ \left[\begin{array}{cc}2 & 5 \\ 3 & 7\end{array}\right]\left[\begin{array}{c}x_{1} \\ x_{2}\end{array}\right] = \left[\begin{array}{c}b_{1} \\ b_{2}\end{array}\right] $ replaces  $ 2x_{1} + 5x_{2} = b_{1} $  $ 3x_{1} + 7x_{2} = b_{2} $.

5 The solution to Ax = b can be written as x = A−1b. But some matrices don't allow A−1.

This section starts with three vectors u, v, w. I will combine them using matrices.

Three vectors

 $$ \boldsymbol{u}=\left[\begin{array}{r}1\\ -1\\ 0\end{array}\right]\qquad\boldsymbol{v}=\left[\begin{array}{r}0\\ 1\\ -1\end{array}\right]\qquad\boldsymbol{w}=\left[\begin{array}{l}0\\ 0\\ 1\end{array}\right]。 $$ 

Their linear combinations in three-dimensional space are  $ x_{1}u + x_{2}v + x_{3}w $:

Combination of the vectors

 $$ x_{1}\left[\begin{array}{r}1\\ -1\\ 0\end{array}\right]+x_{2}\left[\begin{array}{r}0\\ 1\\ -1\end{array}\right]+x_{3}\left[\begin{array}{r}0\\ 0\\ 1\end{array}\right]=\left[\begin{array}{l}x_{1}\\ x_{2}-x_{1}\\ x_{3}-x_{2}\end{array}\right]。 $$ 

Now something important: Rewrite that combination using a matrix. The vectors  $ \boldsymbol{u}, \boldsymbol{v}, \boldsymbol{w} $ go into the columns of the matrix A. That matrix “multiplies” the vector  $ (x_1, x_2, x_3) $:

Matrix times vector

Combination of columns

 $$ \boldsymbol{A}\boldsymbol{x}=\left[\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}-x_{1}}}} \\{{{x_{3}-x_{2}}}}\end{array}\right] $$ 

The numbers  $ x_1, x_2, x_3 $ are the components of a vector  $ x $. The matrix  $ A $ times the vector  $ x $ is the same as the combination  $ x_1u + x_2v + x_3w $ of the three columns in equation (1).

This is more than a definition of Ax, because the rewriting brings a crucial change in viewpoint. At first, the numbers  $ x_{1}, x_{2}, x_{3} $ were multiplying the vectors. Now the