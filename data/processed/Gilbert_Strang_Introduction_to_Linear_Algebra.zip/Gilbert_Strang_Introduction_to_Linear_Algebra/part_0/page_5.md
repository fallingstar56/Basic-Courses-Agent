## The Fifth Edition

The cover shows the Four Fundamental Subspaces—the row space and nullspace are on the left side, the column space and the nullspace of  $ A^{T} $ are on the right. It is not usual to put the central ideas of the subject on display like this! When you meet those four spaces in Chapter 3, you will understand why that picture is so central to linear algebra.

Those were named the Four Fundamental Subspaces in my first book, and they start from a matrix A. Each row of A is a vector in n-dimensional space. When the matrix has m rows, each column is a vector in m-dimensional space. The crucial operation in linear algebra is to take linear combinations of column vectors. This is exactly the result of a matrix-vector multiplication. Ax is a combination of the columns of A.

When we take all combinations Ax of the column vectors, we get the column space. If this space includes the vector b, we can solve the equation Ax = b.

May I call special attention to Section 1.3, where these ideas come early—with two specific examples. You are not expected to catch every detail of vector spaces in one day! But you will see the first matrices in the book, and a picture of their column spaces. There is even an inverse matrix and its connection to calculus. You will be learning the language of linear algebra in the best and most efficient way: by using it.

Every section of the basic course ends with a large collection of review problems. They ask you to use the ideas in that section—the dimension of the column space, a basis for that space, the rank and inverse and determinant and eigenvalues of A. Many problems look for computations by hand on a small matrix, and they have been highly praised. The Challenge Problems go a step further, and sometimes deeper. Let me give four examples:

Section 2.1: Which row exchanges of a Sudoku matrix produce another Sudoku matrix?

Section 2.7: If P is a permutation matrix, why is some power  $ P^{k} $ equal to I?

Section 3.4: If Ax = b and Cx = b have the same solutions for every b, does A equal C?

Section 4.1: What conditions on the four vectors r, n, c,  $ \ell $ allow them to be bases for the row space, the nullspace, the column space, and the left nullspace of a 2 by 2 matrix?

## The Start of the Course

The equation  $ Ax = b $ uses the language of linear combinations right away. The vector  $ Ax $ is a combination of the columns of A. The equation is asking for a combination that produces b. The solution vector  $ x $ comes at three levels and all are important:

1. Direct solution to find x by forward elimination and back substitution.

2. Matrix solution using the inverse matrix:  $ x = A^{-1}b $ (if A has an inverse).

3. Particular solution (to Ay = b) plus nullspace solution (to Az = 0).

That vector space solution  $ x = y + z $ is shown on the cover of the book.