## Preface

I am happy for you to see this Fifth Edition of Introduction to Linear Algebra. This is the text for my video lectures on MIT's OpenCourseWare (ocw.mit.edu and also YouTube). I hope those lectures will be useful to you (maybe even enjoyable!).

Hundreds of colleges and universities have chosen this textbook for their basic linear algebra course. A sabbatical gave me a chance to prepare two new chapters about probability and statistics and understanding data. Thousands of other improvements too—probably only noticed by the author... Here is a new addition for students and all readers:

Every section opens with a brief summary to explain its contents. When you read a new section, and when you revisit a section to review and organize it in your mind, those lines are a quick guide and an aid to memory.

Another big change comes on this book's website math.mit.edu/linearalgebra. That site now contains solutions to the Problem Sets in the book. With unlimited space, this is much more flexible than printing short solutions. There are three key websites:

ocw.mit.edu Messages come from thousands of students and faculty about linear algebra on this OpenCourseWare site. The 18.06 and 18.06 SC courses include video lectures of a complete semester of classes. Those lectures offer an independent review of the whole subject based on this textbook—the professor's time stays free and the student's time can be 2 a.m. (The reader doesn't have to be in a class at all.) Six million viewers around the world have seen these videos (amazing). I hope you find them helpful.

web.mit.edu/18.06 This site has homeworks and exams (with solutions) for the current course as it is taught, and as far back as 1996. There are also review questions, Java demos, Teaching Codes, and short essays (and the video lectures). My goal is to make this book as useful to you as possible, with all the course material we can provide.

math.mit.edu/linearalgebra This has become an active website. It now has Solutions to Exercises—with space to explain ideas. There are also new exercises from many different sources—practice problems, development of textbook examples, codes in MATLAB and Julia and Python, plus whole collections of exams (18.06 and others) for review.

Please visit this linear algebra site. Send suggestions to linearalgebrabook@gmail.com