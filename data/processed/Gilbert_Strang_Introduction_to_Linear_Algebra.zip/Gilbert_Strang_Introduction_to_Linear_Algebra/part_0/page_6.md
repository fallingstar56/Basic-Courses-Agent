Direct elimination is the most frequently used algorithm in scientific computing. The matrix A becomes triangular—then solutions come quickly. We also see bases for the four subspaces. But don’t spend forever on practicing elimination … good ideas are coming.

The speed of every new supercomputer is tested on Ax = b: pure linear algebra. But even a supercomputer doesn't want the inverse matrix: too slow. Inverses give the simplest formula  $ x = A^{-1}b $ but not the top speed. And everyone must know that determinants are even slower—there is no way a linear algebra course should begin with formulas for the determinant of an n by n matrix. Those formulas have a place, but not first place.

## Structure of the Textbook

Already in this preface, you can see the style of the book and its goal. That goal is serious, to explain this beautiful and useful part of mathematics. You will see how the applications of linear algebra reinforce the key ideas. This book moves gradually and steadily from numbers to vectors to subspaces—each level comes naturally and everyone can get it.

Here are 12 points about learning and teaching from this book:

1. Chapter 1 starts with vectors and dot products. If the class has met them before, focus quickly on linear combinations. Section 1.3 provides three independent vectors whose combinations fill all of 3-dimensional space, and three dependent vectors in a plane. Those two examples are the beginning of linear algebra.

2. Chapter 2 shows the row picture and the column picture of Ax = b. The heart of linear algebra is in that connection between the rows of A and the columns of A: the same numbers but very different pictures. Then begins the algebra of matrices: an elimination matrix E multiplies A to produce a zero. The goal is to capture the whole process—start with A, multiply by E's, end with U.

Elimination is seen in the beautiful form  $ A = LU $. The lower triangular  $ L $ holds the forward elimination steps, and  $ U $ is upper triangular for back substitution.

3. Chapter 3 is linear algebra at the best level: subspaces. The column space contains all linear combinations of the columns. The crucial question is: How many of those columns are needed? The answer tells us the dimension of the column space, and the key information about A. We reach the Fundamental Theorem of Linear Algebra.

4. With more equations than unknowns, it is almost sure that Ax = b has no solution. We cannot throw out every measurement that is close but not perfectly exact! When we solve by least squares, the key will be the matrix  $ A^{T}A $. This wonderful matrix appears everywhere in applied mathematics, when A is rectangular.

5. Determinants give formulas for all that has come before—Cramer's Rule, inverse matrices, volumes in $n$ dimensions. We don't need those formulas to compute. They slow us down. But $\det A = 0$ tells when a matrix is singular: this is the key to eigenvalues.