### 1.2 Lengths and Dot Products

1 The “dot product” of  $ v = \left[\begin{array}{c} 1 \\ 2 \end{array}\right] $ and  $ w = \left[\begin{array}{c} 4 \\ 5 \end{array}\right] $ is  $ v \cdot w = (1)(4) + (2)(5) = 4 + 10 = 14 $.

2  $ v = \left[\begin{array}{c} 1 \\ 3 \\ 2 \end{array}\right] $ and  $ w = \left[\begin{array}{c} 4 \\ -4 \\ 4 \end{array}\right] $ are perpendicular because  $ v \cdot w $ is zero:

(1) $ (4) + (3)(-4) + (2)(4) = 0 $.

3 The length squared of  $ v = \left[\begin{array}{c} 1 \\ 3 \\ 2 \end{array}\right] $ is  $ v \cdot v = 1 + 9 + 4 = 14 $. The length is  $ ||v|| = \sqrt{14} $.

4 Then  $ u = \frac{v}{||v||} = \frac{v}{\sqrt{14}} = \frac{1}{\sqrt{14}} \left[\begin{array}{c} 1 \\ 3 \\ 2 \end{array}\right] $ has length  $ ||u|| = 1 $. Check  $ \frac{1}{14} + \frac{9}{14} + \frac{4}{14} = 1 $.

5 The angle  $ \theta $ between  $ v $ and  $ w $ has  $ \cos \theta = \frac{v \cdot w}{||v||} \cdot \frac{||w||}{||w||} $.

6 The angle between  $ \left[\begin{array}{c} 1 \\ 0 \end{array}\right] $ and  $ \left[\begin{array}{c} 1 \\ 1 \end{array}\right] $ has  $ \cos \theta = \frac{1}{(1)(\sqrt{2})} \cdot $ That angle is  $ \theta = 45^\circ $.

7 All angles have  $ |\cos \theta| \leq 1 $. So all vectors have  $ \boxed{|v \cdot w|} \leq ||v|| \cdot ||w|| $.

The first section backed off from multiplying vectors. Now we go forward to define the “dot product” of v and w. This multiplication involves the separate products  $ v_1w_1 $ and  $ v_2w_2 $, but it doesn’t stop there. Those two numbers are added to produce one number  $ v \cdot w $.

This is the geometry section (lengths of vectors and cosines of angles between them).

The dot product or inner product of  $  v = (v_{1}, v_{2})  $ and  $  w = (w_{1}, w_{2})  $ is the number  $  v \cdot w  $:

 $$ v\cdot w=v_{1}w_{1}+v_{2}w_{2}. $$ 

Example 1 The vectors  $ v = (4, 2) $ and  $ w = (-1, 2) $ have a zero dot product:

Dot product is zero

Perpendicular vectors

 $$ \begin{bmatrix}4\\ 2\end{bmatrix}\cdot\begin{bmatrix}-1\\ 2\end{bmatrix}=-4+4=0. $$ 

In mathematics, zero is always a special number. For dot products, it means that these two vectors are perpendicular. The angle between them is 90°. When we drew them in Figure 1.1, we saw a rectangle (not just any parallelogram). The clearest example of perpendicular vectors is  $ i = (1, 0) $ along the x axis and  $ \boldsymbol{j} = (0, 1) $ up the y axis. Again the dot product is  $ i \cdot j = 0 + 0 = 0 $. Those vectors  $ i $ and  $ j $ form a right angle.