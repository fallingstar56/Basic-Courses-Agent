Problems 18–28 lead to the main facts about lengths and angles in triangles.

The parallelogram with sides  $ v = (4, 2) $ and  $ w = (-1, 2) $ is a rectangle. Check the Pythagoras formula  $ a^{2} + b^{2} = c^{2} $ which is for right triangles only:

 $$ (\mathrm{l e n g t h~o f~}v)^{2}+(\mathrm{l e n g t h~o f~}w)^{2}=(\mathrm{l e n g t h~o f~}v+w)^{2}. $$ 

(Rules for dot products) These equations are simple but useful:

(1)  $  v \cdot w = w \cdot v  $ (2)  $  u \cdot (v + w) = u \cdot v + u \cdot w  $ (3)  $  (cv) \cdot w = c(v \cdot w)  $

Use (2) with  $ u = v + w $ to prove  $ \|v + w\|^2 = v \cdot v + 2v \cdot w + w \cdot w $.

The “Law of Cosines” comes from  $ (v - w) \cdot (v - w) = v \cdot v - 2v \cdot w + w \cdot w $:

Cosine Law

 $$ \|v-w\|^{2}=\|v\|^{2}-2\|v\|\|w\|\cos\theta+\|w\|^{2}. $$ 

Draw a triangle with sides v and w and v − w. Which of the angles is θ ?

The triangle inequality says: (length of v + w) ≤ (length of v) + (length of w).

Problem 19 found  $ \|v + w\|^2 = \|v\|^2 + 2v \cdot w + \|w\|^2 $. Increase that  $ v \cdot w $ to  $ \|v\|\|w\| $ to show that  $ \|\text{side } 3\| $ can not exceed  $ \|\text{side } 1\| $ +  $ \|\text{side } 2\| $:

Triangle inequality

 $$ \left\| \mathbf{v}+\mathbf{w} \right\|^{2}\leq \left( \left\| \mathbf{v} \right\|+\left\| \mathbf{w} \right\| \right)^{2} \quad \mathbf{or} \quad \left\| \mathbf{v}+\mathbf{w} \right\|\leq \left\| \mathbf{v} \right\|+\left\| \mathbf{w} \right\|. $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_213_758_870_923.jpg" alt="Image" width="61%" /></div>


22 The Schwarz inequality  $ |v \cdot w| \leq \|v\|\|w\| $ by algebra instead of trigonometry:

(a) Multiply out both sides of  $ (v_{1}w_{1} + v_{2}w_{2})^{2} \leq (v_{1}^{2} + v_{2}^{2})(w_{1}^{2} + w_{2}^{2}) $.

(b) Show that the difference between those two sides equals  $ (v_{1}w_{2} - v_{2}w_{1})^{2} $. This cannot be negative since it is a square—so the inequality is true.

The figure shows that  $ \cos \alpha = v_1 / \|v\| $ and  $ \sin \alpha = v_2 / \|v\| $. Similarly  $ \cos \beta $ is ___ and  $ \sin \beta $ is ___. The angle  $ \theta $ is  $ \beta - \alpha $. Substitute into the trigonometry formula  $ \cos \beta \cos \alpha + \sin \beta \sin \alpha $ for  $ \cos(\beta - \alpha) $ to find  $ \cos \theta = v \cdot w / \|v\| \|w\| $.