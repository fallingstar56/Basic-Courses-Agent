<div style="text-align: center;"><img src="imgs/img_in_image_box_363_117_756_339.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;">Figure 2.1: Row picture: The point  $ (3,1) $ where the lines meet solves both equations.</div>


ROWS The row picture shows two lines meeting at a single point (the solution).

Turn now to the column picture. I want to recognize the same linear system as a “vector equation”. Instead of numbers we need to see vectors. If you separate the original system into its columns instead of its rows, you get a vector equation:

Combination equals b

 $$ x\left[\begin{array}{c}1\\ 3\end{array}\right]+y\left[\begin{array}{c}-2\\ 2\end{array}\right]=\left[\begin{array}{c}1\\ 11\end{array}\right]=b. $$ 

This has two column vectors on the left side. The problem is to find the combination of those vectors that equals the vector on the right. We are multiplying the first column by x and the second column by y, and adding. With the right choices x = 3 and y = 1 (the same numbers as before), this produces 3 (column 1) + 1 (column 2) = b.

COLUMNS The column picture combines the column vectors on the left side to produce the vector b on the right side.

Figure 2.2 is the “column picture” of two equations in two unknowns. The first part shows the two separate columns, and that first column multiplied by 3. This multiplication by a scalar (a number) is one of the two basic operations in linear algebra:

Scalar multiplication

 $$ 3\left[\begin{array}{l}1\\ 3\end{array}\right]=\left[\begin{array}{l}3\\ 9\end{array}\right]. $$ 

If the components of a vector v are v1 and v2, then cv has components cv1 and cv2

The other basic operation is vector addition. We add the first components and the second components separately. The vector sum is  $ (1, 11) $, the desired vector b.

Vector addition

 $$ \left[\begin{array}{l}3\\ 9\end{array}\right]+\left[\begin{array}{r}-2\\ 2\end{array}\right]=\left[\begin{array}{r}1\\ 11\end{array}\right]. $$ 

The right side of Figure 2.2 shows this addition. Two vectors are in black. The sum along the diagonal is the vector  $ \boldsymbol{b} = (1, 11) $ on the right side of the linear equations.