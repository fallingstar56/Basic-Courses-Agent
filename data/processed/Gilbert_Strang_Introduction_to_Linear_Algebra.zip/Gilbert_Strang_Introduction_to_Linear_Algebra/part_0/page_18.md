<div style="text-align: center;"><img src="imgs/img_in_image_box_197_118_842_349.jpg" alt="Image" width="60%" /></div>


<div style="text-align: center;">Figure 1.4: Unit cube from i,j,k and twelve clock vectors.</div>


13 (a) What is the sum V of the twelve vectors that go from the center of a clock to the hours 1:00, 2:00, ..., 12:00?

(b) If the 2:00 vector is removed, why do the 11 remaining vectors add to 8:00?

(c) What are the x, y components of that 2:00 vector  $ \boldsymbol{v} = (\cos \theta, \sin \theta) $?

14 Suppose the twelve vectors start from 6:00 at the bottom instead of  $ (0,0) $ at the center. The vector to 12:00 is doubled to  $ (0,2) $. The new twelve vectors add to ___.

Problems 15–19 go further with linear combinations of v and w (Figure 1.5a).

15 Figure 1.5a shows  $ \frac{1}{2}v + \frac{1}{2}w $. Mark the points  $ \frac{3}{4}v + \frac{1}{4}w $ and  $ \frac{1}{4}v + \frac{1}{4}w $ and  $ v + w $.

Mark the point  $ -v + 2w $ and any other combination  $ cv + dw $ with  $ c + d = 1 $. Draw the line of all combinations that have  $ c + d = 1 $.

Locate  $ \frac{1}{3} v + \frac{1}{3} w $ and  $ \frac{2}{3} v + \frac{2}{3} w $. The combinations  $ cv + cw $ fill out what line?

Restricted by  $ 0 \leq c \leq 1 $ and  $ 0 \leq d \leq 1 $, shade in all combinations  $ cv + dw $.

Restricted only by  $ c \geq 0 $ and  $ d \geq 0 $ draw the “cone” of all combinations  $ cv + dw $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_265_918_493_1114.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">Figure 1.5: Problems 15–19 in a plane</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_540_919_770_1127.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">Problems 20–25 in 3-dimensional space</div>
