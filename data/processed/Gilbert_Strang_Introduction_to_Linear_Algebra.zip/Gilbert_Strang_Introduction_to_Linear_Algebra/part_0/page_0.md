## INTRODUCTION TO LINEAR ALGEBRA

Fifth Edition

GILBERT STRANG

Massachusetts Institute of Technology

WELLESLEY - CAMBRIDGE PRESS

Box 812060 Wellesley MA 02482