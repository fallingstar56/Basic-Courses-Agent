1.1 B For  $ v = (1, 0) $ and  $ w = (0, 1) $, describe all points  $ cv $ with (1) whole numbers  $ c $ (2) nonnegative numbers  $ c \geq 0 $. Then add all vectors  $ dw $ and describe all  $ cv + dw $.

## Solution

(1) The vectors  $ cv = (c, 0) $ with whole numbers c are equally spaced points along the x axis (the direction of v). They include  $ (-2, 0) $,  $ (-1, 0) $,  $ (0, 0) $,  $ (1, 0) $,  $ (2, 0) $.

(2) The vectors  $ cv $ with  $ c \geq 0 $ fill a half-line. It is the positive  $ x $ axis. This half-line starts at  $ (0,0) $ where  $ c = 0 $. It includes  $ (100,0) $ and  $ (\pi,0) $ but not  $ (-100,0) $.

(1') Adding all vectors  $ dw = (0, d) $ puts a vertical line through those equally spaced cv. We have infinitely many parallel lines from (whole number c, any number d).

(2') Adding all vectors  $ dw $ puts a vertical line through every  $ cv $ on the half-line. Now we have a half-plane. The right half of the  $ xy $ plane has any  $ x \geq 0 $ and any  $ y $.

1.1 C Find two equations for c and d so that the linear combination cv + dw equals b:

 $$ \boldsymbol{v}=\left[\begin{array}{r}2\\ -1\end{array}\right]\qquad\boldsymbol{w}=\left[\begin{array}{r}-1\\ 2\end{array}\right]\qquad\boldsymbol{b}=\left[\begin{array}{l}1\\ 0\end{array}\right]. $$ 

__anematics, many problems have two parts:

1 Modeling part Express the problem by a set of equations.

2 Computational part Solve those equations by a fast and accurate algorithm.

Here we are only asked for the first part (the equations). Chapter 2 is devoted to the second part (the solution). Our example fits into a fundamental model for linear algebra:

Find n numbers

 $$ c_{1},\cdots,c_{n}\text{ so that}c_{1}v_{1}+\cdots+c_{n}v_{n}=b. $$ 

For n = 2 we will find a formula for the c's. The “elimination method” in Chapter 2 succeeds far beyond n = 1000. For n greater than 1 billion, see Chapter 11. Here n = 2:

Vector equation  $ cv \perp dw = b $

 $$ c \left[\begin{array}{c} 2 \\ -1 \end{array} \right]+ d \left[\begin{array}{c} -1 \\ 2 \end{array} \right]=\left[\begin{array}{l} 1 \\ 0 \end{array} \right] $$ 

The required equations for c and d just come from the two components separately:

Two ordinary equations

 $$ \begin{array}{c}2c-d=1\\-c+2d=0\end{array} $$ 

Each equation produces a line. The two lines cross at the solution  $ c = \frac{2}{3} $,  $ d = \frac{1}{3} $. Why not see this also as a matrix equation, since that is where we are going:

2 by 2 matrix

 $$ \left[\begin{array}{c c}{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}\end{array}\right]\left[\begin{array}{l}{{{c}}} \\{{{d}}}\end{array}\right]=\left[\begin{array}{l}{{{1}}} \\{{{0}}}\end{array}\right]. $$ 