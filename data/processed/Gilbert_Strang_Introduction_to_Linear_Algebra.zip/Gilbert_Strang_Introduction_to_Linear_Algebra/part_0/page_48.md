Julia combines the high productivity of SciPy or R for technical computing with performance comparable to C or Fortran. It can call Python and C/Fortran libraries. But it doesn’t rely on “vectorized” library functions for speed; Julia is designed to be fast.

I entered juliabox.org. I clicked Sign in via Google to access my gmail space. Then I clicked new at the right and chose a Julia notebook. I chose 0.4.5 and not one under development. The Julia command line came up immediately.

As a novice, I computed  $ 1 + 1 $. To see the answer I pressed Shift+Enter. I also learned that  $ 1.0 + 1.0 $ uses floating point, much faster for a large problem. The website math.mit.edu/linearalgebra will show part of the power of Julia and Python and R.

Python is a popular general-purpose programming language. When combined with packages like NumPy and the SciPy library, it provides a full-featured environment for technical computing. NumPy has the basic linear algebra commands. Download the Anaconda Python distribution from https://www.continuum.io (a prepackaged collection of Python and most important mathematical libraries, with a graphical installer).

R is free software for statistical computing and graphics. To download and install R, go to r-project.org (prefix https://www.). Commands are prompted by > and R is a scripted language. It works with lists that can be shaped into vectors and matrices.

It is important to recommend RStudio for editing and graphing (and help resources). When you download from www.RStudio.com, a window opens for R commands—plus windows for editing and managing files and plots. Tell R the form of the matrix as well as the list of numerical entries:

 $$ >A=matrix\left(c\left(1,2,3,2,5,2,6,-3,1\right),nrow=3,byrow=TRUE\right) $$ 

 $$ >x=matrix\left(c\left(0,0,2\right),nrow=3\right) $$ 

To see A and x, type their names at the new prompt >. To multiply type  $ b = A\% * \% x $. Transpose by  $ t(A) $ and use as.matrix to turn a vector into a matrix.

MATLAB and Julia have a cleaner syntax for matrix computations than R. But R has become very familiar and widely used. The website for this book has space for proper demos (including the Manipulate command) of MATLAB and Julia and Python and R.

## ■ REVIEW OF THE KEY IDEAS

1. The basic operations on vectors are multiplication cv and vector addition v + w.

2. Together those operations give linear combinations  $ cv + dw $.

3. Matrix-vector multiplication  $ A x $ can be computed by dot products, a row at a time. But  $ A x $ must be understood as a combination of the columns of  $ A $.

4. Column picture: Ax = b asks for a combination of columns to produce b.

5. Row picture: Each equation in Ax = b gives a line  $ (n = 2) $ or a plane  $ (n = 3) $ or a “hyperplane”  $ (n > 3) $. They intersect at the solution or solutions, if any.