Solution Solve the (linear triangular) system Ax = b from top to bottom:

\[\begin{array}{l}{{{\mathrm{f r i s t}\quad x_{1}=b_{1}\quad}}} \\{{{\mathrm{t h e n}\quad x_{2}=b_{1}+b_{2}\quad\quad\quad\

This is good practice to see the columns of the inverse matrix multiplying  $ b_1, b_2 $, and  $ b_3 $. The first column of  $ A^{-1} $ is the solution for  $ \boldsymbol{b} = (1, 0, 0) $. The second column is the solution for  $ \boldsymbol{b} = (0, 1, 0) $. The third column  $ \boldsymbol{x} $ of  $ A^{-1} $ is the solution for  $ A\boldsymbol{x} = \boldsymbol{b} = (0, 0, 1) $.

The three columns of A are still independent. They don’t lie in a plane. The combinations of those three columns, using the right weights  $ x_{1}, x_{2}, x_{3} $, can produce any three-dimensional vector  $ \boldsymbol{b} = (b_{1}, b_{2}, b_{3}) $. Those weights come from  $ \boldsymbol{x} = A^{-1} \boldsymbol{b} $.

1.3 B This E is an elimination matrix. E has a subtraction and  $ E^{-1} $ has an addition.

 $$ \boldsymbol{b}=E\boldsymbol{x}\qquad\begin{bmatrix}{{{b_{1}}}} \\{{{b_{2}}}}\end{bmatrix}=\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}-\ell x_{1}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{-\ell}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}}\end{bmatrix}\qquad\qquad E=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{-\ell}}}&{{{1}}}\end{bmatrix} $$ 

The first equation is  $ x_1 = b_1 $. The second equation is  $ x_2 - \ell x_1 = b_2 $. The inverse will add  $ \ell b_1 $ to  $ b_2 $, because the elimination matrix subtracted:

 $$ \boldsymbol{x}=E^{-1}\boldsymbol{b}\quad\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}}\end{bmatrix}=\begin{bmatrix}{{{b_{1}}}} \\{{{\ell b_{1}+b_{2}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{\ell}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{b_{1}}}} \\{{{b_{2}}}}\end{bmatrix}\quad\boldsymbol{E}^{-1}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{\ell}}}&{{{1}}}\end{bmatrix} $$ 

1.3 C Change C from a cyclic difference to a centered difference producing  $ x_{3} - x_{1} $:

 $$ C\boldsymbol{x}=\boldsymbol{b}\qquad\left[\begin{array}{r r r}{{{0}}}&{{{1}}}&{{{0}}} \\{{{-1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{-1}}}&{{{0}}}\end{array}\right]\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{x_{2}-0}}} \\{{{x_{3}-x_{1}}}} \\{{{0-x_{2}}}}\end{array}\right]=\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{array}\right]. $$ 

 $ Cx = b $ can only be solved when  $ b_1 + b_3 = x_2 - x_2 = 0 $. That is a plane of vectors  $ b $ in three-dimensional space. Each column of  $ C $ is in the plane, the matrix has no inverse. So this plane contains all combinations of those columns (which are all the vectors  $ Cx $).

I included the zeros so you could see that this C produces “centered differences”. Row i of Cx is  $ x_{i+1} $ (right of center) minus  $ x_{i-1} $ (left of center). Here is 4 by 4:

 $ Cx = b $

Centered differences

 $$ \begin{aligned}\left[\begin{array}{cccc}{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{0}}} \\\end{array}\right]\left[\begin{array}{c}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}} \\{{{x_{4}}}} \\\end{array}\right]&=\left[\begin{array}{c}{{{x_{2}-0}}} \\{{{x_{3}-x_{1}}}} \\{{{x_{4}-x_{2}}}} \\{{{0-x_{3}}}} \\\end{array}\right]=\left[\begin{array}{c}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}} \\{{{b_{4}}}} \\\end{array}\right]\end{aligned} $$ 

Surprisingly this matrix is now invertible! The first and last rows tell you  $ x_{2} $ and  $ x_{3} $. Then the middle rows give  $ x_{1} $ and  $ x_{4} $. It is possible to write down the inverse matrix  $ C^{-1} $. But 5 by 5 will be singular (not invertible) again ...