The vector  $ (x, y, z) = (0, 0, 0) $ does not solve  $ x + 2y + 3z = 6 $. Therefore that plane does not contain the origin. The plane  $ x + 2y + 3z = 0 $ does pass through the origin, and it is parallel to  $ x + 2y + 3z = 6 $. When the right side increases to 6, the parallel plane moves away from the origin.

The second plane is given by the second equation  $ 2x + 5y + 2z = 4 $. It intersects the first plane in a line L. The usual result of two equations in three unknowns is a line L of solutions. (Not if the equations were  $ x + 2y + 3z = 6 $ and  $ x + 2y + 3z = 0 $.)

The third equation gives a third plane. It cuts the line L at a single point. That point lies on all three planes and it solves all three equations. It is harder to draw this triple intersection point than to imagine it. The three planes meet at the solution (which we haven't found yet). The column form will now show immediately why z = 2.

<div style="text-align: center;"><img src="imgs/img_in_image_box_176_418_859_728.jpg" alt="Image" width="64%" /></div>


<div style="text-align: center;">Figure 2.3: Row picture: Two planes meet at a line L. Three planes meet at a point.</div>


The column picture starts with the vector form of the equations Ax = b:

Combine columns

 $$ \boldsymbol{x}\left[\begin{array}{l}1\\ 2\\ 6\end{array}\right]+y\left[\begin{array}{r}2\\ 5\\ -3\end{array}\right]+z\left[\begin{array}{l}3\\ 2\\ 1\end{array}\right]=\left[\begin{array}{l}6\\ 4\\ 2\end{array}\right]=\boldsymbol{b}. $$ 

The unknowns are the coefficients x, y, z. We want to multiply the three column vectors by the correct numbers x, y, z to produce  $ \boldsymbol{b} = (6, 4, 2) $.

Figure 2.4 shows this column picture. Linear combinations of those columns can produce any vector  $ b! $. The combination that produces  $ b = (6, 4, 2) $ is just 2 times the third column. The coefficients we need are  $ x = 0 $,  $ y = 0 $, and  $ z = 2 $.

The three planes in the row picture meet at that same solution point  $ (0, 0, 2) $:

Correct combination  $ (x,y,z)=(0,0,2) $

 $$ \begin{array}{l l l l}{0\left[\begin{array}{l}1\\ 2\\ 6\end{array}\right]+0\left[\begin{array}{r}2\\ 5\\ -3\end{array}\right]+2\left[\begin{array}{l}3\\ 2\\ 1\end{array}\right]=\left[\begin{array}{l}6\\ 4\\ 2\end{array}\right].}\end{array} $$ 