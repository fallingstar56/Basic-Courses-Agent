The row picture deals with the two rows of A. The column picture combines the columns. The numbers x = 3 and y = 1 go into x. Here is matrix-vector multiplication:

Dot products with rows Combination of columns

 $$ \begin{array}{r l}{A\boldsymbol{x}=b}&{{}\mathrm{~i s~}}\\ \end{array} \quad \left[\begin{array}{cc}{1}&{-2}\\ {3}&{2}\\ \end{array} \right]  \left[\begin{array}{c}{3}\\ {1}\\ \end{array} \right]=\left[\begin{array}{c}{1}\\ {11}\\ \end{array}\right]. $$ 

Looking ahead This chapter is going to solve n equations in n unknowns (for any n). I am not going at top speed, because smaller systems allow examples and pictures and a complete understanding. You are free to go faster, as long as matrix multiplication and inversion become clear. Those two ideas will be the keys to invertible matrices.

I can list four steps to understanding elimination using matrices.

1. Elimination goes from A to a triangular U by a sequence of matrix steps  $ E_{ij} $

2. The triangular system is solved by back substitution: working bottom to top.

3. In matrix language A is factored into  $ LU = (\text{lower triangular}) (\text{upper triangular}) $.

4. Elimination succeeds if A is invertible. (But it may need row exchanges.)

The most-used algorithm in computational science takes those steps (MATLAB calls it lu). Its quickest form is backslash: x = A \ b. But linear algebra goes beyond square invertible matrices! For m by n matrices, Ax = 0 may have many solutions. Those solutions will go into a vector space. The rank of A leads to the dimension of that vector space.

All this comes in Chapter 3, and I don’t want to hurry. But I must get there.

## Three Equations in Three Unknowns

The three unknowns are x, y, z. We have three linear equations:

 $$ Ax=b $$ 

 $$ \begin{array}{lllllll}  & &x&+&2y&+&3z&=&6\\2x&+&5y&+&2z&=&2&=\\6x&-&3y&+&z&=&2 \end{array} $$ 

We look for numbers x, y, z that solve all three equations at once. Those desired numbers might or might not exist. For this system, they do exist. When the number of unknowns matches the number of equations, in this case 3 = 3, there is usually one solution.

Before solving the problem, we visualize it both ways:

ROW The row picture shows three planes meeting at a single point.

COLUMN The column picture combines three columns to produce  $ b = (6, 4, 2) $.

In the row picture, each equation produces a plane in three-dimensional space. The first plane in Figure 2.3 comes from the first equation  $ x + 2y + 3z = 6 $. That plane crosses the x and y and z axes at the points  $ (6, 0, 0) $ and  $ (0, 3, 0) $ and  $ (0, 0, 2) $. Those three points solve the equation and they determine the whole plane.