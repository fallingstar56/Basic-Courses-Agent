6 Eigenvalues and Eigenvectors 288  
6.1 Introduction to Eigenvalues 288  
6.2 Diagonalizing a Matrix 304  
6.3 Systems of Differential Equations 319  
6.4 Symmetric Matrices 338  
6.5 Positive Definite Matrices 350  
7 The Singular Value Decomposition (SVD) 364  
7.1 Image Processing by Linear Algebra 364  
7.2 Bases and Matrices in the SVD 371  
7.3 Principal Component Analysis (PCA by the SVD) 382  
7.4 The Geometry of the SVD 392  
8 Linear Transformations 401  
8.1 The Idea of a Linear Transformation 401  
8.2 The Matrix of a Linear Transformation 411  
8.3 The Search for a Good Basis 421  
9 Complex Vectors and Matrices 430  
9.1 Complex Numbers 431  
9.2 Hermitian and Unitary Matrices 438  
9.3 The Fast Fourier Transform 445  
10 Applications 452  
10.1 Graphs and Networks 452  
10.2 Matrices in Engineering 462  
10.3 Markov Matrices, Population, and Economics 474  
10.4 Linear Programming 483  
10.5 Fourier Series: Linear Algebra for Functions 490  
10.6 Computer Graphics 496  
10.7 Linear Algebra for Cryptography 502  
11 Numerical Linear Algebra 508  
11.1 Gaussian Elimination in Practice 508  
11.2 Norms and Condition Numbers 518  
11.3 Iterative Methods and Preconditioners 524  
12 Linear Algebra in Probability & Statistics 535  
12.1 Mean, Variance, and Probability 535  
12.2 Covariance Matrices and Joint Probabilities 546  
12.3 Multivariate Gaussian and Weighted Least Squares 555  
Matrix Factorizations 563  
Index 565  
Six Great Theorems / Linear Algebra in a Nutshell 574