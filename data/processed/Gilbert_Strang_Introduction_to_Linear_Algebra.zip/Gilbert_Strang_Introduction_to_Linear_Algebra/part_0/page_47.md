## Multiplication in MATLAB

I want to express $A$ and $x$ and their product $Ax$ using MATLAB commands. This is a first step in learning that language (and others). I begin by defining $A$ and $x$. A vector $x$ in $\mathbf{R}^n$ is an $n$ by 1 matrix (as in this book). Enter matrices $a$ row at $a$ time, and use a semicolon to signal the end of a row. Or enter by columns and transpose by $^\prime$:

 $$ \begin{aligned}&A=[1\quad2\quad3;\quad2\quad5\quad2;\quad6-3\quad1]\\&x=[0\quad0\quad2]^{\prime}\quad\mathbf{or}\quad x=[0;0;2]\\ \end{aligned} $$ 

Here are three ways to multiply Ax in MATLAB. In reality,  $ A * x $ is the good way to do it. MATLAB is a high level language, and it works with matrices:

Matrix multiplication  $ b = A * x $

We can also pick out the first row of A (as a smaller matrix!). The notation for that 3 by 3 submatrix is  $ A(1,:) $. Here the colon symbol : keeps all columns of row 1.

Row at a time

 $$ \boldsymbol{b}=\left[A(1,:)*\boldsymbol{x};A(2,:)*\boldsymbol{x};A(3,:)*\boldsymbol{x}\right] $$ 

Each entry of b is a dot product, row times column, 1 by 3 matrix times 3 by 1 matrix.

The other way to multiply uses the columns of A. The first column is the 3 by 1 submatrix  $ A(:,1) $. Now the colon symbol : comes first, to keep all rows of column 1. This column multiplies  $ x(1) $ and the other columns multiply  $ x(2) $ and  $ x(3) $:

Column at a time

 $$ \boldsymbol{b}=A(:,1)*x(1)+A(:,2)*x(2)+A(:,3)*x(3) $$ 

I think that matrices are stored by columns. Then multiplying a column at a time will be a little faster. So  $ A * x $ is actually executed by columns.

## Programming Languages for Mathematics and Statistics

Here are five more important languages and their commands for the multiplication Ax :


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Julia</td><td style='text-align: center; word-wrap: break-word;'>A * x</td><td style='text-align: center; word-wrap: break-word;'>julialang.org</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Python</td><td style='text-align: center; word-wrap: break-word;'>$ \text{dot}(A, x) $</td><td style='text-align: center; word-wrap: break-word;'>python.org</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>R</td><td style='text-align: center; word-wrap: break-word;'>A % * % x</td><td style='text-align: center; word-wrap: break-word;'>r-project.org</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Mathematica</td><td style='text-align: center; word-wrap: break-word;'>A . x</td><td style='text-align: center; word-wrap: break-word;'>wolfram.com/mathematica</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Maple</td><td style='text-align: center; word-wrap: break-word;'>A * x</td><td style='text-align: center; word-wrap: break-word;'>maplesoft.com</td></tr></table>

Julia, Python, and R are free and open source languages. R is developed particularly for applications in statistics. Other software for statistics (SAS, JMP, and many more) is described on Wikipedia's Comparison of Statistical Packages.

Mathematica and Maple allow symbolic entries $a,b,x,\ldots$ and not only real numbers. As in MATLAB's Symbolic Toolbox, they work with symbolic expressions like $x^{2}-x$. The power of Mathematica is seen in Wolfram Alpha.