6. Section 6.1 explains eigenvalues for 2 by 2 matrices. Many courses want to see eigenvalues early. It is completely reasonable to come here directly from Chapter 3, because the determinant is easy for a 2 by 2 matrix. The key equation is  $ Ax = \lambda x $.

Eigenvalues and eigenvectors are an astonishing way to understand a square matrix. They are not for  $ Ax = b $, they are for dynamic equations like  $ du/dt = Au $. The idea is always the same: follow the eigenvectors. In those special directions,  $ A $ acts like a single number (the eigenvalue  $ \lambda $) and the problem is one-dimensional.

An essential highlight of Chapter 6 is diagonalizing a symmetric matrix. When all the eigenvalues are positive, the matrix is “positive definite”. This key idea connects the whole course—positive pivots and determinants and eigenvalues and energy. I work hard to reach this point in the book and to explain it by examples.

7. Chapter 7 is new. It introduces singular values and singular vectors. They separate all martices into simple pieces, ranked in order of their importance. You will see one way to compress an image. Especially you can analyze a matrix full of data.

8. Chapter 8 explains linear transformations. This is geometry without axes, algebra with no coordinates. When we choose a basis, we reach the best possible matrix.

9. Chapter 9 moves from real numbers and vectors to complex vectors and matrices. The Fourier matrix  $ F $ is the most important complex matrix we will ever see. And the Fast Fourier Transform (multiplying quickly by  $ F $ and  $ F^{-1} $) is revolutionary.

10. Chapter 10 is full of applications, more than any single course could need:

10.1 Graphs and Networks—leading to the edge-node matrix for Kirchhoff's Laws

10.2 Matrices in Engineering—differential equations parallel to matrix equations

10.3 Markov Matrices—as in Google's PageRank algorithm

10.4 Linear Programming—a new requirement  $ x \geq 0 $ and minimization of the cost

10.5 Fourier Series—linear algebra for functions and digital signal processing

10.6 Computer Graphics—matrices move and rotate and compress images

10.7 Linear Algebra in Cryptography—this new section was fun to write. The Hill Cipher is not too secure. It uses modular arithmetic: integers from 0 to  $ p - 1 $. Multiplication gives  $ 4 \times 5 \equiv 1 \pmod{19} $. For decoding this gives  $ 4^{-1} \equiv 5 $.

11. How should computing be included in a linear algebra course? It can open a new understanding of matrices—every class will find a balance. MATLAB and Maple and Mathematica are powerful in different ways. Julia and Python are free and directly accessible on the Web. Those newer languages are powerful too!

Basic commands begin in Chapter 2. Then Chapter 11 moves toward professional algorithms. You can upload and download codes for this course on the website.

12. Chapter 12 on Probability and Statistics is new, with truly important applications. When random variables are not independent we get covariance matrices. Fortunately they are symmetric positive definite. The linear algebra in Chapter 6 is needed now.