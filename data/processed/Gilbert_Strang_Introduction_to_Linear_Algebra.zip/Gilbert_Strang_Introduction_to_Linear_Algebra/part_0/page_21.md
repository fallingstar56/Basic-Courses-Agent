The dot product of  $  \boldsymbol{v} = (1, 2)  $ and  $  \boldsymbol{w} = (3, 1)  $ is 5. Soon  $  \boldsymbol{v} \cdot \boldsymbol{w}  $ will reveal the angle between  $  \boldsymbol{v}  $ and  $  \boldsymbol{w}  $ (not  $ 90^\circ $). Please check that  $  \boldsymbol{w} \cdot \boldsymbol{v}  $ is also 5.

The dot product  $ w \cdot v $ equals  $ v \cdot w $. The order of  $ v $ and  $ w $ makes no difference.

Example 2 Put a weight of 4 at the point  $ x = -1 $ (left of zero) and a weight of 2 at the point  $ x = 2 $ (right of zero). The  $ x $ axis will balance on the center point (like a see-saw). The weights balance because the dot product is  $ (4)(-1) + (2)(2) = 0 $.

This example is typical of engineering and science. The vector of weights is  $ (w_1, w_2) = (4, 2) $. The vector of distances from the center is  $ (v_1, v_2) = (-1, 2) $. The weights times the distances,  $ w_1 v_1 $ and  $ w_2 v_2 $, give the “moments”. The equation for the see-saw to balance is  $ w_1 v_1 + w_2 v_2 = 0 $.

Example 3 Dot products enter in economics and business. We have three goods to buy and sell. Their prices are  $ (p_1, p_2, p_3) $ for each unit—this is the “price vector” p. The quantities we buy or sell are  $ (q_1, q_2, q_3) $—positive when we sell, negative when we buy. Selling  $ q_1 $ units at the price  $ p_1 $ brings in  $ q_1 p_1 $. The total income (quantities q times prices p) is the dot product  $ q \cdot p $ in three dimensions:

 $$  Income=\left(q_{1},q_{2},q_{3}\right)\cdot\left(p_{1},p_{2},p_{3}\right)=q_{1}p_{1}+q_{2}p_{2}+q_{3}p_{3}=dot product. $$ 

A zero dot product means that “the books balance”. Total sales equal total purchases if  $ q \cdot p = 0 $. Then p is perpendicular to q (in three-dimensional space). A supermarket with thousands of goods goes quickly into high dimensions.

Small note: Spreadsheets have become essential in management. They compute linear combinations and dot products. What you see on the screen is a matrix.

Main point For v · w, multiply each vᵢ times wᵢ. Then v · w = v₁w₁ + ⋯ + vₙwₙ.

## Lengths and Unit Vectors

An important case is the dot product of a vector with itself. In this case  $ v $ equals  $ w $. When the vector is  $ v = (1, 2, 3) $, the dot product with itself is  $ v \cdot v = \|v\|^2 = 14 $:

Dot product  $ v \cdot v $

Length squared

 $$ \|\boldsymbol{v}\|^{2}=\begin{bmatrix}1\\ 2\\ 3\end{bmatrix}\cdot\begin{bmatrix}1\\ 2\\ 3\end{bmatrix}=1+4+9=14. $$ 

Instead of a 90° angle between vectors we have 0°. The answer is not zero because v is not perpendicular to itself. The dot product v · v gives the length of v squared.

DEFINITION The length  $ \|v\| $ of a vector v is the square root of  $ v \cdot v $:

 $$ \mathbf{l e n g t h~}=\|\mathbf{v}\|=\sqrt{\mathbf{v}\cdot\mathbf{v}}=\left(v_{1}^{2}+v_{2}^{2}+\cdots+v_{n}^{2}\right)^{1/2}. $$ 