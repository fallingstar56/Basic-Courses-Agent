 $ \cos^2\theta + \sin^2\theta = 1 $. These vectors reach out to the unit circle in Figure 1.7. Thus  $ \cos\theta $ and  $ \sin\theta $ are simply the coordinates of that point at angle  $ \theta $ on the unit circle.

Since  $ (2,2,1) $ has length 3, the vector  $ \left(\frac{2}{3},\frac{2}{3},\frac{1}{3}\right) $ has length 1. Check that  $ u \cdot u = \frac{4}{9} + \frac{4}{9} + \frac{1}{9} = 1 $. For a unit vector, divide any nonzero vector v by its length  $ \|v\| $.

Unit vector

u = v / \|v\| is a unit vector in the same direction as v.



<div style="text-align: center;"><img src="imgs/img_in_image_box_192_310_893_519.jpg" alt="Image" width="65%" /></div>


<div style="text-align: center;">Figure 1.7: The coordinate vectors  $ i $ and  $ j $. The unit vector  $ \boldsymbol{u} $ at angle  $ 45^\circ $ (left) divides  $ \boldsymbol{v} = (1, 1) $ by its length  $ \|\boldsymbol{v}\| = \sqrt{2} $. The unit vector  $ \boldsymbol{u} = (\cos\theta, \sin\theta) $ is at angle  $ \theta $.</div>


The Angle Between Two Vectors

We stated that perpendicular vectors have  $  \boldsymbol{v} \cdot \boldsymbol{w} = 0  $. The dot product is zero when the angle is  $ 90^\circ $. To explain this, we have to connect angles to dot products. Then we show how  $  \boldsymbol{v} \cdot \boldsymbol{w}  $ finds the angle between any two nonzero vectors  $  \boldsymbol{v}  $ and  $  \boldsymbol{w}  $.

Right angles

The dot product is  $ v \cdot w = 0 $ when v is perpendicular to w



Proof When $v$ and $w$ are perpendicular, they form two sides of a right triangle. The third side is $v - w$ (the hypotenuse going across in Figure 1.8). The Pythagoras Law for the sides of a right triangle is $a^2 + b^2 = c^2$.

Perpendicular vectors

 $$ \left\| \mathbf{v} \right\|^{2}+\left\| \mathbf{w} \right\|^{2}=\left\| \mathbf{v}-\mathbf{w} \right\|^{2} $$ 

Writing out the formulas for those lengths in two dimensions, this equation is

Pythagoras

 $$ \left(v_{1}^{2}+v_{2}^{2}\right)+\left(w_{1}^{2}+w_{2}^{2}\right)=\left(v_{1}-w_{1}\right)^{2}+\left(v_{2}-w_{2}\right)^{2}. $$ 

The right side begins with  $ v_1^2 - 2v_1w_1 + w_1^2 $. Then  $ v_1^2 $ and  $ w_1^2 $ are on both sides of the equation and they cancel, leaving  $ -2v_1w_1 $. Also  $ v_2^2 $ and  $ w_2^2 $ cancel, leaving  $ -2v_2w_2 $. (In three dimensions there would be  $ -2v_3w_3 $.) Now divide by -2 to see  $ v - w = 0 $:

 $$ 0=-2v_{1}w_{1}-2v_{2}w_{2}\quad which leads to\quad v_{1}w_{1}+v_{2}w_{2}=0. $$ 

Conclusion Right angles produce  $ v \cdot w = 0 $. The dot product is zero when the angle is  $ \theta = 90^\circ $. Then  $ \cos\theta = 0 $. The zero vector  $ v = 0 $ is perpendicular to every vector  $ w $ because  $ 0 \cdot w $ is always zero.