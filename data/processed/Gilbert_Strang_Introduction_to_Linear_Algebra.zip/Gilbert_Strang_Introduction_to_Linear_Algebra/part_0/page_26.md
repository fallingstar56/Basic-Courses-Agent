MATLAB

 $$ \boldsymbol{v}=\begin{bmatrix}2&3&4\end{bmatrix}^{\prime}\quad;\quad\boldsymbol{w}=\begin{bmatrix}1&1&1\end{bmatrix}^{\prime}\quad;\quad\boldsymbol{u}=2*\boldsymbol{v}+3*\boldsymbol{w} $$ 

The dot product v · w is a row vector times a column vector (use * instead of ·):

Instead of

 $$ \begin{bmatrix}1\\ 2\end{bmatrix}\cdot\begin{bmatrix}3\\ 4\end{bmatrix} $$ 

we more often see

 $$ \left[1\ 2\right]\begin{bmatrix}3\\ 4\end{bmatrix} $$ 

The length of v is known to MATLAB as norm(v). This is  $ \sqrt{v' * v} $. Then find the cosine from the dot product  $ v' * w $ and the angle (in radians) that has that cosine:

Cosine formula

The arc cosine

 $$ \begin{array}{l} \text{cosine} = v^{\prime} * w / (\text{norm}(v) * \text{norm}(w)) \\ \text{angle} = \text{acos}(cosine) \end{array} $$ 

An M-file would create a new function cosine(v, w). Python and Julia are open source.

## ■ REVIEW OF THE KEY IDEAS

1. The dot product  $ v \cdot w $ multiplies each component  $ v_i $ by  $ w_i $ and adds all  $ v_i w_i $.

2. The length  $ \|v\| $ is the square root of  $ v \cdot v $. Then  $ u = v / \|v\| $ is a unit vector: length 1.

3. The dot product is  $ v \cdot w = 0 $ when vectors v and w are perpendicular.

4. The cosine of  $ \theta $ (the angle between any nonzero v and w) never exceeds 1:

Cosine

 $$ \cos\theta=\frac{v\cdot w}{\left\|v\right\|\left\|w\right\|} $$ 

Schwarz inequality

 $$ |v\cdot w|\leq\|v\|\|w\|. $$ 

## WORKED EXAMPLES

1.2 A For the vectors  $ v = (3, 4) $ and  $ w = (4, 3) $ test the Schwarz inequality on  $ v \cdot w $ and the triangle inequality on  $ \|v + w\| $. Find  $ \cos \theta $ for the angle between  $ v $ and  $ w $. Which  $ v $ and  $ w $ give equality  $ |v \cdot w| = \|v\| $ and  $ \|w\| $ and  $ \|v + w\| = \|v\| + \|w\| $?

Solution The dot product is  $ \boldsymbol{v} \cdot \boldsymbol{w} = (3)(4) + (4)(3) = 24 $. The length of  $ \boldsymbol{v} $ is  $ \|\boldsymbol{v}\| = \sqrt{9 + 16} = 5 $ and also  $ \|\boldsymbol{w}\| = 5 $. The sum  $ \boldsymbol{v} + \boldsymbol{w} = (7, 7) $ has length  $ 7\sqrt{2} < 10 $.

Schwarz inequality

 $$ \left|v\cdot w\right|\leq\left\|v\right\|\left\|w\right\|\quad is\quad24<25. $$ 

Triangle inequality

 $$ \left\| \mathbf{v}+\mathbf{w} \right\|\leq \left\| \mathbf{v} \right\|+\left\| \mathbf{w} \right\| \quad is \quad 7\sqrt{2}<5+5. $$ 

Cosine of angle

 $$ \cos\theta=\frac{24}{25}\quad\mathrm{Thin~angle~from~}\boldsymbol{v}=(3,4)\mathrm{to}\boldsymbol{w}=(4,3) $$ 

Equality: One vector is a multiple of the other as in  $ w = cv $. Then the angle is  $ 0^\circ $ or  $ 180^\circ $. In this case  $ |\cos\theta| = 1 $ and  $ |v \cdot w| $ equals  $ \|v\| $  $ \|w\| $. If the angle is  $ 0^\circ $, as in  $ w = 2v $, then  $ \|v + w\| = \|v\| + \|w\| $ (both sides give  $ 3\|v\| $). This  $ v, 2v, 3v $ triangle is flat!