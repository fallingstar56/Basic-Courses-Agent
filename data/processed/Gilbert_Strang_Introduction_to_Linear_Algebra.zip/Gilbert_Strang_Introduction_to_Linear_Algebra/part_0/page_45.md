<div style="text-align: center;"><img src="imgs/img_in_image_box_304_123_786_416.jpg" alt="Image" width="45%" /></div>


<div style="text-align: center;">Figure 2.4: Column picture: Combine the columns with weights  $ (x, y, z) = (0, 0, 2) $.</div>


## The Matrix Form of the Equations

We have three rows in the row picture and three columns in the column picture (plus the right side). The three rows and three columns contain nine numbers. These nine numbers fill a 3 by 3 matrix A:

 $$ \begin{aligned}The\text{“coefficient matrix”in}Ax&=b is\quad A=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{5}}}&{{{2}}} \\{{{6}}}&{{{-3}}}&{{{1}}}\end{bmatrix}.\end{aligned} $$ 

The capital letter A stands for all nine coefficients (in this square array). The letter b denotes the column vector with components 6, 4, 2. The unknown x is also a column vector, with components x, y, z. (We use boldface because it is a vector, x because it is unknown.) By rows the equations were (3), by columns they were (4), and by matrices they are (5):

Matrix equation

 $$ \boldsymbol{A}\boldsymbol{x}=\boldsymbol{b}\quad\left[\begin{array}{ccc}{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{5}}}&{{{2}}} \\{{{6}}}&{{{-3}}}&{{{1}}}\end{array}\right]\left[\begin{array}{c}{{{x}}} \\{{{y}}} \\{{{z}}}\end{array}\right]=\left[\begin{array}{c}{{{6}}} \\{{{4}}} \\{{{2}}}\end{array}\right]. $$ 

Basic question: What does it mean to “multiply A times x”? We can multiply by rows or by columns. Either way, Ax = b must be a correct statement of the three equations. You do the same nine multiplications either way.

Multiplication by rows

Ax comes from dot products, each row times the column x:



 $$ \boldsymbol{A}\boldsymbol{x}=\left[\begin{array}{c}(\boldsymbol{r o w}\boldsymbol{1})\cdot\boldsymbol{x}\\ (\boldsymbol{r o w}\boldsymbol{2})\cdot\boldsymbol{x}\\ (\boldsymbol{r o w}\boldsymbol{3})\cdot\boldsymbol{x}\end{array}\right]. $$ 