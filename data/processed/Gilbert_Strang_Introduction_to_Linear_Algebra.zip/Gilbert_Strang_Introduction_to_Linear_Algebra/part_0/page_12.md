## Linear Combinations

Now we combine addition with scalar multiplication to produce a “linear combination” of v and w. Multiply v by c and multiply w by d. Then add cv + dw.

The sum of cv and dw is a linear combination cv + dw.

Four special linear combinations are: sum, difference, zero, and a scalar multiple cv:

 $$ \begin{array}{r l r}{1v+1w}&{{}=}&{\mathrm{s u m~o f~v e c t o r s~i n~F i g u r e~1.1a~}}\end{array} $$ 

 $$ \begin{array}{r l r}{1v-1w}&{{}=}&{\mathrm{d i f f e r e n c e~o f~v e c t o r s~i n~F i g u r e~1.1b}}\end{array} $$ 

 $$ \begin{array}{r l r}{0v+0w}&{{}=}&{z e r o~v e c t o r}\end{array} $$ 

 $$ \begin{array}{r l r}{c v+0w}&{{}=}&{\mathrm{v e c t o r}c v\mathrm{i n~t h e~d i r e c t i o n~o f~}v}\end{array} $$ 

The zero vector is always a possible combination (its coefficients are zero). Every time we see a “space” of vectors, that zero vector will be included. This big view, taking all the combinations of v and w, is linear algebra at work.

The figures show how you can visualize vectors. For algebra, we just need the components (like 4 and 2). That vector v is represented by an arrow. The arrow goes  $ v_1 = 4 $ units to the right and  $ v_2 = 2 $ units up. It ends at the point whose x, y coordinates are 4, 2. This point is another representation of the vector—so we have three ways to describe v:

Point in the plane

We add using the numbers. We visualize  $ v + w $ using arrows:

Vector addition (head to tail) At the end of v, place the start of w.

<div style="text-align: center;"><img src="imgs/img_in_image_box_154_804_495_961.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_529_786_870_980.jpg" alt="Image" width="31%" /></div>


 $$ v+w=\begin{bmatrix}4\\ 2\end{bmatrix}+\begin{bmatrix}-1\\ 2\end{bmatrix}=\begin{bmatrix}3\\ 4\end{bmatrix} $$ 

 $$ v-w=\begin{bmatrix}4\\ 2\end{bmatrix}-\begin{bmatrix}-1\\ 2\end{bmatrix}=\begin{bmatrix}5\\ 0\end{bmatrix} $$ 

Figure 1.1: Vector addition  $ v + w = (3, 4) $ produces the diagonal of a parallelogram. The reverse of w is -w. The linear combination on the right is  $ v - w = (5, 0) $.

We travel along v and then along w. Or we take the diagonal shortcut along  $ v + w $. We could also go along w and then v. In other words,  $ w + v $ gives the same answer as  $ v + w $. These are different ways along the parallelogram (in this example it is a rectangle).