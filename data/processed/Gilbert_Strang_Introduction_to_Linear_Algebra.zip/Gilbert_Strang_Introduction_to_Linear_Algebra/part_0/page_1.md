Introduction to Linear Algebra, 5th Edition

Copyright ©2016 by Gilbert Strang

ISBN 978-0-9802327-7-6

All rights reserved. No part of this book may be reproduced or stored or transmitted by any means, including photocopying, without written permission from Wellesley - Cambridge Press. Translation in any language is strictly prohibited — authorized translations are arranged by the publisher.

BTEX typesetting by Ashley C. Fernandes (info@problemsolvingpathway.com)

Printed in the United States of America

QA184.S78 2016 512'5 93-14092

9876543

Other texts from Wellesley - Cambridge Press

Computational Science and Engineering, Gilbert Strang ISBN 978-0-9614088-1-7

Wavelets and Filter Banks, Gilbert Strang and Truong Nguyen ISBN 978-0-9614088-7-9

Introduction to Applied Mathematics, Gilbert Strang ISBN 978-0-9614088-0-0

Calculus Third Edition (2017), Gilbert Strang ISBN 978-0-9802327-5-2

Algorithms for Global Positioning, Kai Borre & Gilbert Strang ISBN 978-0-9802327-3-8

Essays in Linear Algebra, Gilbert Strang ISBN 978-0-9802327-6-9

Differential Equations and Linear Algebra, Gilbert Strang ISBN 978-0-9802327-9-0

An Analysis of the Finite Element Method, 2008 edition, Gilbert Strang and George Fix ISBN 978-0-9802327-0-7

Wellesley - Cambridge Press

Box 812060

Wellesley MA 02482 USA

www.wellesleycambridge.com

linearalgebrabook@gmail.com

math.mit.edu/~gs

phone (781) 431-8488

fax (617) 253-4358

The website for this book is math.mit.edu/linearalgebra.

The Solution Manual can be printed from that website.

Course material including syllabus and exams and also videotaped lectures are available on the book website and the teaching website: web.mit.edu/18.06

Linear Algebra is included in MIT's OpenCourseWare site ocw.mit.edu. This provides video lectures of the full linear algebra course 18.06 and 18.06 SC. MATLAB® is a registered trademark of The MathWorks, Inc.

The front cover captures a central idea of linear algebra.

 $ Ax = b $ is solvable when  $ b $ is in the (red) column space of  $ A $.

One particular solution y is in the (yellow) row space:  $ Ay = b $.

Add any vector z from the (green) nullspace of A: Az = 0.

The complete solution is  $ x = y + z $. Then  $ Ax = Ay + Az = b $.

The cover design was the inspiration of Lois Sellers and Gail Corbett.