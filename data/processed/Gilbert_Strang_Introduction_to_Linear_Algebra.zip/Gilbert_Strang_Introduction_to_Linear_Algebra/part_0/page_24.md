Now suppose  $ v \cdot w $ is not zero. It may be positive, it may be negative. The sign of  $ v \cdot w $ immediately tells whether we are below or above a right angle. The angle is less than  $ 90^\circ $ when  $ v \cdot w $ is positive. The angle is above  $ 90^\circ $ when  $ v \cdot w $ is negative. The right side of Figure 1.8 shows a typical vector  $ v = (3, 1) $. The angle with  $ w = (1, 3) $ is less than  $ 90^\circ $ because  $ v \cdot w = 6 $ is positive.

<div style="text-align: center;"><img src="imgs/img_in_image_box_168_250_870_425.jpg" alt="Image" width="65%" /></div>


<div style="text-align: center;">Figure 1.8: Perpendicular vectors have  $ v \cdot w = 0 $. Then  $ \|v\|^2 + \|w\|^2 = \|v - w\|^2 $.</div>


The borderline is where vectors are perpendicular to v. On that dividing line between plus and minus,  $ (1, -3) $ is perpendicular to  $ (3, 1) $. The dot product is zero.

The dot product reveals the exact angle  $ \theta $. For unit vectors  $ u $ and  $ U $, the sign of  $ u \cdot U $ tells whether  $ \theta < 90^\circ $ or  $ \theta > 90^\circ $. More than that, the dot product  $ u \cdot U $ is the cosine of  $ \theta $. This remains true in  $ n $ dimensions.

Unit vectors u and U at angle  $ \theta $ have  $ u \cdot U = \cos \theta $. Certainly  $ |u \cdot U| \leq 1 $.

Remember that  $ \cos\theta $ is never greater than 1. It is never less than -1. The dot product of unit vectors is between -1 and 1. The cosine of  $ \theta $ is revealed by  $ u \cdot U $.

Figure 1.9 shows this clearly when the vectors are  $ \boldsymbol{u} = (\cos\theta, \sin\theta) $ and  $ \boldsymbol{i} = (1, 0) $. The dot product is  $ \boldsymbol{u} \cdot \boldsymbol{i} = \cos\theta $. That is the cosine of the angle between them.

After rotation through any angle  $ \alpha $, these are still unit vectors. The vector  $ \boldsymbol{i} = (1, 0) $ rotates to  $ (\cos \alpha, \sin \alpha) $. The vector  $ \boldsymbol{u} $ rotates to  $ (\cos \beta, \sin \beta) $ with  $ \beta = \alpha + \theta $. Their dot product is  $ \cos \alpha \cos \beta + \sin \alpha \sin \beta $. From trigonometry this is  $ \cos(\beta - \alpha) = \cos \theta $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_232_855_862_1046.jpg" alt="Image" width="59%" /></div>


<div style="text-align: center;">Figure 1.9: Unit vectors:  $ u \cdot U $ is the cosine of  $ \theta $ (the angle between).</div>
