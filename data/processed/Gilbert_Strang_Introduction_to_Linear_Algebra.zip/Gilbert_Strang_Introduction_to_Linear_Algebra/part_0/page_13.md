## Vectors in Three Dimensions

A vector with two components corresponds to a point in the xy plane. The components of v are the coordinates of the point:  $ x = v_1 $ and  $ y = v_2 $. The arrow ends at this point  $ (v_1, v_2) $, when it starts from  $ (0, 0) $. Now we allow vectors to have three components  $ (v_1, v_2, v_3) $.

The xy plane is replaced by three-dimensional xyz space. Here are typical vectors (still column vectors but with three components):

 $$ \boldsymbol{v}=\begin{bmatrix}1\\ 1\\ -1\end{bmatrix}\quad and\quad\boldsymbol{w}=\begin{bmatrix}2\\ 3\\ 4\end{bmatrix}\quad and\quad\boldsymbol{v}+\boldsymbol{w}=\begin{bmatrix}3\\ 4\\ 3\end{bmatrix}。 $$ 

The vector v corresponds to an arrow in 3-space. Usually the arrow starts at the “origin”, where the xyz axes meet and the coordinates are  $ (0,0,0) $. The arrow ends at the point with coordinates  $ v_{1} $,  $ v_{2} $,  $ v_{3} $. There is a perfect match between the column vector and the arrow from the origin and the point where the arrow ends.

The vector  $ (x, y) $ in the plane is different from  $ (x, y, 0) $ in 3-space!

<div style="text-align: center;"><img src="imgs/img_in_image_box_257_574_496_752.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_583_543_803_773.jpg" alt="Image" width="20%" /></div>


Figure 1.2: Vectors  $ \begin{bmatrix} x \\ y \end{bmatrix} $ and  $ \begin{bmatrix} x \\ y \\ z \end{bmatrix} $ correspond to points  $ (x, y) $ and  $ (x, y, z) $.

From now on  $ v = \begin{bmatrix} 1 \\ 1 \\ -1 \end{bmatrix} $ is also written as  $ v = (1, 1, -1) $.

The reason for the row form (in parentheses) is to save space. But  $ v = (1, 1, -1) $ is not a row vector! It is in actuality a column vector, just temporarily lying down. The row vector  $ [1 \quad 1 \quad -1] $ is absolutely different, even though it has the same three components. That 1 by 3 row vector is the “transpose” of the 3 by 1 column vector v.