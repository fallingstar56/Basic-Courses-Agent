6 (a) Describe every vector  $ \boldsymbol{w} = (w_{1}, w_{2}) $ that is perpendicular to  $ \boldsymbol{v} = (2, -1) $.

(b) All vectors perpendicular to  $ V = (1, 1, 1) $ lie on a ___ in 3 dimensions.

(c) The vectors perpendicular to both  $ (1,1,1) $ and  $ (1,2,3) $ lie on a ___.

7 Find the angle  $ \theta $ (from its cosine) between these pairs of vectors:

(a)

 $$ v=\begin{bmatrix}1\\ \sqrt{3}\end{bmatrix}\quad and\quad w=\begin{bmatrix}1\\ 0\end{bmatrix} $$ 

 $$ \boldsymbol{v}=\begin{bmatrix}2\\ 2\\ -1\end{bmatrix}\quad and\quad\boldsymbol{w}=\begin{bmatrix}2\\ -1\\ 2\end{bmatrix} $$ 

(c)

 $$ \left(\mathrm{d}\right)\quad v=\begin{bmatrix}3\\ 1\end{bmatrix}\quad and\quad w=\begin{bmatrix}-1\\ -2\end{bmatrix}. $$ 

8 True or false (give a reason if true or find a counterexample if false):

(a) If  $ u = (1, 1, 1) $ is perpendicular to v and w, then v is parallel to w.

(b) If u is perpendicular to v and w, then u is perpendicular to v + 2w.

(c) If  $ u $ and  $ v $ are perpendicular unit vectors then  $ \|u - v\| = \sqrt{2} $. Yes!

9 The slopes of the arrows from  $ (0,0) $ to  $ (v_1,v_2) $ and  $ (w_1,w_2) $ are  $ v_2/v_1 $ and  $ w_2/w_1 $. Suppose the product  $ v_2w_2/v_1w_1 $ of those slopes is -1. Show that  $ v \cdot w = 0 $ and the vectors are perpendicular. (The line  $ y = 4x $ is perpendicular to  $ y = -\frac{1}{4}x $.)

10 Draw arrows from  $ (0,0) $ to the points  $ v = (1,2) $ and  $ w = (-2,1) $. Multiply their slopes. That answer is a signal that  $ v \cdot w = 0 $ and the arrows are ___.

If $v \cdot w$ is negative, what does this say about the angle between $v$ and $w$? Draw a 3-dimensional vector $v$ (an arrow), and show where to find all $w$'s with $v \cdot w < 0$.

With $v = (1, 1)$ and $w = (1, 5)$ choose a number $c$ so that $w - cv$ is perpendicular to $v$. Then find the formula for $c$ starting from any nonzero $v$ and $w$.

Find nonzero vectors v and w that are perpendicular to  $ (1,0,1) $ and to each other.

Find nonzero vectors u, v, w that are perpendicular to  $ (1, 1, 1, 1) $ and to each other.

The geometric mean of $x = 2$ and $y = 8$ is $\sqrt{xy} = 4$. The arithmetic mean is larger: $\frac{1}{2}(x + y) = \underline{\qquad}$. This would come in Example 6 from the Schwarz inequality for $w = (\sqrt{2}, \sqrt{8})$ and $w = (\sqrt{8}, \sqrt{2})$. Find $\cos\theta$ for this $v$ and $w$.

16 How long is the vector  $ v = (1, 1, \ldots, 1) $ in 9 dimensions? Find a unit vector  $ u $ in the same direction as  $ v $ and a unit vector  $ w $ that is perpendicular to  $ v $.

17 What are the cosines of the angles  $ \alpha, \beta, \theta $ between the vector  $ (1, 0, -1) $ and the unit vectors  $ i, j, k $ along the axes? Check the formula  $ \cos^2 \alpha + \cos^2 \beta + \cos^2 \theta = 1 $.