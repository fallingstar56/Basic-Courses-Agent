matrix is multiplying those numbers. The matrix A acts on the vector x. The output Ax is a combination b of the columns of A.

To see that action, I will write  $ b_{1}, b_{2}, b_{3} $ for the components of Ax:

 $$ \boldsymbol{A}\boldsymbol{x}=\left[\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}-x_{1}}}} \\{{{x_{3}-x_{2}}}}\end{array}\right]=\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{array}\right]=\boldsymbol{b}. $$ 

The input is x and the output is b = Ax. This A is a “difference matrix” because b contains differences of the input vector x. The top difference is  $ x_1 - x_0 = x_1 - 0 $.

Here is an example to show differences of x = (1, 4, 9): squares in x, odd numbers in b.

 $$ \boldsymbol{x}=\begin{bmatrix}1\\ 4\\ 9\end{bmatrix}=squares\quad\boldsymbol{A}\boldsymbol{x}=\begin{bmatrix}1-0\\ 4-1\\ 9-4\end{bmatrix}=\begin{bmatrix}1\\ 3\\ 5\end{bmatrix}=\boldsymbol{b}． $$ 

That pattern would continue for a 4 by 4 difference matrix. The next square would be  $ x_4 = 16 $. The next difference would be  $ x_4 - x_3 = 16 - 9 = 7 $ (the next odd number). The matrix finds all the differences 1, 3, 5, 7 at once.

Important Note: Multiplication a row at a time. You may already have learned about multiplying Ax, a matrix times a vector. Probably it was explained differently, using the rows instead of the columns. The usual way takes the dot product of each row with x:

Ax is also

dot products

with rows

 $$ \boldsymbol{A}\boldsymbol{x}=\left[\begin{array}{r r r}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{\left(1,0,0\right)\bullet\left(x_{1},x_{2},x_{3}\right)}}} \\{{{\left(-1,1,0\right)\bullet\left(x_{1},x_{2},x_{3}\right)}}} \\{{{\left(0,-1,1\right)\bullet\left(x_{1},x_{2},x_{3}\right)}}}\end{array}\right]. $$ 

Those dot products are the same  $ x_1 $ and  $ x_2 - x_1 $ and  $ x_3 - x_2 $ that we wrote in equation (3). The new way is to work with  $ Ax $ a column at a time. Linear combinations are the key to linear algebra, and the output  $ Ax $ is a linear combination of the columns of  $ A $.

With numbers, you can multiply  $ A \times $ by rows. With letters, columns are the good way. Chapter 2 will repeat these rules of matrix multiplication, and explain the ideas.

Linear Equations

One more change in viewpoint is crucial. Up to now, the numbers  $ x_{1}, x_{2}, x_{3} $ were known. The right hand side b was not known. We found that vector of differences by multiplying A times x. Now we think of b as known and we look for x.

Old question: Compute the linear combination  $ x_1u + x_2v + x_3w $ to find b.

New question: Which combination of u, v, w produces a particular vector b?

This is the inverse problem—to find the input x that gives the desired output b = Ax. You have seen this before, as a system of linear equations for  $ x_1, x_2, x_3 $. The right hand sides of the equations are  $ b_1, b_2, b_3 $. I will now solve that system  $ Ax = b $ to find  $ x_1, x_2, x_3 $: