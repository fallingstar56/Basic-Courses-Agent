## Chapter 1

## Introduction to Vectors

The heart of linear algebra is in two operations—both with vectors. We add vectors to get  $ v + w $. We multiply them by numbers c and d to get cv and dw. Combining those two operations (adding cv to dw) gives the linear combination cv + dw.

Linear combination

 $$ c\boldsymbol{v}+d\boldsymbol{w}=c\left[\begin{array}{l}1\\ 1\end{array}\right]+d\left[\begin{array}{l}2\\ 3\end{array}\right]=\left[\begin{array}{l}c+2d\\ c+3d\end{array}\right] $$ 

Example  $ v + w = \left[\begin{array}{c} 1 \\ 1 \end{array}\right] + \left[\begin{array}{c} 2 \\ 3 \end{array}\right] = \left[\begin{array}{c} 3 \\ 4 \end{array}\right] $ is the combination with c = d = 1

Linear combinations are all-important in this subject! Sometimes we want one particular combination, the specific choice $c = 2$ and $d = 1$ that produces $cv + dw = (4, 5)$. Other times we want all the combinations of $v$ and $w$ (coming from all $c$ and $d$).

The vectors  $ cv $ lie along a line. When  $ w $ is not on that line, the combinations  $ cv + dw $ fill the whole two-dimensional plane. Starting from four vectors  $ u, v, w, z $ in four-dimensional space, their combinations  $ cu + dv + ew + fz $ are likely to fill the space—but not always. The vectors and their combinations could lie in a plane or on a line.

Chapter 1 explains these central ideas, on which everything builds. We start with two-dimensional vectors and three-dimensional vectors, which are reasonable to draw. Then we move into higher dimensions. The really impressive feature of linear algebra is how smoothly it takes that step into n-dimensional space. Your mental picture stays completely correct, even if drawing a ten-dimensional vector is impossible.

This is where the book is going (into n-dimensional space). The first steps are the operations in Sections 1.1 and 1.2. Then Section 1.3 outlines three fundamental ideas.

1.1 Vector addition v + w and linear combinations cv + dw.

1.2 The dot product  $ v \cdot w $ of two vectors and the length  $ \|v\| = \sqrt{v \cdot v} $.

1.3 Matrices A, linear equations Ax = b, solutions x = A^{-1}b.