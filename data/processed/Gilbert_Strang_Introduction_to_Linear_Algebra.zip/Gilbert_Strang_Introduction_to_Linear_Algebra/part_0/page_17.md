### Problem Set 1.1

Problems 1–9 are about addition of vectors and linear combinations.

1 Describe geometrically (line, plane, or all of  $ R^{3} $) all linear combinations of

(a)

 $$ \begin{bmatrix}1\\ 2\\ 3\end{bmatrix}and\begin{bmatrix}3\\ 6\\ 9\end{bmatrix} $$ 

(b)

 $$ \begin{bmatrix}1\\ 0\\ 0\end{bmatrix}and\begin{bmatrix}0\\ 2\\ 3\end{bmatrix} $$ 

(c)

 $$ \begin{bmatrix}2\\ 0\\ 0\end{bmatrix}and\begin{bmatrix}0\\ 2\\ 2\end{bmatrix}and\begin{bmatrix}2\\ 2\\ 3\end{bmatrix} $$ 

2 Draw  $ v=\begin{bmatrix} 4 \\ 1 \end{bmatrix} $ and  $ w=\begin{bmatrix} -2 \\ 2 \end{bmatrix} $ and  $ v+w $ and  $ v-w $ in a single xy plane.

If  $ v + w = \begin{bmatrix} 5 \\ 1 \end{bmatrix} $ and  $ v - w = \begin{bmatrix} 1 \\ 5 \end{bmatrix} $, compute and draw the vectors v and w.

From  $ v = \begin{bmatrix} 2 \\ 1 \end{bmatrix} $ and  $ w = \begin{bmatrix} 1 \\ 2 \end{bmatrix} $, find the components of  $ 3v + w $ and  $ cv + dw $.

5 Compute  $ u + v + w $ and  $ 2u + 2v + w $. How do you know u, v, w lie in a plane?

These lie in a plane because  $ w = cu + dv $. Find c and d

 $$ \boldsymbol{u}=\begin{bmatrix}1\\ 2\\ 3\end{bmatrix},\quad\boldsymbol{v}=\begin{bmatrix}-3\\ 1\\ -2\end{bmatrix},\quad\boldsymbol{w}=\begin{bmatrix}2\\ -3\\ -1\end{bmatrix}. $$ 

6 Every combination of  $ v = (1, -2, 1) $ and  $ w = (0, 1, -1) $ has components that add to ___. Find c and d so that  $ cv + dw = (3, 3, -6) $. Why is  $ (3, 3, 6) $ impossible?

7 In the xy plane mark all nine of these linear combinations:

 $$ c\begin{bmatrix}2\\ 1\end{bmatrix}+d\begin{bmatrix}0\\ 1\end{bmatrix}\quad with\quad c=0,1,2\quad and\quad d=0,1,2. $$ 

8 The parallelogram in Figure 1.1 has diagonal  $ v + w $. What is its other diagonal? What is the sum of the two diagonals? Draw that vector sum.

9 If three corners of a parallelogram are  $ (1,1) $,  $ (4,2) $, and  $ (1,3) $, what are all three of the possible fourth corners? Draw two of them.

Problems 10–14 are about special vectors on cubes and clocks in Figure 1.4.

10 Which point of the cube is  $ i + j $? Which point is the vector sum of  $ i = (1, 0, 0) $ and  $ j = (0, 1, 0) $ and  $ k = (0, 0, 1) $? Describe all points  $ (x, y, z) $ in the cube.

11 Four corners of this unit cube are  $ (0,0,0) $,  $ (1,0,0) $,  $ (0,1,0) $,  $ (0,0,1) $. What are the other four corners? Find the coordinates of the center point of the cube. The center points of the six faces are ___. The cube has how many edges?

12 Review Question. In xyz space, where is the plane of all linear combinations of  $ i = (1, 0, 0) $ and  $ i + j = (1, 1, 0) $?