# Chapter 2

# Solving Linear Equations

### 2.1 Vectors and Linear Equations

1 The column picture of  $ Ax = b $: a combination of  $ n $ columns of  $ A $ produces the vector  $ \mathbf{b} $.

2 This is a vector equation  $ Ax = x_1a_1 + \cdots + x_na_n = b $: the columns of  $ A $ are  $ a_1, a_2, \ldots, a_n $.

3 When  $ b = 0 $, a combination  $ Ax $ of the columns is zero: one possibility is  $ \mathbf{x} = (0, \ldots, 0) $.

4 The row picture of  $ Ax = b $:  $ m $ equations from  $ m $ rows give  $ m $ planes meeting at  $ \mathbf{x} $.

5 A dot product gives the equation of each plane:  $ (\mathbf{row} \mathbf{1}) \cdot \mathbf{x} = b_1, \ldots, (\mathbf{row} \mathbf{m}) \cdot \mathbf{x} = b_m $.

6 When  $ b = 0 $, all the planes  $ (\mathbf{row} \mathbf{i}) \cdot \mathbf{x} = 0 $ go through the center point  $ \mathbf{x} = (0, 0, \ldots, 0) $.

The central problem of linear algebra is to solve a system of equations. Those equations are linear, which means that the unknowns are only multiplied by numbers—we never see x times y. Our first linear system is small. But you will see how far it leads:

Two equations

Two unknowns

 $$ \begin{array}{lllll}  &x&-&2y&=&1\\3x&+&2y&=&11 \end{array} $$ 

We begin a row at a time. The first equation  $ x - 2y = 1 $ produces a straight line in the xy plane. The point  $ x = 1 $,  $ y = 0 $ is on the line because it solves that equation. The point  $ x = 3 $,  $ y = 1 $ is also on the line because  $ 3 - 2 = 1 $. If we choose  $ x = 101 $ we find  $ y = 50 $.

The slope of this particular line is  $ \frac{1}{2} $, because y increases by 1 when x changes by 2. But slopes are important in calculus and this is linear algebra!

Figure 2.1 will show that first line  $ x - 2y = 1 $. The second line in this “row picture” comes from the second equation  $ 3x + 2y = 11 $. You can’t miss the point  $ x = 3, y = 1 $ where the two lines meet. That point  $ (3, 1) $ lies on both lines and solves both equations.