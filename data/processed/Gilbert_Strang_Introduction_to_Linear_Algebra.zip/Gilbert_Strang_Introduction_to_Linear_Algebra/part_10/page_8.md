In homogeneous coordinates the projection matrix becomes 4 by 4 (but the origin doesn't move):

 $$ \begin{aligned}&Projection onto the plane\quad n^{\mathrm{T}}v=0\quad&P=\begin{bmatrix} \\{{{I-nn^{\mathrm{T}}}}}&{{{0}}} \\{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\\end{bmatrix}.\\ \end{aligned} $$ 

Now project onto a plane  $ \boldsymbol{n}^{\mathrm{T}}(\boldsymbol{v}-\boldsymbol{v}_{0})=0 $ that does not go through the origin. One point on the plane is  $ \boldsymbol{v}_{0} $. This is an affine space (or a  $ \mathrm{flat} $). It is like the solutions to  $ A\boldsymbol{v}=\boldsymbol{b} $ when the right side is not zero. One particular solution  $ \boldsymbol{v}_{0} $ is added to the nullspace—to produce a flat.

The projection onto the flat has three steps. Translate  $ v_0 $ to the origin by  $ T_\perp $. Project along the  $ n $ direction, and translate back along the row vector  $ v_0 $:

Projection onto a flat

 $$ T_{-}P T_{+}=\begin{bmatrix}{{{I}}}&{{{0}}} \\{{{-v_{0}}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{I-n n^{\mathrm{T}}}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{I}}}&{{{0}}} \\{{{v_{0}}}}&{{{1}}}\end{bmatrix}. $$ 

I can’t help noticing that  $ T_{-} $ and  $ T_{+} $ are inverse matrices: translate and translate back. They are like the elementary matrices of Chapter 2.

The exercises will include reflection matrices, also known as mirror matrices. These are the fifth type needed in computer graphics. A reflection moves each point twice as far as a projection—the reflection goes through the plane and out the other side. So change the projection  $ I - n n^{\mathrm{T}} $ to  $ I - 2n n^{\mathrm{T}} $ for a mirror matrix.

The matrix P gave a “parallel” projection. All points move parallel to n, until they reach the plane. The other choice in computer graphics is a “perspective” projection. This is more popular because it includes foreshortening. With perspective, an object looks larger as it moves closer. Instead of staying parallel to n (and parallel to each other), the lines of projection come toward the eye—the center of projection. This is how we perceive depth in a two-dimensional photograph.

The basic problem of computer graphics starts with a scene and a viewing position. Ideally, the image on the screen is what the viewer would see. The simplest image assigns just one bit to every small picture element—called a pixel. It is light or dark. This gives a black and white picture with no shading. You would not approve. In practice, we assign shading levels between 0 and  $ 2^8 $ for three colors like red, green, and blue. That means  $ 8 \times 3 = 24 $ bits for each pixel. Multiply by the number of pixels, and a lot of memory is needed!

Physically, a raster frame buffer directs the electron beam. It scans like a television set. The quality is controlled by the number of pixels and the number of bits per pixel. In this area, the standard text is Computer Graphics: Principles and Practice by Hughes, Van Dam, McGuire, Skylar, Foley, Feiner, and Akeley (3rd edition, Addison-Wesley, 2014). Notes by Ronald Goldman and by Tony DeRose were excellent references.