basis vectors are orthogonal. We are just doing one-dimensional projections, to find the components along each basis vector.

The formulas are even better when the vectors are orthonormal. Then we have unit vectors in Q. The denominators  $ v_k^T v_k $ are all 1. You know  $ c_k = v_k^T b $ in another form:

 $$ \begin{aligned}Equation for c^{*}s\quad&c_{1}v_{1}+\cdots+c_{n}v_{n}=b\quad or\quad\begin{bmatrix}\\ &v_{1}&\cdots&v_{n}\\ &\end{bmatrix}\begin{bmatrix}\\ &c_{1}\\ &\vdots\\ &c_{n}\\ &\end{bmatrix}=b.\end{aligned} $$ 

 $$ \begin{array}{l}Qc=b\quad yields\quad c=Q^{\mathrm{T}}b.\quad\text{Row by row this is}c_{k}=q_{k}^{\mathrm{T}}b.\end{array} $$ 

Fourier series is like having a matrix with infinitely many orthogonal columns. Those columns are the basis functions 1,  $ \cos x, \sin x, \ldots $ After dividing by their lengths we have an “infinite orthogonal matrix.” Its inverse is its transpose,  $ Q^{T} $. Orthogonality is what reduces a series of terms to one single term, when we integrate.

### Problem Set 10.5

1 Integrate the trig identity  $ 2 \cos jx \cos kx = \cos(j + k)x + \cos(j - k)x $ to show that  $ \cos jx $ is orthogonal to  $ \cos kx $, provided  $ j \neq k $. What is the result when  $ j = k $?

2 Show that 1, x, and  $ x^{2} - \frac{1}{3} $ are orthogonal, when the integration is from x = -1 to x = 1. Write  $ f(x) = 2x^{2} $ as a combination of those orthogonal functions.

3 Find a vector  $ (w_1, w_2, w_3, \ldots) $ that is orthogonal to  $ \boldsymbol{v} = (1, \frac{1}{2}, \frac{1}{4}, \ldots) $. Compute its length  $ \|\boldsymbol{w}\| $.

4 The first three Legendre polynomials are 1, x, and  $ x^2 - \frac{1}{3} $. Choose c so that the fourth polynomial  $ x^3 - cx $ is orthogonal to the first three. All integrals go from -1 to 1.

5 For the square wave  $ f(x) $ in Example 3 jumping from 1 to -1, show that

 $$ \int_{0}^{2\pi}f(x)\cos x dx=0\quad\int_{0}^{2\pi}f(x)\sin x dx=4\quad\int_{0}^{2\pi}f(x)\sin2x dx=0. $$ 

Which three Fourier coefficients come from those integrals?

6 The square wave has  $ \|f\|^2 = 2\pi $. Then (6) gives what remarkable sum for  $ \pi^2 $?

7 Graph the square wave. Then graph by hand the sum of two sine terms in its series, or graph by machine the sum of 2, 3, and 10 terms. The famous Gibbs phenomenon is the oscillation that overshoots the jump (this doesn't die down with more terms).

8 Find the lengths of these vectors in Hilbert space:

(a)

 $$ \boldsymbol{v}=\left(\frac{1}{\sqrt{1}},\frac{1}{\sqrt{2}},\frac{1}{\sqrt{4}},\frac{1}{\sqrt{8}},\cdots\right) $$ 