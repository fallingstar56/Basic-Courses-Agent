## ■ REVIEW OF THE KEY IDEAS

1. Computer graphics needs shift operations  $ T(v) = v + v_{0} $ as well as linear operations  $ T(v) = Av $.

2. A shift in  $ R^{n} $ can be executed by a matrix of order  $ n+1 $, using homogeneous coordinates.

3. The extra component 1 in  $ [x y z 1] $ is preserved when all matrices have the numbers 0, 0, 0, 1 as last column.

### Problem Set 10.6

1 A typical point in  $ \mathbf{R}^3 $ is  $ xi + yj + zk $. The coordinate vectors  $ i, j $, and  $ k $ are  $ (1, 0, 0) $,  $ (0, 1, 0) $,  $ (0, 0, 1) $. The coordinates of the point are  $ (x, y, z) $.

This point in computer graphics is  $ xi + yj + zk + \text{origin} $. Its homogeneous coordinates are  $ ( , , , ) $. Other coordinates for the same point are  $ ( , , , ) $.

2 A linear transformation $T$ is determined when we know $T(i), T(j), T(k)$. For an affine transformation we also need $T(\_\_\_\_\_\_)$. The input point $(x, y, z, 1)$ is transformed to $xT(i) + yT(j) + zT(k) + \_\_\_\_\_\_$.

3 Multiply the 4 by 4 matrix T for translation along  $ (1,4,3) $ and the matrix  $ T_{1} $ for translation along  $ (0,2,5) $. The product  $ TT_{1} $ is translation along ___.

4 Write down the 4 by 4 matrix S that scales by a constant c. Multiply ST and also TS, where T is translation by  $ (1,4,3) $. To blow up the picture around the center point  $ (1,4,3) $, would you use vST or vTS?

5 What scaling matrix S (in homogeneous coordinates, so 3 by 3) would produce a 1 by 1 square page from a standard 8.5 by 11 page?

6 What 4 by 4 matrix would move a corner of a cube to the origin and then multiply all lengths by 2? The corner of the cube is originally at  $ (1, 1, 2) $.

7 When the three matrices in equation 1 multiply the unit vector  $ \boldsymbol{a} $, show that they give  $ (\cos\theta)\boldsymbol{a} $ and  $ (1-\cos\theta)\boldsymbol{a} $ and  $ \boldsymbol{0} $. Addition gives  $ \boldsymbol{a}\boldsymbol{Q}=\boldsymbol{a} $ and the rotation axis is not moved.

8 If $b$ is perpendicular to $a$, multiply by the three matrices in 1 to get $(\cos\theta)b$ and 0 and a vector perpendicular to $b$. So $Qb$ makes an angle $\theta$ with $b$. This is rotation.

9 What is the 3 by 3 projection matrix  $ I - n n^{\mathrm{T}} $ onto the plane  $ \frac{2}{3}x + \frac{2}{3}y + \frac{1}{3}z = 0 $? In homogeneous coordinates add 0, 0, 0, 1 as an extra row and column in P.