The expected value of x starts with the probabilities  $ p_{1}, \ldots, p_{n} $ of the ages  $ x_{1}, \ldots, x_{n} $

Expected value  $ m = E[x] = p_1 x_1 + p_2 x_2 + \cdots + p_n x_n $.

This is  $ p \cdot x $. Notice that  $ m = \mathrm{E}[x] $ tells us what to expect,  $ m = \mu $ tells us what we got.

By taking many samples (large $N$), the sample results will come close to the probabilities. The “Law of Large Numbers” says that with probability 1, the sample mean will converge to its expected value $E[x]$ as the sample size $N$ increases. A fair coin has probability $p_0 = \frac{1}{2}$ of tails and $p_1 = \frac{1}{2}$ of heads. Then $E[x] = \left(\frac{1}{2}\right)0 + \frac{1}{2}(1)$. The fraction of heads in $N$ flips of the coin is the sample mean, expected to approach $E[x] = \frac{1}{2}$.

This does not mean that if we have seen more tails than heads, the next sample is likely to be heads. The odds remain 50-50. The first 100 or 1000 flips do affect the sample mean. But 1000 flips will not affect its limit—because you are dividing by  $ N \to \infty $.

Variance (around the mean)

The variance  $ \sigma^2 $ measures expected distance (squared) from the expected mean E[x]. The sample variance  $ S^2 $ measures actual distance (squared) from the sample mean. The square root is the standard deviation  $ \sigma $ or  $ S $. After an exam, I email  $ \mu $ and  $ S $ to the class. I don't know the expected mean and variance because I don't know the probabilities  $ p_1 $ to  $ p_{100} $ for each score. (After teaching for 50 years, I still have no idea what to expect.)

The deviation is always deviation from the mean—sample or expected. We are looking for the size of the “spread” around the mean value x = m. Start with N samples.

Sample variance

 $$ S^{2}=\frac{1}{N-1}\left[\left(x_{1}-m\right)^{2}+\cdots+\left(x_{N}-m\right)^{2}\right] $$ 

The sample ages x = 18, 17, 18, 19, 17 have mean m = 17.8. That sample has variance 0.7 :

 $$ S^{2}=\frac{1}{4}\left[(.2)^{2}+(-.8)^{2}+(.2)^{2}+(1.2)^{2}+(-.8)^{2}\right]=\frac{1}{4}(2.8)=\mathbf{0}.\mathbf{7} $$ 

The minus signs disappear when we compute squares. Please notice! Statisticians divide by  $ N - 1 = 4 $ (and not  $ N = 5 $) so that  $ S^2 $ is an unbiased estimate of  $ \sigma^2 $. One degree of freedom is already accounted for in the sample mean.

An important identity comes from splitting each  $ (x - m)^2 $ into  $ x^2 - 2mx + m^2 $:

 $$ \begin{align*}\operatorname{sum of}\left(x_{i}-m\right)^{2}&=\left(\operatorname{sum of}x_{i}^{2}\right)-2m(\operatorname{sum of}x_{i})+\left(\operatorname{sum of}m^{2}\right)\\&=\left(\operatorname{sum of}x_{i}^{2}\right)-2m(Nm)+Nm^{2}\\\operatorname{sum of}\left(x_{i}-m\right)^{2}&=\left(\operatorname{sum of}x_{i}^{2}\right)-Nm^{2}.\end{align*} $$ 

This is an equivalent way to find (x1 − m)2 + ⋯ + (xN − m2) by adding x12 + ⋯ + x2N.