Proof The original equation is  $ b = Ax $. The error equation (5) is  $ \Delta x = A^{-1}\Delta b $. Apply the key property  $ \|Ax\| \leq \|A\|\|x\| $ of matrix norms:

 $$ \left\| \mathbf{b} \right\|\leq \left\| \mathbf{A} \right\| \left\| \mathbf{x} \right\| \quad and \quad \left\| \Delta \mathbf{x} \right\|\leq \left\| \mathbf{A}^{-1} \right\| \left\| \Delta \mathbf{b} \right\|. $$ 

Multiply the left sides to get  $ \|b\|\|\Delta x\| $, and multiply the right sides to get  $ c\|x\|\|\Delta b\| $. Divide both sides by  $ \|b\|\|x\| $. The left side is now the relative error  $ \|\Delta x\|\|/\|x\| $. The right side is now the upper bound in equation (6).

The same condition number  $ c = \|A\|\|A^{-1}\| $ appears when the error is in the matrix. We have  $ \Delta A $ instead of  $ \Delta b $ in the error equation:

Subtract  $ Ax = b $ from  $ (A + \Delta A)(x + \Delta x) = b $ to find  $ A(\Delta x) = -(\Delta A)(x + \Delta x) $.

Multiply the last equation by  $ A^{-1} $ and take norms to reach equation (7):

 $$ \left\|\Delta\boldsymbol{x}\right\|\leq\left\|\boldsymbol{A}^{-1}\right\|\left\|\Delta\boldsymbol{A}\right\|\left\|\boldsymbol{x}+\Delta\boldsymbol{x}\right\|\quad or\quad\frac{\left\|\Delta\boldsymbol{x}\right\|}{\left\|\boldsymbol{x}+\Delta\boldsymbol{x}\right\|}\leq\left\|\boldsymbol{A}\right\|\left\|\boldsymbol{A}^{-1}\right\|\frac{\left\|\Delta\boldsymbol{A}\right\|}{\left\|\boldsymbol{A}\right\|}. $$ 

Conclusion Errors enter in two ways. They begin with an error  $ \Delta A $ or  $ \Delta b $—a wrong matrix or a wrong b. This problem error is amplified (a lot or a little) into the solution error  $ \Delta x $. That error is bounded, relative to x itself, by the condition number c.

The error  $ \Delta b $ depends on computer roundoff and on the original measurements of b. The error  $ \Delta A $ also depends on the elimination steps. Small pivots tend to produce large errors in L and U. Then  $ L + \Delta L $ times  $ U + \Delta U $ equals  $ A + \Delta A $. When  $ \Delta A $ or the condition number is very large, the error  $ \Delta x $ can be unacceptable.

Example 3 When $A$ is symmetric, $c = \|A\| \|A^{-1}\|$ comes from the eigenvalues:

 $$ A=\begin{bmatrix}{{{6}}}&{{{0}}} \\{{{0}}}&{{{2}}}\end{bmatrix}has norm6.\qquad A^{-1}=\begin{bmatrix}{{{\frac{1}{6}}}}&{{{0}}} \\{{{0}}}&{{{\frac{1}{2}}}}\end{bmatrix}has norm\frac{1}{2}. $$ 

This $A$ is symmetric positive definite. Its norm is $\lambda_{\max} = 6$. The norm of $A^{-1}$ is $1/\lambda_{\min} = \frac{1}{2}$. Multiplying norms gives the condition number $\|A\| \|A^{-1}\| = \lambda_{\max}/\lambda_{\min}$.

Condition number for positive definite A

 $$ c=\frac{\lambda_{max}}{\lambda_{min}}=\frac{6}{2}=3. $$ 

Example 4 Keep the same A, with eigenvalues 6 and 2. To make x small, choose b along the first eigenvector  $ (1,0) $. To make  $ \Delta x $ large, choose  $ \Delta b $ along the second eigenvector  $ (0,1) $. Then  $ x = \frac{1}{6}b $ and  $ \Delta x = \frac{1}{2}\Delta b $. The ratio  $ \|\Delta x\|/\|x\| $ is exactly c = 3 times the ratio  $ \|\Delta b\|/\|b\| $.

This shows that the worst error allowed by the condition number  $ \|A\|\|A^{-1}\| $ can actually happen. Here is a useful rule of thumb, experimentally verified for Gaussian elimination: The computer can lose  $ \log c $ decimal places to roundoff error.