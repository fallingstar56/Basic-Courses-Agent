Test the iteration starting from another start  $ u_{0}=0 $ and  $ v_{0}=-1 $:

 $$ \begin{bmatrix}0\\ -1\end{bmatrix}&\begin{bmatrix}3/2\\ -1/4\end{bmatrix}&\begin{bmatrix}15/8\\ -1/16\end{bmatrix}&\begin{bmatrix}63/32\\ -1/64\end{bmatrix}\quad approaches&\begin{bmatrix}2\\ 0\end{bmatrix}.\end{bmatrix} $$ 

The errors in the first component are 2, 1/2, 1/8, 1/32. The errors in the second component are -1, -1/4, -1/16, -1/32. We divide by 4 in one step not two steps. Gauss-Seidel is twice as fast as Jacobi. We have  $ \rho_{\mathrm{GS}} = (\rho_{\mathrm{J}})^2 $ when  $ A $ is positive definite tridiagonal:

 $$ S=\begin{bmatrix}{{{2}}}&{{{0}}} \\{{{-1}}}&{{{2}}}\end{bmatrix}\quad and\quad T=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad S^{-1}T=\begin{bmatrix}{{{\mathbf{0}}}}&{{{\frac{1}{2}}}} \\{{{0}}}&{{{\frac{1}{4}}}}\end{bmatrix}. $$ 

The Gauss-Seidel eigenvalues are 0 and  $ \frac{1}{4} $. Compare with  $ \frac{1}{2} $ and  $ -\frac{1}{2} $ for Jacobi.

With a small push we can describe the successive overrelaxation method (SOR). The new idea is to introduce a parameter  $ \omega $ (omega) into the iteration. Then choose this number  $ \omega $ to make the spectral radius of  $ S^{-1}T $ as small as possible.

Rewrite  $ Ax = b $ as  $ \omega A x = \omega b $. The matrix  $ S $ in SOR has the diagonal of the original  $ A $, but below the diagonal we use  $ \omega A $. On the right side  $ T $ is  $ S - \omega A $:

SOR

 $$ \begin{array}{r l r l}{{2}u_{k+1}}&{{}=(2-2\omega)u_{k}+\quad}&{\omega v_{k}+4\omega}\\ {-\omega u_{k+1}+2v_{k+1}}&{{}=}&{(2-2\omega)v_{k}-2\omega.}\end{array} $$ 

This looks more complicated to us, but the computer goes as fast as ever. SOR is like Gauss-Seidel, with an adjustable number  $ \omega $. The best  $ \omega $ makes it faster.

I will put on record the most valuable test matrix of order  $ n $. It is our favorite  $ -1, 2, -1 $ tridiagonal matrix  $ K $. The diagonal is  $ 2I $. Below and above are  $ -1 $'s. Our example had  $ n = 2 $, which leads to  $ \cos \frac{\pi}{3} = \frac{1}{2} $ as the Jacobi eigenvalue found above. Notice especially that this  $ |\lambda|_{\max} $ is squared for Gauss-Seidel:

The splittings of the  $ -1 $,  $ 2 $,  $ -1 $ matrix K of order n yield these eigenvalues of B:

Jacobi  $ (S = 0, 2, 0 \text{ matrix}) $:

 $$ S^{-1}T has\left|\lambda\right|_{\max}=\cos\frac{\pi}{n+1} $$ 

Gauss-Seidel  $ (S = -1, 2, 0 \text{ matrix}) $:

 $$ S^{-1}T has\left|\lambda\right|_{\max}=\left(\cos\frac{\pi}{n+1}\right)^{2} $$ 

SOR (with the best  $ \omega $):

 $$ ^{-1}T\mathrm{\  has\ }\left|\lambda\right|_{\max}=\left(\cos\frac{\pi}{n+1}\right)^{2}\bigg/\left(1+\sin\frac{\pi}{n+1}\right)^{2} $$ 

Let me be clear: For the -1, 2, -1 matrix you should not use any of these iterations! Elimination on a tridiagonal matrix is very fast (exact LU). Iterations are intended for a large sparse matrix that has nonzeros far from the central diagonal. Those create many more nonzeros in the exact L and U. This fill-in is why elimination becomes expensive.