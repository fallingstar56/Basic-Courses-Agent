### Problem Set 11.2

1 Find the norms  $ \|A\| = \lambda_{\max} $ and condition numbers  $ c = \lambda_{\max} / \lambda_{\min} $ of these positive definite matrices:

 $$ \begin{bmatrix}{{{.5}}}&{{{0}}} \\{{{0}}}&{{{2}}}\end{bmatrix}\qquad\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{1}}}&{{{2}}}\end{bmatrix}\qquad\begin{bmatrix}{{{3}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{bmatrix}. $$ 

2 Find the norms and condition numbers from the square roots of  $ \lambda_{\max}(A^{\mathrm{T}}A) $ and  $ \lambda_{\min}(A^{\mathrm{T}}A) $. Without positive definiteness in A, we go to  $ A^{\mathrm{T}}A! $

 $$ \begin{bmatrix}{{{-2}}}&{{{0}}} \\{{{0}}}&{{{2}}}\end{bmatrix}\qquad\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\qquad\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{-1}}}&{{{1}}}\end{bmatrix}. $$ 

Explain these two inequalities from the definitions (3) of  $ \|A\| $ and  $ \|B\| $:

 $$ \left\|A B x\right\|\leq\left\|A\right\|\left\|B x\right\|\leq\left\|A\right\|\left\|B\right\|\left\|x\right\|. $$ 

From the ratio of  $ \|ABx\| $ to  $ \|x\| $, deduce that  $ \|AB\|\leq\|A\|\|B\| $. This is the key to using matrix norms. The norm of  $ A^n $ is never larger than  $ \|A\|^n $.

Use  $ \|AA^{-1}\| \leq \|A\|\|A^{-1}\| $ to prove that the condition number is at least 1.

Why is $I$ the only symmetric positive definite matrix that has $\lambda_{\max} = \lambda_{\min} = 1$? Then the only other matrices with $\|A\| = 1$ and $\|A^{-1}\| = 1$ must have $A^{\mathrm{T}}A = I$. Those are ___ matrices: perfectly conditioned.

6 Orthogonal matrices have norm  $ \|Q\| = 1 $. If  $ A = QR $ show that  $ \|A\| \leq \|R\| $ and also  $ \|R\| \leq \|A\| $. Then  $ \|A\| = \|Q\|\|R\| $. Find an example of  $ A = LU $ with  $ \|A\| < \|L\|\|U\| $.

(a) Which famous inequality gives \|(A + B)x\| ≤ \|Ax\| + \|Bx\| for every x?

(b) Why does the definition (3) of matrix norms lead to  $ \|A + B\| \leq \|A\| + \|B\| $?

8 Show that if  $ \lambda $ is any eigenvalue of  $ A $, then  $ |\lambda| \leq \|A\| $. Start from  $ Ax = \lambda x $.

9 The “spectral radius”  $ \rho(A) = |\lambda_{\max}| $ is the largest absolute value of the eigenvalues. Show with 2 by 2 examples that  $ \rho(A + B) \leq \rho(A) + \rho(B) $ and  $ \rho(AB) \leq \rho(A)\rho(B) $ can both be false. The spectral radius is not acceptable as a norm.

(a) Explain why A and  $ A^{-1} $ have the same condition number.

(b) Explain why A and  $ A^{T} $ have the same norm, based on  $ \lambda(A^{T}A) $ and  $ \lambda(AA^{T}) $

Estimate the condition number of the ill-conditioned matrix  $ A = \begin{bmatrix} 1 & 1 \\ 1 & 1.0001 \end{bmatrix} $.

Why is the determinant of A no good as a norm? Why is it no good as a condition number?