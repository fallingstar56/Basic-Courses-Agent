Important: S is not cI. We keep the “1” in the lower corner. Then  $ [x,y,1] $ times S is the correct answer in homogeneous coordinates. The origin stays in its normal position because  $ [0\ 0\ 1] $S =  $ [0\ 0\ 1] $.

If we change that 1 to c, the result is strange. The point  $ (cx, cy, cz, c) $ is the same as  $ (x, y, z, 1) $. The special property of homogeneous coordinates is that multiplying by cI does not move the point. The origin in  $ \mathbf{R}^3 $ has homogeneous coordinates  $ (0, 0, 0, 1) $ and  $ (0, 0, 0, c) $ for every nonzero c. This is the idea behind the word “homogeneous.”

Scaling can be different in different directions. To fit a full-page picture onto a half-page, scale the $y$ direction by $\frac{1}{2}$. To create a margin, scale the $x$ direction by $\frac{3}{4}$. The graphics matrix is diagonal but not 2 by 2. It is 3 by 3 to rescale a plane and 4 by 4 to rescale a space:

Scaling matrices

 $$ \begin{align*}S=\begin{bmatrix}\frac{3}{4}&&\\&\frac{1}{2}&\\&&1\end{bmatrix}\qquad\mathrm{and}\qquad S=\begin{bmatrix}c_1&&\\&c_2&\\&&c_3&\\&&&1\end{bmatrix}.\end{align*} $$ 

That last matrix $S$ rescales the $x,y,z$ directions by positive numbers $c_{1},c_{2},c_{3}$. The extra column in all these matrices leaves the extra 1 at the end of every vector.

Summary The scaling matrix S is the same size as the translation matrix T. They can be multiplied. To translate and then rescale, multiply vTS. To rescale and then translate, multiply vST. Are those different? Yes.

The point  $ (x, y, z) $ in  $ \mathbf{R}^3 $ has homogeneous coordinates  $ (x, y, z, 1) $ in  $ \mathbf{P}^3 $. This “projective space” is not the same as  $ \mathbf{R}^4 $. It is still three-dimensional. To achieve such a thing,  $ (cx, cy, cz, c) $ is the same point as  $ (x, y, z, 1) $. Those points of projective space  $ \mathbf{P}^3 $ are really lines through the origin in  $ \mathbf{R}^4 $.

Computer graphics uses affine transformations, linear plus shift. An affine transformation T is executed on  $ \mathbf{P}^3 $ by a 4 by 4 matrix with a special fourth column:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{a_{11}}}}&{{{a_{12}}}}&{{{a_{13}}}}&{{{0}}} \\{{{a_{21}}}}&{{{a_{22}}}}&{{{a_{23}}}}&{{{0}}} \\{{{a_{31}}}}&{{{a_{32}}}}&{{{a_{33}}}}&{{{0}}} \\{{{a_{41}}}}&{{{a_{42}}}}&{{{a_{43}}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{T(1,0,0)}}}&{{{0}}} \\{{{T(0,1,0)}}}&{{{0}}} \\{{{T(0,0,1)}}}&{{{0}}} \\{{{T(0,0,0)}}}&{{{1}}}\end{bmatrix}. $$ 

The usual 3 by 3 matrix tells us three outputs, this tells four. The usual outputs come from the inputs  $ (1,0,0) $ and  $ (0,1,0) $ and  $ (0,0,1) $. When the transformation is linear, three outputs reveal everything. When the transformation is affine, the matrix also contains the output from  $ (0,0,0) $. Then we know the shift.

3. Rotation A rotation in  $ R^2 $ or  $ R^3 $ is achieved by an orthogonal matrix  $ Q $. The determinant is +1. (With determinant -1 we get an extra reflection through a mirror.) Include the extra column when you use homogeneous coordinates!

Plane rotation

 $$ \begin{aligned}Q&=\begin{bmatrix}{{{\cos\theta}}}&{{{-\sin\theta}}} \\{{{\sin\theta}}}&{{{\cos\theta}}}\end{bmatrix}\quad becomes\quad\mathcal{R}=\begin{bmatrix}{{{\cos\theta}}}&{{{-\sin\theta}}}&{{{0}}} \\{{{\sin\theta}}}&{{{\cos\theta}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}.\end{aligned} $$ 