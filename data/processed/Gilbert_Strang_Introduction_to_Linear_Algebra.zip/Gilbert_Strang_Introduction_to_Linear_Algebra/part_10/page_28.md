Symmetric matrices Suppose $A$ is symmetric but not positive definite. $A = Q\Lambda Q^\mathrm{T}$ is still true. Then the norm is the largest of $|\lambda_1|, |\lambda_2|, \ldots, |\lambda_n|$. We take absolute values, because the norm is only concerned with length. For an eigenvector $\|Ax\| = \|\lambda x\| = |\lambda|$ times $\|x\|$. The $x$ that gives the maximum ratio is the eigenvector for the maximum $|\lambda|$.

Unsymmetric matrices If A is not symmetric, its eigenvalues may not measure its true size. The norm can be larger than any eigenvalue. A very unsymmetric example has  $ \lambda_{1} = \lambda_{2} = 0 $ but its norm is not zero:

 $$ \left\|A\right\|>\lambda_{\max}\quad A=\begin{bmatrix}{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\qquad has norm\qquad\left\|A\right\|=\max_{\boldsymbol{x}\neq\mathbf{0}}\frac{\left\|A\boldsymbol{x}\right\|}{\left\|\boldsymbol{x}\right\|}=2. $$ 

The vector  $ \boldsymbol{x} = (0, 1) $ gives  $ A\boldsymbol{x} = (2, 0) $. The ratio of lengths is 2/1. This is the maximum ratio  $ \|A\| $, even though  $ \boldsymbol{x} $ is not an eigenvector.

It is the symmetric matrix  $ A^{\mathrm{T}}A $, not the unsymmetric A, that has eigenvector  $ \boldsymbol{x}=(0,1) $. The norm is really decided by the largest eigenvalue of  $ A^{\mathrm{T}}A $:

The norm of A (symmetric or not) is the square root of  $ \lambda_{\max}(A^{\mathrm{T}}A) $:

 $$ \left\|A\right\|^{2}=\max_{\boldsymbol{x}\neq\mathbf{0}}\frac{\left\|A\boldsymbol{x}\right\|^{2}}{\left\|x\right\|^{2}}=\max_{\boldsymbol{x}\neq\mathbf{0}}\frac{\boldsymbol{x}^{\mathrm{T}}A^{\mathrm{T}}A\boldsymbol{x}}{\boldsymbol{x}^{\mathrm{T}}\boldsymbol{x}}=\lambda_{\max}(A^{\mathrm{T}}A). $$ 

The unsymmetric example with  $ \lambda_{\max}(A)=0 $ has  $ \lambda_{\max}(A^{\mathrm{T}}A)=4 $:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\text{leads to}\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{0}}}&{{{4}}}\end{bmatrix}\text{with}\lambda_{\max}=4.\text{So the norm is}\|\boldsymbol{A}\|=\sqrt{4}. $$ 

For any $A$ Choose $x$ to be the eigenvector of $A^{\mathrm{T}}A$ with largest eigenvalue $\lambda_{\max}$. The ratio in equation (4) is $x^{\mathrm{T}}A^{\mathrm{T}}Ax = x^{\mathrm{T}}(\lambda_{\max})x$ divided by $x^{\mathrm{T}}x$. This is $\lambda_{\max}$.

No $x$ can give a larger ratio. The symmetric matrix $A^\mathrm{T}A$ has eigenvalues $\lambda_1,\ldots,\lambda_n$ and orthonormal eigenvectors $q_1,q_2,\ldots,q_n$. Every $x$ is a combination of those vectors. Try this combination in the ratio and remember that $q_i^\mathrm{T}q_j=0$:

 $$ \frac{\boldsymbol{x}^{\mathrm{T}}\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}\boldsymbol{x}}{\boldsymbol{x}^{\mathrm{T}}\boldsymbol{x}}=\frac{\left(c_{1}\boldsymbol{q}_{1}+\cdots+c_{n}\boldsymbol{q}_{n}\right)^{\mathrm{T}}\left(c_{1}\lambda_{1}\boldsymbol{q}_{1}+\cdots+c_{n}\lambda_{n}\boldsymbol{q}_{n}\right)}{\left(c_{1}\boldsymbol{q}_{1}+\cdots+c_{n}\boldsymbol{q}_{n}\right)^{\mathrm{T}}\left(c_{1}\boldsymbol{q}_{1}+\cdots+c_{n}\boldsymbol{q}_{n}\right)}=\frac{c_{1}^{2}\lambda_{1}+\cdots+c_{n}^{2}\lambda_{n}}{c_{1}^{2}+\cdots+c_{n}^{2}}. $$ 

The maximum ratio  $ \lambda_{\max} $ is when all  $ c' $s are zero, except the one that multiplies  $ \lambda_{\max} $.

Note 1 The ratio in equation (4) is the Rayleigh quotient for the symmetric matrix  $ A^{\mathrm{T}}A $. Its maximum is the largest eigenvalue  $ \lambda_{\max}(A^{\mathrm{T}}A) $. The minimum ratio is  $ \lambda_{\min}(A^{\mathrm{T}}A) $. If you substitute any vector  $ \boldsymbol{x} $ into the Rayleigh quotient  $ \boldsymbol{x}^{\mathrm{T}}A^{\mathrm{T}}Ax/\boldsymbol{x}^{\mathrm{T}}\boldsymbol{x} $, you are guaranteed to get a number between  $ \lambda_{\min}(A^{\mathrm{T}}A) $ and  $ \lambda_{\max}(A^{\mathrm{T}}A) $.