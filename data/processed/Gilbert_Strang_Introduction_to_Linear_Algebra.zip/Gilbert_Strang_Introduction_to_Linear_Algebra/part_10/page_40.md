subdiagonal). The zeros in the lower left corner will stay zero through the QR method. The operation count for each QR factorization drops from  $ \mathrm{O}(n^{3}) $ to  $ \mathrm{O}(n^{2}) $.

Golub and Van Loan give this example of one shifted QR step on a Hessenberg matrix. The shift is 7I, taking 7 from all diagonal entries of A (then shifting back for  $ A_{1} $):

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{4}}}&{{{5}}}&{{{6}}} \\{{{0}}}&{{{.001}}}&{{{7}}}\end{bmatrix}\quad leads to\quad A_{1}=\begin{bmatrix}{{{-.54}}}&{{{1.69}}}&{{{0.835}}} \\{{{.31}}}&{{{6.53}}}&{{{-6.656}}} \\{{{0}}}&{{{.00002}}}&{{{7.012}}}\end{bmatrix}. $$ 

Factoring A - 7I into QR produced  $ A_1 = RQ + 7I $. Notice the very small number .00002. The diagonal entry 7.012 is almost an exact eigenvalue of  $ A_1 $, and therefore of A. Another QR step on  $ A_1 $ with shift by 7.012I would give terrific accuracy.

For a few eigenvalues of a large sparse matrix I would look to ARPACK. Problems 25–27 describe the Arnoldi iteration that orthogonalizes the basis—each step has only three terms when A is symmetric. The matrix becomes tridiagonal: a wonderful start for computing eigenvalues.

### Problem Set 11.3

Problems 1–12 are about iterative methods for Ax = b.

1 Change  $ Ax = b $ to  $ x = (I - A)x + b $. What are S and T for this splitting? What matrix  $ S^{-1}T $ controls the convergence of  $ x_{k+1} = (I - A)x_k + b $?

2 If  $ \lambda $ is an eigenvalue of A, then ___ is an eigenvalue of B = I - A. The real eigenvalues of B have absolute value less than 1 if the real eigenvalues of A lie between ___ and ___.

3 Show why the iteration  $ x_{k+1} = (I - A)x_k + b $ does not converge for  $ A = \begin{bmatrix} 2 & -1 \\ -1 & 2 \end{bmatrix} $.

4 Why is the norm of  $ B^k $ never larger than  $ \|B\|^k $? Then  $ \|B\| < 1 $ guarantees that the powers  $ B^k $ approach zero (convergence). No surprise since  $ |\lambda|_{\max} $ is below  $ \|B\| $.

5 If $A$ is singular then all splittings $A = S - T$ must fail. From $Ax = 0$ show that $S^{-1}Tx = x$. So this matrix $B = S^{-1}T$ has $\lambda = 1$ and fails.

6 Change the 2's to 3's and find the eigenvalues of  $ S^{-1}T $ for Jacobi's method:

 $$ S\boldsymbol{x}_{k+1}=T\boldsymbol{x}_{k}+\boldsymbol{b}\quad is\quad\begin{bmatrix}{{{3}}}&{{{0}}} \\{{{0}}}&{{{3}}}\end{bmatrix}\boldsymbol{x}_{k+1}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\boldsymbol{x}_{k}+\boldsymbol{b}. $$ 

7 Find the eigenvalues of  $ S^{-1}T $ for the Gauss-Seidel method applied to Problem 6:

 $$ \begin{bmatrix}{{{3}}}&{{{0}}} \\{{{-1}}}&{{{3}}}\end{bmatrix}\boldsymbol{x}_{k+1}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\boldsymbol{x}_{k}+\boldsymbol{b}. $$ 

Does  $ |\lambda|_{\max} $ for Gauss-Seidel equal  $ |\lambda|_{\max}^2 $ for Jacobi?