course to be useful. I believe the right way is to understand  $ \mathbf{R}^n $ and its subspaces first, as you do. Then you can look at other fields and vector spaces with a natural question in mind: What is new when the field is not  $ \mathbf{R} $?

These pages are asking that question for finite fields. The possibilities become more limited but also highly interesting. The starting point (and not quite the ending point) is the finite field  $ \mathbf{F}_p $. It contains only the numbers  $ 0, 1, \ldots, p-1 $ and  $ p $ is a prime number. I will focus first on the field  $ \mathbf{F}_2 $ with only 2 members “0” and “1”. You could think of 0 and 1 as “even” and “odd” because the rules to add and multiply are obeyed by the even numbers and odd numbers: even + odd = odd and even × odd = even.

Addition table

 $$ \begin{array}{c|cc}{{{0}}}&{{{1}}} \\{{{\hline0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\\end{array} $$ 

Multiplication table

 $$ \begin{array}{c|cc}{{{0}}}&{{{1}}} \\{{{\hline0}}}&{{{0}}} \\{{{\hline1}}}&{{{0}}}&{{{1}}} \\\end{array} $$ 

This is addition and multiplication "mod 2".

From this field  $ \mathbf{F}_2 $ we can build vectors like  $ \boldsymbol{v} = (0, 0, 1) $ and  $ \boldsymbol{w} = (1, 0, 1) $. There are three components with two choices each: a total of  $ 2^3 = 8 $ different vectors in the vector space ( $ \mathbf{F}_2 $) $ ^3 $. You know the requirements on a subspace and the possibilities it opens up:

a) The zero-dimensional subspace containing only  $ \mathbf{0} = (0, 0, 0) $.

b) One-dimensional subspaces containing 0 and a vector like v. Notice  $ v + v = 0 $ !

c) Two-dimensional subspaces with a basis like v and w and 4 vectors 0, v, w, v + w.

d) The full three-dimensional subspace  $ (F_{2})^{3} $ with 8 vectors.

What are the possible bases for  $ (\mathbf{F}_2)^3 $? The standard basis contains  $ (1,0,0) $ and  $ (0,1,0) $ and  $ (0,0,1) $. Those vectors are linearly independent and they span  $ (\mathbf{F}_2)^3 $. Their eight combinations with coefficients 0 and 1 fill all of  $ (\mathbf{F}_2)^3 $.

What about matrices that multiply those vectors? The matrices will be 1 by 3, or 2 by 3, or 3 by 3. When they are 3 by 3 we can ask if they are invertible. Their determinants can only be 0 (singular matrix) or 1 (invertible matrix). Let me leave you the pleasure of deciding whether these matrices are invertible. And how would you find the inverse?

 $$ \boldsymbol{A}=\left[\begin{array}{lll}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{array}\right]\qquad\boldsymbol{B}=\left[\begin{array}{lll}{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{1}}}\end{array}\right]\qquad\boldsymbol{C}=\left[\begin{array}{lll}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{array}\right] $$ 

Out of  $ 2^9 $ possible matrices over  $ F_2 $, I will guess that most are singular.

To conclude this discussion of  $ \mathbf{F}_2 $, I mention a field with  $ 2^2 = 4 $ members. It will not come from multiplication (mod 4), because 4 is not prime. The multiplication 2 times 2 will give 0 (and 2 has no inverse): not a field. But we can start with the numbers 0 and 1 in  $ \mathbf{F}_2 $ and invent two more numbers  $ a $ and  $ 1 + a $—provided they follow these two rules:  $ (a + a = 0) $ and  $ (a \times a = 1 + a) $. Then  $ a $ and  $ 1 + a $ are inverses. Not obvious!