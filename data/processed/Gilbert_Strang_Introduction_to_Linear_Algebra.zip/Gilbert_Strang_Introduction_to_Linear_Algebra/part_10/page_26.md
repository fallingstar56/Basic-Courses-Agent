(a) Choose sin θ and cos θ to triangularize A, and find R:

Givens rotation

 $$ Q_{21}A=\begin{bmatrix}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{bmatrix}\begin{bmatrix}1&-1\\ 3&5\end{bmatrix}=\begin{bmatrix}*&*\\ 0&*\end{bmatrix}=R. $$ 

(b) Choose  $ \sin \theta $ and  $ \cos \theta $ to make  $ QAQ^{-1} $ triangular. What are the eigenvalues?

When A is multiplied by a plane rotation  $ Q_{ij} $, which entries of A are changed? When  $ Q_{ij}A $ is multiplied on the right by  $ Q_{ij}^{-1} $, which entries are changed now?

How many multiplications and how many additions are used to compute  $ Q_{ij}A $? Careful organization of the whole sequence of rotations gives  $ \frac{2}{3}n^3 $ multiplications and  $ \frac{2}{3}n^3 $ additions—the same as for QR by reflectors and twice as many as for LU.

## Challenge Problems

(Turning a robot hand) The robot produces any 3 by 3 rotation A from plane rotations around the x, y, z axes. Then  $ Q_{32}Q_{31}Q_{21}A = R $, where A is orthogonal so R is I! The three robot turns are in  $ A = Q_{21}^{-1}Q_{31}^{-1}Q_{32}^{-1} $. The three angles are “Euler angles” and  $ \det Q = 1 $ to avoid reflection. Start by choosing  $ \cos \theta $ and  $ \sin \theta $ so that

 $$ Q_{21}A=\begin{bmatrix}{{{\cos\theta}}}&{{{-\sin\theta}}}&{{{0}}} \\{{{\sin\theta}}}&{{{\cos\theta}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\frac{1}{3}\begin{bmatrix}{{{-1}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{-1}}}&{{{2}}} \\{{{2}}}&{{{2}}}&{{{-1}}}\end{bmatrix}\quad is zero in the\left(2,1\right)position. $$ 

Create the 10 by 10 second difference matrix  $ K = \text{toeplitz}([2 - 1 \text{ zeros}(1,8)]) $. Permute rows and columns randomly by  $ KK = K(\text{randperm}(10), \text{randperm}(10)) $ Factor by  $ [L, U] = \text{lu}(K) $ and  $ [LL, UU] = \text{lu}(KK) $, and count nonzeros by  $ \text{nnz}(L) $ and  $ \text{nnz}(LL) $. In this case L is in perfect tridiagonal order, but not LL.

Another ordering for this matrix K colors the meshpoints alternately red and black. This permutation P changes the normal 1, ..., 10 to 1, 3, 5, 7, 9, 2, 4, 6, 8, 10:

Red-black ordering

 $$ \boldsymbol{P}\boldsymbol{K}\boldsymbol{P}^{\mathrm{T}}=\left[\begin{array}{cc}{{{2\boldsymbol{I}}}}&{{{\boldsymbol{D}}}} \\{{{\boldsymbol{D}^{\mathrm{T}}}}}&{{{2\boldsymbol{I}}}}\end{array}\right] $$ 

Find the matrix D.

So many interesting experiments are possible. If you send good ideas they can go on the linear algebra website math.mit.edu/linearalgebra. I also recommend learning the command  $ B = \text{sparse}(A) $, after which  $ \text{find}(B) $ will list the nonzero entries and  $ \ell\mathbf{u}(B) $ will factor B using that sparse format for L and U. Only the nonzeros are computed, where ordinary (dense) MATLAB computes all the zeros too.

Jeff Stuart has created a student activity that brilliantly demonstrates ill-conditioning:

 $$ \begin{bmatrix}1&1.0001\\ 1&1.0000\end{bmatrix}\begin{bmatrix}x\\ y\end{bmatrix}=\begin{bmatrix}3.0001+e\\ 3.0000+E\end{bmatrix}\begin{array}{cc}With errors&x=2-10000(e-E)\\ e and E&y=1+10000(e-E)\end{array} $$ 

When those equations are shown by nearly parallel long sticks, a small shake gives a big jump in the crossing point  $ (x, y) $. Errors e and E are amplified by 10000.