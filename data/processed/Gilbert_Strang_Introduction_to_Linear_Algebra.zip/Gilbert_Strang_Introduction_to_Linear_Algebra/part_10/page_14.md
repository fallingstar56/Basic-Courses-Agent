By pure chance  $ A^{-1} \equiv A! $ Multiplying  $ A $ times  $ A \mod 3 $ does give the identity matrix:

 $$ \boldsymbol{A}^{2}=\boldsymbol{A}\boldsymbol{A}^{-1}=\left[\begin{array}{ll}{{{2}}}&{{{0}}} \\{{{2}}}&{{{1}}}\end{array}\right]\left[\begin{array}{ll}{{{2}}}&{{{0}}} \\{{{2}}}&{{{1}}}\end{array}\right]=\left[\begin{array}{ll}{{{4}}}&{{{0}}} \\{{{6}}}&{{{1}}}\end{array}\right]\equiv\left[\begin{array}{ll}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{array}\right](mod3). $$ 

The determinant of A is 2, and the cofactor formula from Section 5.3 also gives A−1 ≡ A :

 $$ \left[\begin{array}{cc}{{{2}}}&{{{0}}} \\{{{2}}}&{{{1}}}\end{array}\right]^{-1}=2^{-1}\left[\begin{array}{cc}{{{1}}}&{{{-0}}} \\{{{-2}}}&{{{2}}}\end{array}\right]\equiv2\left[\begin{array}{cc}{{{1}}}&{{{-0}}} \\{{{-2}}}&{{{2}}}\end{array}\right]\equiv\left[\begin{array}{cc}{{{2}}}&{{{0}}} \\{{{2}}}&{{{1}}}\end{array}\right](mod3). $$ 

Theorem.  $ A^{-1} $ exists mod p if and only if  $ (\det A)^{-1} $ exists mod p. The requirement is:  $ \det A $ and p have no common factors.

## Encryption with the Hill Cipher

The original cipher used the letters A to Z with  $ p = 26 $. Hill chose an  $ n $ by  $ n $ encryption matrix  $ E $ so that  $ \det E $ is not divisible by 2 or 13. Then the number  $ \det E $ has an inverse  $ \mod 26 $ and so does the matrix  $ E $. The inverse matrix  $ E^{-1} \equiv D \pmod{26} $ will be the decryption matrix that decodes the message.

Now convert each letter of the message into a number from 0 to 25. The obvious choice from A = 0 to Z = 25 is acceptable because the matrix will make this cipher stronger.

Ignore spaces and divide the message into blocks  $ v_1, v_2, \ldots $ of size  $ n $. Then multiply each message block  $ (mod p) $ by the encryption matrix  $ E $. The coded message is  $ Ev_1, Ev_2, \ldots $ and you know what the decoder will do.

 $$ \begin{array}{l} \text{Spikler's example has } D=E^{-1}=\left[\begin{array}{lll}2&3&15\\ 5&8&12\\ 1&13&4 \end{array}\right]^{-1}\equiv\left[\begin{array}{lll}10&19&16\\ 4&23&7\\ 17&5&19 \end{array}\right] \end{array} $$ 

Of course a codebreaker will not know E or D. And the block size n is generally unknown too. For the matrices Hill had in mind n would not be very large and a computer could quickly discover E and D.

I am not sure if Hill’s Cipher could become seriously difficult to break by choosing very large matrices and a large prime number  $ p $. And by encoding the coded message a second time, using a different block size  $ n_{2} $ and large matrix  $ E_{2} $ and large prime  $ p_{2} $.

## Finite Fields and Finite Vector Spaces

In algebra, a field  $ \mathbf{F} $ is a set of scalars that can be added and multiplied and inverted (except 0 can't be inverted). Familiar examples are the real numbers  $ \mathbf{R} $ and the complex numbers  $ \mathbf{C} $ and the rational numbers  $ \mathbf{Q} $ (containing every ratio  $ p/q $ of integers). From a field you build vectors  $ \boldsymbol{v} = (f_1, f_2, \ldots, f_n) $. From linear combinations of vectors you build vector spaces. So linear algebra begins with a field  $ \mathbf{F} $.

I taught for ten years from a textbook that started with fields. On the way to  $ R^{n} $, we lost a lot of students. That was a signal—the emphasis was misplaced if we wanted the