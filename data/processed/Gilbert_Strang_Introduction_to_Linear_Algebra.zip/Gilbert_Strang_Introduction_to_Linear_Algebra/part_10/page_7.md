This matrix rotates the plane around the origin. How would we rotate around a different point (4, 5)? The answer brings out the beauty of homogeneous coordinates. Translate (4, 5) to (0, 0), then rotate by  $ \theta $, then translate (0, 0) back to (4, 5):

 $$ \boldsymbol{v}T_{-}RT_{+}=\begin{bmatrix}{{{x}}}&{{{y}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{-4}}}&{{{-5}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{\cos\theta}}}&{{{-\sin\theta}}}&{{{0}}} \\{{{\sin\theta}}}&{{{\cos\theta}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{4}}}&{{{5}}}&{{{1}}}\end{bmatrix}. $$ 

I won’t multiply. The point is to apply the matrices one at a time: v translates to  $ vT_{-} $, then rotates to  $ vT_{-}R $, and translates back to  $ vT_{-}RT_{+} $. Because each point  $ [x\ y\ 1] $ is a row vector,  $ T_{-} $ acts first. The center of rotation  $ (4,5) $—otherwise known as  $ (4,5,1) $—moves first to  $ (0,0,1) $. Rotation doesn’t change it. Then  $ T_{+} $ moves it back to  $ (4,5,1) $. All as it should be. The point  $ (4,6,1) $ moves to  $ (0,1,1) $, then turns by  $ \theta $ and moves back.

In three dimensions, every rotation $Q$ turns around an axis. The axis doesn't move—it is a line of eigenvectors with $\lambda = 1$. Suppose the axis is in the $z$ direction. The $1$ in $Q$ is to leave the $z$ axis alone, the extra $1$ in $R$ is to leave the origin alone:

 $$ \boldsymbol{Q}=\begin{bmatrix}{{{\cos\theta}}}&{{{-\sin\theta}}}&{{{0}}} \\{{{\sin\theta}}}&{{{\cos\theta}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\qquad and\qquad\boldsymbol{R}=\begin{bmatrix} \\{{{0}}} \\{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\\end{bmatrix}. $$ 

Now suppose the rotation is around the unit vector  $ \boldsymbol{a} = (a_1, a_2, a_3) $. With this axis  $ \boldsymbol{a} $, the rotation matrix  $ Q $ which fits into  $ R $ has three parts:

 $$ \boldsymbol{Q}=(\cos\theta)\boldsymbol{I}+(1-\cos\theta)\begin{bmatrix}a_{1}^{2}&a_{1}a_{2}&a_{1}a_{3}\\ a_{1}a_{2}&a_{2}^{2}&a_{2}a_{3}\\ a_{1}a_{3}&a_{2}a_{3}&a_{3}^{2}\end{bmatrix}-\sin\theta\begin{bmatrix}0&a_{3}&-a_{2}\\ -a_{3}&0&a_{1}\\ a_{2}&-a_{1}&0\end{bmatrix}. $$ 

The axis doesn’t move because aQ = a. When  $ a = (0, 0, 1) $ is in the z direction, this Q becomes the previous Q—for rotation around the z axis.

The linear transformation Q always goes in the upper left block of R. Below it we see zeros, because rotation leaves the origin in place. When those are not zeros, the transformation is affine and the origin moves.

4. Projection In a linear algebra course, most planes go through the origin. In real life, most don't. A plane through the origin is a vector space. The other planes are affine spaces, sometimes called "flats." An affine space is what comes from translating a vector space.

We want to project three-dimensional vectors onto planes. Start with a plane through the origin, whose unit normal vector is  $ n $. (We will keep  $ n $ as a column vector.) The vectors in the plane satisfy  $ n^T v = 0 $. The usual projection onto the plane is the matrix  $ I - nn^T $. To project a vector, multiply by this matrix. The vector  $ n $ is projected to zero, and the in-plane vectors  $ v $ are projected onto themselves:

 $$ (\boldsymbol{I}-\boldsymbol{n}\boldsymbol{n}^{\mathrm{T}})\boldsymbol{n}=\boldsymbol{n}-\boldsymbol{n}(\boldsymbol{n}^{\mathrm{T}}\boldsymbol{n})=\mathbf{0}\quad and\quad(\boldsymbol{I}-\boldsymbol{n}\boldsymbol{n}^{\mathrm{T}})\boldsymbol{v}=\boldsymbol{v}-\boldsymbol{n}(\boldsymbol{n}^{\mathrm{T}}\boldsymbol{v})=\boldsymbol{v}. $$ 