Let me draw the graphs of  $ F(x) $ and its derivative  $ p(x) = \text{probability density function} $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_192_169_551_365.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_574_171_903_364.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">Figure 12.1:  $ F(x) $ is the cumulative distribution and its derivative  $ p(x) = dF/dx $ is the probability density function (pdf). For this uniform distribution,  $ p(x) $ is constant between 17 and 20. The total area under the graph of  $ p(x) $ is the total probability F = 1.</div>


You could say that  $ p(x)\,dx $ is the probability of a sample falling in between  $ x $ and  $ x+dx $. This is “infinitesimally true”:  $ p(x)\,dx $ is  $ F(x+dx) - F(x) $. Here is the full truth:

$$F = \mathrm{integral of} p \quad \mathrm{Probability of} a \leq x \leq b = \int_{a}^{b} p(x) \, dx = F(b) - F(a)$$

 $ F(b) $ is the probability of  $ x \leq b $. I subtract  $ F(a) $ to keep  $ x \geq a $. That leaves  $ a \leq x \leq b $.

Mean and Variance of  $ p(x) $

What are the mean m and variance  $ \sigma^2 $ for a probability distribution ? Previously we added  $ p_i x_i $ to get the mean (expected value). With a continuous distribution we integrate  $ xp(x) $ :

Mean

 $$ m=\mathrm{E}[x]=\int x p(x)dx=\int\limits_{x=17}^{20}(x)\left(\frac{1}{3}\right)dx=18.5 $$ 

For this uniform distribution, the mean $m$ is halfway between 17 and 20. Then the probability of a random value $x$ below this halfway point $m = 18.5$ is $F(m) = \frac{1}{2}$.

In MATLAB,  $ x = \text{rand}(1) $ chooses a random number uniformly between 0 and 1. Then the expected mean is  $ m = \frac{1}{2} $. The interval from 0 to  $ x $ has probability  $ F(x) = x $. The interval below the mean  $ m $ always has probability  $ F(m) = \frac{1}{2} $.

The variance is the average squared distance to the mean. With N outcomes,  $ \sigma^{2} $ is the sum of  $ p_{i}(x_{i} - m)^{2} $. For a continuous random variable x, the sum changes to an integral.

Variance

 $$ \sigma^{2}=\mathrm{E}\left[(x-m)^{2}\right]=\int p(x)\left(x-m\right)^{2}d x $$ 