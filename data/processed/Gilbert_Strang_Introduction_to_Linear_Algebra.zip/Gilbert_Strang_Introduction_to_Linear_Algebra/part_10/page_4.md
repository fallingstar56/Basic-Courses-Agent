(b)  $ v = (1, a, a^2, \ldots) $

(c)  $  f(x) = 1 + \sin x  $.

9 Compute the Fourier coefficients  $ a_{k} $ and  $ b_{k} $ for  $ f(x) $ defined from 0 to  $ 2\pi $:

(a)  $  f(x) = 1  $ for  $ 0 \leq x \leq \pi $,  $  f(x) = 0  $ for  $  \pi < x < 2\pi  $

(b)  $  f(x) = x  $.

10 When $f(x)$ has period $2\pi$, why is its integral from $-\pi$ to $\pi$ the same as from 0 to $2\pi$? If $f(x)$ is an odd function, $f(-x) = -f(x)$, show that $\int_{-\pi}^{\pi} f(x) \, dx$ is zero. Odd functions only have sine terms, even functions only have cosines.

11 Using trigonometric identities find the two terms in the Fourier series for f(x):

(a)  $  f(x) = \cos^2 x  $ (b)  $  f(x) = \cos\left(x + \frac{\pi}{3}\right)  $ (c)  $  f(x) = \sin^3 x  $

12 The functions 1,  $ \cos x $,  $ \sin x $,  $ \cos 2x $,  $ \sin 2x $,  $ \ldots $ are a basis for Hilbert space. Write the derivatives of those first five functions as combinations of the same five functions. What is the 5 by 5 “differentiation matrix” for these functions?

13 Find the Fourier coefficients  $ a_k $ and  $ b_k $ of the square pulse  $ F(x) $ centered at  $ x = 0 $:

 $ F(x) = 1/h $ for  $ |x| \leq h/2 $ and  $ F(x) = 0 $ for  $ h/2 < |x| \leq \pi $.

As  $ h \to 0 $, this  $ F(x) $ approaches a delta function. Find the limits of  $ a_k $ and  $ b_k $.

Section 4.1 of Computational Science and Engineering explains the sine series, cosine series, complete series, and complex series  $ \sum c_k e^{ikx} $ on math.mit.edu/cse.

Section 9.3 of this book explains the Discrete Fourier Transform. This is “Fourier series for vectors” and it is computed by the Fast Fourier Transform. That fast algorithm comes quickly from special complex numbers  $ z = e^{i\theta} = \cos\theta + i\sin\theta $ when the angle is  $ \theta = 2\pi k/n $.