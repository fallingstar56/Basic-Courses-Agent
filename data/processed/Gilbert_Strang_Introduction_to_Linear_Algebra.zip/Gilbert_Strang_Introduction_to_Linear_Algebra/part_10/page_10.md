10 With the same 4 by 4 matrix $P$, multiply $T_{-}PT_{+}$ to find the projection matrix onto the plane $\frac{2}{3}x+\frac{2}{3}y+\frac{1}{3}z=1$. The translation $T_{-}$ moves a point on that plane (choose one) to $(0,0,0,1)$. The inverse matrix $T_{+}$ moves it back.

11 Project (3, 3, 3) onto those planes. Use P in Problem 9 and  $ T_{-}PT_{+} $ in Problem 10.

12 If you project a square onto a plane, what shape do you get?

13 If you project a cube onto a plane, what is the outline of the projection? Make the projection plane perpendicular to a diagonal of the cube.

14 The 3 by 3 mirror matrix that reflects through the plane  $ n^{\mathrm{T}}v = 0 $ is  $ M = I - 2nn^{\mathrm{T}} $. Find the reflection of the point  $ (3, 3, 3) $ in the plane  $ \frac{2}{3}x + \frac{2}{3}y + \frac{1}{3}z = 0 $.

15 Find the reflection of  $ (3,3,3) $ in the plane  $ \frac{2}{3}x + \frac{2}{3}y + \frac{1}{3}z = 1 $. Take three steps  $ T_{-}MT_{+} $ using 4 by 4 matrices: translate by  $ T_{-} $ so the plane goes through the origin, reflect the translated point  $ (3,3,3,1)T_{-} $ in that plane, then translate back by  $ T_{+} $.

16 The vector between the origin  $ (0,0,0,1) $ and the point  $ (x,y,z,1) $ is the difference  $ v=\_\_\_ $. In homogeneous coordinates, vectors end in ___. So we add a ___ to a point, not a point to a point.

17 If you multiply only the last coordinate of each point to get  $ (x, y, z, c) $, you rescale the whole space by the number ___. This is because the point  $ (x, y, z, c) $ is the same as  $ ( , , , 1) $.