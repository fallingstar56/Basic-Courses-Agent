Inverse power method

 $$ u_{k}=A^{-k}u_{0}=\frac{c_{1}x_{1}}{\left(\lambda_{1}\right)^{k}}+\cdots+\frac{c_{n}x_{n}}{\left(\lambda_{n}\right)^{k}}. $$ 

Now the smallest eigenvalue  $ \lambda_{\min} $ is in control. When it is very small, the factor  $ 1/\lambda_{\min}^{k} $ is large. For high speed, we make  $ \lambda_{\min} $ even smaller by shifting the matrix to  $ A - \lambda^{*}I $.

That shift doesn’t change the eigenvectors. ( $ \lambda^* $ might come from the diagonal of  $ A $, even better is a Rayleigh quotient  $ x^\mathrm{T}Ax/x^\mathrm{T}x $). If  $ \lambda^* $ is close to  $ \lambda_{\min} $ then  $ (A - \lambda^*I)^{-1} $ has the very large eigenvalue  $ (\lambda_{\min} - \lambda^*)^{-1} $. Each shifted inverse power step multiplies the eigenvector by this big number, and that eigenvector quickly dominates.

2 The QR Method This is a major achievement in numerical linear algebra. Sixty years ago, eigenvalue computations were slow and inaccurate. We didn't even realize that solving  $ \det(A - \lambda I) = 0 $ was a terrible method. Jacobi had suggested earlier that A should gradually be made triangular—then the eigenvalues appear automatically on the diagonal. He used 2 by 2 rotations to produce off-diagonal zeros. (Unfortunately the previous zeros can become nonzero again. But Jacobi's method made a partial comeback with parallel computers.) The QR method is now a leader in eigenvalue computations.

The basic step is to factor $A$, whose eigenvalues we want, into $QR$. Remember from Gram-Schmidt (Section 4.4) that $Q$ has orthonormal columns and $R$ is triangular. For eigenvalues the key idea is: Reverse $Q$ and $R$. The new matrix (same $\lambda's$) is $A_1 = RQ$. The eigenvalues are not changed in $RQ$ because $A = QR$ is similar to $A_1 = Q^{-1}AQ$.

 $ A_1 = RQ $ has the same  $ \lambda $

 $$ Q R x=\lambda x\quad gives\quad R Q(Q^{-1}x)=\lambda(Q^{-1}x). $$ 

This process continues. Factor the new matrix  $ A_1 $ into  $ Q_1R_1 $. Then reverse the factors to  $ R_1Q_1 $. This is the similar matrix  $ A_2 $ and again no change in the eigenvalues. Amazingly, those eigenvalues begin to show up on the diagonal. Soon the last entry of  $ A_4 $ holds an accurate eigenvalue. In that case we remove the last row and column and continue with a smaller matrix to find the next eigenvalue.

Two extra ideas make this method a success. One is to shift the matrix by a multiple of I, before factoring into QR. Then RQ is shifted back to give  $ A_{k+1} $:

 $$  Factor A_{k}-c_{k}I into Q_{k}R_{k}.The next matrix is A_{k+1}=R_{k}Q_{k}+c_{k}I. $$ 

 $ A_{k+1} $ has the same eigenvalues as  $ A_k $, and the same as the original  $ A_0 = A $. A good shift chooses  $ c $ near an (unknown) eigenvalue. That eigenvalue appears more accurately on the diagonal of  $ A_{k+1} $—which tells us a better  $ c $ for the next step to  $ A_{k+2} $.

The second idea is to obtain off-diagonal zeros before the QR method starts. An elimination step E will do it, or a Givens rotation, but don’t forget  $ E^{-1} $ (or  $ \lambda $ will change):

 $$ EAE^{-1}=\begin{bmatrix}{{{1}}} \\{{{1}}} \\{{{-1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{1}}}&{{{4}}}&{{{5}}} \\{{{1}}}&{{{6}}}&{{{7}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{1}}} \\{{{1}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{5}}}&{{{3}}} \\{{{1}}}&{{{9}}}&{{{5}}} \\{{{0}}}&{{{4}}}&{{{2}}}\end{bmatrix} $$ 

Same λ's.

We must leave those nonzeros 1 and 4 along one subdiagonal. More E’s could remove them, but  $ E^{-1} $ would fill them in again. This is a “Hessenberg matrix” (one nonzero