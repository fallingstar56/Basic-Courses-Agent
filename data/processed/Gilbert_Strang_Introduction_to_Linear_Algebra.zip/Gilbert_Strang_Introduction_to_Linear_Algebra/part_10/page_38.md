The biggest competition is direct elimination, with the equations reordered to take maximum advantage of the zeros in A. It is not easy to outperform Gauss.

## Iterative Methods for Eigenvalues

We move from  $ Ax = b $ to  $ Ax = \lambda x $. Iterations are an option for linear equations. They are a necessity for eigenvalue problems. The eigenvalues of an n by n matrix are the roots of an nth degree polynomial. The determinant of  $ A - \lambda I $ starts with  $ (-\lambda)^n $. This book must not leave the impression that eigenvalues should be computed that way! Working from  $ \det(A - \lambda I) = 0 $ is a very poor approach—except when n is small.

For $n > 4$ there is no formula to solve $\det(A - \lambda I) = 0$. Worse than that, the $\lambda$'s can be very unstable and sensitive. It is much better to work with $A$ itself, gradually making it diagonal or triangular. (Then the eigenvalues appear on the diagonal.) Good computer codes are available in the LAPACK library—individual routines are free on www.netlib.org/lapack. This library combines the earlier LINPACK and EISPACK, with many improvements (to use matrix-matrix operations in the Level 3 BLAS). It is a collection of Fortran 77 programs for linear algebra on high-performance computers. For your computer and mine, a high quality matrix package is all we need. For supercomputers with parallel processing, move to ScaLAPACK and block elimination.

We will briefly discuss the power method and the QR method (chosen by LAPACK) for computing eigenvalues. It makes no sense to give full details of the codes.

1 Power methods and inverse power methods. Start with any vector  $ u_0 $. Multiply by  $ A $ to find  $ u_1 $. Multiply by  $ A $ again to find  $ u_2 $. If  $ u_0 $ is a combination of the eigenvectors, then  $ A $ multiplies each eigenvector  $ x_i $ by  $ \lambda_i $. After  $ k $ steps we have  $ (\lambda_i)^k $:

 $$ \boldsymbol{u}_{k}=A^{k}\boldsymbol{u}_{0}=c_{1}(\lambda_{1})^{k}\boldsymbol{x}_{1}+\cdots+c_{n}(\lambda_{n})^{k}\boldsymbol{x}_{n}. $$ 

As the power method continues, the largest eigenvalue begins to dominate. The vectors  $ u_k $ point toward that dominant eigenvector  $ x_1 $. We saw this for Markov matrices:

 $$ A=\begin{bmatrix}.9&.3\\ .1&.7\end{bmatrix}\quad has\quad\lambda_{max}=1\quad with eigenvector\quad\begin{bmatrix}.75\\ .25\end{bmatrix}. $$ 

Start with  $ u_{0} $ and multiply at every step by A:

 $$ \boldsymbol{u}_{0}=\begin{bmatrix}1\\ 0\end{bmatrix},\boldsymbol{u}_{1}=\begin{bmatrix}.9\\ .1\end{bmatrix},\boldsymbol{u}_{2}=\begin{bmatrix}.84\\ .16\end{bmatrix}\quad is approaching\quad\boldsymbol{u}_{\infty}=\begin{bmatrix}.75\\ .25\end{bmatrix}. $$ 

The speed of convergence depends on the ratio of the second largest eigenvalue  $ \lambda_2 $ to the largest  $ \lambda_1 $. We don’t want  $ \lambda_1 $ to be small, we want  $ \lambda_2/\lambda_1 $ to be small. Here  $ \lambda_2 = .6 $ and  $ \lambda_1 = 1 $, giving good speed. For large matrices it often happens that  $ |\lambda_2/\lambda_1| $ is very close to 1. Then the power method is too slow.

Is there a way to find the smallest eigenvalue—which is often the most important in applications? Yes, by the inverse power method: Multiply  $ u_0 $ by  $ A^{-1} $ instead of  $ A $. Since we never want to compute  $ A^{-1} $, we actually solve  $ Au_1 = u_0 $. By saving the  $ L $ U factors, the next step  $ Au_2 = u_1 $ is fast. Step  $ k $ has  $ Au_k = u_{k-1} $: