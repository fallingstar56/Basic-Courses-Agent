## Modular Arithmetic

Linear algebra is based on linear combinations of vectors. Now our vectors  $ (x_1, \ldots, x_n) $ are strings of integers limited to  $ x = 0, 1, \ldots, p - 1 $. All calculations produce these integers when we work “mod  $ p $”. This means: Every integer  $ y $ outside that range is divided by  $ p $ and  $ x $ is the remainder:

 $ y = qp + x \quad y \equiv x \left( \text{mod } p \right) \quad y \text{ divided by } p \text{ has remainder } x $

Addition mod 3  $ 10 \equiv 1 \pmod{3} $ and  $ 16 \equiv 1 \pmod{3} $ and  $ 10 + 16 \equiv 1 + 1 \pmod{3} $

I could add 10 + 16 and divide 26 by 3 to get the remainder 2.

Or I can just add remainders 1 + 1 to reach the same answer 2.

Addition mod 2  $ 11 \equiv 1 \pmod{2} $ and  $ 17 \equiv 1 \pmod{2} $ and  $ 11 + 17 = 28 \equiv 0 \pmod{2} $

The remainders added to  $ 1 + 1 $ but this is not 2. The final step was  $ 2 \equiv 0 \pmod{2} $.

Addition  $  \text{mod} \, p  $ is completely reasonable. So is  $  \text{multiplication} \, \text{mod} \, p  $. Here  $  p = 3  $:
 $  10 \equiv 1 \, (\text{mod} \, 3)  $ times  $  16 \equiv 1 \, (\text{mod} \, 3)  $ gives 1 times  $  1 \equiv 1  $   $  160 \equiv 1 \, (\text{mod} \, 3)  $
 $  5 \equiv 2 \, (\text{mod} \, 3)  $ times  $  8 \equiv 2 \, (\text{mod} \, 3)  $ gives 2 times  $  2 \equiv 1  $   $  40 \equiv 1 \, (\text{mod} \, 3)  $

Conclusion: We can safely add and multiply modulo  $ p $. So we can take linear combinations. This is the key operation in linear algebra. But can we divide?

In the real number field, the inverse is 1/y (for any number except y = 0). This means:

We found another real number z so that yz = 1. Invertibility is a requirement for a field.

Is inversion always possible mod p? For every number y = 1, ..., p - 1 can we find another number z = 1, ..., p - 1 so that yz ≡ 1 mod p?

The examples  $ 3^{-1} \equiv 4 \pmod{11} $ and  $ 2^{-1} \equiv 6 \pmod{11} $ and  $ 5^{-1} \equiv 9 \pmod{11} $ all succeed. Can you solve  $ 7z \equiv 1 \pmod{11} $? Inverting numbers will be the key to inverting matrices.

Let me show that inversion  $  \text{mod} \, p  $ has a problem when  $  p  $ is not a prime number. The example  $  p = 26  $ factors into 2 times 13. Then  $  y = 2  $ cannot have an inverse  $  z  $ ( $  \text{mod} \, 26  $). The requirement  $  2z \equiv 1  $ ( $  \text{mod} \, 26  $) is impossible to satisfy because  $  2z  $ and  $  26  $ are even.

Similarly 5 has no inverse z when p is 25. We can’t solve  $ 5z \equiv 1 \pmod{25} $. The number 5z - 1 is never going to be a multiple of 5, so it can’t be a multiple of 25.

Inversion of every y (0 < y < p) will be possible if and only if p is prime.

Inversion needs y, 2y, 3y, …, py to have different remainders when divided by p. If my and ny had the same remainder x then  $ (m - n)y $ would be divisible by p. The prime number p would have to divide either m - n or y. Both are impossible. So y, …, py have different remainders: One of those remainders must be x = 1.