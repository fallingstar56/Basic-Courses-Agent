## Operation Counts: Full Matrices

Here is a practical question about cost. How many separate operations are needed to solve  $ Ax = b $ by elimination? This decides how large a problem we can afford.

Look first at A, which changes gradually into U. When a multiple of row 1 is subtracted from row 2, we do n operations. The first is a division by the pivot, to find the multiplier  $ \ell $. For the other n - 1 entries along the row, the operation is a “multiply-subtract”. For convenience, we count this as a single operation. If you regard multiplying by  $ \ell $ and subtracting from the existing entry as two separate operations, multiply all our counts by 2.

The matrix A is n by n. The operation count applies to all n - 1 rows below the first. Thus it requires n times n - 1 operations, or  $ n^2 - n $, to produce zeros below the first pivot. Check: All  $ n^2 $ entries are changed, except the n entries in the first row.

When elimination is down to $k$ equations, the rows are shorter. We need only $k^2 - k$ operations (instead of $n^2 - n$) to clear out the column below the pivot. This is true for $1 \leq k \leq n$. The last step requires no operations ($1^2 - 1 = 0$); forward elimination is complete. The total count to reach $U$ is the sum of $k^2 - k$ over all values of $k$ from 1 to $n$:

 $$ (1^{2}+\cdots+n^{2})-(1+\cdots+n)=\frac{n(n+1)(2n+1)}{6}-\frac{n(n+1)}{2}=\frac{n^{3}-n}{3}. $$ 

Those are known formulas for the sum of the first $n$ numbers and their squares. Substituting $n = 100$ gives a million minus a hundred—then divide by 3. (That translates into one second on a workstation.) We will ignore $n$ in comparison with $n^{3}$, to reach our main conclusion:

The multiply-subtract count is  $ \frac{1}{3}n^{3} $ for forward elimination (A to U, producing L).

That means  $ \frac{1}{3}n^{3} $ multiplications and subtractions. Doubling n increases this cost by eight (because n is cubed). 100 equations are easy, 1000 are more expensive, 10000 dense equations are close to impossible. We need a faster computer or a lot of zeros or a new idea.

On the right side of the equations, the steps go much faster. We operate on single numbers, not whole rows. Each right side needs exactly  $ n^2 $ operations. Down and back up we are solving two triangular systems,  $ Lc = b $ forward and  $ Ux = c $ backward. In back substitution, the last unknown needs only division by the last pivot. The equation above it needs two operations—substituting  $ x_n $ and dividing by its pivot. The  $ k $th step needs  $ k $ multiply-subtract operations, and the total for back substitution is

 $$ 1+2+\cdots+n=\frac{n(n+1)}{2}\approx\frac{1}{2}n^{2}\quad operations. $$ 

The forward part is similar. The  $ n^2 $ total exactly equals the count for multiplying  $ A^{-1}b! $. This leaves Gaussian elimination with two big advantages over  $ A^{-1}b $:

1 Elimination requires  $ \frac{1}{3}n^3 $ multiply-subtracts, compared to  $ n^3 $ for  $ A^{-1} $

2 If A is banded so are L and U: by comparison  $ A^{-1} $ is full of nonzeros.