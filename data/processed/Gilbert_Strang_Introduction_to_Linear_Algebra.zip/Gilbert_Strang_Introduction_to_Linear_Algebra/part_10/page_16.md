 $$ \begin{array}{c|cccc}{{{Add}}}&{{{0}}}&{{{1}}}&{{{a}}}&{{{1+a}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{a}}}&{{{1+a}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{1+a}}}&{{{a}}} \\{{{a}}}&{{{a}}}&{{{1+a}}}&{{{0}}}&{{{1}}} \\{{{1+a}}}&{{{1+a}}}&{{{a}}}&{{{1}}}&{{{0}}} \\\end{array} $$ 

 $$ \begin{aligned}Multiply&\begin{vmatrix}{{{0}}}&{{{1}}}&{{{a}}}&{{{1+a}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{1}}}&{{{a}}}&{{{1+a}}} \\{{{a}}}&{{{0}}}&{{{a}}}&{{{1+a}}}&{{{1}}} \\{{{1+a}}}&{{{0}}}&{{{1+a}}}&{{{1}}}&{{{a}}} \\\end{vmatrix}\end{aligned} $$ 

Beyond $p = 2$, we have the fields $\mathbf{F}_p$ for all prime numbers $p$. They use addition and multiplication $mod$ $p$. They are alphabets for codes. They provide the components for vectors $\boldsymbol{v} = (f_1, \ldots, f_n)$ in the space $(\mathbf{F}_p)^n$. They provide the entries for matrices that multiply those vectors. These fields $\mathbf{F}_p$ are the most frequently used finite fields.

The only other finite fields have  $ p^k $ members. The example above of 0, 1, a, 1 + a had  $ 2^2 = 4 $ members. We will leave it there and get back safely to  $ \mathbf{R} $.

### Problem Set 10.7

1 If you multiply n whole numbers (even or odd) when is the answer odd? Translate into multiplication (mod 2): If you multiply 0's and 1's when is the answer 1?

2 If you add n whole numbers (even or odd) when is the sum of the numbers odd? Translate into adding 0's and 1's (mod 2). When do they add to 1?

3 (a) If  $ y_1 \equiv x_1 $ and  $ y_2 \equiv x_2 $, why is  $ y_1 + y_2 \equiv x_1 + x_2 $? All are mod p.

Suggestion:  $ y_1 = p q_1 + x_1 $ and  $ y_2 = p q_2 + x_2 $. Now add  $ y_1 + y_2 $.

(b) Can you be sure that  $ x_{1} + x_{2} $ is smaller than p? No. Give an example where there is a smaller x with  $ (y_{1} + y_{2}) = x \pmod{p} $.

4 $p = 39$ is not prime. Find a number $a$ that has no inverse $z$ (mod 39). This means that $az \equiv 1$ (mod 39) has no solution. Then find a 2 by 2 matrix $A$ that has no inverse matrix $Z$ (mod 39). This means that $AZ \equiv I$ (mod 39) has no solution.

5 Show that  $ y \equiv x \pmod{p} $ leads to  $ -y \equiv -x \pmod{p} $.

6 Find a matrix that has independent columns in  $ \mathbf{R}^2 $ but dependent columns (mod 5).

7 What are all the 2 by 2 matrices of 0's and 1's that are invertible (mod 2)?

8 Is the row space of A still orthogonal to the nullspace in modular arithmetic (mod 11)?

Are bases for those subspaces still bases (mod 11)?

9 (Hill's Cipher) Separate the message THISWHOLEBOOKISINCODE into blocks of 3 letters. Replace each letter by a number from 1 to 26 (normal order). Multiply each block by the 3 by 3 matrix L with 1's on and below the diagonal. What is the coded message (in numbers) and how would you decode it?

10 Suppose you know the original message (the plaintext). Suppose you also see the coded message. How would you start to discover the matrix in Hill's Cipher? For a very long message do you expect success?