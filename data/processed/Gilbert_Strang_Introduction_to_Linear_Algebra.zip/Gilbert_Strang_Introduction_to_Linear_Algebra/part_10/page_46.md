Now start with probabilities  $ p_i $ (never negative!) instead of samples. We find expected values instead of sample values. The variance  $ \sigma^2 $ is the crucial number in statistics.

Variance

 $$ \sigma^{2}=\mathrm{E}\left[(x-m)^{2}\right]=p_{1}(x_{1}-m)^{2}+\cdots+p_{n}(x_{n}-m)^{2}. $$ 

We are squaring the distance from the expected value  $ m = \mathrm{E}[x] $. We don’t have samples, only expectations. We know probabilities but we don’t know experimental outcomes.

Example 1 Find the variance  $ \sigma^{2} $ of the ages of college freshmen.

Solution The probabilities of ages  $ x_i = 17, 18, 19 $ were  $ p_i = 0.2 $ and 0.5 and 0.3. The expected value was  $ m = \sum p_i x_i = 18.1 $. The variance uses those same probabilities:

 $$ \begin{aligned}\sigma^{2}&=(0.2)(17-18.1)^{2}+(0.5)(18-18.1)^{2}+(0.3)(19-18.1)^{2}\\&=(0.2)(1.21)+(0.5)(0.01)+(0.3)(0.81)=0.49.\end{aligned} $$ 

The standard deviation is the square root  $ \sigma = 0.7 $.

This measures the spread of 17, 18, 19 around E[x], weighted by probabilities .2, .5, .3.

## Continuous Probability Distributions

Up to now we have allowed for $n$ possible outcomes $x_1, \ldots, x_n$. With ages 17, 18, 19, we only had $n = 3$. If we measure age in days instead of years, there will be a thousand possible ages (too many). Better to allow every number between 17 and 20—a continuum of possible ages. Then the probabilities $p_1, p_2, p_3$ for ages $x_1, x_2, x_3$ have to move to a probability distribution $p(x)$ for a whole continuous range of ages $17 \leq x \leq 20$.

The best way to explain probability distributions is to give you two examples. They will be the uniform distribution and the normal distribution. The first (uniform) is easy. The normal distribution is all-important.

Uniform distribution Suppose ages are uniformly distributed between 17.0 and 20.0. All ages between those numbers are “equally likely”. Of course any one exact age has no chance at all. There is zero probability that you will hit the exact number  $ x = 17.1 $ or  $ x = 17 + \sqrt{2} $. What you can truthfully provide (assuming our uniform distribution) is the chance  $ F(x) $ that a random freshman has age less than  $ x $:

The chance of age less than $x = 17$ is $F(17) = 0$ $x \leq 17$ won't happen

The chance of age less than $x = 20$ is $F(20) = 1$ $x \leq 20$ will happen

The chance of age less than $x$ is $F(x) = \frac{1}{3}(x - 17)$ $F$ goes from 0 to 1

That formula  $ F(x) = \frac{1}{3}(x - 17) $ gives  $ F = 0 $ at  $ x = 17 $; then  $ x \leq 17 $ won't happen. It gives  $ F(x) = 1 $ at  $ x = 20 $; then  $ x \leq 20 $ is sure. Between 17 and 20, the graph of the cumulative distribution  $ F(x) $ increases linearly for this uniform model.