### 11.2 Norms and Condition Numbers

How do we measure the size of a matrix? For a vector, the length is  $ \|x\| $. For a matrix, the norm is  $ \|A\| $. This word “norm” is sometimes used for vectors, instead of length. It is always used for matrices, and there are many ways to measure  $ \|A\| $. We look at the requirements on all “matrix norms” and then choose one.

Frobenius squared all the  $ |a_{ij}|^2 $ and added; his norm  $ \|A\|_F $ is the square root. This treats  $ A $ like a long vector with  $ n^2 $ components: sometimes useful, but not the choice here.

I prefer to start with a vector norm. The triangle inequality says that  $ \|x + y\| $ is not greater than  $ \|x\| + \|y\| $. The length of  $ 2x $ or  $ -2x $ is doubled to  $ 2\|x\| $. The same rules will apply to matrix norms:

 $$ \left\| \mathbf{A}+\mathbf{B} \right\|\leq \left\| \mathbf{A} \right\|+\left\| \mathbf{B} \right\| \quad and \quad \left\| \mathbf{c}\mathbf{A} \right\|=|\mathbf{c}||\mathbf{A}|. $$ 

The second requirements for a matrix norm are new, because matrices multiply. The norm  $ \|A\| $ controls the growth from x to Ax, and from B to AB:

Growth factor  $ \|A\| $

 $$ \left\| \mathbf{A}\mathbf{x} \right\|\leq \left\| \mathbf{A} \right\| \left\| \mathbf{x} \right\| \quad and \quad \left\| \mathbf{A}\mathbf{B} \right\|\leq \left\| \mathbf{A} \right\| \left\| \mathbf{B} \right\|. $$ 

This leads to a natural way to define  $ \|A\| $, the norm of a matrix:

The norm of A is the largest ratio

 $$ \left\|A\boldsymbol{x}\right\|/\left\|x\right\|: $$ 

 $$ \|A\|=\max_{\boldsymbol{x}\neq\mathbf{0}}\frac{\|A\boldsymbol{x}\|}{\|x\|}. $$ 

 $ \|Ax\|/\|x\| $ is never larger than  $ \|A\| $ (its maximum). This says that  $ \|Ax\|\leq\|A\|\|x\| $.

Example 1 If $A$ is the identity matrix $I$, the ratios are $\|x\|/\|x\|$. Therefore $\|I\| = 1$. If $A$ is an orthogonal matrix $Q$, lengths are again preserved: $\|Qx\| = \|x\|$. The ratios still give $\|Q\| = 1$. An orthogonal $Q$ is good to compute with: errors don't grow.

Example 2 The norm of a diagonal matrix is its largest entry (using absolute values):

 $$ A=\begin{bmatrix}{{{2}}}&{{{0}}} \\{{{0}}}&{{{3}}}\end{bmatrix}\quad has norm\quad\|A\|=3.\quad The eigenvector\quad\boldsymbol{x}=\begin{bmatrix}{{{0}}} \\{{{1}}}\end{bmatrix}\quad has\quad A\boldsymbol{x}=3\boldsymbol{x}. $$ 

The eigenvalue is 3. For this A (but not all A), the largest eigenvalue equals the norm.

For a positive definite symmetric matrix the norm is  $ \|A\| = \lambda_{\max}(A) $.

Choose $x$ to be the eigenvector with maximum eigenvalue. Then $\|Ax\|/\|x\|$ equals $\lambda_{\max}$. The point is that no other $x$ can make the ratio larger. The matrix is $A = Q\Lambda Q^\top$, and the orthogonal matrices $Q$ and $Q^\top$ leave lengths unchanged. So the ratio to maximize is really $\|\Lambda x\|/\|x\|$. The norm is the largest eigenvalue in the diagonal $\Lambda$.