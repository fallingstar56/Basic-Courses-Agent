A band structure is very common in practice, when the matrix reflects connections between near neighbors:  $ a_{13} = 0 $ and  $ a_{14} = 0 $ because 1 is not a neighbor of 3 and 4.

We close with counts for Gauss-Jordan and Gram-Schmidt-Householder:

 $ A^{-1} $ costs  $ n^{3} $ multiply-subtract steps.

QR costs  $ \frac{2}{3}n^{3} $ steps.

In  $ AA^{-1} = I $, the  $ j $th column of  $ A^{-1} $ solves  $ Ax_j = j $th column of  $ I $. The left side costs  $ \frac{1}{3}n^3 $ as usual. (This is a one-time cost!  $ L $ and  $ U $ are not repeated.) The special saving for the  $ j $th column of  $ I $ comes from its first  $ j - 1 $ zeros. No work is required on the right side until elimination reaches row  $ j $. The forward cost is  $ \frac{1}{2}(n - j)^2 $ instead of  $ \frac{1}{2}n^2 $. Summing over  $ j $, the total for forward elimination on the  $ n $ right sides is  $ \frac{1}{6}n^3 $. The final multiply-subtract count for  $ A^{-1} $ is  $ n^3 $ if we actually want the inverse:

 $$ \begin{array}{r l}{\mathrm{F o r}A^{-1}}&{{}\quad\frac{n^{3}}{3}\left(L\mathrm{~a n d~}U\right)+\frac{n^{3}}{6}\left(\mathrm{f o r w a r d}\right)+n\bigg(\frac{n^{2}}{2}\bigg)\mathrm{~(b a c k~s u b s t i t u t i o n s~}=n^{3}.}\end{array} $$ 

Orthogonalization (A to Q): The key difference from elimination is that each multiplier is decided by a dot product. That takes n operations, where elimination just divides by the pivot. Then there are n “multiply-subtract” operations to remove from column k its projection along column j < k (see Section 4.4). The combined cost is 2n where for elimination it is n. This factor 2 is the price of orthogonality. We are changing a dot product to zero where elimination changes an entry to zero.

Caution To judge a numerical algorithm, it is not enough to count the operations. Beyond "flop counting" is a study of stability (Householder wins) and the flow of data.

## Reordering Sparse Matrices

For band matrices with constant width w, the row ordering is optimal. But for most sparse matrices in real computations, the width of the band is not constant and there are many zeros inside the band. Those zeros can fill in as elimination proceeds—they are lost. We need to renumber the equations to reduce fill-in, and thereby speed up elimination.

Generally speaking, we want to move zeros to early rows and columns. Later rows and columns are shorter anyway. The “approximate minimum degree” algorithm in sparse MATLAB is greedy—it chooses the row to eliminate without counting all the consequences. We may reach a nearly full matrix near the end, but the total operation count to reach LU is still much smaller. To find the absolute minimum of nonzeros in L and U is an NP-hard problem, much too expensive, and  $ \text{amd} $ is a good compromise.

Fill-in is famous when each point on a square grid is connected to its four nearest neighbors. It is impossible to number all the gridpoints so that neighbors stay together! If we number by rows of the grid, there is a long wait to come around to the gridpoint above.