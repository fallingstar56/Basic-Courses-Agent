Remember: The list is infinite. The Fourier series is an infinite series. We avoided the vector  $ \boldsymbol{v} = (1, 1, 1, \ldots) $ because its length is infinite, now we avoid a function like  $ \frac{1}{2} + \cos x + \cos 2x + \cos 3x + \cdots $. (Note: This is  $ \pi $ times the famous delta function  $ \delta(x) $). It is an infinite “spike” above a single point. At  $ x = 0 $ its height  $ \frac{1}{2} + 1 + 1 + \cdots $ is infinite. At all points inside  $ 0 < x < 2\pi $ the series adds in some average way to zero.) The integral of  $ \delta(x) $ is 1. But  $ \int \delta^2(x) = \infty $, so delta functions are not allowed into Hilbert space.

Compute the length of a typical sum f(x):

 $$ \begin{align*}(f,f)&=\int_{0}^{2\pi}(a_{0}+a_{1}\cos x+b_{1}\sin x+a_{2}\cos2x+\cdots)^{2}dx\\&=\int_{0}^{2\pi}(a_{0}^{2}+a_{1}^{2}\cos^{2}x+b_{1}^{2}\sin^{2}x+a_{2}^{2}\cos^{2}2x+\cdots)dx\\\|f\|^{2}&=2\pi a_{0}^{2}+\pi(a_{1}^{2}+b_{1}^{2}+a_{2}^{2}+\cdots).\end{align*} $$ 

The step from line 1 to line 2 used orthogonality. All products like  $ \cos x \cos 2x $ integrate to give zero. Line 2 contains what is left—the integrals of each sine and cosine squared. Line 3 evaluates those integrals. (The integral of  $ 1^2 $ is  $ 2\pi $, when all other integrals give  $ \pi $.) If we divide by their lengths, our functions become orthonormal:

 $$ \frac{1}{\sqrt{2\pi}},\frac{\cos x}{\sqrt{\pi}},\frac{\sin x}{\sqrt{\pi}},\frac{\cos2x}{\sqrt{\pi}},\cdots is an orthonormal basis for our function space. $$ 

These are unit vectors. We could combine them with coefficients  $ A_0, A_1, B_1, A_2, \ldots $ to yield a function  $ F(x) $. Then the  $ 2\pi $ and the  $ \pi $'s drop out of the formula for length.

Function length = vector length

 $$ \|F\|^{2}=(F,F)=A_{0}^{2}+A_{1}^{2}+B_{1}^{2}+A_{2}^{2}+\cdots. $$ 

Here is the important point, for  $ f(x) $ as well as  $ F(x) $. The function has finite length exactly when the vector of coefficients has finite length. Fourier series gives us a perfect match between the Hilbert spaces for functions and for vectors. The function is in  $ L^2 $, its Fourier coefficients are in  $ \ell^2 $.

The function space contains $f(x)$ exactly when the Hilbert space contains the vector $\boldsymbol{v} = (a_{0}, a_{1}, b_{1}, \ldots)$ of Fourier coefficients of $f(x)$. Both must have finite length.

Example 3 Suppose $f(x)$ is a “square wave,” equal to $1$ for $0 \leq x < \pi$. Then $f(x)$ drops to $-1$ for $\pi \leq x < 2\pi$. The $+1$ and $-1$ repeat forever. This $f(x)$ is an odd function like the sines, and all its cosine coefficients are zero. We will find its Fourier series, containing only sines:

Square wave

 $$ f(x)=\frac{4}{\pi}\left[\frac{\sin x}{1}+\frac{\sin3x}{3}+\frac{\sin5x}{5}+\cdots\right]. $$ 

The length of this function is  $ \sqrt{2\pi} $, because at every point  $ (f(x))^2 $ is  $ (-1)^2 $ or  $ (+1)^2 $:

 $$ \|f\|^{2}=\int_{0}^{2\pi}\left(f(x)\right)^{2}d x=\int_{0}^{2\pi}1d x=2\pi. $$ 