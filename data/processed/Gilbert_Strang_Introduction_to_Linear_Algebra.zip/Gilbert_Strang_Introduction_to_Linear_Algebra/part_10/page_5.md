### 10.6 Computer Graphics

Computer graphics deals with images. The images are moved around. Their scale is changed. Three dimensions are projected onto two dimensions. All the main operations are done by matrices—but the shape of these matrices is surprising.

The transformations of three-dimensional space are done with 4 by 4 matrices. You would expect 3 by 3. The reason for the change is that one of the four key operations cannot be done with a 3 by 3 matrix multiplication. Here are the four operations:

Translation (shift the origin to another point  $ P_{0} = (x_{0}, y_{0}, z_{0}) $)

Rescaling (by c in all directions or by different factors  $ c_{1}, c_{2}, c_{3} $)

Rotation (around an axis through the origin or an axis through  $ P_{0} $)

Projection (onto a plane through the origin or a plane through  $ P_{0} $).

Translation is the easiest—just add  $ (x_{0}, y_{0}, z_{0}) $ to every point. But this is not linear! No 3 by 3 matrix can move the origin. So we change the coordinates of the origin to  $ (0, 0, 0, 1) $. This is why the matrices are 4 by 4. The “homogeneous coordinates” of the point  $ (x, y, z) $ are  $ (x, y, z, 1) $ and we now show how they work.

1. Translation Shift the whole three-dimensional space along the vector  $ v_0 $. The origin moves to  $ (x_0, y_0, z_0) $. This vector  $ v_0 $ is added to every point  $ v $ in  $ \mathbf{R}^3 $. Using homogeneous coordinates, the 4 by 4 matrix  $ T $ shifts the whole space by  $ v_0 $:

Translation matrix

 $$ \boldsymbol{T}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{x_{0}}}}&{{{y_{0}}}}&{{{z_{0}}}}&{{{1}}}\end{bmatrix}. $$ 

Important: Computer graphics works with row vectors. We have row times matrix instead of matrix times column. You can quickly check that  $ [0\ 0\ 0\ 1]T = [x_0\ y_0\ z_0\ 1] $.

To move the points  $ (0,0,0) $ and  $ (x,y,z) $ by  $ v_{0} $, change to homogeneous coordinates  $ (0,0,0,1) $ and  $ (x,y,z,1) $. Then multiply by T. A row vector times T gives a row vector. Every v moves to  $ v + v_{0} $:  $ [x\ y\ z\ 1] $  $ T = [x + x_{0}\ y + y_{0}\ z + z_{0}\ 1] $.

The output tells where any $v$ will move. (It goes to $v + v_0$.) Translation is now achieved by a matrix, which was impossible in $\mathbf{R}^3$.

2. Scaling To make a picture fit a page, we change its width and height. A copier will rescale a figure by 90%. In linear algebra, we multiply by .9 times the identity matrix. That matrix is normally 2 by 2 for a plane and 3 by 3 for a solid. In computer graphics, with homogeneous coordinates, the matrix is one size larger:

Rescale the plane:

 $$ \begin{aligned}&S=\begin{bmatrix} \\{{{.9}}} \\{{{.9}}} \\{{{1}}} \\\end{bmatrix}\\ \end{aligned} $$ 

Rescale a solid:

 $$ S=\begin{bmatrix}{{{c}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{c}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{c}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 