Note 2 The norm  $ \|A\| $ equals the largest singular value  $ \sigma_{\max} $ of A. The singular values  $ \sigma_{1}, \ldots, \sigma_{r} $ are the square roots of the positive eigenvalues of  $ A^{\mathrm{T}}A $. So certainly  $ \sigma_{\max} = (\lambda_{\max})^{1/2} $. Since U and V are orthogonal in  $ A = U \Sigma V^{\mathrm{T}} $, the norm is  $ \|A\| = \sigma_{\max} $.

## The Condition Number of A

Section 9.1 showed that roundoff error can be serious. Some systems are sensitive, others are not so sensitive. The sensitivity to error is measured by the condition number. This is the first chapter in the book which intentionally introduces errors. We want to estimate how much they change x.

The original equation is  $ Ax = b $. Suppose the right side is changed to  $ b + \Delta b $ because of roundoff or measurement error. The solution is then changed to  $ x + \Delta x $. Our goal is to estimate the change  $ \Delta x $ in the solution from the change  $ \Delta b $ in the equation. Subtraction gives the error equation  $ A(\Delta x) = \Delta b $:

 $$ \begin{aligned}Subtract\ A\boldsymbol{x}=\boldsymbol{b}\ from\ A(\boldsymbol{x}+\Delta\boldsymbol{x})=\boldsymbol{b}+\Delta\boldsymbol{b}\quad to find\quad A(\Delta\boldsymbol{x})=\Delta\boldsymbol{b}.\end{aligned} $$ 

The error is  $ \Delta x = A^{-1} \Delta b $. It is large when  $ A^{-1} $ is large (then  $ A $ is nearly singular). The error  $ \Delta x $ is especially large when  $ \Delta b $ points in the worst direction—which is amplified most by  $ A^{-1} $. The worst error has  $ \|\Delta x\| = \|A^{-1}\| \|\Delta b\| $.

This error bound  $ \|A^{-1}\| $ has one serious drawback. If we multiply  $ A $ by 1000, then  $ A^{-1} $ is divided by 1000. The matrix looks a thousand times better. But a simple rescaling cannot change the reality of the problem. It is true that  $ \Delta x $ will be divided by 1000, but so will the exact solution  $ x = A^{-1}b $. The relative error  $ \|\Delta x\|/\|x\| $ will stay the same. It is this relative change in  $ x $ that should be compared to the relative change in  $ b $.

Comparing relative errors will now lead to the “condition number”  $ c = \|A\|\|A^{-1}\| $. Multiplying A by 1000 does not change this number, because  $ A^{-1} $ is divided by 1000 and the condition number c stays the same. It measures the sensitivity of  $ Ax = b $.

The solution error is less than c =  $ \|A\| $  $ \|A^{-1}\| $ times the problem error:

Condition number c

 $$ \frac{\left\|\Delta x\right\|}{\left\|x\right\|}\leq c\frac{\left\|\Delta b\right\|}{\left\|b\right\|}. $$ 

If the problem error is ∆A (error in A instead of b), still c controls ∆x:

Error  $ \Delta A $ in A

 $$ \frac{\left\|\Delta\boldsymbol{x}\right\|}{\left\|\boldsymbol{x}+\Delta\boldsymbol{x}\right\|}\leq c\frac{\left\|\Delta A\right\|}{\left\|A\right\|}. $$ 