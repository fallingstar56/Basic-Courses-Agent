## Roundoff Error and Partial Pivoting

Up to now, any pivot (nonzero of course) was accepted. In practice a small pivot is dangerous. A catastrophe can occur when numbers of different sizes are added. Computers keep a fixed number of significant digits (say three decimals, for a very weak machine). The sum 10,000 + 1 is rounded off to 10,000. The “1” is completely lost. Watch how that changes the solution to this problem:

 $$ \begin{array}{r l r l r l}{{0.0001}u+v=1}&&{\quad}&{\mathrm{s t a r t s~w i t h~c o e f f i c i e n t~m a t r i x}}&&{A=\left[\begin{matrix}{.0001}&{1}\\ {-1}&{1}\end{matrix}\right].}&&{}\\ {-u+v=0}&&{}&&{}\end{array} $$ 

If we accept .0001 as the pivot, elimination adds 10,000 times row 1 to row 2. Roundoff leaves

 $$ 10,000v=10,000\qquad{\mathrm{i n s t e a d~o f}}\qquad10,001v=10,000. $$ 

The computed answer v = 1 is near the true v = .9999. But then back substitution puts the wrong v = 1 into the equation for u:

 $$ .0001\;u+1=1\qquad\mathrm{i n s t e a d~o f}\qquad.0001\;u+.9999=1. $$ 

The first equation gives u = 0. The correct answer (look at the second equation) is u = 1.000. By losing the “1” in the matrix, we have lost the solution. The small change from 10,001 to 10,000 has changed the answer from u = 1 to u = 0 (100% error!). If we exchange rows, even this weak computer finds an answer that is correct to 3 places:

 $$ \begin{array}{ccc}-u+v=0& \longrightarrow& -u+v=0\\.0001u+v=1& & v=1\end{array}\quad\begin{array}{ccc}u=1\\ \longrightarrow& \\ v=1.\end{array} $$ 

The original pivots were .0001 and 10,000—badly scaled. After a row exchange the exact pivots are -1 and 1.0001—well scaled. The computed pivots -1 and 1 come close to the exact values. Small pivots bring numerical instability, and the remedy is partial pivoting. Here is our strategy when we reach and search column k for the best available pivot:

Choose the largest number in row k or below. Exchange its row with row k.

The strategy of complete pivoting looks also in later columns for the largest pivot. It exchanges columns as well as rows. This expense is seldom justified, and all major codes use partial pivoting. Multiplying a row or column by a scaling constant can also be very worthwhile. If the first equation above is  $ u + 10{,}000v = 10{,}000 $ and we don't rescale, then 1 looks like a good pivot and we would miss the essential row exchange.

For positive definite matrices, row exchanges are not required. It is safe to accept the pivots as they appear. Small pivots can occur, but the matrix is not improved by row exchanges. When its condition number is high, the problem is in the matrix and not in the code. In this case the output is unavoidably sensitive to the input.

The reader now understands how a computer actually solves Ax = b—by elimination with partial pivoting. Compared with the theoretical description—find  $ A^{-1} $ and multiply  $ A^{-1}b $—the details took time. But in computer time, elimination is much faster. I believe that elimination is also the best approach to the algebra of row spaces and nullspaces.