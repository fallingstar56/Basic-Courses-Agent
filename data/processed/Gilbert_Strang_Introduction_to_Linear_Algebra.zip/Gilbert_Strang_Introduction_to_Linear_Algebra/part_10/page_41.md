For any 2 by 2 matrix  $ \begin{bmatrix} a & b \\ c & d \end{bmatrix} $ show that  $ |\lambda|_{\max} $ equals  $ |bc/ad| $ for Gauss-Seidel and  $ |bc/ad|^{1/2} $ for Jacobi. We need  $ ad \neq 0 $ for the matrix  $ S $ to be invertible.

Write a computer code (MATLAB or other) for the Gauss-Seidel method. You can define $S$ and $T$ from $A$, or set up the iteration loop directly from the entries $a_{ij}$. Test it on the $-1, 2, -1$ matrices $A$ of order $10, 20, 50$ with $\boldsymbol{b} = (1, 0, \ldots, 0)$.

Gauss-Seidel

The Gauss-Seidel iteration at component $i$ uses earlier parts of $x^{new}$:

If every  $ x_i^{new} = x_i^{old} $ how does this show that the solution  $ x $ is correct? How does the formula change for Jacobi's method? For SOR insert  $ \omega $ outside the parentheses.

 $$ x_{i}^{\mathrm{new}}=x_{i}^{\mathrm{old}}+\frac{1}{a_{ii}}\Big(b_{i}-\sum_{j=1}^{i-1}a_{ij}x_{j}^{\mathrm{new}}-\sum_{j=i}^{n}a_{ij}x_{j}^{\mathrm{old}}\Big). $$ 

Divide equation (10) by  $ \lambda_1^k $ and explain why  $ |\lambda_2/\lambda_1| $ controls the convergence of the power method. Construct a matrix  $ A $ for which this method does not converge.

The Markov matrix  $ A = \begin{bmatrix} \cdot9 \cdot3 \\ \cdot1 \cdot7 \end{bmatrix} $ has  $ \lambda = 1 $ and  $ .6 $, and the power method  $ u_k = A^k u_0 $ converges to  $ \begin{bmatrix} \cdot75 \\ \cdot25 \end{bmatrix} $. Find the eigenvectors of  $ A^{-1} $. What does the inverse power method  $ u_{-k} = A^{-k} u_0 $ converge to (after you multiply by  $ .6^k $?

The tridiagonal matrix of size $n-1$ with diagonals $-1,2,-1$ has eigenvalues $\lambda_{j}=2-2\cos(j\pi/n)$. Why are the smallest eigenvalues approximately $(j\pi/n)^{2}$? The inverse power method converges at the speed $\lambda_{1}/\lambda_{2}\approx1/4$.

For  $ A = \begin{bmatrix} 2 & -1 \\ -1 & 2 \end{bmatrix} $ apply the power method  $ u_{k+1} = Au_k $ three times starting with  $ u_0 = \begin{bmatrix} 1 \\ 0 \end{bmatrix} $. What eigenvector is the power method converging to?

For $A = -1$, $2, -1$ matrix, apply the inverse power method $u_{k+1} = A^{-1} u_k$ three times with the same $u_0$. What eigenvector are the $u_k$'s approaching?

In the QR method for eigenvalues when $A$ is shifted to make $A_{22} = 0$, show that the 2, 1 entry drops from $\sin \theta$ in $A = QR$ to $-\sin^3 \theta$ in $RQ$. (Compute $R$ and $RQ$) This “cubic convergence” makes the method a success:

 $$ \boldsymbol{A}=\begin{bmatrix}\cos\theta&\sin\theta\\ \sin\theta&0\end{bmatrix}=\boldsymbol{Q}\boldsymbol{R}=\begin{bmatrix}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{bmatrix}\begin{bmatrix}1&?\\ 0&?\end{bmatrix}. $$ 

If $A$ is an orthogonal matrix, its $QR$ factorization has $Q = \underline{\qquad}$ and $R = \underline{\qquad}$. Therefore $RQ = \underline{\qquad}$. These are among the rare examples when the $QR$ method goes nowhere.

18 The shifted QR method factors  $ A - cI $ into QR. Show that the next matrix  $ A_1 = RQ + cI $ equals  $ Q^{-1}AQ $. Therefore  $ A_1 $ has the ___ eigenvalues as  $ A $ (but  $ A_1 $ is closer to triangular).