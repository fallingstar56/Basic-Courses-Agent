Now we attack the  $ (3,1) $ entry. The rotation will be in rows and columns 3 and 1. The numbers  $ \cos\theta $ and  $ \sin\theta $ are determined from 150 and 200, instead of 90 and 120.

 $$ Q_{31}Q_{21}A=\begin{bmatrix}{{{.6}}}&{{{0}}}&{{{.8}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{-.8}}}&{{{0}}}&{{{.6}}}\end{bmatrix}\begin{bmatrix}{{{150}}}&{{{\cdot}}}&{{{\cdot}}} \\{{{0}}}&{{{\cdot}}}&{{{\cdot}}} \\{{{200}}}&{{{\cdot}}}&{{{\cdot}}}\end{bmatrix}=\begin{bmatrix}{{{250}}}&{{{-125}}}&{{{250}}} \\{{{0}}}&{{{75}}}&{{{-225}}} \\{{{0}}}&{{{100}}}&{{{325}}}\end{bmatrix}. $$ 

One more step to $R$. The $(3,2)$ entry has to go. The numbers $\cos\theta$ and $\sin\theta$ now come from 75 and 100. The rotation is now in rows and columns 2 and 3:

 $$ Q_{32}Q_{31}Q_{21}A=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{.6}}}&{{{.8}}} \\{{{0}}}&{{{-.8}}}&{{{.6}}}\end{bmatrix}\begin{bmatrix}{{{250}}}&{{{-125}}}&{{{\cdot}}} \\{{{0}}}&{{{75}}}&{{{\cdot}}} \\{{{0}}}&{{{100}}}&{{{\cdot}}}\end{bmatrix}=\begin{bmatrix}{{{250}}}&{{{-125}}}&{{{250}}} \\{{{0}}}&{{{125}}}&{{{125}}} \\{{{0}}}&{{{0}}}&{{{375}}}\end{bmatrix}. $$ 

We have reached the upper triangular $R$. What is $Q$? Move the plane rotations $Q_{ij}$ to the other side to find $A = QR$—just as you moved the elimination matrices $E_{ij}$ to the other side to find $A = LU$:

 $$ Q_{32}Q_{31}Q_{21}A=R\qquad means\qquad A=(Q_{21}^{-1}Q_{31}^{-1}Q_{32}^{-1})R=QR. $$ 

The inverse of each  $ Q_{ij} $ is  $ Q_{ij}^{\mathrm{T}} $ (rotation through  $ -\theta $). The inverse of  $ E_{ij} $ was not an orthogonal matrix! L U and QR are similar but L and Q are not the same.

Householder reflections are faster than rotations because each one clears out a whole column below the diagonal. Watch how the first column  $ a_{1} $ of A becomes column  $ r_{1} $ of R:

 $$ \begin{array}{r l r l r l r}{\mathrm{R e f l e c t i o n~b y~}H_{1}}&{}&{H_{1}\;a_{1}}&{=\left[\begin{array}{c}{\|a_{1}\|}\\ {0}\\ {.}\\ {0}\end{array}\right]}&{\mathrm{o r}}&{\left[\begin{array}{c}{-\|a_{1}\|}\\ {0}\\ {.}\\ {0}\end{array}\right]}&{=}&{r_{1}}&{.}\end{array} $$ 

The length was not changed, and  $ u_1 $ is in the direction of  $ a_1 - r_1 $. We have  $ n - 1 $ entries in the unit vector  $ u_1 $ to get  $ n - 1 $ zeros in  $ r_1 $. (Rotations had one angle  $ \theta $ to get one zero.) When we reach column  $ k $, we have  $ n - k $ available choices in the unit vector  $ u_k $. This leads to  $ n - k $ zeros in  $ r_k $. We just store the  $ u $'s and  $ r $'s to know the final  $ Q $ and  $ R $:

 $$ \mathbf{I n v e r s e~o f~}H_{i}\mathbf{i s~}H_{i}\quad(H_{n-1}\ldots H_{1})A=R\quad\mathbf{m e a n s}\quad A=(H_{1}\ldots H_{n-1})R=Q R. $$ 

This is how LAPACK improves on 19th century Gram-Schmidt. Q is exactly orthogonal.

Section 11.3 explains how  $ A = QR $ is used in the other big computation of linear algebra—the eigenvalue problem. The factors  $ QR $ are reversed to give  $ A_1 = RQ $ which is  $ Q^{-1}AQ $. Since  $ A_1 $ is similar to  $ A $, the eigenvalues are unchanged. Then  $ A_1 $ is factored into  $ Q_1R_1 $, and reversing the factors gives  $ A_2 $. Amazingly, the entries below the diagonal get smaller in  $ A_1, A_2, A_3, \ldots $ and we can identify the eigenvalues. This is the “QR method” for  $ Ax = \lambda x $, a big success of numerical linear algebra.