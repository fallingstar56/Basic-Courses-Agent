The zero mean was easy because we are integrating an odd function. Changing x to -x shows that “integral = -integral”. So that integral must be m = 0.

The other two integrals apply the idea in Problem 12 to reach 1. Figure 12.2 shows a graph of  $ p(x) $ for the normal distribution  $ \mathbf{N}(0, \sigma) $ and also its cumulative distribution  $ F(x) = \text{integral of } p(x) $. From the symmetry of  $ p(x) $ you see mean = zero. From  $ F(x) $ you see a very important practical approximation for opinion polling:

The probability that a random sample falls between  $ -\sigma $ and  $ \sigma $ is  $ F(\sigma) - F(-\sigma) \approx \frac{2}{3} $.

 $$ \begin{array}{c} This is because\int\limits_{-\sigma}^{\sigma}p(x)dx equals\int\limits_{-\infty}^{\sigma}p(x)dx-\int\limits_{-\infty}^{-\sigma}p(x)dx=F(\sigma)-F(-\sigma).\end{array} $$ 

Similarly, the probability that a random $x$ lies between $-2\sigma$ and $2\sigma$ ("less than two standard deviations from the mean") is $F(2\sigma) - F(-2\sigma) \approx 0.95$. If you have an experimental result further than $2\sigma$ from the mean, it is fairly sure to be not accidental: chance = 0.05. Drug tests may look for a tighter confirmation, like probability 0.001. Searching for the Higgs boson used a hyper-strict test of $5\sigma$ deviation from pure accident.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_188_512_494_738.jpg" alt="Image" width="28%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_499_505_912_737.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">Figure 12.2: The standard normal distribution  $ p(x) $ has mean m = 0 and  $ \sigma = 1 $.</div>


The normal distribution with any mean m and standard deviation  $ \sigma $ comes by shifting and stretching the standard N  $ (0,1) $. Shift x to x - m. Stretch x - m to  $ (x - m)/\sigma $.

Gaussian density  $ p(x) $

Normal distribution N(m,  $ \sigma $)

 $$ p(x)=\frac{1}{\sigma\sqrt{2\pi}}e^{-(x-m)^{2}/2\sigma^{2}} $$ 

The integral of  $ p(x) $ is  $ F(x) $—the probability that a random sample will fall below x. The differential  $ p(x)\,dx = F(x + dx) - F(x) $ is the probability that a random sample will fall between x and  $ x + dx $. There is no simple formula to integrate  $ e^{-x^2/2} $, so this cumulative distribution  $ F(x) $ is computed and tabulated very carefully.