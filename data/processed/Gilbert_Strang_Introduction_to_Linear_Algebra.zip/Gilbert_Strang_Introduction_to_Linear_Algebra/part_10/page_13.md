## The Enigma Machine and the Hill Cipher

Lester Hill published his cipher (his system for encoding and decoding) in the American Mathematical Monthly (1929). The idea was simple, but in some way it started the transition of cryptography from linguistics to mathematics. Codes up to that time mainly mixed up alphabets and rearranged messages. The Enigma code used by the German Navy in World War II was a giant advance—using machines that look to us like primitive computers. The English set up Bletchley Park to break Enigma. They hired puzzle solvers and language majors. And by good luck they also happened to get Alan Turing.

I don't know if you have seen the movie about him: The Imitation Game. A lot of it is unrealistic (like Good Will Hunting and A Beautiful Mind at MIT). But the core idea of breaking the Enigma code was correct, using human weaknesses in the encoding and broadcasting. The German naval command openly sent out their coded orders—knowing that the codes were too complicated to break (if it hadn't been for those weaknesses). The codebreaking required English electronics to undo the German electronics. It also required genius.

Alan Turing was surely a genius—England’s most exceptional mathematician. His life was ultimately tragic and he ended it in 1954. The biography by Andrew Hodges is excellent. Turing arrived at Bletchley Park the day after Poland was invaded. It is to Winston Churchill’s credit that he gave fast and full support when his support was needed.

The Enigma Machine had gears and wheels. The Hill Cipher only needs a matrix. That is the code to be explained now, using linear algebra. You will see how decoding involved inverse matrices. All steps use modular arithmetic, multiplying and inverting mod p.

I will follow the neat exposition of Professor Spickler of Salisbury State University, which he made available on the Web: facultyfp.salisbury.edu/despickler/personal/index.asp

## Modular Arithmetic with Matrices

Addition, subtraction, and multiplication are all we need for Ax (matrix times vector). To multiply mod p we can multiply the integers in A times the integers in x as usual—and then replace every entry of Ax by its value mod p.

Key questions: When can we solve  $ A\boldsymbol{x} \equiv \boldsymbol{b} (\mathrm{mod} p) $? Do we still have the four subspaces  $ C(A), N(A), C(A^{\mathrm{T}}), N(A^{\mathrm{T}}) $? Are they still orthogonal in pairs? Is there still an inverse matrix mod p whenever the determinant of A is nonzero mod p? I am happy to say that the last three answers are yes (but the inverse question requires p to be a prime number).

We can find  $ A^{-1} (\text{mod } p) $ by Gauss-Jordan elimination, reducing  $ [A\ I] $ to  $ [I\ A^{-1}] $ as in Section 2.5. Or we can use determinants and the cofactor matrix  $ C $ in the formula  $ A^{-1} = (\det A)^{-1} C^\text{T} $. I will work  $ mod\ 3 $ with a 2 by 2 integer matrix  $ A $:

 $$ \left[\begin{array}{l l}{{{A}}}&{{{I}}}\end{array}\right]=\left[\begin{array}{l l l}{{{2}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{2}}}&{{{1}}}&{{{0}}}&{{{1}}}\end{array}\right]\rightarrow\left[\begin{array}{l l l}{{{2}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{1}}}\end{array}\right]\rightarrow\begin{array}{l l}{{{\text{multiply row 1}}}}&{{{\rightarrow}}} \\{{{\text{by }2^{-1}\equiv2}}}&{{{\rightarrow}}}\end{array}\left[\begin{array}{l l l}{{{1}}}&{{{0}}}&{{{2}}}&{{{\mathbf{0}}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{\mathbf{1}}}}\end{array}\right]=\left[\begin{array}{l l}{{{I}}}&{{{A^{-1}}}}\end{array}\right] $$ 