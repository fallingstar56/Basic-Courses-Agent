At $x = 0$ the sines are zero and the Fourier series gives zero. This is half way up the jump from $-1$ to $+1$. The Fourier series is also interesting when $x = \frac{\pi}{2}$. At this point the square wave equals 1, and the sines in (8) alternate between $+1$ and $-1$:

Formula for  $ \pi $

 $$ 1=\frac{4}{\pi}\Big(1-\frac{1}{3}+\frac{1}{5}-\frac{1}{7}+\cdots\Big). $$ 

Multiply by π to find a magical formula 4(1 − 1/3 + 1/5 − 1/7 + …) for that famous number.

The Fourier Coefficients

How do we find the $a$'s and $b$'s which multiply the cosines and sines? For a given function $f(x)$, we are asking for its Fourier coefficients $a_{k}$ and $b_{k}$:

Fourier series

 $$ f(x)=a_{0}+a_{1}\cos x+b_{1}\sin x+a_{2}\cos2x+\cdots. $$ 

Here is the way to find  $ a_{1} $. Multiply both sides by  $ \cos x $. Then integrate from 0 to  $ 2\pi $. The key is orthogonality! All integrals on the right side are zero, except for  $ \cos^{2}x $:

For coefficient  $ a_{1} $

 $$ \int_{0}^{2\pi}f(x)\cos x dx=\int_{0}^{2\pi}a_{1}\cos^{2}x dx=\pi a_{1}. $$ 

Divide by  $ \pi $ and you have  $ a_1 $. To find any other  $ a_k $, multiply the Fourier series by  $ \cos kx $. Integrate from 0 to  $ 2\pi $. Use orthogonality, so only the integral of  $ a_k \cos^2 kx $ is left. That integral is  $ \pi a_k $, and divide by  $ \pi $:

 $$ a_{k}=\frac{1}{\pi}\int_{0}^{2\pi}f(x)\cos kx\,dx\qquad and similarly\qquad b_{k}=\frac{1}{\pi}\int_{0}^{2\pi}f(x)\sin kx\,dx. $$ 

The exception is  $ a_{0} $. This time we multiply by  $ \cos 0x = 1 $. The integral of 1 is  $ 2\pi $:

Constant term

 $$ a_{0}=\frac{1}{2\pi}\int_{0}^{2\pi}f(x)\cdot1dx=a v e r a g e v a l u e o f f(x). $$ 

I used those formulas to find the Fourier coefficients for the square wave in equation (8). The integral of  $ f(x)\cos kx $ was zero. The integral of  $ f(x)\sin kx $ was 4/k for odd k.

Compare Linear Algebra in  $ R^{n} $

Infinite-dimensional Hilbert space is very much like the $n$-dimensional space $\mathbf{R}^n$. Suppose the nonzero vectors $\boldsymbol{v}_1, \ldots, \boldsymbol{v}_n$ are orthogonal in $\mathbf{R}^n$. We want to write the vector $b$ (instead of the function $f(x)$) as a combination of those $\boldsymbol{v}'$s:

Finite orthogonal series

 $$ \boldsymbol{b}=c_{1}\boldsymbol{v}_{1}+c_{2}\boldsymbol{v}_{2}+\cdots+c_{n}\boldsymbol{v}_{n}. $$ 

Multiply both sides by  $ v_1^T $. Use orthogonality, so  $ v_1^T v_2 = 0 $. Only the  $ c_1 $ term is left:

Coefficient  $ c_{1} $  $ v_{1}^{\mathrm{T}}b = c_{1}v_{1}^{\mathrm{T}}v_{1} + 0 + \cdots + 0 $. Therefore  $ c_{1} = v_{1}^{\mathrm{T}}b/v_{1}^{\mathrm{T}}v_{1} $.

The denominator  $ v_1^T v_1 $ is the length squared, like  $ \pi $ in equation (11). The numerator  $ v_1^T b $ is the inner product like  $ \int f(x) \cos kx \, dx $. Coefficients are easy to find when the