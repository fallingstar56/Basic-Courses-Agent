We mention one more splitting. The idea of “incomplete $L$ $U$” is to set the small nonzeros in $L$ and $U$ back to zero. This leaves triangular matrices $L_0$ and $U_0$ which are again sparse. The splitting has $S = L_0 U_0$ on the left side. Each step is quick:

Incomplete LU

 $$ L_{0}U_{0}\boldsymbol{x}_{k+1}=(L_{0}U_{0}-A)\boldsymbol{x}_{k}+\boldsymbol{b}. $$ 

On the right side we do sparse matrix-vector multiplications. Don’t multiply  $ L_0 $ times  $ U_0 $, those are matrices. Multiply  $ x_k $ by  $ U_0 $ and then multiply that vector by  $ L_0 $. On the left side we do forward and back substitutions. If  $ L_0U_0 $ is close to  $ A $, then  $ |\lambda|_{\max} $ is small. A few iterations will give a close answer.

## Multigrid and Conjugate Gradients

I cannot leave the impression that Jacobi and Gauss-Seidel are great methods. Generally the “low-frequency” part of the error decays very slowly, and many iterations are needed. Here are two important ideas that bring tremendous improvement. Multigrid can solve problems of size n in  $ O(n) $ steps. With a good preconditioner, conjugate gradients becomes one of the most popular and powerful algorithms in numerical linear algebra.

Multigrid Solve smaller problems with coarser grids. Each iteration will be cheaper and faster. Then interpolate between the coarse grid values to get a quick headstart on the full-size problem. Multigrid might go 4 levels down and back.

Conjugate gradients An ordinary iteration like  $ x_{k+1} = x_k - Ax_k + b $ involves multiplication by  $ A $ at each step. If  $ A $ is sparse, this is not too expensive:  $ Ax_k $ is what we are willing to do. It adds one more basis vector to the growing “Krylov spaces” that contain our approximations. But  $ x_{k+1} $ is not the best combination of  $ x_0 $,  $ Ax_0, \ldots, A^k x_0 $. The ordinary iterations are simple but far from optimal.

The conjugate gradient method chooses the best combination  $ x_k $ at every step. The extra cost (beyond one multiplication by  $ A $) is not great. We will give the CG iteration, emphasizing that this method was created for a symmetric positive definite matrix. When  $ A $ is not symmetric, one good choice is GMRES. When  $ A = A^\mathrm{T} $ is not positive definite, there is MINRES. A world of high-powered iterative methods has been created around the idea of making optimal choices of each successive  $ x_k $.

My textbook Computational Science and Engineering describes multigrid and CG in much more detail. Among books on numerical linear algebra, Trefethen-Bau is deservedly popular (others are terrific too). Golub-Van Loan is a level up.

The Problem Set reproduces the five steps in each conjugate gradient cycle from  $ \boldsymbol{x}_{k-1} $ to  $ \boldsymbol{x}_k $. We compute that new approximation  $ \boldsymbol{x}_k $, the new residual  $ \boldsymbol{r}_k = \boldsymbol{b} - \boldsymbol{A}\boldsymbol{x}_k $, and the new search direction  $ \boldsymbol{d}_k $ to look for the next  $ \boldsymbol{x}_{k+1} $.

I wrote those steps for the original matrix A. But a preconditioner S can make convergence much faster. Our original equation is  $ Ax = b $. The preconditioned equation is  $ S^{-1}Ax = S^{-1}b $. Small changes in the code give the preconditioned conjugate gradient method—the leading iterative method to solve positive definite systems.