Band Matrices

These counts are improved when A has “good zeros”. A good zero is an entry that remains zero in L and U. The best zeros are at the beginning of a row. They require no elimination steps (the multipliers are zero). So we also find those same good zeros in L. That is especially clear for this tridiagonal matrix A (and for band matrices in Figure 11.1):

Tridiagonal

Bidiagonal

times

bidiagonal

 $$ \begin{aligned}\begin{bmatrix} \\{{{1}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}} \\\end{bmatrix}&=\begin{bmatrix} \\{{{1}}} \\{{{-1}}}&{{{1}}} \\{{{-1}}}&{{{1}}} \\{{{-1}}}&{{{1}}} \\\end{bmatrix}\begin{bmatrix} \\{{{1}}}&{{{-1}}} \\{{{1}}}&{{{-1}}} \\{{{1}}}&{{{-1}}} \\{{{1}}} \\\end{bmatrix}.\\ \end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_288_372_808_525.jpg" alt="Image" width="48%" /></div>


<div style="text-align: center;">Figure 11.1: A = LU for a band matrix. Good zeros in A stay zero in L and U.</div>


These zeros lead to a complete change in the operation count, for “half-bandwidth” w:

 $$ A\;band matrix\;has\;a_{ij}=0\;when\;|i-j|>w. $$ 

Thus $w = 1$ for a diagonal matrix, $w = 2$ for tridiagonal, $w = n$ for dense. The length of the pivot row is at most $w$. There are no more than $w - 1$ nonzeros below any pivot. Each stage of elimination is complete after $w(w - 1)$ operations, and the band structure survives. There are $n$ columns to clear out. Therefore:

Elimination on a band matrix (A to L and U) needs less than  $ w^{2}n $ operations.

For a band matrix, the count is proportional to  $ n $ instead of  $ n^3 $. It is also proportional to  $ w^2 $. A full matrix has  $ w = n $ and we are back to  $ n^3 $. For an exact count, remember that the bandwidth drops below  $ w $ in the lower right corner (not enough space):

Band

 $$ \frac{w(w-1)(3n-2w+1)}{3}\qquad\mathbf{Dense}\quad\frac{n(n-1)(n+1)}{3}=\frac{n^{3}-n}{3} $$ 

On the right side of  $ Ax = b $, to find x from b, the cost is about 2wn (compared to the usual  $ n^2 $). Main point: For a band matrix the operation counts are proportional to n. This is extremely fast. A tridiagonal matrix of order 10,000 is very cheap, provided we don't compute  $ A^{-1} $. That inverse matrix has no zeros at all:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}\quad has\quad\boldsymbol{A}^{-1}=\boldsymbol{U}^{-1}\boldsymbol{L}^{-1}=\begin{bmatrix}{{{4}}}&{{{3}}}&{{{2}}}&{{{1}}} \\{{{3}}}&{{{3}}}&{{{2}}}&{{{1}}} \\{{{2}}}&{{{2}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix}. $$ 

We are actually worse off knowing  $ A^{-1} $ than knowing L and U. Multiplication by  $ A^{-1} $ needs the full  $ n^2 $ steps. Solving  $ L\boldsymbol{c} = \boldsymbol{b} $ and  $ U\boldsymbol{x} = \boldsymbol{c} $ needs only 2wn.