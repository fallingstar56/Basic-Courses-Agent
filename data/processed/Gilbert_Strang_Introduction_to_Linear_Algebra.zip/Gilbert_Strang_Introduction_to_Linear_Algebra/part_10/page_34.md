Our first question is pure linear algebra: When do the  $ x_k $'s converge to  $ x $? The answer uncovers the number  $ |\lambda|_{\max} $ that controls convergence. In examples of Jacobi and Gauss-Seidel, we will compute this “spectral radius”  $ |\lambda|_{\max} $. It is the largest eigenvalue of the iteration matrix  $ B = S^{-1}T $.

## The Spectral Radius  $ \rho(B) $ Controls Convergence

Equation (3) is  $ e_{k+1} = S^{-1}Te_k $. Every iteration step multiplies the error by the same matrix  $ B = S^{-1}T $. The error after  $ k $ steps is  $ e_k = B^k e_0 $. The error approaches zero if the powers of  $ B = S^{-1}T $ approach zero. It is beautiful to see how the eigenvalues of  $ B $—the largest eigenvalue in particular—control the matrix powers  $ B^k $.

The powers  $ B^k $ approach zero if and only if every eigenvalue of  $ B $ has  $ |\lambda| < 1 $. The rate of convergence is controlled by the spectral radius of  $ B $:  $ \rho = \max |\lambda(B)| $.

The test for convergence is  $ |\lambda|_{\max} < 1 $. Real eigenvalues must lie between -1 and 1. Complex eigenvalues  $ \lambda = a + ib $ must have  $ |\lambda|^2 = a^2 + b^2 < 1 $. The spectral radius “rho” is the largest distance from 0 to the eigenvalues of  $ B = S^{-1}T $. This is  $ \rho = |\lambda|_{\max} $.

To see why  $ |\lambda|_{\max} < 1 $ is necessary, suppose the starting error  $ e_0 $ happens to be an eigenvector of  $ B $. After one step the error is  $ B e_0 = \lambda e_0 $. After  $ k $ steps the error is  $ B^k e_0 = \lambda^k e_0 $. If we start with an eigenvector, we continue with that eigenvector—and the factor  $ \lambda^k $ only goes to zero when  $ |\lambda| < 1 $. This condition is required of every eigenvalue.

To see why  $ |\lambda|_{\max} < 1 $ is sufficient for the error to approach zero, suppose  $ e_0 $ is a combination of eigenvectors:

 $$ \boldsymbol{e}_{0}=c_{1}\boldsymbol{x}_{1}+\cdots+c_{n}\boldsymbol{x}_{n}\quad\mathrm{leads to}\quad\boldsymbol{e}_{k}=c_{1}(\lambda_{1})^{k}\boldsymbol{x}_{1}+\cdots+c_{n}(\lambda_{n})^{k}\boldsymbol{x}_{n}. $$ 

This is the point of eigenvectors! When we multiply by $B$, each eigenvector $x_i$ is multiplied by $\lambda_i$. If all $|\lambda_i| < 1$ then equation (4) ensures that $e_k$ goes to zero.

 $$ \boldsymbol{B}=\left[\begin{array}{cc}{{{.6}}}&{{{.5}}} \\{{{.6}}}&{{{.5}}}\end{array}\right]has\lambda_{max}=1.1\qquad\boldsymbol{B}^{\prime}=\left[\begin{array}{cc}{{{.6}}}&{{{1.1}}} \\{{{0}}}&{{{.5}}}\end{array}\right]has\lambda_{max}=.6 $$ 

 $ B^2 $ is 1.1 times  $ B $. Then  $ B^3 $ is  $ (1.1)^2 $ times  $ B $. The powers of  $ B $ will blow up. Contrast with the powers of  $ B' $. The matrix  $ (B')^k $ has  $ (.6)^k $ and  $ (.5)^k $ on its diagonal. The off-diagonal entries also involve  $ \rho^k = (.6)^k $, which sets the speed of convergence.

Note When there are too few eigenvectors, equation (4) is not correct. We turn to the Jordan form when eigenvectors are missing and the matrix B can't be diagonalized:

Jordan form J

 $$ \begin{array}{r}{B=M J M^{-1}\qquad\mathrm{a n d}\qquad B^{k}=M J^{k}M^{-1}.}\end{array} $$ 

Section 8.3 shows how J and  $ J^{k} $ are made of “blocks” with one repeated eigenvalue:

The powers of a 2 by 2 block in J are

 $$ \begin{bmatrix}{{{\lambda}}}&{{{1}}} \\{{{0}}}&{{{\lambda}}}\end{bmatrix}^{k}=\begin{bmatrix}{{{\lambda^{k}}}}&{{{k\lambda^{k-1}}}} \\{{{0}}}&{{{\lambda^{k}}}}\end{bmatrix}. $$ 