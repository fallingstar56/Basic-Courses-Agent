### 10.7 Linear Algebra for Cryptography

1 Codes can use finite fields as alphabets: letters in the message become numbers 0, 1, ..., p - 1.
2 The numbers are added and multiplied (mod p). Divide by p, keep the remainder.
3 A Hill Cipher multiplies blocks of the message by a secret matrix E (mod p).
4 To decode, multiply each block by the inverse matrix D (mod p). Not a very secure cipher!

Cryptography is about encoding and decoding messages. Banks do this all the time with financial information. Amazingly, modern algorithms can involve extremely deep mathematics. “Elliptic curves” play a part in cryptography, as they did in the sensational proof by Andrew Wiles of Fermat’s Last Theorem.

This section will not go that far! But it will be our first experience with finite fields and finite vector spaces. The field for  $ \mathbf{R}^n $ contains all real numbers. The field for “modular arithmetic” contains only  $ p $ integers  $ 0, 1, \ldots, p - 1 $. There were infinitely many vectors in  $ \mathbf{R}^n $—now there will only be  $ p^n $ messages of length  $ n $ in message space. The alphabet from A to Z is finite (as in  $ p = 26 $).

The codes in this section will be easily breakable—they are much too simple for practical security. The power of computers demands more complex cryptography, because that power would quickly detect a small encoding matrix. But a matrix code (the Hill Cipher) will allow us to see linear algebra at work in a new way.

All our calculations in encoding and decoding will be “mod  $ p $”. But the central concepts of linear independence and bases and inverse matrices and determinants survive this change. We will be doing “linear algebra with finite fields”. Here is the meaning of mod  $ p $:

 $$ \begin{array}{l} 27\equiv2\left(mod\ 5\right)\quad means that\ 27-2is divisible by\ 5\\y\equiv x\left(mod\ p\right)\quad means that\ y-xis divisible by\ p \end{array} $$ 

Dividing y by 5 produces one of the five possible remainders  $ x = 0, 1, 2, 3, 4 $. All the numbers 5, -5, 10, -10, ... with no remainder are congruent to zero (mod 5). The numbers  $ y = 6, -4, 11, -9, \ldots $ are all congruent to  $ x = 1 \pmod{5} $.

We use the word congruent for the symbol  $ \equiv $ and we call this “modular arithmetic”. Every integer  $ y $ produces one of the values  $ x = 0, 1, 2, \ldots, p - 1 $.

The theory is best if p is a prime number. With p = 26 letters from A to Z, we unfortunately don't start with a prime p. Cryptography can deal with this problem.