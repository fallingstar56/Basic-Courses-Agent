### 11.3 Iterative Methods and Preconditioners

Up to now, our approach to  $ Ax = b $ has been direct. We accepted A as it came. We attacked it by elimination with row exchanges. We now look at iterative methods, which replace A by a simpler matrix S. The difference  $ T = S - A $ is moved over to the right side of the equation. The problem becomes easier to solve, with S instead of A. But there is a price—the simpler system has to be solved over and over.

An iterative method is easy to invent. Just split A (carefully) into S - T.

 $$ Ax=b\qquad Sx=Tx+b. $$ 

The novelty is to solve (1) iteratively. Each guess  $ x_k $ leads to the next  $ x_{k+1} $:

Pure iteration

 $$ S\boldsymbol{x}_{k+1}=T\boldsymbol{x}_{k}+\boldsymbol{b}. $$ 

Start with any  $ x_0 $. Then solve  $ Sx_1 = Tx_0 + b $. Continue to  $ Sx_2 = Tx_1 + b $. A hundred iterations are very common—often more. Stop when (and if!)  $ x_{k+1} $ is sufficiently close to  $ x_{k} $—or when the  $ \text{residual} r_k = b - Ax_k $ is near zero. Our hope is to get near the true solution, more quickly than by elimination. When the  $ x_k $ converge, their limit  $ x_\infty $ does solve equation (1):  $ Sx_\infty = Tx_\infty + b $ means  $ Ax_\infty = b $.

The two goals of the splitting  $ A = S - T $ are speed per step and fast convergence. The speed of each step depends on S and the speed of convergence depends on  $ S^{-1}T $:

1 Equation (2) should be easy to solve for  $ x_{k+1} $. The “preconditioner” S could be the diagonal or triangular part of A. A fast way uses  $ S = L_0 U_0 $, where those factors have many zeros compared to the exact A = LU. This is “incomplete LU”.

2 The difference  $ x - x_k $ (this is the error  $ e_k $) should go quickly to zero. Subtracting equation (2) from (1) cancels b, and it leaves the equation for the error  $ e_k $:

Error equation

 $$ S e_{k+1}=T e_{k}\quad\mathrm{w h i c h~m e a n s}\quad e_{k+1}=S^{-1}T e_{k}. $$ 

At every step the error is multiplied by  $ S^{-1}T $. If  $ S^{-1}T $ is small, its powers go quickly to zero. But what is “small”?

The extreme splitting is $S = A$ and $T = 0$. Then the first step of the iteration is the original $Ax = b$. Convergence is perfect and $S^{-1}T$ is zero. But the cost of that step is what we wanted to avoid. The choice of $S$ is a battle between speed per step (a simple $S$) and fast convergence ($S$ close to $A$). Here are some choices of $S$:

J S = diagonal part of A (the iteration is called Jacobi's method)

GS S = lower triangular part of A including the diagonal (Gauss-Seidel method)

 $  \mathbf{ILU}  $  $  S =  $ approximate  $  L  $ times approximate  $  U  $ (incomplete  $  L  $  $  U  $ method).