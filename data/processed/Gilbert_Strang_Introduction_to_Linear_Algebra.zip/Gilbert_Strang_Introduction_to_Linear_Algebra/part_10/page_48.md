When ages are uniform between 17 ≤ x ≤ 20, the integral can shift to 0 ≤ x ≤ 3 :

 $$ \sigma^{2}=\int\limits_{17}^{20}\frac{1}{3}(x-18.5)^{2}dx=\int\limits_{0}^{3}\frac{1}{3}(x-1.5)^{2}dx=\frac{1}{9}(x-1.5)^{3}\Bigg|_{x=0}^{x=3}=\frac{2}{9}(1.5)^{3}=\frac{3}{4}. $$ 

That is a typical example, and here is the complete picture for a uniform  $ p(x) $, 0 to a.

Uniform distribution for  $ 0 \leq x \leq a $ Density  $ p(x) = \frac{1}{a} $ Cumulative  $ F(x) = \frac{x}{a} $

 $$ \begin{aligned}Mean m=\frac{a}{2}halfway\quad Variance\sigma^{2}=\int\limits_{a}^{\hat{}}\frac{1}{a}\left(x-\frac{a}{2}\right)^{2}\mathrm{d}x=\frac{a^{2}}{12}\end{aligned} $$ 

The mean is a multiple of $a$, the variance is a multiple of $a^{2}$. For $a = 3$, $\sigma^{2} = \frac{9}{12} = \frac{3}{4}$. For one random number between 0 and 1 (mean $\frac{1}{2}$) the variance is $\sigma^{2} = \frac{1}{12}$.

## Normal Distribution: Bell-shaped Curve

The normal distribution is also called the “Gaussian” distribution. It is the most important of all probability density functions  $ p(x) $. The reason for its overwhelming importance comes from repeating an experiment and averaging the outcomes. The experiments have their own distribution (like heads and tails). The average approaches a normal distribution.

Central Limit Theorem (informal) The average of N samples of “any” probability distribution approaches a normal distribution as  $ N \to \infty $.

Start with the “standard normal distribution”. It is symmetric around x = 0, so its mean value is m = 0. It is chosen to have a standard variance  $ \sigma^2 = 1 $. It is called  $ \mathbf{N}(0,1) $.

Standard normal distribution  $  p(x) = \frac{1}{\sqrt{2\pi}} e^{-x^{2}/2}  $

The graph of  $ p(x) $ is the bell-shaped curve in Figure 12.2. The standard facts are

Total probability = 1

 $$ \int\limits_{-\infty}^{\infty}p(x)dx=\frac{1}{\sqrt{2\pi}}\int\limits_{-\infty}^{\infty}e^{-x^{2}/2}dx=\mathbf{1} $$ 

Mean E [x] = 0

 $$ m=\frac{1}{\sqrt{2\pi}}\int\limits_{-\infty}^{\infty}xe^{-x^{2}/2}dx=\mathbf{0} $$ 

Variance E  $ [x^{2}]=1 $

 $$ \sigma^{2}=\frac{1}{\sqrt{2\pi}}\int\limits_{-\infty}^{\infty}(x-0)^{2}e^{-x^{2}/2}dx=1 $$ 