ordered to produce a narrow band of nonzeros. Zeros inside the band “fill in” during elimination—those zeros are destroyed and don’t save computing time.

Section 11.2 is about instability that can't be avoided. It is built into the problem, and this sensitivity is measured by the “condition number”. Then Section 11.3 describes how to solve Ax = b by iterations. Instead of direct elimination, the computer solves an easier equation many times. Each answer  $ x_k $ leads to the next guess  $ x_{k+1} $. For good iterations (the conjugate gradient method is extremely good), the  $ x_k $ converge quickly to  $ x = A^{-1}b $.

## The Fastest Supercomputer

A new supercomputing record was announced by IBM and Los Alamos on May 20, 2008. The Roadrunner was the first to achieve a quadrillion (10^{15}) floating-point operations per second: a petaflop machine. The benchmark for this world record was a large dense linear system  $ Ax = b $: computer speed is tested by linear algebra.

That machine was shut down in 2013! The TOP500 project ranks the 500 most powerful computer systems in the world. As I write this page in October 2015, the first four are from NUDT in China, Cray and IBM in the US, and Fujitsu in Japan. They all use a LINUX-based system. And all vector processors have fallen out of the top 500.

Looking ahead, the Summit is expected to take first place with 150-300 petaflops. President Obama has just ordered the development of an exascale system (1000 petaflops). Up to now we are following Moore’s Law of doubling every 14 months.

The LAPACK software does elimination with partial pivoting. The biggest difference from this book is to organize the steps to use large submatrices and never single numbers. And graphics processing units (GPU's) are now almost required for success. The market for video games dwarfs scientific computing and led to astonishing acceleration in the chips.

Before IBM's BlueGene, a key issue was to count the standard quad-core processors that a petaflop machine would need: 32,000. The new architecture uses much less power, but its hybrid design has a price: a code needs three separate compilers and explicit instructions to move all the data. Please see the excellent article in SIAM News (siam.org, July 2008) and the update on www.lanl.gov/roadrunner.

Our thinking about matrix calculations is reflected in the highly optimized BLAS (Basic Linear Algebra Subroutines). They come at levels 1, 2, and 3:

Level 1 Linear combinations of vectors  $ a u + v $:  $ O(n) $ work

Level 2 Matrix-vector multiplications  $ Au + v: O(n^{2}) $ work

Level 3 Matrix-matrix multiplications  $ AB + C: O(n^{3}) $ work

Level 1 is an elimination step (multiply row $j$ by $\ell_{ij}$ and subtract from row $i$). Level 2 can eliminate a whole column at once. A high performance solver is rich in Level 3 BLAS ($AB$ has $2n^3$ flops and $2n^2$ data, a good ratio of work to talk).

It is data passing and storage retrieval that limit the speed of parallel processing. The high-velocity cache between main memory and floating-point computation has to be fully used! Top speed demands a block matrix approach to elimination.

The big change, coming now, is parallel processing at the chip level.