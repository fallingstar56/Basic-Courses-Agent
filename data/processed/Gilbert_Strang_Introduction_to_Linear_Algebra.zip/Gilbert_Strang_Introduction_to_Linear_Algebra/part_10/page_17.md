# Chapter 11

## Numerical Linear Algebra

1 The goals of numerical linear algebra are speed and accuracy and stability:  $ n > 10^{3} $ or  $ 10^{6} $.

2 Matrices can be full or sparse or banded or structured: special algorithms for each.

3 Accuracy of elimination is controlled by the condition number  $ \|A\|\|A^{-1}\| $.

4 Gram-Schmidt is often computed by using Householder reflections  $ H = I - 2uu^{\mathrm{T}} $ to find  $ Q $.

5 Eigenvalues use QR iterations  $ A_{0} = Q_{0}R_{0} \rightarrow R_{0}Q_{0} = A_{1} = Q_{1}R_{1} \rightarrow \rightarrow A_{n} $.

6 Shifted  $ QR $ is even better: Shift to  $ A_{k} - c_{k}I = Q_{k}R_{k} $, shift back  $ A_{k+1} = R_{k}Q_{k} + c_{k}I $.

7 Iteration  $ Sx_{k+1} = b - Tx_{k} $ solves  $ (S + T)x = b $ if all eigenvalues of  $ S^{-1}T $ have  $ |\lambda| < 1 $.

8 Iterative methods often use preconditioners  $ P $. Change  $ Ax = b $ to  $ PAx = Pb $ with  $ PA \approx I $.

9 Conjugate gradients and GMRES are Krylov methods; see Trefethen-Bau (and other texts).

### 11.1 Gaussian Elimination in Practice

Numerical linear algebra is a struggle for quick solutions and also accurate solutions. We need efficiency but we have to avoid instability. In Gaussian elimination, the main freedom (always available) is to exchange equations. This section explains when to exchange rows for the sake of speed, and when to do it for the sake of accuracy.

The key to accuracy is to avoid unnecessarily large numbers. Often that requires us to avoid small numbers! A small pivot generally means large multipliers (since we divide by the pivot). A good plan is “partial pivoting”, to choose the largest available pivot in each new column. We will see why this pivoting strategy is built into computer programs.

Other row exchanges are done to save elimination steps. In practice, most large matrices are sparse—almost all entries are zeros. Elimination is fastest when the equations are