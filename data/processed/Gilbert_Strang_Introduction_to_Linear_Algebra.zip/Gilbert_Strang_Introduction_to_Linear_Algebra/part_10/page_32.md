13 (Suggested by C. Moler and C. Van Loan.) Compute b - Ay and b - Az when

 $$ b=\left[\begin{array}{l} {.217}\\{.254} \end{array}\right] \quad A=\left[\begin{array}{l l}{.780}&{.563}\\{.913}&{.659} \end{array}\right] \quad y=\left[\begin{array}{r} {.341}\\{-.087} \end{array}\right] \quad z=\left[\begin{array}{r} {.999}\\{-1.0} \end{array}\right]. $$ 

Is  $ y $ closer than  $ z $ to solving  $ Ax = b $? Answer in two ways: Compare the residual  $ b - Ay $ to  $ b - Az $. Then compare  $ y $ and  $ z $ to the true  $ x = (1, -1) $. Both answers can be right. Sometimes we want a small residual, sometimes a small  $ \Delta x $.

(a) Compute the determinant of A in Problem 13. Compute  $ A^{-1} $.

(b) If possible compute  $ \|A\| $ and  $ \|A^{-1}\| $ and show that  $ c > 10^{6} $.

Problems 15–19 are about vector norms other than the usual  $ \|x\| = \sqrt{x \cdot x} $.

15 The “ $ \ell^1 $ norm” and the “ $ \ell^\infty $ norm” of  $ x = (x_1, \ldots, x_n) $ are

 $$ \left\| \mathbf{x} \right\|_{1}=\left|x_{1}\right|+\cdots+\left|x_{n}\right|\quad and\quad\left\| \mathbf{x} \right\|_\infty=\max\limits_{1\leq i\leq n} \left|x_{i}\right|. $$ 

Compute the norms  $ \|x\| $ and  $ \|x\|_{1} $ and  $ \|x\|_{\infty} $ of these two vectors in  $ \mathbf{R}^{5} $:

 $$ \begin{aligned}x&=(1,1,1,1,1)\quad&x&=(.1,.7,.3,.4,.5).\end{aligned} $$ 

Prove that  $ \|x\|_\infty \leq \|x\| \leq \|x\|_1 $. Show from the Schwarz inequality that the ratios  $ \|x\|/\|x\|_\infty $ and  $ \|x\|_1/\|x\| $ are never larger than  $ \sqrt{n} $. Which vector  $ (x_1, \ldots, x_n) $ gives ratios equal to  $ \sqrt{n} $?

17 All vector norms must satisfy the triangle inequality. Prove that

 $$ \|x+y\|_{\infty}\leq\|x\|_{\infty}+\|y\|_{\infty}\qquad\mathrm{a n d}\qquad\|x+y\|_{1}\leq\|x\|_{1}+\|y\|_{1}. $$ 

Vector norms must also satisfy  $ \|cx\| = |c|\|x\| $. The norm must be positive except when  $ x = 0 $. Which of these are norms for vectors  $ (x_1, x_2) $ in  $ \mathbf{R}^2 $?

 $$ \left\| \mathbf{x} \right\|_A= \left\| \mathbf{x}_{1} \right\|+2 \left\| \mathbf{x}_{2} \right\| \qquad \left\| \mathbf{x} \right\|_{B}=\min\left( \left\| \mathbf{x}_{1} \right\|, \left\| \mathbf{x}_{2} \right\| \right) $$ 

 $$ \left\| \mathbf{x} \right\|_C=\left\| \mathbf{x} \right\|+\left\| \mathbf{x} \right\|_\infty \quad \left\| \mathbf{x} \right\|_{D}=\left\| A \mathbf{x} \right\|\quad(this answer depends on A). $$ 

Challenge Problems

Show that  $ x^\mathrm{T}y \leq \|x\|_1 \|y\|_\infty $ by choosing components  $ y_i = \pm 1 $ to make  $ x^\mathrm{T}y $ as large as possible.

The eigenvalues of the -1, 2, -1 difference matrix  $ K $ are  $ \lambda = 2 - 2 \cos(j\pi/n + 1) $. Estimate  $ \lambda_{\min} $ and  $ \lambda_{\max} $ and  $ c = \mathbf{cond}(K) = \lambda_{\max}/\lambda_{\min} $ as  $ n $ increases:  $ c \approx Cn^2 $ with what constant  $ C $?

Test this estimate with  $ \mathbf{eig}(K) $ and  $ \mathbf{cond}(K) $ for  $ n = 10, 100, 1000 $.