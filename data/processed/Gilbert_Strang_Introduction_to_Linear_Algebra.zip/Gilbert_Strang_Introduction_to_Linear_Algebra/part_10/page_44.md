# Chapter 12

# Linear Algebra in Probability & Statistics

### 12.1 Mean, Variance, and Probability

We are starting with the three fundamental words of this chapter: mean, variance, and probability. Let me give a rough explanation of their meaning before I write any formulas:

The mean is the average value or expected value

The variance  $ \sigma^{2} $ measures the average squared distance from the mean m

The probabilities of n different outcomes are positive numbers  $ p_{1}, \ldots, p_{n} $ adding to 1.

Certainly the mean is easy to understand. We will start there. But right away we have two different situations that you have to keep straight. On the one hand, we may have the results (sample values) from a completed trial. On the other hand, we may have the expected results (expected values) from future trials. Let me give examples:

Sample values Five random freshmen have ages 18, 17, 18, 19, 17

Sample mean

 $$ \frac{1}{5}(18+17+18+19+17)=17.8 $$ 

Probabilities The ages in a freshmen class are 17 (20%), 18 (50%), 19 (30%)

A random freshman has expected age E[x] = (0.2) 17 + (0.5) 18 + (0.3) 19 = 18.1

Both numbers 17.8 and 18.1 are correct averages. The sample mean starts with N samples  $ x_{1}, \ldots, x_{N} $ from a completed trial. Their mean is the average of the N observed samples:

Sample mean

 $$ m=\mu=\frac{1}{N}(x_{1}+x_{2}+\cdots+x_{N}) $$ 