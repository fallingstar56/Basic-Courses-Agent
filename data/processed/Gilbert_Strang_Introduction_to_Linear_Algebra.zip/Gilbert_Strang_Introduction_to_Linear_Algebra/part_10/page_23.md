 $$ \begin{aligned}j_{i}\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{-2}}}&{{{1}}}&{{{0}}} \\{{{-2}}}&{{{0}}}&{{{2}}}\end{bmatrix}&\longrightarrow\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{3}}}&{{{2}}} \\{{{0}}}&{{{2}}}&{{{4}}}\end{bmatrix}\quad j&=1\\a_{32}&=0\quad a_{32}=2\quad a_{32}=0\text{ before}\quad a_{32}\neq0\text{ after}\end{aligned} $$ 

We only need the positions of the nonzeros, not their exact values. Think of the graph of nonzeros: Node i is connected to node j if  $ a_{ij} \neq 0 $. Watch to see how elimination can create nonzeros (new edges), which we are trying to avoid.

The command nnz(L) counts the nonzero multipliers in the lower triangular L, find (L) will list them, and spy(L) shows them all.

The goal of  $ \text{colamd} $ and  $ \text{symamd} $ is a better ordering (permutation  $ P $) that reduces  $ \text{fill-in} $ for  $ AP $ and  $ P^{\text{T}}AP $—by choosing the pivot with the fewest nonzeros below it.

## Fast Orthogonalization

There are three ways to reach the important factorization  $ A = QR $. Gram-Schmidt works to find the orthonormal vectors in Q. Then R is upper triangular because of the order of Gram-Schmidt steps. Now we look at better methods (Householder and Givens), which use a product of specially simple Q's that we know are orthogonal.

Elimination gives  $ A = LU $, orthogonalization gives  $ A = QR $. We don't want a triangular  $ L $, we want an orthogonal  $ Q $.  $ L $ is a product of  $ E $'s from elimination, with 1's on the diagonal and the multiplier  $ \ell_{ij} $ below.  $ Q $ will be a product of orthogonal matrices.

There are two simple orthogonal matrices to take the place of the  $ E $'s. The reflection matrices  $ I - 2uu^{\mathrm{T}} $ are named after Householder. The plane rotation matrices are named after Givens. The simple matrix that rotates the xy plane by  $ \theta $ is  $ Q_{21} $:

Givens rotation in the 1-2 plane

 $$ Q_{21}=\begin{bmatrix}{{{\cos\theta}}}&{{{-\sin\theta}}}&{{{0}}} \\{{{\sin\theta}}}&{{{\cos\theta}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

Use  $ Q_{21} $ the way you used  $ E_{21} $, to produce a zero in the  $ (2,1) $ position. That determines the angle  $ \theta $. Bill Hager gives this example in Applied Numerical Linear Algebra:

 $$ Q_{21}A={\left[\begin{array}{l l l}{.6}&{.8}&{0}\\ {-.8}&{.6}&{0}\\ {0}&{0}&{1}\end{array}\right]}{\left[\begin{array}{l l l}{90}&{-153}&{114}\\ {120}&{-79}&{-223}\\ {200}&{-40}&{395}\end{array}\right]}={\left[\begin{array}{l l l}{150}&{-155}&{-110}\\ {0}&{75}&{-225}\\ {200}&{-40}&{395}\end{array}\right]}. $$ 

The zero came from  $ -.8(90) + .6(120) $. No need to find  $ \theta $, what we needed was  $ \cos\theta $:

 $$ \cos\theta=\frac{90}{\sqrt{90^{2}+120^{2}}}\qquad\mathrm{a n d}\qquad\sin\theta=\frac{-120}{\sqrt{90^{2}+120^{2}}}. $$ 