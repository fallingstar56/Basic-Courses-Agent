If  $ |\lambda| < 1 $ then these powers approach zero. The extra factor  $ k $ from a double eigenvalue is overwhelmed by the decreasing factor  $ \lambda^{k-1} $. This applies to every block:

Diagonalizable or not: Convergence B^k → 0 and its speed depend on ρ = |λ|max < 1.

Jacobi versus Gauss-Seidel

We now solve a specific 2 by 2 problem by splitting A. Watch for that number  $ \left|\lambda\right|_{\max} $.

 $$ \begin{array}{r l r l r l}{A\boldsymbol{x}=\boldsymbol{b}}&{{}}&{\quad}&{{}2u-\quad v=\quad4}&{{}}&{\quad\left[\begin{matrix}{u}\\ {v}\\ \end{matrix}\right]=\left[\begin{matrix}{2}\\ {0}\\ \end{matrix}\right].}\\ {}&{{}}&{\quad-u+2v=-2}&{{}}&{\quad\mathrm{h a s~t h e~s o l u t i o n}}&{{}}&{\quad\left[\begin{matrix}{u}\\ {v}\\ \end{matrix}\right]=\left[\begin{matrix}{2}\\ {0}\\ \end{matrix}\right].}\\ \end{array} $$ 

The first splitting is Jacobi's method. Keep the diagonal of A on the left side (this is S). Move the off-diagonal part of A to the right side (this is T). Then iterate:

Jacobi iteration

 $$ \begin{array}{r l}{S x_{k+1}=T x_{k}+b}&{{}\begin{array}{r l}{2u_{k+1}}&{{}=v_{k}+4}\\ {2v_{k+1}}&{{}=u_{k}-2.}\end{array}}\end{array} $$ 

Start from  $ u_0 = v_0 = 0 $. The first step finds  $ u_1 = 2 $ and  $ v_1 = -1 $. Keep going:

 $$ \begin{bmatrix} {2}\\{-1} \end{bmatrix} \quad \begin{bmatrix} {3/2}\\{0} \end{bmatrix} \quad \begin{bmatrix} {2}\\{-1/4} \end{bmatrix} \quad \begin{bmatrix} {15/8}\\{0} \end{bmatrix} \quad \begin{bmatrix} {2}\\{-1/16} \end{bmatrix} $$ 

 $$ \begin{bmatrix}2\\ 0\end{bmatrix}. $$ 

This shows convergence. At steps 1, 3, 5 the second component is  $ -1 $,  $ -1/4 $,  $ -1/16 $. Those drop by 4 in each two steps. The error equation is  $ Se_{k+1} = Te_k $:

Error equation

 $$ \begin{bmatrix}{{{2}}}&{{{0}}} \\{{{0}}}&{{{2}}}\end{bmatrix}\boldsymbol{e}_{k+1}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\boldsymbol{e}_{k}\quad or\quad\boldsymbol{e}_{k+1}=\begin{bmatrix}{{{0}}}&{{{\frac{1}{2}}}} \\{{{\frac{1}{2}}}}&{{{0}}}\end{bmatrix}\boldsymbol{e}_{k}. $$ 

That last matrix  $ S^{-1}T $ has eigenvalues  $ \frac{1}{2} $ and  $ -\frac{1}{2} $. So its spectral radius is  $ \rho(B) = \frac{1}{2} $:

 $$ B=S^{-1}T=\begin{bmatrix}{{{0}}}&{{{\frac{1}{2}}}} \\{{{\frac{1}{2}}}}&{{{0}}}\end{bmatrix}\quad has\left|\lambda\right|_{\max}=\frac{1}{2}\quad and\quad\begin{bmatrix}{{{0}}}&{{{\frac{1}{2}}}} \\{{{\frac{1}{2}}}}&{{{0}}}\end{bmatrix}^{2}=\begin{bmatrix}{{{\frac{1}{4}}}}&{{{0}}} \\{{{0}}}&{{{\frac{1}{4}}}}\end{bmatrix}. $$ 

Two steps multiply the error by  $ \frac{1}{4} $ exactly, in this special example. The important message is this: Jacobi's method works well when the main diagonal of A is large compared to the off-diagonal part. The diagonal part is S, the rest is -T. We want the diagonal to dominate.

The eigenvalue  $ \lambda = \frac{1}{2} $ is unusually small. Ten iterations reduce the error by  $ 2^{10} = 1024 $. More typical and more expensive is  $ |\lambda|_{\max} = .99 $ or .999.

The Gauss-Seidel method keeps the whole lower triangular part of A as S:

Gauss-Seidel

 $$ \begin{array}{r l r l r l}{{2}u_{k+1}}&{{}=v_{k}+4}&{}&{{}}&{}&{{}u_{k+1}=\frac{1}{2}v_{k}}&{{}+2}\\ {-u_{k+1}+2v_{k+1}}&{{}=}&{{}-2}&{}&{{}}&{}&{{}v_{k+1}=\frac{1}{2}u_{k+1}-1.}\end{array} $$ 

Notice the change. The new  $ u_{k+1} $ from the first equation is used immediately in the second equation. With Jacobi, we saved the old  $ u_k $ until the whole step was complete. With Gauss-Seidel, the new values enter right away and the old  $ u_k $ is destroyed. This cuts the storage in half. It also speeds up the iteration (usually). And it costs no more than the Jacobi method.