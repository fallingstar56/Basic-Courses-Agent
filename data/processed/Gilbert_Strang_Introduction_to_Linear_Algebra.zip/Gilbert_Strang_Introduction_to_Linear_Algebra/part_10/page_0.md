Now change over to functions. Those are the “vectors.” The space of functions  $ f(x) $,  $ g(x) $,  $ h(x) $,  $ \ldots $ defined for  $ 0 \leq x \leq 2\pi $ must be somehow bigger than  $ R^n $. What is the dot product of  $ f(x) $ and  $ g(x) $? What is the length of  $ f(x) $?

Key point in the continuous case: Sums are replaced by integrals. Instead of a sum of  $ v_j $ times  $ w_j $, the dot product is an integral of  $ f(x) $ times  $ g(x) $. Change the “dot” to parentheses with a comma, and change the words “dot product” to inner product:

DEFINITION The inner product of  $ f(x) $ and  $ g(x) $, and the length squared of  $ f(x) $, are

 $$ \left(f,g\right)=\int_{0}^{2\pi}f(x)g(x)dx\qquad and\qquad\|f\|^{2}=\int_{0}^{2\pi}\left(f(x)\right)^{2}dx. $$ 

The interval  $ [0, 2\pi] $ where the functions are defined could change to a different interval like  $ [0, 1] $ or  $ (-\infty, \infty) $. We chose  $ 2\pi $ because our first examples are  $ \sin x $ and  $ \cos x $.

Example 2 The length of  $ f(x) = \sin x $ comes from its inner product with itself:

 $$ \left(f,f\right)=\int_{0}^{2\pi}\left(\sin x\right)^{2}dx=\pi.\quad The length of \sin x is\sqrt{\pi}. $$ 

That is a standard integral in calculus—not part of linear algebra. By writing  $ \sin^2 x $ as  $ \frac{1}{2} - \frac{1}{2} \cos 2x $, we see it go above and below its average value  $ \frac{1}{2} $. Multiply that average by the interval length  $ 2\pi $ to get the answer  $ \pi $.

More important:  $ \sin x $ and  $ \cos x $ are orthogonal in function space:  $ (f, g) = 0 $

Inner product is zero

 $$ \int_{0}^{2\pi}\sin x\cos x dx=\int_{0}^{2\pi}\frac{1}{2}\sin2x dx=\left[-\frac{1}{4}\cos2x\right]_{0}^{2\pi}=0. $$ 

This zero is no accident. It is highly important to science. The orthogonality goes beyond the two functions  $ \sin x $ and  $ \cos x $, to an infinite list of sines and cosines. The list contains  $ \cos 0x $ (which is 1),  $ \sin x $,  $ \cos x $,  $ \sin 2x $,  $ \cos 2x $,  $ \sin 3x $,  $ \cos 3x $,  $ \cdots $.

Every function in that list is orthogonal to every other function in the list.

Fourier Series

The Fourier series of a function  $ f(x) $ is its expansion into sines and cosines:

 $$ f(x)=a_{0}+a_{1}\cos x+b_{1}\sin x+a_{2}\cos2x+b_{2}\sin2x+\cdots. $$ 

We have an orthogonal basis! The vectors in “function space” are combinations of the sines and cosines. On the interval from  $ x = 2\pi $ to  $ x = 4\pi $, all our functions repeat what they did from 0 to  $ 2\pi $. They are “periodic.” The distance between repetitions is the period  $ 2\pi $.