Arnoldi's method is finding Q so that AQ = QH (column by column):

 $$ \boldsymbol{A}\boldsymbol{Q}=\left[\boldsymbol{A}\boldsymbol{q}_{1}\quad\cdots\quad\boldsymbol{A}\boldsymbol{q}_{N}\right]=\left[\boldsymbol{q}_{1}\quad\cdots\quad\boldsymbol{q}_{N}\right]\begin{bmatrix}h_{11}&h_{12}&\cdot&h_{1N}\\ h_{21}&h_{22}&\cdot&h_{2N}\\ 0&h_{32}&\cdot&\cdot\\ 0&0&\cdot&h_{NN}\end{bmatrix}=\boldsymbol{Q}\boldsymbol{H} $$ 

H is a “Hessenberg matrix” with one nonzero subdiagonal. Here is the crucial fact when A is symmetric: The Hessenberg matrix  $ H = Q^{-1}AQ = Q^{\mathrm{T}}AQ $ is symmetric and therefore it is tridiagonal. Explain that sentence.

Three terms only

This tridiagonal H (when A is symmetric) gives the Lanczos iteration:

 $$ q_{j+1}=(A\boldsymbol{q}_{j}-h_{j,j}\boldsymbol{q}_{j}-h_{j-1,j}\boldsymbol{q}_{j-1})/h_{j+1,j} $$ 

From  $ H = Q^{-1}AQ $, why are the eigenvalues of  $ H $ the same as the eigenvalues of  $ A $? For large matrices, the “Lanczos method” computes the leading eigenvalues by stopping at a smaller tridiagonal matrix  $ H_k $. The  $ QR $ method in the text is applied to compute the eigenvalues of  $ H_k $.

Apply the conjugate gradient method to solve  $ Ax = b = \text{ones}(100,1) $, where  $ A $ is the  $ -1,2,-1 $ second difference matrix  $ A = \text{toeplitz}([2 - 1 \text{ zeros}(1,98)]) $. Graph  $ x_{10} $ and  $ x_{20} $ from CG, along with the exact solution  $ x $. (Its 100 components are  $ x_i = (ih - i^2h^2)/2 $ with  $ h = 1/101 $. “ $ \text{plot}(i,x(i)) $” should produce a parabola.)

For unsymmetric matrices, the spectral radius  $ \rho = \max |\lambda_i| $ is not a norm. But still  $ \|A^n\| $ grows or decays like  $ \rho^n $ for large  $ n $. Compare those numbers for  $ A = [1\ 1;\ 0\ 1.1] $ using the command norm.

 $ A^n \to 0 $ if and only if  $ \rho < 1 $. When  $ A = S^{-1}T $, this is the key to convergence.