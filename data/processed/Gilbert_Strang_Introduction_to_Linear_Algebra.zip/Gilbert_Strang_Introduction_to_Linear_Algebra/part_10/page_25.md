### Problem Set 11.1

1 Find the two pivots with and without row exchange to maximize the pivot:

 $$ A=\begin{bmatrix}{{{.001}}}&{{{0}}} \\{{{1}}}&{{{1000}}}\end{bmatrix}. $$ 

With row exchanges to maximize pivots, why are no entries of $L$ larger than 1? Find a 3 by 3 matrix $A$ with all $|a_{ij}| \leq 1$ and $|\ell_{ij}| \leq 1$ but third pivot = 4.

Compute the exact inverse of the Hilbert matrix A by elimination. Then compute  $ A^{-1} $ again by rounding all numbers to three figures:

Ill-conditioned matrix

 $$ \begin{align*}A=\mathsf{hilb}(3)=\begin{bmatrix}1&\frac{1}{2}&\frac{1}{3}\\ \frac{1}{2}&\frac{1}{3}&\frac{1}{4}\\ \frac{1}{3}&\frac{1}{4}&\frac{1}{5}\end{bmatrix}.\end{align*} $$ 

For the same A compute $b = Ax$ for $x = (1, 1, 1)$ and $x = (0, 6, -3.6)$. A small change $\Delta b$ produces a large change $\Delta x$.

Find the eigenvalues (by computer) of the 8 by 8 Hilbert matrix  $ a_{ij} = 1/(i + j - 1) $. In the equation  $ Ax = b $ with  $ \|b\| = 1 $, how large can  $ \|x\| $ be? If b has roundoff error less than  $ 10^{-16} $, how large an error can this cause in x? See Section 9.2.

5 For back substitution with a band matrix (width w), show that the number of multi-plications to solve  $ Ux = c $ is approximately wn.

6 If you know L and U and Q and R, is it faster to solve  $ L U x = b $ or  $ Q R x = b $?

Show that the number of multiplications to invert an upper triangular n by n matrix is about  $ \frac{1}{6}n^{3} $. Use back substitution on the columns of I, upward from 1's.

8 Choosing the largest available pivot in each column (partial pivoting), factor each A into PA = LU:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{2}}}&{{{2}}}\end{bmatrix}\qquad and\qquad\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{1}}} \\{{{2}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{2}}}&{{{0}}}\end{bmatrix}. $$ 

Put 1's on the three central diagonals of a 4 by 4 tridiagonal matrix. Find the cofactors of the six zero entries. Those entries are nonzero in  $ A^{-1} $.

(Suggested by C. Van Loan.) Find the LU factorization and solve by elimination when  $ \varepsilon = 10^{-3}, 10^{-6}, 10^{-9}, 10^{-12}, 10^{-15} $:

 $$ \begin{bmatrix}{{{\varepsilon}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}}\end{bmatrix}=\begin{bmatrix}{{{1+\varepsilon}}} \\{{{2}}}\end{bmatrix}. $$ 

The true x is  $ (1,1) $. Make a table to show the error for each  $ \varepsilon $. Exchange the two equations and solve again—the errors should almost disappear.