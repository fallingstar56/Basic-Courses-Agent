## Linear Transformations of the Plane

It is more interesting to see a transformation than to define it. When a 2 by 2 matrix A multiplies all vectors in  $ R^2 $, we can watch how it acts. Start with a “house” that has eleven endpoints. Those eleven vectors v are transformed into eleven vectors Av. Straight lines between v’s become straight lines between the transformed vectors Av. (The transformation from house to house is linear!) Applying A to a standard house produces a new house—possibly stretched or rotated or otherwise unlivable.

This part of the book is visual, not theoretical. We will show four houses and the matrices that produce them. The columns of H are the eleven corners of the first house. (H is 2 by 12, so plot2d in Problem 25 will connect the 11th corner to the first.) A multiplies the 11 points in the house matrix H to produce the corners AH of the other houses.

House matrix

 $$ H=\begin{bmatrix}-6&-6&-7&0&7&6&6&-3&-3&0&0&-6\\ -7&2&1&8&1&2&-7&-7&-2&-2&-7&-7\end{bmatrix}. $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_236_476_854_926.jpg" alt="Image" width="57%" /></div>


<div style="text-align: center;">Figure 8.2: Linear transformations of a house drawn by plot2d( $ A * H $).</div>


## ■ REVIEW OF THE KEY IDEAS

1. A transformation T takes each v in the input space to  $ T(v) $ in the output space.

2. T is linear if  $ T(v + w) = T(v) + T(w) $ and  $ T(cv) = cT(v) $: lines to lines.

3. Combinations to combinations:  $ T(c_1v_1 + \cdots + c_n v_n) = c_1 T(v_1) + \cdots + c_n T(v_n) $.

4.  $ T = \text{derivative and } T^{+} = \text{integral are linear. So is } T(v) = Av \text{ from } R^{n} \text{ to } R^{m} $.