Change of Basis

Example 2 Suppose the input space  $ V = R^2 $ is also the output space  $ W = R^2 $. Suppose that  $ T(v) = v $ is the identity transformation. You might expect its matrix to be  $ I $, but that only happens when the input basis is the same as the output basis. I will choose different bases to see how the matrix is constructed.

For this special case  $ T(v) = v $, I will call the matrix B instead of A. We are just changing basis from the  $ v $'s to the  $ w $'s. Each  $ v $ is a combination of  $ w_1 $ and  $ w_2 $.

 $$ \begin{aligned}&Input\left[v_{1}\quad v_{2}\right]=\begin{bmatrix}{{{3}}}&{{{6}}} \\{{{3}}}&{{{8}}}\end{bmatrix}\quad Output\left[w_{1}\quad w_{2}\right]=\begin{bmatrix}{{{3}}}&{{{0}}} \\{{{1}}}&{{{2}}}\end{bmatrix}\quad Change v_{1}=1w_{1}+1w_{2}\\&basis\quad\\ \end{aligned} $$ 

Please notice! I wrote the input basis  $ v_1 $,  $ v_2 $ in terms of the output basis  $ w_1 $,  $ w_2 $. That is because of our key rule. We apply the identity transformation  $ T $ to each input basis vector:  $ T(v_1) = v_1 $ and  $ T(v_2) = v_2 $. Then we write those outputs  $ v_1 $ and  $ v_2 $ in the output basis  $ w_1 $ and  $ w_2 $. Those bold numbers 1, 1 and 2, 3 tell us column 1 and column 2 of the matrix  $ B $ (the change of basis matrix):  $ WB = V $ so  $ B = W^{-1}V $.

Matrix B for change of basis

 $$ \left[\boldsymbol{w}_{1}\quad\boldsymbol{w}_{2}\right]\left[\boldsymbol{B}\right]=\left[\boldsymbol{v}_{1}\quad\boldsymbol{v}_{2}\right]\text{i s}\left[\begin{array}{l l}{{{3}}}&{{{0}}} \\{{{1}}}&{{{2}}}\end{array}\right]\left[\begin{array}{l l}{{{1}}}&{{{2}}} \\{{{1}}}&{{{3}}}\end{array}\right]=\left[\begin{array}{l l}{{{3}}}&{{{6}}} \\{{{3}}}&{{{8}}}\end{array}\right]. $$ 

When the input basis is in the columns of a matrix V, and the output basis is in the columns of W, the change of basis matrix for T = I is  $ B = W^{-1}V $.

The key I see a clear way to understand that rule  $ B = W^{-1}V $. Suppose the same vector u is written in the input basis of v's and the output basis of w's. I will do that three ways:

 $$ \boldsymbol{u}=c_{1}\boldsymbol{v}_{1}+\cdots+c_{n}\boldsymbol{v}_{n}\quad\text{is}\left[\boldsymbol{v}_{1}\cdots\boldsymbol{v}_{n}\right]\begin{bmatrix}c_{1}\\ \vdots\\ c_{n}\end{bmatrix}=\begin{bmatrix}\boldsymbol{w}_{1}\cdots\boldsymbol{w}_{n}\\ \end{bmatrix}\begin{bmatrix}d_{1}\\ \vdots\\ d_{n}\end{bmatrix}\text{and}V\boldsymbol{c}=\boldsymbol{W}\boldsymbol{d}. $$ 

The coefficients  $ d $ in the new basis of  $ w $'s are  $ d = W^{-1}Vc $. Then  $ B $ is  $ W^{-1}V $.

This formula  $ B = W^{-1}V $ produces one of the world’s greatest mysteries: When the standard basis  $ V = I $ is changed to a different basis  $ W $, the change of basis matrix is not  $ W $ but  $ B = W^{-1} $. Larger basis vectors have smaller coefficients!

 $$ \begin{bmatrix}x\\ y\end{bmatrix}in the standard basis has coefficients\begin{bmatrix}w_{1}&w_{2}\end{bmatrix}^{-1}\begin{bmatrix}x\\ y\end{bmatrix}in the w_{1},w_{2}basis. $$ 