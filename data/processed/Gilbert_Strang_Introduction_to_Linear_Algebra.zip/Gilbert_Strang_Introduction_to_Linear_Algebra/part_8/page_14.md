Example 5 Integration  $ T^{+} $ is also linear:  $ \int_{0}^{x}(D + Ex)\,dx = Dx + \frac{1}{2}Ex^{2} $.

The input basis is now 1, x. The output basis is 1,  $ x, x^{2} $. The matrix  $ A^{+} $ for  $ T^{+} $ is 3 by 2:

Input v  $ \mathbf{Multiplication} A^{+}v = \begin{bmatrix} 0 & 0 \\ 1 & 0 \\ 0 & \frac{1}{2} \end{bmatrix} \begin{bmatrix} D \\ E \end{bmatrix} = \begin{bmatrix} 0 \\ D \\ \frac{1}{2}E \end{bmatrix} $  $ \mathbf{Output} = \text{Integral of } v $  $ D + Ex $  $ T^{+}(v) = Dx + \frac{1}{2}Ex^{2} $

The Fundamental Theorem of Calculus says that integration is the (pseudo)inverse of differentiation. For linear algebra, the matrix  $ A^{+} $is the (pseudo)inverse of the matrix A:

 $$ \boldsymbol{A}^{+}\boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}} \\{{{0}}}&{{{\frac{1}{2}}}}\end{bmatrix}\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{2}}}\end{bmatrix}=\begin{bmatrix}{{{\mathbf{0}}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{\mathbf{1}}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{\mathbf{1}}}}\end{bmatrix}\quad and\quad\boldsymbol{A}\boldsymbol{A}^{+}=\begin{bmatrix}{{{\mathbf{1}}}}&{{{0}}} \\{{{0}}}&{{{\mathbf{1}}}}\end{bmatrix}. $$ 

The derivative of a constant function is zero. That zero is on the diagonal of  $ A^{+}A $. Calculus wouldn’t be calculus without that 1-dimensional nullspace of  $ T = d/dx $.

## Examples of Transformations (mostly linear)

Example 6 Project every 3-dimensional vector onto the horizontal plane z = 1. The vector  $ \boldsymbol{v} = (x, y, z) $ is transformed to  $ T(\boldsymbol{v}) = (x, y, 1) $. This transformation is not linear. Why not? It doesn’t even transform  $ \boldsymbol{v} = \mathbf{0} $ into  $ T(\boldsymbol{v}) = \mathbf{0} $.

Example 7 Suppose $A$ is an invertible matrix. Certainly $T(v + w) = Av + Aw = T(v) + T(w)$. Another linear transformation is multiplication by $A^{-1}$. This produces the inverse transformation $T^{-1}$, which brings every vector $T(v)$ back to $v$:

 $$ T^{-1}(T(\boldsymbol{v}))=\boldsymbol{v}\quad matches the matrix multiplication $$ 

If T(v) = Av and S(u) = Bu, then the product T(S(u)) matches the product ABu.

We are reaching an unavoidable question. Are all linear transformations from  $ \mathbf{V} = \mathbf{R}^n $ to  $ \mathbf{W} = \mathbf{R}^m $ produced by matrices? When a linear  $ T $ is described as a “rotation” or “projection” or “...”, is there always a matrix  $ A $ hiding behind  $ T $? Is  $ T(\mathbf{v}) $ always  $ A\mathbf{v} $?

The answer is yes! This is an approach to linear algebra that doesn't start with matrices. We still end up with matrices—after we choose an input basis and output basis.

Note Transformations have a language of their own. For a matrix, the column space contains all outputs Av. The nullspace contains all inputs for which Av = 0. Translate those words into “range” and “kernel”:

Range of T = set of all outputs  $ T(v) $. Range corresponds to column space.

Kernel of T = set of all inputs for which  $ T(\boldsymbol{v}) = 0 $. Kernel corresponds to nullspace.

The range is in the output space W. The kernel is in the input space V. When T is multiplication by a matrix,  $ T(v) = Av $, range is column space and kernel is nullspace.