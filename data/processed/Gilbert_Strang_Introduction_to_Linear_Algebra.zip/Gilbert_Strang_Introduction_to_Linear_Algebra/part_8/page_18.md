12 Suppose a linear T transforms (1, 1) to (2, 2) and (2, 0) to (0, 0). Find  $ T(v) $:

(a)  $ v = (2, 2) $ (b)  $ v = (3, 1) $ (c)  $ v = (-1, 1) $ (d)  $ v = (a, b) $.

### Problems 13-19 may be harder. The input space V contains all 2 by 2 matrices M

13 M is any 2 by 2 matrix and  $ A = \begin{bmatrix} 1 & 2 \\ 3 & 4 \end{bmatrix} $. The transformation T is defined by  $ T(M) = AM $. What rules of matrix multiplication show that T is linear?

14 Suppose  $ A = \begin{bmatrix} 1 & 2 \\ 3 & 5 \end{bmatrix} $. Show that the range of  $ T $ is the whole matrix space  $ V $ and the kernel is the zero matrix:

(1) If AM = 0 prove that M must be the zero matrix.

(2) Find a solution to AM = B for any 2 by 2 matrix B.

15 Suppose  $ A = \begin{bmatrix} 1 & 2 \\ 3 & 6 \end{bmatrix} $. Show that the identity matrix  $ I $ is not in the range of  $ T $. Find a nonzero matrix  $ M $ such that  $ T(M) = AM $ is zero.

16 Suppose $T$ transposes every 2 by 2 matrix $M$. Try to find a matrix $A$ which gives $AM = M^{\mathrm{T}}$. Show that no matrix $A$ will do it. To professors: Is this a linear transformation that doesn't come from a matrix? The matrix should be 4 by 4!

17 The transformation T that transposes every 2 by 2 matrix is definitely linear. Which of these extra properties are true?

(a)  $ T^{2} = $ identity transformation.

(b) The kernel of T is the zero matrix.

(c) Every 2 by 2 matrix is in the range of T.

(d)  $  T(M) = -M  $ is impossible.

18 Suppose  $ T(M) = \begin{bmatrix} 1 & 0 \\ 0 & 0 \end{bmatrix} \begin{bmatrix} M \\ 0 & 1 \end{bmatrix} $. Find a matrix with  $ T(M) \neq 0 $. Describe all matrices with  $ T(M) = 0 $ (the kernel) and all output matrices  $ T(M) $ (the range).

19 If A and B are invertible and  $ T(M) = AMB $, find  $ T^{-1}(M) $ in the form ( )  $ M(\quad) $.

Questions 20–26 are about house transformations. The output is  $ T(H) = AH $.

20 How can you tell from the picture of T (house) that A is

(a) a diagonal matrix?

(b) a rank-one matrix?

(c) a lower triangular matrix?

21 Draw a picture of  $ T $ (house) for these matrices:

 $$ D=\begin{bmatrix}{{{2}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{.7}}}&{{{.7}}} \\{{{.3}}}&{{{.3}}}\end{bmatrix}\quad and\quad U=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}. $$ 