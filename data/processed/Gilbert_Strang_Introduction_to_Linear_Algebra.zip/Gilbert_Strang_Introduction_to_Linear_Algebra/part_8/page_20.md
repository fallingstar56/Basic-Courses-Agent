### 8.2 The Matrix of a Linear Transformation

1 We know all $T(v)$ if we know $T(v_1), \ldots, T(v_n)$ for an input basis $v_1, \ldots, v_n$: use linearity.
2 Column $j$ in the “matrix for $T$” comes from applying $T$ to the input basis vector $v_j$.
3 Write $T(v_j) = a_{1j} w_1 + \cdots + a_{mj} w_m$ in the output basis of $w$’s. Those $a_{ij}$ go into column $j$.
4 The matrix for $T(x) = Ax$ is $A$, if the input and output bases = columns of $I_{n \times n}$ and $I_{m \times m}$.
5 When the bases change to $v$’s and $w$’s, the matrix for the same $T$ changes from $A$ to $W^{-1}AV$.
6 Best bases: $V = W = \text{eigenvectors}$ and $V, W = \text{singular vectors}$ give diagonal $\Lambda$ and $\Sigma$.

The next pages assign a matrix  $ A $ to every linear transformation  $ T $. For ordinary column vectors, the input  $ v $ is in  $ \mathbf{V} = \mathbf{R}^n $ and the output  $ T(v) $ is in  $ \mathbf{W} = \mathbf{R}^m $. The matrix  $ A $ for this transformation will be  $ m $ by  $ n $. Our choice of bases in  $ \mathbf{V} $ and  $ \mathbf{W} $ will decide  $ A $.

The standard basis vectors for  $ \mathbf{R}^n $ and  $ \mathbf{R}^m $ are the columns of  $ I $. That choice leads to a standard matrix. Then  $ T(\mathbf{v}) = Av $ in the normal way. But these spaces also have other bases, so the same transformation  $ T $ is represented by other matrices. A main theme of linear algebra is to choose the bases that give the best matrix (a diagonal matrix) for  $ T $.

All vector spaces V and W have bases. Each choice of those bases leads to a matrix for T. When the input basis is different from the output basis, the matrix for  $ T(v) = v $ will not be the identity I. It will be the “change of basis matrix”. Here is the key idea:

Suppose we know  $ T(v) $ for the input basis vectors  $ v_1 $ to  $ v_n $.
Columns 1 to n of the matrix will contain those outputs  $ T(v_1) $ to  $ T(v_n) $.
A times  $ c = \text{matrix times vector} = \text{combination of those } n \text{ columns} $.
Ac is the correct combination  $ c_1T(v_1) + \cdots + c_nT(v_n) = T(v) $.

Reason Every v is a unique combination  $ c_1 v_1 + \cdots + c_n v_n $ of the basis vectors  $ v_j $. Since T is a linear transformation (here is the moment for linearity),  $ T(v) $ must be the same combination  $ c_1 T(v_1) + \cdots + c_n T(v_n) $ of the outputs  $ T(v_j) $ in the columns.

Our first example gives the matrix A for the standard basis vectors in R2 and R3.

Example 1 Suppose $T$ transforms $\boldsymbol{v}_1 = (1,0)$ to $T(\boldsymbol{v}_1) = (2,3,4)$. Suppose the second basis vector $\boldsymbol{v}_2 = (0,1)$ goes to $T(\boldsymbol{v}_2) = (5,5,5)$. If $T$ is linear from $\mathbf{R}^2$ to $\mathbf{R}^3$ then its “standard matrix” is 3 by 2. Those outputs $T(\boldsymbol{v}_1)$ and $T(\boldsymbol{v}_2)$ go into the columns of $A$:

 $$ \begin{aligned}A&=\begin{bmatrix}{{{2}}}&{{{5}}} \\{{{3}}}&{{{5}}} \\{{{4}}}&{{{5}}}\end{bmatrix}\quad&c_{1}&=1and c_{2}=1give T(v_{1}+v_{2})=\begin{bmatrix}{{{2}}}&{{{5}}} \\{{{3}}}&{{{5}}} \\{{{4}}}&{{{5}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{1}}}\end{bmatrix}&=\begin{bmatrix}{{{7}}} \\{{{8}}} \\{{{9}}}\end{bmatrix}.\end{aligned} $$ 