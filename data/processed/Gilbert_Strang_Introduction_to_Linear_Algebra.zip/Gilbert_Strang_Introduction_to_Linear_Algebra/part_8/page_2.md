The Norm of a Matrix

If I choose one crucial number in the picture it is  $ \sigma_1 $. That number is the largest growth factor of any vector  $ \boldsymbol{x} $. If you follow the vector  $ \boldsymbol{v}_1 $ on the left, you see it rotate to  $ (1,0) $ and stretch to  $ (\sigma_1,0) $ and finally rotate to  $ \sigma_1\boldsymbol{u}_1 $. The statement  $ A\boldsymbol{v}_1 = \sigma_1\boldsymbol{u}_1 $ is exactly the SVD equation. This largest singular value  $ \sigma_1 $ is the “norm” of the matrix  $ A $.

The norm  $ \|A\| $ is the largest ratio  $ \frac{\|Ax\|}{\|x\|} $  $ \|A\| = \max_{x \neq 0} \frac{\|Ax\|}{\|x\|} = \sigma_1 $

MATLAB uses norm(x) for vector lengths and the same word norm(A) for matrix norms. The math symbols have double bars:  $ \|x\| $ and  $ \|A\| $. Here  $ \|x\| $ means the standard length of a vector with  $ \|x\|^2 = |x_1|^2 + \cdots + |x_n|^2 $. The matrix norm comes from this vector norm when  $ x = v_1 $ and  $ Ax = \sigma_1 u_1 $ and  $ \|Ax\| $ /  $ \|x\| $ =  $ \sigma_1 = $ largest ratio =  $ \|A\| $.

Two valuable properties of that number norm (A) come directly from its definition:

Triangle inequality

 $$ \left|\left|A+B\right|\right|\leq\left|\left|A\right|\right|+\left|\left|B\right|\right| $$ 

Product inequality

 $$ \left\| \mathbf{A}\mathbf{B} \right\|\leq \left\| \mathbf{A} \right\| \left\| \mathbf{B} \right\| $$ 

The definition (2) says that  $ ||Ax|| \leq ||A|| ||x|| $ for every vector x. That is what we know! Then the triangle inequality for vectors leads to the triangle inequality for matrices:

For vectors

 $$ ||(A+B)\boldsymbol{x}||\leq||A\boldsymbol{x}||+||B\boldsymbol{x}||\leq||A||||\boldsymbol{x}||+||B||||\boldsymbol{x}||. $$ 

Divide this by  $ \|x\| $. Take the maximum over all x. Then  $ \|A + B\| \leq \|A\| + \|B\| $.

The product inequality comes quickly from  $ \|ABx\| \leq \|A\|\|Bx\| \leq \|A\|\|B\|\|x\| $. Again divide by  $ \|x\| $. Take the maximum over all x. The result is  $ \|AB\| \leq \|A\|\|B\| $.

Example 1 A rank-one matrix  $ A = uv^\top $ is as basic as we can get. It has one nonzero eigenvalue  $ \lambda_1 $ and one nonzero singular value  $ \sigma_1 $. Neatly, its eigenvector is  $ u $ and its singular vectors (left and right) are  $ u $ and  $ v $.

Eigenvector

 $$ \boldsymbol{A}\boldsymbol{u}=(\boldsymbol{u}\boldsymbol{v}^{\mathrm{T}})\boldsymbol{u}=\boldsymbol{u}(\boldsymbol{v}^{\mathrm{T}}\boldsymbol{u})=\lambda_{1}\boldsymbol{u} $$ 

 $$ \mathrm{S o}\lambda_{1}=\boldsymbol{v}^{\mathrm{T}}\boldsymbol{u} $$ 

Singular vector  $ A^{\mathrm{T}}Av = (vu^{\mathrm{T}})(uv^{\mathrm{T}})v = v(u^{\mathrm{T}}u)(v^{\mathrm{T}}v) = \sigma_{1}^{2}v $  $ \mathrm{So}\sigma_{1} = ||u|| ||v|| $. It makes you feel good that  $ |\lambda_{1}| \leq \sigma_{1} $ is exactly the Schwarz inequality  $ |v^{\mathrm{T}}u| \leq ||u|| ||v|| $.

How do we know that  $ |\lambda_1| \leq \sigma_1 $? The eigenvector for  $ A\boldsymbol{x} = \lambda_1\boldsymbol{x} $ will give the ratio  $ ||A\boldsymbol{x}|| / ||\boldsymbol{x}|| = ||\lambda_1\boldsymbol{x}|| / ||\boldsymbol{x}|| $ which is  $ |\lambda_1| $. The maximum ratio  $ \sigma_1 $ can't be less than  $ |\lambda_1| $.

Is it also true that  $ |\lambda_2| \leq \sigma_2 $? No. That is completely wrong. In fact a 2 by 2 matrix will have  $ |\det A| = |\lambda_1\lambda_2| = \sigma_1\sigma_2 $. In this case  $ |\lambda_1| \leq \sigma_1 $ will force  $ |\lambda_2| \geq \sigma_2 $.