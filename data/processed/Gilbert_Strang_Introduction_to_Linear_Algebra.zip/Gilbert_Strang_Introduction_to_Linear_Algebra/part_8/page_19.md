22 What are the conditions on A =  $ \begin{bmatrix} a & b \\ c & d \end{bmatrix} $ to ensure that T (house) will

(a) sit straight up?

(b) expand the house by 3 in all directions?

(c) rotate the house with no change in its shape?

23 Describe  $ T $ (house) when  $ T(v) = -v + (1,0) $. This  $ T $ is “affine”.

24 Change the house matrix H to add a chimney.

25 The standard house is drawn by plot2d(H). Circles from o and lines from −:

 $$ \begin{array}{l}x=H(1,:)^{\prime};y=H(2,:)^{\prime};\\ axis([-1010-1010]),axis(^{\prime}square^{\prime})\\ plot(x,y,^{\prime}o^{\prime},x,y,^{\prime}-^{\prime});\end{array} $$ 

Test plot2d(A' * H) and plot2d(A' * A * H) with the matrices in Figure 8.1.

26 Without a computer sketch the houses A * H for these matrices A:

 $$ \begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{.1}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{.5}}}&{{{.5}}} \\{{{.5}}}&{{{.5}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{.5}}}&{{{.5}}} \\{{{-.5}}}&{{{.5}}}\end{bmatrix}\quad and\quad\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}. $$ 

This code creates a vector theta of 50 angles. It draws the unit circle and then it draws $T$ (circle) = ellipse. $T(v) = Av$ takes circles to ellipses.

A = [2 1; 1 2]    % You can change A
theta = [0:2 * pi/50:2 * pi];
circle = [cos(theta); sin(theta)];
ellipse = A * circle;
axis([-4 4 -4 4]); axis('square')
plot(circle(1,:), circle(2,:), ellipse(1,:), ellipse(2,:))

28 Add two eyes and a smile to the circle in Problem 27. (If one eye is dark and the other is light, you can tell when the face is reflected across the y axis.) Multiply by matrices A to get new faces.

29 What conditions on det A = ad - bc ensure that the output house AH will

(a) be squashed onto a line?

(b) keep its endpoints in clockwise order (not reflected)?

(c) have the same area as the original house?

30 Why does every linear transformation $T$ from $\mathbf{R}^{2}$ to $\mathbf{R}^{2}$ take squares to parallelograms? Rectangles also go to parallelograms (squashed if $T$ is not invertible).