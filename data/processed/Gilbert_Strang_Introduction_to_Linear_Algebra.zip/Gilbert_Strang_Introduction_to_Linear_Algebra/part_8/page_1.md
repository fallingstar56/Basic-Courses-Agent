### 7.4 The Geometry of the SVD

1 A typical square matrix  $ A = U \Sigma V^{\mathrm{T}} $ factors into (rotation) (stretching) (rotation).

2 The geometry shows how A transforms vectors x on a circle to vectors Ax on an ellipse.

3 The norm of A is  $ \|A\| = \sigma_{1} $. This singular value is its maximum growth factor  $ \|Ax\| $ /  $ \|x\| $.

4 Polar decomposition factors A into QS: rotation  $ Q = UV^{\mathrm{T}} $ times stretching  $ S = V \Sigma V^{\mathrm{T}} $.

5 The pseudoinverse A+ = VΣ+UT brings Ax in the column space back to x in the row space,

The SVD separates a matrix into three steps: (orthogonal)×(diagonal)×(orthogonal). Ordinary words can express the geometry behind it: (rotation)×(stretching)×(rotation).  $ U\Sigma V^{\mathrm{T}}x $ starts with the rotation to  $ V^{\mathrm{T}}x $. Then  $ \Sigma $ stretches that vector to  $ \Sigma V^{\mathrm{T}}x $, and  $ U $ rotates to  $ Ax = U\Sigma V^{\mathrm{T}}x $. Here is the picture.

<div style="text-align: center;">A</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_197_562_910_778.jpg" alt="Image" width="66%" /></div>


<div style="text-align: center;">Figure 7.5: U and V are rotations and possible reflections.  $ \Sigma $ stretches circle to ellipse.</div>


Admittedly, this picture applies to a 2 by 2 matrix. And not every 2 by 2 matrix, because U and V didn't allow for a reflection—all three matrices have determinant > 0. This A would have to be invertible because the three steps are shown as invertible:

 $$ \left[\begin{array}{c c}{a}&{b}\\ {c}&{d}\\ \end{array}\right]=\left[\begin{array}{c c}{\cos\theta}&{-\sin\theta}\\ {\sin\theta}&{\cos\theta}\\ \end{array}\right]\left[\begin{array}{c c}{\sigma_{1}}&{}\\ {}&{\sigma_{2}}\\ \end{array}\right]\left[\begin{array}{c c}{\cos\phi}&{\sin\phi}\\ {-\sin\phi}&{\cos\phi}\\ \end{array}\right]=U\Sigma V^{\mathrm{T}}. $$ 

The four numbers a, b, c, d in the matrix A led to four numbers  $ \theta $,  $ \sigma_{1} $,  $ \sigma_{2} $,  $ \phi $ in its SVD.

This picture will guide us to three neat ideas in the algebra of matrices:

1 The norm  $ \left\|A\right\| $ of a matrix—its maximum growth factor.

2 The polar decomposition  $ A = QS $—orthogonal Q times positive definite S.

3 The pseudoinverse  $ A^{+} $—the best inverse when the matrix A is not invertible.