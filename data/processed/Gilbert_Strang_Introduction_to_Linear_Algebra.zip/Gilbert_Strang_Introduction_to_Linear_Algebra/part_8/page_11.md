If the input is v = 0, the output must be  $ T(v) = 0 $. We combine rules (a) and (b) into one:

Linear transformation  $ T(cv + dw) $ must equal  $ cT(v) + dT(w) $.

Again I can test matrix multiplication for linearity:  $ A(cv + dw) = cAv + dAw $ is true.

A linear transformation is highly restricted. Suppose  $ T $ adds  $ u_0 $ to every vector. Then  $ T(v) = v + u_0 $ and  $ T(w) = w + u_0 $. This isn’t good, or at least it isn’t linear. Applying  $ T $ to  $ v + w $ produces  $ v + w + u_0 $. That is not the same as  $ T(v) + T(w) $:

Shift is not linear

 $$ \boldsymbol{v}+\boldsymbol{w}+\boldsymbol{u}_{0}\quad is not\quad T(\boldsymbol{v})+T(\boldsymbol{w})=(\boldsymbol{v}+\boldsymbol{u}_{0})+(\boldsymbol{w}+\boldsymbol{u}_{0}). $$ 

The exception is when  $ u_0 = 0 $. The transformation reduces to  $ T(v) = v $. This is the identity transformation (nothing moves, as in multiplication by the identity matrix). That is certainly linear. In this case the input space  $ V $ is the same as the output space  $ W $.

The linear-plus-shift transformation  $ T(\boldsymbol{v}) = Av + u_0 $ is called “affine”. Straight lines stay straight although T is not linear. Computer graphics works with affine transformations in Section 10.6, because we must be able to move images.

Example 1 Choose a fixed vector  $ a = (1, 3, 4) $, and let  $ T(v) $ be the dot product  $ a \cdot v $:

The input is  $ v = (v_1, v_2, v_3) $. The output is  $ T(v) = a \cdot v = v_1 + 3v_2 + 4v_3 $.

Dot products are linear. The inputs v come from three-dimensional space, so  $ \mathbf{V} = \mathbf{R}^3 $. The outputs are just numbers, so the output space is  $ \mathbf{W} = \mathbf{R}^1 $. We are multiplying by the row matrix  $ A = [1 \quad 3 \quad 4] $. Then  $ T(\mathbf{v}) = A\mathbf{v} $.

You will get good at recognizing which transformations are linear. If the output involves squares or products or lengths,  $ v_{1}^{2} $ or  $ v_{1}v_{2} $ or  $ \|v\| $, then T is not linear.

Example 2 The length  $ T(v) = \|v\| $ is not linear. Requirement (a) for linearity would be  $ \|v + w\| = \|v\| + \|w\| $. Requirement (b) would be  $ \|cv\| = c\|v\| $. Both are false!

Not (a): The sides of a triangle satisfy an inequality  $ \|v + w\| \leq \|v\| + \|w\| $.

Not (b): The length  $ \| - v\| $ is  $ \|v\| $ and not  $ -\|v\| $. For negative c, linearity fails.

Example 3 (Rotation) T is the transformation that rotates every vector by  $ 30^{\circ} $. The “domain” of T is the xy plane (all input vectors v). The “range” of T is also the xy plane (all rotated vectors  $ T(v) $). We described T without a matrix: rotate the plane by  $ 30^{\circ} $.

Is rotation linear? Yes it is. We can rotate two vectors and add the results. The sum of rotations  $ T(v) + T(w) $ is the same as the rotation  $ T(v + w) $ of the sum. The whole plane is turning together, in this linear transformation.