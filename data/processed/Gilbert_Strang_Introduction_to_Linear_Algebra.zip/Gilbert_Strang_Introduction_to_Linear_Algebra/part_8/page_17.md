4 If S and T are linear transformations, is  $ T(S(v)) $ linear or quadratic?

(a) (Special case) If  $ S(v) = v $ and  $ T(v) = v $, then  $ T(S(v)) = v $ or  $ v^{2} $?

(b) (General case)  $  S(v_1 + v_2) = S(v_1) + S(v_2)  $ and  $  T(v_1 + v_2) = T(v_1) + T(v_2)  $ combine into

 $$ T(S(v_{1}+v_{2}))=T(\_\_\_\_)=\_\_\_\_+\_\_\_\_. $$ 

5 Suppose  $ T(v) = v $ except that  $ T(0, v_2) = (0, 0) $. Show that this transformation satisfies  $ T(cv) = cT(v) $ but does not satisfy  $ T(v + w) = T(v) + T(w) $.

6 Which of these transformations satisfy  $ T(v + w) = T(v) + T(w) $ and which satisfy  $ T(cv) = cT(v) $?

(a)  $ T(\boldsymbol{v}) = \boldsymbol{v} / \| \boldsymbol{v} \| $ (b)  $ T(\boldsymbol{v}) = v_1 + v_2 + v_3 $ (c)  $ T(\boldsymbol{v}) = (v_1, 2v_2, 3v_3) $

(d)  $  T(v) = \text{largest component of } v  $.

7 For these transformations of  $ \mathbf{V} = \mathbf{R}^2 $ to  $ \mathbf{W} = \mathbf{R}^2 $, find  $ T(T(\mathbf{v})) $. Show that when  $ T(\mathbf{v}) $ is linear, then also  $ T(T(\mathbf{v})) $ is linear.

(a)  $ T(v) = -v $ (b)  $ T(v) = v + (1,1) $

(c)  $  T(v) = 90^\circ  $ rotation =  $ (-v_2, v_1) $

 $$ \begin{array}{r}{(\mathbf{d})~T(\mathbf{v})=\mathrm{p r o j e c t i o n}=\frac{1}{2}\big(v_{1}+v_{2},~v_{1}+v_{2}\big).}\end{array} $$ 

8 Find the range and kernel (like the column space and nullspace) of T:

 $$ \left(\mathbf{a}\right)T(v_{1},v_{2})=(v_{1}-v_{2},0) $$ 

(b)  $  T(v_{1}, v_{2}, v_{3}) = (v_{1}, v_{2})  $

 $$ T(v_{1},v_{2})=(0,0) $$ 

 $$ (\mathbf{d})~T(v_{1},v_{2})=(v_{1},v_{1}). $$ 

9 The “cyclic” transformation  $ T $ is defined by  $ T(v_1, v_2, v_3) = (v_2, v_3, v_1) $. What is  $ T(T(v)) $? What is  $ T^3(v) $? What is  $ T^{100}(v) $? Apply  $ T $ a hundred times to  $ v $.

10 A linear transformation from V to W has an inverse from W to V when the range is all of W and the kernel contains only v = 0. Then  $ T(v) = w $ has one solution v for each w in W. Why are these T's not invertible?

 $$ (\mathbf{a})~T(v_{1},v_{2})=(v_{2},v_{2})\quad\mathbf{W}=\mathbf{R}^{2} $$ 

 $$ \mathbf{(b)}\;T(v_{1},v_{2})=(v_{1},v_{2},v_{1}+v_{2})\qquad\mathbf{W}=\mathbf{R}^{3} $$ 

(c)

 $$ T(v_{1},v_{2})=v_{1} $$ 

 $$ \mathbf{W}=\mathbf{R}^{1} $$ 

11 If  $ T(v) = Av $ and A is m by n, then T is “multiplication by A.”

(a) What are the input and output spaces V and W?

(b) Why is range of T = column space of A?

(c) Why is kernel of T = nullspace of A?