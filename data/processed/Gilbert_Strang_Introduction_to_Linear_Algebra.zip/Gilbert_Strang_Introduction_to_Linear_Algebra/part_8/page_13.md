## Example 4 The transformation T takes the derivative of the input:  $ T(u) = du/dx $

How do you find the derivative of  $ u = 6 - 4x + 3x^2 $? You start with the derivatives of 1, x, and  $ x^2 $. Those are the basis vectors. Their derivatives are 0, 1, and 2x. Then you use linearity for the derivative of any combination:

 $$ \frac{du}{dx}=6\left(\mathrm{derivative~of~}1\right)-4\left(\mathrm{derivative~of~}x\right)+3\left(\mathrm{derivative~of~}x^{2}\right)=-4+6x. $$ 

All of calculus depends on linearity! Precalculus finds a few key derivatives, for  $ x^n $ and  $ \sin x $ and  $ \cos x $ and  $ e^x $. Then linearity applies to all their combinations.

I would say that the only rule special to calculus is the chain rule. That produces the derivative of a chain of functions  $ f(g(x)) $.

Nullspace of  $ T(u) = du/dx $. For the nullspace we solve  $ T(u) = 0 $. The derivative is zero when u is a constant function. So the one-dimensional nullspace is a line in function space—all multiples of the special solution u = 1.

Column space of  $ T(u) = du/dx $. In our example the input space contains all quadratics  $ a + bx + cx^2 $. The outputs (the column space) are all linear functions  $ b + 2cx $. Notice that the Counting Theorem is still true:  $ \boldsymbol{r} + (\boldsymbol{n} - \boldsymbol{r}) = \boldsymbol{n} $.

dimension (column space) + dimension (nullspace) = 2 + 1 = 3 = dimension (input space)

What is the matrix for  $ d/dx $? I can't leave derivatives without asking for a matrix. We have a linear transformation  $ T = d/dx $. We know what  $ T $ does to the basis functions:

 $$ v_{1},v_{2},v_{3}=1,x,x^{2}\qquad\frac{d v_{1}}{d x}=0\qquad\frac{d v_{2}}{d x}=1=v_{1}\qquad\frac{d v_{3}}{d x}=2x=2v_{2}. $$ 

The 3-dimensional input space  $ \mathbf{V} $ (= quadratics) transforms to the 2-dimensional output space  $ \mathbf{W} $ (= linear functions). If  $ \mathbf{v}_1, \mathbf{v}_2, \mathbf{v}_3 $ were vectors, I would know the matrix.

 $$ \left|\begin{array}{c c c}{{A=\left[\begin{array}{c c c}{{0}}&{{1}}&{{0}}\\ {{0}}&{{0}}&{{2}}\end{array}\right]=\mathrm{m a t r i x~f o r m~o f~t h e~d e r i v a t i v e}}}\\ \end{array}T=\frac{d}{d x}.\right| $$ 

The linear transformation du/dx is perfectly copied by the matrix multiplication Au.

 $$ \mathbf{M u l t i p l i c a t i o n}A u=\begin{bmatrix}0&1&0\\ 0&0&2\end{bmatrix}\begin{bmatrix}a\\ b\\ c\end{bmatrix}=\begin{bmatrix}b\\ 2c\end{bmatrix}\quad\mathbf{O u t p u t}\frac{d u}{d x}=b+2c x. $$ 

The connection from T to A (we will connect every transformation to a matrix) depended on choosing an input basis 1, x,  $ x^{2} $ and an output basis 1, x.

Next we look at integrals. They give the pseudoinverse  $ T^{+} $of the derivative! I can't write  $ T^{-1} $ and I can't say “inverse of  $ T $” when the derivative of 1 is 0.