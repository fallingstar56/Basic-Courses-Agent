### Problem Set 7.3

1 Suppose  $ A_{0} $ holds these 2 measurements of 5 samples:

 $$ A_{0}=\left[\begin{array}{cccc}{{{5}}}&{{{4}}}&{{{3}}}&{{{2}}}&{{{1}}} \\{{{-1}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{-1}}}\end{array}\right] $$ 

Find the average of each row and subtract it to produce the centered matrix  $ A $. Compute the sample covariance matrix  $ S = AA^{\mathrm{T}}/(n-1) $ and find its eigenvalues  $ \lambda_1 $ and  $ \lambda_2 $. What line through the origin is closest to the 5 samples in columns of  $ A $?

2 Take the steps of Problem 1 for this 2 by 6 matrix  $ A_{0} $ :

 $$ A_{0}=\left[\begin{array}{ccccc}{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{3}}}&{{{2}}}&{{{1}}}\end{array}\right] $$ 

3 The sample variances  $ s_{1}^{2}, s_{2}^{2} $ and the sample covariance  $ s_{12} $ are the entries of S.

What is S (after subtracting means) when A_{0}=\left[\begin{array}{ccc}1 & 2 & 3 \\ 5 & 2 & 2\end{array}\right]? What is \sigma_{1}?

4 From the eigenvectors of  $ S = AA^{\mathrm{T}} $, find the line (the  $ u_1 $ direction through the center point) and then the plane  $ (\boldsymbol{u}_1, \boldsymbol{u}_2 $ directions) closest to these four points in three-dimensional space:

 $$ \boldsymbol{A}=\left[\begin{array}{ccc}{{{1}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{-2}}} \\{{{1}}}&{{{1}}}&{{{-1}}}&{{{-1}}}\end{array}\right]. $$ 

5 From this sample covariance matrix S, find the correlation matrix DSD with 1's down its main diagonal. D is a positive diagonal matrix that produces those 1's.

 $$ \boldsymbol{S}=\left[\begin{array}{lll}{{{4}}}&{{{2}}}&{{{0}}} \\{{{2}}}&{{{4}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}}\end{array}\right]. $$ 

6 Choose the diagonal matrix D that produces DSD and find the correlations  $ c_{ij} $:

 $$ S=\left[\begin{array}{c c c}s_{1}^{2}&s_{12}&s_{13}\\ s_{12}&s_{2}^{2}&s_{23}\\ s_{13}&s_{23}&s_{3}^{2}\end{array}\right]\qquad D S D=\left[\begin{array}{c c c}1&c_{12}&c_{13}\\ c_{12}&1&c_{23}\\ c_{13}&c_{23}&1\end{array}\right]. $$ 

7 Suppose  $ A_{0} $ is a 5 by 10 matrix with average grades for 5 courses over 10 years. How would you create the centered matrix A and the sample covariance matrix  $ S' $? When you find the leading eigenvector of S, what does it tell you?