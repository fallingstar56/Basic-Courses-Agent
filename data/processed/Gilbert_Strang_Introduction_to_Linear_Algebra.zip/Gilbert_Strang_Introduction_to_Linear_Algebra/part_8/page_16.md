## WORKED EXAMPLES

8.1 A The elimination matrix  $ \left[\begin{array}{c}1 \\ 1\end{array}\right]^{0} $ gives a shearing transformation from  $ (x,y) $ to  $ T(x,y)=(x,x+y) $. If the inputs fill a square, draw the transformed square.

Solution The points  $ (1,0) $ and  $ (2,0) $ on the x axis transform by  $ T $ to  $ (1,1) $ and  $ (2,2) $ on the  $ 45^\circ $ line. Points on the y axis are not moved:  $ T(0,y)=(0,y)=\text{eigenvectors} $ with  $ \lambda=1 $.

Vertical lines slide up

This is the shearing

Squares go to parallelograms

 $$ \begin{aligned}&\boldsymbol{A}=\left[\begin{array}{cc}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{array}\right]\quad\boxed{v}\quad(1,1)\\&\boldsymbol{z}\quad(1,0)\\ \end{aligned} $$ 

 $$ \bigcirc\bigcirc T(v)\bigcirc\bigcirc(1,2) $$ 

8.1 B A nonlinear transformation T is invertible if every b in the output space comes from exactly one x in the input space:  $ T(x) = b $ always has exactly one solution. Which of these transformations (on real numbers x) is invertible and what is  $ T^{-1} $? None are linear, not even  $ T_3 $. When you solve  $ T(x) = b $, you are inverting T:

 $$ T_{1}(x)=x^{2}\quad T_{2}(x)=x^{3}\quad T_{3}(x)=x+9\quad T_{4}(x)=e^{x}\quad T_{5}(x)=\frac{1}{x}\quad for nonzero x^{\prime}s $$ 

Solution  $ T_{1} $ is not invertible:  $ x^{2}=1 $ has two solutions and  $ x^{2}=-1 $ has no solution.  $ T_{4} $ is not invertible because  $ e^{x}=-1 $ has no solution. (If the output space changes to positive b's then the inverse of  $ e^{x}=b $ is  $ x=\ln b $.)

Notice  $ T_5^2 = $ identity. But  $ T_3^2(x) = x + 18 $. What are  $ T_2^2(x) $ and  $ T_4^2(x) $?

 $ T_{2}, T_{3}, T_{5} $ are invertible:  $ x^{3} = b $ and  $ x + 9 = b $ and  $ \frac{1}{x} = b $ have one solution x.

 $$ x=T_{2}^{-1}(b)=b^{1/3}\quad x=T_{3}^{-1}(b)=b-9\quad x=T_{5}^{-1}(b)=1/b $$ 

### Problem Set 8.1

1 A linear transformation must leave the zero vector fixed:  $ T(\mathbf{0}) = \mathbf{0} $. Prove this from  $ T(\mathbf{v} + \mathbf{w}) = T(\mathbf{v}) + T(\mathbf{w}) $ by choosing  $ \mathbf{w} = $ ___ (and finish the proof). Prove it also from  $ T(cv) = cT(\mathbf{v}) $ by choosing  $ c = $ ___ .

2 Requirement (b) gives  $ T(cv) = cT(v) $ and also  $ T(dw) = dT(w) $. Then by addition, requirement (a) gives  $ T(\quad) = (\quad) $. What is  $ T(cv + dw + eu) $?

3 Which of these transformations are not linear? The input is  $ \boldsymbol{v} = (v_{1}, v_{2}) $:

(a)

 $$ T(\boldsymbol{v})=(v_{2},v_{1}) $$ 

(b)

 $$ T(\boldsymbol{v})=(v_{1},v_{1}) $$ 

(c)

 $$ T(\boldsymbol{v})=(0,v_{1}) $$ 

 $$ (\mathbf{d})~T(\boldsymbol{v})=(0,1)\qquad(\mathbf{e})\quad T(\boldsymbol{v})=v_{1}-v_{2}\qquad(\mathbf{f})\quad T(\boldsymbol{v})=v_{1}v_{2}. $$ 