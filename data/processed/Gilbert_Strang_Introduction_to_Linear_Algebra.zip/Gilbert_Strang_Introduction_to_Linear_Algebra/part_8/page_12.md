## Lines to Lines, Triangles to Triangles, Basis Tells All

Figure 8.1 shows the line from v to w in the input space. It also shows the line from  $ T(v) $ to  $ T(w) $ in the output space. Linearity tells us: Every point on the input line goes onto the output line. And more than that: Equally spaced points go to equally spaced points. The middle point  $ u = \frac{1}{2}v + \frac{1}{2}w $ goes to the middle point  $ T(u) = \frac{1}{2}T(v) + \frac{1}{2}T(w) $.

The second figure moves up a dimension. Now we have three corners  $ v_1 $,  $ v_2 $,  $ v_3 $. Those inputs have three outputs  $ T(v_1) $,  $ T(v_2) $,  $ T(v_3) $. The input triangle goes onto the output triangle. Equally spaced points stay equally spaced (along the edges, and then between the edges). The middle point  $ \mathbf{u} = \frac{1}{3}(v_1 + v_2 + v_3) $ goes to the middle point  $ T(\mathbf{u}) = \frac{1}{3}(T(v_1) + T(v_2) + T(v_3)) $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_174_381_839_605.jpg" alt="Image" width="62%" /></div>


<div style="text-align: center;">Figure 8.1: Lines to lines, equal spacing to equal spacing,  $ \boldsymbol{u} = \boldsymbol{0} $ to  $ T(\boldsymbol{u}) = \boldsymbol{0} $.</div>


The rule of linearity extends to combinations of three vectors or n vectors:

Linearity

 $$ u=c_{1}v_{1}+c_{2}v_{2}+\cdots+c_{n}v_{n} $$ 

must transform to

 $$ T(\boldsymbol{u})=c_{1}T(\boldsymbol{v}_{1})+c_{2}T(\boldsymbol{v}_{2})+\cdots+c_{n}T(\boldsymbol{v}_{n}) $$ 

The 2-vector rule starts the 3-vector proof:  $ T(c\boldsymbol{u} + dv + e\boldsymbol{w}) = T(c\boldsymbol{u}) + T(dv + e\boldsymbol{w}) $. Then linearity applies to both of those parts, to give  $ cT(\boldsymbol{u}) + dT(\boldsymbol{v}) + eT(\boldsymbol{w}) $.

The n-vector rule (1) leads to the most important fact about linear transformations:

Suppose you know  $ T(v) $ for all vectors  $ v_{1}, \ldots, v_{n} $ in a basis

Then you know  $ T(u) $ for every vector u in the space.

You see the reason: Every u in the space is a combination of the basis vectors  $ v_j $

Then linearity tells us that  $ T(u) $ is the same combination of the outputs  $ T(v_j) $.