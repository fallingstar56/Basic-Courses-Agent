## Construction of the Matrix

Now we construct a matrix for any linear transformation. Suppose $T$ transforms the space $\mathbf{V}$ ($n$-dimensional) to the space $\mathbf{W}$ ($m$-dimensional). We choose a basis $v_1, \ldots, v_n$ for $\mathbf{V}$ and we choose a basis $w_1, \ldots, w_m$ for $\mathbf{W}$. The matrix $A$ will be $m$ by $n$. To find the first column of $A$, apply $T$ to the first basis vector $v_1$. The output $T(v_1)$ is in $\mathbf{W}$.

 $ T(v_{1}) $ is a combination

 $$ a_{11}w_{1}+\cdots+a_{m1}w_{m} $$ 

of the output basis for W.

These numbers  $ a_{11}, \ldots, a_{m1} $ go into the first column of A. Transforming  $ v_1 $ to  $ T(v_1) $ matches multiplying  $ (1,0,\ldots,0) $ by A. It yields that first column of the matrix. When T is the derivative and the first basis vector is 1, its derivative is  $ T(v_1) = 0 $. So for the derivative matrix below, the first column of A is all zero.

Example 3 The input basis of $v$'s is $1, x, x^2, x^3$. The output basis of $w$'s is $1, x, x^2$. Then $T$ takes the derivative: $T(v) = \frac{dv}{dx}$ and $A$ = “derivative matrix”.

 $$ \begin{aligned}&\mathrm{If}\boldsymbol{v}=c_{1}+c_{2}x+c_{3}x^{2}+c_{4}x^{3}\\&\mathrm{then}\frac{d\boldsymbol{v}}{d x}=\mathbf{1}c_{2}+\mathbf{2}c_{3}x+\mathbf{3}c_{4}x^{2}\end{aligned}\quad\begin{aligned}Ac&=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{3}}}\end{bmatrix}\begin{bmatrix}{{{c_{1}}}} \\{{{c_{2}}}} \\{{{c_{3}}}} \\{{{c_{4}}}}\end{bmatrix}=\begin{bmatrix}{{{c_{2}}}} \\{{{2c_{3}}}} \\{{{3c_{4}}}}\end{bmatrix}\end{aligned} $$ 

Key rule: The jth column of A is found by applying T to the jth basis vector  $ v_{j} $

 $$ T(\boldsymbol{v}_{j})=combination of output basis vectors=a_{1j}\boldsymbol{w}_{1}+\cdots+a_{mj}\boldsymbol{w}_{m}. $$ 

These numbers  $ a_{ij} $ go into A. The matrix is constructed to get the basis vectors right. Then linearity gets all other vectors right. Every v is a combination  $ c_1 v_1 + \cdots + c_n v_n $, and  $ T(v) $ is a combination of the w's. When A multiplies the vector  $ \boldsymbol{c} = (c_1, \ldots, c_n) $ in the v combination, Ac produces the coefficients in the  $ T(v) $ combination. This is because matrix multiplication (combining columns) is linear like T.

The matrix A tells us what T does. Every linear transformation from V to W can be converted to a matrix. This matrix depends on the bases.

Example 4 For the integral  $ T^{+}(v) $, the first basis function is again 1. Its integral is the second basis function x. So the first column of the “integral matrix”  $ A^{+} $ is  $ (0,1,0,0) $.

 $$ \begin{array}{l}{{{\mathrm{T h e~i n t e g r a l~o f~}d_{1}+d_{2}x+d_{3}x^{2}\quad}}} \\{{{\mathrm{i s}\quad d_{1}x+\frac{1}{2}d_{2}x^{2}+\frac{1}{3}d_{3}x^{3}\quad}}} \\{{{A^{+}d=\left[\begin{array}{l l l}0}}}&{0}}}&{0}}} \\{{{1}}}&{0}}}&{0}}} \\{{{0}}}&{{{\frac{1}{2}}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{\frac{1}{3}}}}\end{array}\right]\left[\begin{array}{l}{{{d_{1}}}} \\{{{d_{2}}}} \\{{{d_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{0}}} \\{{{d_{1}}}} \\{{{\frac{1}{2}d_{2}}}} \\{{{\frac{1}{3}d_{3}}}}\end{array}\right]\end{array} $$ 