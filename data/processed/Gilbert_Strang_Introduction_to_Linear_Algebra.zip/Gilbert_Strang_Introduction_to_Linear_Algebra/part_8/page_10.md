## Chapter 8

## Linear Transformations

### 8.1 The Idea of a Linear Transformation

1 A linear transformation T takes vectors v to vectors T(v). Linearity requires
 $$ 
\begin{aligned}
& T(c\,v + d\,w) = c\,T(v) + d\,T(w) \\
& \text{Note } T(\mathbf{0}) = \mathbf{0} \text{ so } T(v) = v + u_0 \text{ is not linear.}
\end{aligned}
 $$ 
2 The input vectors v and outputs T(v) can be in \mathbf{R}^n or matrix space or function space.
3 If A is m by n, T(x) = Ax is linear from the input space \mathbf{R}^n to the output space \mathbf{R}^m.
4 The derivative T(f) = \frac{df}{dx} is linear. The integral T^+(f) = \int_0^x f(t) \, dt is its pseudoinverse.
5 The product ST of two linear transformations is still linear:
 $$ 
\begin{aligned}
(ST)(v) &= S(T(v)).
\end{aligned}

When a matrix  $ A $ multiplies a vector  $ v $, it “transforms”  $ v $ into another vector  $ Av $. In goes  $ v $, out comes  $ T(v) = Av $. A transformation  $ T $ follows the same idea as a function. In goes a number  $ x $, out comes  $ f(x) $. For one vector  $ v $ or one number  $ x $, we multiply by the matrix or we evaluate the function. The deeper goal is to see all vectors  $ v $ at once. We are transforming the whole space  $ \mathbf{V} $ when we multiply every  $ v $ by  $ A $.

Start again with a matrix A. It transforms v to Av. It transforms w to Aw. Then we know what happens to  $ \boldsymbol{u} = \boldsymbol{v} + \boldsymbol{w} $. There is no doubt about Au, it has to equal Av + Aw. Matrix multiplication  $ T(\boldsymbol{v}) = Av $ gives a linear transformation:

A transformation T assigns an output T(v) to each input vector v in V. The transformation is linear if it meets these requirements for all v and w:

(a)  $ T(v + w) = T(v) + T(w) $

(b)  $ T(cv) = cT(v) $ for all c.

