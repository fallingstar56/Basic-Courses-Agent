## Eigenvalues versus Pivots

The eigenvalues of A are very different from the pivots. For eigenvalues, we solve  $ \det(A - \lambda I) = 0 $. For pivots, we use elimination. The only connection so far is this:

product of pivots = determinant = product of eigenvalues.

We are assuming a full set of pivots  $ d_1, \ldots, d_n $. There are  $ n $ real eigenvalues  $ \lambda_1, \ldots, \lambda_n $. The  $ d' $s and  $ \lambda' $s are not the same, but they come from the same symmetric matrix. Those  $ d' $s and  $ \lambda' $s have a hidden relation. For symmetric matrices the pivots and the eigenvalues have the same signs:

The number of positive eigenvalues of  $ S = S^{\mathrm{T}} $ equals the number of positive pivots.

Special case: S has all  $ \lambda_i > 0 $ if and only if all pivots are positive.

That special case is an all-important fact for positive definite matrices in Section 6.5.

Example 4 This symmetric matrix has one positive eigenvalue and one positive pivot:

Matching signs

 $$ S=\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{3}}}&{{{1}}}\end{bmatrix}\qquad has pivots 1 and -8\qquad eigenvalues 4 and -2. $$ 

The signs of the pivots match the signs of the eigenvalues, one plus and one minus. This could be false when the matrix is not symmetric:

Opposite signs

 $$ B=\begin{bmatrix}{{{1}}}&{{{6}}} \\{{{-1}}}&{{{-4}}}\end{bmatrix}\quad has pivots 1 and 2\quad\\ eigenvalues-1and-2. $$ 

The diagonal entries are a third set of numbers and we say nothing about them.

Here is a proof that the pivots and eigenvalues have matching signs, when  $ S = S^{T} $.

You see it best when the pivots are divided out of the rows of U. Then $S$ is $LDL^{\mathrm{T}}$. The diagonal pivot matrix $D$ goes between triangular matrices $L$ and $L^{\mathrm{T}}$:

 $$ \begin{bmatrix}{{{1}}}&{{{3}}} \\{{{3}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{3}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{-8}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad\mathbf{T}\mathbf{h}\mathbf{i s}\mathbf{i s}S=L D L^{\mathrm{T}}.\mathbf{I}t\mathbf{i s}\mathbf{s y m m e t r i c}. $$ 

Watch the eigenvalues of  $ LDL^{T} $ when L moves to I. S changes to D.

The eigenvalues of  $ LDL^{\mathrm{T}} $ are 4 and -2. The eigenvalues of  $ IDI^{\mathrm{T}} $ are 1 and -8 (the pivots!). The eigenvalues are changing, as the “3” in L moves to zero. But to change sign, a real eigenvalue would have to cross zero. The matrix would at that moment be singular. Our changing matrix always has pivots 1 and -8, so it is never singular. The signs cannot change, as the  $ \lambda $'s move to the  $ d $'s.

We repeat the proof for any  $ S = LDL^{\mathrm{T}} $. Move  $ L $ toward  $ I $, by moving the off-diagonal entries to zero. The pivots are not changing and not zero. The eigenvalues  $ \lambda $ of  $ LDL^{\mathrm{T}} $ change to the eigenvalues  $ d $ of  $ IDI^{\mathrm{T}} $. Since these eigenvalues cannot cross zero as they move into the pivots, their signs cannot change. Same signs for the  $ \lambda $'s and  $ d $'s.

This connects the two halves of applied linear algebra—pivots and eigenvalues.