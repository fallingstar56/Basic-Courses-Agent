## Chapter 7

# The Singular Value Decomposition (SVD)

### 7.1 Image Processing by Linear Algebra

1 An image is a large matrix of grayscale values, one for each pixel and color.
2 When nearby pixels are correlated (not random) the image can be compressed.
3 The SVD separates any matrix A into rank one pieces  $ uv^{\mathrm{T}} = (\text{column})(\text{row}) $.
4 The columns and rows are eigenvectors of symmetric matrices  $ AA^{\mathrm{T}} $ and  $ A^{\mathrm{T}}A $.

The singular value theorem for A is the eigenvalue theorem for  $ A^{T}A $ and  $ AA^{T} $.

That is a quick preview of what you will see in this chapter. A has two sets of singular vectors (the eigenvectors of  $ A^T A $ and  $ AA^T $). There is one set of positive singular values (because  $ A^T A $ has the same positive eigenvalues as  $ AA^T $). A is often rectangular, but  $ A^T A $ and  $ AA^T $ are square, symmetric, and positive semidefinite.

The Singular Value Decomposition (SVD) separates any matrix into simple pieces.

Each piece is a column vector times a row vector. An m by n matrix has m times n entries (a big number when the matrix represents an image). But a column and a row only have  $ m + n $ components, far less than m times n. Those (column)(row) pieces are full size matrices that can be processed with extreme speed—they need only m plus n numbers.

Unusually, this image processing application of the SVD is coming before the matrix algebra it depends on. I will start with simple images that only involve one or two pieces. Right now I am thinking of an image as a large rectangular matrix. The entries  $ a_{ij} $ tell the grayscales of all the pixels in the image. Think of a pixel as a small square, i steps across and j steps up from the lower left corner. Its grayscale is a number (often a whole number in the range  $ 0 \leq a_{ij} < 256 = 2^8 $). An all-white pixel has  $ a_{ij} = 255 = 11111111 $. That number has eight 1's when the computer writes 255 in binary notation.