(b) Choose  $ v_2 $ and  $ u_2 $ in  $ U $ and  $ V $. Then  $ A = U \Sigma V^\mathrm{T} = u_1 \sigma_1 v_1^\mathrm{T} $ (one term only).

Substitute the SVD for $A$ and $A^{\mathrm{T}}$ to show that $A^{\mathrm{T}}A$ has its eigenvalues in $\Sigma^{\mathrm{T}}\Sigma$ and $AA^{\mathrm{T}}$ has its eigenvalues in $\Sigma\Sigma^{\mathrm{T}}$. Since a diagonal $\Sigma^{\mathrm{T}}\Sigma$ has the same nonzeros as $\Sigma\Sigma^{\mathrm{T}}$, we see again that $A^{\mathrm{T}}A$ and $AA^{\mathrm{T}}$ have the same nonzero eigenvalues.

If $(A^{\mathrm{T}}A)v=\sigma^{2}v$, multiply by $A$. Move the parentheses to get $(AA^{\mathrm{T}})Av=\sigma^{2}(Av)$. If $v$ is an eigenvector of $A^{\mathrm{T}}A$, then ___ is an eigenvector of $AA^{\mathrm{T}}$.

8 Find the eigenvalues and unit eigenvectors  $ v_1, v_2 $ of  $ A^\mathrm{T}A $. Then find  $ u_1 = Av_1/\sigma_1 $:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{3}}}&{{{6}}}\end{bmatrix}\quad and\quad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\begin{bmatrix}{{{10}}}&{{{20}}} \\{{{20}}}&{{{40}}}\end{bmatrix}\quad and\quad\boldsymbol{A}\boldsymbol{A}^{\mathrm{T}}=\begin{bmatrix}{{{5}}}&{{{15}}} \\{{{15}}}&{{{45}}}\end{bmatrix}. $$ 

Verify that  $ u_1 $ is a unit eigenvector of  $ AA^\top $. Complete the matrices  $ U, \Sigma, V $.

SVD

 $$ \left[\begin{array}{l l}{1}&{2}\\ {3}&{6}\end{array}\right]=\left[\begin{array}{l l}{u_{1}}&{u_{2}}\end{array}\right]\left[\begin{array}{c c}{\sigma_{1}}&{}\\ {}&{0}\end{array}\right]\left[\begin{array}{l l}{v_{1}}&{v_{2}}\end{array}\right]^{\mathrm{T}}. $$ 

Write down orthonormal bases for the four fundamental subspaces of this A.

(a) Why is the trace of  $ A^{T}A $ equal to the sum of all  $ a_{ij}^{2} $? In Example 3 it is 50.

(b) For every rank-one matrix, why is  $ \sigma_{1}^{2} = \sum_{i} a_{ij}^{2} $?

 $$ A^{\mathrm{T}}A $$ 

 $$ \boldsymbol{A}\boldsymbol{A}^{\mathrm{T}} $$ 

 $$ Av=\sigma u $$ 

 $$ U\Sigma V^{\mathrm{T}} $$ 

Fibonacci matrix

 $$ \boldsymbol{A}=\left[\begin{array}{ll}{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{array}\right] $$ 

Use the svd part of the MATLAB demo eigshow to find those v's graphically.

If $A = U \Sigma V^{\mathrm{T}}$ is a square invertible matrix then $A^{-1} = \underline{\qquad} \qquad \qquad \

Note: The largest singular value of  $ A^{-1} $ is therefore  $ 1/\sigma_{\min}(A) $. The largest eigenvalue  $ |\lambda(A^{-1})|_{\max} $ is  $ 1/|\lambda(A)|_{\min} $. Then equation (14) says that  $ \sigma_{\min}(A) \leq |\lambda(A)|_{\min} $.

Suppose  $ u_1, \ldots, u_n $ and  $ v_1, \ldots, v_n $ are orthonormal bases for  $ \mathbf{R}^n $. Construct the matrix  $ A = U \Sigma V^\mathrm{T} $ that transforms each  $ v_j $ into  $ u_j $ to give  $ Av_1 = u_1, \ldots, Av_n = u_n $.

Construct the matrix with rank one that has $Av = 12u$ for $v = \frac{1}{2}(1,1,1,1)$ and $u = \frac{1}{3}(2,2,1)$. Its only singular value is $\sigma_{1} = \underline{\qquad}$.

Suppose $A$ has orthogonal columns $w_{1}, w_{2}, \ldots, w_{n}$ of lengths $\sigma_{1}, \sigma_{2}, \ldots, \sigma_{n}$. What are $U$, $\Sigma$, and $V$ in the SVD?

17 Suppose $A$ is a 2 by 2 symmetric matrix with unit eigenvectors $u_1$ and $u_2$. If its eigenvalues are $\lambda_1 = 3$ and $\lambda_2 = -2$, what are the matrices $U$, $\Sigma$, $V^\mathrm{T}$ in its SVD?