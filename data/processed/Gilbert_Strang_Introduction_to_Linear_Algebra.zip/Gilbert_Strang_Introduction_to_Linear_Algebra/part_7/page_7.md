Find all 2 by 2 matrices that are orthogonal and also symmetric. Which two numbers can be eigenvalues of those two matrices?

This A is nearly symmetric. But its eigenvectors are far from orthogonal:

 $$ A=\begin{bmatrix}1&10^{-15}\\ 0&1+10^{-15}\end{bmatrix}\quad has eigenvectors\quad\begin{bmatrix}1\\ 0\end{bmatrix}\quad and\quad\begin{bmatrix}\\ \end{bmatrix} $$ 

What is the angle between the eigenvectors?

(MATLAB) Take two symmetric matrices with different eigenvectors, say  $ A = \begin{bmatrix} 1 & 0 \\ 0 & 2 \end{bmatrix} $ and  $ B = \begin{bmatrix} 8 & 1 \\ 1 & 0 \end{bmatrix} $. Graph the eigenvalues  $ \lambda_1(A + tB) $ and  $ \lambda_2(A + tB) $ for  $ -8 < t < 8 $. Peter Lax says on page 113 of Linear Algebra that  $ \lambda_1 $ and  $ \lambda_2 $ appear to be on a collision course at certain values of  $ t $. “Yet at the last minute they turn aside.” How close does  $ \lambda_1 $ come to  $ \lambda_2 $?

For complex matrices, the symmetry $S^{\mathrm{T}} = S$ that produces real eigenvalues must change in Section 9.2 to $\overline{S}^{\mathrm{T}} = S$. From $\det(S - \lambda I) = 0$, find the eigenvalues of the 2 by 2 Hermitian matrix $S = [4 \quad 2 + i; \quad 2 - i \quad 0] = \overline{S}^{\mathrm{T}}$.

## Challenge Problems

Normal matrices have  $ \overline{N}^{\mathrm{T}}N = N\overline{N}^{\mathrm{T}} $. For real matrices, this is  $ N^{\mathrm{T}}N = NN^{\mathrm{T}} $. Normal includes symmetric, skew-symmetric, and orthogonal (with real  $ \lambda $, imaginary  $ \lambda $, and  $ |\lambda| = 1 $). Other normal matrices can have any complex eigenvalues.

Key point: Normal matrices have $n$ orthonormal eigenvectors. Those vectors $x_i$ probably will have complex components. In that complex case (Chapter 9) orthogonality means $\overline{x}_i^\mathrm{T} x_j = 0$. Inner products (dot products) $x^\mathrm{T} y$ become $\overline{x}^\mathrm{T} y$.

The test for n orthonormal columns in Q becomes  $ \overline{Q}^{\mathrm{T}}Q = I $ instead of  $ Q^{\mathrm{T}}Q = I $.

$N$ has $n$ orthonormal eigenvectors ($N = Q\Lambda\overline{Q}^{\mathrm{T}}$) if and only if $N$ is normal.

(a) Start from  $ N = Q \Lambda \overline{Q}^{\mathrm{T}} $ with  $ \overline{Q}^{\mathrm{T}} Q = I $. Show that  $ \overline{N}^{\mathrm{T}} N = N \overline{N}^{\mathrm{T}} $:  $ N $ is normal.

(b) Now start from  $ \overline{N}^{\mathrm{T}}N = N\overline{N}^{\mathrm{T}} $. Schur found  $ A = QT\overline{Q}^{\mathrm{T}} $ for every matrix  $ A $, with a triangular  $ T $. For normal matrices  $ A = N $ we must show (in 3 steps) that this triangular matrix  $ T $ will actually be diagonal. Then  $ T = \Lambda $.

Step 1. Put  $ N = QT \overline{Q}^{\mathrm{T}} $ into  $ \overline{N}^{\mathrm{T}} N = N \overline{N}^{\mathrm{T}} $ to find  $ \overline{T}^{\mathrm{T}} T = T \overline{T}^{\mathrm{T}} $.

Step 2. Suppose  $ T = \left| \begin{array}{cc} a & b \\ 0 & d \end{array} \right| $ has  $ \overline{T}^{T}T = T\overline{T}^{T} $. Prove that b = 0.

Step 3. Extend Step 2 to size n. Any normal triangular T must be diagonal.