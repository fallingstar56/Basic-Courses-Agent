### 7.3 Principal Component Analysis (PCA by the SVD)

1 Data often comes in a matrix: $n$ samples and $m$ measurements per sample.
2 Center each row of the matrix $A$ by subtracting the mean from each measurement.
3 The SVD finds combinations of the data that contain the most information.
4 Largest singular value $\sigma_{1} \leftrightarrow$ greatest variance $\leftrightarrow$ most information in $u_{1}$.

This section explains a major application of the SVD to statistics and data analysis. Our examples will come from human genetics and face recognition and finance. The problem is to understand a large matrix of data (= measurements). For each of n samples we are measuring m variables. The data matrix  $ A_0 $ has n columns and m rows.

Graphically, the columns of  $ A_0 $ are  $ n $ points in  $ \mathbf{R}^m $. After we subtract the average of each row to reach  $ A $, the  $ n $ points are often clustered along a line or close to a plane (or other low-dimensional subspace of  $ \mathbf{R}^m $). What is that line or plane or subspace?

Let me start with a picture instead of numbers. For  $ m = 2 $ variables like age and height, the  $ n $ points lie in the plane  $ \mathbf{R}^2 $. Subtract the average age and height to center the data. If the  $ n $ recentered points cluster along a line, how will linear algebra find that line?

<div style="text-align: center;"><img src="imgs/img_in_image_box_237_625_789_787.jpg" alt="Image" width="51%" /></div>


<div style="text-align: center;">Figure 7.2: Data points in A are often close to a line in  $ R^{2} $ or a subspace in  $ R^{m} $</div>


Let me go more carefully in constructing the data matrix. Start with the measurements in  $ A_0 $: the sample data. Find the average (the mean)  $ \mu_1, \mu_2, \ldots, \mu_m $ of each row. Subtract each mean  $ \mu_i $ from row  $ i $ to center the data. The average along each row is now zero, for the centered matrix  $ A $. So the point  $ (0,0) $ in Figure 7.2 is now the true center of the  $ n $ points.

The “sample covariance matrix” is defined by  $ S = \frac{AA^{\mathrm{T}}}{n-1} $.

A shows the distance  $ a_{ij} - \mu_i $ from each measurement to the row average  $ \mu_i $.

 $ (AA^{\mathrm{T}})_{11} $ and  $ (AA^{\mathrm{T}})_{22} $ show the sum of squared distances (sample variances  $ s_1^2 $,  $ s_2^2 $).

 $ (AA^{\mathrm{T}})_{12} $ shows the sample covariance  $ s_{12} = (\text{row } 1 \text{ of } A) \cdot (\text{row } 2 \text{ of } A) $.

The variance is a key number throughout statistics. An average exam score  $ \mu = 85 $ tells you it was a decent exam. A variance of  $ s^2 = 25 $ (standard deviation  $ s = 5 $) means that most grades were in the 80's: closely packed. A sample variance  $ s^2 = 225 $ ( $ s = 15 $) means that grades were widely scattered. Chapter 12 explains variances.