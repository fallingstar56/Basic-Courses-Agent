The covariance of a math exam and a history exam is a dot product of those rows of A, with average grades subtracted out. Covariance below zero means: One subject strong when the other is weak. High covariance means: Both strong or both weak.

We divide by  $ n - 1 $ instead of  $ n $ for reasons known best to statisticians. They tell me that one degree of freedom was used by the mean, leaving  $ n - 1 $. (I think the best plan is to agree with them.) In any case  $ n $ should be a big number to count on reliable statistics. Since the rows of  $ A $ have  $ n $ entries, the numbers in  $ AA^\top $ have size growing like  $ n $ and the division by  $ n - 1 $ keeps them steady.

Example 1 Six math and history scores (notice the zero mean in each row)

 $$ \boldsymbol{A}=\left[\begin{array}{c c c c c}3&-4&7&1&-4&-3\\ 7&-6&8&-1&-1&-7\end{array}\right]has sample covariance\boldsymbol{S}=\frac{A\boldsymbol{A}^{\mathrm{T}}}{5}=\left[\begin{array}{l l}20&25\\ 25&40\end{array}\right]. $$ 

The two rows of A are highly correlated:  $ s_{12} = 25 $. Above average math went with above average history. Changing all the signs in row 2 would produce negative covariance  $ s_{12} = -25 $. Notice that S has positive trace and determinant;  $ AA^{\mathrm{T}} $ is positive definite.

The eigenvalues of $S$ are near 57 and 3. So the first rank one piece $\sqrt{57}u_1v_1^T$ is much larger than the second piece $\sqrt{3}u_2v_2^T$. The leading eigenvector $u_1$ shows the direction that you see in the scatter graph of Figure 7.2. That eigenvector is close to $u_1 = (.6, .8)$ and the direction in the graph nearly gives a $6 - 8 - 10$ or $3 - 4 - 5$ right triangle.

The SVD of A (centered data) shows the dominant direction in the scatter plot.

The second singular vector  $ u_2 $ is perpendicular to  $ u_1 $. The second singular value  $ \sigma_2 \approx \sqrt{3} $ measures the spread across the dominant line. If the data points in  $ A $ fell exactly on a line ( $ u_1 $ direction), then  $ \sigma_2 $ would be zero. Actually there would only be  $ \sigma_1 $.

## The Essentials of Principal Component Analysis (PCA)

PCA gives a way to understand a data plot in dimension  $ m = \text{the number of measured variables (here age and height)} $. Subtract average age and height ( $ m = 2 $ for  $ n $ samples) to center the  $ m $ by  $ n $ data matrix  $ A $. The crucial connection to linear algebra is in the singular values and singular vectors of  $ A $. Those come from the eigenvalues  $ \lambda = \sigma^2 $ and the eigenvectors  $ u $ of the sample covariance matrix  $ S = AA^\mathrm{T}/(n-1) $.

- The total variance in the data is the sum of all eigenvalues and of sample variances  $ s^2 $:

Total variance  $ T = \sigma_1^2 + \cdots + \sigma_m^2 = s_1^2 + \cdots + s_m^2 = \text{trace}(\text{diagonal sum}) $.

• The first eigenvector  $ u_1 $ of  $ S $ points in the most significant direction of the data. That direction accounts for (or explains) a fraction  $ \sigma_1^2 / T $ of the total variance.

• The next eigenvector  $ u_2 $ (orthogonal to  $ u_1 $) accounts for a smaller fraction  $ \sigma_2^2/T $.

• Stop when those fractions are small. You have the R directions that explain most of the data. The n data points are very near an R-dimensional subspace with basis  $ u_{1} $ to  $ u_{R} $. These u's are the principal components in m-dimensional space.

• R is the “effective rank” of A. The true rank r is probably m or n: full rank matrix.