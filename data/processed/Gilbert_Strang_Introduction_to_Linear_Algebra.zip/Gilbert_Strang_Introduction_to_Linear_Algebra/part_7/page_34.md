Removing the zero row of  $ A $ (now  $ 3 \times 4 $) just removes the last row of  $ \Sigma $ and also the last row and column of  $ U $. Then  $ (3 \times 4) = U \Sigma V^{\mathrm{T}} = (3 \times 3)(3 \times 4)(4 \times 4) $. The SVD is totally adapted to rectangular matrices.

A good thing, because the rows and columns of a data matrix  $ A $ often have completely different meanings (like a spreadsheet). If we have the grades for all courses, there would be a column for each student and a row for each course: The entry  $ a_{ij} $ would be the grade. Then  $ \sigma_1 u_1 v_1^T $ could have  $ u_1 = \text{combination course} $ and  $ v_1 = \text{combination student} $. And  $ \sigma_1 $ would be the grade for those combinations: the highest grade.

The matrix  $ A $ could count the frequency of key words in a journal:  $ A $ different article for each column of  $ A $ and a different word for each row. The whole journal is indexed by the matrix  $ A $ and the most important information is in  $ \sigma_1 u_1 v_1^\top $. Then  $ \sigma_1 $ is the largest frequency for a hyperword (the word combination  $ u_1 $) in the hyperarticle  $ v_1 $.

Section 7.3 will apply the SVD to finance and genetics and search engines.

## Singular Value Stability versus Eigenvalue Instability

The 4 by 4 example A provides an example (an extreme case) of the instability of eigenvalues. Suppose the 4,1 entry barely changes from zero to 1/60, 000. The rank is now 4.

 $$ \boldsymbol{A}=\left[\begin{array}{cccc}{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{3}}} \\{{{\frac{1}{60,000}}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]\quad\begin{array}{l}{{{That change by only 1/60,000 produces a}}}} \\{{{much bigger jump in the eigenvalues of A}}} \\{{{\lambda=0,0,0,0to\lambda=\frac{1}{10},\frac{i}{10},\frac{-1}{10},\frac{-i}{10}}}}\end{array} $$ 

The four eigenvalues moved from zero onto a circle around zero. The circle has radius  $ \frac{1}{10} $ when the new entry is only 1/60,000. This shows serious instability of eigenvalues when  $ AA^{\mathrm{T}} $ is far from  $ A^{\mathrm{T}}A $. At the other extreme, if  $ A^{\mathrm{T}}A = AA^{\mathrm{T}} $ (a “normal matrix”) the eigenvectors of A are orthogonal and the eigenvalues of A are totally stable.

By contrast, the singular values of any matrix are stable. They don't change more than the change in A. In this example, the new singular values are 3, 2, 1, and 1/60, 000. The matrices U and V stay the same. The new fourth piece of A is  $ \sigma_4 u_4 v_4^T $, with fifteen zeros and that small entry  $ \sigma_4 = 1/60 $, 000.

## Singular Vectors of A and Eigenvectors of  $ S = A^{T} A $

Equations (5–6) “proved” the SVD all at once. The singular vectors  $ v_i $ are the eigenvectors  $ q_i $ of  $ S = A^\mathrm{T} A $. The eigenvalues  $ \lambda_i $ of  $ S $ are the same as  $ \sigma_i^2 $ for  $ A $. The rank  $ r $ of  $ S $ equals the rank of  $ A $. The expansions in eigenvectors and singular vectors are perfectly parallel.

Symmetric S

Any matrix A

 $$ \begin{array}{r l}{S=Q\Lambda Q^{\mathrm{T}}}&{{}=\lambda_{1}\boldsymbol{q}_{1}\boldsymbol{q}_{1}^{\mathrm{T}}+\lambda_{2}\boldsymbol{q}_{2}\boldsymbol{q}_{2}^{\mathrm{T}}+\cdots+\lambda_{r}\boldsymbol{q}_{r}\boldsymbol{q}_{r}^{\mathrm{T}}}\end{array} $$ 

 $$ \begin{array}{r l}{A=U\Sigma V^{\mathrm{T}}}&{{}=\sigma_{1}\boldsymbol{u}_{1}\boldsymbol{v}_{1}^{\mathrm{T}}+\sigma_{2}\boldsymbol{u}_{2}\boldsymbol{v}_{2}^{\mathrm{T}}+\cdots+\sigma_{r}\boldsymbol{u}_{r}\boldsymbol{v}_{r}^{\mathrm{T}}}\end{array} $$ 