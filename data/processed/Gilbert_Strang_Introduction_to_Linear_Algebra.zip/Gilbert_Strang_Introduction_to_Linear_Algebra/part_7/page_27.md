With full rank, A has a full set of n singular values  $ \sigma $ (all positive). The SVD will produce n pieces  $ \sigma_i \boldsymbol{u}_i \boldsymbol{v}_i^\mathrm{T} $ of rank one. Perfect reproduction needs all n pieces.

In compression small  $ \sigma $'s can be discarded with no serious loss in image quality. We want to understand and plot the  $ \sigma $'s for n = 4 and also for large n. Notice that Example 3 was the special case n = 2 of this triangular Example 4.

Working by hand, we begin with  $ AA^{T} $ (a computer would proceed differently):

 $$ \boldsymbol{A}\boldsymbol{A}^{\mathrm{T}}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{2}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{3}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}}\end{bmatrix}\quad and\quad(\boldsymbol{A}\boldsymbol{A}^{\mathrm{T}})^{-1}=(\boldsymbol{A}^{-1})^{\mathrm{T}}\boldsymbol{A}^{-1}=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{1}}}\end{bmatrix}. $$ 

That  $ -1, 2, -1 $ inverse matrix is included because its eigenvalues all have the form  $ 2 - 2 \cos \theta $. So we know the  $ \lambda $'s for  $ AA^\top $ and the  $ \sigma $'s for  $ A $:

 $$ \lambda=\frac{1}{2-2\cos\theta}=\frac{1}{4\sin^{2}(\theta/2)}\quad gives\quad\sigma=\sqrt{\lambda}=\frac{1}{2\sin(\theta/2)}. $$ 

The n different angles  $ \theta $ are equally spaced, which makes this example so exceptional:

 $$ \theta=\frac{\pi}{2n+1},\frac{3\pi}{2n+1},\cdots,\frac{(2n-1)\pi}{2n+1}\quad\left(n=4 includes\theta=\frac{3\pi}{9}with2\sin\frac{\theta}{2}=1\right). $$ 

That special case gives  $ \lambda = 1 $ as an eigenvalue of  $ AA^{\mathrm{T}} $ when  $ n = 4 $. So  $ \sigma = \sqrt{\lambda} = 1 $ is a singular value of A. You can check that the vector  $ \boldsymbol{u} = (1, 1, 0, -1) $ has  $ AA^{\mathrm{T}}\boldsymbol{u} = \boldsymbol{u} $ (a truly special case).

The important point is to graph the n singular values of A. Those numbers drop off (unlike the eigenvalues of A, which are all 1). But the dropoff is not steep. So the SVD gives only moderate compression of this triangular flag. Great compression for Hilbert.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_172_811_521_1097.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_532_814_890_1098.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">Figure 7.1: Singular values of the triangle of 1's in Examples 3-4 (not compressible) and the evil Hilbert matrix  $ H(i,j)=(i+j-1)^{-1} $ in Section 8.3: compress it to work with it.</div>
