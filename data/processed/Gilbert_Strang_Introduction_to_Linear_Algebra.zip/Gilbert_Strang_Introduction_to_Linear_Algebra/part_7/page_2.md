## All Symmetric Matrices are Diagonalizable

When no eigenvalues of A are repeated, the eigenvectors are sure to be independent. Then A can be diagonalized. But a repeated eigenvalue can produce a shortage of eigenvectors. This sometimes happens for nonsymmetric matrices. It never happens for symmetric matrices. There are always enough eigenvectors to diagonalize  $ S = S^{T} $.

Here is one idea for a proof. Change $S$ slightly by a diagonal matrix $\mathbf{diag}(c, 2c, \ldots, nc)$. If $c$ is very small, the new symmetric matrix will have no repeated eigenvalues. Then we know it has a full set of orthonormal eigenvectors. As $c \to 0$ we obtain $n$ orthonormal eigenvectors of the original $S$—even if some eigenvalues of that $S$ are repeated.

Every mathematician knows that this argument is incomplete. How do we guarantee that the small diagonal matrix will separate the eigenvalues? (I am sure this is true.)

A different proof comes from a useful new factorization that applies to all square matrices  $ A $, symmetric or not. This new factorization quickly produces  $ S = Q \Lambda Q^{\mathrm{T}} $ with a full set of real orthonormal eigenvectors when  $ S $ is any real symmetric matrix.

Every square A factors into  $ QTQ^{-1} $ where T is upper triangular and  $ \overline{Q}^{\mathrm{T}} = Q^{-1} $. If A has real eigenvalues then Q and T can be chosen real:  $ Q^{\mathrm{T}}Q = I $.

This is Schur's Theorem. Its proof will go onto the website math.mit.edu/linearalgebra. Here I will show how T is diagonal (T = Λ) when S is symmetric. Then S is QΛQᵀ.

We know that every symmetric $S$ has real eigenvalues, and Schur allows repeated $\lambda$'s:

Schur's  $ S = QTQ^{-1} $ means that  $ T = Q^{\mathrm{T}}SQ $. The transpose is again  $ Q^{\mathrm{T}}SQ $.

The triangular T is symmetric when S^T = S. Then T must be diagonal and T = Λ

This proves that  $ S = Q\Lambda Q^{-1} $. The symmetric  $ S $ has  $ n $ orthonormal eigenvectors in  $ Q $

Note. I have added another proof in Section 7.2 of this book. That proof shows how the eigenvalues  $ \lambda $ can be described one at a time. The largest  $ \lambda_1 $ is the maximum of  $ \boldsymbol{x}^\mathrm{T} S\boldsymbol{x}/\boldsymbol{x}^\mathrm{T} \boldsymbol{x} $. Then  $ \lambda_2 $ (second largest) is again the same maximum, if we only allow vectors  $ \boldsymbol{x} $ that are perpendicular to the first eigenvector. The third eigenvalue  $ \lambda_3 $ comes by requiring  $ \boldsymbol{x}^\mathrm{T} \boldsymbol{q}_1 = 0 $ and  $ \boldsymbol{x}^\mathrm{T} \boldsymbol{q}_2 = 0 $.

This proof is placed in Chapter 7 because the same one-at-a-time idea succeeds for the singular values of any matrix A. Singular values come from  $ A^{T}A $ and  $ AA^{T} $.

## ■ REVIEW OF THE KEY IDEAS

1. Every symmetric matrix S has real eigenvalues and perpendicular eigenvectors.

2. Diagonalization becomes  $ S = Q \Lambda Q^{\mathrm{T}} $ with an orthogonal eigenvector matrix Q.

3. All symmetric matrices are diagonalizable, even with repeated eigenvalues.

4. The signs of the eigenvalues match the signs of the pivots, when  $ S = S^{T} $

5. Every square matrix can be "triangularized" by A = QTQ⁻¹. If A = S then T = Λ.