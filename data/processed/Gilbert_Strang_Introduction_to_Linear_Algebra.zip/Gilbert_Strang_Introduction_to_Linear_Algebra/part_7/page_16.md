## WORKED EXAMPLES

6.5 A The great factorizations of a symmetric matrix are  $ S = LDL^T $ from pivots and multipliers, and  $ S = Q\Lambda Q^T $ from eigenvalues and eigenvectors. Try these n by n tests on pascal(6) and ones(6) and hilb(6) and other matrices in MATLAB's gallery.

pascal(6) is positive definite because all its pivots are 1 (Worked Example 2.6 A).

ones(6) is positive semidefinite because its eigenvalues are 0, 0, 0, 0, 0, 6.

H=hilb(6) is positive definite even though eig(H) shows eigenvalues very near zero.

Hilbert matrix  $ x^{\mathrm{T}}Hx=\int_{0}^{1}(x_{1}+x_{2}s+\cdots+x_{6}s^{5})^{2}ds>0 $,  $ H_{ij}=1/(i+j-1) $.

rand(6) + rand(6)' can be positive definite or not. Experiments gave only 2 in 20000.

n = 20000; p = 0; for k = 1:n, A = rand(6); p = p + all(eig(A + A') > 0); end, p / n

6.5 B When is the symmetric block matrix  $ M = \begin{bmatrix} A & B \\ B^{\mathrm{T}} & C \end{bmatrix} $

positive definite?

Solution Multiply the first row of M by  $ B^{\mathrm{T}}A^{-1} $ and subtract from the second row, to get a block of zeros. The Schur complement  $ S = C - B^{\mathrm{T}}A^{-1}B $ appears in the corner:

 $$ \left[\begin{array}{c c}{{{I}}}&{{{0}}} \\{{{-B^{\mathrm{T}}A^{-1}}}}&{{{I}}}\end{array}\right]\left[\begin{array}{c c}{{{A}}}&{{{B}}} \\{{{B^{\mathrm{T}}}}}&{{{C}}}\end{array}\right]=\left[\begin{array}{c c}{{{A}}}&{{{B}}} \\{{{0}}}&{{{C-B^{\mathrm{T}}A^{-1}B}}}\end{array}\right]=\left[\begin{array}{c c}{{{A}}}&{{{B}}} \\{{{0}}}&{{{S}}}\end{array}\right] $$ 

Those two blocks A and S must be positive definite. Their pivots are the pivots of M.

6.5 C Find the eigenvalues of the  $ -1, 2, -1 $ tridiagonal n by n matrix S (my favorite).

Solution The best way is to guess  $ \lambda $ and  $ x $. Then check  $ Sx = \lambda x $. Guessing could not work for most matrices, but special cases are a big part of mathematics (pure and applied).

The key is hidden in a differential equation. The second difference matrix S is like a second derivative, and those eigenvalues are much easier to see:

Eigenvalues

Eigenfunctions

 $$ \begin{array}{c}\lambda_{1},\lambda_{2},\cdots\\ s y_{1},y_{2},\cdots\end{array} $$ 

 $$ \frac{d^{2}y}{dx^{2}}=\lambda y(x)\quad\mathbf{with}\quad\begin{array}{l}y(0)=0\\ y(1)=0\end{array} $$ 

Try  $ y = \sin cx $. Its second derivative is  $ y'' = -c^2 \sin cx $. So the eigenvalue in (5) will be  $ \lambda = -c^2 $, provided  $ y = \sin cx $ satisfies the end point conditions  $ y(0) = 0 = y(1) $.

Certainly  $ \sin 0 = 0 $ (this is where cosines are eliminated). At the other end  $ x = 1 $, we need  $ y(1) = \sin c = 0 $. The number  $ c $ must be  $ k\pi $, a multiple of  $ \pi $. Then  $ \lambda $ is  $ -k^2\pi^2 $:

Eigenvalues  $ \lambda = -k^{2}\pi^{2} $

Eigenfunctions  $ y = \sin k\pi x $

 $$ \frac{d^{2}}{dx^{2}}\sin k\pi x=-k^{2}\pi^{2}\sin k\pi x. $$ 

Now we go back to the matrix $S$ and guess its eigenvectors. They come from $\sin k\pi x$ at $n$ points $x = h, 2h, \ldots, nh$, equally spaced between $0$ and $1$. The spacing $\Delta x$ is $h = 1/(n + 1)$, so the $(n + 1)$st point has $(n + 1)h = 1$. Multiply that sine vector $x$ by $S$:

Eigenvalue of S is positive

 $$ Sx=\lambda_{k}x=\left(2-2\cos k\pi h\right)x $$ 

Eigenvector of S is sine vector

 $$ \boldsymbol{x}=(\sin k\pi h,\ldots,\sin n k\pi h). $$ 