### Problem Set 6.5

Problems 1–13 are about tests for positive definiteness.

1 Suppose the 2 by 2 tests a > 0 and ac − b2 > 0 are passed. Then c > b2/a > 0.

(i)  $ \lambda_{1} $ and  $ \lambda_{2} $ have the same sign because their product  $ \lambda_{1}\lambda_{2} $ equals ___.

(i) That sign is positive because  $ \lambda_{1} + \lambda_{2} $ equals ___.

Conclusion: The tests a > 0, ac − b2 > 0 guarantee positive eigenvalues λ1, λ2.

Which of $S_{1}, S_{2}, S_{3}, S_{4}$ has two positive eigenvalues? Use a test, don't compute the $\lambda$'s. Also find an $x$ so that $\boldsymbol{x}^{\mathrm{T}} S_{1} \boldsymbol{x} < 0$, so $S_{1}$ is not positive definite.

 $$ S_{1}=\begin{bmatrix}{{{5}}}&{{{6}}} \\{{{6}}}&{{{7}}}\end{bmatrix}\quad S_{2}=\begin{bmatrix}{{{-1}}}&{{{-2}}} \\{{{-2}}}&{{{-5}}}\end{bmatrix}\quad S_{3}=\begin{bmatrix}{{{1}}}&{{{10}}} \\{{{10}}}&{{{100}}}\end{bmatrix}\quad S_{4}=\begin{bmatrix}{{{1}}}&{{{10}}} \\{{{10}}}&{{{101}}}\end{bmatrix}. $$ 

3 For which numbers b and c are these matrices positive definite?

 $$ S=\begin{bmatrix}{{{1}}}&{{{b}}} \\{{{b}}}&{{{9}}}\end{bmatrix}\qquad S=\begin{bmatrix}{{{2}}}&{{{4}}} \\{{{4}}}&{{{c}}}\end{bmatrix}\qquad S=\begin{bmatrix}{{{c}}}&{{{b}}} \\{{{b}}}&{{{c}}}\end{bmatrix}. $$ 

With the pivots in D and multiplier in L, factor each A into LDLT.

What is the function  $ f = ax^2 + 2bxy + cy^2 $ for each of these matrices? Complete the square to write each  $ f $ as a sum of one or two squares  $ f = d_1( \quad )^2 + d_2( \quad )^2 $.

 $$ S_{1}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{9}}}\end{bmatrix}\qquad S_{2}=\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{3}}}&{{{9}}}\end{bmatrix}\qquad f=[x\ y]\left[\begin{array}{l}{{{S}}} \\ \\\end{array}\right]\begin{bmatrix}{{{x}}} \\{{{y}}}\end{bmatrix} $$ 

Write  $ f(x,y) = x^2 + 4xy + 3y^2 $ as a difference of squares and find a point  $ (x,y) $ where f is negative. No minimum at  $ (0,0) $ even though f has positive coefficients.

6 The function  $ f(x, y) = 2xy $ certainly has a saddle point and not a minimum at  $ (0, 0) $. What symmetric matrix S produces this  $ f $? What are its eigenvalues?

7 Test to see if  $ A^{T}A $ is positive definite in each case: A needs independent columns.

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{3}}}\end{bmatrix}\quad and\quad\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}} \\{{{2}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{1}}}\end{bmatrix}. $$ 

8 The function  $ f(x, y) = 3(x + 2y)^2 + 4y^2 $ is positive except at  $ (0, 0) $. What is the matrix in  $ f = [x \quad y] S[x \quad y]^T $? Check that the pivots of  $ A $ are 3 and 4.