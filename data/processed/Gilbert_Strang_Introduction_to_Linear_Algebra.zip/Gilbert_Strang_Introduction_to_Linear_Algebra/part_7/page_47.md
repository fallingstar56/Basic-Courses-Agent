Many of the important techniques are well-kept secrets of Google. Probably they start with an earlier eigenvector as a first approximation, and they run the random walk very fast. To get a high ranking, you want a lot of links from important sites.

Here is an application of the SVD to web search engines. When you google a word, you get a list of web sites in order of importance. You could try typing “four subspaces”.

The HITS algorithm was an early proposal to produce that ranked list. It begins with about 200 sites found from an index of key words. After that we look only at links between pages. Search engines are link-based more than content-based.

Start with the 200 sites and all sites that link to them and all sites they link to. That is our list, to be put in order. Importance can be measured by links out and links in.

1. The site may be an authority: Links come in from many sites. Especially from hubs.

2. The site may be a hub: Links go out to many sites in the list. Especially to authorities.

We want numbers  $ x_1, \ldots, x_N $ to rank the authorities and  $ y_1, \ldots, y_N $ to rank the hubs. Start with a simple count:  $ x_i^0 $ and  $ y_i^0 $ count the links into and out of site  $ i $.

Here is the point: A good authority has links from important sites (like hubs). Links from universities count more heavily than links from friends. A good hub is linked to important sites (like authorities). A link to amazon.com unfortunately means more than a link to wellesleycambridge.com. The raw counts  $ x^0 $ and  $ y^0 $ are updated to  $ x^1 $ and  $ y^1 $ by taking account of good links (measuring their quality by  $ x^0 $ and  $ y^0 $):

Authority/Hub

 $ x_i^1 / y_i^1 = \text{Add up } y_j^0 / x_j^0 \text{ for all links into } i \text{ / out from } i $

In matrix language those are  $ \boldsymbol{x}^1 = A^\mathrm{T} \boldsymbol{y}^0 $ and  $ \boldsymbol{y}^1 = A \boldsymbol{x}^0 $. The matrix  $ A $ contains 1's and 0's, with  $ a_{ij} = 1 $ when  $ i $ links to  $ j $. In the language of graphs,  $ A $ is an “adjacency matrix” for the Web (an enormous matrix). The new  $ \boldsymbol{x}^1 $ and  $ \boldsymbol{y}^1 $ give better rankings, but not the best. Take another step like (2), to reach  $ \boldsymbol{x}^2 $ and  $ \boldsymbol{y}^2 $ from  $ A^\mathrm{T} A \boldsymbol{x}^0 $ and  $ AA^\mathrm{T} \boldsymbol{y}^0 $:

Authority

 $$ \mathbf{x}^{2}=A^{\mathrm{T}}\mathbf{y}^{1}=A^{\mathrm{T}}A\mathbf{x}^{0}\quad 爻 \quad\mathbf{H}\mathbf{u}\mathbf{b}\quad\mathbf{y}^{2}=A\mathbf{x}^{1}=AA^{\mathrm{T}}\mathbf{y}^{0}. $$ 

In two steps we are multiplying by  $ A^{\mathrm{T}}A $ and  $ AA^{\mathrm{T}} $. Twenty steps will multiply by  $ (\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A})^{10} $ and  $ (\boldsymbol{A}\boldsymbol{A}^{\mathrm{T}})^{10} $. When we take powers, the largest eigenvalue  $ \sigma_{1}^{2} $ begins to dominate. The vectors x and y line up with the leading eigenvectors  $ v_{1} $ and  $ u_{1} $ of  $ A^{\mathrm{T}}A $ and  $ AA^{\mathrm{T}} $. We are computing the top terms in the SVD, by the power method that is discussed in Section 11.3. It is wonderful that linear algebra helps to understand the Web.

This HITS algorithm is described in the 1999 Scientific American (June 16). But I don’t think the SVD is mentioned there. . . The excellent book by Langville and Meyer, Google’s PageRank and Beyond, explains in detail the science of search engines.