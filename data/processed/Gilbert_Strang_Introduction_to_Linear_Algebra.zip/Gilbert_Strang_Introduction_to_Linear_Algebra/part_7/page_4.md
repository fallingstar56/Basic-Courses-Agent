### Problem Set 6.4

1 Which of these matrices ASB will be symmetric with eigenvalues 1 and -1?

 $$ \begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{-1}}}&{{{1}}}\end{bmatrix}\quad\begin{bmatrix}{{{0}}}&{{{-1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{-1}}}&{{{0}}}\end{bmatrix} $$ 

 $ B = A^{\mathrm{T}} $ doesn't do it.  $ B = A^{-1} $ doesn't do it.  $ B = \_\_ $ = \_\_ $ will succeed. So B must be an  $ \_\_ $ matrix.

2 Suppose  $ S = S^{T} $. When is ASB also symmetric with the same eigenvalues as  $ S $?

(a) Transpose ASB to see that it stays symmetric when B = ___.

(b) ASB is similar to S (same eigenvalues) when B = ___.

Put (a) and (b) together. The symmetric matrices similar to S look like (___)S(___).

3 Write A as  $ S + N $, symmetric matrix S plus skew-symmetric matrix N:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{4}}} \\{{{4}}}&{{{3}}}&{{{0}}} \\{{{8}}}&{{{6}}}&{{{5}}}\end{bmatrix}=\boldsymbol{S}+\boldsymbol{N}\qquad\left(\boldsymbol{S}^{\mathrm{T}}=\boldsymbol{S}\text{and}\boldsymbol{N}^{\mathrm{T}}=-\boldsymbol{N}\right). $$ 

For any square matrix,  $  S = \frac{1}{2}(A + A^{\mathrm{T}})  $ and  $  N =  $ ___ add up to A.

If $C$ is symmetric prove that $A^{\mathrm{T}}CA$ is also symmetric. (Transpose it.) When $A$ is 6 by 3, what are the shapes of $C$ and $A^{\mathrm{T}}CA$?

5 Find the eigenvalues and the unit eigenvectors of

 $$ S=\begin{bmatrix}{{{2}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{0}}}&{{{0}}} \\{{{2}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Find an orthogonal matrix $Q$ that diagonalizes $S = \begin{bmatrix} -2 & 6 \\ 6 & 7 \end{bmatrix}$. What is $\Lambda$?

Find an orthogonal matrix Q that diagonalizes this symmetric matrix:

 $$ S=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{2}}} \\{{{0}}}&{{{-1}}}&{{{-2}}} \\{{{2}}}&{{{-2}}}&{{{0}}}\end{bmatrix}. $$ 

Find all orthogonal matrices that diagonalize $S = \begin{bmatrix} 9 & 12 \\ 12 & 16 \end{bmatrix}$.

(a) Find a symmetric matrix  $ \begin{bmatrix} 1 & b \\ b & 1 \end{bmatrix} $ that has a negative eigenvalue.

(b) How do you know it must have a negative pivot?

(c) How do you know it can’t have two negative eigenvalues?