### Problem Set 7.1

1 What are the ranks $r$ for these matrices with entries $i$ times $j$ and $i$ plus $j$? Write $A$ and $B$ as the sum of $r$ pieces $uv^\mathrm{T}$ of rank one. Not requiring $\boldsymbol{u}_1^\mathrm{T} \boldsymbol{u}_2 = \boldsymbol{v}_1^\mathrm{T} \boldsymbol{v}_2 = 0$.

 $$ A={\left[\begin{array}{l l l l}{1}&{2}&{3}&{4}\\ {2}&{4}&{6}&{8}\\ {3}&{6}&{9}&{12}\\ {4}&{8}&{12}&{16} \end{array}\right]}  \quad B={\left[\begin{array}{l l l l}{2}&{3}&{4}&{5}\\ {3}&{4}&{5}&{6}\\ {4}&{5}&{6}&{7}\\ {5}&{6}&{7}&{8} \end{array}\right]} $$ 

2 We usually think that the identity matrix I is as simple as possible. But why is I completely incompressible? Draw a rank 5 flag with a cross.

3 These flags have rank 2. Write A and B in any way as  $ u_{1}v_{1}^{\mathrm{T}} + u_{2}v_{2}^{\mathrm{T}} $.

 $$ A_{\mathrm{Sweden}}=A_{\mathrm{Finland}}=\left[\begin{array}{llll}{{{1}}}&{{{2}}}&{{{1}}}&{{{1}}} \\{{{2}}}&{{{2}}}&{{{2}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{1}}}&{{{1}}}\end{array}\right]\qquad B_{\mathrm{Benin}}=\left[\begin{array}{lll}{{{1}}}&{{{2}}}&{{{2}}} \\{{{1}}}&{{{3}}}&{{{3}}}\end{array}\right] $$ 

4 Now find the trace and determinant of  $ BB^{T} $ and  $ B^{T}B $ in Problem 3. The singular values of B are close to  $ \sigma_{1}^{2}=28-\frac{1}{14} $ and  $ \sigma_{2}^{2}=\frac{1}{14} $. Is B compressible or not?

5 Use  $ [U, S, V] = \text{svd}(A) $ to find two orthogonal pieces  $ \sigma u v^{\mathrm{T}} $ of  $ A_{\mathrm{Sweden}} $.

6 Find the eigenvalues and the singular values of this 2 by 2 matrix A.

 $$ \boldsymbol{A}=\left[\begin{array}{ll}{{{2}}}&{{{1}}} \\{{{4}}}&{{{2}}}\end{array}\right]\quad with\quad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\left[\begin{array}{ll}{{{20}}}&{{{10}}} \\{{{10}}}&{{{5}}}\end{array}\right]\quad and\quad\boldsymbol{A}\boldsymbol{A}^{\mathrm{T}}=\left[\begin{array}{ll}{{{5}}}&{{{10}}} \\{{{10}}}&{{{20}}}\end{array}\right]. $$ 

The eigenvectors  $ (1,2) $ and  $ (1,-2) $ of  $ A $ are not orthogonal. How do you know the eigenvectors  $ v_1, v_2 $ of  $ A^\mathrm{T} A $ are orthogonal? Notice that  $ A^\mathrm{T} A $ and  $ AA^\mathrm{T} $ have the same eigenvalues  $ (25 $ and  $ (0) $.

7 How does the second form  $ AV = U\Sigma $ in equation (3) follow from the first form  $ A = U\Sigma V^{\mathrm{T}} $? That is the most famous form of the SVD.

8 The two columns of AV = U∑ are Av₁ = σ₁u₁ and Av₂ = σ₂u₂. So we hope that

 $$ \boldsymbol{A}\boldsymbol{v}_{1}=\left[\begin{array}{cc}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{c}{{{\sigma_{1}}}} \\{{{1}}}\end{array}\right]=\sigma_{1}\left[\begin{array}{c}{{{1}}} \\{{{\sigma_{1}}}}\end{array}\right]\quad and\quad\left[\begin{array}{cc}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{array}\right]\left[\begin{array}{c}{{{1}}} \\{{{-\sigma_{1}}}}\end{array}\right]=\sigma_{2}\left[\begin{array}{c}{{{\sigma_{1}}}} \\{{{-1}}}\end{array}\right] $$ 

The first needs  $ \sigma_1 + 1 = \sigma_1^2 $ and the second needs  $ 1 - \sigma_1 = -\sigma_2 $. Are those true?

9 The MATLAB commands  $ A = \text{rand}(20, 40) $ and  $ B = \text{randn}(20, 40) $ produce 20 by 40 random matrices. The entries of  $ A $ are between 0 and 1 with uniform probability. The entries of  $ B $ have a normal “bell-shaped” probability distribution. Using an svd command, find and graph their singular values  $ \sigma_1 $ to  $ \sigma_{20} $. Why do they have 20  $ \sigma $’s?