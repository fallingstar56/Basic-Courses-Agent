## Positive Semidefinite Matrices

Often we are at the edge of positive definiteness. The determinant is zero. The smallest eigenvalue is zero. The energy in its eigenvector is  $ \boldsymbol{x}^{\mathrm{T}} S \boldsymbol{x} = \boldsymbol{x}^{\mathrm{T}} 0 \boldsymbol{x} = 0 $. These matrices on the edge are called positive semidefinite. Here are two examples (not invertible):

 $$ S=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{4}}}\end{bmatrix}\text{and}T=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{-1}}}&{{{2}}}\end{bmatrix}\text{are positive semidefinite.} $$ 

S has eigenvalues 5 and 0. Its upper left determinants are 1 and 0. Its rank is only 1. This matrix S factors into  $ A^{T}A $ with dependent columns in A:

Dependent columns in A Positive semidefinite S

 $$ \begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{4}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{2}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{0}}}\end{bmatrix}=\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}. $$ 

If 4 is increased by any small number, the matrix S will become positive definite.

The cyclic $T$ also has zero determinant (computed above when $b = -1$). $T$ is singular. The eigenvector $\boldsymbol{x} = (1, 1, 1)$ has $T\boldsymbol{x} = \mathbf{0}$ and energy $\boldsymbol{x}^{\mathrm{T}}T\boldsymbol{x} = 0$. Vectors $\boldsymbol{x}$ in all other directions do give positive energy. This $T$ can be written as $A^{\mathrm{T}}A$ in many ways, but $A$ will always have dependent columns, with $(1, 1, 1)$ in its nullspace:

Second differences T from first differences A

Cyclic T from cyclic A

 $$ \begin{aligned}\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{-1}}}&{{{2}}}\end{bmatrix}&=\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{-1}}} \\{{{-1}}}&{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}}&{{{-1}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{bmatrix},\end{aligned} $$ 

Positive semidefinite matrices have all  $ \lambda \geq 0 $ and all  $ \boldsymbol{x}^{\mathrm{T}} S \boldsymbol{x} \geq 0 $. Those weak inequalities ( $ \geq $ instead of>) include positive definite  $ S $ and also the singular matrices at the edge.

 $$ \mathrm{T h e~E l l i p s e~}a x^{2}+2b x y+c y^{2}=1 $$ 

Think of a tilted ellipse  $ \boldsymbol{x}^{\mathrm{T}}S\boldsymbol{x}=1 $. Its center is  $ (0,0) $, as in Figure 6.7a. Turn it to line up with the coordinate axes  $ (X\text{ and }Y\text{ axes}) $. That is Figure 6.7b. These two pictures show the geometry behind the factorization  $ S=Q\Lambda Q^{-1}=Q\Lambda Q^{\mathrm{T}} $:

1. The tilted ellipse is associated with S. Its equation is  $ \boldsymbol{x}^{\mathrm{T}}S\boldsymbol{x}=1 $.

2. The lined-up ellipse is associated with  $ \Lambda $. Its equation is  $ X^{\mathrm{T}}\Lambda X = 1 $.

3. The rotation matrix that lines up the ellipse is the eigenvector matrix Q.

Example 2 Find the axes of this tilted ellipse  $ 5x^2 + 8xy + 5y^2 = 1 $.

Solution Start with the positive definite matrix that matches this equation:

The equation is

 $$ \begin{bmatrix}{{{x}}}&{{{y}}} \\\end{bmatrix}\begin{bmatrix}{{{5}}}&{{{4}}} \\{{{4}}}&{{{5}}} \\\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\\end{bmatrix}=1.\quad\text{The matrix is}\quad S=\begin{bmatrix}{{{5}}}&{{{4}}} \\{{{4}}}&{{{5}}} \\\end{bmatrix}. $$ 