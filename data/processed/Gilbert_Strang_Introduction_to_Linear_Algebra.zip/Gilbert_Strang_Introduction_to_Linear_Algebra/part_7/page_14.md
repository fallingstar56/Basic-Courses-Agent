<div style="text-align: center;"><img src="imgs/img_in_image_box_153_120_856_426.jpg" alt="Image" width="65%" /></div>


<div style="text-align: center;">Figure 6.7: The tilted ellipse 5x2 + 8xy + 5y2 = 1. Lined up it is 9X2 + Y2 = 1.</div>


The eigenvectors are  $ \begin{bmatrix} 1 \\ 1 \end{bmatrix} $ and  $ \begin{bmatrix} 1 \\ -1 \end{bmatrix} $. Divide by  $ \sqrt{2} $ for unit vectors. Then  $ S = Q \Lambda Q^{\mathrm{T}} $:

Eigenvectors in Q

Eigenvalues 9 and 1

 $$ \begin{bmatrix}{{{5}}}&{{{4}}} \\{{{4}}}&{{{5}}}\end{bmatrix}=\frac{1}{\sqrt{2}}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{\pmb{9}}}}&{{{0}}} \\{{{0}}}&{{{\pmb{1}}}}\end{bmatrix}\frac{1}{\sqrt{2}}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{-1}}}\end{bmatrix}. $$ 

Now multiply by  $ [x\ y] $ on the left and  $ \begin{bmatrix} x \\ y \end{bmatrix} $ on the right to get  $ \boldsymbol{x}^{\mathrm{T}} S\boldsymbol{x} = (\boldsymbol{x}^{\mathrm{T}} Q) \Lambda(Q^{\mathrm{T}} \boldsymbol{x}) $:

 $$ \begin{array}{r l}{x^{\mathrm{T}}S x=\mathrm{~s u m~o f~s q u a r e s~}}&{{}5x^{2}+8x y+5y^{2}=9\left(\frac{x+y}{\sqrt{2}}\right)^{2}+1\left(\frac{x-y}{\sqrt{2}}\right)^{2}.}\end{array} $$ 

The coefficients are not the pivots 5 and 9/5 from $D$, they are the eigenvalues 9 and 1 from $\Lambda$. Inside the squares are the eigenvectors $q_1 = (1, 1)/\sqrt{2}$ and $q_2 = (1, -1)/\sqrt{2}$.

The axes of the tilted ellipse point along those eigenvectors. This explains why  $ S = Q\Lambda Q^{\mathrm{T}} $ is called the “principal axis theorem”—it displays the axes. Not only the axis directions (from the eigenvectors) but also the axis lengths (from the eigenvalues). To see it all, use capital letters for the new coordinates that line up the ellipse:

Lined up

 $$ \frac{x+y}{\sqrt{2}}=X\qquad and\qquad\frac{x-y}{\sqrt{2}}=Y\qquad and\qquad9X^{2}+Y^{2}=1. $$ 

The largest value of  $ X^2 $ is 1/9. The endpoint of the shorter axis has  $ X = 1/3 $ and  $ Y = 0 $. Notice: The bigger eigenvalue  $ \lambda_1 $ gives the shorter axis, of half-length  $ 1/\sqrt{\lambda_1} = 1/3 $. The smaller eigenvalue  $ \lambda_2 = 1 $ gives the greater length  $ 1/\sqrt{\lambda_2} = 1 $.

In the xy system, the axes are along the eigenvectors of S. In the XY system, the axes are along the eigenvectors of  $ \Lambda $—the coordinate axes. All comes from  $ S = Q\Lambda Q^{\mathrm{T}} $.