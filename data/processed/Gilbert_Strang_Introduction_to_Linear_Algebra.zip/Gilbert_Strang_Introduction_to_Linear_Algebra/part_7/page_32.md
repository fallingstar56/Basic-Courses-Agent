Now  $ Av_i = \sigma_i u_i $ tells us the unit vectors  $ u_1 $ to  $ u_r $. This is the key equation (1). The essential point—the whole reason that the SVD succeeds—is that those unit vectors  $ u_1 $ to  $ u_r $ are automatically orthogonal to each other (because the  $ v $'s are orthogonal):

 $$ \begin{array}{r l}{\mathbf{K e y s t e p}}&{{}\quad u_{i}^{\mathrm{T}}u_{j}=\left(\frac{A v_{i}}{\sigma_{i}}\right)^{\mathrm{T}}\left(\frac{A v_{j}}{\sigma_{j}}\right)=\frac{v_{i}^{\mathrm{T}}A^{\mathrm{T}}A v_{j}}{\sigma_{i}\sigma_{j}}=\frac{\sigma_{j}^{2}}{\sigma_{i}\sigma_{j}}v_{i}^{\mathrm{T}}v_{j}=\mathbf{z e r o}.}\end{array} $$ 

The $v$'s are eigenvectors of $A^{\mathrm{T}}A$ (symmetric). They are orthogonal and now the $u$'s are also orthogonal. Actually those $u$'s will be eigenvectors of $AA^{\mathrm{T}}$.

Finally we complete the  $ v $'s and  $ u $'s to  $ n $  $ v $'s and  $ m $  $ u $'s with any orthonormal bases for the nullspaces  $ \mathbf{N}(A) $ and  $ \mathbf{N}(A^{\mathrm{T}}) $. We have found  $ V $ and  $ \Sigma $ and  $ U $ in  $ A = U\Sigma V^{\mathrm{T}} $.

## An Example of the SVD

Here is an example to show the computation of all three matrices in  $ A = U \Sigma V^{\mathrm{T}} $

Example 3 Find the matrices $U, \Sigma, V$ for $A = \left[\begin{array}{cc} 3 & 0 \\ 4 & 5 \end{array}\right]$. The rank is $r = 2$.

With rank 2, this $A$ has positive singular values $\sigma_1$ and $\sigma_2$. We will see that $\sigma_1$ is larger than $\lambda_{\max} = 5$, and $\sigma_2$ is smaller than $\lambda_{\min} = 3$. Begin with $A^\mathrm{T}A$ and $AA^\mathrm{T}$:

 $$ \boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\left[\begin{array}{ll}{{{25}}}&{{{20}}} \\{{{20}}}&{{{25}}}\end{array}\right]\quad\boldsymbol{A}\boldsymbol{A}^{\mathrm{T}}=\left[\begin{array}{cc}{{{9}}}&{{{12}}} \\{{{12}}}&{{{41}}}\end{array}\right] $$ 

Those have the same trace (50) and the same eigenvalues  $ \sigma_1^2 = 45 $ and  $ \sigma_2^2 = 5 $. The square roots are  $ \sigma_1 = \sqrt{45} $ and  $ \sigma_2 = \sqrt{5} $. Then  $ \sigma_1 \sigma_2 = 15 $ and this is the determinant of  $ A $.

A key step is to find the eigenvectors of  $ A^{T}A $ (with eigenvalues 45 and 5):

 $$ \left[\begin{array}{cc}{25}&{20}\\ {20}&{25} \end{array}\right]\left[\begin{array}{l}{1}\\ {1} \end{array}\right]=45\left[\begin{array}{l}{1}\\ {1} \end{array}\right]\qquad\qquad\left[\begin{array}{cc}{25}&{20}\\ {20}&{25} \end{array}\right]\left[\begin{array}{r}{-1}\\ {1} \end{array}\right]=5\left[\begin{array}{r}{-1}\\ {1} \end{array}\right] $$ 

Then  $ v_{1} $ and  $ v_{2} $ are those orthogonal eigenvectors rescaled to length 1. Divide by  $ \sqrt{2} $.

Right singular vectors  $ v_1 = \frac{1}{\sqrt{2}} \begin{bmatrix} 1 \\ 1 \end{bmatrix} $  $ v_2 = \frac{1}{\sqrt{2}} \begin{bmatrix} -1 \\ 1 \end{bmatrix} $ Left singular vectors  $ u_i = \frac{Av_i}{\sigma_i} $

Now compute Av1 and Av2 which will be σ1u1 = √45u1 and σ2u2 = √5u2 :

 $$ \begin{array}{r c l c r c l}{{A}\boldsymbol{v}_{1}}&{{=}}&{{\displaystyle\frac{3}{\sqrt{2}}\left[\begin{array}{l}{1}\\ {3}\end{array}\right]}}&{{=}}&{{\displaystyle\sqrt{45}\frac{1}{\sqrt{10}}\left[\begin{array}{l}{1}\\ {3}\end{array}\right]}}&{{=}}&{{\sigma_{1}\boldsymbol{u}_{1}}}\end{array} $$ 

 $$ \begin{array}{r c l c r c l}{{A}\boldsymbol{v}_{2}}&{{=}}&{{\displaystyle\frac{1}{\sqrt{2}}\left[\begin{array}{c c}{-3}\\ {1}\end{array}\right]}}&{{=}}&{{\displaystyle\sqrt{5}\frac{1}{\sqrt{10}}\left[\begin{array}{c c}{-3}\\ {1}\end{array}\right]}}&{{=}}&{{\sigma_{2}\boldsymbol{u}_{2}}}\end{array} $$ 

The division by  $ \sqrt{10} $ makes  $ u_1 $ and  $ u_2 $ orthonormal. Then  $ \sigma_1 = \sqrt{45} $ and  $ \sigma_2 = \sqrt{5} $ as expected. The Singular Value Decomposition of  $ A $ is  $ U $ times  $ \Sigma $ times  $ V^\mathrm{T} $.