## Table of Eigenvalues and Eigenvectors

How are the properties of a matrix reflected in its eigenvalues and eigenvectors? This question is fundamental throughout Chapter 6. A table that organizes the key facts may be helpful. Here are the special properties of the eigenvalues  $ \lambda_i $ and the eigenvectors  $ x_i $.

Symmetric:  $ S^{\mathrm{T}} = S = Q \Lambda Q^{\mathrm{T}} $

Orthogonal:  $ Q^{\mathrm{T}} = Q^{-1} $

real eigenvalues

Skew-symmetric:  $ A^{\mathrm{T}} = -A $

 $$ \mathrm{all}\mid\lambda\mid=1 $$ 

Complex Hermitian:  $ \overline{S}^{\mathrm{T}} = S $

imaginary  $ \lambda $'s

real  $ \lambda $'s

Positive Definite:  $ x^{\mathrm{T}} S x > 0 $

 $$ \mathrm{all}\lambda>0 $$ 

orthogonal  $ \overline{x}_{i}^{\mathrm{T}}x_{j}=0 $

Markov:  $ m_{ij} > 0 $,  $ \sum_{i=1}^{n} m_{ij} = 1 $

orthogonal  $ \overline{x}_{i}^{\mathrm{T}}x_{j}=0 $

orthogonal  $ \overline{x}_{i}^{\mathrm{T}}x_{j}=0 $

Similar: A = BCB^{-1}

orthogonal  $ \boldsymbol{x}_{i}^{\mathrm{T}}\boldsymbol{x}_{j}=0 $

 $$ \lambda_{max}=1 $$ 

 $$ \lambda(A)=\lambda(C) $$ 

Projection:  $ P = P^2 = P^\mathrm{T} $

orthogonal since  $ S^{T} = S $

steady state x > 0

 $$ \lambda=1;0 $$ 

B times eigenvector of C column space; nullspace

Plane Rotation: cosine-sine

 $$ e^{i\theta}\mathrm{a n d}e^{-i\theta} $$ 

Reflection:  $ I - 2uu^{\mathrm{T}} $

 $  \boldsymbol{x} = (1, i)  $ and  $  (1, -i)  $

 $$ \lambda=-1;\;1,..,1 $$ 

Rank One:  $ uv^{T} $

u; whole plane  $ u^{\perp} $

 $$ \lambda=\boldsymbol{v}^{\mathrm{T}}\boldsymbol{u};0,..,0 $$ 

Inverse:  $ A^{-1} $

Shift: A + cI

u; whole plane  $ v^{\perp} $

 $ 1/\lambda(A) $

Stable Powers:  $ A^{n} \rightarrow 0 $

keep eigenvectors of A

 $$ \lambda(A)+c $$ 

Stable Exponential:  $ e^{At} \rightarrow 0 $

all  $ |\lambda| < 1 $

keep eigenvectors of A

any eigenvectors

any eigenvectors

Cyclic Permutation:  $ P_{i,i+1} = 1 $,  $ P_{n1} = 1 $

all Re  $ \lambda < 0 $



Circulant:  $ c_{0}I + c_{1}P + \cdots $

 $$ \lambda_{k}=e^{2\pi ik/n}=roots of1 $$ 

Tridiagonal: -1, 2, -1 on diagonals

 $$ \boldsymbol{x}_{k}=(1,\lambda_{k},\cdots,\lambda_{k}^{n-1}) $$ 

Diagonalizable:  $ A = X \Lambda X^{-} $

 $$ \boldsymbol{x}_{k}=(1,\lambda_{k},\ldots,\lambda_{k}^{n-1}) $$ 

 $$ \lambda_{k}=c_{0}+c_{1}e^{2\pi i k/n}+\cdots $$ 

 $$ \lambda_{k}=2-2\cos\frac{k\pi}{n+1} $$ 

Jordan:  $ A = BJB^{-1} $

diagonal of  $ \Lambda $

SVD:  $ A = U \Sigma V^{T} $

diagonal of triangular $T$

$x_k = \left( \sin \frac{k\pi}{n+1}, \sin \frac{2k\pi}{n+1}, \cdots \right)$ columns of $X$ are independent columns of $Q$ if $A^\mathrm{T}A = AA^\mathrm{T}$ each block gives 1 eigenvector envectors of $A^\mathrm{T}A$, $AA^\mathrm{T}$ in $V$, $U$



diagonal of J

r singular values in  $ \Sigma $ eigenvectors of  $ A^{\mathrm{T}}A $,  $ AA^{\mathrm{T}} $ in V, U