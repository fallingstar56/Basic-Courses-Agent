 $$ \begin{array}{l} Example2\\\text{“ace flag”}\\ French flag A\quad Don^{\prime}t send A=\left[\begin{array}{l}a a c c e e\\ a a c c e e\\ a a c c e e e\\ a a c c e e e\\ a a c c e e e\\ a a c c e e e\end{array}\right]\quad\text{Send}A=\left[\begin{array}{l}1\\ 1\\ 1\\ 1\\ 1\\ 1\end{array}\right]\left[\begin{array}{l}a a c c e e\end{array}\right]\\ Italian flag A\\ German flag A^{\mathrm{T}}\end{array} $$ 

This flag has 3 colors but it still has rank 1. We still have one column times one row. The 36 entries could even be all different, provided they keep that rank 1 pattern  $ A = u_1 v_1^T $. But when the rank moves up to  $ r = 2 $, we need  $ u_1 v_1^T + u_2 v_2^T $. Here is one choice:

Example 3

Embedded square

 $$ \boldsymbol{A}=\left[\begin{array}{l l}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{array}\right]is equal to\boldsymbol{A}=\left[\begin{array}{l}{{{1}}} \\{{{1}}}\end{array}\right]\left[\begin{array}{l l}{{{1}}}&{{{1}}}\end{array}\right]-\left[\begin{array}{l}{{{1}}} \\{{{0}}}\end{array}\right]\left[\begin{array}{l l}{{{0}}}&{{{1}}}\end{array}\right] $$ 

The 1's and the 0 in A could be blocks of 1's and a block of 0's. We would still have rank 2. We would still only need two terms  $ u_1 v_1^T $ and  $ u_2 v_2^T $. A 6 by 6 image would be compressed into 24 numbers. An N by N image ( $ N^2 $ numbers) would be compressed into 4N numbers from the four vectors  $ u_1 $,  $ v_1 $,  $ u_2 $,  $ v_2 $.

Have I made the best choice for the  $ u $'s and  $ v $'s? This is not the choice from the SVD! I notice that  $ \mathbf{u}_1 = (1, 1) $ is not orthogonal to  $ \mathbf{u}_2 = (1, 0) $. And  $ \mathbf{v}_1 = (1, 1) $ is not orthogonal to  $ \mathbf{v}_2 = (0, 1) $. The theory says that orthogonality will produce a smaller second piece  $ c_2 \mathbf{u}_2 \mathbf{v}_2^\mathrm{T} $. (The SVD chooses rank one pieces in order of importance.)

If the rank of A is much higher than 2, as we expect for real images, then A will add up many rank one pieces. We want the small ones to be really small—they can be discarded with no loss to visual quality. Image compression becomes lossy, but good image compression is virtually undetectable by the human visual system.

The question becomes: What are the orthogonal choices from the SVD?

Eigenvectors for the SVD

I want to introduce the use of eigenvectors. But the eigenvectors of most images are not orthogonal. Furthermore the eigenvectors  $ x_1 $,  $ x_2 $ give only one set of vectors, and we want two sets ( $ u $'s and  $ v $'s). The answer to both of those difficulties is the SVD idea:

Use the eigenvectors u of AA^T and the eigenvectors v of A^T A.

Since  $ AA^\top $ and  $ A^\top A $ are automatically symmetric (but not usually equal!) the  $ \boldsymbol{u} $'s will be one orthogonal set and the eigenvectors  $ \boldsymbol{v} $ will be another orthogonal set. We can and will make them all unit vectors:  $ \|\boldsymbol{u}_i\| = 1 $ and  $ \|\boldsymbol{v}_i\| = 1 $. Then our rank 2 matrix will be  $ \boldsymbol{A} = \sigma_1 \boldsymbol{u}_1 \boldsymbol{v}_1^\top + \sigma_2 \boldsymbol{u}_2 \boldsymbol{v}_2^\top $. The size of those numbers  $ \sigma_1 $ and  $ \sigma_2 $ will decide whether they can be ignored in compression. We keep larger  $ \sigma $'s, we discard small  $ \sigma $'s.