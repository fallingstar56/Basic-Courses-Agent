### 7.2 Bases and Matrices in the SVD

1 The SVD produces orthonormal basis of $v$'s and $u$'s for the four fundamental subspaces.

2 Using those bases, $A$ becomes a diagonal matrix $\Sigma$ and $Av_i = \sigma_i u_i : \sigma_i = \text{singular value}$.

3 The two-bases diagonalization $A = U \Sigma V^\text{T}$ often has more information than $A = X \Lambda X^{-1}$.

4 $U \Sigma V^\text{T}$ separates $A$ into rank-1 matrices $\sigma_1 u_1 v_1^\text{T} + \cdots + \sigma_r u_r v_r^\text{T}$. $\sigma_1 u_1 v_1^\text{T}$ is the largest!

The Singular Value Decomposition is a highlight of linear algebra. A is any m by n matrix, square or rectangular. Its rank is r. We will diagonalize this A, but not by  $ X^{-1}AX $. The eigenvectors in X have three big problems: They are usually not orthogonal, there are not always enough eigenvectors, and  $ Ax = \lambda x $ requires A to be a square matrix. The singular vectors of A solve all those problems in a perfect way.

Let me describe what we want from the SVD: the right bases for the four subspaces. Then I will write about the steps to find those basis vectors in order of importance.

The price we pay is to have two sets of singular vectors, u's and v's. The u's are in  $ \mathbf{R}^m $ and the v's are in  $ \mathbf{R}^n $. They will be the columns of an m by m matrix U and an n by n matrix V. I will first describe the SVD in terms of those basis vectors. Then I can also describe the SVD in terms of the orthogonal matrices U and V.

(using vectors) The u's and v's give bases for the four fundamental subspaces:

 $ u_{1}, \ldots, u_{r} $ is an orthonormal basis for the column space

 $ u_{r+1}, \ldots, u_{m} $ is an orthonormal basis for the left nullspace  $ \mathbf{N}(A^{\mathrm{T}}) $

 $ v_{1}, \ldots, v_{r} $ is an orthonormal basis for the row space

 $ v_{r+1}, \ldots, v_{n} $ is an orthonormal basis for the nullspace  $ \mathbf{N}(A) $.

More than just orthogonality, these basis vectors diagonalize the matrix  $ A $:

“A is diagonalized”

 $$ Av_{1}=\sigma_{1}u_{1} $$ 

 $$ A v_{2}=\sigma_{2}u_{2}\quad\cdots\quad A v_{r}=\sigma_{r}u_{r} $$ 

Those singular values  $ \sigma_1 $ to  $ \sigma_r $ will be positive numbers:  $ \sigma_i $ is the length of  $ Av_i $. The  $ \sigma $'s go into a diagonal matrix that is otherwise zero. That matrix is  $ \Sigma $.

(using matrices) Since the  $ u $'s are orthonormal, the matrix  $ U_r $ with those  $ r $ columns has  $ U_r^\mathrm{T}U_r = I $. Since the  $ v $'s are orthonormal, the matrix  $ V_r $ has  $ V_r^\mathrm{T}V_r = I $. Then the equations  $ Av_i = \sigma_i u_i $ tell us column by column that  $ AV_r = U_r \Sigma_r $:

 $$ \begin{array}{l l l l l}{\left(m\;\mathrm{b y}\;n\right)(n\;\mathrm{b y}\;r)}&{}&{}&{}\\ {A V_{r}=U_{r}\Sigma_{r}}&{}&{A}&{\left[\begin{array}{c}{}\\ {}\\ {v_{1}\cdot\cdot\cdot v_{r}}\\ \end{array}\right]=\left[\begin{array}{c}{}\\ {}\\ {u_{1}\cdot\cdot\cdot u_{r}}\\ \end{array}\right]\left[\begin{array}{c c c}{\sigma_{1}}&{}&{}\\ {}&{\cdot}&{}\\ {}&{}&{\sigma_{r}}\\ \end{array}\right].}\\ {(m\;\mathrm{b y}\;r)(r\;\mathrm{b y}\;r)}&{}&{}&{}\\ \end{array} $$ 