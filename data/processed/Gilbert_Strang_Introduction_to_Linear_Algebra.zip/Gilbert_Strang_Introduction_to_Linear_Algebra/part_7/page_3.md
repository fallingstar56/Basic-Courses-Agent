## WORKED EXAMPLES

6.4 A What matrix A has eigenvalues  $ \lambda = 1, -1 $ and eigenvectors  $ \boldsymbol{x}_1 = (\cos\theta, \sin\theta) $ and  $ \boldsymbol{x}_2 = (-\sin\theta, \cos\theta) $? Which of these properties can be predicted in advance?

 $$ A=A^{\mathrm{T}}\qquad A^{2}=I\qquad\det A=-1\qquad\mathrm{p i v o t~a r e+a n d-}\qquad A^{-1}=A $$ 

Solution All those properties can be predicted! With real eigenvalues 1, -1 and orthonormal  $ x_1 $ and  $ x_2 $, the matrix  $ A = Q\Lambda Q^\mathrm{T} $ must be symmetric. The eigenvalues 1 and -1 tell us that  $ A^2 = I $ (since  $ \lambda^2 = 1 $) and  $ A^{-1} = A $ (same thing) and  $ \det A = -1 $. The two pivots must be positive and negative like the eigenvalues, since  $ A $ is symmetric.

The matrix will be a reflection. Vectors in the direction of  $ x_1 $ are unchanged by  $ A $ (since  $ \lambda = 1 $). Vectors in the perpendicular direction are reversed (since  $ \lambda = -1 $). The reflection  $ A = Q \Lambda Q^\mathrm{T} $ is across the “ $ \theta $-line”. Write  $ c $ for  $ \cos \theta $ and  $ s $ for  $ \sin \theta $:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{c-s}}} \\{{{s}}}&{{{c}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0-1}}}\end{bmatrix}\begin{bmatrix}{{{c}}}&{{{s}}} \\{{{-s}}}&{{{c}}}\end{bmatrix}=\begin{bmatrix}{{{c^{2}-s^{2}}}}&{{{2c s}}} \\{{{2c s}}}&{{{s^{2}-c^{2}}}}\end{bmatrix}=\begin{bmatrix}{{{\cos2\theta}}}&{{{\sin2\theta}}} \\{{{\sin2\theta-\cos2\theta}}}\end{bmatrix}. $$ 

Notice that  $ \boldsymbol{x} = (1, 0) $ goes to  $ A\boldsymbol{x} = (\cos 2\theta, \sin 2\theta) $ on the 2 $ \theta $-line. And  $ (\cos 2\theta, \sin 2\theta) $ goes back across the  $ \theta $-line to  $ \boldsymbol{x} = (1, 0) $.

6.4 B Find the eigenvalues and eigenvectors (discrete sines and cosines) of  $ A_{3} $ and  $ B_{4} $

 $$ \boldsymbol{A}_{3}=\left[\begin{array}{r r r}{{{2}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{2}}}\end{array}\right]\qquad\quad\boldsymbol{B}_{4}=\left[\begin{array}{r r r}{{{1}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{1}}}\end{array}\right] $$ 

The -1, 2, -1 pattern in both matrices is a “second difference”. This is like a second derivative. Then  $ Ax = \lambda x $ and  $ Bx = \lambda x $ are like  $ d^2 x / dt^2 = \lambda x $. This has eigenvectors  $ x = \sin kt $ and  $ x = \cos kt $ that are the bases for Fourier series.

 $ A_{n} $ and  $ B_{n} $ lead to “discrete sines” and “discrete cosines” that are the bases for the Discrete Fourier Transform. This DFT is absolutely central to all areas of digital signal processing. The favorite choice for JPEG in image processing has been  $ B_{8} $ of size n = 8.

Solution The eigenvalues of  $ A_3 $ are  $ \lambda = 2 - \sqrt{2} $ and  $ 2 $ and  $ 2 + \sqrt{2} $ (see 6.3 B). Their sum is  $ 6 $ (the trace of  $ A_3 $) and their product is  $ 4 $ (the determinant). The eigenvector matrix gives the “Discrete Sine Transform” and the eigenvectors fall onto sine curves.

 $$ \mathbf{Sines}=\left[\begin{array}{ccc}{{{1}}}&{{{\sqrt{2}}}}&{{{1}}} \\{{{\sqrt{2}}}}&{{{0}}}&{{{-\sqrt{2}}}} \\{{{1}}}&{{{-\sqrt{2}}}}&{{{1}}} \\\end{array}\right]\qquad\mathbf{Cosines}=\left[\begin{array}{cccc}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{\sqrt{2}-1}}}&{{{-1}}}&{{{1-\sqrt{2}}}} \\{{{1}}}&{{{1-\sqrt{2}}}}&{{{-1}}}&{{{\sqrt{2}-1}}} \\{{{1}}}&{{{-1}}}&{{{1}}}&{{{-1}}} \\\end{array}\right] $$ 

Sine matrix = Eigenvectors of  $ A_{3} $

Cosine matrix = Eigenvectors of  $ B_{4} $

The eigenvalues of  $ B_4 $ are  $ \lambda = 2 - \sqrt{2} $ and  $ 2 $ and  $ 2 + \sqrt{2} $ and  $ 0 $ (the same as for  $ A_3 $, plus the zero eigenvalue). The trace is still  $ 6 $, but the determinant is now zero. The eigenvector matrix  $ C $ gives the 4-point “Discrete Cosine Transform”. The graph on the Web shows how the first two eigenvectors fall onto cosine curves. (So do all the eigenvectors of  $ B $.) These eigenvectors match cosines at the halfway points  $ \pi/8 $,  $ 3\pi/8 $,  $ 5\pi/8 $,  $ 7\pi/8 $.