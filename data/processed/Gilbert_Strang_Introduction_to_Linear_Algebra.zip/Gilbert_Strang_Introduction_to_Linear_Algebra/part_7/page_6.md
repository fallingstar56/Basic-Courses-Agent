(a) Show that −λ is also an eigenvalue, with the eigenvector (y, −z).

(b) Show that  $ A^{\mathrm{T}}Az = \lambda^{2}z $, so that  $ \lambda^{2} $ is an eigenvalue of  $ A^{\mathrm{T}}A $.

(c) If  $ A = I $ (2 by 2) find all four eigenvalues and eigenvectors of  $ S $.

If  $ A = \begin{bmatrix} 1 \\ 1 \end{bmatrix} $ in Problem 18, find all three eigenvalues and eigenvectors of  $ S $.

Another proof that eigenvectors are perpendicular when $S = S^{\mathrm{T}}$. Two steps:

1. Suppose  $ Sx = \lambda x $ and  $ Sy = 0y $ and  $ \lambda \neq 0 $. Then y is in the nullspace and x is in the column space. They are perpendicular because ___. Go carefully—why are these subspaces orthogonal?

2. If  $ S y = \beta y $, apply that argument to  $ S - \beta I $. One eigenvalue of  $ S - \beta I $ moves to zero. The eigenvectors x, y stay the same—so they are perpendicular.

Find the eigenvector matrices Q for S and X for B. Show that X doesn't collapse at d = 1, even though  $ \lambda = 1 $ is repeated. Are those eigenvectors perpendicular?

Write a 2 by 2 complex matrix with  $ \overline{S}^{\mathrm{T}} = S $ (a “Hermitian matrix”). Find  $ \lambda_{1} $ and  $ \lambda_{2} $ for your complex matrix. Check that  $ \overline{x}_{1}^{\mathrm{T}} x_{2} = 0 $ (this is complex orthogonality).

 $$ S=\begin{bmatrix}{{{0}}}&{{{d}}}&{{{0}}} \\{{{d}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad B=\begin{bmatrix}{{{-d}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{d}}}\end{bmatrix}\quad have\quad\lambda=1,d,-d. $$ 

23 True (with reason) or false (with example).

(a) A matrix with real eigenvalues and n real eigenvectors is symmetric.

(b) A matrix with real eigenvalues and n orthonormal eigenvectors is symmetric.

(c) The inverse of an invertible symmetric matrix is symmetric.

(d) The eigenvector matrix Q of a symmetric matrix is symmetric.

(A paradox for instructors) If  $ AA^{\mathrm{T}} = A^{\mathrm{T}}A $ then  $ A $ and  $ A^{\mathrm{T}} $ share the same eigenvectors (true).  $ A $ and  $ A^{\mathrm{T}} $ always share the same eigenvalues. Find the flaw in this conclusion:  $ A $ and  $ A^{\mathrm{T}} $ must have the same  $ X $ and same  $ \Lambda $. Therefore  $ A $ equals  $ A^{\mathrm{T}} $.

(Recommended) Which of these classes of matrices do A and B belong to: Invertible, orthogonal, projection, permutation, diagonalizable, Markov?

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}\qquad\boldsymbol{B}=\frac{1}{3}\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix}. $$ 

Which of these factorizations are possible for A and B: LU, QR, XAX−1, QΛQT?

What number $b$ in $A = \begin{bmatrix} 2 & b \\ 1 & 0 \end{bmatrix}$ makes $A = Q\Lambda Q^\mathrm{T}$ possible? What number will make it impossible to diagonalize $A$? What number makes $A$ singular?