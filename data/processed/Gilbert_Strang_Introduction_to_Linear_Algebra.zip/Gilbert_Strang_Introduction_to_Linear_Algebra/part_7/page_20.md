27 The symmetric factorization  $ S = LDL^{\mathrm{T}} $ means that  $ \boldsymbol{x}^{\mathrm{T}} S \boldsymbol{x} = \boldsymbol{x}^{\mathrm{T}} L D L^{\mathrm{T}} \boldsymbol{x} $:

 $$ \left[\begin{array}{l l}{{{x}}}&{{{y}}}\end{array}\right]\left[\begin{array}{l l}{{{a}}}&{{{b}}} \\{{{b}}}&{{{c}}}\end{array}\right]\left[\begin{array}{l l}{{{x}}} \\{{{y}}}\end{array}\right]=\left[\begin{array}{l l}{{{x}}}&{{{y}}}\end{array}\right]\left[\begin{array}{l l}{{{1}}}&{{{0}}} \\{{{b/a}}}&{{{1}}}\end{array}\right]\left[\begin{array}{c c}{{{a}}}&{{{0}}} \\{{{0}}}&{{{(a c-b^{2})/a}}}\end{array}\right]\left[\begin{array}{l l}{{{1}}}&{{{b/a}}} \\{{{0}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{x}}} \\{{{y}}}\end{array}\right]. $$ 

The left side is  $ ax^2 + 2bxy + cy^2 $. The right side is  $ a(x + \frac{b}{a}y)^2 + \_\_\_y^2 $. The second pivot completes the square! Test with  $ a = 2 $,  $ b = 4 $,  $ c = 10 $.

Without multiplying $S=\begin{bmatrix}\cos\theta & -\sin\theta \\ \sin\theta & \cos\theta\end{bmatrix}\begin{bmatrix}2 & 0 \\ 0 & 5\end{bmatrix}\begin{bmatrix}\cos\theta & \sin\theta \\ -\sin\theta & \cos\theta\end{bmatrix}$, find

(a) the determinant of S (b) the eigenvalues of S

(c) the eigenvectors of S (d) a reason why S is symmetric positive definite.

For  $ F_{1}(x,y)=\frac{1}{4}x^{4}+x^{2}y+y^{2} $ and  $ F_{2}(x,y)=x^{3}+xy-x $ find the second derivative matrices  $ S_{1} $ and  $ S_{2} $:

Test for minimum

$$S = \begin{bmatrix} \partial^2 F / \partial x^2 & \partial^2 F / \partial x \partial y \\ \partial^2 F / \partial y \partial x & \partial^2 F / \partial y^2 \end{bmatrix}$$ is positive definite

 $ S_{1} $ is positive definite so  $ F_{1} $ is concave up (= convex). Find the minimum point of  $ F_{1} $. Find the saddle point of  $ F_{2} $ (look only where first derivatives are zero).

The graph of  $ z = x^2 + y^2 $ is a bowl opening upward. The graph of  $ z = x^2 - y^2 $ is a saddle. The graph of  $ z = -x^2 - y^2 $ is a bowl opening downward. What is a test on a, b, c for  $ z = ax^2 + 2bxy + cy^2 $ to have a saddle point at  $ (x, y) = (0, 0) $?

Which values of $c$ give a bowl and which $c$ give a saddle point for the graph $o$ $z = 4x^2 + 12xy + cy^2$? Describe this graph at the borderline value of $c$.

## The Minimum of a Function  $ F(x, y, z) $

What tests would you expect for a minimum point? First come zero slopes :

First derivatives are zero  $ \frac{\partial F}{\partial x} = \frac{\partial F}{\partial y} = \frac{\partial F}{\partial z} = 0 $ at the minimum point.

Next comes the linear algebra version of the usual calculus test  $ d^2 f/dx^2 > 0 $:

Second derivative matrix $S$ is positive definite $S = \left[ \begin{array}{ccc} F_{xx} & F_{xy} & F_{xz} \\ F_{yx} & F_{yy} & F_{yz} \\ F_{zx} & F_{zy} & F_{zz} \end{array} \right]$

Here  $ F_{xy} = \frac{\partial}{\partial x} \left( \frac{\partial F}{\partial y} \right) = \frac{\partial}{\partial y} \left( \frac{\partial F}{\partial x} \right) = F_{yx} $ is a ‘mixed” second derivative.