 $$ \boldsymbol{U}=\frac{1}{\sqrt{10}}\left[\begin{array}{cc}{{{1}}}&{{{-3}}} \\{{{3}}}&{{{1}}}\end{array}\right]\quad\boldsymbol{\Sigma}=\left[\begin{array}{cc}{{{\sqrt{45}}}} \\{{{\sqrt{5}}}}\end{array}\right]\quad\boldsymbol{V}=\frac{1}{\sqrt{2}}\left[\begin{array}{cc}{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}\end{array}\right] $$ 

U and V contain orthonormal bases for the column space and the row space (both spaces are just  $ \mathbf{R}^2 $). The real achievement is that those two bases diagonalize  $ A: AV $ equals  $ U\Sigma $. The matrix  $ A $ splits into a combination of two rank-one matrices, columns times rows:

 $$ \sigma_{1}\boldsymbol{u}_{1}\boldsymbol{v}_{1}^{\mathrm{T}}+\sigma_{2}\boldsymbol{u}_{2}\boldsymbol{v}_{2}^{\mathrm{T}}=\frac{\sqrt{45}}{\sqrt{20}}\left[\begin{array}{cc}{{{1}}}&{{{1}}} \\{{{3}}}&{{{3}}}\end{array}\right]+\frac{\sqrt{5}}{\sqrt{20}}\left[\begin{array}{cc}{{{3}}}&{{{-3}}} \\{{{-1}}}&{{{1}}}\end{array}\right]=\left[\begin{array}{cc}{{{3}}}&{{{0}}} \\{{{4}}}&{{{5}}}\end{array}\right]=\boldsymbol{A}. $$ 

## An Extreme Matrix

Here is a larger example, when the  $ u $'s and the  $ v $'s are just columns of the identity matrix. So the computations are easy, but keep your eye on the order of the columns. The matrix  $ A $ is badly lopsided (strictly triangular). All its eigenvalues are zero.  $ AA^{\mathrm{T}} $ is not close to  $ A^{\mathrm{T}}A $. The matrices  $ U $ and  $ V $ will be permutations that fix these problems properly.

 $$ \boldsymbol{A}=\left[\begin{array}{cccc}{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]\begin{array}{l}{{{eigenvalues\lambda=0,0,0,0\ all\ zero!}}} \\{{{only\ one\ eigenvector\ (1,0,0,0)}}} \\{{{singular\ values\sigma=3,2,1}}} \\{{{singular\ vectors\ are\ columns\ of\ I}}}\end{array} $$ 

 $ A^{T}A $ and  $ AA^{T} $ are diagonal (with easy eigenvectors, but in different orders):

 $$ \boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\left[\begin{array}{llll}{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{4}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{9}}}\end{array}\right]\qquad\boldsymbol{A}\boldsymbol{A}^{\mathrm{T}}=\left[\begin{array}{llll}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{4}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{9}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right] $$ 

Their eigenvectors (u's for  $ AA^T $ and v's for  $ A^T A $) go in decreasing order  $ \sigma_1^2 > \sigma_2^2 > \sigma_3^2 $ of the eigenvalues. Those eigenvalues are  $ \sigma^2 = 9, 4, 1 $.

 $$ \boldsymbol{U}=\left[\begin{array}{cccc}{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{array}\right]\qquad\boldsymbol{\Sigma}=\left[\begin{array}{cccc}{{{3}}} \\{{{2}}} \\{{{1}}} \\{{{0}}}\end{array}\right]\qquad\boldsymbol{V}=\left[\begin{array}{cccc}{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right] $$ 

Those first columns  $ u_1 $ and  $ v_1 $ have 1's in positions 3 and 4. Then  $ u_1 \sigma_1 v_1^T $ picks out the biggest number  $ A_{34} = 3 $ in the original matrix  $ A $. The three rank-one matrices in the SVD come (for this extreme example) exactly from the numbers 3, 2, 1 in  $ A $.

 $$ \begin{array}{r}{\mathbf{A}=\mathbf{U}\mathbf{\Sigma}\mathbf{V}^{\mathrm{T}}=3\mathbf{u}_{1}\mathbf{v}_{1}^{\mathrm{T}}+2\mathbf{u}_{2}\mathbf{v}_{2}^{\mathrm{T}}+1\mathbf{u}_{3}\mathbf{v}_{3}^{\mathrm{T}}.}\end{array} $$ 

Note Suppose I remove the last row of A (all zeros). Then A is a 3 by 4 matrix and  $ AA^{\mathrm{T}} $ is 3 by 3—its fourth row and column will disappear. We still have eigenvalues  $ \lambda = 1, 4, 9 $ in  $ A^{\mathrm{T}}A $ and  $ AA^{\mathrm{T}} $, producing the same singular values  $ \sigma = 3, 2, 1 $ in  $ \Sigma $.