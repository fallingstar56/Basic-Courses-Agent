If $\lambda_{\max}$ is the largest eigenvalue of a symmetric matrix $S$, no diagonal entry can be larger than $\lambda_{\max}$. What is the first entry $a_{11}$ of $S = Q\Lambda Q^{\mathrm{T}}$? Show why $a_{11} \leq \lambda_{\max}$.

33 Suppose  $ A^{\mathrm{T}} = -A $ (real antisymmetric matrix). Explain these facts about A:

(a)  $ x^{\mathrm{T}}Ax = 0 $ for every real vector x.

(b) The eigenvalues of A are pure imaginary.

(c) The determinant of A is positive or zero (not negative).

For (a), multiply out an example of  $ x^{\mathrm{T}}Ax $ and watch terms cancel. Or reverse  $ x^{\mathrm{T}}(Ax) $ to  $ -(Ax)^{\mathrm{T}}x $. For (b),  $ Az = \lambda z $ leads to  $ \overline{z}^{\mathrm{T}}Az = \lambda \overline{z}^{\mathrm{T}}z = \lambda \|z\|^{2} $. Part (a) shows that  $ \overline{z}^{\mathrm{T}}Az = (x - iy)^{\mathrm{T}}A(x + iy) $ has zero real part. Then (b) helps with (c).

If $S$ is symmetric and all its eigenvalues are $\lambda = 2$, how do you know that $S$ must be $2I$? Key point: Symmetry guarantees that $S = Q\Lambda Q^{\mathrm{T}}$. What is that $\Lambda$?

35 Which symmetric matrices S are also orthogonal? Then  $ S^{\mathrm{T}} = S^{-1} $.

(a) Show how symmetry and orthogonality lead to  $ S^{2} = I $.

(b) What are the possible eigenvalues of this S?

(c) What are the possible eigenvalue matrices  $ \Lambda $ ? Then  $ S $ must be  $ Q\Lambda Q^{\mathrm{T}} $ for those  $ \Lambda $ and any orthogonal  $ Q $.

If $S$ is symmetric, show that $A^{\mathrm{T}}SA$ is also symmetric (take the transpose of $A^{\mathrm{T}}SA$). Here $A$ is $m$ by $n$ and $S$ is $m$ by $m$. Are eigenvalues of $S = \text{eigenvalues}$ of $A^{\mathrm{T}}SA$?

In case A is square and invertible,  $ A^{T}SA $ is called congruent to S. They have the same number of positive, negative, and zero eigenvalues: Law of Inertia.

Here is a way to show that a is in between the eigenvalues  $ \lambda_{1} $ and  $ \lambda_{2} $ of S:

 $$ S=\left[\begin{array}{cc}{{{a}}}&{{{b}}} \\{{{b}}}&{{{c}}}\end{array}\right]\qquad\begin{array}{l}\det\left(S-\lambda I\right)=\lambda^{2}-a\lambda-c\lambda+ac-b^{2}\\  is a parabola opening upwards (because of\lambda^{2})\end{array} $$ 

Show that  $ \det(S - \lambda I) $ is negative at  $ \lambda = a $. So the parabola crosses the axis left and right of  $ \lambda = a $. It crosses at the two eigenvalues of  $ S $ so they must enclose  $ a $.

The $n-1$ eigenvalues of $A$ always fall between the $n$ eigenvalues of $S = \begin{bmatrix} A & b \\ b^{\mathrm{T}} & c \end{bmatrix}$.