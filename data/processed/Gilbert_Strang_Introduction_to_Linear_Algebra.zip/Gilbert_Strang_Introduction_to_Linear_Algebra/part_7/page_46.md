## Applications of Eigenfaces

The first commercial use of PCA face recognition was for law enforcement and security. An early test at Super Bowl 35 in Tampa produced a very negative reaction from the crowd! The test was without the knowledge of the fans. Newspapers began calling it the “Snooper Bowl”. I don’t think the original eigenface idea is still used commercially (even in secret).

New applications of the SVD approach have come for other identification problems: Eigenvoices, Eigengaits, Eigeneyes, Eigenexpressions. I learned this from Matthew Turk (now in Santa Barbara, originally an MIT grad student. He told me he was in my class). The original eigenfaces in his thesis had problems accounting for rotation and scaling and lighting in the facial images. But the key ideas live on.

In the end, face space is nonlinear. So eventually we want nonlinear PCA.

## Model Order Reduction

For a large-scale dynamic problem, the computational cost can become unmanageable. “Dynamic” means that the solution  $ u(t) $ evolves as time goes forward. Fluid flow, chemical reactions, wave propagation, biological growth, electronic systems, these problems are everywhere. A reduced model tries to identify important states of the system. From a reduced problem we compute the needed information at much lower cost.

Model reduction is a truly important computational approach. Many good ideas have been proposed to reduce the original large problem. One simple and often useful idea is to take “snapshots” of the flow, put them in a matrix A, find the principal components (the left singular vectors of A), and work in their much smaller subspace:

A snapshot is a column vector that describes the state of the system.

It can be an approximation to a typical true state  $ \boldsymbol{u}(t^{*}) $

From n snapshots, build a matrix A whose columns span a useful range of states

Now find the first  $ R $ left singular vectors  $ \boldsymbol{u}_1 $ to  $ \boldsymbol{u}_R $ of  $ A $. They are a basis for a Proper Orthogonal Decomposition (POD basis). In practice we choose  $ R $ so that

Variance  $ \approx $ Energy

 $$ \sigma_{1}^{2}+\cdots+\sigma_{R}^{2}\mathrm{~i s~}99\%\mathrm{o r}99.9\%\mathrm{o f}\sigma_{1}^{2}+\cdots+\sigma_{n}^{2}. $$ 

These vectors are an optimal basis for reconstructing the snapshots in A. If those snapshots are well chosen, then combinations of  $ u_1 $ to  $ u_R $ will be close to the exact solution  $ \boldsymbol{u}(t) $ for desired times  $ t $ and parameters  $ p $.

So much depends on the snapshots! SIAM Review 2015 includes an excellent survey by Beiner, Gugercin, and Willcox. The SVD compresses data as well as images.

Searching the Web

We believe that Google creates rankings by a walk that follows web links. When this walk goes often to a site, the ranking is high. The frequency of visits gives the leading eigenvector ( $ \lambda = 1 $) of the “Web matrix”—the largest eigenvalue problem ever solved.

That Markov matrix has more than 3 billion rows and columns, from 3 billion web sites.