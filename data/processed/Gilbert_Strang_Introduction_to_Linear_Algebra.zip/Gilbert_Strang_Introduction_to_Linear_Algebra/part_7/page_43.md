## Perpendicular Least Squares

It may not be widely recognized that the best line in Figure 7.2 (the line in the  $ u_1 $ direction) also solves a problem of perpendicular least squares (= orthogonal regression):

The sum of squared distances from the points to the line is a minimum.

Proof. Separate each column  $ a_{j} $ into its components along the  $ u_{1} $ line and  $ u_{2} $ line:

Right triangles

 $$ \sum_{j=1}^{n}||\boldsymbol{a}_{j}||^{2}=\sum_{j=1}^{n}|\boldsymbol{a}_{j}^{\mathrm{T}}\boldsymbol{u}_{1}|^{2}+\sum_{j=1}^{n}|\boldsymbol{a}_{j}^{\mathrm{T}}\boldsymbol{u}_{2}|^{2} $$ 

The sum on the left is fixed by the data points  $ a_j $ (columns of  $ A $). The first sum on the right is  $ \mathbf{u}_1^\text{T} A A^\text{T} \mathbf{u}_1 $. So when we maximize that sum in PCA by choosing the eigenvector  $ \mathbf{u}_1 $, we minimize the second sum. That second sum (squared distances from the data points to the best line) is a minimum for perpendicular least squares.

Ordinary least squares in Chapter 4 reached a linear equation  $ A^{\mathrm{T}} A \widehat{x} = A^{\mathrm{T}} b $ by using vertical distances to the best line. PCA produces an eigenvalue problem for  $ u_1 $ by using perpendicular distances. “Total least squares” will allow for errors in  $ A $ as well as  $ b $.

## The Sample Correlation Matrix

Data analysis works mostly with A (centered data). But the measurements in A might have different units like inches and pounds and years and dollars. Changing one set of units (inches to meters or years to seconds) would have a big effect on that row of A and S. If scaling is a problem, we change from covariance matrix S to correlation matrix C:

A diagonal matrix D rescales A. Each row of DA has length  $ \sqrt{n-1} $.

The sample correlation matrix  $ C = DAA^{\mathrm{T}}D/(n-1) $ has 1's on its diagonal.

Chapter 12 on Probability and Statistics will introduce the expected covariance matrix V and the expected correlation matrix (with diagonal 1's). Those use probabilities instead of actual measurements. The covariance matrix predicts the spread of future measurements around their mean, while A and the sample covariances S and the scaled correlation matrix C = DSD use real data. All are highly important—a big connection between statistics and the linear algebra of positive definite matrices and the SVD.

## Genetic Variation in Europe

We can follow changes in human populations by looking at genomes. To manage the huge amount of data, one good way to see genetic variation is from SNP's. The uncommon alleles (bases A/C/T/G in a pair from father and mother) are counted by the SNP:

SNP = 0 No change from the common base in that population: normal genotype

SNP = 1 The base pair shows one change from the usual pair

SNP = 2 Both bases are the less common allele

The uncentered matrix  $ A_0 $ has a column for every person and a row for every base pair. The entries are mostly 0, quite a few 1, not so many 2. We don’t test all 3 billion pairs. After subtracting row averages from  $ A_0 $, the eigenvectors of  $ AA^\top $ are extremely revealing. In Figure 7.4 the first singular vectors of  $ A $ almost reproduce a map of Europe.