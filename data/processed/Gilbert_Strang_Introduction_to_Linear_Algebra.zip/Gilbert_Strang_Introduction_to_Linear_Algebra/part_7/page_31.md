This is the heart of the SVD, but there is more. Those $v$'s and $u$'s account for the row space and column space of $A$. We have $n-r$ more $v$'s and $m-r$ more $u$'s, from the nullspace $N(A)$ and the left nullspace $N(A^{\mathrm{T}})$. They are automatically orthogonal to the first $v$'s and $u$'s (because the whole nullspaces are orthogonal). We now include all the $v$'s and $u$'s in $V$ and $U$, so these matrices become square. We still have $AV = U\Sigma$.

 $$ \begin{array}{l}(m by n)(n by n)\\ AV\quad equals\quad U\Sigma\quad A\ $ m by m)(m by n)\end{array}\left[v_{1}\cdot\cdot\cdot v_{r}\cdot\cdot\cdot v_{n}\right]=\left[u_{1}\cdot\cdot\cdot u_{r}\cdot\cdot\cdot u_{m}\right]\left[\begin{array}{c}\sigma_{1}\\\cdot\\\sigma_{r}\end{array}\right](3) $$ 

The new  $ \Sigma $ is  $ m $ by  $ n $. It is just the  $ r $ by  $ r $ matrix in equation (2) with  $ m - r $ extra zero rows and  $ n - r $ new zero columns. The real change is in the shapes of  $ U $ and  $ V $. Those are square matrices and  $ V^{-1} = V^\mathrm{T} $. So  $ AV = U\Sigma $ becomes  $ A = U\Sigma V^\mathrm{T} $. This is the Singular Value Decomposition. I can multiply columns  $ u_i\sigma_i $ from  $ U\Sigma $ by rows of  $ V^\mathrm{T} $:

SVD

 $$ \begin{array}{r}{A=U\Sigma V^{\mathrm{T}}=u_{1}\sigma_{1}v_{1}^{\mathrm{T}}+\cdots+u_{r}\sigma_{r}v_{r}^{\mathrm{T}}.}\end{array} $$ 

Equation (2) was a “reduced SVD” with bases for the row space and column space. Equation (3) is the full SVD with nullspaces included. They both split up A into the same r matrices  $ \boldsymbol{u}_{i}\sigma_{i}\boldsymbol{v}_{i}^{\mathrm{T}} $ of rank one. Column times row is the fourth way to multiply matrices.

We will see that each  $ \sigma_i^2 $ is an eigenvalue of  $ A^\mathrm{T}A $ and also  $ AA^\mathrm{T} $. When we put the singular values in descending order,  $ \sigma_1 \geq \sigma_2 \geq \ldots \sigma_r > 0 $, the splitting in equation (4) gives the  $ r $ rank-one pieces of  $ A $ in order of importance. This is crucial.

Example 1 When is  $ A = U \Sigma V^{\mathrm{T}} $ (singular values) the same as  $ X \Lambda X^{-1} $ (eigenvalues)?

Solution A needs orthonormal eigenvectors to allow  $ X = U = V $.  $ A $ also needs eigenvalues  $ \lambda \geq 0 $ if  $ \Lambda = \Sigma $. So  $ A $ must be a positive semidefinite (or definite) symmetric matrix. Only then will  $ A = X \Lambda X^{-1} $ which is also  $ Q \Lambda Q^{\mathrm{T}} $ coincide with  $ A = U \Sigma V^{\mathrm{T}} $.

Example 2 If  $ A = xy^{\mathrm{T}} $ (rank 1) with unit vectors x and y, what is the SVD of  $ A $?

Solution The reduced SVD in (2) is exactly  $ \boldsymbol{x}\boldsymbol{y}^{\mathrm{T}} $, with rank r = 1. It has  $ \boldsymbol{u}_{1} = \boldsymbol{x} $ and  $ \boldsymbol{v}_{1} = \boldsymbol{y} $ and  $ \sigma_{1} = 1 $. For the full SVD, complete  $ \boldsymbol{u}_{1} = \boldsymbol{x} $ to an orthonormal basis of  $ \boldsymbol{u}^{\prime} $s, and complete  $ \boldsymbol{v}_{1} = \boldsymbol{y} $ to an orthonormal basis of  $ \boldsymbol{v}^{\prime} $s. No new  $ \sigma^{\prime} $s, only  $ \sigma_{1} = 1 $.

Proof of the SVD

We need to show how those amazing u's and v's can be constructed. The v's will be orthonormal eigenvectors of  $ A^{T}A $. This must be true because we are aiming for

 $$ \boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=(U\boldsymbol{\Sigma}V^{\mathrm{T}})^{\mathrm{T}}(U\boldsymbol{\Sigma}V^{\mathrm{T}})=V\boldsymbol{\Sigma}^{\mathrm{T}}U^{\mathrm{T}}U\boldsymbol{\Sigma}V^{\mathrm{T}}=V\boldsymbol{\Sigma}^{\mathrm{T}}\boldsymbol{\Sigma}V^{\mathrm{T}}. $$ 

On the right you see the eigenvector matrix V for the symmetric positive (semi) definite matrix  $ A^{\mathrm{T}}A $. And  $ (\Sigma^{\mathrm{T}}\Sigma) $ must be the eigenvalue matrix of  $ (\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}) $:  $ Each \sigma^{2} $ is  $ \lambda(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}) $.