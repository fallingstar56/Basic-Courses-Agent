10 If  $ A^{3} = 0 $ then the eigenvalues of A must be ___. Give an example that has  $ A \neq 0 $. But if A is symmetric, diagonalize it to prove that A must be a zero matrix.

If $\lambda = a + ib$ is an eigenvalue of a real matrix $A$, then its conjugate $\overline{\lambda} = a - ib$ is also an eigenvalue. (If $Ax = \lambda x$ then also $A\overline{x} = \overline{\lambda}\overline{x}$: a conjugate pair $\lambda$ and $\overline{\lambda}$.) Explain why every real 3 by 3 matrix has at least one real eigenvalue.

12 Here is a quick “proof” that the eigenvalues of every real matrix A are real:

False proof

Find the flaw in this reasoning—a hidden assumption that is not justified. You could test those steps on the 90° rotation matrix  $ [0 -1; 1, 0] $ with  $ \lambda = i $ and  $ \boldsymbol{x} = (i, 1) $.

 $$ \boldsymbol{A}\boldsymbol{x}=\lambda\boldsymbol{x}\quad gives\quad\boldsymbol{x}^{\mathrm{T}}\boldsymbol{A}\boldsymbol{x}=\lambda\boldsymbol{x}^{\mathrm{T}}\boldsymbol{x}\quad so\quad\lambda=\frac{\boldsymbol{x}^{\mathrm{T}}\boldsymbol{A}\boldsymbol{x}}{\boldsymbol{x}^{\mathrm{T}}\boldsymbol{x}}=\frac{real}{real}. $$ 

Write $S$ and $B$ in the form $\lambda_{1}x_{1}x_{1}^{\mathrm{T}}+\lambda_{2}x_{2}x_{2}^{\mathrm{T}}$ of the spectral theorem $Q\Lambda Q^{T}$:

 $$ S=\begin{bmatrix}{{{3}}}&{{{1}}} \\{{{1}}}&{{{3}}}\end{bmatrix}\qquad B=\begin{bmatrix}{{{9}}}&{{{12}}} \\{{{12}}}&{{{16}}}\end{bmatrix}\quad(keep\|x_{1}\|=\|x_{2}\|=1). $$ 

Every 2 by 2 symmetric matrix is  $ \lambda_1 x_1 x_1^\mathrm{T} + \lambda_2 x_2 x_2^\mathrm{T} = \lambda_1 P_1 + \lambda_2 P_2 $. Explain  $ P_1 + P_2 = x_1 x_1^\mathrm{T} + x_2 x_2^\mathrm{T} = I $ from columns times rows of  $ Q $. Why is  $ P_1 P_2 = 0 $?

What are the eigenvalues of  $ A = \begin{bmatrix} 0 & b \\ -b & 0 \end{bmatrix} $? Create a 4 by 4 antisymmetric matrix  $ (A^\mathrm{T} = -A) $ and verify that all its eigenvalues are imaginary.

(Recommended) This matrix $M$ is antisymmetric and also ___. Then all its eigenvalues are pure imaginary and they also have $|\lambda|=1$. $(\|M\boldsymbol{x}\|=\|\boldsymbol{x}\|$ for every $\boldsymbol{x}$ so $\|\lambda\boldsymbol{x}\|=\|\boldsymbol{x}\|$ for eigenvectors.) Find all four eigenvalues from the trace of $M$:

$$M=\frac{1}{\sqrt{3}}\begin{bmatrix}0&1&1&1\\ -1&0&-1&1\\ -1&1&0&-1\\ -1&-1&1&0\end{bmatrix}$$

can only have eigenvalues $i$ or $-i$.

17 Show that this A (symmetric but complex) has only one line of eigenvectors:

 $ A = \begin{bmatrix} i & 1 \\ 1 & -i \end{bmatrix} $ is not even diagonalizable: eigenvalues  $ \lambda = 0, 0. $

 $ A^{\mathrm{T}} = A $ is not such a special property for complex matrices. The good property is  $ \overline{A}^{\mathrm{T}} = A $ (Section 9.2). Then all  $ \lambda $’s are real and the eigenvectors are orthogonal.

18 Even if $A$ is rectangular, the block matrix $S = \begin{bmatrix} 0 & A \\ A^\mathrm{T} & 0 \end{bmatrix}$ is symmetric:

 $$ S\boldsymbol{x}=\lambda\boldsymbol{x}\quad is\quad\begin{bmatrix}0&A\\ A^{\mathrm{T}}&0\end{bmatrix}\begin{bmatrix}y\\ z\end{bmatrix}=\lambda\begin{bmatrix}y\\ z\end{bmatrix}\quad which is\quad\begin{aligned}A\boldsymbol{z}&=\lambda\boldsymbol{y}\\ A^{\mathrm{T}}\boldsymbol{y}&=\lambda\boldsymbol{z}.\end{aligned} $$ 