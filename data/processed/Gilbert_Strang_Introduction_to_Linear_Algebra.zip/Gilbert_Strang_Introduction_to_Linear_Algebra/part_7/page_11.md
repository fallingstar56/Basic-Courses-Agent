Definition S is positive definite if  $ x^{\mathrm{T}}Sx > 0 $ for every nonzero vector x:

 $$ \begin{aligned}\mathbf{2}\mathbf{by}\mathbf{2}\quad\mathbf{x}^{\mathrm{T}}S\mathbf{x}&=\left[\begin{bmatrix}{{{x}}}&{{{y}}}\end{bmatrix}\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{b}}}&{{{c}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}}\end{bmatrix}=\quad ax^{2}+2bxy+cy^{2}>0.\end{aligned} $$ 

The four entries $a, b, b, c$ give the four parts of $\boldsymbol{x}^{\mathrm{T}} S\boldsymbol{x}$. From $a$ and $c$ come the pure squares $ax^{2}$ and $cy^{2}$. From $b$ and $b$ off the diagonal come the cross terms $bxy$ and $byx$ (the same). Adding those four parts gives $\boldsymbol{x}^{\mathrm{T}} S\boldsymbol{x}$. This energy-based definition leads to a basic fact:

If S and T are symmetric positive definite, so is  $ S + T $.

Reason:  $ \boldsymbol{x}^{\mathrm{T}}(S+T)\boldsymbol{x} $ is simply  $ \boldsymbol{x}^{\mathrm{T}}S\boldsymbol{x}+\boldsymbol{x}^{\mathrm{T}}T\boldsymbol{x} $. Those two terms are positive (for  $ \boldsymbol{x}\neq0 $) so  $ S+T $ is also positive definite. The pivots and eigenvalues are not easy to follow when matrices are added, but the energies just add.

 $ x^{\mathrm{T}}Sx $ also connects with our final way to recognize a positive definite matrix. Start with any matrix A, possibly rectangular. We know that  $ S = A^{\mathrm{T}}A $ is square and symmetric. More than that, S will be positive definite when A has independent columns:

Test: If the columns of A are independent, then  $ S = A^{T} A $ is positive definite.

Again eigenvalues and pivots are not easy. But the number  $ \boldsymbol{x}^{\mathrm{T}} S \boldsymbol{x} $ is the same as  $ \boldsymbol{x}^{\mathrm{T}} A^{\mathrm{T}} A \boldsymbol{x} $.  $ \boldsymbol{x}^{\mathrm{T}} A^{\mathrm{T}} A \boldsymbol{x} $ is exactly  $ (\boldsymbol{A} \boldsymbol{x})^{\mathrm{T}} (\boldsymbol{A} \boldsymbol{x}) = \| A \boldsymbol{x} \|^2 $—another important proof by parenthesis! That vector  $ A \boldsymbol{x} $ is not zero when  $ \boldsymbol{x} \neq \mathbf{0} $ (this is the meaning of independent columns). Then  $ \boldsymbol{x}^{\mathrm{T}} S \boldsymbol{x} $ is the positive number  $ \| A \boldsymbol{x} \|^2 $ and the matrix  $ S $ is positive definite.

Let me collect this theory together, into five equivalent statements of positive definiteness. You will see how that key idea connects the whole subject of linear algebra: pivots, determinants, eigenvalues, and least squares (from  $ A^{T}A $). Then come the applications.

When a symmetric matrix S has one of these five properties, it has them all :

1. All n pivots of S are positive.

2. All n upper left determinants are positive.

3. All n eigenvalues of S are positive.

4.  $ x^{\mathrm{T}} S x $ is positive except at x = 0. This is the energy-based definition.

5. S equals  $ A^{T}A $ for a matrix A with independent columns.

The “upper left determinants” are 1 by 1, 2 by 2, ..., n by n. The last one is the determinant of the complete matrix S. This theorem ties together the whole linear algebra course.