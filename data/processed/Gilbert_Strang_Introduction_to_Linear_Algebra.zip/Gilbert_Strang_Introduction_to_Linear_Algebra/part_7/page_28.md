Your faithful author has continued research on the ranks of flags. Quite a few are based on horizontal or vertical stripes. Those have rank one—all rows or all columns are multiples of the ones vector  $ (1,1,\ldots,1) $. Armenia, Austria, Belgium, Bulgaria, Chad, Colombia, Ireland, Madagascar, Mali, Netherlands, Nigeria, Romania, Russia (and more) have three stripes. Indonesia and Poland have two! Libya was the extreme case in the Gadaffi years 1977 to 2011 (the whole flag was green).

At the other extreme, many flags include diagonal lines. Those could be long diagonals as in the British flag. Or they could be short diagonals coming from the edges of a star—as in the US flag. The text example of a triangle of ones shows how those flag matrices will have large rank. The rank increases to infinity as the pixel sizes get small.

Other flags have circles or crescents or various curved shapes. Their ranks are large and also increasing to infinity. These are still compressible! The compressed image won't be perfect but our eyes won't see the difference (with enough terms  $ \sigma_i \boldsymbol{u}_i \boldsymbol{v}_i^T $ from the SVD). Those examples actually bring out the main purpose of image compression:

Visual quality can be preserved even with a big reduction in the rank.

For fun I looked back at the flags with finite rank. They can have stripes and they can also have crosses—provided the edges of the cross are horizontal or vertical. Some flags have a thin outline around the cross. This artistic touch will increase the rank. Right now my champion is the flag of Greece shown below, with a cross and also stripes. Its rank is three by my counting (three different columns). I see no US State Flags of finite rank!

The reader could google “national flags” to see the variety of designs and colors. I would be glad to know any finite rank examples with rank > 3. Good examples of all kinds will go on the book’s website math.mit.edu/linearalgebra (and flags in full color).

<div style="text-align: center;"><img src="imgs/img_in_image_box_161_703_867_1137.jpg" alt="Image" width="66%" /></div>
