#### 7.2 B Show that  $ \sigma_1 \geq |\lambda|_{\max} $. The largest singular value dominates all eigenvalues

Solution Start from  $ A = U \Sigma V^\mathrm{T} $. Remember that multiplying by an orthogonal matrix does not change length:  $ \|Qx\| = \|x\| $ because  $ \|Qx\|^2 = x^\mathrm{T}Q^\mathrm{T}Qx = x^\mathrm{T}x = \|x\|^2 $. This applies to  $ Q = U $ and  $ Q = V^\mathrm{T} $. In between is the diagonal matrix  $ \Sigma $.

 $$ \|A\boldsymbol{x}\|=\|U\Sigma V^{\mathrm{T}}\boldsymbol{x}\|=\|\Sigma V^{\mathrm{T}}\boldsymbol{x}\|\leq\sigma_{1}\|V^{\mathrm{T}}\boldsymbol{x}\|=\sigma_{1}\|\boldsymbol{x}\|. $$ 

An eigenvector has  $ \|Ax\| = |\lambda|\|x\| $. So (14) says that  $ |\lambda|\|x\| \leq \sigma_1\|x\| $. Then  $ |\lambda| \leq \sigma_1 $.

Apply also to the unit vector  $ \boldsymbol{x} = (1, 0, \ldots, 0) $. Now  $ A\boldsymbol{x} $ is the first column of  $ A $

Then by inequality (14), this column has length  $ \leq \sigma_1 $. Every entry must have  $ |a_{ij}| \leq \sigma_1 $

Equation (14) shows again that the maximum value of ||Ax||/||x|| equals σ1.

Section 11.2 will explain how the ratio  $ \sigma_{\max}/\sigma_{\min} $ governs the roundoff error in solving Ax = b. MATLAB warns you if this “condition number” is large. Then x is unreliable.

### Problem Set 7.2

1 Find the eigenvalues of these matrices. Then find singular values from  $ A^{T}A $:

 $$ \boldsymbol{A}=\left[\begin{array}{ll}{{{0}}}&{{{4}}} \\{{{0}}}&{{{0}}}\end{array}\right]\quad\boldsymbol{A}=\left[\begin{array}{ll}{{{0}}}&{{{4}}} \\{{{1}}}&{{{0}}}\end{array}\right] $$ 

For each $A$, construct $V$ from the eigenvectors of $A^\mathrm{T}A$ and $U$ from the eigenvectors of $AA^\mathrm{T}$. Check that $A = U \Sigma V^\mathrm{T}$.

Find  $ A^{\mathrm{T}}A $ and  $ V $ and  $ \Sigma $ and  $ u_i = Av_i/\sigma_i $ and the full SVD:

 $$ \boldsymbol{A}=\left[\begin{array}{cc}{{{2}}}&{{{2}}} \\{{{-1}}}&{{{1}}}\end{array}\right]=\boldsymbol{U}\boldsymbol{\Sigma}\boldsymbol{V}^{\mathrm{T}}. $$ 

In Problem 2, show that  $ AA^{\mathrm{T}} $ is diagonal. Its eigenvectors  $ u_{1}, u_{2} $ are ___. Its eigenvalues  $ \sigma_{1}^{2}, \sigma_{2}^{2} $ are ___. The rows of A are orthogonal but they are not ___. So the columns of A are not orthogonal.

4 Compute  $ A^{T}A $ and  $ AA^{T} $ and their eigenvalues and unit eigenvectors for V and U.

Rectangular matrix

 $$ \boldsymbol{A}=\left[\begin{array}{lll}{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}}\end{array}\right]. $$ 

Check AV = U∑ (this decides ± signs in U). ∑ has the same shape as A : 2 × 3.

(a) The row space of  $ A = \left[\begin{array}{cc} 1 & 1 \\ 3 & 3 \end{array}\right] $ is 1-dimensional. Find  $ v_1 $ in the row space and  $ u_1 $ in the column space. What is  $ \sigma_1 $? Why is there no  $ \sigma_2 $?