9 Find the 3 by 3 matrix S and its pivots, rank, eigenvalues, and determinant:

 $$ \left[\begin{matrix}x_{1}&x_{2}&x_{3}\\ \end{matrix}\right]\left[\begin{matrix}\\ &S\\ \end{matrix}\right]\left[\begin{matrix}x_{1}\\ x_{2}\\ x_{3}\\ \end{matrix}\right]=4(x_{1}-x_{2}+2x_{3})^{2}. $$ 

10 Which 3 by 3 symmetric matrices S and T produce these quadratics?

 $  \boldsymbol{x}^{\mathrm{T}} \boldsymbol{S} \boldsymbol{x} = 2 \left( x_{1}^{2} + x_{2}^{2} + x_{3}^{2} - x_{1} x_{2} - x_{2} x_{3} \right)  $. Why is  $  S  $ positive definite?

 $$ \boldsymbol{x}^{\mathrm{T}}T\boldsymbol{x}=2\big(x_{1}^{2}+x_{2}^{2}+x_{3}^{2}-x_{1}x_{2}-x_{1}x_{3}-x_{2}x_{3}\big). $$ 

Why is T semidefinite?

11 Compute the three upper left determinants of S to establish positive definiteness. Verify that their ratios give the second and third pivots.

Pivots = ratios of determinants

 $$ S=\begin{bmatrix}{{{2}}}&{{{2}}}&{{{0}}} \\{{{2}}}&{{{5}}}&{{{3}}} \\{{{0}}}&{{{3}}}&{{{8}}}\end{bmatrix}. $$ 

12 For what numbers c and d are S and T positive definite? Test their 3 determinants:

 $$ S=\begin{bmatrix}{{{c}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{c}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{c}}}\end{bmatrix}\qquad and\qquad T=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{d}}}&{{{4}}} \\{{{3}}}&{{{4}}}&{{{5}}}\end{bmatrix}. $$ 

13 Find a matrix with a > 0 and c > 0 and a + c > 2b that has a negative eigenvalue.

Problems 14–20 are about applications of the tests.

14 If $S$ is positive definite then $S^{-1}$ is positive definite. Best proof: The eigenvalues of $S^{-1}$ are positive because ___. Second proof (only for 2 by 2):

The entries of  $ S^{-1} = \frac{1}{ac - b^{2}} \begin{bmatrix} c & -b \\ -b & a \end{bmatrix} $ pass the determinant tests ___.

If $S$ and $T$ are positive definite, their sum $S + T$ is positive definite. Pivots and eigenvalues are not convenient for $S + T$. Better to use $\mathbf{x}^{\mathrm{T}}(S + T)\mathbf{x} > 0$. Also $S = A^{\mathrm{T}}A$ and $T = B^{\mathrm{T}}B$ give $S + T = \left[\mathbf{A} \mathbf{B}\right]^{\mathrm{T}} \left[\begin{array}{c} \mathbf{A} \\ \mathbf{B} \end{array}\right]$ with independent columns.

16 A positive definite matrix cannot have a zero (or even worse, a negative number) on its main diagonal. Show that this matrix fails to have  $ \boldsymbol{x}^{\mathrm{T}} \boldsymbol{S} \boldsymbol{x} > 0 $:

 $$ \begin{aligned}\left[\begin{bmatrix}{{{x_{1}}}}&{{{x_{2}}}}&{{{x_{3}}}}\end{bmatrix}\right]\begin{bmatrix}{{{4}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{5}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}}\end{bmatrix}&is not positive when\left(x_{1},x_{2},x_{3}\right)=\left(\quad,\quad,\quad\right).\end{aligned} $$ 

17 A diagonal entry  $ s_{jj} $ of a symmetric matrix cannot be smaller than all the  $ \lambda $'s. If it were, then  $ S - s_{jj}I $ would have ___ eigenvalues and would be positive definite. But  $ S - s_{jj}I $ has a ___ on the main diagonal.