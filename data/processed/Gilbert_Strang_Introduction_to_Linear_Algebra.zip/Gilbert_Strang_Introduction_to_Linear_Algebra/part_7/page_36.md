Start with any orthogonal matrix  $ Q_1 $ that has  $ q_1 $ in its first column. The other  $ n - 1 $ orthonormal columns just have to be orthogonal to  $ q_1 $. Then use  $ Sq_1 = \lambda_1 q_1 $:

 $$ S Q_{1}=S\left[\boldsymbol{q}_{1}\boldsymbol{q}_{2}\cdots\boldsymbol{q}_{n}\right]=\left[\boldsymbol{q}_{1}\boldsymbol{q}_{2}\cdots\boldsymbol{q}_{n}\right]\begin{bmatrix}\lambda_{1}&\boldsymbol{w}^{\mathrm{T}}\\ \mathbf{0}&S_{n-1}\end{bmatrix}=Q_{1}\begin{bmatrix}\lambda_{1}&\boldsymbol{w}^{\mathrm{T}}\\ \mathbf{0}&S_{n-1}\end{bmatrix}. $$ 

Multiply by  $ Q_{1}^{\mathrm{T}} $, remember  $ Q_{1}^{\mathrm{T}}Q_{1}=I $, and recognize that  $ Q_{1}^{\mathrm{T}}SQ_{1} $ is symmetric like S:

 $$ \mathrm{T h e~s y m m e t r y~o f~}Q_{1}^{\mathrm{T}}S Q_{1}=\left[\begin{array}{c c}\lambda_{1}&\boldsymbol{w}^{\mathrm{T}}\\ \mathbf{0}&S_{n-1}\end{array}\right]\mathrm{f o r c e s}\boldsymbol{w}=\mathbf{0}\mathrm{a n d}S_{n-1}^{\mathrm{T}}=S_{n-1}. $$ 

The requirement  $ q_1^\mathrm{T} x = 0 $ has reduced the maximum problem (10) to size  $ n - 1 $. The largest eigenvalue of  $ S_{n-1} $ will be the second largest for  $ S $.  $ \mathbf{It} $ is  $ \lambda_2 $. The winning vector in (10) will be the eigenvector  $ q_2 $ with  $ S q_2 = \lambda_2 q_2 $.

We just keep going—or use the magic word induction—to produce all the eigenvectors  $ q_1, \ldots, q_n $ and their eigenvalues  $ \lambda_1, \ldots, \lambda_n $. The Spectral Theorem  $ S = Q\Lambda Q^\mathrm{T} $ is proved even with repeated eigenvalues. All symmetric matrices can be diagonalized.

Similarly the SVD is found one step at a time from (9) and (11) and onwards. Section 7.4 will show the geometry—we are finding the axes of an ellipse. Here I ask a different question: How are the  $ \lambda $'s and  $ \sigma $'s actually computed?

## Computing the Eigenvalues of S and Singular Values of A

The singular values  $ \sigma_i $ of  $ A $ are the square roots of the eigenvalues  $ \lambda_i $ of  $ S = A^\mathrm{T} A $. This connects the SVD to a symmetric eigenvalue problem (good). But in the end we don’t want to multiply  $ A^\mathrm{T} $ times  $ A $ (squaring is time-consuming: not good).

The first idea is to produce zeros in A and S without changing any  $ \sigma $'s and  $ \lambda $'s. Singular vectors and eigenvectors will change—no problem. The similar matrix  $ Q^{-1}SQ $ has the same  $ \lambda $'s as S. If Q is orthogonal, this matrix is  $ Q^{T}SQ $ and still symmetric.

Section 11.3 will show how to build Q from 2 by 2 rotations so that  $ Q^{T}SQ $ is symmetric and tridiagonal (many zeros). But rotations can't get all the way to a diagonal matrix. To show all the eigenvalues of S needs a new idea and more work.

For the SVD, what is the parallel to  $ Q^{\mathrm{T}}SQ $ ? Now we don’t want to change any singular values of A. Natural answer: You can multiply A by two different orthogonal matrices  $ Q_{1} $ and  $ Q_{2} $. Use them to produce zeros in  $ Q_{1}^{\mathrm{T}}AQ_{2} $. The  $ \sigma $'s don’t change :

 $$ (\boldsymbol{Q}_{1}^{\mathrm{T}}\boldsymbol{A}\boldsymbol{Q}_{2})^{\mathrm{T}}(\boldsymbol{Q}_{1}^{\mathrm{T}}\boldsymbol{A}\boldsymbol{Q}_{2})=\boldsymbol{Q}_{2}^{\mathrm{T}}\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}\boldsymbol{Q}_{2}=\boldsymbol{Q}_{2}^{\mathrm{T}}\boldsymbol{S}\boldsymbol{Q}_{2}gives the same\sigma(\boldsymbol{A}) $$ 

The freedom of two $Q$'s allows us to reach $Q_1^\mathrm{T} A Q_2 = \text{bidiaqonal matrix}$ (2 diagonals). This compares perfectly to $Q^\mathrm{T} S Q = 3$ diagonals. It is nice to notice the connection between them: (bidiaqonal)$^\mathrm{T}$ (bidiaqonal) = tridiagonal.

The final steps to a diagonal  $ \Lambda $ and a diagonal  $ \Sigma $ need more ideas. This problem can't be easy, because underneath we are solving  $ \det(S - \lambda I) = 0 $ for polynomials of degree  $ n = 100 $ or 1000 or more. We certainly don't use those polynomials!