The $u$'s from the SVD are called left singular vectors (unit eigenvectors of $AA^{\mathrm{T}}$). The $v$'s are right singular vectors (unit eigenvectors of $A^{\mathrm{T}}A$). The $\sigma$'s are singular values, square roots of the equal eigenvalues of $AA^{\mathrm{T}}$ and $A^{\mathrm{T}}A$:

Choices from the SVD

 $$ \begin{array}{c} AA^{\mathrm{T}}u_{i}=\sigma_{i}^{2}u_{i}\quad A^{\mathrm{T}}Av_{i}=\sigma_{i}^{2}v_{i}\quad Av_{i}=\sigma_{i}u_{i}\end{array} $$ 

In Example 3 (the embedded square), here are the symmetric matrices AA^T and A^T A:

 $$ \boldsymbol{A}\boldsymbol{A}^{\mathrm{T}}=\left[\begin{array}{l}10\\ 11\end{array}\right]\left[\begin{array}{l}11\\ 01\end{array}\right]=\left[\begin{array}{l}11\\ 12\end{array}\right]\qquad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\left[\begin{array}{l}11\\ 01\end{array}\right]\left[\begin{array}{l}10\\ 11\end{array}\right]=\left[\begin{array}{l}21\\ 11\end{array}\right]. $$ 

Their determinants are 1, so  $ \lambda_{1}\lambda_{2}=1 $. Their traces (diagonal sums) are 3:

 $$ \det\left[\begin{array}{cc}{{{1-\lambda}}}&{{{1}}} \\{{{1}}}&{{{2-\lambda}}}\end{array}\right]=\lambda^{2}-3\lambda+1=0\quad gives\quad\lambda_{1}=\frac{3+\sqrt{5}}{2}\quad and\quad\lambda_{2}=\frac{3-\sqrt{5}}{2}. $$ 

The square roots of  $ \lambda_{1} $ and  $ \lambda_{2} $ are  $ \sigma_{1} = \frac{\sqrt{5} + 1}{2} $ and  $ \sigma_{2} = \frac{\sqrt{5} - 1}{2} $ with  $ \sigma_{1} \sigma_{2} = 1 $.

The nearest rank 1 matrix to A will be σ1u1v1. The error is only σ2 ≈ 0.6 = best possible.

The orthonormal eigenvectors of  $ AA^{T} $ and  $ A^{T}A $ are

 $$ \boldsymbol{u}_{1}=\begin{bmatrix}1\\ \sigma_{1}\end{bmatrix}\quad\boldsymbol{u}_{2}=\begin{bmatrix}\sigma_{1}\\ -1\end{bmatrix}\quad\boldsymbol{v}_{1}=\begin{bmatrix}\sigma_{1}\\ 1\end{bmatrix}\quad\boldsymbol{v}_{2}=\begin{bmatrix}1\\ -\sigma_{1}\end{bmatrix}\quad\mathrm{all\ divided\ by\ }\sqrt{1+\sigma_{1}^{2}}. $$ 

Every reader understands that in real life those calculations are done by computers! (Certainly not by unreliable professors. I corrected myself using  $  \text{svd}(A)  $ in MATLAB.) And we can check that the matrix  $  A  $ is correctly recovered from  $  \sigma_1 u_1 v_1^\text{T} + \sigma_2 u_2 v_2^\text{T}  $:

 $$ \boldsymbol{A}=\left[\boldsymbol{u}_{1}\quad\boldsymbol{u}_{2}\right]\left[\begin{array}{c}\sigma_{1}\\ \\ \sigma_{2}\end{array}\right]\left[\begin{array}{c}\boldsymbol{v}_{1}^{\mathrm{T}}\\ \boldsymbol{v}_{2}^{\mathrm{T}}\end{array}\right]\mathrm{o r~m o r e~s i m p l y}\boldsymbol{A}\left[\begin{array}{l l}\boldsymbol{v}_{1}\quad\boldsymbol{v}_{2}\end{array}\right]=\left[\begin{array}{l l}\sigma_{1}\boldsymbol{u}_{1}&\sigma_{2}\boldsymbol{u}_{2}\end{array}\right] $$ 

Important The key point is not that images tend to have low rank. No: Images mostly have full rank. But they do have low effective rank. This means: Many singular values are small and can be set to zero. We transmit a low rank approximation.

Example 4 Suppose the flag has two triangles of different colors. The lower left triangle has 1's and the upper right triangle has 0's. The main diagonal is included with the 1's. Here is the image matrix when n = 4. It has full rank r = 4 so it is invertible:

Triangular flag matrix

 $$ \boldsymbol{A}=\left[\begin{array}{cccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}}\end{array}\right]\quad and\quad\boldsymbol{A}^{-1}=\left[\begin{array}{cccc}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right] $$ 