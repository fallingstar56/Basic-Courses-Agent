Example 1 Test these symmetric matrices S and T for positive definiteness:

 $$ \boldsymbol{S}=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}\qquad and\qquad\boldsymbol{T}=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{b}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{b}}}&{{{-1}}}&{{{2}}}\end{bmatrix}. $$ 

Solution The pivots of $S$ are 2 and $\frac{3}{2}$ and $\frac{4}{3}$, all positive. Its upper left determinants are 2 and 3 and 4, all positive. The eigenvalues of $S$ are $2 - \sqrt{2}$ and $2$ and $2 + \sqrt{2}$, all positive. That completes tests 1, 2, and 3. Any one test is decisive!

I have three candidates  $ A_1, A_2, A_3 $ to suggest for  $ S = A^\mathrm{T} A $. They all show that  $ S $ is positive definite.  $ A_1 $ is a first difference matrix, 4 by 3, to produce  $ -1, 2, -1 $ in  $ S $:

 $$ \boldsymbol{S}=\boldsymbol{A}_{1}^{\mathrm{T}}\boldsymbol{A}_{1}\quad\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}\end{bmatrix} $$ 

The three columns of  $ A_{1} $ are independent. Therefore S is positive definite.

 $ A_2 $ comes from  $ S = LDL^\mathrm{T} $ (the symmetric version of  $ S = LU $). Elimination gives the pivots  $ 2, \frac{3}{2}, \frac{4}{3} $ in  $ D $ and the multipliers  $ -\frac{1}{2}, 0, -\frac{2}{3} $ in  $ L $. Just put  $ A_2 = L\sqrt{D} $.

 $$ L D L^{\mathrm{T}}=\left[\begin{array}{c c}{{{1}}} \\{{{-\frac{1}{2}}}}&{{{1}}} \\{{{0}}}&{{{-\frac{2}{3}}}}&{{{1}}}\end{array}\right]\left[\begin{array}{c c}{{{2}}} \\{{{\frac{3}{2}}}} \\{{{\frac{4}{3}}}}\end{array}\right]\left[\begin{array}{c c}{{{1}}}&{{{-\frac{1}{2}}}}&{{{0}}} \\{{{1}}}&{{{-\frac{2}{3}}}} \\{{{1}}}\end{array}\right]=(L\sqrt{D})(L\sqrt{D})^{\mathrm{T}}=A_{2}^{\mathrm{T}}A_{2}. $$ 

This triangular choice of $A$ has square roots (not so beautiful). It is the “Cholesky factor” of $S$ and the MATLAB command is $A = \text{chol}(S)$. In applications, the rectangular $A_1$ is how we build $S$ and this Cholesky $A_2$ is how we break it apart.

Eigenvalues give the symmetric choice  $ A_3 = Q\sqrt{\Lambda}Q^\mathrm{T} $. This is also successful with  $ A_3^\mathrm{T}A_3 = Q\Lambda Q^\mathrm{T} = S $. All tests show that the  $ -1, 2, -1 $ matrix  $ S $ is positive definite.

To see that the energy  $ \boldsymbol{x}^{\mathrm{T}} S \boldsymbol{x} $ is positive, we can write it as a sum of squares. The three choices  $ A_{1}, A_{2}, A_{3} $ give three different ways to split up  $ \boldsymbol{x}^{\mathrm{T}} S \boldsymbol{x} $:

 $$ \boldsymbol{x}^{\mathrm{T}}S\boldsymbol{x}=2x_{1}^{2}-2x_{1}x_{2}+2x_{2}^{2}-2x_{2}x_{3}+2x_{3}^{2}\qquad\text{Rewrite with squares} $$ 

 $$ ||A_{1}\boldsymbol{x}||^{2}=x_{1}^{2}+\left(x_{2}-x_{1}\right)^{2}+\left(x_{3}-x_{2}\right)^{2}+x_{3}^{2}\qquad Using differences in A_{1} $$ 

 $$ \left|\left|A_{2}\boldsymbol{x}\right|\right|^{2}=2\left(x_{1}-\frac{1}{2}x_{2}\right)^{2}+\frac{3}{2}\left(x_{2}-\frac{2}{3}x_{3}\right)^{2}+\frac{4}{3}x_{3}^{2}\quad\mathbf{U}\mathbf{s}\mathbf{i}\mathbf{n}\mathbf{g}\boldsymbol{S}=\boldsymbol{L}\boldsymbol{D}\boldsymbol{L}^{\mathrm{T}} $$ 

 $$ ||A_{3}\boldsymbol{x}||^{2}=\lambda_{1}(\boldsymbol{q}_{1}^{\mathrm{T}}\boldsymbol{x})^{2}+\lambda_{2}(\boldsymbol{q}_{2}^{\mathrm{T}}\boldsymbol{x})^{2}+\lambda_{3}(\boldsymbol{q}_{3}^{\mathrm{T}}\boldsymbol{x})^{2}\qquad\mathbf{U}sing\boldsymbol{S}=Q\boldsymbol{\Lambda}\boldsymbol{Q}^{\mathrm{T}} $$ 

Now turn to T (top of this page). The  $ (1,3) $ and  $ (3,1) $ entries move away from 0 to b. This b must not be too large! The determinant test is easiest. The 1 by 1 determinant is 2, the 2 by 2 determinant T is still 3. The 3 by 3 determinant involves b:

Test on T

 $$ \det T=4+2b-2b^{2}=(1+b)(4-2b)\quad must be positive. $$ 

At $b = -1$ and $b = 2$ we get $\det T = 0$. Between $b = -1$ and $b = 2$ this matrix $T$ is positive definite. The corner entry $b = 0$ in the matrix $S$ was safely between $-1$ and $2$.