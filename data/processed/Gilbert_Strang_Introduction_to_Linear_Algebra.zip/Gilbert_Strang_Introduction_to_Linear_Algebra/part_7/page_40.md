If $A = QR$ with an orthogonal matrix $Q$, the SVD of $A$ is almost the same as the SVD of $R$. Which of the three matrices $U, \Sigma, V$ is changed because of $Q$?

Suppose A is invertible (with $\sigma_{1} > \sigma_{2} > 0$). Change A by as small a matrix as possible to produce a singular matrix $A_{0}$. Hint: $U$ and $V$ do not change:

From

 $$ \boldsymbol{A}=\left[\begin{array}{ll}\boldsymbol{u}_{1}&\boldsymbol{u}_{2}\end{array}\right]\left[\begin{array}{ll}\sigma_{1}&&\\ &\sigma_{2}\end{array}\right]\left[\begin{array}{ll}v_{1}&v_{2}\end{array}\right]^{\mathrm{T}}\quad find the nearest A_{0}. $$ 

20 Find the singular values of A from the command svd(A) or by hand.

 $$ A=\left[\begin{array}{cc}{{{1}}}&{{{0}}} \\{{{100}}}&{{{1}}}\end{array}\right].Why is\sigma_{2}=\frac{1}{\sigma_{1}}-for this matrix? $$ 

21 Why doesn’t the SVD for  $ A + I $ just use  $ \Sigma + I $?

22 If $A = U \Sigma V^{\mathrm{T}}$ then $Q_{1} A Q_{2}^{\mathrm{T}} = (Q_{1} U) \Sigma (Q_{2} V)^{\mathrm{T}}$. Why will any orthogonal matrices $Q_{1}$ and $Q_{2}$ leave $Q_{1} U$ = orthogonal matrix and $Q_{2} V$ = orthogonal matrix? Then $\Sigma$ sees no change in the singular values: $Q_{1} A Q_{2}^{\mathrm{T}}$ has the same $\sigma^{\prime}$s as $A$.

23 If Q is an orthogonal matrix, why do all its singular values equal 1?

24 (a) Find the maximum of  $ \frac{x^{\mathrm{T}}Sx}{x^{\mathrm{T}}x} = \frac{3x_{1}^{2} + 2x_{1}x_{2} + 3x_{2}^{2}}{x_{1}^{2} + x_{2}^{2}} $. What matrix is S?

(b) Find the maximum of  $ \frac{(x_1 + 4x_2)^2}{x_1^2 + x_2^2} $. For what matrix  $ A $ is this  $ \frac{||A\boldsymbol{x}||^2}{||\boldsymbol{x}||^2} $?

What are the minimum values of the ratios  $ \frac{x^{\mathrm{T}}Sx}{x^{\mathrm{T}}x} $ and  $ \frac{||Ax||^{2}}{||x||^{2}} $? We should take x to be which eigenvectors of S? Should x always be an eigenvector of A?

Every matrix  $ A = U \Sigma V^{\mathrm{T}} $ takes circles to ellipses.  $ AV = U \Sigma $ says that the radius vectors  $ v_1 $ and  $ v_2 $ of the circle go to the semi-axes  $ \sigma_1 u_1 $ and  $ \sigma_2 u_2 $ of the ellipse. Draw the circle and the ellipse for  $ \theta = 30^\circ $:

 $$ V=\left[\begin{array}{cc}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{array}\right]\qquad U=\left[\begin{array}{cc}{{{\cos\theta}}}&{{{-\sin\theta}}} \\{{{\sin\theta}}}&{{{\cos\theta}}}\end{array}\right]\qquad\Sigma=\left[\begin{array}{cc}{{{2}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{array}\right]. $$ 

Section 7.4 will start with an important SVD picture for 2 by 2 matrices:

 $ A = (\mathrm{rotate})(\mathrm{stretch})(\mathrm{rotate}) $. With symmetry  $ S = (\mathrm{rotate})(\mathrm{stretch})(\mathrm{rotate}) $ back.

This problem looks for all matrices A with a given column space in  $ \mathbf{R}^m $ and a given row space in  $ \mathbf{R}^n $. Suppose  $ c_1, \ldots, c_r $ and  $ b_1, \ldots, b_r $ are bases for those two spaces. Make them columns of C and B. The goal is to show that A has this form:

 $ A = CMB^\mathrm{T} $ for an  $ r $ by  $ r $ invertible matrix  $ M $. Hint: Start from  $ A = U\Sigma V^\mathrm{T} $

The first $r$ columns of $U$ and $V$ must be connected to $C$ and $B$ by invertible matrices, because they contain bases for the same column space (in $U$) and row space (in $V$).