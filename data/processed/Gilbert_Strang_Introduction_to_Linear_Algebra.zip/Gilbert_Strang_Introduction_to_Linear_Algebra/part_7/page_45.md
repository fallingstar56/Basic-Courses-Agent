Recognizing faces would not seem to depend—at first glance—on linear algebra. But an early and well publicized application of the SVD was to face recognition. We are not compressing an image, we are identifying it.

The plan is to start with a “training set”  $ A_0 $ of  $ n $ images of a wide variety of faces. Each image becomes a very long vector by stacking all pixel grayscales into a column. Then  $ A_0 $ must be centered: subtract the average of every column of  $ A_0 $ to reach  $ A $.

The singular vector  $ v_{1} $ of this A tells us the combination of known faces that best identifies a new face. Then  $ v_{2} $ tells us the next best combination.

Probably we will use the $R$ best vectors $v_1, \ldots, v_R$ with largest singular values $\sigma_1 \geq \cdots \geq \sigma_R$ of $A$. Those identify new faces more accurately than any other $R$ vectors. Perhaps $R = 100$ of those eigenfaces $A v$ will capture nearly all the variance in the training set. Those $R$ eigenfaces span “face space”.

This plan of attack was suggested by Matthew Turk and Alex Pentland. It developed the suggestion by Sirovich and Kirby to use PCA in compressing images of faces. I learned a lot from Jeff Jauregui's description on the Web. His summary is this: PCA provides a mechanism to recognize geometric/photometric similarity through algebraic means. He assembled the first principal component (first singular vector) into the first eigenface. Of course the average of each column was added back or you wouldn't see a face!

Note PCA is compared to NMF in a fascinating letter to Nature (Lee and Seung, vol. 401, 21 Oct. 1999). Nonnegative Matrix Factorization does not allow the negative entries that always appear in the singular vectors v. So everything adds—which needs more vectors but they are often more meaningful.

<div style="text-align: center;"><img src="imgs/img_in_image_box_376_722_544_925.jpg" alt="Image" width="15%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_564_721_732_925.jpg" alt="Image" width="15%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_376_952_546_1154.jpg" alt="Image" width="15%" /></div>


<div style="text-align: center;">Figure 7.4: Eigenfaces pick out hairline and mouth and eyes and shape.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_563_952_733_1154.jpg" alt="Image" width="15%" /></div>
