## Challenge Problems

A group of nonsingular matrices includes AB and  $ A^{-1} $ if it includes A and B. “Products and inverses stay in the group.” Which of these are groups (as in 2.7.37)?

Invent a “subgroup” of two of these groups (not I by itself = the smallest group).

(a) Positive definite symmetric matrices S.

(c) All exponentials  $ e^{tA} $ of a fixed matrix A.

(b) Orthogonal matrices Q.

(d) Matrices P with positive eigenvalues.

(e) Matrices D with determinant 1.

When $S$ and $T$ are symmetric positive definite, $ST$ might not even be symmetric. But its eigenvalues are still positive. Start from $STx = \lambda x$ and take dot products with $Tx$. Then prove $\lambda > 0$.

Write down the 5 by 5 sine matrix Q from Worked Example 6.5 C, containing the eigenvectors of S when n = 5 and h = 1/6. Multiply SQ to see the five  $ \lambda $'s.

The sum of λ's should equal the trace 10. Their product should be det S = 6.

Suppose $C$ is positive definite (so $\mathbf{y}^{\mathrm{T}}C\mathbf{y}>0$ whenever $\mathbf{y}\neq0$) and $A$ has independent columns (so $Ax\neq0$ whenever $\mathbf{x}\neq0$). Apply the energy test to $\mathbf{x}^{\mathrm{T}}A^{\mathrm{T}}CA\mathbf{x}$ to show that $S=A^{\mathrm{T}}CA$ is positive definite: the crucial matrix in engineering.

Important! Suppose $S$ is positive definite with eigenvalues $\lambda_{1} \geq \lambda_{2} \geq \ldots \geq \lambda_{n}$.

(a) What are the eigenvalues of the matrix  $ \lambda_{1}I - S $? Is it positive semidefinite?

(b) How does it follow that  $ \lambda_1 x^\mathrm{T} x \geq x^\mathrm{T} S x $ for every  $ x $?

(c) Draw this conclusion: The maximum value of  $ x^{\mathrm{T}}Sx/x^{\mathrm{T}}x $ is ___.

For which $a$ and $c$ is this matrix positive definite? For which $a$ and $c$ is it positive semidefinite (this includes definite)?

 $$ \boldsymbol{S}=\left[\begin{array}{ccc}a&a&a\\a&a+c&a-c\\a&a-c&a+c\end{array}\right]\qquad\begin{array}{l}All5testsarepossible.\\ Theenergy\boldsymbol{x}^{\mathrm{T}}S\boldsymbol{x}equals\\a\left(x_{1}+x_{2}+x_{3}\right)^{2}+c\left(x_{2}-x_{3}\right)^{2}.\end{array} $$ 