 $ S = Q \Lambda Q^{\mathrm{T}} $ is positive definite when all  $ \lambda_i > 0 $. The graph of  $ x^{\mathrm{T}} S x = 1 $ is an ellipse:

 $$ \mathbf{E}l l i p\mathbf{s}\mathbf{e}\left[\begin{array}{l l}x&y\end{array}\right]Q\Lambda Q^{\mathrm{T}}\begin{bmatrix}x\\ y\end{bmatrix}=\left[\begin{array}{l l}X&Y\end{array}\right]\Lambda\begin{bmatrix}X\\ Y\end{bmatrix}=\lambda_{1}X^{2}+\lambda_{2}Y^{2}=1. $$ 

The axes point along eigenvectors of S. The half-lengths are  $ 1/\sqrt{\lambda_1} $ and  $ 1/\sqrt{\lambda_2} $.

$S = I$ gives the circle $x^2 + y^2 = 1$. If one eigenvalue is negative (exchange 4's and 5's in $S$), the ellipse changes to a hyperbola. The sum of squares becomes a difference of squares: $9X^2 - Y^2 = 1$. For a negative definite matrix like $S = -I$, with both $\lambda$'s negative, the graph of $-x^2 - y^2 = 1$ has no points at all.

If $S$ is $n$ by $n$, $\boldsymbol{x}^{\mathrm{T}}S\boldsymbol{x}=1$ is an “ellipsoid” in $\mathbf{R}^{n}$. Its axes are the eigenvectors of $S$.

## Important Application: Test for a Minimum

Does  $  F(x,y)  $ have a minimum if  $  \partial F/\partial x = 0  $ and  $  \partial F/\partial y = 0  $ at the point  $  (x,y) = (0,0)  $?

For $f(x)$, the test for a minimum comes from calculus: $df/dx$ is zero and $d^2f/dx^2 > 0$. Two variables in $F(x, y)$ produce a symmetric matrix $S$. It contains four second derivatives. Positive $d^2f/dx^2$ changes to positive definite $S$:

Second derivatives

 $$ S=\left[\begin{array}{cc}\partial^{2}F/\partial x^{2}&\partial^{2}F/\partial x\partial y\\ \partial^{2}F/\partial y\partial x&\partial^{2}F/\partial y^{2}\end{array}\right] $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_678_637_895_740.jpg" alt="Image" width="20%" /></div>


 $ F(x,y) $ has a minimum if  $ \partial F/\partial x = \partial F/\partial y = 0 $ and  $ S $ is positive definite.

Reason: $S$ reveals the all-important terms $ax^2 + 2bxy + cy^2$ near $(x,y) = (0,0)$. The second derivatives of $F$ are $2a, 2b, 2b, 2c$. For $F(x,y,z)$ the matrix $S$ will be 3 by 3.

## ■ REVIEW OF THE KEY IDEAS

1. Positive definite matrices have positive eigenvalues and positive pivots.

2. A quick test is given by the upper left determinants: a > 0 and ac - b^{2} > 0.

3. The graph of the energy  $ x^{\mathrm{T}}Sx $ is then a “bowl” going up from x = 0:

 $  \mathbf{x}^\mathrm{T} S \mathbf{x} = a x^2 + 2 b x y + c y^2  $ is positive except at  $  (x, y) = (0, 0)  $.

4.  $ S = A^{\mathrm{T}} A $ is automatically positive definite if  $ A $ has independent columns.

5. The ellipsoid  $ x^{\mathrm{T}}Sx = 1 $ has its axes along the eigenvectors of S. Lengths  $ 1/\sqrt{\lambda} $.

6. Minimum of  $ F(x, y) $ if  $ \frac{\partial F}{\partial x} = \frac{\partial F}{\partial y} = 0 $ and 2nd derivative matrix is positive definite.