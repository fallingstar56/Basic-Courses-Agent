This means: The SNP’s from France and Germany and Italy are quite different. Even from the French and German and Italian parts of Switzerland those “snips” are different! Only Spain and Portugal are surprisingly confounded and harder to separate. More often than not, the DNA of an individual reveals his birthplace within 300 kilometers or 200 miles. A mixture of grandparents usually places the grandchild between their origins.

<div style="text-align: center;"><img src="imgs/img_in_image_box_237_262_824_705.jpg" alt="Image" width="55%" /></div>


<div style="text-align: center;">Figure 7.3: Nature (2008) Novembre et al: vol. 456 pp.98-101/doc:10.1038/nature07331.</div>


What is the significant message? If we test genomes to understand how they correlate with diseases, we must not forget their spatial variation. Without correcting for geography, what looks medically significant can be very misleading. Confounding is a serious problem in medical genetics that PCA and population genetics can help to solve—to remove effects due to geography that don't have medical importance.

In fact “spatial statistics” is a tricky world. Example: Every matrix with three diagonals of 1, C, 1 shows a not surprising influence of next door neighbors (from the 1’s). But its singular vectors have sine and cosine oscillations going across the map, independent of C. You might think those are true wave-like variations but they can be meaningless.

Maybe statistics produces more arguments than mathematics does? Reducing big data to a single small “P-value” can be instructive or it can be extremely deceptive. The expression P-value appears in many articles. P stands for the probability that an observation is consistent with the null hypothesis (= pure chance). If you see 5 heads in a row, the probability is  $ P = \frac{1}{32} $ that this came by chance from a fair coin (or  $ P = \frac{2}{32} $ if your observation is taken to be 5 heads or 5 tails in a row). Often a P-value below 0.05 makes the null hypothesis doubtful—maybe a crook is flipping the coin. As here, P-values are not the most reliable guides in statistics—but they are extremely convenient.