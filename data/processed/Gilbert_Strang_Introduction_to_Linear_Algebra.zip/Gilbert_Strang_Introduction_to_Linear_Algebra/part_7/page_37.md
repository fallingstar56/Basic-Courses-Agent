The favorite way to find  $ \lambda $'s and  $ \sigma $'s in LAPACK uses simple orthogonal matrices to approach  $ Q^{\mathrm{T}}SQ = \Lambda $ and  $ U^{\mathrm{T}}AV = \Sigma $. We stop when very close to  $ \Lambda $ and  $ \Sigma $.

This 2-step approach (zeros first) is built into the commands  $ \mathbf{eig}(S) $ and  $ \mathbf{svd}(A) $.

## ■ REVIEW OF THE KEY IDEAS

1. The SVD factors  $ A $ into  $ U\Sigma V^\mathrm{T} $, with  $ r $ singular values  $ \sigma_1 \geq \ldots \geq \sigma_r > 0 $.

2. The numbers  $ \sigma_{1}^{2}, \ldots, \sigma_{r}^{2} $ are the nonzero eigenvalues of  $ AA^{T} $ and  $ A^{T}A $.

3. The orthonormal columns of U and V are eigenvectors of  $ AA^{T} $ and  $ A^{T}A $.

4. Those columns hold orthonormal bases for the four fundamental subspaces of A.

5. Those bases diagonalize the matrix:  $ Av_i = \sigma_i u_i $ for  $ i \leq r $. This is  $ AV = U\Sigma $.

6.  $ A = \sigma_1 u_1 v_1^\mathrm{T} + \cdots + \sigma_r u_r v_r^\mathrm{T} $ and  $ \sigma_1 $ is the maximum of the ratio  $ \|Ax\| $ /  $ \|x\| $.

## WORKED EXAMPLES

7.2 A Identify by name these decompositions of A into a sum of columns times rows:

1. Orthogonal columns  $ u_{1}\sigma_{1},\ldots,u_{r}\sigma_{r} $ times orthonormal rows  $ v_{1}^{\mathrm{T}},\ldots,v_{r}^{\mathrm{T}} $

2. Orthonormal columns  $ q_{1},\ldots,q_{r} $ times triangular rows  $ r_{1}^{\mathrm{T}},\ldots,r_{r}^{\mathrm{T}}. $

3. Triangular columns  $ l_{1}, \ldots, l_{r} $ times triangular rows  $ u_{1}^{T}, \ldots, u_{r}^{T} $

Where do the rank and the pivots and the singular values of A come into this picture?

Solution These three factorizations are basic to linear algebra, pure or applied:

1. Singular Value Decomposition  $ A = U \Sigma V^{\mathrm{T}} $

2. Gram-Schmidt Orthogonalization  $ A = QR $

3. Gaussian Elimination A = LU

You might prefer to separate out singular values  $ \sigma_i $ and heights  $ h_i $ and pivots  $ d_i $:

1.  $ A = U \Sigma V^{\mathrm{T}} $ with unit vectors in U and V. The r singular values  $ \sigma_i $ are in  $ \Sigma $.

2. A = QHR with unit vectors in Q and diagonal 1's in R. The r heights  $ h_{i} $ are in H.

3. A = LDU with diagonal 1's in L and U. The r pivots  $ d_i $ are in D.

Each $h_i$ tells the height of column $i$ above the plane of columns 1 to $i - 1$. The volume of the full $n$-dimensional box $(r = m = n)$ comes from $A = U \Sigma V^\mathrm{T} = LDU = QHR$:

 $$ \left|det A\right|=\left|product of\sigma^{\prime}s\right|=\left|product of d^{\prime}s\right|=\left|product of h^{\prime}s\right|. $$ 