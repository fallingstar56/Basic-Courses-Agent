both positive (if $a$ or $c$ is not positive, $ac - b^2 > 0$ will fail). Problem 1 reverses the reasoning to show that the tests $a > 0$ and $ac > b^2$ guarantee $\lambda_1 > 0$ and $\lambda_2 > 0$.

This test uses the 1 by 1 determinant a and the 2 by 2 determinant  $ ac - b^2 $. When S is 3 by 3,  $ \det S > 0 $ is the third part of the test. The next test requires positive pivots.

Test: The eigenvalues of S are positive if and only if the pivots are positive:

 $$ a>0\qquad and\qquad\frac{ac-b^{2}}{a}>0. $$ 

a > 0 is required in both tests. So ac > b² is also required, for the determinant test and now the pivot test. The point is to recognize that ratio as the second pivot of S:

 $$ \begin{bmatrix}{{{a}}}&{{{b}}} \\{{{b}}}&{{{c}}}\end{bmatrix}\quad\xrightarrow{The first pivot is a}\quad\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{0}}}&{{{c-\frac{b}{a}b}}}\end{bmatrix}\quad\begin{aligned}The second pivot is\\c-\frac{b^{2}}{a}=\frac{ac-b^{2}}{a}\end{aligned} $$ 

This connects two big parts of linear algebra. Positive eigenvalues mean positive pivots and vice versa. Each pivot is a ratio of upper left determinants. The pivots give a quick test for  $ \lambda > 0 $, and they are a lot faster to compute than the eigenvalues. It is very satisfying to see pivots and determinants and eigenvalues come together in this course.

$$S = \begin{bmatrix} 2 & 1 & 1 \\ 1 & 2 & 1 \\ 1 & 1 & 2 \end{bmatrix}$$ is positive definite

eigenvalues 1, 1, 4

determinants 2 and 3 and 4

pivots 2 and 3/2 and 4/3



$S-I$ will be semidefinite: eigenvalues 0, 0, 3. $S-2I$ is indefinite because $\lambda = -1, -1, 2$. Now comes a different way to look at symmetric matrices with positive eigenvalues.

Energy-based Definition

From  $ Sx = \lambda x $, multiply by  $ x^T $ to get  $ x^T Sx = \lambda x^T x $. The right side is a positive  $ \lambda $ times a positive number  $ x^T x = \|x\|^2 $. So the left side  $ x^T Sx $ is positive for any eigenvector.

Important point: The new idea is that  $ \mathbf{x}^{\mathrm{T}}S\mathbf{x} $ is positive for all nonzero vectors  $ \mathbf{x} $, not just the eigenvectors. In many applications this number  $ \mathbf{x}^{\mathrm{T}}S\mathbf{x} $ (or  $ \frac{1}{2}\mathbf{x}^{\mathrm{T}}S\mathbf{x} $) is the energy in the system. The requirement of positive energy gives another definition of a positive definite matrix. I think this energy-based definition is the fundamental one.

Eigenvalues and pivots are two equivalent ways to test the new requirement xT Sx > 0.