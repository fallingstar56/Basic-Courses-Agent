If Sx = λx then x^T Sx = ___. Why is this number positive when λ > 0?

Reverse Problem 18 to show that if all $\lambda > 0$ then $\boldsymbol{x}^{\mathrm{T}} \boldsymbol{S} \boldsymbol{x} > 0$. We must do this for every nonzero $\boldsymbol{x}$, not just the eigenvectors. So write $\boldsymbol{x}$ as a combination of the eigenvectors and explain why all “cross terms” are $\boldsymbol{x}_{i}^{\mathrm{T}} \boldsymbol{x}_{j} = 0$. Then $\boldsymbol{x}^{\mathrm{T}} \boldsymbol{S} \boldsymbol{x}$ is

 $$ \left(c_{1}\boldsymbol{x}_{1}+\cdots+c_{n}\boldsymbol{x}_{n}\right)^{\mathrm{T}}\left(c_{1}\lambda_{1}\boldsymbol{x}_{1}+\cdots+c_{n}\lambda_{n}\boldsymbol{x}_{n}\right)=c_{1}^{2}\lambda_{1}\boldsymbol{x}_{1}^{\mathrm{T}}\boldsymbol{x}_{1}+\cdots+c_{n}^{2}\lambda_{n}\boldsymbol{x}_{n}^{\mathrm{T}}\boldsymbol{x}_{n}>0. $$ 

20 Give a quick reason why each of these statements is true:

(a) Every positive definite matrix is invertible.

(b) The only positive definite projection matrix is P = I.

(c) A diagonal matrix with positive diagonal entries is positive definite.

(d) A symmetric matrix with a positive determinant might not be positive definite!

Problems 21–24 use the eigenvalues; Problems 25–27 are based on pivots.

21 For which s and t do S and T have all  $ \lambda > 0 $ (therefore positive definite)?

 $$ S={\left[\begin{matrix}{s}&{-4}&{-4}\\ {-4}&{s}&{-4}\\ {-4}&{-4}&{s}\\ \end{matrix}\right]}\qquad{\mathrm{a n d}}\qquad T={\left[\begin{matrix}{t}&{3}&{0}\\ {3}&{t}&{4}\\ {0}&{4}&{t}\\ \end{matrix}\right]}. $$ 

From $S = Q\Lambda Q^{\mathrm{T}}$ compute the positive definite symmetric square root $Q\sqrt{\Lambda}Q^{\mathrm{T}}$ of each matrix. Check that this square root gives $A^{\mathrm{T}}A = S$:

 $$ S=\begin{bmatrix}{{{5}}}&{{{4}}} \\{{{4}}}&{{{5}}}\end{bmatrix}\qquad and\qquad S=\begin{bmatrix}{{{10}}}&{{{6}}} \\{{{6}}}&{{{10}}}\end{bmatrix}. $$ 

You may have seen the equation for an ellipse as  $ x^2/a^2 + y^2/b^2 = 1 $. What are a and b when the equation is written  $ \lambda_1 x^2 + \lambda_2 y^2 = 1 $? The ellipse  $ 9x^2 + 4y^2 = 1 $ has axes with half-lengths  $ a = $ ___ and  $ b = $ ___.

Draw the tilted ellipse  $ x^2 + xy + y^2 = 1 $ and find the half-lengths of its axes from the eigenvalues of the corresponding matrix  $ S $.

With positive pivots in $D$, the factorization $S = LDL^{\mathrm{T}}$ becomes $L\sqrt{D}\sqrt{D}L^{\mathrm{T}}$. (Square roots of the pivots give $D = \sqrt{D}\sqrt{D}$.) Then $C = \sqrt{D}L^{\mathrm{T}}$ yields the Cholesky factorization $A = C^{\mathrm{T}}C$ which is “symmetrized $L U$”:

 $$ \begin{aligned}From\quad C&=\begin{bmatrix}{{{3}}}&{{{1}}} \\{{{0}}}&{{{2}}}\end{bmatrix}\quad find S.\quad&From\quad S&=\begin{bmatrix}{{{4}}}&{{{8}}} \\{{{8}}}&{{{25}}}\end{bmatrix}\quad find C&=chol(S).\end{aligned} $$ 

In the Cholesky factorization  $ S = C^{\mathrm{T}}C $, with  $ C = \sqrt{D}L^{\mathrm{T}} $, the square roots of the pivots are on the diagonal of  $ C $. Find  $ C $ (upper triangular) for

 $$ S=\begin{bmatrix}{{{9}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{2}}} \\{{{0}}}&{{{2}}}&{{{8}}}\end{bmatrix}\qquad and\qquad S=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{7}}}\end{bmatrix}. $$ 