You see how an image that has m times n pixels, with each pixel using 8 bits (0 or 1) for its grayscale, becomes an m by n matrix with 256 possible values for each entry  $ a_{ij} $.

In short, an image is a large matrix. To copy it perfectly, we need  $ 8(m)(n) $ bits of information. High definition television typically has  $ m = 1080 $ and  $ n = 1920 $. Often there are 24 frames each second and you probably like to watch in color (3 color scales). This requires transmitting (3)(8)(48, 470, 400) bits per second. That is too expensive and it is not done. The transmitter can't keep up with the show.

When compression is well done, you can't see the difference from the original. Edges in the image (sudden changes in the grayscale) are the hard parts to compress.

Major success in compression will be impossible if every  $ a_{ij} $ is an independent random number. We totally depend on the fact that nearby pixels generally have similar grayscales. An edge produces a sudden jump when you cross over it. Cartoons are more compressible than real-world images. with edges everywhere.

For a video, the numbers  $ a_{ij} $ don't change much between frames. We only transmit the small changes. This is difference coding in the H.264 video compression standard (on this book's website). We compress each change matrix by linear algebra (and by nonlinear "quantization" for an efficient step to integers in the computer).

The natural images that we see every day are absolutely ready and open for compression—but that doesn't make it easy to do.

## Low Rank Images (Examples)

The easiest images to compress are all black or all white or all a constant grayscale g. The matrix A has the same number g in every entry:  $ a_{ij} = g $. When g = 1 and m = n = 6, here is an extreme example of the central SVD dogma of image processing:

Example 1 Don't send

 $$ \boldsymbol{A}=\left[\begin{array}{llll}1&1&1&1&1\\1&1&1&1&1\\1&1&1&1&1\\1&1&1&1&1\\1&1&1&1&1\\1&1&1&1&1\end{array}\right]\quad\mathbf{S e n d~t h i s}\boldsymbol{A}=\left[\begin{array}{l}1\\1\\1\\1\\1\\1\end{array}\right]\left[\begin{array}{llll}1&1&1&1&1\end{array}\right] $$ 

36 numbers become 12 numbers. With 300 by 300 pixels, 90,000 numbers become 600. And if we define the all-ones vector x in advance, we only have to send one number. That number would be the constant grayscale g that multiplies  $ xx^{T} $ to produce the matrix.

Of course this first example is extreme. But it makes an important point. If there are special vectors like  $ x = \mathbf{ones} $ that can usefully be defined in advance, then image processing can be extremely fast. The battle is between preselected bases (the Fourier basis allows speed-up from the FFT) and adaptive bases determined by the image. The SVD produces bases from the image itself—this is adaptive and it can be expensive.

I am not saying that the SVD always or usually gives the most effective algorithm in practice. The purpose of these next examples is instruction and not production.