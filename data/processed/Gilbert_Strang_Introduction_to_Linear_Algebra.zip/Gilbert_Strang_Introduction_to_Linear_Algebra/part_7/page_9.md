### 6.5 Positive Definite Matrices

1 Symmetric $S$: all eigenvalues > 0 ⇔ all pivots > 0 ⇔ all upper left determinants > 0.
2 The matrix $S$ is then positive definite. The energy test is $x^{\mathrm{T}}Sx > 0$ for all vectors $x \neq 0$.
3 One more test for positive definiteness: $S = A^{\mathrm{T}}A$ with independent columns in $A$.
4 Positive semidefinite $S$ allows $\lambda = 0$, pivot = 0, determinant = 0, energy $x^{\mathrm{T}}Sx = 0$.
5 The equation $x^{\mathrm{T}}Sx = 1$ gives an ellipse in $\mathbf{R}^n$ when $S$ is symmetric positive definite.

This section concentrates on symmetric matrices that have positive eigenvalues. If symmetry makes a matrix important, this extra property (all  $ \lambda > 0 $) makes it truly special. When we say special, we don't mean rare. Symmetric matrices with positive eigenvalues are at the center of all kinds of applications. They are called positive definite.

The first problem is to recognize positive definite matrices. You may say, just find all the eigenvalues and test  $ \lambda > 0 $. That is exactly what we want to avoid. Calculating eigenvalues is work. When the  $ \lambda $'s are needed, we can compute them. But if we just want to know that all the  $ \lambda $'s are positive, there are faster ways. Here are two goals of this section:

• To find quick tests on a symmetric matrix that guarantee positive eigenvalues.

• To explain important applications of positive definiteness.

Every eigenvalue is real because the matrix is symmetric.

Start with 2 by 2. When  $ \text{does } S = \begin{bmatrix} a & b \\ b & c \end{bmatrix} $ have  $ \lambda_1 > 0 $ and  $ \lambda_2 > 0 $?

Test: The eigenvalues of S are positive if and only if a > 0 and ac - b² > 0.

$$S_{1}=\begin{bmatrix}1&2\\ 2&1\end{bmatrix}$$ is not positive definite because $ac-b^{2}=1-4<0$$

$$S_{2}=\begin{bmatrix}1&-2\\ -2&6\end{bmatrix}$$ is positive definite because $a=1$ and $ac-b^{2}=6-4>0$$

$$S_{3}=\begin{bmatrix}-1&2\\ 2&-6\end{bmatrix}$$ is not positive definite (even with $\det A=+2$) because $a=-$$

The eigenvalues 3 and -1 of  $ S_1 $ confirm that  $ S_1 $ is not positive definite. Positive trace 3 - 1 = 2, but negative determinant (3)(-1) = -3. And  $ S_3 = -S_2 $ is negative definite. Two positive eigenvalues for  $ S_2 $, two negative eigenvalues for  $ S_3 $.

Proof that the 2 by 2 test is passed when  $ \lambda_1 > 0 $ and  $ \lambda_2 > 0 $. Their product  $ \lambda_1 \lambda_2 $ is the determinant so  $ ac - b^2 > 0 $. Their sum  $ \lambda_1 + \lambda_2 $ is the trace so  $ a + c > 0 $. Then a and c are