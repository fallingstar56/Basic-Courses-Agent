The q's are orthonormal, the u's are orthonormal, the v's are orthonormal. Beautiful.

But I want to look again, for two good reasons. One is to fix a weak point in the eigenvalue part, where Chapter 6 was not complete. If  $ \lambda $ is a double eigenvalue of  $ S $, we can and must find two orthonormal eigenvectors. The other reason is to see how the SVD picks off the largest term  $ \sigma_1 u_1 v_1^T $ before  $ \sigma_2 u_2 v_2^T $. We want to understand the eigenvalues  $ \lambda $ (of  $ S $) and the singular values  $ \sigma $ (of  $ A $) one at a time instead of all at once.

Start with the largest eigenvalue  $ \lambda_{1} $ of S. It solves this problem:

$$\lambda_{1}=\mathrm{maximum ratio}\ \frac{x^{\mathrm{T}}Sx}{x^{\mathrm{T}}x}.\ \mathrm{The winning vector is}\ x=q_{1}\ \mathrm{with}\ Sq_{1}=\lambda_{1}q_{1}.\ (8)$$
Compare with the largest singular value $\sigma_{1}$ of $A$. It solves this problem:
$$\sigma_{1}=\mathrm{maximum ratio}\ \frac{||Ax||}{||x||}.\ \mathrm{The winning vector is}\ x=v_{1}\ \mathrm{with}\ Av_{1}=\sigma_{1}u_{1}.\ (9)$$

This “one at a time approach” applies also to  $ \lambda_{2} $ and  $ \sigma_{2} $. But not all  $ x $'s are allowed:


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$ \lambda_2 = \text{maximum ratio} \frac{x^\text{T} S x}{x^\text{T} x} $ among all  $ x&#x27; $s with  $ q_1^\text{T} x = 0 $.</td><td style='text-align: center; word-wrap: break-word;'>$ x = q_2 $ will win. (10)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \sigma_2 = \text{maximum ratio} \frac{||A x||}{||x||} $ among all  $ x&#x27; $s with  $ v_1^\text{T} x = 0 $.</td><td style='text-align: center; word-wrap: break-word;'>$ x = v_2 $ will win. (11)</td></tr></table>

When  $ S = A^{\mathrm{T}} A $ we find  $ \lambda_{1} = \sigma_{1}^{2} $ and  $ \lambda_{2} = \sigma_{2}^{2} $. Why does this approach succeed?

Start with the ratio  $  r(\boldsymbol{x}) = \boldsymbol{x}^{\mathrm{T}} S \boldsymbol{x} / \boldsymbol{x}^{\mathrm{T}} \boldsymbol{x}  $. This is called the Rayleigh quotient. To maximize  $  r(\boldsymbol{x})  $, set its partial derivatives to zero:  $  \partial r / \partial x_i = 0  $ for  $  i = 1, \ldots, n  $. Those derivatives are messy and here is the result: one vector equation for the winning  $  x  $:

The derivatives of  $  r(x) = \frac{x^{\mathrm{T}} S x}{x^{\mathrm{T}} x}  $ are zero when  $  S x = r(x) x  $.

So the winning x is an eigenvector of S. The maximum ratio  $ r(x) $ is the largest eigenvalue  $ \lambda_1 $ of S. All good. Now turn to A—and notice the connection to  $ S = A^\mathrm{T} A! $

 $$  Maximizing\frac{||A\boldsymbol{x}||}{||\boldsymbol{x}||}also maximizes\left(\frac{||A\boldsymbol{x}||}{||\boldsymbol{x}||}\right)^{2}=\frac{\boldsymbol{x}^{\mathrm{T}}A^{\mathrm{T}}A\boldsymbol{x}}{\boldsymbol{x}^{\mathrm{T}}\boldsymbol{x}}=\frac{\boldsymbol{x}^{\mathrm{T}}S\boldsymbol{x}}{\boldsymbol{x}^{\mathrm{T}}\boldsymbol{x}}. $$ 

So the winning x = v1 in (9) is the same as the top eigenvector q1 of S = A^T A in (8).

Now I have to explain why  $ q_{2} $ and  $ v_{2} $ are the winning vectors in (10) and (11). We know they are orthogonal to  $ q_{1} $ and  $ v_{1} $, so they are allowed in those competitions. These paragraphs can be optional for readers who aim to see the SVD in action (Section 7.3).