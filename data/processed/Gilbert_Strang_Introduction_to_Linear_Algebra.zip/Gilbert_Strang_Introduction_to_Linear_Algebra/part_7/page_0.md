Every symmetric matrix

 $$ \boldsymbol{S}=\boldsymbol{Q}\boldsymbol{\Lambda}\boldsymbol{Q}^{\mathrm{T}}=\lambda_{1}\boldsymbol{q}_{1}\boldsymbol{q}_{1}^{\mathrm{T}}+\cdots+\lambda_{n}\boldsymbol{q}_{n}\boldsymbol{q}_{n}^{\mathrm{T}}. $$ 

Remember the steps to this great result (the spectral theorem).

Section 6.2 Write  $ Ax_i = \lambda_i x_i $ in matrix form  $ AX = X\Lambda $ or  $ A = X\Lambda X^{-1} $

Section 6.4 Orthonormal  $ x_i = q_i $ gives  $ X = Q $  $ S = Q \Lambda Q^{-1} = Q \Lambda Q^{\mathrm{T}} $

 $ Q\Lambda Q^{\mathrm{T}} $ in equation (6) has columns of  $ Q\Lambda $ times rows of  $ Q^{\mathrm{T}} $. Here is a direct proof.

S has correct eigenvectors

Those q's are orthonormal

 $$ \boldsymbol{S}\boldsymbol{q}_{i}=(\lambda_{1}\boldsymbol{q}_{1}\boldsymbol{q}_{1}^{\mathrm{T}}+\cdots+\lambda_{n}\boldsymbol{q}_{n}\boldsymbol{q}_{n}^{\mathrm{T}})\boldsymbol{q}_{i}=\lambda_{i}\boldsymbol{q}_{i}. $$ 

## Complex Eigenvalues of Real Matrices

For any real matrix, $S x = \lambda x$ gives $S \overline{x} = \overline{\lambda} \overline{x}$. For a symmetric matrix, $\lambda$ and $x$ turn out to be real. Those two equations become the same. But a nonsymmetric matrix can easily produce $\lambda$ and $x$ that are complex. Then $A \overline{x} = \overline{\lambda} \overline{x}$ is true but different from $A x = \lambda x$. We get another complex eigenvalue (which is $\overline{\lambda}$) and a new eigenvector (which is $\overline{x}$):

For real matrices, complex  $ \lambda $'s and  $ x $'s come in "conjugate pairs."

 $$ \begin{array}{l}\lambda=a+i b\\\overline{\lambda}=a-i b\end{array}\quad If\quad A\ x=\lambda\ x\quad then\quad A\overline{x}=\overline{\lambda}\overline{x}. $$ 

Example 3  $ A=\begin{bmatrix}\cos\theta-\sin\theta\\ \sin\theta\quad\cos\theta\end{bmatrix} $ has  $ \lambda_{1}=\cos\theta+i\sin\theta $ and  $ \lambda_{2}=\cos\theta-i\sin\theta $.

Those eigenvalues are conjugate to each other. They are  $ \lambda $ and  $ \overline{\lambda} $. The eigenvectors must be x and  $ \overline{x} $, because A is real:

 $$ \begin{aligned}&\mathrm{T h i s~i s~}\lambda\boldsymbol{x}\qquad A\boldsymbol{x}=\begin{bmatrix}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{bmatrix}\begin{bmatrix}1\\ -i\end{bmatrix}=\left(\cos\theta+i\sin\theta\right)\begin{bmatrix}1\\ -i\end{bmatrix}\\&\mathrm{T h i s~i s~}\overline{\lambda}\overline{\boldsymbol{x}}\qquad A\overline{\boldsymbol{x}}=\begin{bmatrix}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{bmatrix}\begin{bmatrix}1\\ i\end{bmatrix}=\left(\cos\theta-i\sin\theta\right)\begin{bmatrix}1\\ i\end{bmatrix}.\end{aligned} $$ 

Those eigenvectors (1, −i) and (1, i) are complex conjugates because A is real.

For this rotation matrix the absolute value is  $ |\lambda| = 1 $, because  $ \cos^2 \theta + \sin^2 \theta = 1 $. This fact  $ |\lambda| = 1 $ holds for the eigenvalues of every orthogonal matrix  $ Q $.

We apologize that a touch of complex numbers slipped in. They are unavoidable even when the matrix is real. Chapter 9 goes beyond complex numbers  $ \lambda $ and complex eigenvectors  $ \pmb{x} $ to complex matrices A. Then you have the whole picture.

We end with two optional discussions.