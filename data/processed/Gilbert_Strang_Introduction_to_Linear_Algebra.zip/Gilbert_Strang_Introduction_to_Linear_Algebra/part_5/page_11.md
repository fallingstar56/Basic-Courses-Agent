9 The determinant of AB is  $ \det A $ times  $ \det B $:  $ |AB| = |A| |B| $.

Product rule

 $$ \left|\begin{matrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|\left|\begin{matrix}{{{p}}}&{{{q}}} \\{{{r}}}&{{{s}}}\end{matrix}\right|=\left|\begin{matrix}{{{a p+b r a q+b s}}} \\{{{c p+d r c q+d s}}}\end{matrix}\right|. $$ 

When the matrix B is  $ A^{-1} $, this rule says that the determinant of  $ A^{-1} $ is 1/det A:

 $$ A^{-1}\quad AA^{-1}=I\quad so\quad(det A)(det A^{-1})=det I=1. $$ 

This product rule is the most intricate so far. Even the 2 by 2 case needs some algebra:

 $$ |A|\left|B\right|=(ad-b\ c)(\mathfrak{p}-qr)=(ap+b\ r)\mathfrak{c}q+ds)-(aq+bs)(cp+dr)=|AB|. $$ 

For the $n$ by $n$ case, here is a snappy proof that $|AB| = |A||B|$. When $|B|$ is not zero, consider the ratio $D(A) = |AB| / |B|$. Check that this ratio $D(A)$ has properties 1, 2, 3. Then $D(A)$ has to be the determinant and we have $|AB| / |B| = |A|$. Good.

Property 1 (Determinant of I) If A = I then the ratio D(A) becomes |B|/|B| = 1.

Property 2 (Sign reversal) When two rows of A are exchanged, so are the same two rows of AB. Therefore |AB| changes sign and so does the ratio |AB|/|B|.

Property 3 (Linearity) When row 1 of A is multiplied by t, so is row 1 of AB. This multiplies the determinant  $ |AB| $ by t. So the ratio  $ |AB|/|B| $ is multiplied by t.

Add row 1 of A to row 1 of  $ A' $. Then row 1 of AB adds to row 1 of  $ A'B $. By rule 3, determinants add. After dividing by  $ |B| $, the ratios add—as desired.

Conclusion This ratio  $ |AB| / |B| $ has the same three properties that define  $ |A| $. Therefore it equals  $ |A| $. This proves the product rule  $ |AB| = |A| |B| $. The case  $ |B| = 0 $ is separate and easy, because  $ AB $ is singular when  $ B $ is singular. Then  $ |AB| = |A| |B| $ is 0 = 0.

10 The transpose  $ A^{T} $ has the same determinant as A.

Transpose

 $$ \left|\begin{matrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|=\left|\begin{matrix}{{{a}}}&{{{c}}} \\{{{b}}}&{{{d}}}\end{matrix}\right|\quad since both sides equal\quad ad-bc. $$ 

The equation  $ |A^{\mathrm{T}}| = |A| $ becomes 0 = 0 when  $ A $ is singular (we know that  $ A^{\mathrm{T}} $ is also singular). Otherwise  $ A $ has the usual factorization  $ PA = LU $. Transposing both sides gives  $ A^{\mathrm{T}}P^{\mathrm{T}} = U^{\mathrm{T}}L^{\mathrm{T}} $. The proof of  $ |A| = |A^{\mathrm{T}}| $ comes by using rule 9 for products:

Compare  $ \det P \det A = \det L \det U $ with  $ \det A^{\mathrm{T}} \det P^{\mathrm{T}} = \det U^{\mathrm{T}} \det L^{\mathrm{T}} $.

First, det $L = \det L^{\mathrm{T}} = 1$ (both have $1's$ on the diagonal). Second, det $U = \det U^{\mathrm{T}}$ (those triangular matrices have the same diagonal). Third, det $P = \det P^{\mathrm{T}}$ (permutations have $P^{\mathrm{T}}P = I$, so $|P^{\mathrm{T}}||P| = 1$ by rule 9; thus $|P|$ and $|P^{\mathrm{T}}|$ both equal 1 or both equal $-1$). So $L, U, P$ have the same determinants as $L^{\mathrm{T}}, U^{\mathrm{T}}, P^{\mathrm{T}}$ and this leaves $\det A = \det A^{\mathrm{T}}$.