Confession Good software like LAPACK, used in good systems like MATLAB and Julia and Python, will not use this Gram-Schmidt code. There is now a better way. "Householder reflections" act on A to produce the upper triangular R. This happens one column at a time in the same way that elimination produces the upper triangular U in LU.

Those reflection matrices  $ I - 2uu^\top $ will be described in Chapter 11 on numerical linear algebra. If  $ A $ is tridiagonal we can simplify even more to use 2 by 2 rotations. The result is always  $ A = QR $ and the MATLAB command to orthogonalize  $ A $ is  $ [Q, R] = \text{qr}(A) $. I believe that Gram-Schmidt is still the good process to understand, even if the reflections or rotations lead to a more perfect  $ Q $.

## ■ REVIEW OF THE KEY IDEAS

1. If the orthonormal vectors  $ q_1, \ldots, q_n $ are the columns of  $ Q $, then  $ q_i^\mathrm{T} q_j = 0 $ and  $ q_i^\mathrm{T} q_i = 1 $ translate into the matrix multiplication  $ Q^\mathrm{T} Q = I $.

2. If Q is square (an orthogonal matrix) then  $ Q^{\mathrm{T}} = Q^{-1} $: transpose = inverse.

3. The length of Qx equals the length of x:  $ \|Qx\| = \|x\| $.

4. The projection onto the column space of $Q$ spanned by the $q$'s is $P = QQ^{\mathrm{T}}$.

5. If $Q$ is square then $P = QQ^{\mathrm{T}} = I$ and every $b = q_{1}(q_{1}^{\mathrm{T}}b) + \cdots + q_{n}(q_{n}^{\mathrm{T}}b)$.

6. Gram-Schmidt produces orthonormal vectors  $ q_{1}, q_{2}, q_{3} $ from independent a, b, c. In matrix form this is the factorization  $ A = QR = (\text{orthogonal } Q) $ (triangular } R  $.

## WORKED EXAMPLES

4.4 A Add two more columns with all entries 1 or -1, so the columns of this 4 by 4 "Hadamard matrix" are orthogonal. How do you turn  $ H_4 $ into an orthogonal matrix Q?

 $$ H_{2}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{-1}}}\end{bmatrix}\qquad H_{4}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{x}}}&{{{x}}} \\{{{1}}}&{{{-1}}}&{{{x}}}&{{{x}}} \\{{{1}}}&{{{1}}}&{{{x}}}&{{{x}}} \\{{{1}}}&{{{-1}}}&{{{x}}}&{{{x}}}\end{bmatrix}\qquad and\qquad Q_{4}=\begin{bmatrix} \\{{{\quad}}} \\{{{\quad}}} \\{{{\quad}}} \\{{{\quad}}} \\\end{bmatrix} $$ 

The block matrix  $ H_8 = \begin{bmatrix} H_4 & H_4 \\ H_4 & -H_4 \end{bmatrix} $ is the next Hadamard matrix with 1's and -1's. What is the product  $ H_8^\mathrm{T} H_8 $?

The projection of  $ \boldsymbol{b} = (6, 0, 0, 2) $ onto the first column of  $ H_4 $ is  $ \boldsymbol{p}_1 = (2, 2, 2, 2) $. The projection onto the second column is  $ \boldsymbol{p}_2 = (1, -1, 1, -1) $. What is the projection  $ \boldsymbol{p}_{1,2} $ of  $ \boldsymbol{b} $ onto the 2-dimensional space spanned by the first two columns?