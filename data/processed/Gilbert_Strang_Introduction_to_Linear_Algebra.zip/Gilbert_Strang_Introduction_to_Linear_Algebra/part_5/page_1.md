Solution  $ H_{4} $ can be built from  $ H_{2} $ just as  $ H_{8} $ is built from  $ H_{4} $

 $$ H_{4}=\begin{bmatrix}{{{H_{2}}}}&{{{H_{2}}}} \\{{{H_{2}}}}&{{{-H_{2}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{-1}}}&{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}&{{{-1}}}&{{{-1}}} \\{{{1}}}&{{{-1}}}&{{{-1}}}&{{{1}}}\end{bmatrix}has orthogonal columns. $$ 

Then  $ Q = H/2 $ has orthonormal columns. Dividing by 2 gives unit vectors in Q. A 5 by 5 Hadamard matrix is impossible because the dot product of columns would have five 1's and/or -1's and could not add to zero.  $ H_8 $ has orthogonal columns of length  $ \sqrt{8} $.

 $$ H_{8}^{\mathrm{T}}H_{8}=\begin{bmatrix}{{{H^{\mathrm{T}}}}}&{{{H^{\mathrm{T}}}}} \\{{{H^{\mathrm{T}}}}}&{{{-H^{\mathrm{T}}}}}\end{bmatrix}\begin{bmatrix}{{{H}}}&{{{H}}} \\{{{H}}}&{{{-H}}}\end{bmatrix}=\begin{bmatrix}{{{2H^{\mathrm{T}}H}}}&{{{0}}} \\{{{0}}}&{{{2H^{\mathrm{T}}H}}}\end{bmatrix}=\begin{bmatrix}{{{8I}}}&{{{0}}} \\{{{0}}}&{{{8I}}}\end{bmatrix}\cdot Q_{8}=\frac{H_{8}}{\sqrt{8}} $$ 

4.4 B What is the key point of orthogonal columns? Answer:  $ A^{T}A $ is diagonal and easy to invert. We can project onto lines and just add. The axes are orthogonal.

Add  $ p' $s     Projection  $ p_{1,2} $ onto a plane equals  $ p_{1} + p_{2} $ onto orthogonal lines.

### Problem Set 4.4

Problems 1–12 are about orthogonal vectors and orthogonal matrices.

1 Are these pairs of vectors orthonormal or only orthogonal or only independent?

 $$ \begin{bmatrix}1\\ 0\end{bmatrix}and\begin{bmatrix}-1\\ 1\end{bmatrix} $$ 

 $$ \left[\begin{array}{c} .6 \\ .8 \end{array} \right]  \quad and \quad \left[\begin{array}{c} .4 \\ -.3 \end{array} \right] $$ 

 $$ \begin{bmatrix}\cos\theta\\ \sin\theta\end{bmatrix}and\begin{bmatrix}-\sin\theta\\ \cos\theta\end{bmatrix}. $$ 

Change the second vector when necessary to produce orthonormal vectors.

2 The vectors  $ (2, 2, -1) $ and  $ (-1, 2, 2) $ are orthogonal. Divide them by their lengths to find orthonormal vectors  $ q_1 $ and  $ q_2 $. Put those into the columns of  $ Q $ and multiply  $ Q^\mathrm{T}Q $ and  $ QQ^\mathrm{T} $.

3 (a) If A has three orthogonal columns each of length 4, what is  $ A^{T}A $?

(b) If A has three orthogonal columns of lengths 1, 2, 3, what is  $ A^{T}A $?

4 Give an example of each of the following:

(a) A matrix Q that has orthonormal columns but  $ QQ^{T} \neq I $.

(b) Two orthogonal vectors that are not linearly independent.

(c) An orthonormal basis for  $ \mathbf{R}^3 $, including the vector  $ \boldsymbol{q}_1 = (1, 1, 1)/\sqrt{3} $.

5 Find two orthogonal vectors in the plane  $ x + y + 2z = 0 $. Make them orthonormal.

6 If  $ Q_{1} $ and  $ Q_{2} $ are orthogonal matrices, show that their product  $ Q_{1}Q_{2} $ is also an orthogonal matrix. (Use  $ Q^{T}Q = I $.)