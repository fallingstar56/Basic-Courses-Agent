From  $ A = \begin{bmatrix} 4 & 1 \\ 2 & 3 \end{bmatrix} $ find  $ A^2 $ and  $ A^{-1} $ and  $ A - \lambda I $ and their determinants. Which two numbers  $ \lambda $ lead to  $ \det(A - \lambda I) = 0 $ ?

24 Elimination reduces A to U. Then A = LU:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{3}}}&{{{3}}}&{{{4}}} \\{{{6}}}&{{{8}}}&{{{7}}} \\{{{-3}}}&{{{5}}}&{{{-9}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{2}}}&{{{1}}}&{{{0}}} \\{{{-1}}}&{{{4}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{3}}}&{{{3}}}&{{{4}}} \\{{{0}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}\end{bmatrix}=\boldsymbol{L}\boldsymbol{U}. $$ 

Find the determinants of L, U, A,  $ U^{-1}L^{-1} $, and  $ U^{-1}L^{-1}A $.

If the $i,j$ entry of $A$ is $i$ times $j$, show that $\det A = 0$. (Exception when $A = [1].$)

If the i, j entry of A is i + j, show that  $ \det A = 0 $. (Exception when n = 1 or 2.)

27 Compute the determinants of these matrices by row operations:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{a}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{b}}} \\{{{c}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{vmatrix}{{{0}}}&{{{a}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{b}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{c}}} \\{{{d}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{vmatrix}\quad and\quad\boldsymbol{C}=\begin{bmatrix}{{{a}}}&{{{a}}}&{{{a}}} \\{{{a}}}&{{{b}}}&{{{b}}} \\{{{a}}}&{{{b}}}&{{{c}}}\end{bmatrix}. $$ 

28 True or false (give a reason if true or a 2 by 2 example if false):

(a) If A is not invertible then AB is not invertible.

(b) The determinant of A is always the product of its pivots.

(c) The determinant of A - B equals  $ \det A - \det B $.

(d) AB and BA have the same determinant.

What is wrong with this proof that projection matrices have $\det P = 1$?

 $$ \boldsymbol{P}=\boldsymbol{A}(\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A})^{-1}\boldsymbol{A}^{\mathrm{T}}\qquad\mathrm{s o}\qquad|\boldsymbol{P}|=|\boldsymbol{A}|\frac{1}{|\boldsymbol{A}^{\mathrm{T}}||\boldsymbol{A}|}|\boldsymbol{A}^{\mathrm{T}}|=1. $$ 

(Calculus question) Show that the partial derivatives of ln(det A) give A−1!

 $$ f(a,b,c,d)=\ln(ad-bc)\qquad leads to\qquad\begin{bmatrix}\partial f/\partial a&\partial f/\partial c\\ \partial f/\partial b&\partial f/\partial d\end{bmatrix}=A^{-1}. $$ 

(MATLAB) The Hilbert matrix  $ \text{hilb}(n) $ has  $ i,j $ entry equal to  $ 1/(i+j-1) $. Print the determinants of  $ \text{hilb}(1) $,  $ \text{hilb}(2) $, ...,  $ \text{hilb}(10) $. Hilbert matrices are hard to work with! What are the pivots of  $ \text{hilb}(5) $?

(MATLAB) What is a typical determinant (experimentally) of  $ \mathbf{rand}(n) $ and  $ \mathbf{randn}(n) $ for  $ n = 50, 100, 200, 400 $? (And what does “Inf” mean in MATLAB?)

(MATLAB) Find the largest determinant of a 6 by 6 matrix of 1's and -1's.

4 If you know that  $ \det A = 6 $, what is the determinant of  $ B $?

 $$ \begin{aligned}From\det A&=\left|\begin{matrix}row1\\ row2\\ row3\end{matrix}\right|=6find\det B=\left|\begin{matrix}row3+row2+row1\\ row2+row1\\ row1\end{matrix}\right|.\end{aligned} $$ 