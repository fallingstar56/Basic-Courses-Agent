(a) Find orthonormal vectors  $ q_{1}, q_{2}, q_{3} $ such that  $ q_{1}, q_{2} $ span the column space of

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{2}}}&{{{-1}}} \\{{{-2}}}&{{{4}}}\end{bmatrix}. $$ 

(b) Which of the four fundamental subspaces contains  $ q_{3} $?

(c) Solve  $ Ax = (1, 2, 7) $ by least squares.

What multiple of  $ a = (4, 5, 2, 2) $ is closest to  $ b = (1, 2, 0, 0) $? Find orthonormal vectors  $ q_1 $ and  $ q_2 $ in the plane of  $ a $ and  $ b $.

Find the projection of b onto the line through a:

Compute the orthonormal vectors  $ q_1 = a / \|a\| $ and  $ q_2 = e / \|e\| $.

 $$ \boldsymbol{a}=\begin{bmatrix}1\\ 1\\ 1\end{bmatrix}\quad and\quad\boldsymbol{b}=\begin{bmatrix}1\\ 3\\ 5\end{bmatrix}\quad and\quad\boldsymbol{p}=?\quad and\quad\boldsymbol{e}=\boldsymbol{b}-\boldsymbol{p}=? $$ 

(Recommended) Find orthogonal vectors A, B, C by Gram-Schmidt from a, b, c:

 $$ \boldsymbol{a}=(1,-1,0,0)\qquad\boldsymbol{b}=(0,1,-1,0)\qquad\boldsymbol{c}=(0,0,1,-1). $$ 

A, B, C and a, b, c are bases for the vectors perpendicular to  $ d = (1, 1, 1, 1) $.

If $A = QR$ then $A^{\mathrm{T}}A = R^{\mathrm{T}}R = \underline{\qquad}$ triangular times $\underline{\qquad}$ triangular. Gram-Schmidt on $A$ corresponds to elimination on $A^{\mathrm{T}}A$. The pivots for $A^{\mathrm{T}}A$ must be the squares of diagonal entries of $R$. Find $Q$ and $R$ by Gram-Schmidt for this $A$:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{-1}}}&{{{1}}} \\{{{2}}}&{{{1}}} \\{{{2}}}&{{{4}}}\end{bmatrix}\qquad and\qquad\boldsymbol{A}^{\mathrm{T}}\boldsymbol{A}=\begin{bmatrix}{{{9}}}&{{{9}}} \\{{{9}}}&{{{18}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{9}}} \\{{{9}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

20 True or false (give an example in either case):

(a)  $ Q^{-1} $ is an orthogonal matrix when Q is an orthogonal matrix.

(b) If Q (3 by 2) has orthonormal columns then  $ \|Qx\| $ always equals  $ \|x\| $.

21 Find an orthonormal basis for the column space of A:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{-2}}} \\{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}} \\{{{1}}}&{{{3}}}\end{bmatrix}\qquad and\qquad\boldsymbol{b}=\begin{bmatrix}{{{-4}}} \\{{{-3}}} \\{{{3}}} \\{{{0}}}\end{bmatrix}. $$ 

Then compute the projection of b onto that column space.