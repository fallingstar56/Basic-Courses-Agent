parallel to u, then  $ u \times F = 0 $—there is no turning. The cross product  $ u \times F $ is the turning force or torque. It points along the turning axis (perpendicular to u and F). Its length  $ \|u\|\|F\|\sin\theta $ measures the “moment” that produces turning.

 $$ \begin{aligned}Triple\ Product&=Determinant=Volume\end{aligned} $$ 

Since  $ u \times v $ is a vector, we can take its dot product with a third vector  $ w $. That produces the triple product  $ (u \times v) \cdot w $. It is called a “scalar” triple product, because it is a number. In fact it is a determinant—it gives the volume of the  $ u, v, w $ box:

Triple product

 $$ \begin{align*}(\boldsymbol{u}\times\boldsymbol{v})\cdot\boldsymbol{w}\ =\begin{vmatrix}w_1&w_2&w_3\\u_1&u_2&u_3\\v_1&v_2&v_3\end{vmatrix}=\begin{vmatrix}u_1&u_2&u_3\\v_1&v_2&v_3\\w_1&w_2&w_3\end{vmatrix}.\end{align*} $$ 

We can put w in the top or bottom row. The two determinants are the same because  $ \underline{\text{____}} $ row exchanges go from one to the other. Notice when this determinant is zero:

 $ (u \times v) \cdot w = 0 $ exactly when the vectors  $ u, v, w $ lie in the same plane.

First reason  $ u \times v $ is perpendicular to that plane so its dot product with w is zero.

Second reason Three vectors in a plane are dependent. The matrix is singular (det = 0).

Third reason Zero volume when the u, v, w box is squashed onto a plane.

It is remarkable that  $ (u \times v) \cdot w $ equals the volume of the box with sides  $ u, v, w $. This 3 by 3 determinant carries tremendous information. Like  $ ad - bc $ for a 2 by 2 matrix, it separates invertible from singular. Chapter 6 will be looking for singular.

## ■ REVIEW OF THE KEY IDEAS

1. Cramer's Rule solves Ax = b by ratios like  $ x_1 = |B_1| / |A| = |ba_2 \cdots a_n| / |A| $.

2. When C is the cofactor matrix for A, the inverse is  $ A^{-1} = C^{T} / \det A $.

3. The volume of a box is  $ |det A| $, when the box edges are the rows of A.

4. Area and volume are needed to change variables in double and triple integrals.

5. In  $ R^{3} $, the cross product  $ u \times v $ is perpendicular to u and v. Notice  $ i \times j = k $.