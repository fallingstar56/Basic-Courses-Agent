Combining multiplication and addition, we get any linear combination in one row. Rule 2 for row exchanges can put that row into the first row and back again.

This rule does not mean that  $ \det 2I = 2 \det I $. To obtain 2I we have to multiply both rows by 2, and the factor 2 comes out both times:

 $$ \begin{vmatrix}{{{2}}}&{{{0}}} \\{{{0}}}&{{{2}}}\end{vmatrix}=2^{2}=4\qquad and\qquad\begin{vmatrix}{{{t}}}&{{{0}}} \\{{{0}}}&{{{t}}}\end{vmatrix}=t^{2}. $$ 

This is just like area and volume. Expand a rectangle by 2 and its area increases by 4. Expand an n-dimensional box by t and its volume increases by  $ t^n $. The connection is no accident—we will see how determinants equal volumes.

Pay special attention to rules 1–3. They completely determine the number det A. We could stop here to find a formula for n by n determinants (a little complicated). We prefer to go gradually, because rules 4 – 10 make determinants much easier to work with.

4 If two rows of A are equal, then  $ \det A = 0 $.

Equal rows

 $$  Check2by2:\quad\left|\begin{matrix}{{{a}}}&{{{b}}} \\{{{a}}}&{{{b}}}\end{matrix}\right|=0. $$ 

Rule 4 follows from rule 2. (Remember we must use the rules and not the 2 by 2 formula.) Exchange the two equal rows. The determinant $D$ is supposed to change sign. But also $D$ has to stay the same, because the matrix is not changed. The only number with $-D = D$ is $D = 0$—this must be the determinant. (Note: In Boolean algebra the reasoning fails, because $-1 = 1$. Then $D$ is defined by rules 1, 3, 4.)

A matrix with two equal rows has no inverse. Rule 4 makes  $ \det A = 0 $. But matrices can be singular and determinants can be zero without having equal rows! Rule 5 will be the key. We can do row operations (like elimination) without changing  $ \det A $.

5 Subtracting a multiple of one row from another row leaves det A unchanged.

 $ \ell $ times row 1 from row 2

 $$ \begin{align*}\left|\begin{array}{cc}a&b\\c-\ell a&d-\ell b\\\end{array}\right|=\left|\begin{array}{cc}a&b\\c&d\\\end{array}\right|.\end{align*} $$ 

Rule 3 (linearity) splits the left side into the right side plus another term  $ -\ell\big|_{\text{ab}}^{\text{ab}} $. This extra term is zero by rule 4: equal rows. Therefore rule 5 is correct (not just 2 by 2).

Conclusion The determinant is not changed by the usual elimination steps from A to U. Thus det A equals det U. If we can find determinants of triangular matrices U, we can find determinants of all matrices A. Every row exchange reverses the sign, so always  $ \det A = \pm \det U $. Rule 5 has narrowed the problem to triangular matrices.

6 A matrix with a row of zeros has  $ \det A = 0 $

Row of zeros

 $$ \left|\begin{matrix}{{{0}}}&{{{0}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|=0\qquad and\qquad\left|\begin{matrix}{{{a}}}&{{{b}}} \\{{{0}}}&{{{0}}}\end{matrix}\right|=0. $$ 

For an easy proof, add some other row to the zero row. The determinant is not changed (rule 5). But the matrix now has two equal rows. So  $ \det A = 0 $ by rule 4.