Property 3 The cross product of any vector with itself (two equal rows) is  $ u \times u = 0 $.

When u and v are parallel, the cross product is zero. When u and v are perpendicular, the dot product is zero. One involves  $ \sin\theta $ and the other involves  $ \cos\theta $:

 $$ \left\| \mathbf{u} \times \mathbf{v} \right\|= \left\| \mathbf{u} \right\| \left\| \mathbf{v} \right\| \left\| \sin \theta \right\| \quad and \quad \left| \mathbf{u}\cdot\mathbf{v} \right|=\left\| \mathbf{u} \right\| \left\| \mathbf{v} \right\| \left\| \cos \theta \right\|. $$ 

Example 7  $ u = (3, 2, 0) $ and  $ v = (1, 4, 0) $ are in the xy plane,  $ u \times v $ goes up the z axis:

 $$ \boldsymbol{u}\times\boldsymbol{v}=\left|\begin{matrix}{{{i}}}&{{{j}}}&{{{k}}} \\{{{3}}}&{{{2}}}&{{{0}}} \\{{{1}}}&{{{4}}}&{{{0}}}\end{matrix}\right|=10k.\quad\mathrm{T h e~c r o s s~p r o d u c t~i s~}\boldsymbol{u}\times\boldsymbol{v}=(\mathbf{0},\mathbf{0},\mathbf{10}). $$ 

The length of  $ u \times v $ equals the area of the parallelogram with sides u and v. This will be important: In this example the area is 10.

Example 8 The cross product of  $ u = (1, 1, 1) $ and  $ v = (1, 1, 2) $ is  $ (1, -1, 0) $:

 $$ \left|\begin{matrix}{{{i}}}&{{{j}}}&{{{k}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}} \\\end{matrix}\right|=i\left|\begin{matrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}} \\\end{matrix}\right|-j\left|\begin{matrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}} \\\end{matrix}\right|+k\left|\begin{matrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}} \\\end{matrix}\right|=i-j. $$ 

This vector (1, −1, 0) is perpendicular to (1, 1, 1) and (1, 1, 2) as predicted. Area = √2.

Example 9 The cross product of  $ i = (1, 0, 0) $ and  $ j = (0, 1, 0) $ obeys the right hand rule. That cross product  $ k = i \times j $ goes up not down:

<div style="text-align: center;"><img src="imgs/img_in_image_box_257_717_832_856.jpg" alt="Image" width="53%" /></div>


Thus  $ i \times j = k $. The right hand rule also gives  $ j \times k = i $ and  $ k \times i = j $. Note the cyclic order. In the opposite order (anti-cyclic) the thumb is reversed and the cross product goes the other way:  $ k \times j = -i $ and  $ i \times k = -j $ and  $ j \times i = -k $. You see the three plus signs and three minus signs from a 3 by 3 determinant.

The definition of  $ u \times v $ can be based on vectors instead of their components:

DEFINITION The cross product is a vector with length  $ \|u\|\|v\|\|\sin\theta\| $. Its direction is perpendicular to u and v. It points “up” or “down” by the right hand rule.

This definition appeals to physicists, who hate to choose axes and coordinates. They see  $ (u_{1}, u_{2}, u_{3}) $ as the position of a mass and  $ (F_{x}, F_{y}, F_{z}) $ as a force acting on it. If F is