17 A box has edges from  $ (0,0,0) $ to  $ (3,1,1) $ and  $ (1,3,1) $ and  $ (1,1,3) $. Find its volume. Also find the area of each parallelogram face using  $ \|u \times v\| $.

(a) The corners of a triangle are  $ (2, 1) $ and  $ (3, 4) $ and  $ (0, 5) $. What is the area?

(b) Add a corner at  $ (-1,0) $ to make a lopsided region (four sides). Find the area.

The parallelogram with sides  $ (2, 1) $ and  $ (2, 3) $ has the same area as the parallelogram with sides  $ (2, 2) $ and  $ (1, 3) $. Find those areas from 2 by 2 determinants and say why they must be equal. (I can’t see why from a picture. Please write to me if you do.)

20 The Hadamard matrix H has orthogonal rows. The box is a hypercube!

 $$ \begin{aligned}What is\quad&\left|H\right|=\left|\begin{matrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{-1}}}&{{{-1}}} \\{{{1}}}&{{{-1}}}&{{{-1}}}&{{{1}}} \\{{{1}}}&{{{-1}}}&{{{1}}}&{{{-1}}} \\\end{matrix}\right|=volume of a hypercube in\mathbf{R}^{4}？\end{aligned} $$ 

21 If the columns of a 4 by 4 matrix have lengths  $ L_{1}, L_{2}, L_{3}, L_{4} $, what is the largest possible value for the determinant (based on volume)? If all entries of the matrix are 1 or -1, what are those lengths and the maximum determinant?

22 Show by a picture how a rectangle with area  $ x_{1}y_{2} $ minus a rectangle with area  $ x_{2}y_{1} $ produces the same area as our parallelogram.

23 When the edge vectors $a, b, c$ are perpendicular, the volume of the box is $\|a\|$ times $\|b\|$ times $\|c\|$. The matrix $A^{\mathrm{T}} A$ is ___. Find $\det A^{\mathrm{T}} A$ and $\det A$.

24 The box with edges $i$ and $j$ and $w = 2i + 3j + 4k$ has height ___. What is the volume? What is the matrix with this determinant? What is $i \times j$ and what is its dot product with $w$?

25 An $n$-dimensional cube has how many corners? How many edges? How many $(n-1)$-dimensional faces? The cube in $\mathbf{R}^n$ whose edges are the rows of $2I$ has volume ___. A hypercube computer has parallel processors at the corners with connections along the edges.

26 The triangle with corners  $ (0,0),(1,0),(0,1) $ has area  $ \frac{1}{2} $. The pyramid in  $ R^{3} $ with four corners  $ (0,0,0),(1,0,0),(0,1,0),(0,0,1) $ has volume ___. What is the volume of a pyramid in  $ R^{4} $ with five corners at  $ (0,0,0,0) $ and the rows of  $ I $?

Problems 27–30 are about areas dA and volumes dV in calculus.

27 Polar coordinates satisfy  $ x = r \cos \theta $ and  $ y = r \sin \theta $. Polar area is  $ J \, dr \, d\theta $:

 $$ J=\left|\begin{matrix}\partial x/\partial r&\partial x/\partial\theta\\ \partial y/\partial r&\partial y/\partial\theta\end{matrix}\right|=\left|\begin{matrix}\cos\theta&-r\sin\theta\\ \sin\theta&r\cos\theta\end{matrix}\right|. $$ 

The two columns are orthogonal. Their lengths are ___. Thus J = ___.