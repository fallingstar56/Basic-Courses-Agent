Example 7 This is the same matrix, except the first entry (upper left) is now 1:

 $$ \begin{align*}B_4=\begin{bmatrix}1&-1\\-1&2&-1\\&-1&2&-1\\&&-1&2\end{bmatrix}.\end{align*} $$ 

All pivots of this matrix turn out to be 1. So its determinant is 1. How does that come from cofactors? Expanding on row 1, the cofactors all agree with Example 6. Just change  $ a_{11} = 2 $ to  $ b_{11} = 1 $:

 $$ \det B_{4}=D_{3}-D_{2}\qquad instead of\qquad\det A_{4}=2D_{3}-D_{2}. $$ 

The determinant of B4 is 4 - 3 = 1. The determinant of every Bn is n - (n - 1) = 1.

If you also change the last 2 into 1, why is  $ \det = 0 $?

## ■ REVIEW OF THE KEY IDEAS

1. With no row exchanges,  $ \det A = (product of pivots) $. In the upper left corner of A,  $ \det A_k = (product of the first k pivots) $.

2. Every term in the big formula (8) uses each row and column once. Half of the n! terms have plus signs (when  $ \det P = +1 $) and half have minus signs.

3. The cofactor  $ C_{ij} $ is  $ (-1)^{i+j} $ times the smaller determinant that omits row i and column j (because  $ a_{ij} $ uses that row and column).

4. The determinant is the dot product of any row of A with its row of cofactors. When a row of A has a lot of zeros, we only need a few cofactors.

## WORKED EXAMPLES

5.2 A A Hessenberg matrix is a triangular matrix with one extra diagonal. Use cofactors of row 1 to show that the 4 by 4 determinant satisfies Fibonacci's rule  $ |H_4| = |H_3| + |H_2| $. The same rule will continue for all sizes,  $ |H_n| = |H_{n-1}| + |H_{n-2}| $. Which Fibonacci number is  $ |H_n| $?

 $$ H_{2}=\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{1}}}&{{{2}}}\end{bmatrix}\qquad\quad H_{3}=\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}}\end{bmatrix}\qquad\quad H_{4}=\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{2}}}\end{bmatrix} $$ 