 $$ (\det P)(\det A)=(\det L)(\det U)\quad gives\quad\det A=\pm(d_{1}d_{2}\cdots d_{n}). $$ 

Example 1 A row exchange produces pivots 4, 2, 1 and that important minus sign:

 $$ A=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{2}}}&{{{3}}} \\{{{4}}}&{{{5}}}&{{{6}}}\end{bmatrix}\qquad PA=\begin{bmatrix}{{{4}}}&{{{5}}}&{{{6}}} \\{{{0}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\qquad\det A=-(4)(2)(1)=-8. $$ 

The odd number of row exchanges (namely one exchange) means that det P = −1.

The next example has no row exchanges. It may be the first matrix we factored into  $ L \cup $ (when it was 3 by 3). What is remarkable is that we can go directly to n by n. Pivots give the determinant. We will also see how determinants give the pivots.

Example 2 The first pivots of this tridiagonal matrix $A$ are $2, \frac{3}{2}, \frac{4}{3}$. The next are $\frac{5}{4}$ and $\frac{6}{5}$ and eventually $\frac{n+1}{n}$. Factoring this $n$ by $n$ matrix reveals its determinant:

 $$ \begin{aligned}\begin{bmatrix}2&-1&&&&\\-1&2&-1&&&\\&-1&2&\cdot&\\&&\cdot&,-1&\\&&&-1&2\end{bmatrix}&=\begin{bmatrix}1&&&&\\-\frac{1}{2}&1&&&\\&-\frac{2}{3}&1&&\\&&\cdot&\cdot&\\&&&\frac{n-1}{n}&1\end{bmatrix}\begin{bmatrix}2&-1&&&\\&\frac{3}{2}&-1&&\\&\frac{4}{3}&-1&\cdot&\\&&\cdot&\cdot&\\&&&\frac{n+1}{n}\end{bmatrix}\end{aligned} $$ 

The pivots are on the diagonal of $U$ (the last matrix). When $2$ and $\frac{3}{2}$ and $\frac{4}{3}$ and $\frac{5}{4}$ are multiplied, the fractions cancel. The determinant of the $4$ by $4$ matrix is $5$. The $3$ by $3$ determinant is $4$. The $n$ by $n$ determinant is $n+1$:

 $$ -1,2,-1 matrix\qquad\det A=\left(2\right)\left(\frac{3}{2}\right)\left(\frac{4}{3}\right)\cdots\left(\frac{n+1}{n}\right)=n+1. $$ 

Important point: The first pivots depend only on the upper left corner of the original matrix A. This is a rule for all matrices without row exchanges.

The first $k$ pivots come from the $k$ by $k$ matrix $A_k$ in the top left corner of $A$. The determinant of that corner submatrix $A_k$ is $d_1 d_2 \cdots d_k$ (first $k$ pivots).

The 1 by 1 matrix  $ A_1 $ contains the very first pivot  $ d_1 $. This is det  $ A_1 $. The 2 by 2 matrix in the corner has det  $ A_2 = d_1 d_2 $. Eventually the n by n determinant multiplies all n pivots.

Elimination deals with the matrix  $ A_k $ in the upper left corner while starting on the whole matrix. We assume no row exchanges—then  $ A = LU $ and  $ A_k = L_kU_k $. Dividing one determinant by the previous determinant ( $ \det A_k $ divided by  $ \det A_{k-1} $) cancels everything but the latest pivot  $ d_k $. Each pivot is a ratio of determinants:

Pivots from

determinants

 $$ \mathrm{The~k~th~piv~o~t~i~s~}d_{k}=\frac{d_{1}d_{2}\cdots d_{k}}{d_{1}d_{2}\cdots d_{k-1}}=\frac{\det A_{k}}{\det A_{k-1}}. $$ 

We don’t need row exchanges when all the upper left submatrices have det A k ≠ 0.