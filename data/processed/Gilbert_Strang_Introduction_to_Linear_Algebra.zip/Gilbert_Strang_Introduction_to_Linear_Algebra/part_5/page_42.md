The cofactors along the other rows of A, divided by det A, give the other columns of A−1:

 $$ \boldsymbol{A}^{-1}=\frac{\boldsymbol{C}^{\mathrm{T}}}{\det\boldsymbol{A}}=\frac{1}{2}\left[\begin{array}{rrr}{{{-18}}}&{{{18}}}&{{{4}}} \\{{{10}}}&{{{-10}}}&{{{-2}}} \\{{{-11}}}&{{{12}}}&{{{2}}}\end{array}\right].\quad\text{Multiply to check}\quad\boldsymbol{A}\boldsymbol{A}^{-1}=\boldsymbol{I} $$ 

The box from the columns of A has volume = det A = 2. The box from the rows also has volume 2, since  $ |A^{\mathrm{T}}| = |A| $. The box from the rows of  $ A^{-1} $ has volume  $ 1/|A| = \frac{1}{2} $.

### Problem Set 5.3

 $$ \left(\begin{array}{l}a_{11}a_{12}\\ a_{21}a_{22}\end{array}\right)\left(\begin{array}{l}1\quad m\\ 0\quad1\end{array}\right) $$ 

## Problems 1–5 are about Cramer's Rule for  $ x = A^{-1}b $

 $$ [\begin{bmatrix}a_{11}\\ a_{21}\end{bmatrix}_{2}=\begin{bmatrix}a_{11}\\ a_{21}\end{bmatrix}_{2} $$ 

1 Solve these linear equations by Cramer's Rule  $ x_{j} = \det B_{j} / \det A $:

 $$ \begin{aligned}2x_{1}+5x_{2}&=1\\x_{1}+4x_{2}&=2\end{aligned} $$ 

(b)

 $$ m\left[a_{1}\right]+\left[a_{2}\right]=m a_{1}+a_{2} $$ 

 $$ \begin{aligned}2x_{1}+x_{2}&=1\\x_{1}+2x_{2}+x_{3}&=0\\x_{2}+2x_{3}&=0.\end{aligned} $$ 

 $$ \begin{bmatrix} a_{11} & m a_{11} + a_{12} \\ a_{21} & m a_{21} + a_{22} \end{bmatrix} $$ 

2 Use Cramer's Rule to solve for y (only). Call the 3 by 3 determinant D:

(a)  $ ax + by = 1 $

 $ cx + dy = 0 $

 $$ \begin{array}{l}ax+by+cz=1\\dx+ey+fz=0\\gx+hy+iz=0.\end{array} $$ 

 $$ \left(\begin{array}{c c}a_{11}&a_{12}\\ a_{21}&a_{22}\end{array}\right)\left(\begin{array}{c}1\\ m\end{array}\right)^{G}= $$ 

3 Cramer's Rule breaks down when  $ \det A = 0 $. Example (a) has no solution while (b) has infinitely many. What are the ratios  $ x_{j} = \det B_{j} / \det A $ in these two cases?

 $$ \begin{array}{l} a_{11} + a_{12} m \quad a_{12} \\ a_{21} + m_{22} \quad a_{22} \end{array} $$ 

(a)  $ 2x_{1} + 3x_{2} = 1 $ (parallel lines)

 $ 4x_{1} + 6x_{2} = 1 $

 $ 2x_{1} + 3x_{2} = 1 $ (same line)

 $ 4x_{1} + 6x_{2} = 2 $

4 Quick proof of Cramer's rule. The determinant is a linear function of column 1. It is zero if two columns are equal. When  $ b = Ax = x_1a_1 + x_2a_2 + x_3a_3 $ goes into the first column of A, the determinant of this matrix  $ B_1 $ is

 $$ \begin{vmatrix}b&a_{2}&a_{3}\end{vmatrix}=\left|x_{1}a_{1}+x_{2}a_{2}+x_{3}a_{3}\quad a_{2}\quad a_{3}\right|=x_{1}\left|a_{1}\quad a_{2}\quad a_{3}\right|=x_{1}\det A. $$ 

(a) What formula for  $ x_{1} $ comes from left side = right side?

(b) What steps lead to the middle equation?

5 If the right side $b$ is the first column of $A$, solve the 3 by 3 system $Ax = b$. How does each determinant in Cramer's Rule lead to this solution $x?$