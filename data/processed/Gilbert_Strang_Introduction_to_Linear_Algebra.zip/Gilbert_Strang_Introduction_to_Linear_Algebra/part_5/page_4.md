22 Find orthogonal vectors A, B, C by Gram-Schmidt from

 $$ \boldsymbol{a}=\begin{bmatrix}1\\ 1\\ 2\end{bmatrix}\quad and\quad\boldsymbol{b}=\begin{bmatrix}1\\ -1\\ 0\end{bmatrix}\quad and\quad\boldsymbol{c}=\begin{bmatrix}1\\ 0\\ 4\end{bmatrix}. $$ 

23 Find  $ q_{1}, q_{2}, q_{3} $ (orthonormal) as combinations of a, b, c (independent columns). Then write A as QR:

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{5}}} \\{{{0}}}&{{{3}}}&{{{6}}}\end{bmatrix}. $$ 

(a) Find a basis for the subspace S in  $ \mathbb{R}^4 $ spanned by all solutions of

 $$ x_{1}+x_{2}+x_{3}-x_{4}=0. $$ 

(b) Find a basis for the orthogonal complement  $ S^{\perp} $

(c) Find  $ b_{1} $ in  $ S $ and  $ b_{2} $ in  $ S^{\perp} $ so that  $ b_{1} + b_{2} = b = (1, 1, 1, 1) $.

25 If ad - bc > 0, the entries in A = QR are

 $$ \begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}=\frac{\begin{bmatrix}{{{a}}}&{{{-c}}} \\{{{c}}}&{{{a}}}\end{bmatrix}}{\sqrt{a^{2}+c^{2}}}\frac{\begin{bmatrix}{{{a^{2}+c^{2}}}}&{{{ab+cd}}} \\{{{0}}}&{{{ad-bc}}}\end{bmatrix}}{\sqrt{a^{2}+c^{2}}}. $$ 

Write  $ A = QR $ when  $ a, b, c, d = 2, 1, 1, 1 $ and also 1, 1, 1, 1. Which entry of  $ R $ becomes zero when the columns are dependent and Gram-Schmidt breaks down?

Problems 26–29 use the QR code in equation (11). It executes Gram-Schmidt.

26 Show why C (found via C* in the steps after (11)) is equal to C in equation (8).

Equation (8) subtracts from c its components along A and B. Why not subtract the components along a and along b?

28 Where are the  $ mn^{2} $ multiplications in equation (11)?

29 Apply the MATLAB qr code to  $ a = (2, 2, -1) $,  $ b = (0, -3, 3) $,  $ c = (1, 0, 0) $. What are the  $ q' $s?

Problems 30–35 involve orthogonal matrices that are special.

30 The first four wavelets are in the columns of this wavelet matrix W:

 $$ W=\frac{1}{2}\begin{bmatrix}{{{1}}}&{{{1}}}&{{{\sqrt{2}}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{-\sqrt{2}}}}&{{{0}}} \\{{{1}}}&{{{-1}}}&{{{0}}}&{{{\sqrt{2}}}} \\{{{1}}}&{{{-1}}}&{{{0}}}&{{{-\sqrt{2}}}}\end{bmatrix}. $$ 

What is special about the columns? Find the inverse wavelet transform  $ W^{-1} $.