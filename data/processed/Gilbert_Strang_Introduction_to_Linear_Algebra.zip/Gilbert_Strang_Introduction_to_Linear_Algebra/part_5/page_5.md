(a) Choose c so that Q is an orthogonal matrix:

 $$ Q=c\begin{bmatrix}1&-1&-1&-1\\ -1&1&-1&-1\\ -1&-1&1&-1\\ -1&-1&-1&1\end{bmatrix}. $$ 

Project  $ b = (1, 1, 1, 1) $ onto the first column. Then project  $ b $ onto the plane of the first two columns.

If  $ u $ is a unit vector, then  $ Q = I - 2uu^\mathrm{T} $ is a reflection matrix (Example 3). Find  $ Q_1 $ from  $ u = (0, 1) $ and  $ Q_2 $ from  $ u = (0, \sqrt{2}/2, \sqrt{2}/2) $. Draw the reflections when  $ Q_1 $ and  $ Q_2 $ multiply the vectors  $ (1, 2) $ and  $ (1, 1, 1) $.

Find all matrices that are both orthogonal and lower triangular.

 $ Q = I - 2uu^{\mathrm{T}} $ is a reflection matrix when  $ u^{\mathrm{T}}u = 1 $. Two reflections give  $ Q^{2} = I $.

(a) Show that  $ Qu = -u $. The mirror is perpendicular to u.

(b) Find  $ Qv $ when  $ u^{\mathrm{T}}v = 0 $. The mirror contains  $ v $. It reflects to itself.

## Challenge Problems

(MATLAB) Factor [Q, R] = qr(A) for  $ A = \text{eye}(4) - \text{diag}([1\ 1\ 1], -1) $. You are orthogonalizing the columns  $ (1, -1, 0, 0) $ and  $ (0, 1, -1, 0) $ and  $ (0, 0, 1, -1) $ and  $ (0, 0, 0, 1) $ of A. Can you scale the orthogonal columns of Q to get nice integer components?

If A is m by n with rank n,  $ \mathbf{q}\mathbf{r}(A) $ produces a square Q and zeros below R:

The factors from MATLAB are  $ (m \text{ by } m)(m \text{ by } n) $

 $$ A=\begin{bmatrix}Q_{1}&Q_{2}\end{bmatrix}\begin{bmatrix}R\\ 0\end{bmatrix}. $$ 

The $n$ columns of $Q_{1}$ are an orthonormal basis for which fundamental subspace? The $m-n$ columns of $Q_{2}$ are an orthonormal basis for which fundamental subspace?

We know that  $ P = QQ^{\mathrm{T}} $ is the projection onto the column space of  $ Q(m \text{ by } n) $. Now add another column  $ a $ to produce  $ A = [Q \quad a] $. Gram-Schmidt replaces  $ a $ by what vector  $ q $? Start with  $ a $, subtract ___, divide by ___ to find  $ q $.