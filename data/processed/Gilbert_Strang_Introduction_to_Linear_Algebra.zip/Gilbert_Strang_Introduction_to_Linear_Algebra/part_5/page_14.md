6 Show how Rule 6 (determinant = 0 if a row is all zero) comes from Rule 3.

7 Find the determinants of rotations and reflections:

 $$ Q=\begin{bmatrix}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{bmatrix}\quad and\quad Q=\begin{bmatrix}1-2\cos^{2}\theta&-2\cos\theta\sin\theta\\ -2\cos\theta\sin\theta&1-2\sin^{2}\theta\end{bmatrix}. $$ 

8 Prove that every orthogonal matrix  $ (Q^{\mathrm{T}}Q = I) $ has determinant 1 or -1.

(a) Use the product rule  $ |AB| = |A| |B| $ and the transpose rule  $ |Q| = |Q^{\mathrm{T}}| $.

(b) Use only the product rule. If  $ |\det Q| > 1 $ then  $ \det Q^n = (\det Q)^n $ blows up. How do you know this can't happen to  $ Q^n $?

9 Do these matrices have determinant 0, 1, 2, or 3?

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}\end{bmatrix}\quad\boldsymbol{B}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}}\end{bmatrix}\quad\boldsymbol{C}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix}. $$ 

10 If the entries in every row of A add to zero, solve  $ Ax = 0 $ to prove  $ \det A = 0 $. If those entries add to one, show that  $ \det(A - I) = 0 $. Does this mean  $ \det A = 1 $?

Suppose that $CD = -DC$ and find the flaw in this reasoning: Taking determinants gives $|C||D| = -|D||C|$. Therefore $|C| = 0$ or $|D| = 0$. One or both of the matrices must be singular. (That is not true.)

12 The inverse of a 2 by 2 matrix seems to have determinant = 1:

 $$ \det A^{-1}=\det\frac{1}{ad-bc}\begin{bmatrix}d&-b\\ -c&a\end{bmatrix}=\frac{ad-bc}{ad-bc}=1. $$ 

What is wrong with this calculation? What is the correct det  $ A^{-1} $?

Questions 13–27 use the rules to compute specific determinants.

13 Reduce A to U and find  $ \det A = \text{product of the pivots} $:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{3}}}\end{bmatrix}\quad\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{2}}}&{{{3}}} \\{{{3}}}&{{{3}}}&{{{3}}}\end{bmatrix}. $$ 

14 By applying row operations to produce an upper triangular U, compute

 $$ \det\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}}&{{{0}}} \\{{{2}}}&{{{6}}}&{{{6}}}&{{{1}}} \\{{{-1}}}&{{{0}}}&{{{0}}}&{{{3}}} \\{{{0}}}&{{{2}}}&{{{0}}}&{{{7}}}\end{bmatrix}\qquad and\qquad\det\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}. $$ 