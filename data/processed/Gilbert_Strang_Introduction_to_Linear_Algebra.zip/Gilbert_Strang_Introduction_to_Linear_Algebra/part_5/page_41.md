## WORKED EXAMPLES

5.3 A If A is singular, the equation  $ AC^{\mathrm{T}} = (\det A)I $ becomes  $ AC^{\mathrm{T}} = zero $ matrix. Then each column of  $ C^{\mathrm{T}} $ is in the nullspace of A. Those columns contain cofactors along rows of A. So the cofactors quickly find the nullspace for a 3 by 3 matrix of rank 2. My apologies that this comes so late!

Solve Ax = 0 by x = cofactors along a row, for these singular matrices of rank 2:

Cofactors give

nullspace

 $$ \boldsymbol{A}=\left[\begin{array}{lll}{{{1}}}&{{{4}}}&{{{7}}} \\{{{2}}}&{{{3}}}&{{{9}}} \\{{{2}}}&{{{2}}}&{{{8}}}\end{array}\right]\quad\boldsymbol{A}=\left[\begin{array}{lll}{{{1}}}&{{{1}}}&{{{2}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{array}\right] $$ 

Solution The first matrix has these cofactors along its top row (note each minus sign):

 $$ \left|\begin{array}{cc}{{{3}}}&{{{9}}} \\{{{2}}}&{{{8}}} \\\end{array}\right|=6\quad\left|\begin{array}{cc}{{{2}}}&{{{9}}} \\{{{2}}}&{{{8}}} \\\end{array}\right|=2\quad\left|\begin{array}{cc}{{{2}}}&{{{3}}} \\{{{2}}}&{{{2}}} \\\end{array}\right|=-2 $$ 

Then  $ \boldsymbol{x} = (6, 2, -2) $ solves  $ A\boldsymbol{x} = \boldsymbol{0} $. The cofactors along the second row are  $ (-18, -6, 6) $ which is just  $ -3\boldsymbol{x} $. This is also in the one-dimensional nullspace of A.

The second matrix has zero cofactors along its first row. The nullvector  $ \boldsymbol{x} = (0, 0, 0) $ is not interesting. The cofactors of row 2 give  $ \boldsymbol{x} = (1, -1, 0) $ which solves  $ A\boldsymbol{x} = \boldsymbol{0} $.

Every n by n matrix of rank n - 1 has at least one nonzero cofactor by Problem 3.3.12. But for rank n - 2, all cofactors are zero and we only find x = 0.

5.3 B Use Cramer's Rule with ratios  $ \det B_j/\det A $ to solve  $ Ax = b $. Also find the inverse matrix  $ A^{-1} = C^\mathrm{T}/\det A $. For this  $ b = (0,0,1) $ the solution  $ x $ is column 3 of  $ A^{-1} $! Which cofactors are involved in computing that column  $ x = (x,y,z) $?

Column 3 of  $ A^{-1} $

 $$ \left[\begin{array}{l l l}{{{2}}}&{{{6}}}&{{{2}}} \\{{{1}}}&{{{4}}}&{{{2}}} \\{{{5}}}&{{{9}}}&{{{0}}}\end{array}\right]\left[\begin{array}{l}{{{x}}} \\{{{y}}} \\{{{z}}}\end{array}\right]=\left[\begin{array}{l}{{{0}}} \\{{{0}}} \\{{{1}}}\end{array}\right]. $$ 

Find the volumes of two boxes: edges are columns of A and edges are rows of A−1.

Solution The determinants of the  $ B_{j} $ (with right side b placed in column j) are

 $$ \left|\boldsymbol{B}_{1}\right|=\left|\begin{array}{ccc}{{{\mathbf{0}}}}&{{{6}}}&{{{2}}} \\{{{\mathbf{0}}}}&{{{4}}}&{{{2}}} \\{{{\mathbf{1}}}}&{{{9}}}&{{{0}}} \\\end{array}\right|=4\quad\left|\boldsymbol{B}_{2}\right|=\left|\begin{array}{ccc}{{{2}}}&{{{\mathbf{0}}}}&{{{2}}} \\{{{1}}}&{{{\mathbf{0}}}}&{{{2}}} \\{{{5}}}&{{{\mathbf{1}}}}&{{{0}}} \\\end{array}\right|=-2\quad\left|\boldsymbol{B}_{3}\right|=\left|\begin{array}{ccc}{{{2}}}&{{{6}}}&{{{\mathbf{0}}}} \\{{{1}}}&{{{4}}}&{{{\mathbf{0}}}} \\{{{5}}}&{{{9}}}&{{{\mathbf{1}}}} \\\end{array}\right|=2. $$ 

Those are cofactors C31, C32, C33 of row 3. Their dot product with row 3 is det A = 2:

 $$ \det A=a_{31}C_{31}+a_{32}C_{32}+a_{33}C_{33}=\left(5,9,0\right)\cdot\left(4,-2,2\right)=2. $$ 

The three ratios  $ \det B_j / \det A $ give the three components of  $ \boldsymbol{x} = (2, -1, 1) $. This  $ \boldsymbol{x} $ is the third column of  $ A^{-1} $ because  $ \boldsymbol{b} = (0, 0, 1) $ is the third column of  $ I $.