Example 3 The “sum matrix” A has determinant 1. Then  $ A^{-1} $ contains cofactors:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix}\quad has inverse\quad\boldsymbol{A}^{-1}=\frac{\boldsymbol{C}^{\mathrm{T}}}{1}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{1}}}\end{bmatrix}. $$ 

Cross out row 1 and column 1 of A to see the 3 by 3 cofactor  $ C_{11} = 1 $. Now cross out row 1 and column 2 for  $ C_{12} $. The 3 by 3 submatrix is still triangular with determinant 1. But the cofactor  $ C_{12} $ is -1 because of the sign  $ (-1)^{1+2} $. This number -1 goes into the  $ (2,1) $ entry of  $ A^{-1} $—don't forget to transpose C.

The inverse of a triangular matrix is triangular. Cofactors give a reason why.

Example 4 If all cofactors are nonzero, is A sure to be invertible? No way.

Area of a Triangle

Everybody knows the area of a rectangle—base times height. The area of a triangle is half the base times the height. But here is a question that those formulas don't answer. If we know the corners  $ (x_{1}, y_{1}) $ and  $ (x_{2}, y_{2}) $ and  $ (x_{3}, y_{3}) $ of a triangle, what is the area? Using the corners to find the base and height is not a good way to compute area.

Determinants are the best way to find area. The area of a triangle is half of a 3 by 3 determinant. The square roots in the base and height cancel out in the good formula. If one corner is at the origin, say  $ (x_3, y_3) = (0, 0) $, the determinant is only 2 by 2.

<div style="text-align: center;"><img src="imgs/img_in_image_box_248_709_842_871.jpg" alt="Image" width="55%" /></div>


<div style="text-align: center;">Figure 5.1: General triangle; special triangle from  $ (0,0) $; general from three specials.</div>


The triangle with corners  $ (x_{1}, y_{1}) $ and  $ (x_{2}, y_{2}) $ and  $ (x_{3}, y_{3}) $ has area =  $ \frac{\text{determinant}}{2} $:

Area of triangle

 $$ \begin{array}{l l l}{{{\left|\begin{array}{l l l}x_{1}}}}&{{{y_{1}}}}&{{{1}}} \\{{{x_{2}}}}&{{{y_{2}}}}&{{{1}}} \\{{{x_{3}}}}&{{{y_{3}}}}&{{{1}}}\end{array}\right|}&{\mathrm{A r e a}=\displaystyle\frac{1}{2}\left|\begin{array}{l l}x_{1}}&{y_{1}}\\ {x_{2}}&{y_{2}}\end{array}\right|}&{\mathrm{w h e n}\quad(x_{3},y_{3})=(0,0).}\end{array} $$ 