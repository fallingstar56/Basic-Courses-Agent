2 Compute the determinants of A, B, C, D. Are their columns independent?

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}}\end{bmatrix}\quad\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{4}}}&{{{5}}}&{{{6}}} \\{{{7}}}&{{{8}}}&{{{9}}}\end{bmatrix}\quad\boldsymbol{C}=\begin{bmatrix}{{{\boldsymbol{A}}}}&{{{0}}} \\{{{0}}}&{{{\boldsymbol{A}}}}\end{bmatrix}\quad\boldsymbol{D}=\begin{bmatrix}{{{\boldsymbol{A}}}}&{{{0}}} \\{{{0}}}&{{{\boldsymbol{B}}}}\end{bmatrix}. $$ 

3 Show that  $ \det A = 0 $, regardless of the five nonzeros marked by  $ x' $s:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{x}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{x}}}\end{bmatrix}. $$ 

What are the cofactors of row 1?

What is the rank of A?

What are the 6 terms in det A?

4 Find two ways to choose nonzeros from four different rows and columns:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}\qquad\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{2}}} \\{{{0}}}&{{{3}}}&{{{4}}}&{{{5}}} \\{{{5}}}&{{{4}}}&{{{0}}}&{{{3}}} \\{{{2}}}&{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix} $$ 

(B has the same zeros as A).

Is  $ \det A $ equal to  $ 1+1 $ or  $ 1-1 $ or  $ -1-1 $? What is  $ \det B $?

Place the smallest number of zeros in a 4 by 4 matrix that will guarantee  $ \det A = 0 $.

Place as many zeros as possible while still allowing  $ \det A \neq 0 $.

(a) If  $ a_{11} = a_{22} = a_{33} = 0 $, how many of the six terms in  $ \det A $ will be zero?

(b) If  $ a_{11} = a_{22} = a_{33} = a_{44} = 0 $, how many of the 24 products  $ a_{1j}a_{2k}a_{3l}a_{4m} $ are sure to be zero?

7 How many 5 by 5 permutation matrices have  $ \det P = +1 $? Those are even permutations. Find one that needs four exchanges to reach the identity matrix.

8 If  $ \det A $ is not zero, at least one of the  $ n! $ terms in formula (8) is not zero.  $ \text{Deduce} $ from the big formula that some ordering of the rows of A leaves no zeros on the diagonal.  $ \text{(Don't use } P \text{ from elimination; that } PA \text{ can have zeros on the diagonal.)} $

9 Show that 4 is the largest determinant for a 3 by 3 matrix of 1's and -1's.

10 How many permutations of  $ (1,2,3,4) $ are even and what are they? Extra credit: What are all the possible 4 by 4 determinants of  $ I + P_{even} $?

Problems 11–22 use cofactors  $ C_{ij} = (-1)^{i+j} \det M_{ij} $. Remove row i and column j.

11 Find all cofactors and put them into cofactor matrices C, D. Find AC and det B.

 $$ A=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}\qquad\qquad B=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{4}}}&{{{5}}}&{{{6}}} \\{{{7}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 