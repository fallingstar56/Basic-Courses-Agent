Problems 6–15 are about  $ A^{-1} = C^{\mathrm{T}} / \det A $. Remember to transpose C.

6 Find  $ A^{-1} $ from the cofactor formula  $ C^{T}/\det A $. Use symmetry in part (b).

(a)

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{3}}}&{{{0}}} \\{{{0}}}&{{{7}}}&{{{1}}}\end{bmatrix} $$ 

(b)

 $$ \boldsymbol{A}=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}. $$ 

7 If all the cofactors are zero, how do you know that A has no inverse? If none of the cofactors are zero, is A sure to be invertible?

8 Find the cofactors of A and multiply  $ AC^{T} $ to find det A:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{4}}} \\{{{1}}}&{{{2}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{5}}}\end{bmatrix}\qquad and\qquad\boldsymbol{C}=\begin{bmatrix}{{{6}}}&{{{-3}}}&{{{0}}} \\{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}} \\{{{\cdot}}}&{{{\cdot}}}&{{{\cdot}}}\end{bmatrix}\qquad and A\boldsymbol{C}^{\mathrm{T}}=\underline{\quad}\text{.} $$ 

If you change that 4 to 100, why is det A unchanged?

9 Suppose  $ \det A = 1 $ and you know all the cofactors in C. How can you find A?

From the formula  $ AC^{\mathrm{T}} = (\det A)I $ show that  $ \det C = (\det A)^{n-1} $.

If all entries of A are integers, and  $ \det A = 1 $ or -1, prove that all entries of  $ A^{-1} $ are integers. Give a 2 by 2 example with no zero entries.

If all entries of A and  $ A^{-1} $ are integers, prove that  $ \det A = 1 $ or -1. Hint: What is  $ \det A $ times  $ \det A^{-1} $?

Complete the calculation of  $ A^{-1} $ by cofactors that was started in Example 5.

14 L is lower triangular and S is symmetric. Assume they are invertible:

To invert triangular L symmetric S

 $$ L=\begin{bmatrix}{{{a}}}&{{{0}}}&{{{0}}} \\{{{b}}}&{{{c}}}&{{{0}}} \\{{{d}}}&{{{e}}}&{{{f}}}\end{bmatrix}\qquad S=\begin{bmatrix}{{{a}}}&{{{b}}}&{{{d}}} \\{{{b}}}&{{{c}}}&{{{e}}} \\{{{d}}}&{{{e}}}&{{{f}}}\end{bmatrix}. $$ 

(a) Which three cofactors of L are zero? Then  $ L^{-1} $ is also lower triangular.

(b) Which three pairs of cofactors of S are equal? Then  $ S^{-1} $ is also symmetric.

(c) The cofactor matrix C of an orthogonal Q will be ___. Why?

15 For $n = 5$ the matrix $C$ contains ___ cofactors. Each 4 by 4 cofactor contains ___ terms and each term needs ___ multiplications. Compare with $5^{3} = 125$ for the Gauss-Jordan computation of $A^{-1}$ in Section 2.4.

Problems 16–26 are about area and volume by determinants.

16 (a) Find the area of the parallelogram with edges v = (3, 2) and w = (1, 4).

(b) Find the area of the triangle with sides v, w, and  $ v + w $. Draw it.

(c) Find the area of the triangle with sides v, w, and w - v. Draw it.