Solution The cofactor  $ C_{11} $ for  $ H_{4} $ is the determinant  $ |H_{3}| $. We also need  $ C_{12} $ (in boldface):

 $$ C_{12}=-\left|\begin{matrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}}\end{matrix}\right|=-\left|\begin{matrix}{{{2}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}}\end{matrix}\right|+\left|\begin{matrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}}\end{matrix}\right| $$ 

Rows 2 and 3 stayed the same and we used linearity in row 1. The two determinants on the right are  $ -|H_3| $ and  $ +|H_2| $. Then the 4 by 4 determinant is

 $$ |H_{4}|=2C_{11}+1C_{12}=2|H_{3}|-|H_{3}|+|H_{2}|=|H_{3}|+|H_{2}|. $$ 

The actual numbers are  $ |H_2| = 3 $ and  $ |H_3| = 5 $ (and of course  $ |H_1| = 2 $). Since  $ |H_n| = 2, 3, 5, 8, \ldots $ follows Fibonacci's rule  $ |H_{n-1}| + |H_{n-2}| $, it must be  $ |H_n| = F_{n+2} $.

5.2 B These questions use the  $ \pm $ signs (even and odd P's) in the big formula for det A:

1. If A is the 10 by 10 all-ones matrix, how does the big formula give  $ \det A = 0 $?

2. If you multiply all n! permutations together into a single P, is P odd or even?

3. If you multiply each  $ a_{ij} $ by the fraction i/j, why is det A unchanged?

Solution In Question 1, with all  $ a_{ij} = 1 $, all the products in the big formula (8) will be 1. Half of them come with a plus sign, and half with minus. So they cancel to leave  $ \det A = 0 $. (Of course the all-ones matrix is singular. I am assuming  $ n > 1 $.)

In Question 2, multiplying  $ \left[\begin{array}{c}1 & 0 \\ 0 & 1\end{array}\right]\left[\begin{array}{c}0 & 1 \\ 1 & 0\end{array}\right] $ gives an odd permutation. Also for 3 by 3, the three odd permutations multiply (in any order) to give odd. But for  $ n > 3 $ the product of all permutations will be even. There are  $ n!/2 $ odd permutations and that is an even number as soon as  $ n! $ includes the factor 4.

In Question 3, each  $ a_{ij} $ is multiplied by  $ i/j $. So each product  $ a_{1\alpha}a_{2\beta}\cdots a_{n\omega} $ in the big formula is multiplied by all the row numbers  $ i=1,2,\ldots,n $ and divided by all the column numbers  $ j=1,2,\ldots,n $. (The columns come in some permuted order!) Then each product is unchanged and det A stays the same.

Another approach to Question 3: We are multiplying the matrix A by the diagonal matrix  $ D = \text{diag}(1 : n) $ when row i is multiplied by i. And we are postmultiplying by  $ D^{-1} $ when column j is divided by j. The determinant of  $ DAD^{-1} $ is the same as det A by the product rule.

### Problem Set 5.2

Problems 1–10 use the big formula with  $ n! $ terms:  $ |A| = \sum \pm a_{1\alpha} a_{2\beta} \cdots a_{n\omega} $. Every term uses each row and each column once.

1 Compute the determinants of A, B, C from six terms. Are their rows independent?

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{3}}}&{{{1}}}&{{{2}}} \\{{{3}}}&{{{2}}}&{{{1}}}\end{bmatrix}\qquad\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{4}}}&{{{4}}}&{{{4}}} \\{{{5}}}&{{{6}}}&{{{7}}}\end{bmatrix}\qquad\boldsymbol{C}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 