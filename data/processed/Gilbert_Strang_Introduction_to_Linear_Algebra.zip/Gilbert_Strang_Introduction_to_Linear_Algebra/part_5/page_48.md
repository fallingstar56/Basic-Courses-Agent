To explain eigenvalues, we first explain eigenvectors. Almost all vectors change direction, when they are multiplied by A. Certain exceptional vectors x are in the same direction as Ax. Those are the “eigenvectors”. Multiply an eigenvector by A, and the vector Ax is a number  $ \lambda $ times the original x.

The basic equation is  $ Ax = \lambda x $. The number  $ \lambda $ is an eigenvalue of A.

The eigenvalue  $ \lambda $ tells whether the special vector  $ \boldsymbol{x} $ is stretched or shrunk or reversed or left unchanged—when it is multiplied by  $ A $. We may find  $ \lambda = 2 $ or  $ \frac{1}{2} $ or -1 or 1. The eigenvalue  $ \lambda $ could be zero! Then  $ A\boldsymbol{x} = 0\boldsymbol{x} $ means that this eigenvector  $ \boldsymbol{x} $ is in the nullspace.

If $A$ is the identity matrix, every vector has $Ax = x$. All vectors are eigenvectors of $I$. All eigenvalues “lambda” are $\lambda = 1$. This is unusual to say the least. Most $2$ by $2$ matrices have two eigenvector directions and two eigenvalues. We will show that $\det(A - \lambda I) = 0$.

This section will explain how to compute the  $ x $'s and  $ \lambda $'s. It can come early in the course because we only need the determinant of a 2 by 2 matrix. Let me use  $ \det(A - \lambda I) = 0 $ to find the eigenvalues for this first example, and then derive it properly in equation (3).

Example 1 The matrix A has two eigenvalues  $ \lambda = 1 $ and  $ \lambda = 1/2 $. Look at  $ \det(A - \lambda I) $:

 $$ A=\begin{bmatrix}.8&.3\\ .2&.7\end{bmatrix}\quad\det\begin{bmatrix}.8-\lambda&.3\\ .2&.7-\lambda\end{bmatrix}=\lambda^{2}-\frac{3}{2}\lambda+\frac{1}{2}=(\lambda-1)\left(\lambda-\frac{1}{2}\right). $$ 

I factored the quadratic into  $ \lambda - 1 $ times  $ \lambda - \frac{1}{2} $, to see the two eigenvalues  $ \lambda = 1 $ and  $ \lambda = \frac{1}{2} $. For those numbers, the matrix  $ A - \lambda I $ becomes singular (zero determinant). The eigenvectors  $ x_1 $ and  $ x_2 $ are in the nullspaces of  $ A - I $ and  $ A - \frac{1}{2}I $.

 $$ (A-I)\boldsymbol{x}_{1}=0is A\boldsymbol{x}_{1}=\boldsymbol{x}_{1}and the first eigenvector is(.6,.4). $$ 

(A  $ -\frac{1}{2}I $)  $ x_{2}=0 $ is  $ Ax_{2}=\frac{1}{2}x_{2} $ and the second eigenvector is (1, -1):

 $$ \boldsymbol{x}_{1}=\begin{bmatrix}.6\\ .4\end{bmatrix}\quad and\quad A\boldsymbol{x}_{1}=\begin{bmatrix}.8&.3\\ .2&.7\end{bmatrix}\begin{bmatrix}.6\\ .4\end{bmatrix}=\boldsymbol{x}_{1}\quad(A\boldsymbol{x}=\boldsymbol{x}means that\lambda_{1}=1) $$ 

 $$ \boldsymbol{x}_{2}=\begin{bmatrix}1\\ -1\end{bmatrix}\quad and\quad\boldsymbol{A}\boldsymbol{x}_{2}=\begin{bmatrix}.8&.3\\ .2&.7\end{bmatrix}\begin{bmatrix}1\\ -1\end{bmatrix}=\begin{bmatrix}.5\\ -.5\end{bmatrix}\quad(this is\frac{1}{2}\boldsymbol{x}_{2}so\lambda_{2}=\frac{1}{2}). $$ 

If  $ x_1 $ is multiplied again by  $ A $, we still get  $ x_1 $. Every power of  $ A $ will give  $ A^n x_1 = x_1 $. Multiplying  $ x_2 $ by  $ A $ gave  $ \frac{1}{2} x_2 $, and if we multiply again we get  $ \left(\frac{1}{2}\right)^2 $ times  $ x_2 $.

When A is squared, the eigenvectors stay the same. The eigenvalues are squared.

This pattern keeps going, because the eigenvectors stay in their own directions (Figure 6.1) and never get mixed. The eigenvectors of  $ A^{100} $ are the same  $ x_1 $ and  $ x_2 $. The eigenvalues of  $ A^{100} $ are  $ 1^{100} = 1 $ and  $ \left(\frac{1}{2}\right)^{100} = \text{very small number} $.

Other vectors do change direction. But all other vectors are combinations of the two eigenvectors. The first column of A is the combination  $ \boldsymbol{x}_{1} + (0.2)\boldsymbol{x}_{2} $:

Separate into eigenvectors

Then multiply by A

 $$ \begin{bmatrix}.8\\ .2\end{bmatrix}=\boldsymbol{x}_{1}+(.2)\boldsymbol{x}_{2}=\begin{bmatrix}.6\\ .4\end{bmatrix}+\begin{bmatrix}.2\\ -.2\end{bmatrix}. $$ 