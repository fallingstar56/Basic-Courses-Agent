7 If A is triangular then  $ \det A = a_{11}a_{22} \cdots a_{nn} = product of diagonal entries. $

Triangular

 $$ \left|\begin{matrix}{{{a}}}&{{{b}}} \\{{{0}}}&{{{d}}}\end{matrix}\right|=ad\qquad and also\qquad\left|\begin{matrix}{{{a}}}&{{{0}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|=ad. $$ 

Suppose all diagonal entries are nonzero. Remove the off-diagonal entries by elimination! (If A is lower triangular, subtract multiples of each row from lower rows. If A is upper triangular, subtract from higher rows.) By rule 5 the determinant is not changed—and now the matrix is diagonal:

Diagonal matrix

 $$ \begin{align*}\det\begin{bmatrix}a_{11}&0\\ &a_{22}\\ &&\ddots\\ 0&&&a_{nn}\end{bmatrix}=(a_{11})(a_{22})\cdots(a_{nn}).\end{align*} $$ 

Factor  $ a_{11} $ from the first row by rule 3. Then factor  $ a_{22} $ from the second row. Eventually factor  $ a_{nn} $ from the last row. The determinant is  $ a_{11} $ times  $ a_{22} $ times  $ \cdots $ times  $ a_{nn} $ times  $ \det I $. Then rule 1 (used at last!) is  $ \det I = 1 $.

What if a diagonal entry  $ a_{ii} $ is zero? Then the triangular A is singular. Elimination produces a zero row. By rule 5 the determinant is unchanged, and by rule 6 a zero row means det A = 0. We reach the great test for singular or invertible matrices.

8 If A is singular then  $ \det A = 0 $. If A is invertible then  $ \det A \neq 0 $.

Singular

 $$ \begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}\quad is singular if and only if\quad ad-bc=0. $$ 

Proof Elimination goes from A to U. If A is singular then U has a zero row. The rules give  $ \det A = \det U = 0 $. If A is invertible then U has the pivots along its diagonal. The product of nonzero pivots (using rule 7) gives a nonzero determinant:

Multiply pivots

 $$ \det A=\pm\det U=\pm(product of the pivots). $$ 

The pivots of a 2 by 2 matrix (if  $ a \neq 0 $) are a and  $ d - (c/a)b $:

The determinant is

 $$ \left|\begin{array}{cc}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}} \\\end{array}\right|=\left|\begin{array}{cc}{{{a}}}&{{{b}}} \\{{{0}}}&{{{d-(c/a)b}}} \\\end{array}\right|=ad-bc. $$ 

This is the first formula for the determinant. MATLAB multiplies the pivots to find  $ \det A $. The sign in  $ \pm\det U $ depends on whether the number of row exchanges is even or odd: +1 or -1 is the determinant of the permutation P that exchanges rows.

With no row exchanges, P = I and det A = det U = product of pivots. And det L = 1:

 $$  If\quad PA=LU\quad then\quad\det P\det A=\det L\det U\quad and\quad\det A=\pm\det U. $$ 