Find the cofactor matrix C and multiply A times C. Compare AC.

 $$ A=\begin{bmatrix}{{{2}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{2}}}\end{bmatrix}\qquad A^{-1}=\frac{1}{4}\begin{bmatrix}{{{3}}}&{{{2}}}&{{{1}}} \\{{{2}}}&{{{4}}}&{{{2}}} \\{{{1}}}&{{{2}}}&{{{3}}}\end{bmatrix}. $$ 

The $n$ by $n$ determinant $C_{n}$ has 1's above and below the main diagonal:

 $$ C_{1}=\left|0\right|\quad C_{2}=\left|\begin{matrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{matrix}\right|\quad C_{3}=\left|\begin{matrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}}\end{matrix}\right|\quad C_{4}=\left|\begin{matrix}{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}\end{matrix}\right|. $$ 

(a) What are these determinants  $ C_{1}, C_{2}, C_{3}, C_{4} $?

(b) By cofactors find the relation between Cn and Cn−1 and Cn−2. Find C10.

The matrices in Problem 13 have 1's just above and below the main diagonal. Going down the matrix, which order of columns (if any) gives all 1's? Explain why that permutation is even for  $ n = 4, 8, 12, \ldots $ and odd for  $ n = 2, 6, 10, \ldots $. Then

 $$ C_{n}=0\left(\mathrm{odd}n\right)\qquad C_{n}=1\left(n=4,8,\cdots\right)\qquad C_{n}=-1\left(n=2,6,\cdots\right). $$ 

The tridiagonal 1, 1, 1 matrix of order n has determinant  $ E_{n} $

 $$ E_{1}=\left|1\right|\quad E_{2}=\left|\begin{matrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{matrix}\right|\quad E_{3}=\left|\begin{matrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}}\end{matrix}\right|\quad E_{4}=\left|\begin{matrix}{{{1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{1}}}\end{matrix}\right|. $$ 

(a) By cofactors show that  $ E_{n} = E_{n-1} - E_{n-2} $

(b) Starting from  $ E_{1}=1 $ and  $ E_{2}=0 $ find  $ E_{3}, E_{4}, \ldots, E_{8} $.

(c) By noticing how these numbers eventually repeat, find E100.

6 F n is the determinant of the 1, 1, −1 tridiagonal matrix of order n:

 $$ F_{2}=\left|\begin{matrix}{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}\end{matrix}\right|=2\quad F_{3}=\left|\begin{matrix}{{{1}}}&{{{-1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{-1}}} \\{{{0}}}&{{{1}}}&{{{1}}}\end{matrix}\right|=3\quad F_{4}=\left|\begin{matrix}{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}&{{{-1}}}\end{matrix}\right|\neq4. $$ 

Expand in cofactors to show that  $ F_n = F_{n-1} + F_{n-2} $. These determinants are Fibonacci numbers 1, 2, 3, 5, 8, 13, ... The sequence usually starts 1, 1, 2, 3 (with two 1's) so our  $ F_n $ is the usual  $ F_{n+1} $.