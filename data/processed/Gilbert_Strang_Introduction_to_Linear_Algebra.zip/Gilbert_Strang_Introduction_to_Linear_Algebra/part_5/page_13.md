5.1 B Explain how to reach this determinant by row operations:

 $$ \det\left[\begin{array}{ccc}{{{1-a}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1-a}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1-a}}} \\\end{array}\right]=a^{2}(3-a). $$ 

Solution Subtract row 3 from row 1 and then from row 2. This leaves

 $$ \begin{align*}\det\left[\begin{array}{ccc}-a&0&a\\0&-a&a\\1&1&1-a\end{array}\right].\end{align*} $$ 

Now add column 1 to column 3, and also column 2 to column 3. This leaves a lower triangular matrix with  $ -a, -a, 3 - a $ on the diagonal:  $ \det = (-a)(-a)(3 - a) $.

The determinant is zero if $a = 0$ or $a = 3$. For $a = 0$ we have the all-ones matrix—certainly singular. For $a = 3$, each row adds to zero—again singular. Those numbers 0 and 3 are the eigenvalues of the all-ones matrix. This example is revealing and important, leading toward Chapter 6.

### Problem Set 5.1

Questions 1–12 are about the rules for determinants.

1 If a 4 by 4 matrix has $\det A = \frac{1}{2}$, find $\det(2A)$ and $\det(-A)$ and $\det(A^{2})$ and $\det(A^{-1})$.

2 If a 3 by 3 matrix has $\det A = -1$, find $\det\left(\frac{1}{2}A\right)$ and $\det(-A)$ and $\det(A^{2})$ and $\det(A^{-1})$.

3 True or false, with a reason if true or a counterexample if false:

(a) The determinant of  $ I + A $ is  $ 1 + \det A $.

(b) The determinant of ABC is  $ |A||B||C| $.

(c) The determinant of 4A is 4|A|.

(d) The determinant of AB - BA is zero. Try an example with  $ A = \left[\begin{array}{cc} 0 & 0 \\ 0 & 1 \end{array}\right] $.

4 Which row exchanges show that these “reverse identity matrices”  $ J_{3} $ and  $ J_{4} $ have  $ |J_{3}| = -1 $ but  $ |J_{4}| = +1 $?

 $$ \det\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}=-1\qquad but\qquad\det\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}=+1. $$ 

5 For $n = 5, 6, 7$, count the row exchanges to permute the reverse identity $J_n$ to the identity matrix $I_n$. Propose a rule for every size $n$ and predict whether $J_{101}$ has determinant $+1$ or $-1$.