Example 6 In calculus, the box is infinitesimally small! To integrate over a circle, we might change $x$ and $y$ to $r$ and $\theta$. Those are polar coordinates: $x = r \cos \theta$ and $y = r \sin \theta$. The area of a “polar box” is a determinant $J$ times $dr \, d\theta$:

Area r dr dθ in calculus

 $$ \boldsymbol{J}=\left|\begin{matrix}\partial x/\partial r&\partial x/\partial\theta\\ \partial y/\partial r&\partial y/\partial\theta\end{matrix}\right|=\left|\begin{matrix}\cos\theta&-r\sin\theta\\ \sin\theta&r\cos\theta\end{matrix}\right|=\boldsymbol{r}. $$ 

This determinant is the $r$ in the small area $dA = r\,dr\,d\theta$. The stretching factor $J$ goes into double integrals just as $dx/du$ goes into an ordinary integral $\int dx = \int(dx/du)\,du$. For triple integrals the Jacobian matrix $J$ with nine derivatives will be 3 by 3.

The Cross Product

The cross product is an extra (and optional) application, special for three dimensions. Start with vectors  $ \boldsymbol{u} = (u_1, u_2, u_3) $ and  $ \boldsymbol{v} = (v_1, v_2, v_3) $. Unlike the dot product, which is a number, the cross product is a vector—also in three dimensions. It is written  $ \boldsymbol{u} \times \boldsymbol{v} $ and pronounced “u cross v.” The components of this cross product are 2 by 2 cofactors. We will explain the properties that make  $ \boldsymbol{u} \times \boldsymbol{v} $ useful in geometry and physics.

This time we bite the bullet, and write down the formula before the properties.

DEFINITION The cross product of  $  u = (u_1, u_2, u_3)  $ and  $  v = (v_1, v_2, v_3)  $ is a vector

 $$ \mathbf{u}\times\mathbf{v}=\left|\begin{matrix}{i}&{j}&{k}\\ {u_{1}}&{u_{2}}&{u_{3}}\\ {v_{1}}&{v_{2}}&{v_{3}}\\ \end{matrix}\right|=(u_{2}v_{3}-u_{3}v_{2})\mathbf{i}+(u_{3}v_{1}-u_{1}v_{3})\mathbf{j}+(u_{1}v_{2}-u_{2}v_{1})\mathbf{k}. $$ 

This vector u × v is perpendicular to u and v. The cross product v × u is -(u × v).

Comment The 3 by 3 determinant is the easiest way to remember  $ u \times v $. It is not especially legal, because the first row contains vectors  $ i, j, k $ and the other rows contain numbers. In the determinant, the vector  $ i = (1, 0, 0) $ multiplies  $ u_2 v_3 $ and  $ -u_3 v_2 $. The result is  $ (u_2 v_3 - u_3 v_2, 0, 0) $, which displays the first component of the cross product.

Notice the cyclic pattern of the subscripts: 2 and 3 give component 1 of  $ u \times v $, then 3 and 1 give component 2, then 1 and 2 give component 3. This completes the definition of  $ u \times v $. Now we list the properties of the cross product:

Property 1  $ v \times u $ reverses rows 2 and 3 in the determinant so it equals  $ -(u \times v) $.

Property 2 The cross product  $ u \times v $ is perpendicular to u (and also to v). The direct proof is to watch terms cancel, producing a zero dot product:

 $$ \boldsymbol{u}\cdot(\boldsymbol{u}\times\boldsymbol{v})=u_{1}(u_{2}v_{3}-u_{3}v_{2})+u_{2}(u_{3}v_{1}-u_{1}v_{3})+u_{3}(u_{1}v_{2}-u_{2}v_{1})=0. $$ 

The determinant for  $ \boldsymbol{u} \cdot (\boldsymbol{u} \times \boldsymbol{v}) $ has rows  $ \boldsymbol{u}, \boldsymbol{u} $ and  $ \boldsymbol{v} $ (2 equal rows) so it is zero.