When you set  $ x_{3} = y_{3} = 0 $ in the 3 by 3 determinant, you get the 2 by 2 determinant. These formulas have no square roots—they are reasonable to memorize. The 3 by 3 determinant breaks into a sum of three 2 by 2's (cofactors), just as the third triangle in Figure 5.1 breaks into three special triangles from  $ (0, 0) $:

 $$ \begin{aligned}Area&=\frac{1}{2}\begin{vmatrix}{{{x_{1}}}}&{{{y_{1}}}}&{{{1}}} \\{{{x_{2}}}}&{{{y_{2}}}}&{{{1}}} \\{{{x_{3}}}}&{{{y_{3}}}}&{{{1}}}\end{vmatrix}=\begin{vmatrix}{{{+\frac{1}{2}(x_{1}y_{2}-x_{2}y_{1})}}} \\{{{+\frac{1}{2}(x_{2}y_{3}-x_{3}y_{2})}}} \\{{{+\frac{1}{2}(x_{3}y_{1}-x_{1}y_{3})}}}\end{vmatrix}.\end{aligned} $$ 

If  $ (0,0) $ is outside the triangle, two of the special areas can be negative—but the sum is still correct. The real problem is to explain the area of a triangle with corner  $ (0,0) $.

Why is  $ \frac{1}{2}|x_1y_2 - x_2y_1| $ the area of this triangle? We can remove the factor  $ \frac{1}{2} $ for a parallelogram (twice as big, because the parallelogram contains two equal triangles). We now prove that the parallelogram area is the determinant  $ x_1y_2 - x_2y_1 $. This area in Figure 5.2 is 11, and therefore the triangle has area  $ \frac{11}{2} $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_161_516_369_664.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_414_517_624_664.jpg" alt="Image" width="19%" /></div>


Parallelogram

 $$  Area=\left|\begin{matrix}{{{4}}}&{{{1}}} \\{{{1}}}&{{{3}}}\end{matrix}\right|=11 $$ 

Triangle: Area =  $ \frac{11}{2} $

<div style="text-align: center;">Figure 5.2: A triangle is half of a parallelogram. Area is half of a determinant.</div>


Proof that a parallelogram starting from  $ (0,0) $ has area = 2 by 2 determinant.

There are many proofs but this one fits with the book. We show that the area has the same properties 1-2-3 as the determinant. Then area = determinant! Remember that those three rules defined the determinant and led to all its other properties.

1 When A = I, the parallelogram becomes the unit square. Its area is  $ \det I = 1 $.

2 When rows are exchanged, the determinant reverses sign. The absolute value (positive area) stays the same—it is the same parallelogram.

3 If row 1 is multiplied by t, Figure 5.3a shows that the area is also multiplied by t. Suppose a new row  $ (x_{1}^{\prime}, y_{1}^{\prime}) $ is added to  $ (x_{1}, y_{1}) $ (keeping row 2 fixed). Figure 5.3b shows that the solid parallelogram areas add to the dotted parallelogram area (because the two triangles completed by dotted lines are the same).

That is an exotic proof, when we could use plane geometry. But the proof has a major attraction—it applies in $n$ dimensions. The $n$ edges going out from the origin are given by the rows of an $n$ by $n$ matrix. The box is completed by more edges, like the parallelogram.