Problems 23–26 are about block matrices and block determinants.

23 With 2 by 2 blocks in 4 by 4 matrices, you cannot always use block determinants:

 $$ \left|\begin{matrix}{A}&{B}\\ {0}&{D}\\ \end{matrix}\right|=|A||D|\qquad\mathrm{b u t}\qquad\left|\begin{matrix}{A}&{B}\\ {C}&{D}\\ \end{matrix}\right|\neq|A||D|-|C||B|. $$ 

(a) Why is the first statement true? Somehow B doesn't enter.

(b) Show by example that equality fails (as shown) when C enters.

(c) Show by example that the answer  $ \det(AD - CB) $ is also wrong.

 $$ \boldsymbol{A}=\begin{bmatrix}\boldsymbol{A}_{k}&*\\ *&*\end{bmatrix}=\begin{bmatrix}\boldsymbol{L}_{k}&0\\ *&*\end{bmatrix}\begin{bmatrix}\boldsymbol{U}_{k}&*\\ 0&*\end{bmatrix}. $$ 

With block multiplication, $A = LU$ has $A_k = L_k U_k$ in the top left corner:

(a) Suppose the first three pivots of A are 2, 3, −1. What are the determinants of  $ L_{1}, L_{2}, L_{3} $ (with diagonal 1's) and  $ U_{1}, U_{2}, U_{3} $ and  $ A_{1}, A_{2}, A_{3} $?

(b) If  $ A_{1}, A_{2}, A_{3} $ have determinants 5, 6, 7 find the three pivots from equation (3).

Block elimination subtracts  $ CA^{-1} $ times the first row [A B] from the second row [C D]. This leaves the Schur complement  $ D - CA^{-1}B $ in the corner:

 $$ \begin{bmatrix}{{{I}}}&{{{0}}} \\{{{-C A^{-1}}}}&{{{I}}}\end{bmatrix}\begin{bmatrix}{{{A}}}&{{{B}}} \\{{{C}}}&{{{D}}}\end{bmatrix}=\begin{bmatrix}{{{A}}}&{{{B}}} \\{{{0}}}&{{{D-C A^{-1}B}}}\end{bmatrix}. $$ 

Take determinants of these block matrices to prove correct rules if  $ A^{-1} $ exists:

 $$ \left|\begin{matrix}{A}&{B}\\ {C}&{D}\\ \end{matrix}\right|=\left|\begin{matrix}{A}\\ \end{matrix}\right|\left|\begin{matrix}{D-C A^{-1}B}\\ \end{matrix}\right|=\left|\begin{matrix}{A D-C B}\\ \end{matrix}\right|\mathrm{~p r o v i d e d~}A C=C A. $$ 

If A is m by n and B is n by m, block multiplication gives  $ \det M = \det AB $:

 $$ M=\begin{bmatrix}{{{0}}}&{{{A}}} \\{{{-B}}}&{{{I}}}\end{bmatrix}=\begin{bmatrix}{{{AB}}}&{{{A}}} \\{{{0}}}&{{{I}}}\end{bmatrix}\begin{bmatrix}{{{I}}}&{{{0}}} \\{{{-B}}}&{{{I}}}\end{bmatrix}. $$ 

If A is a single row and B is a single column what is det M? If A is a column and B is a row what is det M? Do a 3 by 3 example of each.

(A calculus question) Show that the derivative of  $ \det A $ with respect to  $ a_{11} $ is the cofactor  $ C_{11} $. The other entries are fixed—we are only changing  $ a_{11} $.