Spherical coordinates $\rho, \phi, \theta$ satisfy $x = \rho \sin \phi \cos \theta$ and $y = \rho \sin \phi \sin \theta$ and $z = \rho \cos \phi$. Find the 3 by 3 matrix of partial derivatives: $\partial x / \partial \rho, \partial x / \partial \phi, \partial x / \partial \theta$ in row 1. Simplify its determinant to $J = \rho^2 \sin \phi$. Then $dV$ in spherical coordinates is $\rho^2 \sin \phi \, d\rho \, d\phi \, d\theta$, the volume of an infinitesimal “coordinate box”.

The matrix that connects $r,\theta$ to $x,y$ is in Problem 27. Invert that 2 by 2 matrix:

 $$ J^{-1}=\left|\begin{matrix}\partial r/\partial x&\partial r/\partial y\\ \partial\theta/\partial x&\partial\theta/\partial y\end{matrix}\right|=\left|\begin{matrix}\cos\theta&\mathrm{?}\\ \mathrm{?}&?\end{matrix}\right|=? $$ 

It is surprising that $\partial r/\partial x = \partial x/\partial r$ (Calculus, Gilbert Strang, p. 501). Multiplying the matrices $J$ and $J^{-1}$ gives the chain rule $\frac{\partial x}{\partial x} = \frac{\partial x}{\partial r} \frac{\partial r}{\partial x} + \frac{\partial x}{\partial \theta} \frac{\partial \theta}{\partial x} = 1$.

The triangle with corners  $ (0,0) $,  $ (6,0) $, and  $ (1,4) $ has area ___. When you rotate it by  $ \theta = 60^{\circ} $ the area is ___. The determinant of the rotation matrix is

 $$ J=\left|\begin{matrix}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{matrix}\right|=\left|\begin{matrix}\frac{1}{2}&?\\ ?&?\end{matrix}\right|=? $$ 

Problems 31–38 are about the triple product  $ (u \times v) \cdot w $ in three dimensions.

31 A box has base area  $ \|u \times v\| $. Its perpendicular height is  $ \|w\|\cos\theta $. Base area times height = volume =  $ \|u \times v\|\|w\|\cos\theta $ which is  $ (u \times v) \cdot w $. Compute base area, height, and volume for  $ u = (2, 4, 0) $,  $ v = (-1, 3, 0) $,  $ w = (1, 2, 2) $.

33 Expand the 3 by 3 determinant in equation (13) in cofactors of its row  $ u_{1}, u_{2}, u_{3} $. This expansion is the dot product of u with the vector ___.

Which of the triple products  $ (u \times w) \cdot v $ and  $ (w \times u) \cdot v $ and  $ (v \times w) \cdot u $ are the same as  $ (u \times v) \cdot w $? Which orders of the rows  $ u, v, w $ give the correct determinant?

Let  $ P = (1, 0, -1) $ and  $ Q = (1, 1, 1) $ and  $ R = (2, 2, 1) $. Choose S so that PQRS is a parallelogram and compute its area. Choose T, U, V so that OPQRSTUV is a tilted box and compute its volume.

Suppose  $ (x,y,z) $ and  $ (1,1,0) $ and  $ (1,2,1) $ lie on a plane through the origin. What determinant is zero? What equation does this give for the plane?

Suppose  $ (x, y, z) $ is a linear combination of  $ (2, 3, 1) $ and  $ (1, 2, 3) $. What determinant is zero? What equation does this give for the plane of all combinations?

(a) Explain from volumes why  $ \det 2A = 2^n \det A $ for n by n matrices.

(b) For what size matrix is the false statement  $ \det A + \det A = \det(A + A) $ true?