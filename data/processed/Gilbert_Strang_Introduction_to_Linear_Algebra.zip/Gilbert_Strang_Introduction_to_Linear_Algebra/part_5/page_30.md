A 3 by 3 determinant has three products “down to the right” and three “down to the left” with minus signs. Compute the six terms like (1)(5)(9) = 45 to find D.

<div style="text-align: center;"><img src="imgs/img_in_image_box_256_185_780_354.jpg" alt="Image" width="49%" /></div>


Explain without determinants why this particular matrix is or is not invertible.

29 For  $ E_{4} $ in Problem 15, five of the 4! = 24 terms in the big formula (8) are nonzero. Find those five terms to show that  $ E_{4} = -1 $.

For the 4 by 4 tridiagonal second difference matrix (entries -1, 2, -1) find the five terms in the big formula that give  $ \det A = 16 - 4 - 4 - 4 + 1 $.

31 Find the determinant of this cyclic $P$ by cofactors of row 1 and then the “big formula”. How many exchanges reorder 4, 1, 2, 3 into 1, 2, 3, 4? Is |$P^2$| = 1 or -1?

 $$ \boldsymbol{P}=\left[\begin{array}{llll}{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}\end{array}\right]\qquad\quad\boldsymbol{P}^{2}=\left[\begin{array}{llll}{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}}\end{array}\right]=\left[\begin{array}{ll}{{{0}}}&{{{I}}} \\{{{I}}}&{{{0}}}\end{array}\right]. $$ 

## Challenge Problems

Cofactors of the 1, 3, 1 matrices in Problem 21 give a recursion  $ S_{n} = 3S_{n-1} - S_{n-2} $. Amazingly that recursion produces every second Fibonacci number. Here is the challenge.

Show that $S_n$ is the Fibonacci number $F_{2n+2}$ by proving $F_{2n+2}=3F_{2n}-F_{2n-2}$. Keep using Fibonacci's rule $F_k=F_{k-1}+F_{k-2}$ starting with $k=2n+2$.

The symmetric Pascal matrices have determinant 1. If I subtract 1 from the n, n entry, why does the determinant become zero? (Use rule 3 or cofactors.)

 $$ \begin{array}{l l l l}{{{\det\left[\begin{array}{l l l l}1}}}&{1}&{1}&{1}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}} \\{{{1}}}&{{{3}}}&{{{6}}}&{{{10}}} \\{{{1}}}&{{{4}}}&{{{10}}}&{{{20}}}\end{array}\right]=1(known)\qquad\quad\det\left[\begin{array}{l l l l}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}} \\{{{1}}}&{{{3}}}&{{{6}}}&{{{10}}} \\{{{1}}}&{{{4}}}&{{{10}}}&{{{19}}}\end{array}\right]={\bf0}(to explain).}\end{array} $$ 