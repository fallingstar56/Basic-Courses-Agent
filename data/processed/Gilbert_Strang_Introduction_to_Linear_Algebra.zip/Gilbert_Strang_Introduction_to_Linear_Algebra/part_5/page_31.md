34 This problem shows in two ways that  $ \det A = 0 $ (the x's are any numbers):

 $$ \boldsymbol{A}=\begin{bmatrix}{{{x}}}&{{{x}}}&{{{x}}}&{{{x}}}&{{{x}}} \\{{{x}}}&{{{x}}}&{{{x}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{x}}}&{{{x}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{x}}}&{{{x}}}\end{bmatrix}. $$ 

(a) How do you know that the rows are linearly dependent?

(b) Explain why all 120 terms are zero in the big formula for det A.

If  $ |\det(A)| > 1 $, prove that the powers  $ A^n $ cannot stay bounded. But if  $ |\det(A)| \leq 1 $, show that some entries of  $ A^n $ might still grow large. Eigenvalues will give the right test for stability, determinants tell us only one number.