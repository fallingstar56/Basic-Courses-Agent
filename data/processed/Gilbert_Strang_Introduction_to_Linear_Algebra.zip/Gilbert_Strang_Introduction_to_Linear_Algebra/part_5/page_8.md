## The Properties of the Determinant

Determinants have three basic properties (rules 1, 2, 3). By using those rules we can compute the determinant of any square matrix A. This number is written in two ways,  $ \det A $ and  $ |A| $. Notice: Brackets for the matrix, straight bars for its determinant. When A is a 2 by 2 matrix, the rules 1, 2, 3 lead to the answer we expect:

The determinant of

 $$ \begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}\quad is\quad\begin{vmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{vmatrix}=ad-bc. $$ 

From rules 1–3 we will reach rules 4–10. The last two are  $ \det(AB) = (\det A)(\det B) $ and  $ \det A^{\mathrm{T}} = \det A $. We will check all rules with the 2 by 2 formula, but do not forget: The rules apply to any n by n matrix A.

Rule 1 (the easiest) matches  $ \det I = 1 $ with volume = 1 for a unit cube.

1 The determinant of the n by n identity matrix is 1.

 $$ \begin{align*}\begin{vmatrix}1&0\\0&1\end{vmatrix}=1\qquad and\qquad\begin{vmatrix}1&&\\&\ddots&\\&&1\end{vmatrix}=1.\end{align*} $$ 

2 The determinant changes sign when two rows are exchanged (sign reversal):

Check:

 $$ \left|\begin{matrix}{c}&{d}\\ {a}&{b}\\ \end{matrix}\right|=-\left|\begin{matrix}{a}&{b}\\ {c}&{d}\\ \end{matrix}\right|\quad(both sides equal bc-ad). $$ 

Because of this rule, we can find  $ \det P $ for any permutation matrix. Just exchange rows of I until you reach P. Then  $ \det P = +1 $ for an even number of row exchanges and  $ \det P = -1 $ for an odd number.

The third rule has to make the big jump to the determinants of all matrices.

3 The determinant is a linear function of each row separately (all other rows stay fixed). If the first row is multiplied by t, the determinant is multiplied by t. If first rows are added, determinants are added. This rule only applies when the other rows do not change! Notice how c and d stay the same:

multiply row 1 by any number t

det is multiplied by t

add row 1 of A to row 1 of A': then determinants add

 $$ \begin{aligned}&\left|\begin{matrix}{{{ta}}}&{{{tb}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|=t\left|\begin{matrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|\\ &\left|\begin{matrix}{{{a+a^{\prime}}}}&{{{b+b^{\prime}}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|=\left|\begin{matrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|+\left|\begin{matrix}{{{a^{\prime}}}}&{{{b^{\prime}}}} \\{{{c}}}&{{{d}}}\end{matrix}\right|.\\ \end{aligned} $$ 

In the first case, both sides are  $ tad - tbc $. Then t factors out. In the second case, both sides are  $ ad + a'd - bc - b'c $. These rules still apply when A is n by n, and one row changes.

 $$ \boldsymbol{A}=\left|\begin{matrix}{{{4}}}&{{{8}}}&{{{8}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{matrix}\right|=4\left|\begin{matrix}{{{1}}}&{{{2}}}&{{{2}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{matrix}\right|\quad and\quad\left|\begin{matrix}{{{4}}}&{{{8}}}&{{{8}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{matrix}\right|=\left|\begin{matrix}{{{4}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{matrix}\right|+\left|\begin{matrix}{{{0}}}&{{{8}}}&{{{8}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{matrix}\right|. $$ 

By itself, rule 3 does not say what those determinants are (det A is 4).