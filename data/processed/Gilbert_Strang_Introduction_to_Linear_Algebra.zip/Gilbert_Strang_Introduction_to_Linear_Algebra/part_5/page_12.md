Important comment on columns Every rule for the rows can apply to the columns (just by transposing, since  $ |A| = |A^\top| $). The determinant changes sign when two columns are exchanged. A zero column or two equal columns will make the determinant zero. If a column is multiplied by t, so is the determinant. The determinant is a linear function of each column separately.

It is time to stop. The list of properties is long enough. Next we find and use an explicit formula for the determinant.

## ■ REVIEW OF THE KEY IDEAS

1. The determinant is defined by  $ \det I = 1 $, sign reversal, and linearity in each row.

2. After elimination det A is  $ \pm $ (product of the pivots).

3. The determinant is zero exactly when A is not invertible.

4. Two remarkable properties are  $ \det A B = (\det A)(\det B) $ and  $ \det A^{T} = \det A $.

## WORKED EXAMPLES

5.1 A Apply these operations to A and find the determinants of  $ M_{1}, M_{2}, M_{3}, M_{4} $: In  $ M_{1} $, multiplying each  $ a_{ij} $ by  $ (-1)^{i+j} $ gives a checkerboard sign pattern.

In  $ M_{2} $, rows 1, 2, 3 of A are subtracted from rows 2, 3, 1.

In  $ M_{3} $, rows 1, 2, 3 of A are added to rows 2, 3, 1.

How are the determinants of  $ M_{1}, M_{2}, M_{3} $ related to the determinant of A?

 $$ \begin{bmatrix} {a_{11}}&{-a_{12}}&{a_{13}} \\ {-a_{21}}&{a_{22}}&{-a_{23}} \\ {a_{31}}&{-a_{32}}&{a_{33}} \end{bmatrix} \quad \begin{bmatrix} {\text{row}1-\text{row}3} \\ {\text{row}2-\text{row}1} \\ {\text{row}3-\text{row}2} \end{bmatrix} \quad \begin{bmatrix} {\text{row}1+\text{row}3} \\ {\text{row}2+\text{row}1} \\ {\text{row}3+\text{row}2} \end{bmatrix} $$ 

Solution The three determinants are  $ \det A $, 0, and 2  $ \det A $. Here are reasons:

 $$ M_{1}=\begin{bmatrix}1&&\\ &-1&\\ &&1\end{bmatrix}\begin{bmatrix}a_{11}&a_{12}&a_{13}\\ a_{21}&a_{22}&a_{23}\\ a_{31}&a_{32}&a_{33}\end{bmatrix}\begin{bmatrix}1&&\\ &-1&\\ &&1\end{bmatrix}\quad so\det M_{1}=(-1)(\det A)(-1). $$ 

 $ M_{2} $ is singular because its rows add to the zero row. Its determinant is zero.

 $ M_{3} $ can be split into eight matrices by Rule 3 (linearity in each row separately):

 $$ \begin{array}{l}\left|\begin{array}{l}row1+row3\\ row2+row1\\ row3+row3\end{array}\right|=\left|\begin{array}{l}row1\\ row2\\ row3\end{array}\right|+\left|\begin{array}{l}row3\\ row2\\ row3\end{array}\right|+\left|\begin{array}{l}row1\\ row1\\ row3\end{array}\right|+\cdots+\left|\begin{array}{l}row3\\ row1\\ row2\end{array}\right|.\end{array} $$ 

All but the first and last have repeated rows and zero determinant. The first is A and the last has two row exchanges. So  $ \det M_{3} = \det A + \det A $. (Try A = I.)