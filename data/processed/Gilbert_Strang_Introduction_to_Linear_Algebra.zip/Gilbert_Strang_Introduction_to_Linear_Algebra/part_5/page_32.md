### 5.3 Cramer's Rule, Inverses, and Volumes

(1)  $ A^{-1} $ equals  $ C^{\mathrm{T}}/\det A $. Then  $ (A^{-1})_{ij} = \text{cofactor } C_{ji} $ divided by the determinant of A.

2)  $ \text{Cramer's Rule} $ computes  $ x = A^{-1}b $ from  $ x_j = \det(A) $ with column  $ j $ changed to  $ b $ /  $ \det A $.

3) Area of parallelogram =  $ |ad - bc| $ if the four corners are  $ (0, 0) $,  $ (a, b) $,  $ (c, d) $, and  $ (a+c, b+d) $.

4) Volume of box =  $ |\det A| $ if the rows of  $ A $ (or the columns of  $ A $) give the sides of the box.

5) The cross product  $ w = u \times v $ is  $ \det\left[\begin{array}{ccc}i & j & k \\ u_1 & u_2 & u_3 \\ v_1 & v_2 & v_3\end{array}\right] $. Notice  $ v \times u = -(u \times v) $.

Notice  $ w^{\mathrm{T}}u = 0 $ and  $ w^{\mathrm{T}}v = 0 $.

This section solves  $ Ax = b $ and also finds  $ A^{-1} $—by algebra and not by elimination. In all formulas you will see a division by det A. Each entry in  $ A^{-1} $ and  $ A^{-1}b $ is a determinant divided by the determinant of A. Let me start with Cramer's Rule.

Cramer's Rule solves Ax = b. A neat idea gives the first component  $ x_1 $. Replacing the first column of I by x gives a matrix with determinant  $ x_1 $. When you multiply it by A, the first column becomes Ax which is b. The other columns of  $ B_1 $ are copied from A:

Key idea

 $$ \begin{aligned}&\begin{bmatrix} \\{{{A}}} \\{{{\begin{bmatrix}}}} \\{{{x_{1}}}}&{{{0}}}&{{{0}}} \\{{{x_{2}}}}&{{{1}}}&{{{0}}} \\{{{x_{3}}}}&{{{0}}}&{{{1}}} \\\end{bmatrix}=\begin{bmatrix} \\{{{b_{1}}}}&{{{a_{12}}}}&{{{a_{13}}}} \\{{{b_{2}}}}&{{{a_{22}}}}&{{{a_{23}}}} \\{{{b_{3}}}}&{{{a_{32}}}}&{{{a_{33}}}} \\\end{bmatrix}=B_{1}.\\ \end{aligned} $$ 

We multiplied a column at a time. Take determinants of the three matrices to find  $ x_{1} $

Product rule

 $$ (\operatorname*{d e t}A)(x_{1})=\operatorname*{d e t}B_{1}\qquad\mathrm{o r}\qquad x_{1}=\frac{\operatorname*{d e t}B_{1}}{\operatorname*{d e t}A}. $$ 

This is the first component of x in Cramer's Rule! Changing a column of A gave  $ B_{1} $. To find  $ x_{2} $ and  $ B_{2} $, put the vectors x and b into the second columns of I and A:

Same idea

 $$ \begin{bmatrix}{{{a_{1}}}}&{{{a_{2}}}}&{{{a_{3}}}} \\ \\\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{x_{1}}}}&{{{0}}} \\{{{0}}}&{{{x_{2}}}}&{{{0}}} \\{{{0}}}&{{{x_{3}}}}&{{{1}}} \\\end{bmatrix}=\begin{bmatrix}{{{a_{1}}}}&{{{b}}}&{{{a_{3}}}} \\\end{bmatrix}=B_{2}. $$ 

Take determinants to find (det A)(x2) = det B2. This gives x2 = (det B2)/(det A).

Example 1 Solving  $ 3x_1 + 4x_2 = 2 $ and  $ 5x_1 + 6x_2 = 4 $ needs three determinants:

 $$ \det A=\left|\begin{array}{cc}{{{3}}}&{{{4}}} \\{{{5}}}&{{{6}}}\end{array}\right|\quad\det B_{1}=\left|\begin{array}{cc}{{{2}}}&{{{4}}} \\{{{4}}}&{{{6}}}\end{array}\right|\quad\det B_{2}=\left|\begin{array}{cc}{{{3}}}&{{{2}}} \\{{{5}}}&{{{4}}}\end{array}\right| $$ 