<div style="text-align: center;"><img src="imgs/img_in_image_box_181_111_915_390.jpg" alt="Image" width="68%" /></div>


<div style="text-align: center;">Figure 5.3: Areas obey the rule of linearity in side 1 (keeping the side  $ (x_{2}, y_{2}) $ constant).</div>


Figure 5.4 shows a three-dimensional box—whose edges are not at right angles. The volume equals the absolute value of det A. Our proof checks again that rules 1–3 for determinants are also obeyed by volumes. When an edge is stretched by a factor t, the volume is multiplied by t. When edge 1 is added to edge 1', the volume is the sum of the two original volumes. This is Figure 5.3b lifted into three dimensions or n dimensions. I would draw the boxes but this paper is only two-dimensional.

<div style="text-align: center;"><img src="imgs/img_in_image_box_280_628_800_946.jpg" alt="Image" width="48%" /></div>


<div style="text-align: center;">Figure 5.4: Three-dimensional box formed from the three rows of A.</div>


The unit cube has volume = 1, which is det I. Row exchanges or edge exchanges leave the same box and the same absolute volume. The determinant changes sign, to indicate whether the edges are a right-handed triple (det A > 0) or a left-handed triple (det A < 0). The box volume follows the rules for determinants, so volume of det A = absolute value.

Example 5 Suppose a rectangular box (90° angles) has side lengths r, s, and t. Its volume is r times s times t. The diagonal matrix A with entries r, s, and t produces those three sides. Then det A also equals the volume r s t.