15 Use row operations to simplify and compute these determinants:

 $$ \det\begin{bmatrix}{{{101}}}&{{{201}}}&{{{301}}} \\{{{102}}}&{{{202}}}&{{{302}}} \\{{{103}}}&{{{203}}}&{{{303}}}\end{bmatrix}\qquad and\qquad\det\begin{bmatrix}{{{1}}}&{{{t}}}&{{{t^{2}}}} \\{{{t}}}&{{{1}}}&{{{t}}} \\{{{t^{2}}}}&{{{t}}}&{{{1}}}\end{bmatrix}. $$ 

16 Find the determinants of a rank one matrix and a skew-symmetric matrix :

 $$ A=\begin{bmatrix}{{{1}}} \\{{{2}}} \\{{{3}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{-4}}}&{{{5}}}\end{bmatrix}\qquad and\qquad A=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{3}}} \\{{{-1}}}&{{{0}}}&{{{4}}} \\{{{-3}}}&{{{-4}}}&{{{0}}}\end{bmatrix}. $$ 

A skew-symmetric matrix has  $ A^{\mathrm{T}} = -A $. Insert  $ a, b, c $ for 1, 3, 4 in Question 16 and show that  $ |A| = 0 $. Write down a 4 by 4 example with  $ |A| = 1 $.

Use row operations to show that the 3 by 3 “Vandermonde determinant” is

 $$ \det\begin{bmatrix}1&a&a^{2}\\ 1&b&b^{2}\\ 1&c&c^{2}\end{bmatrix}=(b-a)(c-a)(c-b). $$ 

19 Find the determinants of U and  $ U^{-1} $ and  $ U^{2} $:

 $$ U=\begin{bmatrix}{{{1}}}&{{{4}}}&{{{6}}} \\{{{0}}}&{{{2}}}&{{{5}}} \\{{{0}}}&{{{0}}}&{{{3}}}\end{bmatrix}\qquad and\qquad U=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{0}}}&{{{d}}}\end{bmatrix}. $$ 

Suppose you do two row operations at once, going from

 $$ \begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix} \quad \mathrm{to} \quad \begin{bmatrix}{{{a-Lc}}}&{{{b-Ld}}} \\{{{c-la}}}&{{{d-lb}}}\end{bmatrix}. $$ 

Find the second determinant. Does it equal ad - bc?

Row exchange: Add row 1 of A to row 2, then subtract row 2 from row 1. Then add row 1 to row 2 and multiply row 1 by -1 to reach B. Which rules show

 $$ \det\boldsymbol{B}=\left|\begin{array}{cc}{{{c}}}&{{{d}}} \\{{{a}}}&{{{b}}}\end{array}\right|\quad equals\quad-\det\boldsymbol{A}=-\left|\begin{array}{cc}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{array}\right|? $$ 

Those rules could replace Rule 2 in the definition of the determinant.

From $ad - bc$, find the determinants of $A$ and $A^{-1}$ and $A - \lambda I$:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{1}}}&{{{2}}}\end{bmatrix}\quad and\quad\boldsymbol{A}^{-1}=\frac{1}{3}\begin{bmatrix}{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}\end{bmatrix}\quad and\quad\boldsymbol{A}-\lambda\boldsymbol{I}=\begin{bmatrix}{{{2-\lambda}}}&{{{1}}} \\{{{1}}}&{{{2-\lambda}}}\end{bmatrix}. $$ 

Which two numbers λ lead to  $ \det(A - \lambda I) = 0 $? Write down the matrix  $ A - \lambda I $ for each of those numbers λ—it should not be invertible.