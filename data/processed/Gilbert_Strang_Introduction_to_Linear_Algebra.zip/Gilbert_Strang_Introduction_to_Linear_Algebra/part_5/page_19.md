## The Big Formula for Determinants

Pivots are good for computing. They concentrate a lot of information—enough to find the determinant. But it is hard to connect them to the original  $ a_{ij} $. That part will be clearer if we go back to rules 1-2-3, linearity and sign reversal and  $ \det I = 1 $. We want to derive a single explicit formula for the determinant, directly from the entries  $ a_{ij} $.

The formula has n! terms. Its size grows fast because n! = 1, 2, 6, 24, 120, …. For n = 11 there are about forty million terms. For n = 2, the two terms are ad and bc. Half the terms have minus signs (as in -bc). The other half have plus signs (as in ad). For n = 3 there are 3! = (3)(2)(1) terms. Here are those six terms:

 $$ \begin{aligned}&3by3\\&determinant\\&\begin{vmatrix}&a_{11}&a_{12}&a_{13}\\&a_{21}&a_{22}&a_{23}\\&a_{31}&a_{32}&a_{33}\end{vmatrix}=\begin{vmatrix}\\ &+a_{11}a_{22}a_{33}+a_{12}a_{23}a_{31}+a_{13}a_{21}a_{32}\\&-a_{11}a_{23}a_{32}-a_{12}a_{21}a_{33}-a_{13}a_{22}a_{31}.\\ &\end{vmatrix}\\ \end{aligned} $$ 

Notice the pattern. Each product like  $ a_{11}a_{23}a_{32} $ has one entry from each row. It also has one entry from each column. The column order 1, 3, 2 means that this particular term comes with a minus sign. The column order 3, 1, 2 in  $ a_{13}a_{21}a_{32} $ has a plus sign (boldface). It will be “permutations” that tell us the sign.

The next step  $ (n = 4) $ brings  $ 4! = 24 $ terms. There are 24 ways to choose one entry from each row and column. Down the main diagonal,  $ a_{11}a_{22}a_{33}a_{44} $ with column order 1, 2, 3, 4 always has a plus sign. That is the “identity permutation”.

To derive the big formula I start with n = 2. The goal is to reach ad−bc in a systematic way. Break each row into two simpler rows:

 $$ \left[\begin{matrix}{a}&{b}\\ \end{matrix}\right]=\left[\begin{matrix}{a}&{0}\\ \end{matrix}\right]+\left[\begin{matrix}{0}&{b}\\ \end{matrix}\right]\qquad\mathrm{a n d}\qquad\left[\begin{matrix}{c}&{d}\\ \end{matrix}\right]=\left[\begin{matrix}{c}&{0}\\ \end{matrix}\right]+\left[\begin{matrix}{0}&{d}\\ \end{matrix}\right]. $$ 

Now apply linearity, first in row 1 (with row 2 fixed) and then in row 2 (with row 1 fixed):

 $$ \begin{aligned}\begin{vmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{vmatrix}&=\begin{vmatrix}{{{a}}}&{{{0}}} \\{{{c}}}&{{{d}}}\end{vmatrix}+\begin{vmatrix}{{{0}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{vmatrix}&(break up row1)\\ &=\begin{vmatrix}{{{a}}}&{{{0}}} \\{{{c}}}&{{{0}}}\end{vmatrix}+\begin{vmatrix}{{{a}}}&{{{0}}} \\{{{0}}}&{{{d}}}\end{vmatrix}+\begin{vmatrix}{{{0}}}&{{{b}}} \\{{{c}}}&{{{0}}}\end{vmatrix}+\begin{vmatrix}{{{0}}}&{{{b}}} \\{{{0}}}&{{{d}}}\end{vmatrix}&(break up row2).\end{aligned} $$ 

The last line has  $ 2^2 = 4 $ determinants. The first and fourth are zero because one row is a multiple of the other row. We are left with  $ 2! = 2 $ determinants to compute:

 $$ \left|\begin{matrix}{{{a}}}&{{{0}}} \\{{{0}}}&{{{d}}}\end{matrix}\right|+\left|\begin{matrix}{{{0}}}&{{{b}}} \\{{{c}}}&{{{0}}}\end{matrix}\right|=ad\left|\begin{matrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{matrix}\right|+bc\left|\begin{matrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{matrix}\right|=ad-bc. $$ 

The splitting led to permutation matrices. Their determinants give a plus or minus sign. The permutation tells the column sequence. In this case the column order is  $ (1, 2) $ or  $ (2, 1) $.

Now try $n = 3$. Each row splits into 3 simpler rows like $[a_{11} \quad 0 \quad 0]$. Using linearity in each row, det $A$ splits into $3^3 = 27$ simple determinants. If a column choice is repeated—for example if we also choose the row $[a_{21} \quad 0 \quad 0]$—then the simple determinant is zero.