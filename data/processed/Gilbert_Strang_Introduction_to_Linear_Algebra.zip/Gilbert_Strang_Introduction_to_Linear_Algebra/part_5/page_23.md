The determinant is the dot product of any row i of A with its cofactors using other rows:

COFACTOR FORMULA

 $$ \det A=a_{i1}C_{i1}+a_{i2}C_{i2}+\cdots+a_{in}C_{in}. $$ 

Each cofactor  $ C_{ij} $ (order n - 1, without row i and column j) includes its correct sign:

Cofactor

 $$ C_{i j}=(-1)^{i+j}\operatorname*{d e t}M_{i j}. $$ 

A determinant of order n is a combination of determinants of order n - 1. A recursive person would keep going. Each subdeterminant breaks into determinants of order n - 2. We could define all determinants via equation (12). This rule goes from order n to n - 1 to n - 2 and eventually to order 1. Define the 1 by 1 determinant  $ |a| $ to be the number a. Then the cofactor method is complete.

We preferred to construct  $ \det A $ from its properties (linearity, sign reversal,  $ \det I = 1 $). The big formula (8) and the cofactor formulas (10)–(12) follow from those rules. One last formula comes from the rule that  $ \det A = \det A^T $. We can expand in cofactors, down a column instead of across a row. Down column j the entries are  $ a_{1j} $ to  $ a_{nj} $. The cofactors are  $ C_{1j} $ to  $ C_{nj} $. The determinant is the dot product:

Cofactors down column j

 $$ \det A=a_{1j}C_{1j}+a_{2j}C_{2j}+\cdots+a_{nj}C_{nj}. $$ 

Cofactors are useful when matrices have many zeros—as in the next examples.

Example 6 The -1, 2, -1 matrix has only two nonzeros in its first row. So only two cofactors  $ C_{11} $ and  $ C_{12} $ are involved in the determinant. I will highlight  $ C_{12} $:

 $$ \begin{aligned}\left|\begin{matrix}{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}} \\\end{matrix}\right|&=2\left|\begin{matrix}{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}} \\\end{matrix}\right|-\left(-1\right)\left|\begin{matrix}{{{-1}}}&{{{-1}}} \\{{{2}}}&{{{-1}}} \\{{{-1}}}&{{{2}}} \\\end{matrix}\right|.\end{aligned} $$ 

You see 2 times  $ C_{11} $ first on the right, from crossing out row 1 and column 1. This cofactor  $ C_{11} $ has exactly the same -1, 2, -1 pattern as the original A—but one size smaller.

To compute the boldface  $ C_{12} $, use cofactors down its first column. The only nonzero is at the top. That contributes another -1 (so we are back to minus). Its cofactor is the -1, 2, -1 determinant which is 2 by 2, two sizes smaller than the original A.

Summary Each determinant  $ D_{n} $ of order n comes from  $ D_{n-1} $ and  $ D_{n-2} $:

 $$ D_{4}=2D_{3}-D_{2}\qquad\mathrm{a n d~g e n e r a l l y}\qquad D_{n}=2D_{n-1}-D_{n-2}. $$ 

Direct calculation gives $D_{2}=3$ and $D_{3}=4$. Equation (14) has $D_{4}=2(4)-3=5$. These determinants 3, 4, 5 fit the formula $D_{n}=n+1$. Then $D_{n}$ equals $2n-(n-1)$. That “special tridiagonal answer” also came from the product of pivots in Example 2.