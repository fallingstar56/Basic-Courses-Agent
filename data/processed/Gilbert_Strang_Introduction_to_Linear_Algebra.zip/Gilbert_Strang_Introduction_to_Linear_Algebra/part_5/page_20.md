We pay attention only when the entries  $ a_{ij} $ come from different columns, like  $ (3, 1, 2) $:

 $$ \begin{aligned}&a_{11}\quad&\begin{vmatrix} \\{{{a_{12}}}}&{{{a_{13}}}} \\{{{a_{22}}}}&{{{a_{23}}}} \\\end{vmatrix}=&\begin{vmatrix} \\{{{a_{11}}}} \\{{{a_{22}}}} \\\end{vmatrix}+&\begin{vmatrix} \\{{{a_{12}}}} \\{{{a_{23}}}} \\\end{vmatrix}+&\begin{vmatrix} \\{{{a_{13}}}} \\{{{a_{21}}}} \\\end{vmatrix}\\&\begin{vmatrix} \\{{{a_{33}}}} \\\end{vmatrix}&a_{31}&a_{32}\\&\end{vmatrix}\\ &Six terms&+&\begin{vmatrix} \\{{{a_{11}}}} \\{{{a_{23}}}} \\\end{vmatrix}+&\begin{vmatrix} \\{{{a_{12}}}} \\{{{a_{21}}}} \\\end{vmatrix}+&\begin{vmatrix} \\{{{a_{13}}}} \\{{{a_{22}}}} \\\end{vmatrix}.\\&\end{aligned} $$ 

There are 3! = 6 ways to order the columns, so six determinants. The six permutations of  $ (1, 2, 3) $ include the identity permutation  $ (1, 2, 3) $ from P = I.

 $$ \begin{array}{r}{\mathrm{C o l u m n~n u m b e r s}=(1,2,3),(2,3,1),(3,1,2),(1,3,2),(2,1,3),(3,2,1).}\end{array} $$ 

The last three are odd permutations (one exchange). The first three are even permutations (0 or 2 exchanges). When the column sequence is  $ (3, 1, 2) $, we have chosen the entries  $ a_{13}a_{21}a_{32} $—that particular column sequence comes with a plus sign (2 exchanges). The determinant of A is now split into six simple terms. Factor out the  $ a_{ij} $:

 $$ \begin{aligned}\det A&=a_{11}a_{22}a_{33}\begin{vmatrix}{{{1}}} \\{{{1}}} \\{{{1}}}\end{vmatrix}+a_{12}a_{23}a_{31}\begin{vmatrix}{{{1}}} \\{{{1}}} \\{{{1}}}\end{vmatrix}+a_{13}a_{21}a_{32}\begin{vmatrix}{{{1}}} \\{{{1}}} \\{{{1}}}\end{vmatrix}\\&\quad+a_{11}a_{23}a_{32}\begin{vmatrix}{{{1}}} \\{{{1}}} \\{{{1}}}\end{vmatrix}+a_{12}a_{21}a_{33}\begin{vmatrix}{{{1}}} \\{{{1}}} \\{{{1}}}\end{vmatrix}+a_{13}a_{22}a_{31}\begin{vmatrix}{{{1}}} \\{{{1}}} \\{{{1}}}\end{vmatrix}.\end{aligned} $$ 

The first three (even) permutations have  $ \det P = +1 $, the last three (odd) permutations have  $ \det P = -1 $. We have proved the 3 by 3 formula in a systematic way.

Now you can see the $n$ by $n$ formula. There are $n!$ orderings of the columns. The columns $(1,2,\ldots,n)$ go in each possible order $(\alpha,\beta,\ldots,\omega)$. Taking $a_{1\alpha}$ from row 1 and $a_{2\beta}$ from row 2 and eventually $a_{nw}$ from row $n$, the determinant contains the product $a_{1\alpha}a_{2\beta}\cdots a_{nw}$ times +1 or -1. Half the column orderings have sign -1.

The determinant of $A$ is the sum of these $n!$ simple determinants, times 1 or -1. The simple determinants $a_{1\alpha}a_{2\beta}\cdots a_{n\omega}$ choose one entry from every row and column. For 5 by 5, the term $a_{15}a_{22}a_{33}a_{44}a_{51}$ would have $\det P = -1$ from exchanging 5 and 1.

 $$ \begin{aligned}det A&=sum over all\mathbf{n}!column permutations P=(\alpha,\beta,\cdots,\omega)\\&=\sum(det P)a_{1\alpha}a_{2\beta}\cdots a_{n\omega}=BIG FORMULA.\end{aligned} $$ 

The 2 by 2 case is +a11a22 − a12a21 (which is ad − bc). Here P is (1, 2) or (2, 1).