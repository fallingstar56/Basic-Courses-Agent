When you separate out the factor  $ a_{11} $ or  $ a_{12} $ or  $ a_{1\alpha} $ that comes from the first row, you see linearity. For 3 by 3, separate the usual 6 terms of the determinant into 3 pairs:

 $$ \det A=a_{11}\left(a_{22}a_{33}-a_{23}a_{32}\right)+a_{12}\left(a_{23}a_{31}-a_{21}a_{33}\right)+a_{13}\left(a_{21}a_{32}-a_{22}a_{31}\right). $$ 

Those three quantities in parentheses are called “cofactors”. They are 2 by 2 determinants, from rows 2 and 3. The first row contributes the factors  $ a_{11}, a_{12}, a_{13} $. The lower rows contribute the cofactors  $ C_{11}, C_{12}, C_{13} $. Certainly the determinant  $ a_{11}C_{11} + a_{12}C_{12} + a_{13}C_{13} $ depends linearly on  $ a_{11}, a_{12}, a_{13} $—this is Rule 3.

The cofactor of  $ a_{11} $ is  $ C_{11} = a_{22}a_{33} - a_{23}a_{32} $. You can see it in this splitting:

 $$ \begin{array}{l l l l l l l l } a_{11}&a_{12}&a_{13}&&&a_{11}&&&a_{12}\\ a_{21}&a_{22}&a_{23}&=&a_{22}&a_{23}&+&a_{21}&a_{23}&+&a_{21}&a_{22}\\ a_{31}&a_{32}&a_{33}&&a_{32}&a_{33}&&&a_{31}&a_{33}&&a_{31}&a_{32}\end{array}． $$ 

We are still choosing one entry from each row and column. Since  $ a_{11} $ uses up row 1 and column 1, that leaves a 2 by 2 determinant as its cofactor.

As always, we have to watch signs. The 2 by 2 determinant that goes with  $ a_{12} $ looks like  $ a_{21}a_{33} - a_{23}a_{31} $. But in the cofactor  $ C_{12} $, its sign is reversed. Then  $ a_{12}C_{12} $ is the correct 3 by 3 determinant. The sign pattern for cofactors along the first row is plus-minus-plus-minus. You cross out row 1 and column j to get a submatrix  $ M_{1j} $ of size  $ n - 1 $. Multiply its determinant by the sign  $ (-1)^{1+j} $ to get the cofactor:

 $$  The cofactors along row 1 are C_{1j}=(-1)^{1+j}\det M_{1j}. $$ 

 $$ \mathrm{T h e~c o f a c t o r~e x p a n s i o n~i s~d e t~}A=a_{11}C_{11}+a_{12}C_{12}+\cdots+a_{1n}C_{1n}. $$ 

In the big formula (8), the terms that multiply  $ a_{11} $ combine to give  $ C_{11} = \det M_{11} $. The sign is  $ (-1)^{1+1} $, meaning plus. Equation (11) is another form of equation (8) and also equation (10), with factors from row 1 multiplying cofactors that use only the other rows.

Note Whatever is possible for row 1 is possible for row i. The entries  $ a_{ij} $ in that row also have cofactors  $ C_{ij} $. Those are determinants of order  $ n - 1 $, multiplied by  $ (-1)^{i+j} $. Since  $ a_{ij} $ accounts for row  $ i $ and column  $ j $, the submatrix  $ M_{ij} $ throws out row  $ i $ and column  $ j $. The display shows  $ a_{43} $ and  $ M_{43} $ (with row 4 and column 3 removed). The sign  $ (-1)^{4+3} $ multiplies the determinant of  $ M_{43} $ to give  $ C_{43} $. The sign matrix shows the  $ \pm $ pattern:

 $$ \begin{aligned}A&=\begin{bmatrix}\bullet&\bullet&\bullet\\ \bullet&\bullet&\bullet\\ \bullet&\bullet&\bullet\\ &a_{43}\end{bmatrix}\qquad signs(-1)^{i+j}=\begin{bmatrix}+&-&+&-\\ &-&-&+\\ &+&-&-\\ &-&-&+\\ \end{bmatrix}.\end{aligned} $$ 