17 The matrix  $ B_n $ is the  $ -1, 2, -1 $ matrix  $ A_n $ except that  $ b_{11} = 1 $ instead of  $ a_{11} = 2 $. Using cofactors of the last row of  $ B_4 $ show that  $ |B_4| = 2|B_3| - |B_2| = 1 $.

 $$ B_{4}=\begin{bmatrix}1&-1&&\\ -1&2&-1&\\ &-1&2&-1&\\ &&-1&2\end{bmatrix}\quad B_{3}=\begin{bmatrix}1&-1&&\\ -1&2&-1&\\ &-1&2\end{bmatrix}\quad B_{2}=\begin{bmatrix}1&-1\\ -1&2\end{bmatrix}. $$ 

The recursion  $ |B_n| = 2|B_{n-1}| - |B_{n-2}| $ is satisfied when every  $ |B_n| = 1 $. This recursion is the same as for the  $ A' $s in Example 6. The difference is in the starting values 1, 1, 1 for the determinants of sizes  $ n = 1, 2, 3 $.

Go back to  $ B_n $ in Problem 17. It is the same as  $ A_n $ except for  $ b_{11} = 1 $. So use linearity in the first row, where  $ [1 - 10] $ equals  $ [2 - 10] $ minus  $ [100] $:

 $$ \left|\boldsymbol{B}_{n}\right|=\left|\begin{array}{ccc}{{{1}}}&{{{-1}}}&{{{0}}} \\{{{-1}}} \\{{{A_{n-1}}}} \\\end{array}\right|=\left|\begin{array}{ccc}{{{2}}}&{{{-1}}}&{{{0}}} \\{{{-1}}} \\{{{A_{n-1}}}} \\\end{array}\right|-\left|\begin{array}{ccc}{{{1}}}&{{{0}}}&{{{0}}} \\{{{-1}}} \\{{{A_{n-1}}}} \\\end{array}\right|. $$ 

Linearity gives  $ |B_n| = |A_n| - |A_{n-1}| = \_\_\_ $.

Explain why the 4 by 4 Vandermonde determinant contains  $ x^{3} $ but not  $ x^{4} $ or  $ x^{5} $:

 $$ V_{4}=\det\begin{bmatrix}1&a&a^{2}&a^{3}\\1&b&b^{2}&b^{3}\\1&c&c^{2}&c^{3}\\1&x&x^{2}&x^{3}\end{bmatrix}. $$ 

The determinant is zero at  $ x = \underline{\quad} $,  $ \underline{\quad} $, and  $ \underline{\quad} $. The cofactor of  $ x^{3} $ is  $ V_{3} = (b - a)(c - a)(c - b) $. Then  $ V_{4} = (b - a)(c - a)(c - b)(x - a)(x - b)(x - c) $.

Find G2 and G3 and then by row operations G4. Can you predict Gn?

 $$ G_{2}=\left|\begin{array}{l l}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{array}\right|\qquad G_{3}=\left|\begin{array}{l l l}{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}}\end{array}\right|\qquad G_{4}=\left|\begin{array}{l l l l}{{{0}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{0}}}\end{array}\right|. $$ 

21 Compute $S_{1}, S_{2}, S_{3}$ for these 1, 3, 1 matrices. By Fibonacci guess and check $S_{4}$.

 $$ S_{1}=\left|3\right|\quad S_{2}=\left|\begin{matrix}{{{3}}}&{{{1}}} \\{{{1}}}&{{{3}}}\end{matrix}\right|\quad S_{3}=\left|\begin{matrix}{{{3}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{3}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{3}}}\end{matrix}\right| $$ 

Change 3 to 2 in the upper left corner of the matrices in Problem 21. Why does that subtract  $ S_{n-1} $ from the determinant  $ S_n $? Show that the determinants of the new matrices become the Fibonacci numbers 2, 5, 13 (always  $ F_{2n+1} $).