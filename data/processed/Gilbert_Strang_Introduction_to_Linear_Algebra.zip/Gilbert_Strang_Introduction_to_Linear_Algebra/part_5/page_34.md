The i, j entry of  $ A^{-1} $ is the cofactor  $ C_{ji} $ (not  $ C_{ij} $) divided by  $ \det A $:

FORMULA FOR

 $$ A^{-1} $$ 

 $$ (A^{-1})_{ij}=\frac{C_{ji}}{\det A}\qquad and\qquad A^{-1}=\frac{C^{\mathrm{T}}}{\det A}. $$ 

The cofactors  $ C_{ij} $ go into the “cofactor matrix” C. The transpose of C leads to  $ A^{-1} $. To compute the  $ i,j $ entry of  $ A^{-1} $, cross out row  $ j $ and column  $ i $ of A. Multiply the determinant by  $ (-1)^{i+j} $ to get the cofactor  $ C_{ji} $, and divide by det A.

Check this rule for the 3, 1 entry of  $ A^{-1} $. For column 1 we solve  $ Ax = (1,0,0) $. The third component  $ x_{3} $ needs the third determinant in equation (5), divided by  $ \det A $. That determinant is exactly the cofactor  $ C_{13} = a_{21}a_{32} - a_{22}a_{31} $. So  $ (A^{-1})_{31} = C_{13}/\det A $.

Summary In solving  $ AA^{-1} = I $, each column of I leads to a column of  $ A^{-1} $. Every entry of  $ A^{-1} $ is a ratio: determinant of size  $ n - 1 $ / determinant of size  $ n $.

Direct proof of the formula  $ A^{-1} = C^{\mathrm{T}}/\det A $ This means  $ AC^{\mathrm{T}} = (\det A)I $:

 $$ \begin{bmatrix}a_{11}&a_{12}&a_{13}\\ a_{21}&a_{22}&a_{23}\\ a_{31}&a_{32}&a_{33}\end{bmatrix}\begin{bmatrix}C_{11}&C_{21}&C_{31}\\ C_{12}&C_{22}&C_{32}\\ C_{13}&C_{23}&C_{33}\end{bmatrix}=\begin{bmatrix}\det A&&0&&0\\ 0&&\det A&&0\\ 0&&0&&\det A\end{bmatrix}. $$ 

(Row 1 of A) times (column 1 of  $ C^{T} $) yields the first det A on the right:

 $$ a_{11}C_{11}+a_{12}C_{12}+a_{13}C_{13}=\det A\quad This is exactly the cofactor rule! $$ 

Similarly row 2 of A times column 2 of  $ C^{\mathrm{T}} $ (notice the transpose) also yields det A. The entries  $ a_{2j} $ are multiplying cofactors  $ C_{2j} $ as they should, to give the determinant.

How to explain the zeros off the main diagonal in equation (7)? The rows of A are multiplying cofactors from different rows. Why is the answer zero?

Row 2 of A

Row 1 of C

 $$ a_{21}C_{11}+a_{22}C_{12}+a_{23}C_{13}=0. $$ 

Answer: This is the cofactor rule for a new matrix, when the second row of  $ A $ is copied into its first row. The new matrix  $ A^* $ has two equal rows, so  $ \det A^* = 0 $ in equation (8). Notice that  $ A^* $ has the same cofactors  $ C_{11}, C_{12}, C_{13} $ as  $ A $—because all rows agree after the first row. Thus the remarkable multiplication (7) is correct:

 $$ \boldsymbol{A}\boldsymbol{C}^{\mathrm{T}}=(\det\boldsymbol{A})\boldsymbol{I}\qquad or\qquad\boldsymbol{A}^{-1}=\frac{\boldsymbol{C}^{\mathrm{T}}}{\det\boldsymbol{A}}. $$ 