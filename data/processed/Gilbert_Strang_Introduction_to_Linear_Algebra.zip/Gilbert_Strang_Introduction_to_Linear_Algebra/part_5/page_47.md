# Eigenvalues and Eigenvectors

### 6.1 Introduction to Eigenvalues

1 An eigenvector x lies along the same line as Ax :  $ \underline{Ax = \lambda x} $. The eigenvalue is  $ \lambda $.
2 If Ax =  $ \lambda x $ then  $ A^2 x = \lambda^2 x $ and  $ A^{-1} x = \lambda^{-1} x $ and  $ (A + cI) x = (\lambda + c) x $: the same x.
3 If Ax =  $ \lambda x $ then  $ (A - \lambda I) x = 0 $ and  $ A - \lambda I $ is singular and  $ \underline{\text{det(A - \lambda I) = 0}} $. n eigenvalues.
4 Check  $ \lambda $s by  $ \det A = (\lambda_1)(\lambda_2) \cdots (\lambda_n) $ and diagonal sum  $ a_{11} + a_{22} + \cdots + a_{nn} = \sum of \lambda's $.
5 Projections have  $ \lambda = 1 $ and 0. Reflections have 1 and -1. Rotations have  $ e^{i\theta} $ and  $ e^{-i\theta} $: complex!

This chapter enters a new part of linear algebra. The first part was about  $ Ax = b $: balance and equilibrium and steady state. Now the second part is about  $ \text{change} $. Time enters the picture—continuous time in a differential equation  $ \frac{du}{dt} = Au $ or time steps in a difference equation  $ u_{k+1} = Au_k $. Those equations are NOT solved by elimination.

The key idea is to avoid all the complications presented by the matrix A. Suppose the solution vector  $ \boldsymbol{u}(t) $ stays in the direction of a fixed vector  $ \boldsymbol{x} $. Then we only need to find the number (changing with time) that multiplies  $ \boldsymbol{x} $. A number is easier than a vector. We want “eigenvectors”  $ \boldsymbol{x} $ that don’t change direction when you multiply by A.

A good model comes from the powers  $ A, A^{2}, A^{3}, \ldots $ of a matrix. Suppose you need the hundredth power  $ A^{100} $. Its columns are very close to the eigenvector  $ (.6, .4) $:

 $$ A,A^{2},A^{3}=\begin{bmatrix}0.8&0.3\\ 0.2&0.7\end{bmatrix}\quad\begin{bmatrix}0.70&0.45\\ 0.30&0.55\end{bmatrix}\quad\begin{bmatrix}0.650&0.525\\ 0.350&0.475\end{bmatrix}\quad A^{100}\approx\begin{bmatrix}0.6000&0.6000\\ 0.4000&0.4000\end{bmatrix} $$ 

 $ A^{100} $ was found by using the eigenvalues of A, not by multiplying 100 matrices. Those eigenvalues (here they are  $ \lambda = 1 $ and  $ 1/2 $) are a new way to see into the heart of a matrix.