<div style="text-align: center;"><img src="imgs/img_in_image_box_198_125_920_442.jpg" alt="Image" width="67%" /></div>


<div style="text-align: center;">Figure 6.1: The eigenvectors keep their directions.  $ A^2x = \lambda^2x $ with  $ \lambda^2 = 1^2 $ and  $ (.5)^2 $.</div>


When we multiply separately for x1 and ( .2) x2, A multiplies x2 by its eigenvalue 12:

 $$ \mathbf{M}\mathbf{u}t i p l y\mathbf{e}a c h x_{i}\mathbf{b}y\lambda_{i}\quad A\begin{bmatrix}.8\\ .2\end{bmatrix}\quad\mathbf{i}\mathbf{s}\quad x_{1}+\frac{1}{2}(.2)x_{2}=\begin{bmatrix}.6\\ .4\end{bmatrix}+\begin{bmatrix}.1\\ -.1\end{bmatrix}=\begin{bmatrix}.7\\ .3\end{bmatrix}. $$ 

Each eigenvector is multiplied by its eigenvalue, when we multiply by A. At every step  $ x_{1} $ is unchanged and  $ x_{2} $ is multiplied by  $ \left(\frac{1}{2}\right) $, so 99 steps give the small number  $ \left(\frac{1}{2}\right)^{99} $:

 $$ \left|\begin{array}{r l}{A^{99}\left[\begin{array}{l}{.8}\\ {.2}\end{array}\right]}&{\mathrm{i s~r e a l l y}\quad\boldsymbol{x}_{1}+(.2)\left(\frac{1}{2}\right)^{99}\boldsymbol{x}_{2}=\left[\begin{matrix}{.6}\\ {.4}\end{matrix}\right]+\left[\begin{matrix}{\mathrm{v e r y}}\\ {\mathrm{s m a l l}}\\ {\mathrm{v e c t o r}}\end{matrix}\right].}\end{array}\right. $$ 

This is the first column of  $ A^{100} $. The number we originally wrote as .6000 was not exact. We left out  $ (.2)(\frac{1}{2})^{99} $ which wouldn’t show up for 30 decimal places.

The eigenvector  $ x_1 $ is a “steady state” that doesn’t change (because  $ \lambda_1 = 1 $). The eigenvector  $ x_2 $ is a “decaying mode” that virtually disappears (because  $ \lambda_2 = .5 $). The higher the power of  $ A $, the more closely its columns approach the steady state.

This particular A is a Markov matrix. Its largest eigenvalue is  $ \lambda = 1 $. Its eigenvector  $ \boldsymbol{x}_1 = (0, 4) $ is the steady state—which all columns of  $ A^k $ will approach. Section 10.3 shows how Markov matrices appear when you search with Google.

For projection matrices P, we can see when Px is parallel to x. The eigenvectors for  $ \lambda = 1 $ and  $ \lambda = 0 $ fill the column space and nullspace. The column space doesn't move  $ (Px = x) $. The nullspace goes to zero  $ (Px = 0x) $.