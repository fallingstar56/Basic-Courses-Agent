7 If Q has orthonormal columns, what is the least squares solution  $ \hat{x} $ to  $ Qx = b $?

8 If $q_{1}$ and $q_{2}$ are orthonormal vectors in $\mathbf{R}^{5}$, what combination ___ $q_{1} +$ ___ $q_{2}$ is closest to a given vector $b$?

(a) Compute  $ P = QQ^{\mathrm{T}} $ when  $ q_{1} = (0.8, 0.6, 0) $ and  $ q_{2} = (-0.6, 0.8, 0) $. Verify that  $ P^{2} = P $.

(b) Prove that always  $ (QQ^{\mathrm{T}})^{2} = QQ^{\mathrm{T}} $ by using  $ Q^{\mathrm{T}}Q = I $. Then  $ P = QQ^{\mathrm{T}} $ is the projection matrix onto the column space of Q.

10 Orthonormal vectors are automatically linearly independent.

(a) Vector proof: When  $ c_{1}q_{1}+c_{2}q_{2}+c_{3}q_{3}=0 $, what dot product leads to  $ c_{1}=0 $?

Similarly  $ c_{2}=0 $ and  $ c_{3}=0 $. Thus the q's are independent.

(b) Matrix proof: Show that  $ Qx = 0 $ leads to x = 0. Since Q may be rectangular, you can use  $ Q^{\mathrm{T}} $ but not  $ Q^{-1} $.

(a) Gram-Schmidt: Find orthonormal vectors  $ q_{1} $ and  $ q_{2} $ in the plane spanned by  $ \boldsymbol{a} = (1, 3, 4, 5, 7) $ and  $ \boldsymbol{b} = (-6, 6, 8, 0, 8) $.

(b) Which vector in this plane is closest to  $ (1,0,0,0,0) $?

12 If  $ a_{1}, a_{2}, a_{3} $ is a basis for  $ R^{3} $, any vector b can be written as

 $$ \boldsymbol{b}=x_{1}\boldsymbol{a}_{1}+x_{2}\boldsymbol{a}_{2}+x_{3}\boldsymbol{a}_{3}\qquad or\qquad\left[\begin{aligned}\\ &a_{1}\quad a_{2}\quad a_{3}\\ &\end{aligned}\right]\begin{bmatrix}x_{1}\\ x_{2}\\ x_{3}\end{bmatrix}=\boldsymbol{b}.\\ \end{aligned} $$ 

(a) Suppose the  $ a' $s are orthonormal. Show that  $ x_1 = a_1^T b $.

(b) Suppose the  $ a' $s are orthogonal. Show that  $ x_1 = a_1^T b / a_1^T a_1 $.

(c) If the  $ a' $s are independent,  $ x_{1} $ is the first component of ___ times b.

## Problems 13–25 are about the Gram-Schmidt process and A = QR

13 What multiple of  $ a = \left[\begin{array}{c} 1 \\ 1 \end{array}\right] $ should be subtracted from  $ b = \left[\begin{array}{c} 4 \\ 0 \end{array}\right] $ to make the result B orthogonal to  $ a $? Sketch a figure to show  $ a, b, $ and  $ B $.

14 Complete the Gram-Schmidt process in Problem 13 by computing  $ q_1 = a / \|a\| $ and  $ q_2 = B / \|B\| $ and factoring into QR:

 $$ \begin{bmatrix}{{{1}}}&{{{4}}} \\{{{1}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{q_{1}}}}&{{{q_{2}}}} \\{{{q_{1}}}}&{{{q_{2}}}}\end{bmatrix}\begin{bmatrix}{{{\|a\|}}}&{{{?}}} \\{{{0}}}&{{{\|B\|}}}\end{bmatrix}. $$ 