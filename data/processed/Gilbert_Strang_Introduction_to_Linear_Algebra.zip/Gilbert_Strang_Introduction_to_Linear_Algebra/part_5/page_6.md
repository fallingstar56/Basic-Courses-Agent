## Chapter 5

## Determinants

1 The determinant of  $ A = \begin{bmatrix} a & b \\ c & d \end{bmatrix} $ is  $ ad - bc $. Singular matrix  $ A = \begin{bmatrix} a & xa \\ c & xc \end{bmatrix} $ has  $ \det = 0 $.

2 Row exchange reverses signs  $ PA = \begin{bmatrix} 0 & 1 \\ 1 & 0 \end{bmatrix} \begin{bmatrix} a & b \\ c & d \end{bmatrix} = \begin{bmatrix} c & d \\ a & b \end{bmatrix} $ has  $ \det PA = bc - ad = -\det A $.

3 The determinant of  $ \begin{bmatrix} xa + yA & xb + yB \\ c & d \end{bmatrix} $ is  $ x(ad - bc) + y(Ad - Bc) $.  $ \det $ is linear in row 1 by itself.

4 Elimination  $ EA = \begin{bmatrix} a & b \\ 0 & d - \frac{c}{a}b \end{bmatrix} $  $ \det EA = a \left(d - \frac{c}{a}b\right) = product of pivots = \det A $.

5 If  $ A $ is  $ n $ by  $ n $ then 1, 2, 3, 4 remain true:  $ \det = 0 $ when  $ A $ is singular,  $ \det $ reverses sign when rows are exchanged,  $ \det $ is linear in row 1 by itself,  $ \det = product of the pivots $. Always  $ \det BA = (\det B)(\det A) $ and  $ \det A^T = \det A $. This is an amazing number.

### 5.1 The Properties of Determinants

The determinant of a square matrix is a single number. That number contains an amazing amount of information about the matrix. It tells immediately whether the matrix is invertible. The determinant is zero when the matrix has no inverse. When A is invertible, the determinant of  $ A^{-1} $ is  $ 1/(\det A) $. If  $ \det A = 2 $ then  $ \det A^{-1} = \frac{1}{2} $. In fact the determinant leads to a formula for every entry in  $ A^{-1} $.

This is one use for determinants—to find formulas for inverse matrices and pivots and solutions  $ A^{-1}b $. For a large matrix we seldom use those formulas, because elimination is faster. For a 2 by 2 matrix with entries  $ a, b, c, d $, its determinant  $ ad - bc $ shows how  $ A^{-1} $ changes as  $ A $ changes. Notice the division by the determinant!

 $$ A=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}\quad has inverse\quad A^{-1}=\frac{1}{ad-bc}\begin{bmatrix}{{{d}}}&{{{-b}}} \\{{{-c}}}&{{{a}}}\end{bmatrix}. $$ 