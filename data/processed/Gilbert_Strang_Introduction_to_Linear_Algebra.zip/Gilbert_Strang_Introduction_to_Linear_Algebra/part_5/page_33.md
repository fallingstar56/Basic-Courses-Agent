Those determinants of A, B1, B2 are −2 and −4 and 2. All ratios divide by det A = −2:

 $$ \mathbf{Find}\ x=A^{-1}b\quad\ x_{1}=\frac{-4}{-2}=2\quad x_{2}=\frac{2}{-2}=-1\quad Check\left[\begin{array}{cc}{{{3}}}&{{{4}}} \\{{{5}}}&{{{6}}}\end{array}\right]\left[\begin{array}{c}{{{2}}} \\{{{-1}}}\end{array}\right]=\left[\begin{array}{c}{{{2}}} \\{{{4}}}\end{array}\right] $$ 

CRAMER's RULE If det A is not zero, Ax = b is solved by determinants:

 $$ x_{1}=\frac{\det B_{1}}{\det A}\qquad x_{2}=\frac{\det B_{2}}{\det A}\qquad\cdots\qquad x_{n}=\frac{\det B_{n}}{\det A} $$ 

The matrix  $ B_{j} $ has the jth column of A replaced by the vector b.

To solve an n by n system, Cramer's Rule evaluates  $ n + 1 $ determinants (of A and the n different B's). When each one is the sum of  $ n! $ terms—applying the “big formula” with all permutations—this makes a total of  $ (n+1)! $ terms. It would be crazy to solve equations that way. But we do finally have an explicit formula for the solution x.

Example 2 Cramer’s Rule is inefficient for numbers but it is well suited to letters. For $n=2$, find the columns of $A^{-1}=[x\ y]$ by solving $AA^{-1}=I$:

 $$ \begin{array}{l}\mathbf{A}^{-1}\quad\left[\begin{array}{l l}a&b\\ c&d\end{array}\right]\left[\begin{array}{l}x_{1}\\ x_{2}\end{array}\right]=\left[\begin{array}{l}1\\ 0\end{array}\right]\quad\left[\begin{array}{l l}a&b\\ c&d\end{array}\right]\left[\begin{array}{l}y_{1}\\ y_{2}\end{array}\right]=\left[\begin{array}{l}0\\ 1\end{array}\right]\end{array} $$ 

Those share the same matrix A. We need |A| and four determinants for x1, x2, y1, y2:

 $$ \left|\begin{array}{cc}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}} \\\end{array}\right|\text{and}\left|\begin{array}{cc}{{{1}}}&{{{b}}} \\{{{0}}}&{{{d}}} \\\end{array}\right|\left|\begin{array}{cc}{{{a}}}&{{{1}}} \\{{{c}}}&{{{0}}} \\\end{array}\right|\left|\begin{array}{cc}{{{0}}}&{{{b}}} \\{{{1}}}&{{{d}}} \\\end{array}\right|\left|\begin{array}{cc}{{{a}}}&{{{0}}} \\{{{c}}}&{{{1}}} \\\end{array}\right| $$ 

The last four determinants are d, -c, -b, and a. (They are the cofactors!) Here is A−1:

 $$ x_{1}=\frac{d}{\left|A\right|},x_{2}=\frac{-c}{\left|A\right|},y_{1}=\frac{-b}{\left|A\right|},y_{2}=\frac{a}{\left|A\right|}\mathrm{a n d}\mathrm{t h e n}A^{-1}=\frac{1}{a d-b c}\left[\begin{array}{c c}d&-b\\ -c&a\end{array}\right]. $$ 

I chose 2 by 2 so that the main points could come through clearly. The new idea is:  $ A^{-1} $ involves the cofactors. When the right side is a column of the identity matrix I, as in  $ AA^{-1} = I $, the determinant of each  $ B_j $ in Cramer's Rule is a cofactor of A.

You can see those cofactors for n = 3. Solve Ax = (1, 0, 0) to find column 1 of A^{-1}.

Determinants of B's = Cofactors of A

 $$ \begin{array}{c|ccc|c|c|c|c}{s}&{1}&{a_{12}}&{a_{13}}&{a_{11}}&{1}&{a_{13}}&{a_{11}}&{a_{12}}&{1}\\{}&{0}&{a_{22}}&{a_{23}}&{a_{21}}&{0}&{a_{23}}&{a_{21}}&{a_{22}}&{0}\\{}&{0}&{a_{32}}&{a_{33}}&{a_{31}}&{0}&{a_{33}}&{a_{31}}&{a_{32}}&{0}\\\end{array} $$ 

That first determinant  $ |B_1| $ is the cofactor  $ C_{11} = a_{22}a_{33} - a_{23}a_{32} $. Then  $ |B_2| $ is the cofactor  $ C_{12} $. Notice that the correct minus sign appears in  $ -(a_{21}a_{33} - a_{23}a_{31}) $. This cofactor  $ C_{12} $ goes into column 1 of  $ A^{-1} $. When we divide by  $ \det A $, we have the inverse matrix!