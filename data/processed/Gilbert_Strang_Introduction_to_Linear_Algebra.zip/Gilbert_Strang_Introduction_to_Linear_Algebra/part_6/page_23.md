The eigenvalues of  $ A^{-1} $ are 1,  $ \frac{1}{5} $,  $ \frac{1}{5} $,  $ \frac{1}{5} $. The eigenvectors are not changed so  $ A^{-1} = H\Lambda^{-1}H^{-1} $. The inverse matrix is surprisingly neat:

 $$ \boldsymbol{A}^{-1}=\frac{1}{5}*(\mathbf{e}\mathbf{y}\mathbf{e}(4)+\mathbf{o n}\mathbf{e}\mathbf{s}(4))=\frac{1}{5}\left[\begin{array}{cccc}{{{2}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{2}}}\end{array}\right] $$ 

A is a rank-one change from 5I. So  $ A^{-1} $ is a rank-one change from I/5.

In a graph with 5 nodes, the determinant 125 counts the “spanning trees” (trees that touch all nodes). Trees have no loops (graphs and trees are in Section 10.1).

With 6 nodes, the matrix 6 * eye(5) - ones(5) has the five eigenvalues 1, 6, 6, 6, 6.

### Problem Set 6.2

Questions 1–7 are about the eigenvalue and eigenvector matrices  $ \Lambda $ and X.

1 (a) Factor these two matrices into  $ A = X \Lambda X^{-1} $:

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{3}}}\end{bmatrix}\qquad and\qquad A=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{3}}}&{{{3}}}\end{bmatrix}. $$ 

(b) If  $ A = X \Lambda X^{-1} $ then  $ A^{3} = (\quad)(\quad)(\quad) $ and  $ A^{-1} = (\quad)(\quad)(\quad) $.

2 If $A$ has $\lambda_{1} = 2$ with eigenvector $x_{1} = \begin{bmatrix} 1 \\ 0 \end{bmatrix}$ and $\lambda_{2} = 5$ with $x_{2} = \begin{bmatrix} 1 \\ 1 \end{bmatrix}$, use $X\Lambda X^{-1}$ to find $A$. No other matrix has the same $\lambda$'s and $x$'s.

Suppose $A = X\Lambda X^{-1}$. What is the eigenvalue matrix for $A + 2I$? What is the eigenvector matrix? Check that $A + 2I = (\quad)( \quad )^{-1}$.

4 True or false: If the columns of X (eigenvectors of A) are linearly independent, then

(a) A is invertible

(b) A is diagonalizable



(c) X is invertible (d) X is diagonalizable.

5 If the eigenvectors of A are the columns of I, then A is a ___ matrix. If the eigenvector matrix X is triangular, then  $ X^{-1} $ is triangular. Prove that A is also triangular.

6 Describe all matrices X that diagonalize this matrix A (find all eigenvectors):

 $$ \boldsymbol{A}=\begin{bmatrix}{{{4}}}&{{{0}}} \\{{{1}}}&{{{2}}}\end{bmatrix}. $$ 

Then describe all matrices that diagonalize  $ A^{-1} $

7 Write down the most general matrix that has eigenvectors  $ \begin{bmatrix} 1 \\ 1 \end{bmatrix} $ and  $ \begin{bmatrix} 1 \\ -1 \end{bmatrix} $.