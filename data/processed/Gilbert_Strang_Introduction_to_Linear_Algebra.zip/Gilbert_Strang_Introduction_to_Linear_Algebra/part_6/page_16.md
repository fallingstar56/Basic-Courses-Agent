#### 6.2. Diagonalizing a Matrix

This proof extends directly to $j$ eigenvectors. Suppose that $c_1 \boldsymbol{x}_1 + \cdots + c_j \boldsymbol{x}_j = \boldsymbol{0}$. Multiply by $A$, multiply by $\lambda_j$, and subtract. This multiplies $\boldsymbol{x}_j$ by $\lambda_j - \lambda_j = 0$, and $\boldsymbol{x}_j$ is gone. Now multiply by $A$ and by $\lambda_{j-1}$ and subtract. This removes $\boldsymbol{x}_{j-1}$. Eventually only $\boldsymbol{x}_1$ is left:

 $$ \begin{aligned}We reach\quad(\lambda_{1}-\lambda_{2})\cdots(\lambda_{1}-\lambda_{j})c_{1}\boldsymbol{x}_{1}=\mathbf{0}\quad which forces\quad c_{1}=0.\end{aligned} $$ 

Similarly every  $ c_i = 0 $. When the  $ \lambda $s are all different, the eigenvectors are independent. A full set of eigenvectors can go into the columns of the eigenvector matrix  $ X $.

Example 2 Powers of $A$ The Markov matrix $A = \begin{bmatrix} 8 & 3 \\ 2 & 7 \end{bmatrix}$ in the last section had $\lambda_1 = 1$ and $\lambda_2 = .5$. Here is $A = X \Lambda X^{-1}$ with those eigenvalues in the diagonal $\Lambda$:

Markov example

 $$ \begin{bmatrix}{{{.8}}}&{{{.3}}} \\{{{.2}}}&{{{.7}}}\end{bmatrix}=\begin{bmatrix}{{{.6}}}&{{{1}}} \\{{{.4}}}&{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{.5}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{.4}}}&{{{-.6}}}\end{bmatrix}=X\Lambda X^{-1}. $$ 

The eigenvectors  $ (.6, .4) $ and  $ (1, -1) $ are in the columns of X. They are also the eigenvectors of  $ A^2 $. Watch how  $ A^2 $ has the same X, and the eigenvalue matrix of  $ A^2 $ is  $ \Lambda^2 $:

Same X for  $ A^{2} $

 $$ A^{2}=X\Lambda X^{-1}X\Lambda X^{-1}=\begin{array}{r}X\Lambda^{2}X^{-1}.\end{array} $$ 

Just keep going, and you see why the high powers  $ A^{k} $ approach a “steady state”:

Powers of A

 $$ A^{k}=X\Lambda^{k}X^{-1}=\begin{bmatrix}{{{.6}}}&{{{1}}} \\{{{.4}}}&{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{1^{k}}}}&{{{0}}} \\{{{0}}}&{{{(.5)^{k}}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{.4}}}&{{{-.6}}}\end{bmatrix}. $$ 

As k gets larger, (.5) k gets smaller. In the limit it disappears completely. That limit is A∞:

Limit  $ k \rightarrow \infty $

 $$ \boldsymbol{A}^{\infty}=\begin{bmatrix}{{{.6}}}&{{{1}}} \\{{{.4}}}&{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{.4}}}&{{{-.6}}}\end{bmatrix}=\begin{bmatrix}{{{.6}}}&{{{.6}}} \\{{{.4}}}&{{{.4}}}\end{bmatrix}. $$ 

The limit has the eigenvector  $ \boldsymbol{x}_1 $ in both columns. We saw this  $ A^\infty $ on the very first page of Chapter 6. Now we see it coming from powers like  $ A^{100} = X\Lambda^{100}X^{-1} $.

Question When does  $ A^{k} \rightarrow zero matrix $?

Answer



 $$  All\mid\lambda\mid<1. $$ 

## Similar Matrices: Same Eigenvalues

Suppose the eigenvalue matrix  $ \Lambda $ is fixed. As we change the eigenvector matrix  $ X $, we get a whole family of different matrices  $ A = X\Lambda X^{-1} $—all with the same eigenvalues in  $ \Lambda $. All those matrices  $ A $ (with the same  $ \Lambda $) are called similar.

This idea extends to matrices that can’t be diagonalized. Again we choose one constant matrix $C$ (not necessarily $\Lambda$). And we look at the whole family of matrices $A = BCB^{-1}$, allowing all invertible matrices $B$. Again those matrices $A$ and $C$ are called similar.