This chapter emphasizes how to find  $ \boldsymbol{u}(t) = e^{At} \boldsymbol{u}(0) $ by diagonalization. Assume  $ A $ does have  $ n $ independent eigenvectors, so it is diagonalizable. Substitute  $ A = X \Lambda X^{-1} $ into the series for  $ e^{At} $. Whenever  $ X \Lambda X^{-1} X \Lambda X^{-1} $ appears, cancel  $ X^{-1} X $ in the middle:

Use the series

 $$ \begin{aligned}e^{At}&=I+X\Lambda X^{-1}t+\frac{1}{2}(X\Lambda X^{-1}t)(X\Lambda X^{-1}t)+\cdots\\&=X\left[I+\Lambda t+\frac{1}{2}(\Lambda t)^{2}+\cdots\right]X^{-1}\end{aligned} $$ 

Factor out X and  $ X^{-1} $

 $ e^{At} $ is diagonalized!

 $$ \left|e^{A t}=X e^{\Lambda t}X^{-1}.\right| $$ 

 $ e^{At} $ has the same eigenvector matrix X as A. Then  $ \Lambda $ is a diagonal matrix and so is  $ e^{\Lambda t} $. The numbers  $ e^{\lambda_i t} $ are on the diagonal. Multiply  $ X e^{\Lambda t} X^{-1} \boldsymbol{u}(0) $ to recognize  $ \boldsymbol{u}(t) $:

 $$ e^{A t}\boldsymbol{u}(0)=X e^{\Lambda t}X^{-1}\boldsymbol{u}(0)=\left[\begin{array}{ccc}x_{1}&\cdots&x_{n}\\\end{array}\right]\left[\begin{array}{ccc}e^{\lambda_{1}t}&&\\&\ddots&\\&&e^{\lambda_{n}t}\\\end{array}\right]\left[\begin{array}{c}c_{1}\\\vdots\\c_{n}\\\end{array}\right]. $$ 

This solution  $ e^{At}u(0) $ is the same answer that came in equation (6) from three steps:

 $$ \mathbf{1}.u(0)=c_{1}\boldsymbol{x}_{1}+\cdots+c_{n}\boldsymbol{x}_{n}=X c.Here we need n independent eigenvectors. $$ 

2. Multiply each  $ x_i $ by its growth factor  $ e^{\lambda_i t} $ to follow it forward in time.

 $$ \begin{array}{r l}{{3.~}\mathrm{T h e~b e s t~f o r m~o f~}e^{A t}u(0)\mathrm{~i s~}}&{u(t)=c_{1}e^{\lambda_{1}t}x_{1}+\dots+c_{n}e^{\lambda_{n}t}x_{n}.}\end{array} $$ 

Example 4 When you substitute  $ y = e^{\lambda t} $ into  $ y'' - 2y' + y = 0 $, you get an equation with repeated roots:  $ \lambda^2 - 2\lambda + 1 = 0 $ is  $ (\lambda - 1)^2 = 0 $ with  $ \lambda = 1 $. A differential equations course would propose  $ e^t $ and  $ te^t $ as two independent solutions. Here we discover why.

Linear algebra reduces  $ y'' - 2y' + y = 0 $ to a vector equation for  $ \boldsymbol{u} = (y, y'): $

 $$ \frac{d}{dt}\left[\begin{array}{c}{{{y}}} \\{{{y^{\prime}}}}\end{array}\right]=\left[\begin{array}{c}{{{y^{\prime}}}} \\{{{2y^{\prime}-y}}}\end{array}\right]\quad is\quad\frac{d\boldsymbol{u}}{dt}=\boldsymbol{A}\boldsymbol{u}=\left[\begin{array}{cc}{{{0}}}&{{{1}}} \\{{{-1}}}&{{{2}}}\end{array}\right]\boldsymbol{u}. $$ 

A has a repeated eigenvalue  $ \lambda = 1 $, 1 (with trace = 2 and det A = 1). The only eigenvectors are multiples of  $ \boldsymbol{x} = (1, 1) $. Diagonalization is not possible, A has only one line of eigenvectors. So we compute  $ e^{At} $ from its definition as a series:

 $$ e^{A t}=e^{I t}e^{(A-I)t}=e^{t}\left[I+(A-I)t\right]. $$ 

Short series

That “infinite” series for  $ e^{(A-I)t} $ ended quickly because  $ (A-I)^2 $ is the zero matrix! You can see  $ te^t $ in equation (19). The first component of  $ e^{At}u(0) $ is our answer  $ y(t) $:

 $$ \left[\begin{array}{l}{{{y}}} \\{{{y^{\prime}}}}\end{array}\right]=e^{t}\left[I+\left[\begin{array}{c c}{{{-1}}}&{{{1}}} \\{{{-1}}}&{{{1}}}\end{array}\right]t\right]\left[\begin{array}{l}{{{y(0)}}} \\{{{y^{\prime}(0)}}}\end{array}\right]\qquad y(t)=e^{t}y(0)-t e^{t}y(0)+t e^{t}y^{\prime}(0). $$ 