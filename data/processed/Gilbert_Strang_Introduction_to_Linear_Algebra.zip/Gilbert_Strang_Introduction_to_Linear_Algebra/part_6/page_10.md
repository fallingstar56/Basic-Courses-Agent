19 A 3 by 3 matrix B is known to have eigenvalues 0, 1, 2. This information is enough to find three of these (give the answers where possible):

(a) the rank of B

(b) the determinant of  $ B^{T}B $

(c) the eigenvalues of  $ B^{T}B $

(d) the eigenvalues of  $ (B^{2} + I)^{-1} $

20 Choose the last rows of A and C to give eigenvalues 4, 7 and 1, 2, 3:

Companion matrices

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{*}}}&{{{*}}}\end{bmatrix}\quad\boldsymbol{C}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{*}}}&{{{*}}}&{{{*}}}\end{bmatrix}. $$ 

The eigenvalues of A equal the eigenvalues of  $ A^{\mathrm{T}} $. This is because  $ \det(A - \lambda I) $ equals  $ \det(A^{\mathrm{T}} - \lambda I) $. That is true because ___. Show by an example that the eigenvectors of A and  $ A^{\mathrm{T}} $ are not the same.

Construct any 3 by 3 Markov matrix  $ M\colon $ positive entries down each column add to 1. Show that  $ M^{\mathrm{T}}(1,1,1) = (1,1,1) $. By Problem 21,  $ \lambda = 1 $ is also an eigenvalue of  $ M $. Challenge: A 3 by 3 singular Markov matrix with trace  $ \frac{1}{2} $ has what  $ \lambda $'s?

Find three 2 by 2 matrices that have  $ \lambda_{1} = \lambda_{2} = 0 $. The trace is zero and the determinant is zero. A might not be the zero matrix but check that  $ A^{2} = 0 $.

24 This matrix is singular with rank one. Find three  $ \lambda $'s and three eigenvectors:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}} \\{{{2}}} \\{{{1}}}\end{bmatrix}\begin{bmatrix}{{{2}}}&{{{1}}}&{{{2}}}\end{bmatrix}=\begin{bmatrix}{{{2}}}&{{{1}}}&{{{2}}} \\{{{4}}}&{{{2}}}&{{{4}}} \\{{{2}}}&{{{1}}}&{{{2}}}\end{bmatrix}. $$ 

Suppose $A$ and $B$ have the same eigenvalues $\lambda_1, \ldots, \lambda_n$ with the same independent eigenvectors $\boldsymbol{x}_1, \ldots, \boldsymbol{x}_n$. Then $A = B$. Reason: Any vector $\boldsymbol{x}$ is a combination $c_1\boldsymbol{x}_1 + \cdots + c_n\boldsymbol{x}_n$. What is $A\boldsymbol{x}$? What is $B\boldsymbol{x}$?

The block B has eigenvalues 1, 2 and C has eigenvalues 3, 4 and D has eigenvalues 5, 7. Find the eigenvalues of the 4 by 4 matrix A:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{B}}}&{{{C}}} \\{{{0}}}&{{{D}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{3}}}&{{{0}}} \\{{{-2}}}&{{{3}}}&{{{0}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{6}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{6}}}\end{bmatrix}. $$ 

27 Find the rank and the four eigenvalues of A and C:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{C}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 