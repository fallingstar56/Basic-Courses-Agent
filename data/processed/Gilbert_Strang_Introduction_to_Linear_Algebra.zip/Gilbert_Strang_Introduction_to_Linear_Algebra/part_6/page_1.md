## The Equation for the Eigenvalues

For projection matrices we found $\lambda$'s and $x$'s by geometry: $Px = x$ and $Px = 0$. For other matrices we use determinants and linear algebra. This is the key calculation in the chapter—almost every application starts by solving $Ax = \lambda x$.

First move $\lambda x$ to the left side. Write the equation $Ax = \lambda x$ as $(A - \lambda I)x = 0$. The matrix $A - \lambda I$ times the eigenvector $x$ is the zero vector. The eigenvectors make up the nullspace of $A - \lambda I$. When we know an eigenvalue $\lambda$, we find an eigenvector by solving $(A - \lambda I)x = 0$.

Eigenvalues first. If  $ (A - \lambda I)x = 0 $ has a nonzero solution,  $ A - \lambda I $ is not invertible. The determinant of  $ A - \lambda I $ must be zero. This is how to recognize an eigenvalue  $ \lambda $:

Eigenvalues The number  $ \lambda $ is an eigenvalue of A if and only if  $ A - \lambda I $ is singular.

Equation for the eigenvalues

 $$ \det(A-\lambda I)=0. $$ 

This “characteristic polynomial”  $ \det(A - \lambda I) $ involves only  $ \lambda $, not  $ \boldsymbol{x} $. When  $ A $ is  $ n $ by  $ n $, equation (3) has degree  $ n $. Then  $ A $ has  $ n $ eigenvalues (repeats possible!) Each  $ \lambda $ leads to  $ \boldsymbol{x} $:

For each eigenvalue  $ \lambda $ solve  $ (A - \lambda I)x = 0 $ or  $ Ax = \lambda x $ to find an eigenvector  $ x $.

Example 4  $ A = \begin{bmatrix} 1 & 2 \\ 2 & 4 \end{bmatrix} $ is already singular (zero determinant). Find its  $ \lambda $'s and  $ x $'s.

When $A$ is singular, $\lambda = 0$ is one of the eigenvalues. The equation $Ax = 0x$ has solutions. They are the eigenvectors for $\lambda = 0$. But $\det(A - \lambda I) = 0$ is the way to find all $\lambda$'s and $x$'s. Always subtract $\lambda I$ from $A$:

Subtract  $ \lambda $ from the diagonal to find

 $$ \boldsymbol{A}-\lambda\boldsymbol{I}=\begin{bmatrix}{{{1-\lambda}}}&{{{2}}} \\{{{2}}}&{{{4-\lambda}}}\end{bmatrix}. $$ 

Take the determinant “ad − bc” of this 2 by 2 matrix. From 1 − λ times 4 − λ, the “ad” part is λ² − 5λ + 4. The “bc” part, not containing λ, is 2 times 2.

 $$ \det\left[\begin{array}{cc}{{{1-\lambda}}}&{{{2}}} \\{{{2}}}&{{{4-\lambda}}}\end{array}\right]=(1-\lambda)(4-\lambda)-(2)(2)=\lambda^{2}-5\lambda. $$ 

Set this determinant  $ \lambda^2 - 5\lambda $ to zero. One solution is  $ \lambda = 0 $ (as expected, since  $ A $ is singular). Factoring into  $ \lambda $ times  $ \lambda - 5 $, the other root is  $ \lambda = 5 $:

 $$ \det(A-\lambda I)=\lambda^{2}-5\lambda=0\quad yields the eigenvalues\quad\lambda_{1}=0\quad and\quad\lambda_{2}=5 $$ 