The good thing is that  $ \overline{\lambda} $ times  $ \overline{x} $ is always the conjugate of  $ \lambda $ times  $ x $. So we can take conjugates of  $ Sx = \lambda x $, remembering that  $ S $ is real:

 $$ S\boldsymbol{x}=\lambda\boldsymbol{x}\quad leads to\quad S\overline{\boldsymbol{x}}=\overline{\lambda}\overline{\boldsymbol{x}}.\qquad Transpose to\quad\overline{\boldsymbol{x}}^{\mathrm{T}}S=\overline{\boldsymbol{x}}^{\mathrm{T}}\overline{\lambda}. $$ 

Now take the dot product of the first equation with  $ \overline{x} $ and the last equation with  $ x $:

 $$ \overline{\boldsymbol{x}}^{\mathrm{T}}\boldsymbol{S}\boldsymbol{x}=\overline{\boldsymbol{x}}^{\mathrm{T}}\lambda\boldsymbol{x}\qquad\mathrm{a n d~a l s o}\qquad\overline{\boldsymbol{x}}^{\mathrm{T}}\boldsymbol{S}\boldsymbol{x}=\overline{\boldsymbol{x}}^{\mathrm{T}}\overline{\lambda}\boldsymbol{x}. $$ 

The left sides are the same so the right sides are equal. One equation has $\lambda$, the other has $\overline{\lambda}$. They multiply $\overline{\boldsymbol{x}}^{\mathrm{T}}\boldsymbol{x} = |\boldsymbol{x}_{1}|^{2} + |\boldsymbol{x}_{2}|^{2} + \cdots = \text{length squared which is not zero. Therefore } \lambda \text{ must equal } \overline{\lambda}$, and $a + i b \text{ equals } a - i b$. So $b = 0$ and $\lambda = a = \text{real}$. Q.E.D.

The eigenvectors come from solving the real equation  $ (S - \lambda I)x = 0 $. So the  $ x $'s are also real. The important fact is that they are perpendicular.

Orthogonal Eigenvectors Eigenvectors of a real symmetric matrix (when they correspond to different $\lambda^{\prime}$s) are always perpendicular.

Proof Suppose  $ Sx = \lambda_1 x $ and  $ Sy = \lambda_2 y $. We are assuming here that  $ \lambda_1 \neq \lambda_2 $. Take dot products of the first equation with y and the second with x:

 $$ \mathbf{U}\mathbf{s}\mathbf{e}\mathbf{\delta}S^{\mathrm{T}}=S\quad\left(\lambda_{1}\mathbf{x}\right)^{\mathrm{T}}\mathbf{y}=\left(S\mathbf{x}\right)^{\mathrm{T}}\mathbf{y}=\mathbf{x}^{\mathrm{T}}S^{\mathrm{T}}\mathbf{y}=\mathbf{x}^{\mathrm{T}}S\mathbf{y}=\mathbf{x}^{\mathrm{T}}\lambda_{2}\mathbf{y}. $$ 

The left side is  $ \boldsymbol{x}^{\mathrm{T}}\lambda_{1}\boldsymbol{y} $, the right side is  $ \boldsymbol{x}^{\mathrm{T}}\lambda_{2}\boldsymbol{y} $. Since  $ \lambda_{1}\neq\lambda_{2} $, this proves that  $ \boldsymbol{x}^{\mathrm{T}}\boldsymbol{y}=0 $. The eigenvector  $ \boldsymbol{x} $ (for  $ \lambda_{1} $) is perpendicular to the eigenvector  $ \boldsymbol{y} $ (for  $ \lambda_{2} $).

Example 2 The eigenvectors of a 2 by 2 symmetric matrix have a special form:

Not widely known

 $$ S=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{b}}}&{{{c}}}\end{bmatrix}\quad has\quad\boldsymbol{x}_{1}=\begin{bmatrix}{{{b}}} \\{{{\lambda_{1}-a}}}\end{bmatrix}\quad and\quad\boldsymbol{x}_{2}=\begin{bmatrix}{{{\lambda_{2}-c}}} \\{{{b}}}\end{bmatrix}. $$ 

This is in the Problem Set. The point here is that  $ x_{1} $ is perpendicular to  $ x_{2} $:

 $$ \boldsymbol{x}_{1}^{\mathrm{T}}\boldsymbol{x}_{2}=b(\lambda_{2}-c)+(\lambda_{1}-a)b=b(\lambda_{1}+\lambda_{2}-a-c)=0. $$ 

This is zero because  $ \lambda_1 + \lambda_2 $ equals the trace  $ a + c $. Thus  $ \boldsymbol{x}_1^\mathrm{T} \boldsymbol{x}_2 = 0 $. Eagle eyes might notice the special case  $ S = I $, when  $ b $ and  $ \lambda_1 - a $ and  $ \lambda_2 - c $ and  $ \boldsymbol{x}_1 $ and  $ \boldsymbol{x}_2 $ are all zero. Then  $ \lambda_1 = \lambda_2 = 1 $ is repeated. But of course  $ S = I $ has perpendicular eigenvectors.

Symmetric matrices S have orthogonal eigenvector matrices Q. Look at this again:

Symmetry

 $$ S=X\Lambda X^{-1}\quad becomes\quad S=Q\Lambda Q^{\mathrm{T}}\quad with\quad Q^{\mathrm{T}}Q=I. $$ 

This says that every 2 by 2 symmetric matrix is (rotation)(stretch)(rotate back)

 $$ \boldsymbol{S}=\boldsymbol{Q}\boldsymbol{\Lambda}\boldsymbol{Q}^{\mathrm{T}}=\left[\boldsymbol{q}_{1}\quad\boldsymbol{q}_{2}\right]\left[\begin{array}{l l}\lambda_{1}&\\ &\lambda_{2}\end{array}\right]\left[\begin{array}{c}\boldsymbol{q}_{\mathrm{L}}^{\mathrm{T}}\\ \boldsymbol{q}_{2}^{\mathrm{T}}\end{array}\right]. $$ 

Columns q1 and q2 multiply rows  $ \lambda_1q_1^{\mathrm{T}} $ and  $ \lambda_2q_2^{\mathrm{T}} $ to produce  $ S = \lambda_1q_1q_1^{\mathrm{T}} + \lambda_2q_2q_2^{\mathrm{T}} $.