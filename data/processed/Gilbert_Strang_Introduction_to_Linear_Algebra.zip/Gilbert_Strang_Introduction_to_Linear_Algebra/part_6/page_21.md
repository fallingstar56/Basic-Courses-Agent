There “should” be two eigenvectors, because  $ \lambda^2 = 0 $ has a double root. The double factor  $ \lambda^2 $ makes AM = 2. But there is only one eigenvector  $ \boldsymbol{x} = (1, 0) $ and GM = 1. This shortage of eigenvectors when GM is below AM means that A is not diagonalizable.

These three matrices all have the same shortage of eigenvectors. Their repeated eigenvalue is  $ \lambda = 5 $. Traces are 10 and determinants are 25:

 $$ A=\begin{bmatrix}{{{5}}}&{{{1}}} \\{{{0}}}&{{{5}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{6}}}&{{{-1}}} \\{{{1}}}&{{{4}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{7}}}&{{{2}}} \\{{{-2}}}&{{{3}}}\end{bmatrix}. $$ 

Those all have  $ \det(A - \lambda I) = (\lambda - 5)^2 $. The algebraic multiplicity is AM = 2. But each  $ A - 5I $ has rank  $ r = 1 $. The geometric multiplicity is GM = 1. There is only one line of eigenvectors for  $ \lambda = 5 $, and these matrices are not diagonalizable.

## ■ REVIEW OF THE KEY IDEAS ■

1. If A has n independent eigenvectors  $ \boldsymbol{x}_{1}, \ldots, \boldsymbol{x}_{n} $, they go into the columns of X.

A is diagonalized by X

 $$ X^{-1}AX=\Lambda\quad and\quad A=X\Lambda X^{-1}. $$ 

2. The powers of  $ A $ are  $ A^k = X \Lambda^k X^{-1} $. The eigenvectors in  $ X $ are unchanged.

3. The eigenvalues of  $ A^{k} $ are  $ (\lambda_{1})^{k}, \ldots, (\lambda_{n})^{k} $ in the matrix  $ \Lambda^{k} $.

4. The solution to  $ u_{k+1} = Au_k $ starting from  $ u_0 $ is  $ u_k = A^k u_0 = X \Lambda^k X^{-1} u_0 $:

 $$ \begin{array}{r l r}&{}&{\boldsymbol{u}_{k}=c_{1}(\lambda_{1})^{k}\boldsymbol{x}_{1}+\cdots+c_{n}(\lambda_{n})^{k}\boldsymbol{x}_{n}\quad\mathrm{p r o v i d e d}\quad\boldsymbol{u}_{0}=c_{1}\boldsymbol{x}_{1}+\cdots+c_{n}\boldsymbol{x}_{n}.}\end{array} $$ 

That shows Steps 1, 2, 3 (c's from  $ X^{-1}u_{0} $,  $ \lambda^{k} $ from  $ \Lambda^{k} $, and  $ x $'s from X)

5. A is diagonalizable if every eigenvalue has enough eigenvectors (GM = AM).

## WORKED EXAMPLES

6.2 A The Lucas numbers are like the Fibonacci numbers except they start with  $ L_1 = 1 $ and  $ L_2 = 3 $. Using the same rule  $ L_{k+2} = L_{k+1} + L_k $, the next Lucas numbers are 4, 7, 11, 18. Show that the Lucas number  $ L_{100} $ is  $ \lambda_1^{100} + \lambda_2^{100} $.