6.1 C Find the eigenvalues and eigenvectors of this symmetric 3 by 3 matrix S:

Symmetric matrix

Singular matrix

Trace 1 + 2 + 1 = 4

 $$ S=\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{1}}}\end{bmatrix} $$ 

Solution Since all rows of $S$ add to zero, the vector $\boldsymbol{x} = (1, 1, 1)$ gives $S\boldsymbol{x} = 0$. This is an eigenvector for $\lambda = 0$. To find $\lambda_2$ and $\lambda_3$, I will compute the 3 by 3 determinant:

 $$ \det(S-\lambda I)=\left|\begin{array}{ccc}{{{1-\lambda}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{2-\lambda}}}&{{{-1}}} \\{{{0}}}&{{{-1}}}&{{{1-\lambda}}} \\\end{array}\right|=(1-\lambda)(2-\lambda)(1-\lambda)-2(1-\lambda)\\=(1-\lambda)[(2-\lambda)(1-\lambda)-2]\\=(1-\lambda)(-\lambda)(3-\lambda). $$ 

Those three factors give  $ \lambda = 0, 1, 3 $. Each eigenvalue corresponds to an eigenvector (or a line of eigenvectors):

 $$ \boldsymbol{x}_{1}=\begin{bmatrix}1\\ 1\\ 1\end{bmatrix}\quad S\boldsymbol{x}_{1}=\mathbf{0}\boldsymbol{x}_{1}\quad\boldsymbol{x}_{2}=\begin{bmatrix}1\\ 0\\ -1\end{bmatrix}\quad S\boldsymbol{x}_{2}=\mathbf{1}\boldsymbol{x}_{2}\quad\boldsymbol{x}_{3}=\begin{bmatrix}1\\ -2\\ 1\end{bmatrix}\quad S\boldsymbol{x}_{3}=\mathbf{3}\boldsymbol{x}_{3}. $$ 

I notice again that eigenvectors are perpendicular when $S$ is symmetric. We were lucky to find $\lambda = 0, 1, 3$. For a larger matrix I would use $\mathbf{e}_{i}g(A)$, and never touch determinants.

The full command  $ [X,E]=\mathbf{eig}(A) $ will produce unit eigenvectors in the columns of X.

### Problem Set 6.1

1 The example at the start of the chapter has powers of this matrix A:

 $$ A=\begin{bmatrix}.8&.3\\ .2&.7\end{bmatrix}\quad and\quad A^{2}=\begin{bmatrix}.70&.45\\ .30&.55\end{bmatrix}\quad and\quad A^{\infty}=\begin{bmatrix}.6&.6\\ .4&.4\end{bmatrix}. $$ 

Find the eigenvalues of these matrices. All powers have the same eigenvectors.

(a) Show from A how a row exchange can produce different eigenvalues.

(b) Why is a zero eigenvalue not changed by the steps of elimination?

2 Find the eigenvalues and the eigenvectors of these two matrices:

 $$ A=\begin{bmatrix}{{{1}}}&{{{4}}} \\{{{2}}}&{{{3}}}\end{bmatrix}\quad and\quad A+I=\begin{bmatrix}{{{2}}}&{{{4}}} \\{{{2}}}&{{{4}}}\end{bmatrix}. $$ 

A + I has the ___ eigenvectors as A. Its eigenvalues are ___ by 1.

3 Compute the eigenvalues and eigenvectors of A and  $ A^{-1} $. Check the trace!

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{2}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{A}^{-1}=\begin{bmatrix}{{{-1/2}}}&{{{1}}} \\{{{1/2}}}&{{{0}}}\end{bmatrix}. $$ 

 $ A^{-1} $ has the ___ eigenvectors as A. When A has eigenvalues  $ \lambda_{1} $ and  $ \lambda_{2} $, its inverse has eigenvalues ___.