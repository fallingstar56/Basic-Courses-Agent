(Recommended) Suppose  $ Ax = \lambda x $. If  $ \lambda = 0 $ then  $ x $ is in the nullspace. If  $ \lambda \neq 0 $ then  $ x $ is in the column space. Those spaces have dimensions  $ (n - r) + r = n $. So why doesn't every square matrix have  $ n $ linearly independent eigenvectors?

The eigenvalues of A are 1 and 9, and the eigenvalues of B are -1 and 9:

Find a matrix square root of  $ A $ from  $ R = X\sqrt{\Lambda}X^{-1} $. Why is there no real matrix square root of  $ B $?

 $$ A=\begin{bmatrix}{{{5}}}&{{{4}}} \\{{{4}}}&{{{5}}}\end{bmatrix}\qquad and\qquad B=\begin{bmatrix}{{{4}}}&{{{5}}} \\{{{5}}}&{{{4}}}\end{bmatrix}. $$ 

Suppose the same X diagonalizes both A and B. They have the same eigenvectors in  $ A = X\Lambda_1X^{-1} $ and  $ B = X\Lambda_2X^{-1} $. Prove that  $ AB = BA $.

If A and B have the same $\lambda$'s with the same independent eigenvectors, their factorizations into ___ are the same. So $A = B$.

(a) If  $ A = \begin{bmatrix} a & b \\ 0 & d \end{bmatrix} $ then the determinant of  $ A - \lambda I $ is  $ (\lambda - a)(\lambda - d) $. Check the “Cayley-Hamilton Theorem” that  $ (A - aI)(A - dI) = zero $ matrix.

(b) Test the Cayley-Hamilton Theorem on Fibonacci's  $ A = \begin{bmatrix} 1 & 1 \\ 1 & 0 \end{bmatrix} $. The theorem predicts that  $ A^2 - A - I = 0 $, since the polynomial  $ \det(A - \lambda I) $ is  $ \lambda^2 - \lambda - 1 $.

Substitute  $ A = X \Lambda X^{-1} $ into the product  $ (A - \lambda_1 I)(A - \lambda_2 I) \cdots (A - \lambda_n I) $ and explain why this produces the zero matrix. We are substituting the matrix  $ A $ for the number  $ \lambda $ in the polynomial  $ p(\lambda) = \det(A - \lambda I) $. The Cayley-Hamilton Theorem says that this product is always  $ p(A) = zero $ matrix, even if  $ A $ is not diagonalizable.

If  $ A = \begin{bmatrix} 1 & 0 \\ 0 & 2 \end{bmatrix} $ and  $ AB = BA $, show that  $ B = \begin{bmatrix} a & b \\ c & d \end{bmatrix} $ is also a diagonal matrix.  $ B $ has the same eigen___ as  $ A $ but different eigen___ . These diagonal matrices  $ B $ form a two-dimensional subspace of matrix space.  $ AB - BA = 0 $ gives four equations for the unknowns  $ a, b, c, d $—find the rank of the 4 by 4 matrix.

The powers  $ A^k $ approach zero if all  $ |\lambda_i| < 1 $ and they blow up if any  $ |\lambda_i| > 1 $. Peter Lax gives these striking examples in his book Linear Algebra:

 $$ A=\begin{bmatrix}{{{3}}}&{{{2}}} \\{{{1}}}&{{{4}}}\end{bmatrix}\qquad\quad B=\begin{bmatrix}{{{3}}}&{{{2}}} \\{{{-5}}}&{{{-3}}}\end{bmatrix}\qquad C=\begin{bmatrix}{{{5}}}&{{{7}}} \\{{{-3}}}&{{{-4}}}\end{bmatrix}\qquad D=\begin{bmatrix}{{{5}}}&{{{6.9}}} \\{{{-3}}}&{{{-4}}}\end{bmatrix} $$ 

 $$ \left\| \mathbf{A}^{1024} \right\|>10^{700} \quad B^{1024}=I \quad C^{1024}=-C \quad \left\| \mathbf{D}^{1024} \right\|<10^{-78} $$ 

Find the eigenvalues  $ \lambda = e^{i\theta} $ of B and C to show  $ B^{4} = I $ and  $ C^{3} = -I $.