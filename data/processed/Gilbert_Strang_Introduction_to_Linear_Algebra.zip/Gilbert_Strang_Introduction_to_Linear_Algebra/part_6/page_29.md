## Solution of du/dt = Au

Our pure exponential solution will be  $ e^{\lambda t} $ times a fixed vector  $ \boldsymbol{x} $. You may guess that  $ \lambda $ is an eigenvalue of  $ A $, and  $ x $ is the eigenvector. Substitute  $ \boldsymbol{u}(t) = e^{\lambda t} \boldsymbol{x} $ into the equation  $ du/dt = Au $ to prove you are right. The factor  $ e^{\lambda t} $ will cancel to leave  $ \lambda \boldsymbol{x} = A \boldsymbol{x} $:

 $$ \begin{array}{l} Choose u=e^{\lambda t}x\\ when A x=\lambda x\end{array}\quad\begin{array}{l}\frac{d u}{d t}=\lambda e^{\lambda t}x\end{array}\quad agrees with\quad A u=A e^{\lambda t}x $$ 

All components of this special solution  $ \boldsymbol{u} = e^{\lambda t} \boldsymbol{x} $ share the same  $ e^{\lambda t} $. The solution grows when  $ \lambda > 0 $. It decays when  $ \lambda < 0 $. If  $ \lambda $ is a complex number, its real part decides growth or decay. The imaginary part  $ \omega $ gives oscillation  $ e^{i\omega t} $ like a sine wave.

Example 1

 $$ \operatorname{S o l v e}\frac{d\boldsymbol{u}}{d t}=\boldsymbol{A}\boldsymbol{u}=\left[\begin{array}{c c}{0}&{1}\\ {1}&{0}\\ \end{array}\right]\boldsymbol{u}\quad\mathrm{s t a r t i n g f r o m}\quad\boldsymbol{u}(0)=\left[\begin{array}{c}{4}\\ {2}\\ \end{array}\right]. $$ 

This is a vector equation for u. It contains two scalar equations for the components y and z. They are “coupled together” because the matrix A is not diagonal:

 $$ \frac{d\boldsymbol{u}}{dt}=\boldsymbol{A}\boldsymbol{u}\qquad\frac{d}{dt}\begin{bmatrix}{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{y}}} \\{{{z}}}\end{bmatrix}\quad means that\quad\frac{dy}{dt}=z\quad and\quad\frac{dz}{dt}=y. $$ 

The idea of eigenvectors is to combine those equations in a way that gets back to 1 by 1 problems. The combinations  $ y + z $ and  $ y - z $ will do it. Add and subtract equations:

 $$ \frac{d}{dt}(y+z)=z+y\qquad and\qquad\frac{d}{dt}(y-z)=-(y-z). $$ 

The combination  $ y + z $ grows like  $ e^t $, because it has  $ \lambda = 1 $. The combination  $ y - z $ decays like  $ e^{-t} $, because it has  $ \lambda = -1 $. Here is the point: We don't have to juggle the original equations  $ du/dt = Au $, looking for these special combinations. The eigenvectors and eigenvalues of  $ A $ will do it for us.

This matrix A has eigenvalues 1 and -1. The eigenvectors  $ \boldsymbol{x} $ are  $ (1,1) $ and  $ (1,-1) $. The pure exponential solutions  $ \boldsymbol{u}_1 $ and  $ \boldsymbol{u}_2 $ take the form  $ e^{\lambda t} \boldsymbol{x} $ with  $ \lambda_1 = 1 $ and  $ \lambda_2 = -1 $:

 $$ \boldsymbol{u}_{1}(t)=e^{\lambda_{1}t}\boldsymbol{x}_{1}=e^{t}\begin{bmatrix}1\\ 1\end{bmatrix}\qquad and\qquad\boldsymbol{u}_{2}(t)=e^{\lambda_{2}t}\boldsymbol{x}_{2}=e^{-t}\begin{bmatrix}1\\ -1\end{bmatrix}. $$ 

Notice: These $u$'s satisfy $Au_1 = u_1$ and $Au_2 = -u_2$, just like $x_1$ and $x_2$. The factors $e^t$ and $e^{-t}$ change with time. Those factors give $du_1/dt = u_1 = Au_1$ and $du_2/dt = -u_2 = Au_2$. We have two solutions to $du/dt = Au$. To find all other solutions, multiply those special solutions by any numbers $C$ and $D$ and add:

Complete solution

 $$ \boldsymbol{u}(t)=C e^{t}\begin{bmatrix}1\\ 1\end{bmatrix}+D e^{-t}\begin{bmatrix}1\\ -1\end{bmatrix}=\begin{bmatrix}C e^{t}+D e^{-t}\\ C e^{t}-D e^{-t}\end{bmatrix}. $$ 