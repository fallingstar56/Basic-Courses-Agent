All these steps use the  $ \lambda $'s and the  $ \mathbf{x} $'s. This section solves the constant coefficient problems that turn into linear algebra. It clarifies these simplest but most important differential equations—whose solution is completely based on growth factors  $ e^{\lambda t} $.

## Second Order Equations

The most important equation in mechanics is  $ my'' + by' + ky = 0 $. The first term is the mass m times the acceleration  $ a = y'' $. This term ma balances the force  $ F $ (that is Newton's Law). The force includes the damping  $ -by' $ and the elastic force  $ -ky $, proportional to distance moved. This is a second-order equation because it contains the second derivative  $ y'' = d^2y/dt^2 $. It is still linear with constant coefficients  $ m, b, k $.

In a differential equations course, the method of solution is to substitute  $ y = e^{\lambda t} $. Each derivative of y brings down a factor  $ \lambda $. We want  $ y = e^{\lambda t} $ to solve the equation:

 $$ m\frac{d^{2}y}{dt^{2}}+b\frac{dy}{dt}+ky=0\quad becomes\quad\left(m\lambda^{2}+b\lambda+k\right)e^{\lambda t}=0. $$ 

Everything depends on  $ m\lambda^2 + b\lambda + k = 0 $. This equation for  $ \lambda $ has two roots  $ \lambda_1 $ and  $ \lambda_2 $. Then the equation for  $ y $ has two pure solutions  $ y_1 = e^{\lambda_1 t} $ and  $ y_2 = e^{\lambda_2 t} $. Their combinations  $ c_1 y_1 + c_2 y_2 $ give the complete solution unless  $ \lambda_1 = \lambda_2 $.

In a linear algebra course we expect matrices and eigenvalues. Therefore we turn the scalar equation (with  $ y'' $) into a vector equation for  $ y $ and  $ y' $: first derivative only. Suppose the mass is  $ m = 1 $. Two equations for  $ \boldsymbol{u} = (y, y') $ give  $ d\boldsymbol{u}/dt = A\boldsymbol{u} $:

 $$ \begin{array}{l}dy/dt=y^{\prime}\\ dy^{\prime}/dt=-ky-by^{\prime}\end{array}\quad converts to\quad\begin{array}{l}\displaystyle\frac{d}{dt}\begin{bmatrix}y\\ y^{\prime}\end{bmatrix}=\begin{bmatrix}0&1\\ -k&-b\end{bmatrix}\begin{bmatrix}y\\ y^{\prime}\end{bmatrix}=Au. $$ 

The first equation  $ dy/dt = y' $ is trivial (but true). The second is equation (8) connecting  $ y'' $ to  $ y' $ and  $ y $. Together they connect  $ u' $ to  $ u $. So we solve  $ u' = Au $ by eigenvalues of  $ A $:

 $$ A-\lambda I=\begin{bmatrix}{{{-\lambda}}}&{{{1}}} \\{{{-k}}}&{{{-b-\lambda}}}\end{bmatrix}\quad has determinant\quad\lambda^{2}+b\lambda+k=0. $$ 

The equation for the λ's is the same as (8)! It is still λ² + bλ + k = 0, since m = 1. The roots λ₁ and λ₂ are now eigenvalues of A. The eigenvectors and the solution are

 $$ \boldsymbol{x}_{1}=\begin{bmatrix}1\\ \lambda_{1}\end{bmatrix}\qquad\boldsymbol{x}_{2}=\begin{bmatrix}1\\ \lambda_{2}\end{bmatrix}\qquad\boldsymbol{u}(t)=c_{1}e^{\lambda_{1}t}\begin{bmatrix}1\\ \lambda_{1}\end{bmatrix}+c_{2}e^{\lambda_{2}t}\begin{bmatrix}1\\ \lambda_{2}\end{bmatrix}. $$ 

The first component of  $ \boldsymbol{u}(t) $ has  $ y = c_1 e^{\lambda_1 t} + c_2 e^{\lambda_2 t} $—the same solution as before. It can’t be anything else. In the second component of  $ \boldsymbol{u}(t) $ you see the velocity  $ dy/dt $. The vector problem is completely consistent with the scalar problem. The 2 by 2 matrix  $ A $ is called a companion matrix—a companion to the second order equation with  $ y'' $.