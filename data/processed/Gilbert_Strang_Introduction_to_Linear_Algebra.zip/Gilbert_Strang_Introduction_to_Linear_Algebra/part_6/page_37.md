Example 5 Use the infinite series to find  $ e^{At} $ for  $ A = \begin{bmatrix} 0 & 1 \\ -1 & 0 \end{bmatrix} $. Notice that  $ A^4 = I $:

 $$ \boldsymbol{A}=\begin{bmatrix} \\{{{1}}} \\{{{-1}}} \\\end{bmatrix}\quad\boldsymbol{A}^{2}=\begin{bmatrix} \\{{{-1}}} \\{{{-1}}} \\\end{bmatrix}\quad\boldsymbol{A}^{3}=\begin{bmatrix} \\{{{-1}}} \\{{{1}}} \\\end{bmatrix}\quad\boldsymbol{A}^{4}=\begin{bmatrix} \\{{{1}}} \\{{{1}}} \\\end{bmatrix}. $$ 

$A^{5}, A^{6}, A^{7}, A^{8}$ will be a repeat of $A, A^{2}, A^{3}, A^{4}$. The top right corner has $1, 0, -1, 0$ repeating over and over in powers of $A$. Then $t - \frac{1}{6}t^{3}$ starts the infinite series for $e^{At}$ in that top right corner, and $1 - \frac{1}{2}t^{2}$ starts the top left corner:

 $$ e^{A t}=I+A t+\frac{1}{2}(A t)^{2}+\frac{1}{6}(A t)^{3}+\cdots=\left[\begin{array}{c c}1-\frac{1}{2}t^{2}+\cdots&t-\frac{1}{6}t^{3}+\cdots\\ -t+\frac{1}{6}t^{3}-\cdots&1-\frac{1}{2}t^{2}+\cdots\end{array}\right]. $$ 

The top row of that matrix  $ e^{At} $ shows the infinite series for the cosine and sine!

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{-1}}}&{{{0}}}\end{bmatrix}\quad e^{A t}=\begin{bmatrix}{{{\cos t}}}&{{{\sin t}}} \\{{{-\sin t}}}&{{{\cos t}}}\end{bmatrix}. $$ 

A is an antisymmetric matrix  $ (A^{\mathrm{T}} = -A) $. Its exponential  $ e^{At} $ is an orthogonal matrix. The eigenvalues of A are i and -i. The eigenvalues of  $ e^{At} $ are  $ e^{it} $ and  $ e^{-it} $. Three rules:

1  $ e^{At} $ always has the inverse  $ e^{-At} $

2 The eigenvalues of  $ e^{At} $ are always  $ e^{\lambda t} $.

3 When A is antisymmetric,  $ e^{At} $ is orthogonal. Inverse = transpose =  $ e^{-At} $.

Antisymmetric is the same as “skew-symmetric”. Those matrices have pure imaginary eigenvalues like $i$ and $-i$. Then $e^{At}$ has eigenvalues like $e^{it}$ and $e^{-it}$. Their absolute value is 1: neutral stability, pure oscillation, energy is conserved. So $\|u(t)\| = \|u(0)\|$.

Our final example has a triangular matrix  $ A $. Then the eigenvector matrix  $ X $ is triangular. So are  $ X^{-1} $ and  $ e^{At} $. You will see the two forms of the solution: a combination of eigenvectors and the short form  $ e^{At}u(0) $.

 $$  Example6\quad Solve\frac{d\boldsymbol{u}}{dt}=\boldsymbol{A}\boldsymbol{u}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{2}}}\end{bmatrix}\boldsymbol{u} starting from\boldsymbol{u}(0)=\begin{bmatrix}{{{2}}} \\{{{1}}}\end{bmatrix}at t=0. $$ 

Solution The eigenvalues 1 and 2 are on the diagonal of  $ A $ (since  $ A $ is triangular). The eigenvectors are  $ (1,0) $ and  $ (1,1) $. The starting  $ \boldsymbol{u}(0) $ is  $ \boldsymbol{x}_1 + \boldsymbol{x}_2 $ so  $ c_1 = c_2 = 1 $. Then  $ \boldsymbol{u}(t) $ is the same combination of pure exponentials ( $ no\,te^{\lambda t} $ when  $ \lambda = 1 $ and 2):

Solution to  $ u' = Au $

 $$ \boldsymbol{u}(t)=e^{t}\begin{bmatrix}1\\ 0\end{bmatrix}+e^{2t}\begin{bmatrix}1\\ 1\end{bmatrix}. $$ 

That is the clearest form. But the matrix form with e^{At} produces u(t) for every u(0):

 $$ \boldsymbol{u}(t)=X e^{\Lambda t}X^{-1}\boldsymbol{u}(0)\mathrm{i s}\left[\begin{matrix}{1}&{1}\\ {0}&{1}\\ \end{matrix}\right]\left[\begin{matrix}{e^{t}}&{}&{}\\ {}&{e^{2t}}\\ \end{matrix}\right]\left[\begin{matrix}{1}&{-1}\\ {0}&{1}\\ \end{matrix}\right]\boldsymbol{u}(0)=\left[\begin{matrix}{e^{t}}&{e^{2t}+e^{t}}\\ {0}&{e^{2t}}\\ \end{matrix}\right]\boldsymbol{u}(0). $$ 

That last matrix is  $ e^{At} $. It is nice because  $ A $ is triangular. The situation is the same as for  $ Ax = b $ and inverses. We don’t need  $ A^{-1} $ to find  $ x $, and we don’t need  $ e^{At} $ to solve  $ du/dt = Au $. But as quick formulas for the answers,  $ A^{-1}b $ and  $ e^{At}u(0) $ are unbeatable.