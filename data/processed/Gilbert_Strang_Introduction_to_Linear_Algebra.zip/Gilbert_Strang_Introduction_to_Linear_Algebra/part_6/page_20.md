Find  $ u_k = A^k u_0 $ in 3 steps  $ u_0 = c_1 x_1 + c_2 x_2 $ and  $ u_k = c_1 (\lambda_1)^k x_1 + c_2 (\lambda_2)^k x_2 $

Step 1

 $$ u_{0}=\begin{bmatrix}1\\ 0\end{bmatrix}=\frac{1}{3}\begin{bmatrix}2\\ 1\end{bmatrix}+\frac{1}{3}\begin{bmatrix}1\\ -1\end{bmatrix}\quad so\quad c_{1}=c_{2}=\frac{1}{3} $$ 

Step 2 Multiply the two parts by  $ (\lambda_{1})^{k}=2^{k} $ and  $ (\lambda_{2})^{k}=(-1)^{k} $

Step 3 Combine eigenvectors  $ c_{1}(\lambda_{1})^{k}x_{1} $ and  $ c_{2}(\lambda_{2})^{k}x_{2} $ into  $ u_{k} $:

 $$ u_{k}=A^{k}u_{0}\qquad u_{k}=\frac{1}{3}2^{k}\left[\begin{matrix}{2}\\ {1}\\ \end{matrix}\right]+\frac{1}{3}(-1)^{k}\left[\begin{matrix}{1}\\ {-1}\\ \end{matrix}\right]=\left[\begin{matrix}{F_{k+1}}\\ {F_{k}}\\ \end{matrix}\right]. $$ 

The new number is  $ F_k = (2^k - (-1)^k)/3 $. After 0, 1, 1, 3 comes  $ F_4 = 15/3 = 5 $.

Behind these numerical examples lies a fundamental idea: Follow the eigenvectors. In Section 6.3 this is the crucial link from linear algebra to differential equations ( $ \lambda^k $ will become  $ e^{\lambda t} $). Chapter 8 sees the same idea as “transforming to an eigenvector basis.” The best example of all is a Fourier series, built from the eigenvectors  $ e^{ikx} $ of  $ d/dx $.

## Nondiagonalizable Matrices (Optional)

Suppose  $ \lambda $ is an eigenvalue of A. We discover that fact in two ways:

1. Eigenvectors (geometric) There are nonzero solutions to  $ Ax = \lambda x $.

2. Eigenvalues (algebraic) The determinant of  $ A - \lambda I $ is zero.

The number  $ \lambda $ may be a simple eigenvalue or a multiple eigenvalue, and we want to know its multiplicity. Most eigenvalues have multiplicity  $ M = 1 $ (simple eigenvalues). Then there is a single line of eigenvectors, and  $ \det(A - \lambda I) $ does not have a double factor.

For exceptional matrices, an eigenvalue can be repeated. Then there are two different ways to count its multiplicity. Always  $ GM \leq AM $ for each  $ \lambda $:

1. (Geometric Multiplicity = GM) Count the independent eigenvectors for  $ \lambda $. Then GM is the dimension of the nullspace of  $ A - \lambda I $.

2. (Algebraic Multiplicity = AM) AM counts the repetitions of  $ \lambda $ among the eigenvalues. Look at the n roots of  $ \det(A - \lambda I) = 0 $.

If A has  $ \lambda = 4, 4, 4 $, then that eigenvalue has AM = 3 and GM = 1, 2, or 3.

The following matrix A is the standard example of trouble. Its eigenvalue  $ \lambda = 0 $ is repeated. It is a double eigenvalue (AM = 2) with only one eigenvector (GM = 1).

 $$ \begin{array}{r l}{\mathbf{A}\mathbf{M}=2}&{{}\quad A=\left[\begin{matrix}{0}&{1}\\ {0}&{0}\\ \end{matrix}\right]\mathrm{~h a s~}\operatorname*{d e t}(A-\lambda I)=\left|\begin{matrix}{-\lambda}&{1}\\ {0}&{-\lambda}\\ \end{matrix}\right|=\lambda^{2}.}&{{}\quad\lambda=0,0\mathrm{~b u t~}}\\ {\mathbf{G}\mathbf{M}=1}&{{}\quad1\mathrm{~e i g e n v e c t o r~}}\end{array} $$ 