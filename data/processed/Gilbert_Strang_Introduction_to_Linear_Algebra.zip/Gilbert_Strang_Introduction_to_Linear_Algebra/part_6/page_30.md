With these two constants $C$ and $D$, we can match any starting vector $\boldsymbol{u}(0) = (u_1(0), u_2(0))$. Set $t = 0$ and $e^0 = 1$. Example 1 asked for the initial value to be $\boldsymbol{u}(0) = (4, 2)$:

 $ u(0) $ decides C, D

 $$ C\begin{bmatrix}1\\ 1\end{bmatrix}+D\begin{bmatrix}1\\ -1\end{bmatrix}=\begin{bmatrix}4\\ 2\end{bmatrix}\quad yields\quad C=3\quad and\quad D=1. $$ 

With $C = 3$ and $D = 1$ in the solution (5), the initial value problem is completely solved.

The same three steps that solved $u_{k+1} = Au_k$ now solve $du/dt = Au$:

1. Write  $ u(0) $ as a combination  $ c_1x_1 + \cdots + c_nx_n $ of the eigenvectors of  $ A $.

2. Multiply each eigenvector  $ x_i $ by its growth factor  $ e^{\lambda_i t} $.

3. The solution is the same combination of those pure solutions  $ e^{\lambda t}x $:

 $$ \frac{d\boldsymbol{u}}{dt}=\boldsymbol{A}\boldsymbol{u}\quad\boldsymbol{u}(t)=c_{1}\boldsymbol{e}^{\lambda_{1}t}\boldsymbol{x}_{1}+\cdots+c_{n}\boldsymbol{e}^{\lambda_{n}t}\boldsymbol{x}_{n}. $$ 

Not included: If two $\lambda$'s are equal, with only one eigenvector, another solution is needed. (It will be $te^{\lambda t}x$.) Step 1 needs to diagonalize $A = X\Lambda X^{-1}$: a basis of $n$ eigenvectors.

Example 2 Solve du/dt = Au knowing the eigenvalues  $ \lambda = 1, 2, 3 $ of A:

Typical example

Equation for u

Initial condition  $ u(0) $

 $$ \frac{d\boldsymbol{u}}{d t}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{3}}}\end{bmatrix}\boldsymbol{u}\quad starting from\quad\boldsymbol{u}(0)=\begin{bmatrix}{{{9}}} \\{{{7}}} \\{{{4}}}\end{bmatrix}. $$ 

The eigenvectors are x1 = (1,0,0) and x2 = (1,1,0) and x3 = (1,1,1).

Step 1 The vector  $ u(0) = (9, 7, 4) $ is  $ 2x_1 + 3x_2 + 4x_3 $. Thus  $ (c_1, c_2, c_3) = (2, 3, 4) $.

Step 2 The factors  $ e^{\lambda t} $ give exponential solutions  $ e^{t}x_{1} $ and  $ e^{2t}x_{2} $ and  $ e^{3t}x_{3} $.

Step 3 The combination that starts from  $ \boldsymbol{u}(0) $ is  $ \boldsymbol{u}(t) = 2e^{t}x_{1} + 3e^{2t}x_{2} + 4e^{3t}x_{3} $.

The coefficients 2, 3, 4 came from solving the linear equation  $ c_1x_1 + c_2x_2 + c_3x_3 = u(0) $:

 $$ \begin{bmatrix} \\{{{x_{1}}}}&{{{x_{2}}}}&{{{x_{3}}}} \\\end{bmatrix}\begin{bmatrix}{{{c_{1}}}} \\{{{c_{2}}}} \\{{{c_{3}}}} \\\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\\end{bmatrix}\begin{bmatrix}{{{2}}} \\{{{3}}} \\{{{4}}} \\\end{bmatrix}=\begin{bmatrix}{{{9}}} \\{{{7}}} \\{{{4}}} \\\end{bmatrix}\quad which is\quad X\boldsymbol{c}=\boldsymbol{u}(0). $$ 

You now have the basic idea—how to solve  $ du/dt = Au $. The rest of this section goes further. We solve equations that contain second derivatives, because they arise so often in applications. We also decide whether  $ \boldsymbol{u}(t) $ approaches zero or blows up or just oscillates.

At the end comes the matrix exponential  $ e^{At} $. The short formula  $ e^{At}u(0) $ solves the equation  $ du/dt = Au $ in the same way that  $ A^{k}u_{0} $ solves the equation  $ u_{k+1} = Au_{k} $. Example 3 will show how “difference equations” help to solve differential equations.