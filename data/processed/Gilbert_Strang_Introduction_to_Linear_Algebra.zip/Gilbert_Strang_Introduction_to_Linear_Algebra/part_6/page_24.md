Questions 8–10 are about Fibonacci and Gibonacci numbers.

8 Diagonalize the Fibonacci matrix by completing X−1:

 $$ \begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{\lambda_{1}}}}&{{{\lambda_{2}}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{\lambda_{1}}}}&{{{0}}} \\{{{0}}}&{{{\lambda_{2}}}}\end{bmatrix} $$ 

Do the multiplication  $ X\Lambda^k X^{-1}\begin{bmatrix}1\\ 0\end{bmatrix} $ to find its second component. This is the  $ k $th Fibonacci number  $ F_k = \left(\lambda_1^k - \lambda_2^k\right)/\left(\lambda_1 - \lambda_2\right) $.

Suppose  $ G_{k+2} $ is the average of the two previous numbers  $ G_{k+1} $ and  $ G_{k} $:

 $$ \begin{array}{r l r}&{G_{k+2}=\frac{1}{2}G_{k+1}+\frac{1}{2}G_{k}}\\ &{G_{k+1}=G_{k+1}}\\ &{}\end{array}\quad\mathrm{i s}\qquad\begin{bmatrix}G_{k+2}\\ G_{k+1}\end{bmatrix}=\left[\begin{array}{c c}A&\\ &\end{array}\right]\begin{bmatrix}G_{k+1}\\ G_{k}\end{bmatrix}. $$ 

(a) Find the eigenvalues and eigenvectors of A.

(b) Find the limit as  $ n \to \infty $ of the matrices  $ A^n = X \Lambda^n X^{-1} $.

(c) If  $ G_0 = 0 $ and  $ G_1 = 1 $ show that the Gibonacci numbers approach  $ \frac{2}{3} $.

Prove that every third Fibonacci number in 0, 1, 1, 2, 3, ... is even.

Questions 11–14 are about diagonalizability.

11 True or false: If the eigenvalues of A are 2, 2, 5 then the matrix is certainly

(a) invertible (b) diagonalizable (c) not diagonalizable.

True or false: If the only eigenvectors of A are multiples of  $ (1, 4) $ then A has

(a) no inverse    (b) a repeated eigenvalue    (c) no diagonalization  $ X\Lambda X^{-1} $

Complete these matrices so that  $ \det A = 25 $. Then check that  $ \lambda = 5 $ is repeated—the trace is 10 so the determinant of  $ A - \lambda I $ is  $ (\lambda - 5)^2 $. Find an eigenvector with  $ A\boldsymbol{x} = 5\boldsymbol{x} $. These matrices will not be diagonalizable because there is no second line of eigenvectors.

 $$ A=\begin{bmatrix}{{{8}}} \\{{{2}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{9}}}&{{{4}}} \\{{{1}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{10}}}&{{{5}}} \\{{{-5}}}\end{bmatrix} $$ 

14 The matrix  $ A = \begin{bmatrix} 3 & 1 \\ 0 & 3 \end{bmatrix} $ is not diagonalizable because the rank of  $ A - 3I $ is  $ \_\_\_\_\_ $. Change one entry to make  $ A $ diagonalizable. Which entries could you change?

Questions 15–19 are about powers of matrices.

15  $ A^k = X \Lambda^k X^{-1} $ approaches the zero matrix as  $ k \to \infty $ if and only if every  $ \lambda $ has absolute value less than ___. Which of these matrices has  $ A^k \to 0 $?

 $$ A_{1}=\begin{bmatrix}.6&.9\\ .4&.1\end{bmatrix}\qquad and\qquad A_{2}=\begin{bmatrix}.6&.9\\ .1&.6\end{bmatrix}. $$ 