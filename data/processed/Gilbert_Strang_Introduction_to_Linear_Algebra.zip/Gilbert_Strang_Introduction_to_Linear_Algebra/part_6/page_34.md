<div style="text-align: center;"><img src="imgs/img_in_chart_box_167_118_494_380.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_168_120_874_381.jpg" alt="Image" width="66%" /></div>


<div style="text-align: center;">Figure 6.4: Backward differences spiral in. Leapfrog stays near the correct circle.</div>


## Stability of 2 by 2 Matrices

For the solution of  $ du/dt = Au $, there is a fundamental question. Does the solution approach  $ u = 0 $ as  $ t \to \infty $? Is the problem stable, by dissipating energy? A solution that includes  $ e^t $ is unstable. Stability depends on the eigenvalues of  $ A $.

The complete solution  $ \boldsymbol{u}(t) $ is built from pure solutions  $ e^{\lambda t} \boldsymbol{x} $. If the eigenvalue  $ \lambda $ is real, we know exactly when  $ e^{\lambda t} $ will approach zero: The number  $ \lambda $ must be negative. If the eigenvalue is a complex number  $ \lambda = r + is $, the real part  $ r $ must be negative. When  $ e^{\lambda t} $ splits into  $ e^{rt} e^{ist} $, the factor  $ e^{ist} $ has absolute value fixed at 1:

 $$ e^{i s t}=\cos s t+i\sin s t\quad\mathrm{h a s}\quad|e^{i s t}|^{2}=\cos^{2}s t+\sin^{2}s t=1. $$ 

The real part of  $ \lambda $ controls the growth  $ (r > 0) $ or the decay  $ (r < 0) $

The question is: Which matrices have negative eigenvalues? More accurately, when are the real parts of the  $ \lambda $'s all negative? 2 by 2 matrices allow a clear answer.

Stability A is stable and  $ u(t) \to 0 $ when all eigenvalues  $ \lambda $ have negative real parts. The 2 by 2 matrix  $ A = \begin{bmatrix} a & b \\ c & d \end{bmatrix} $ must pass two tests:

The trace  $ T = a + d $ must be negative.

The determinant  $ D = ad - bc $ must be positive.

Reason If the  $ \lambda $'s are real and negative, their sum is negative. This is the trace  $ T $. Their product is positive. This is the determinant  $ D $. The argument also goes in the reverse direction. If  $ D = \lambda_1 \lambda_2 $ is positive, then  $ \lambda_1 $ and  $ \lambda_2 $ have the same sign. If  $ T = \lambda_1 + \lambda_2 $ is negative, that sign will be negative. We can test  $ T $ and  $ D $.

If the $\lambda$'s are complex numbers, they must have the form $r + is$ and $r - is$. Otherwise $T$ and $D$ will not be real. The determinant $D$ is automatically positive, since $(r + is)(r - is) = r^2 + s^2$. The trace $T$ is $r + is + r - is = 2r$. So a negative trace $T$ means that the real part $r$ is negative and the matrix is stable. Q.E.D.