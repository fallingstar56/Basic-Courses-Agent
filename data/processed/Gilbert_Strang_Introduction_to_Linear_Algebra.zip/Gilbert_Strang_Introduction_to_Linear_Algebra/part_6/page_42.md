7 Suppose $P$ is the projection matrix onto the $45^{\circ}$ line $y = x$ in $\mathbf{R}^{2}$. What are its eigenvalues? If $du/dt = -Pu$ (notice minus sign) can you find the limit of $u(t)$ at $t = \infty$ starting from $\mathbf{u}(0) = (3,1)?$

8 The rabbit population shows fast growth (from 6r) but loss to wolves (from  $ -2w $). The wolf population always grows in this model ( $ -w^{2} $ would control wolves):

 $$ \frac{d r}{d t}=6r-2w\qquad\mathrm{a n d}\qquad\frac{d w}{d t}=2r+w. $$ 

Find the eigenvalues and eigenvectors. If  $ r(0) = w(0) = 30 $ what are the populations at time t? After a long time, what is the ratio of rabbits to wolves?

9 (a) Write  $ (4,0) $ as a combination  $ c_{1}x_{1} + c_{2}x_{2} $ of these two eigenvectors of A:

 $$ \begin{bmatrix}{{{0}}}&{{{1}}} \\{{{-1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{i}}}\end{bmatrix}=i\begin{bmatrix}{{{1}}} \\{{{i}}}\end{bmatrix}\qquad\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{-1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{-i}}}\end{bmatrix}=-i\begin{bmatrix}{{{1}}} \\{{{-i}}}\end{bmatrix}. $$ 

(b) The solution to  $ du/dt = Au $ starting from  $ (4,0) $ is  $ c_1e^{it}x_1 + c_2e^{-it}x_2 $. Substitute  $ e^{it} = \cos t + i \sin t $ and  $ e^{-it} = \cos t - i \sin t $ to find  $ \boldsymbol{u}(t) $.

Questions 10–13 reduce second-order equations to first-order systems for  $ (y, y') $.

10 Find $A$ to change the scalar equation $y'' = 5y' + 4y$ into a vector equation for $u = (y, y')$:

 $$ \frac{d\boldsymbol{u}}{dt}=\begin{bmatrix}y^{\prime}\\ y^{\prime \prime}\end{bmatrix}=\begin{bmatrix}\\ &\end{bmatrix}\begin{bmatrix}y\\ y^{\prime}\end{bmatrix}=A\boldsymbol{u}. $$ 

What are the eigenvalues of $A$? Find them also by substituting $y = e^{\lambda t}$ into $y'' = 5y' + 4y$.

11 The solution to  $ y'' = 0 $ is a straight line  $ y = C + Dt $. Convert to a matrix equation:

 $$ \frac{d}{d t}\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}has the solution\begin{aligned}\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}&=e^{At}\begin{bmatrix}{{{y(0)}}} \\{{{y^{\prime}(0)}}}\end{bmatrix}.\end{aligned} $$ 

This matrix $A$ has $\lambda = 0, 0$ and it cannot be diagonalized. Find $A^2$ and compute $e^{At} = I + At + \frac{1}{2}A^2t^2 + \cdots$. Multiply your $e^{At}$ times $(y(0), y'(0))$ to check the straight line $y(t) = y(0) + y'(0)t$.

Substitute  $ y = e^{\lambda t} $ into  $ y'' = 6y' - 9y $ to show that  $ \lambda = 3 $ is a repeated root. This is trouble; we need a second solution after  $ e^{3t} $. The matrix equation is

 $$ \frac{d}{d t}\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{-9}}}&{{{6}}}\end{bmatrix}\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}. $$ 

Show that this matrix has  $ \lambda = 3, 3 $ and only one line of eigenvectors. Trouble here too. Show that the second solution to  $ y'' = 6y' - 9y $ is  $ y = te^{3t} $.