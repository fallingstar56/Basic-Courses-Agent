6.3. Systems of Differential Equations

<div style="text-align: center;"><img src="imgs/img_in_image_box_164_119_475_312.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_554_119_870_324.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">Figure 6.6: Heat diffuses away from box 2 (left). Wave travels from box 2 (right).</div>


6.3 C Solve the four equations  $ da/dt = 0 $,  $ db/dt = a $,  $ dc/dt = 2b $,  $ dz/dt = 3c $ in that order starting from  $ \boldsymbol{u}(0) = (a(0), b(0), c(0), z(0)) $. Solve the same equations by the matrix exponential in  $ \boldsymbol{u}(t) = e^{At} \boldsymbol{u}(0) $.

Four equations  $ \lambda = 0, 0, 0, 0 $

Eigenvalues on the diagonal

 $$ \frac{d}{dt}\begin{bmatrix}{{{a}}} \\{{{b}}} \\{{{c}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{2}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{3}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{a}}} \\{{{b}}} \\{{{c}}} \\{{{z}}}\end{bmatrix}\quad is\quad\frac{d\boldsymbol{u}}{dt}=\boldsymbol{A}\boldsymbol{u}. $$ 

First find  $ A^2 $,  $ A^3 $,  $ A^4 $ and  $ e^{At} = I + At + \frac{1}{2}(At)^2 + \frac{1}{6}(At)^3 $. Why does the series stop? Why is it true that  $ (e^A)(e^A) = (e^{2A}) $? Always  $ e^{As} $ times  $ e^{At} $ is  $ e^{A}(s + t) $.

Solution 1 Integrate da/dt = 0, then db/dt = a, then dc/dt = 2b and dz/dt = 3c:

 $$ \begin{array}{l l}{a(t)=}&{a(0)}\\ {b(t)=}&{t a(0)+\qquad b(0)}\\ {c(t)=}&{t^{2}a(0)+\quad2t b(0)+\qquad c(0)}\\ {z(t)=}&{t^{3}a(0)+3t^{2}b(0)+3t c(0)+z(0)}\\ \end{array}\quad\begin{array}{l l}{\mathrm{T h e~4~b y~4~m a t r i x~w h i c h~i s}}\\ {\mathrm{m u l t i p l y i n g~}a(0),b(0),c(0),d(0)}\\ {\mathrm{t o~p r o d u c e~}a(t),b(t),c(t),d(t)}\\ {\mathrm{m u s t~b e~t h e~s a m e~}e^{A t}\mathrm{~a s~b e l o w}}\\ \end{array} $$ 

Solution 2 The powers of A (strictly triangular) are all zero after A3.

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{2}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{3}}}&{{{0}}}\end{bmatrix}\quad\boldsymbol{A}^{2}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{2}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{6}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad\boldsymbol{A}^{3}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{6}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad\boldsymbol{A}^{4}=\mathbf{0} $$ 

The diagonals move down at each step. So the series for  $ e^{At} $ stops after four terms:

Same  $ e^{At} $ as in Solution 1

 $$ e^{At}=I+At+\frac{(At)^{2}}{2}+\frac{(At)^{3}}{6}=\begin{bmatrix}{{{1}}} \\{{{t}}}&{{{1}}} \\{{{t^{2}}}}&{{{2t}}}&{{{1}}} \\{{{t^{3}}}}&{{{3t^{2}}}}&{{{3t}}}&{{{1}}}\end{bmatrix} $$ 

The square of  $ e^{A} $ is  $ e^{2A} $. But  $ e^{A}e^{B} $ and  $ e^{B}e^{A} $ and  $ e^{A} + B $ can be all different.