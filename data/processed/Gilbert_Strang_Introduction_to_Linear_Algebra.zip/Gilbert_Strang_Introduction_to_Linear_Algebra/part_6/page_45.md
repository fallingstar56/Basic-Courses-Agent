That centered choice (leapfrog method) in Problem 28 is very successful for small time steps  $ \Delta t $. But find the eigenvalues of  $ A $ for  $ \Delta t = \sqrt{2} $ and 2:

 $$ \boldsymbol{A}=\left[\begin{array}{cc}{{{1}}}&{{{\sqrt{2}}}} \\{{{-\sqrt{2}}}}&{{{-1}}}\end{array}\right]\quad and\quad\boldsymbol{A}=\left[\begin{array}{cc}{{{1}}}&{{{2}}} \\{{{-2}}}&{{{-3}}}\end{array}\right]. $$ 

Both matrices have  $ |\lambda| = 1 $. Compute  $ A^4 $ in both cases and find the eigenvectors of  $ A $. That second value  $ \Delta t = 2 $ is at the border of instability. Any time step  $ \Delta t > 2 $ will lead to  $ |\lambda| > 1 $, and the powers in  $ U_n = A^n U_0 $ will explode.

Note You might say that nobody would compute with  $ \Delta t > 2 $. But if an atom vibrates with  $ y'' = -1000000y $, then  $ \Delta t > .0002 $ will give instability. Leapfrog has a very strict stability limit.  $ Y_{n+1} = Y_n + 3Z_n $ and  $ Z_{n+1} = Z_n - 3Y_{n+1} $ will explode because  $ \Delta t = 3 $ is too large. The matrix has  $ |\lambda| > 1 $.

Another good idea for  $ y'' = -y $ is the trapezoidal method (half forward/half back). This may be the best way to keep  $ (Y_n, Z_n) $ exactly on a circle.

Trapezoidal

 $$ \left[\begin{array}{c c}{1}&{-\Delta t/2}\\ {\Delta t/2}&{1}\\ \end{array}\right]\left[\begin{array}{c}{Y_{n+1}}\\ {Z_{n+1}}\\ \end{array}\right]=\left[\begin{array}{c c}{1}&{\Delta t/2}\\ {-\Delta t/2}&{1}\\ \end{array}\right]\left[\begin{array}{c}{Y_{n}}\\ {Z_{n}}\\ \end{array}\right]. $$ 

(a) Invert the left matrix to write this equation as  $ U_{n+1} = AU_n $. Show that A is an orthogonal matrix:  $ A^\mathrm{T}A = I $. These points  $ U_n $ never leave the circle.  $ A = (I - B)^{-1}(I + B) $ is always an orthogonal matrix if  $ B^\mathrm{T} = -B $.

(b) (Optional MATLAB) Take 32 steps from  $ U_0 = (1, 0) $ to  $ U_{32} $ with  $ \Delta t = 2\pi/32 $.

Is  $ U_{32} = U_0 $? I think there is a small error.

31 The cosine of a matrix is defined like  $ e^{A} $, by copying the series for cos t:

 $$ \cos t=1-\frac{1}{2!}t^{2}+\frac{1}{4!}t^{4}-\cdots\quad\cos A=I-\frac{1}{2!}A^{2}+\frac{1}{4!}A^{4}-\cdots $$ 

(a) If  $ Ax = \lambda x $, multiply each term times  $ x $ to find the eigenvalue of  $ \cos A $.

(b) Find the eigenvalues of  $ A = \begin{bmatrix} \pi & \pi \\ \pi & \pi \end{bmatrix} $ with eigenvectors  $ (1, 1) $ and  $ (1, -1) $.

From the eigenvalues and eigenvectors of  $ \cos A $, find that matrix  $ C = \cos A $.

(c) The second derivative of  $ \cos(At) $ is  $ -A^{2}\cos(At) $.

 $$ \boldsymbol{u}(t)=\cos(A t)\boldsymbol{u}(0)\mathrm{s o l v e s}\frac{d^{2}\boldsymbol{u}}{d t^{2}}=-A^{2}\boldsymbol{u}\mathrm{s t a r t i n g f r o m}\boldsymbol{u}^{\prime}(0)=0. $$ 

Construct  $ \boldsymbol{u}(t) = \cos(At)\boldsymbol{u}(0) $ by the usual three steps for that specific A:

1. Expand  $  u(0) = (4, 2) = c_1 x_1 + c_2 x_2  $ in the eigenvectors.

2. Multiply those eigenvectors by ___ and ___ (instead of  $ e^{\lambda t} $).

3. Add up the solution  $ u(t) = c_1 $ ___  $ x_1 + c_2 $ ___  $ x_2 $.