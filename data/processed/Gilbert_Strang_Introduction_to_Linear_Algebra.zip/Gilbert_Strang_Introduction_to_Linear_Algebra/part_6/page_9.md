Find three eigenvectors for this matrix P (projection matrices have  $ \lambda=1 $ and 0):

Projection matrix

 $$ \boldsymbol{P}=\begin{bmatrix}{{{.2}}}&{{{.4}}}&{{{0}}} \\{{{.4}}}&{{{.8}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

If two eigenvectors share the same  $ \lambda $, so do all their linear combinations. Find an eigenvector of P with no zero components.

From the unit vector  $ u = \left(\frac{1}{6}, \frac{1}{6}, \frac{3}{6}, \frac{5}{6}\right) $ construct the rank one projection matrix  $ P = uu^{\mathrm{T}} $. This matrix has  $ P^{2} = P $ because  $ u^{\mathrm{T}} u = 1 $.

(a)  $ P \cup = u $ comes from  $ (uu^{\mathrm{T}})u = u(\_\_\_\_\_ $. Then u is an eigenvector with  $ \lambda = 1 $.

(b) If v is perpendicular to u show that Pv = 0. Then  $ \lambda = 0 $.

(c) Find three independent eigenvectors of P all with eigenvalue  $ \lambda = 0 $.

Solve  $ \det(Q - \lambda I) = 0 $ by the quadratic formula to reach  $ \lambda = \cos \theta \pm i \sin \theta $:

 $$ Q=\begin{bmatrix}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{bmatrix}\quad rotates the xy plane by the angle\theta.No real\lambda^{\prime}s. $$ 

Find the eigenvectors of Q by solving (Q − λI)x = 0. Use i2 = −1.

Every permutation matrix leaves  $ \boldsymbol{x} = (1, 1, \ldots, 1) $ unchanged. Then  $ \lambda = 1 $. Find two more  $ \lambda $'s (possibly complex) for these permutations, from  $ \det(P - \lambda I) = 0 $:

The determinant of $A$ equals the product $\lambda_{1}\lambda_{2}\cdots\lambda_{n}$. Start with the polynomial $\det(A-\lambda I)$ separated into its $n$ factors (always possible). Then set $\lambda=0$:

 $$ \boldsymbol{P}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{P}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

 $$ \det(A-\lambda I)=(\lambda_{1}-\lambda)(\lambda_{2}-\lambda)\cdots(\lambda_{n}-\lambda)\quad so\quad\det A=\underline{\quad}. $$ 

Check this rule in Example 1 where the Markov matrix has  $ \lambda = 1 $ and  $ \frac{1}{2} $.

The sum of the diagonal entries (the trace) equals the sum of the eigenvalues:

 $$ A=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}\quad has\quad\det(A-\lambda I)=\lambda^{2}-(a+d)\lambda+ad-bc=0. $$ 

The quadratic formula gives the eigenvalues  $ \lambda = (a + d + \sqrt{2})/2 $ and  $ \lambda = \_\_\_\_\_\_ $. Their sum is ___. If  $ A $ has  $ \lambda_1 = 3 $ and  $ \lambda_2 = 4 $ then  $ \det(A - \lambda I) = \_\_\_\_\_\_ $.

If $A$ has $\lambda_1 = 4$ and $\lambda_2 = 5$ then $\det(A - \lambda I) = (\lambda - 4)(\lambda - 5) = \lambda^2 - 9\lambda + 20$. Find three matrices that have trace $a + d = 9$ and determinant $20$ and $\lambda = 4, 5$.