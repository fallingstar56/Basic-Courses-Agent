### 6.4 Symmetric Matrices

1 A symmetric matrix $S$ has $n$ real eigenvalues $\lambda_i$ and $n$ orthonormal eigenvectors $q_1, \ldots, q_n$.

2 Every real symmetric $S$ can be diagonalized: $\boxed{S = Q \Lambda Q^{-1} = Q \Lambda Q^\mathrm{T}}$

3 The number of positive eigenvalues of $S$ equals the number of positive pivots.

4 Antisymmetric matrices $A = -A^\mathrm{T}$ have imaginary $\lambda^\prime$s and orthonormal (complex) $q^\prime$s.

5 Section 9.2 explains why the test $S = S^\mathrm{T}$ becomes $\boldsymbol{S} = \overline{\boldsymbol{S}}^\mathrm{T}$ for complex matrices.

$S = \begin{bmatrix} 0 & i \\ -i & 0 \end{bmatrix} = \overline{S}^\mathrm{T}$ has real $\lambda = 1, -1$.

$A = \begin{bmatrix} 0 & i \\ i & 0 \end{bmatrix} = -\overline{A}^\mathrm{T}$ has $\lambda = i, -i$.

It is no exaggeration to say that symmetric matrices S are the most important matrices the world will ever see—in the theory of linear algebra and also in the applications. We come immediately to the key question about symmetry. Not only the question, but also the two-part answer.

What is special about  $ Sx = \lambda x $ when  $ S $ is symmetric?

We look for special properties of the eigenvalues  $ \lambda $ and eigenvectors  $ \boldsymbol{x} $ when  $ S = S^{\mathrm{T}} $. The diagonalization  $ S = X\Lambda X^{-1} $ will reflect the symmetry of  $ S $. We get some hint by transposing to  $ S^{\mathrm{T}} = (X^{-1})^{\mathrm{T}}\Lambda X^{\mathrm{T}} $. Those are the same since  $ S = S^{\mathrm{T}} $. Possibly  $ X^{-1} $ in the first form equals  $ X^{\mathrm{T}} $ in the second form? Then  $ X^{\mathrm{T}}X = I $. That makes each eigenvector in  $ X $ orthogonal to the other eigenvectors when  $ S = S^{\mathrm{T}} $. Here are the key facts:

1. A symmetric matrix has only real eigenvalues.

2. The eigenvectors can be chosen orthonormal.

Those $n$ orthonormal eigenvectors go into the columns of $X$. Every symmetric matrix can be diagonalized. Its eigenvector matrix $X$ becomes an orthogonal matrix $Q$. Orthogonal matrices have $Q^{-1} = Q^{\mathrm{T}}$—what we suspected about the eigenvector matrix is true. To remember it we write $Q$ instead of $X$, when we choose orthonormal eigenvectors.

Why do we use the word “choose”? Because the eigenvectors do not have to be unit vectors. Their lengths are at our disposal. We will choose unit vectors—eigenvectors of length one, which are orthonormal and not just orthogonal. Then  $ A = X \Lambda X^{-1} $ is in its special and particular form  $ S = Q \Lambda Q^{\mathrm{T}} $ for symmetric matrices.