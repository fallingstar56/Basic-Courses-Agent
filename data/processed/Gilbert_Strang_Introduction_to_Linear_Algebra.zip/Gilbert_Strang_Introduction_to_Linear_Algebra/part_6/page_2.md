Now find the eigenvectors. Solve (A − λI)x = 0 separately for λ1 = 0 and λ2 = 5:

 $$ \begin{array}{r l}{(A-0I)\boldsymbol{x}=}&{{}\left[\begin{matrix}{1}&{2}\\ {2}&{4}\end{matrix}\right]\left[\begin{matrix}{y}\\ {z}\end{matrix}\right]=\left[\begin{matrix}{0}\\ {0}\end{matrix}\right]\mathrm{~y i e l d s~a n~e i g e n v e c t o r}\quad\left[\begin{matrix}{y}\\ {z}\end{matrix}\right]=\left[\begin{matrix}{2}\\ {-1}\end{matrix}\right]\mathrm{~f o r~}\lambda_{1}=0}\end{array} $$ 

 $$ (A-5I)\boldsymbol{x}=\begin{bmatrix}{{{-4}}}&{{{2}}} \\{{{2}}}&{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}}\end{bmatrix}\text{yields an eigenvector}\quad\begin{bmatrix}{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{2}}}\end{bmatrix}\quad\text{for}\lambda_{2}=5. $$ 

The matrices  $ A - 0I $ and  $ A - 5I $ are singular (because 0 and 5 are eigenvalues). The eigenvectors  $ (2, -1) $ and  $ (1, 2) $ are in the nullspaces:  $ (A - \lambda I)x = 0 $ is  $ Ax = \lambda x $.

We need to emphasize: There is nothing exceptional about  $ \lambda = 0 $. Like every other number, zero might be an eigenvalue and it might not. If  $ A $ is singular, the eigenvectors for  $ \lambda = 0 $ fill the nullspace:  $ Ax = 0x = 0 $. If  $ A $ is invertible, zero is not an eigenvalue. We shift  $ A $ by a multiple of  $ I $ to make it singular.

In the example, the shifted matrix  $ A - 5I $ is singular and 5 is the other eigenvalue.

Summary To solve the eigenvalue problem for an n by n matrix, follow these steps:

1. Compute the determinant of  $ A - \lambda I $. With  $ \lambda $ subtracted along the diagonal, this determinant starts with  $ \lambda^n $ or  $ -\lambda^n $. It is a polynomial in  $ \lambda $ of degree  $ n $.

2. Find the roots of this polynomial, by solving  $ \det(A - \lambda I) = 0 $. The n roots are the n eigenvalues of A. They make  $ A - \lambda I $ singular.

3. For each eigenvalue  $ \lambda $, solve  $ (A - \lambda I)x = 0 $ to find an eigenvector  $ x $.

A note on the eigenvectors of 2 by 2 matrices. When  $ A - \lambda I $ is singular, both rows are multiples of a vector  $ (a, b) $. The eigenvector is any multiple of  $ (b, -a) $. The example had

λ = 0 : rows of A − 0I in the direction (1, 2); eigenvector in the direction (2, −1)

 $ \lambda = 5 : \text{rows of } A - 5I \text{ in the direction } (-4, 2); \text{ eigenvector in the direction } (2, 4). $

Previously we wrote that last eigenvector as  $ (1,2) $. Both  $ (1,2) $ and  $ (2,4) $ are correct. There is a whole line of eigenvectors—any nonzero multiple of x is as good as x. MATLAB's  $ \mathbf{eig}(A) $ divides by the length, to make the eigenvector into a unit vector.

We must add a warning. Some 2 by 2 matrices have only one line of eigenvectors. This can only happen when two eigenvalues are equal. (On the other hand  $ A = I $ has equal eigenvalues and plenty of eigenvectors.) Without a full set of eigenvectors, we don’t have a basis. We can’t write every v as a combination of eigenvectors. In the language of the next section, we can’t diagonalize a matrix without n independent eigenvectors.