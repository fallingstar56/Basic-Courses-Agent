The projection matrix  $ P = \begin{bmatrix} .5 & .5 \\ .5 & .5 \end{bmatrix} $ has eigenvalues  $ \lambda = 1 $ and  $ \lambda = 0 $.

Example 2

Its eigenvectors are  $ \boldsymbol{x}_1 = (1,1) $ and  $ \boldsymbol{x}_2 = (1,-1) $. For those vectors,  $ P\boldsymbol{x}_1 = \boldsymbol{x}_1 $ (steady state) and  $ P\boldsymbol{x}_2 = \boldsymbol{0} $ (nullspace). This example illustrates Markov matrices and singular matrices and (most important) symmetric matrices. All have special  $ \lambda $'s and  $ \boldsymbol{x} $'s:

1. Markov matrix: Each column of P adds to 1, so  $ \lambda = 1 $ is an eigenvalue.

2. P is singular, so  $ \lambda = 0 $ is an eigenvalue.

3. P is symmetric, so its eigenvectors  $ (1,1) $ and  $ (1,-1) $ are perpendicular.

The only eigenvalues of a projection matrix are 0 and 1. The eigenvectors for  $ \lambda = 0 $ (which means  $ P\boldsymbol{x} = 0\boldsymbol{x} $) fill up the nullspace. The eigenvectors for  $ \lambda = 1 $ (which means  $ P\boldsymbol{x} = \boldsymbol{x} $) fill up the column space. The nullspace is projected to zero. The column space projects onto itself. The projection keeps the column space and destroys the nullspace:

Project each part

 $$ v=\begin{bmatrix}1\\ -1\end{bmatrix}+\begin{bmatrix}2\\ 2\end{bmatrix}\quad projects onto $$ 

 $$ P v=\begin{bmatrix}0\\ 0\end{bmatrix}+\begin{bmatrix}2\\ 2\end{bmatrix}. $$ 

Projections have  $ \lambda = 0 $ and 1. Permutations have all  $ |\lambda| = 1 $. The next matrix  $ R $ is a reflection and at the same time a permutation.  $ R $ also has special eigenvalues.

Example 3

The reflection matrix  $ R = \begin{bmatrix} 0 & 1 \\ 1 & 0 \end{bmatrix} $ has eigenvalues 1 and -1.



The eigenvector  $ (1,1) $ is unchanged by  $ R $. The second eigenvector is  $ (1,-1) $—its signs are reversed by  $ R $. A matrix with no negative entries can still have a negative eigenvalue! The eigenvectors for  $ R $ are the same as for  $ P $, because reflection = 2(projection) -  $ I $:

 $$ R=2P-I $$ 

 $$ \begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}=2\begin{bmatrix}{{{.5}}}&{{{.5}}} \\{{{.5}}}&{{{.5}}}\end{bmatrix}-\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

When a matrix is shifted by I, each  $ \lambda $ is shifted by 1. No change in eigenvectors.

<div style="text-align: center;"><img src="imgs/img_in_image_box_167_949_415_1077.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;">Projection onto blue line</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_547_948_854_1097.jpg" alt="Image" width="28%" /></div>


Reflection across line

<div style="text-align: center;">Figure 6.2: Projections P have eigenvalues 1 and 0. Reflections R have  $ \lambda = 1 $ and -1. A typical x changes direction, but an eigenvector stays along the same line.</div>
