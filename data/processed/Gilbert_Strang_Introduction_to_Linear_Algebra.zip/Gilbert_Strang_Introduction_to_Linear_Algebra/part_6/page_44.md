22 If  $ A^{2} = A $ show that the infinite series produces  $ e^{At} = I + (e^{t} - 1)A $. For  $ A = \begin{bmatrix} 1 & 4 \\ 0 & 0 \end{bmatrix} $ in Problem 21 this gives  $ e^{At} = \_\_\_\_\_\_  $.

23 Generally  $ e^{A}e^{B} $ is different from  $ e^{B}e^{A} $. They are both different from  $ e^{A+B} $. Check this using Problems 21–22 and 19. (If AB = BA, all three are the same.)

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{4}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\qquad\boldsymbol{B}=\begin{bmatrix}{{{0}}}&{{{-4}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\qquad\boldsymbol{A}+\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Write  $ A = \begin{bmatrix} 1 & 1 \\ 0 & 3 \end{bmatrix} $ as  $ X \Lambda X^{-1} $. Multiply  $ X e^{\Lambda t} X^{-1} $ to find the matrix exponential  $ e^{A t} $. Check  $ e^{A t} $ and the derivative of  $ e^{A t} $ when t = 0.

Put A = [1 3] into the infinite series to find e^{At}. First compute A^{2} and A^{n} :

 $$ e^{A t}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}+\begin{bmatrix}{{{t}}}&{{{3t}}} \\{{{0}}}&{{{0}}}\end{bmatrix}+\frac{1}{2}\begin{bmatrix}\\\end{bmatrix}+\cdots=\begin{bmatrix}{{{e^{t}}}} \\{{{0}}}\end{bmatrix}. $$ 

26 (Recommended) Give two reasons why the matrix exponential  $ e^{At} $ is never singular:

(a) Write down its inverse.

(b) Why are these eigenvalues nonzero? If Ax = λx then e^{At}x = ___x.

Find a solution  $ x(t) $,  $ y(t) $ that gets large as  $ t \to \infty $. To avoid this instability a scientist exchanged the two equations:

 $$ \begin{array}{l} dx/dt=\quad0x-4y \\ dy/dt=-2x+2y \end{array}  \quad \mathrm{becomes} \quad \begin{array}{l} dy/dt=-2x+2y \\ dx/dt=\quad0x-4y. \end{array} $$ 

Now the matrix  $ \begin{bmatrix} -2 & 2 \\ 0 & -4 \end{bmatrix} $ is stable. It has negative eigenvalues. How can this be?

## Challenge Problems

28 Centering  $ y'' = -y $ in Example 3 will produce  $ Y_{n+1} - 2Y_n + Y_{n-1} = -(\Delta t)^2 Y_n $. This can be written as a one-step difference equation for  $ \boldsymbol{U} = (Y, Z) $:

 $$ \begin{array}{l}{{{Y_{n+1}=Y_{n}+\Delta t Z_{n}}}} \\{{{Z_{n+1}=Z_{n}-\Delta t Y_{n+1}}}}\end{array}\qquad\begin{array}{l}{{{\left[\begin{array}{cc}1}}}&{{{0}}} \\{{{\Delta t}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{Y_{n+1}}}} \\{{{Z_{n+1}}}}\end{array}\right]=\left[\begin{array}{cc}{{{1}}}&{{{\Delta t}}} \\{{{0}}}&{{{1}}}\end{array}\right]\left[\begin{array}{l}{{{Y_{n}}}} \\{{{Z_{n}}}}\end{array}\right] $$ 

Invert the matrix on the left side to write this as  $ U_{n+1} = AU_n $. Show that  $ \det A = 1 $. Choose the large time step  $ \Delta t = 1 $ and find the eigenvalues  $ \lambda_1 $ and  $ \lambda_2 = \overline{\lambda}_1 $ of  $ A $:

 $$ A=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{-1}}}&{{{0}}}\end{bmatrix}\mathrm{has}|\lambda_{1}|=|\lambda_{2}|=1.\mathrm{Show that}A^{6}\mathrm{is exactly}I. $$ 

After 6 steps to t = 6,  $ U_6 $ equals  $ U_0 $. The exact  $ y = \cos t $ returns to 1 at  $ t = 2\pi $.