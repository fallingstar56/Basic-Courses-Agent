The eigenvectors come separately by solving  $ (A - \lambda I)x = 0 $ which is  $ Ax = \lambda x $:

 $$ \begin{aligned}\lambda&=1:\quad(A-I)\boldsymbol{x}&=\begin{bmatrix}1&-1\\ -1&1\end{bmatrix}\begin{bmatrix}x\\ y\end{bmatrix}=\begin{bmatrix}0\\ 0\end{bmatrix}gives the eigenvector\boldsymbol{x}_{1}&=\begin{bmatrix}1\\ 1\end{bmatrix}\end{aligned} $$ 

 $$ \lambda=3:\quad(A-3I)x=\begin{bmatrix}-1&-1\\ -1&-1\end{bmatrix}\begin{bmatrix}x\\ y\end{bmatrix}=\begin{bmatrix}0\\ 0\end{bmatrix}gives the eigenvector x_{2}=\begin{bmatrix}1\\ -1\end{bmatrix} $$ 

 $ A^2 $ and  $ A^{-1} $ and  $ A + 4I $ keep the same eigenvectors as  $ A $. Their eigenvalues are  $ \lambda^2 $ and  $ \lambda^{-1} $ and  $ \lambda + 4 $:

 $$ A^{2}\ has\ eigenvalue\ 1^{2}=1\ and\ 3^{2}=9\quad A^{-1}\ has\ \frac{1}{1}\ and\ \frac{1}{3}\quad A+4I\ has\ \begin{array}{l}1+4=5\\ 3+4=7\end{array} $$ 

Notes for later sections: A has orthogonal eigenvectors (Section 6.4 on symmetric matrices). A can be diagonalized since  $ \lambda_1 \neq \lambda_2 $ (Section 6.2). A is similar to any 2 by 2 matrix with eigenvalues 1 and 3 (Section 6.2). A is a positive definite matrix (Section 6.5) since  $ A = A^\mathrm{T} $ and the  $ \lambda $s are positive.

### 6.1 B How can you estimate the eigenvalues of any A? Gershgorin gave this answer

Every eigenvalue of $A$ must be “near” at least one of the entries $a_{ii}$ on the main diagonal. For $\lambda$ to be “near $a_{ii}$” means that $|a_{ii} - \lambda|$ is no more than the sum $R_i$ of all other $|a_{ij}|$ in that row $i$ of the matrix. Then $R_i = \Sigma_{j \neq i}|a_{ij}|$ is the radius of a circle centered at $a_{ii}$.

Every  $ \lambda $ is in the circle around one or more diagonal entries  $ a_{ii}: |a_{ii} - \lambda| \leq R_i $.

Here is the reasoning. If  $ \lambda $ is an eigenvalue, then  $ A - \lambda I $ is not invertible. Then  $ A - \lambda I $ cannot be diagonally dominant (see Section 2.5). So at least one diagonal entry  $ a_{ii} - \lambda $ is not larger than the sum  $ R_i $ of all other entries  $ |a_{ij}| $ (we take absolute values!) in row  $ i $.

Example 1. Every eigenvalue  $ \lambda $ of this  $ A $ falls into one or both of the Gershgorin circles: The centers are  $ a $ and  $ d $, the radii are  $ R_1 = |b| $ and  $ R_2 = |c| $.

 $$ A=\left[\begin{array}{cc}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{array}\right]\qquad\begin{array}{c}First circle:\quad|\lambda-a|\leq|b|\\ Second circle:\quad|\lambda-d|\leq|c|\end{array} $$ 

Those are circles in the complex plane, since  $ \lambda $ could certainly be complex.

Example 2. All eigenvalues of this A lie in a circle of radius  $ R = 3 $ around one or more of the diagonal entries  $ d_1, d_2, d_3 $:

 $$ \boldsymbol{A}=\left[\begin{array}{ccc}{{{d_{1}}}}&{{{1}}}&{{{2}}} \\{{{2}}}&{{{d_{2}}}}&{{{1}}} \\{{{-1}}}&{{{2}}}&{{{d_{3}}}}\end{array}\right]\qquad\begin{array}{l}{{{\left|\lambda-d_{1}\right|\leq1+2=R_{1}}}} \\{{{\left|\lambda-d_{2}\right|\leq2+1=R_{2}}}} \\{{{\left|\lambda-d_{3}\right|\leq1+2=R_{3}}}}\end{array} $$ 

You see that “near” means not more than 3 away from  $ d_{1} $ or  $ d_{2} $ or  $ d_{3} $, for this example.