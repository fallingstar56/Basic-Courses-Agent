4 Compute the eigenvalues and eigenvectors of A and  $ A^{2} $:

 $$ A=\begin{bmatrix}{{{-1}}}&{{{3}}} \\{{{2}}}&{{{0}}}\end{bmatrix}\quad and\quad A^{2}=\begin{bmatrix}{{{7}}}&{{{-3}}} \\{{{-2}}}&{{{6}}}\end{bmatrix}. $$ 

 $ A^{2} $ has the same ___ as A. When A has eigenvalues  $ \lambda_{1} $ and  $ \lambda_{2} $,  $ A^{2} $ has eigenvalues ___. In this example, why is  $ \lambda_{1}^{2} + \lambda_{2}^{2} = 13 $?

5 Find the eigenvalues of A and B (easy for triangular matrices) and A + B:

 $$ A=\begin{bmatrix}{{{3}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{3}}}\end{bmatrix}\quad and\quad A+B=\begin{bmatrix}{{{4}}}&{{{1}}} \\{{{1}}}&{{{4}}}\end{bmatrix}. $$ 

Eigenvalues of  $ A + B $ (are equal to) (are not equal to) eigenvalues of A plus eigenvalues of B.

6 Find the eigenvalues of A and B and AB and BA:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{A}\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{1}}}&{{{3}}}\end{bmatrix}\quad and\quad\boldsymbol{B}\boldsymbol{A}=\begin{bmatrix}{{{3}}}&{{{2}}} \\{{{1}}}&{{{1}}}\end{bmatrix}. $$ 

(a) Are the eigenvalues of AB equal to eigenvalues of A times eigenvalues of B?

(b) Are the eigenvalues of AB equal to the eigenvalues of BA?

7 Elimination produces A = LU. The eigenvalues of U are on its diagonal; they are the ___. The eigenvalues of L are on its diagonal; they are all ___. The eigenvalues of A are not the same as ___.

(a) If you know that x is an eigenvector, the way to find  $ \lambda $ is to ___.

(b) If you know that  $ \lambda $ is an eigenvalue, the way to find x is to ___.

9 What do you do to the equation  $ Ax = \lambda x $, in order to prove (a), (b), and (c)?

(a)  $ \lambda^{2} $ is an eigenvalue of  $ A^{2} $, as in Problem 4.

(b)  $ \lambda^{-1} $ is an eigenvalue of  $ A^{-1} $, as in Problem 3.

(c)  $ \lambda + 1 $ is an eigenvalue of  $ A + I $, as in Problem 2.

10 Find the eigenvalues and eigenvectors for both of these Markov matrices A and  $ A^{\infty} $. Explain from those answers why  $ A^{100} $ is close to  $ A^{\infty} $:

 $$ A=\begin{bmatrix}0&0\\ 0&0\end{bmatrix}\quad and\quad A^{\infty}=\begin{bmatrix}1/3&1/3\\ 2/3&2/3\end{bmatrix}. $$ 

Here is a strange fact about 2 by 2 matrices with eigenvalues  $ \lambda_1 \neq \lambda_2 $: The columns of  $ A - \lambda_1 I $ are multiples of the eigenvector  $ x_2 $. Any idea why this should be?