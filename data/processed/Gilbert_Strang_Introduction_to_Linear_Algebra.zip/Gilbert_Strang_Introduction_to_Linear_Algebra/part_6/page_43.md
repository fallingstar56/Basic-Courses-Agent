(a) Write down two familiar functions that solve the equation  $ d^{2}y/dt^{2} = -9y $. Which one starts with  $ y(0) = 3 $ and  $ y'(0) = 0 $?

(b) This second-order equation  $ y'' = -9y $ produces a vector equation  $ u' = Au $:

 $$ \boldsymbol{u}=\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}\qquad\frac{d\boldsymbol{u}}{dt}=\begin{bmatrix}{{{y^{\prime}}}} \\{{{y^{\prime\prime}}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{-9}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}=A\boldsymbol{u}. $$ 

Find  $ u(t) $ by using the eigenvalues and eigenvectors of  $ A: u(0) = (3,0) $.

14 The matrix in this question is skew-symmetric (A^{T} = -A):

 $$ \frac{d\boldsymbol{u}}{d t}=\begin{bmatrix}{{{0}}}&{{{c}}}&{{{-b}}} \\{{{-c}}}&{{{0}}}&{{{a}}} \\{{{b}}}&{{{-a}}}&{{{0}}}\end{bmatrix}\boldsymbol{u}\qquad or\qquad\begin{aligned}u_{1}^{\prime}&=c u_{2}-b u_{3}\\u_{2}^{\prime}&=a u_{3}-c u_{1}\\u_{3}^{\prime}&=b u_{1}-a u_{2}.\end{aligned} $$ 

(a) The derivative of  $ \|u(t)\|^2 = u_1^2 + u_2^2 + u_3^2 $ is  $ 2u_1u_1' + 2u_2u_2' + 2u_3u_3' $. Substitute  $ u_1', u_2', u_3' $ to get zero. Then  $ \|u(t)\|^2 $ stays equal to  $ \|u(0)\|^2 $.

(b) When $A$ is skew-symmetric, $Q = e^{At}$ is orthogonal. Prove $Q^{\mathrm{T}} = e^{-At}$ from the series for $Q = e^{At}$. Then $Q^{\mathrm{T}}Q = I$.

15 A particular solution to  $ du/dt = Au - b $ is  $ u_p = A^{-1}b $, if  $ A $ is invertible. The usual solutions to  $ du/dt = Au $ give  $ u_n $. Find the complete solution  $ u = u_p + u_n $:

(a)

 $$ \frac{du}{dt}=u-4 $$ 

 $$ \frac{d\boldsymbol{u}}{d t}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}\end{bmatrix}\boldsymbol{u}-\begin{bmatrix}{{{4}}} \\{{{6}}}\end{bmatrix}. $$ 

16 If $c$ is not an eigenvalue of $A$, substitute $u = e^{ct}v$ and find a particular solution to $du/dt = Au - e^{ct}b$. How does it break down when $c$ is an eigenvalue of $A”？The “nullspace” of $du/dt = Au$ contains the usual solutions $e^{\lambda_i t}x_i$.

17 Find a matrix A to illustrate each of the unstable regions in Figure 6.5:

 $$ \begin{aligned}(a)\lambda_{1}<0and\lambda_{2}>0\quad(b)\lambda_{1}>0and\lambda_{2}>0\quad(c)\lambda=a\pm ib with a>0.\end{aligned} $$ 

Questions 18–27 are about the matrix exponential  $ e^{At} $.

18 Write five terms of the infinite series for  $ e^{At} $. Take the  $ t $ derivative of each term. Show that you have four terms of  $ Ae^{At} $. Conclusion:  $ e^{At}u_0 $ solves  $ u' = Au $.

19 The matrix  $ B = \begin{bmatrix} 0 & -4 \\ 0 & 0 \end{bmatrix} $ has  $ B^2 = 0 $. Find  $ e^{Bt} $ from a (short) infinite series. Check that the derivative of  $ e^{Bt} $ is  $ Be^{Bt} $.

20 Starting from  $ u(0) $ the solution at time T is  $ e^{AT}u(0) $. Go an additional time t to reach  $ e^{At}e^{AT}u(0) $. This solution at time  $ t+T $ can also be written as ___.

Conclusion:  $ e^{At} $ times  $ e^{AT} $ equals ___.

21 Write  $ A = \begin{bmatrix} 1 & 4 \\ 0 & 0 \end{bmatrix} $ in the form  $ X\Lambda X^{-1} $. Find  $ e^{At} $ from  $ Xe^{\Lambda t}X^{-1} $.