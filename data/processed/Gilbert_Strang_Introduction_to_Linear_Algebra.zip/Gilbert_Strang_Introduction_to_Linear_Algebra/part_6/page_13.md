### 6.2 Diagonalizing a Matrix

1 The columns of AX = XΛ are Ax_k = λ_k x_k. The eigenvalue matrix Λ is diagonal.

2 n independent eigenvectors in X diagonalize A

 $$ \left|A=X\Lambda X^{-1}\mathrm{a n d}\Lambda=X^{-1}A X\right| $$ 

3 The eigenvector matrix X also diagonalizes all powers  $ A^{k} $ :

 $$ \boxed{A^{k}=X\Lambda^{k}X^{-1}} $$ 

 $$ 4\operatorname{S o l v e}u_{k+1}=A u_{k}\operatorname{b y}u_{k}=A^{k}u_{0}=X\Lambda^{k}X^{-1}u_{0}=\left|\begin{array}{c}c_{1}(\lambda_{1})^{k}x_{1}+\cdots+c_{n}(\lambda_{n})^{k}x_{n}\end{array}\right| $$ 

5 No equal eigenvalues  $ \Rightarrow $ X is invertible and A can be diagonalized.

Equal eigenvalues  $ \Rightarrow $ A might have too few independent eigenvectors. Then  $ X^{-1} $ fails.

6 Every matrix C = B−1 AB has the same eigenvalues as A. These C's are "similar" to A.

When x is an eigenvector, multiplication by A is just multiplication by a number λ: Ax = λx. All the difficulties of matrices are swept away. Instead of an interconnected system, we can follow the eigenvectors separately. It is like having a diagonal matrix, with no off-diagonal interconnections. The 100th power of a diagonal matrix is easy.

The point of this section is very direct. The matrix A turns into a diagonal matrix  $ \Lambda $ when we use the eigenvectors properly. This is the matrix form of our key idea. We start right off with that one essential computation. The next page explains why  $ AX = X\Lambda $.

Diagonalization Suppose the $n$ by $n$ matrix $A$ has $n$ linearly independent eigenvectors $x_{1},\ldots,x_{n}$. Put them into the columns of an eigenvector matrix $X$. Then $X^{-1}AX$ is the eigenvalue matrix $\Lambda$:

Eigenvector matrix X

Eigenvalue matrix Λ

 $$ \boldsymbol{X}^{-1}\boldsymbol{A}\boldsymbol{X}=\boldsymbol{\Lambda}=\begin{bmatrix}\lambda_{1}&&\\ &\ddots&\\ &&\lambda_{n}\end{bmatrix}. $$ 

The matrix A is “diagonalized.” We use capital lambda for the eigenvalue matrix, because the small  $ \lambda $'s (the eigenvalues) are on its diagonal.

Example 1 This A is triangular so its eigenvalues are on the diagonal:  $ \lambda = 1 $ and  $ \lambda = 6 $.

Eigenvectors go into X

 $$ \begin{bmatrix}1\\ 0\end{bmatrix}\begin{bmatrix}1\\ 1\end{bmatrix} $$ 

 $$ \begin{aligned}\begin{bmatrix}{{{1}}}&{{{-1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}&\quad\begin{bmatrix}{{{1}}}&{{{5}}} \\{{{0}}}&{{{6}}}\end{bmatrix}&\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}&=&\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{6}}}\end{bmatrix}\\ X^{-1}&\quad A&\quad X&\quad=\quad\Lambda\end{aligned} $$ 

In other words  $ A = X \Lambda X^{-1} $. Then watch  $ A^2 = X \Lambda X^{-1} X \Lambda X^{-1} $. So  $ A^2 $ is  $ X \Lambda^2 X^{-1} $.

A² has the same eigenvectors in X and squared eigenvalues in Λ².