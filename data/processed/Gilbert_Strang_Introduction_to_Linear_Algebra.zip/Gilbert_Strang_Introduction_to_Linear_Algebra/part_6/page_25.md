(Recommended) Find  $ \Lambda $ and  $ X $ to diagonalize  $ A_1 $ in Problem 15. What is the limit of  $ \Lambda^k $ as  $ k \to \infty $? What is the limit of  $ X\Lambda^k X^{-1} $? In the columns of this limiting matrix you see the ___.

Find Λ and X to diagonalize A2 in Problem 15. What is (A2)¹⁰u₀ for these u₀?

 $$ u_{0}=\begin{bmatrix}3\\ 1\end{bmatrix}\quad and\quad u_{0}=\begin{bmatrix}3\\ -1\end{bmatrix}\quad and\quad u_{0}=\begin{bmatrix}6\\ 0\end{bmatrix}. $$ 

Diagonalize A and compute XΛ k X−1 to prove this formula for A k :

 $$ A=\begin{bmatrix}2&-1\\ -1&2\end{bmatrix}\qquad has\qquad A^{k}=\frac{1}{2}\begin{bmatrix}1+3^{k}&1-3^{k}\\ 1-3^{k}&1+3^{k}\end{bmatrix}. $$ 

Diagonalize B and compute  $ X\Lambda^{k}X^{-1} $ to prove this formula for  $ B^{k} $:

Suppose  $ A = X \Lambda X^{-1} $. Take determinants to prove  $ \det A = \det \Lambda = \lambda_1 \lambda_2 \cdots \lambda_n $. This quick proof only works when  $ A $ can be ___.

 $$ B=\begin{bmatrix}{{{5}}}&{{{1}}} \\{{{0}}}&{{{4}}}\end{bmatrix}\qquad has\qquad B^{k}=\begin{bmatrix}{{{5^{k}}}}&{{{5^{k}-4^{k}}}} \\{{{0}}}&{{{4^{k}}}}\end{bmatrix}. $$ 

Show that trace  $ XY = \text{trace } YX $, by adding the diagonal entries of  $ XY $ and  $ YX $:

 $$ X=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}&{{{d}}}\end{bmatrix}\qquad and\qquad Y=\begin{bmatrix}{{{q}}}&{{{r}}} \\{{{s}}}&{{{t}}}\end{bmatrix}. $$ 

Now choose Y to be  $ \Lambda X^{-1} $. Then  $ X\Lambda X^{-1} $ has the same trace as  $ \Lambda X^{-1}X = \Lambda $. This proves that the trace of A equals the trace of  $ \Lambda = \text{sum of the eigenvalues} $.

 $ AB - BA = I $ is impossible since the left side has trace = ___. But find an elimination matrix so that  $ A = E $ and  $ B = E^{T} $ give

 $$ AB-BA=\begin{bmatrix}{{{-1}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad which has trace zero. $$ 

If  $ A = X \Lambda X^{-1} $, diagonalize the block matrix  $ B = \begin{bmatrix} A & 0 \\ 0 & 2A \end{bmatrix} $. Find its eigenvalue and eigenvector (block) matrices.

Consider all 4 by 4 matrices  $ A $ that are diagonalized by the same fixed eigenvector matrix  $ X $. Show that the  $ A $'s form a subspace  $ (cA $ and  $ A_1 + A_2 $ have this same  $ X $). What is this subspace when  $ X = I $? What is its dimension?

Suppose  $ A^2 = A $. On the left side  $ A $ multiplies each column of  $ A $. Which of our four subspaces contains eigenvectors with  $ \lambda = 1 $? Which subspace contains eigenvectors with  $ \lambda = 0 $? From the dimensions of those subspaces,  $ A $ has a full set of independent eigenvectors. So a matrix with  $ A^2 = A $ can be diagonalized.