### Problem Set 6.3

1 Find two  $ \lambda $'s and  $ x $'s so that  $ u = e^{\lambda t} x $ solves

 $$ \frac{d\boldsymbol{u}}{dt}=\begin{bmatrix}{{{4}}}&{{{3}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\boldsymbol{u}. $$ 

What combination  $ u = c_1 e^{\lambda_1 t} x_1 + c_2 e^{\lambda_2 t} x_2 $ starts from  $ u(0) = (5, -2) $?

Solve Problem 1 for  $ \boldsymbol{u} = (y, z) $ by back substitution, z before y:

 $$  Solve\ \frac{dz}{dt}=z from z(0)=-2.\qquad Then solve\ \frac{dy}{dt}=4y+3z from y(0)=5. $$ 

The solution for y will be a combination of  $ e^{4t} $ and  $ e^{t} $. The  $ \lambda $'s are 4 and 1.

(a) If every column of A adds to zero, why is  $ \lambda = 0 $ an eigenvalue?

(b) With negative diagonal and positive off-diagonal adding to zero,  $ u' = Au $ will be a “continuous” Markov equation. Find the eigenvalues and eigenvectors, and the steady state as  $ t \to \infty $

 $$ \begin{aligned}Solve\quad\frac{d\boldsymbol{u}}{dt}=\begin{bmatrix}{{{-2}}}&{{{3}}} \\{{{2}}}&{{{-3}}}\end{bmatrix}\boldsymbol{u}\quad with\quad\boldsymbol{u}(0)=\begin{bmatrix}{{{4}}} \\{{{1}}}\end{bmatrix}.\quad What is\boldsymbol{u}(\infty)?\end{aligned} $$ 

4 A door is opened between rooms that hold  $ v(0) = 30 $ people and  $ w(0) = 10 $ people. The movement between rooms is proportional to the difference  $ v - w $:

 $$ \frac{d v}{d t}=w-v\qquad\mathrm{a n d}\qquad\frac{d w}{d t}=v-w. $$ 

Show that the total  $ v + w $ is constant (40 people). Find the matrix in  $ du/dt = Au $ and its eigenvalues and eigenvectors. What are  $ v $ and  $ w $ at  $ t = 1 $ and  $ t = \infty $?

R

 $$ \frac{d v}{d t}=v-w\qquad\mathrm{a n d}\qquad\frac{d w}{d t}=w-v. $$ 

The total  $ v+w $ still remains constant. How are the  $ \lambda $'s changed now that  $ A $ is changed to  $ -A $? But show that  $ v(t) $ grows to infinity from  $ v(0) = 30 $.

A has real eigenvalues but B has complex eigenvalues:

 $$ \boldsymbol{A}=\left[\begin{array}{ll}{{{a}}}&{{{1}}} \\{{{1}}}&{{{a}}}\end{array}\right]\quad\boldsymbol{B}=\left[\begin{array}{cc}{{{b}}}&{{{-1}}} \\{{{1}}}&{{{b}}}\end{array}\right]\quad(a and b are real) $$ 

Find the conditions on $a$ and $b$ so that all solutions of $du/dt = Au$ and $dv/dt = Bv$ approach zero as $t \to \infty$: $\mathbf{Re} \lambda < 0$ for all eigenvalues.