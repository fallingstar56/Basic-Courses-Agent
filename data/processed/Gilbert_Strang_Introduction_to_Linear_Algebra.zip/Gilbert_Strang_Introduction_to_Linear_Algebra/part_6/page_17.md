We are using $C$ instead of $\Lambda$ because $C$ might not be diagonal. We are using $B$ instead of $X$ because the columns of $B$ might not be eigenvectors. We only require that $B$ is invertible—its columns can contain any basis for $\mathbf{R}^n$. The key fact about similar matrices stays true. Similar matrices $A$ and $C$ have the same eigenvalues.

All the matrices  $ A = BCB^{-1} $ are “similar.” They all share the eigenvalues of C.

Proof Suppose  $ Cx = \lambda x $. Then  $ BCB^{-1} $ has the same eigenvalue  $ \lambda $ with the new eigenvector  $ Bx $:

 $$ \begin{array}{r l}{S a m e~\lambda}&{{}\quad(B C B^{-1})(B\boldsymbol{x})=B C\boldsymbol{x}=B\lambda\boldsymbol{x}=\lambda(B\boldsymbol{x}).}\end{array} $$ 

A fixed matrix C produces a family of similar matrices  $ BCB^{-1} $, allowing all B. When C is the identity matrix, the “family” is very small. The only member is  $ BIB^{-1} = I $. The identity matrix is the only diagonalizable matrix with all eigenvalues  $ \lambda = 1 $.

The family is larger when  $ \lambda = 1 $ and 1 with only one eigenvector (not diagonalizable). The simplest C is the Jordan form—to be developed in Section 8.3. All the similar A's have two parameters r and s, not both zero: always determinant = 1 and trace = 2.

 $$ \boldsymbol{C}=\begin{bmatrix}\mathbf{1}&\mathbf{1}\\ 0&\mathbf{1}\end{bmatrix}=\mathrm{Jordan~form~gives~}\boldsymbol{A}=\boldsymbol{B}\boldsymbol{C}\boldsymbol{B}^{-1}=\begin{bmatrix}1-r s&r^{2}\\ -s^{2}&1+r s\end{bmatrix}. $$ 

For an important example I will take eigenvalues  $ \lambda = 1 $ and 0 (not repeated!). Now the whole family is diagonalizable with the same eigenvalue matrix  $ \Lambda $. We get every 2 by 2 matrix that has eigenvalues 1 and 0. The trace is 1 and the determinant is zero:

All similar

 $$ \Lambda=\left[\begin{array}{cc}{{{\mathbf{1}}}}&{{{0}}} \\{{{0}}}&{{{\mathbf{0}}}}\end{array}\right]\quad A=\left[\begin{array}{cc}{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{array}\right]\quad or A=\left[\begin{array}{cc}{{{.5}}}&{{{.5}}} \\{{{.5}}}&{{{.5}}}\end{array}\right]\quad or any A=\frac{x\boldsymbol{y}^{\mathrm{T}}}{\boldsymbol{x}^{\mathrm{T}}\boldsymbol{y}}. $$ 

The family contains all matrices with  $ A^2 = A $, including  $ A = \Lambda $ when  $ B = I $. When  $ A $ is symmetric these are also projection matrices. Eigenvalues 1 and 0 make life easy.

Fibonacci Numbers

We present a famous example, where eigenvalues tell how fast the Fibonacci numbers grow. Every new Fibonacci number is the sum of the two previous  $ F' $s:

 $$ \begin{array}{r l r l r l}{\mathrm{T h e~s e q u e n c e}}&{{}0,1,1,2,3,5,8,13,\dots}&{}&{{}\mathrm{c o m e s~f r o m}}&{}&{{}F_{k+2}=F_{k+1}+F_{k}.}\end{array} $$ 

These numbers turn up in a fantastic variety of applications. Plants and trees grow in a spiral pattern, and a pear tree has 8 growths for every 3 turns. For a willow those numbers can be 13 and 5. The champion is a sunflower of Daniel O'Connell, which had 233 seeds in 144 loops. Those are the Fibonacci numbers  $ F_{13} $ and  $ F_{12} $. Our problem is more basic.