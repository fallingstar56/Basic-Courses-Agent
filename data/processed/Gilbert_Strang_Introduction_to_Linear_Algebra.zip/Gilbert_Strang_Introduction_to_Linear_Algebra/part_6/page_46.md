32 Explain one of these three proofs that the square of  $ e^{A} $ is  $ e^{2A} $.

1. Solving with  $ e^{A} $ from t = 0 to 1 and then 1 to 2 agrees with  $ e^{2A} $ from 0 to 2.

2. The squared series  $ (I + A + \frac{A^2}{2} + \cdots)^2 $ matches  $ I + 2A + \frac{(2A)^2}{2} + \cdots = e^{2A} $.

3. If A can be diagonalized then  $ (Xe^{\Lambda}X^{-1})(Xe^{\Lambda}X^{-1}) = Xe^{2\Lambda}X^{-1} $.

## Notes on a Differential Equations Course

Certainly constant-coefficient linear equations are the simplest to solve. This section 6.3 of the book shows you part of a differential equations course, but there is more:

1. The second order equation  $ mu'' + bu' + ku = 0 $ has major importance in applications. The exponents  $ \lambda $ in the solutions  $ u = e^{\lambda t} $ solve  $ m\lambda^2 + b\lambda + k = 0 $. The damping coefficient  $ b $ is crucial:

Underdamping  $ b^2 < 4mk $ Critical damping  $ b^2 = 4mk $ Overdamping  $ b^2 > 4mk $

This decides whether  $ \lambda_1 $ and  $ \lambda_2 $ are real roots or repeated roots or complex roots.

With complex  $ \lambda $'s the solution  $ u(t) $ oscillates as it decays.

2. Our equations had no forcing term  $ f(t) $. We were finding the “nullspace solution”. To  $ \boldsymbol{u}_{n}(t) $ we need to add a particular solution  $ u_{p}(t) $ that balances the force  $ f(t) $:

Input  $ f(s) $ at time s

Growth factor  $ e^{A(t-s)} $

Add up outputs at time t

 $$ \boldsymbol{u}_{\mathrm{p a r t i c u l a r}}=\int_{0}^{t}e^{A(t-s)}\;f(s)d s. $$ 

This solution can also be discovered and studied by Laplace transform—that is the established way to convert linear differential equations to linear algebra.

In real applications, nonlinear differential equations are solved numerically. A standard method with good accuracy is “Runge-Kutta”—named after its discoverers. Analysis can find the constant solutions to  $ du/dt = f(u) $. Those are solutions  $ u(t) = Y $ with  $ f(Y) = 0 $ and  $ du/dt = 0 $: no movement. We can also understand stability or instability near  $ u = Y $. Far from  $ Y $, the computer takes over.

This basic course is the subject of my textbook (companion to this one) on Differential Equations and Linear Algebra: math.mit.edu/dela.