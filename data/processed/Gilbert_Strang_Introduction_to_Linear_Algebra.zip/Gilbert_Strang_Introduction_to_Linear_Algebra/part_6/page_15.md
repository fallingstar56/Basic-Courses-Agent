Remark 3 The eigenvectors in X come in the same order as the eigenvalues in  $ \Lambda $. To reverse the order in  $ \Lambda $, put the eigenvector  $ (1,1) $ before  $ (1,0) $ in X:

New order 6, 1

 $$ \begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{-1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{5}}} \\{{{0}}}&{{{6}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{6}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}=\Lambda_{new} $$ 

To diagonalize $A$ we must use an eigenvector matrix. From $X^{-1}AX = \Lambda$ we know that $AX = X\Lambda$. Suppose the first column of $X$ is $\boldsymbol{x}$. Then the first columns of $AX$ and $X\Lambda$ are $Ax$ and $\lambda_1x$. For those to be equal, $x$ must be an eigenvector.

Remark 4 (repeated warning for repeated eigenvalues) Some matrices have too few eigenvectors. Those matrices cannot be diagonalized. Here are two examples:

Not diagonalizable

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{-1}}} \\{{{1}}}&{{{-1}}}\end{bmatrix}\quad\mathbf{a n d}\quad\boldsymbol{B}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Their eigenvalues happen to be 0 and 0. Nothing is special about  $ \lambda = 0 $, the problem is the repetition of  $ \lambda $. All eigenvectors of the first matrix are multiples of  $ (1, 1) $:

Only one line of eigenvectors

 $$ A\boldsymbol{x}=0\boldsymbol{x}\quad means\quad\begin{bmatrix}1&-1\\ 1&-1\end{bmatrix}\begin{bmatrix}\boldsymbol{x}\end{bmatrix}=\begin{bmatrix}0\\ 0\end{bmatrix}\quad and\quad\boldsymbol{x}=c\begin{bmatrix}1\\ 1\end{bmatrix}. $$ 

There is no second eigenvector, so this unusual matrix A cannot be diagonalized.

Those matrices are the best examples to test any statement about eigenvectors. In many true-false questions, non-diagonalizable matrices lead to false.

Remember that there is no connection between invertibility and diagonalizability:

- Invertibility is concerned with the eigenvalues ( $ \lambda = 0 $ or  $ \lambda \neq 0 $).

– Diagonalizability is concerned with the eigenvectors (too few or enough for X).

Each eigenvalue has at least one eigenvector!  $ A - \lambda I $ is singular. If  $ (A - \lambda I)x = 0 $ leads you to  $ x = 0 $,  $ \lambda $ is not an eigenvalue. Look for a mistake in solving  $ \det(A - \lambda I) = 0 $.

Eigenvectors for n different  $ \lambda $'s are independent. Then we can diagonalize A.

Independent x from different λ Eigenvectors  $ x_{1}, \ldots, x_{j} $ that correspond to distinct (all different) eigenvalues are linearly independent. An n by n matrix that has n different eigenvalues (no repeated λ's) must be diagonalizable.

Proof Suppose  $ c_1x_1 + c_2x_2 = 0 $. Multiply by  $ A $ to find  $ c_1\lambda_1x_1 + c_2\lambda_2x_2 = 0 $. Multiply by  $ \lambda_2 $ to find  $ c_1\lambda_2x_1 + c_2\lambda_2x_2 = 0 $. Now subtract one from the other:

Subtraction leaves

 $$ (\lambda_{1}-\lambda_{2})c_{1}\boldsymbol{x}_{1}=\mathbf{0}.\quad Therefore c_{1}=0. $$ 

Since the $\lambda$s are different and $x_1 \neq 0$, we are forced to the conclusion that $c_1 = 0$. Similarly $c_2 = 0$. Only the combination with $c_1 = c_2 = 0$ gives $c_1 x_1 + c_2 x_2 = 0$. So the eigenvectors $x_1$ and $x_2$ must be independent.