## Challenge Problems

The nth power of rotation through  $ \theta $ is rotation through  $ n\theta $:

 $$ \boldsymbol{A}^{n}=\left[\begin{array}{c c}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{array}\right]^{n}=\left[\begin{array}{c c}\cos n\theta&-\sin n\theta\\ \sin n\theta&\cos n\theta\end{array}\right]. $$ 

Prove that neat formula by diagonalizing  $ A = X \Lambda X^{-1} $. The eigenvectors (columns of  $ X $) are  $ (1, i) $ and  $ (i, 1) $. You need to know Euler's formula  $ e^{i\theta} = \cos\theta + i\sin\theta $.

The transpose of  $ A = X \Lambda X^{-1} $ is  $ A^{\mathrm{T}} = (X^{-1})^{\mathrm{T}} \Lambda X^{\mathrm{T}} $. The eigenvectors in  $ A^{\mathrm{T}} y = \lambda y $ are the columns of that matrix  $  (X^{-1})^{\mathrm{T}}  $. They are often called left eigenvectors of  $ A $, because  $ y^{\mathrm{T}} A = \lambda y^{\mathrm{T}} $. How do you multiply matrices to find this formula for  $ A $?

Sum of rank-1 matrices

 $$ \boldsymbol{A}=\boldsymbol{X}\boldsymbol{\Lambda}\boldsymbol{X}^{-1}=\lambda_{1}\boldsymbol{x}_{1}\boldsymbol{y}_{1}^{\mathrm{T}}+\cdots+\lambda_{n}\boldsymbol{x}_{n}\boldsymbol{y}_{n}^{\mathrm{T}}. $$ 

The inverse of $A = \mathrm{eye}(n) + \mathrm{ones}(n)$ is $A^{-1} = \mathrm{eye}(n) + C * \mathrm{ones}(n)$. Multiply $AA^{-1}$ to find that number $C$ (depending on $n$).

Suppose $A_{1}$ and $A_{2}$ are $n$ by $n$ invertible matrices. What matrix $B$ shows that $A_{2}A_{1}=B(A_{1}A_{2})B^{-1}$? Then $A_{2}A_{1}$ is similar to $A_{1}A_{2}$: same eigenvalues.

38 When is a matrix A similar to its eigenvalue matrix  $ \Lambda $ ?

A and  $ \Lambda $ always have the same eigenvalues. But similarity requires a matrix B with  $ A = B\Lambda B^{-1} $. Then B is the ___ matrix and A must have n independent ___.

39 (Pavel Grinfeld) Without writing down any calculations, can you find the eigenvalues of this matrix? Can you find the 2017th power  $ A^{2017} $?

 $$ \boldsymbol{A}=\left[\begin{array}{ccc}110&55&-164\\42&21&-62\\88&44&-131\\\end{array}\right]. $$ 

If A is m by n and B is n by m, then AB and BA have same nonzero eigenvalues.

Proof. Start with this identity between square matrices (easily checked). The first and third matrices are inverses. The “size matrix” shows the shapes of all blocks.

 $$ \left[\begin{array}{c c}{{{I}}}&{{{-A}}} \\{{{0}}}&{{{I}}}\end{array}\right]\left[\begin{array}{c c}{{{A B}}}&{{{0}}} \\{{{B}}}&{{{0}}}\end{array}\right]\left[\begin{array}{c c}{{{I}}}&{{{A}}} \\{{{0}}}&{{{I}}}\end{array}\right]=\left[\begin{array}{c c}{{{0}}}&{{{0}}} \\{{{B}}}&{{{B A}}}\end{array}\right]\quad\left[\begin{array}{c c}{{{m\times m}}}&{{{m\times n}}} \\{{{n\times m}}}&{{{n\times n}}}\end{array}\right] $$ 

This equation  $ D^{-1}ED = F $ says  $ F $ is similar to  $ E $—they have the same  $ m+n $ eigenvalues.

 $ E = \left[ \begin{array}{cc} AB & 0 \\ B & 0 \end{array} \right] $ has the m eigenvalues of AB, plus n zeros

 $ F = \left[ \begin{array}{cc} 0 & 0 \\ B & BA \end{array} \right] $ has the n eigenvalues of BA, plus m zeros

So AB and BA have the same eigenvalues except for  $ |n-m| $ zeros. Wow.

If  $ A = [1 \quad 1] $ and  $ B = A^{\mathrm{T}} $ then  $ A^{\mathrm{T}}A = \begin{bmatrix} 1 & 1 \\ 1 & 1 \end{bmatrix} $ (notice  $ \lambda = 2 $ and 0) and  $ AA^{\mathrm{T}} = [2] $.