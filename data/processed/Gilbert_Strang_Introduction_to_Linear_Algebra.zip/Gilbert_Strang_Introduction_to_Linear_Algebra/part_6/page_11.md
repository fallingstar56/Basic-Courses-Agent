28 Subtract I from the previous A. Find the  $ \lambda $'s and then the determinants of

 $$ \boldsymbol{B}=\boldsymbol{A}-\boldsymbol{I}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{1}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{C}=\boldsymbol{I}-\boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{-1}}}&{{{-1}}}&{{{-1}}} \\{{{-1}}}&{{{0}}}&{{{-1}}}&{{{-1}}} \\{{{-1}}}&{{{-1}}}&{{{0}}}&{{{-1}}} \\{{{-1}}}&{{{-1}}}&{{{-1}}}&{{{0}}}\end{bmatrix}. $$ 

29 (Review) Find the eigenvalues of A, B, and C:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{4}}}&{{{5}}} \\{{{0}}}&{{{0}}}&{{{6}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{2}}}&{{{0}}} \\{{{3}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{C}=\begin{bmatrix}{{{2}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{2}}}&{{{2}}}\end{bmatrix}. $$ 

30 When  $ a + b = c + d $ show that  $ (1, 1) $ is an eigenvector and find both eigenvalues:

 $$ \begin{align*}A=\begin{bmatrix}a&b\\ c&d\end{bmatrix}.\end{align*} $$ 

31 If we exchange rows 1 and 2 and columns 1 and 2, the eigenvalues don't change. Find eigenvectors of A and B for  $ \lambda = 11 $. Rank one gives  $ \lambda_{2} = \lambda_{3} = 0 $.

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{1}}} \\{{{3}}}&{{{6}}}&{{{3}}} \\{{{4}}}&{{{8}}}&{{{4}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\boldsymbol{P}\boldsymbol{A}\boldsymbol{P}^{\mathrm{T}}=\begin{bmatrix}{{{6}}}&{{{3}}}&{{{3}}} \\{{{2}}}&{{{1}}}&{{{1}}} \\{{{8}}}&{{{4}}}&{{{4}}}\end{bmatrix}. $$ 

32 Suppose A has eigenvalues 0, 3, 5 with independent eigenvectors u, v, w.

(a) Give a basis for the nullspace and a basis for the column space.

(b) Find a particular solution to  $ Ax = v + w $. Find all solutions.

(c) Ax = u has no solution. If it did then ___ would be in the column space.

## Challenge Problems

Show that $u$ is an eigenvector of the rank one $2 \times 2$ matrix $A = u v^{\mathrm{T}}$. Find both eigenvalues of $A$. Check that $\lambda_{1} + \lambda_{2}$ agrees with the trace $u_{1}v_{1} + u_{2}v_{2}$.

Find the eigenvalues of this permutation matrix P from  $ \det(P - \lambda I) = 0 $. Which vectors are not changed by the permutation? They are eigenvectors for  $ \lambda = 1 $. Can you find three more eigenvectors?

 $$ \boldsymbol{P}=\left[\begin{array}{cccc}{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{0}}}\end{array}\right]. $$ 