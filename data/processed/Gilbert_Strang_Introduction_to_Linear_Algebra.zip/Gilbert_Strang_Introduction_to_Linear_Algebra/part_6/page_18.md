Problem: Find the Fibonacci number  $ F_{100} $ The slow way is to apply the rule  $ F_{k+2} = F_{k+1} + F_k $ one step at a time. By adding  $ F_6 = 8 $ to  $ F_7 = 13 $ we reach  $ F_8 = 21 $. Eventually we come to  $ F_{100} $. Linear algebra gives a better way.

The key is to begin with a matrix equation  $ \mathbf{u}_{k+1} = \mathbf{A}\mathbf{u}_k $. That is a one-step rule for vectors, while Fibonacci gave a two-step rule for scalars. We match those rules by putting two Fibonacci numbers into a vector. Then you will see the matrix  $ A $.

 $$ \begin{aligned}&Let\boldsymbol{u}_{k}=\begin{bmatrix}{{{F_{k+1}}}} \\{{{F_{k}}}}\end{bmatrix}.The rule\begin{array}{c}{{{F_{k+2}=F_{k+1}+F_{k}}}} \\{{{F_{k+1}=F_{k+1}}}}\end{array}is\begin{aligned}\\ &u_{k+1}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}u_{k}.\\ &\end{aligned} $$ 

Every step multiplies by  $ A = \begin{bmatrix} 1 & 1 \\ 1 & 0 \end{bmatrix} $. After 100 steps we reach  $ u_{100} = A^{100} u_{0} $:

 $$ u_{0}=\begin{bmatrix}1\\ 0\end{bmatrix},\quad u_{1}=\begin{bmatrix}1\\ 1\end{bmatrix},\quad u_{2}=\begin{bmatrix}2\\ 1\end{bmatrix},\quad u_{3}=\begin{bmatrix}3\\ 2\end{bmatrix},\quad\ldots,\quad\boldsymbol{u}_{100}=\begin{bmatrix}F_{101}\\ F_{100}\end{bmatrix}. $$ 

This problem is just right for eigenvalues. Subtract  $ \lambda $ from the diagonal of A:

 $$ A-\lambda I=\begin{bmatrix}{{{1-\lambda}}}&{{{1}}} \\{{{1}}}&{{{-\lambda}}}\end{bmatrix}\quad leads to\quad\det(A-\lambda I)=\lambda^{2}-\lambda-1. $$ 

The equation  $ \lambda^2 - \lambda - 1 = 0 $ is solved by the quadratic formula  $ \left(-b \pm \sqrt{b^2 - 4ac}\right)/2a $:

Eigenvalues

 $$ \lambda_{1}=\frac{1+\sqrt{5}}{2}\approx1.618\qquad\mathrm{a n d}\qquad\lambda_{2}=\frac{1-\sqrt{5}}{2}\approx-.618. $$ 

These eigenvalues lead to eigenvectors  $ \boldsymbol{x}_{1} = (\lambda_{1}, 1) $ and  $ \boldsymbol{x}_{2} = (\lambda_{2}, 1) $. Step 2 finds the combination of those eigenvectors that gives  $ \boldsymbol{u}_{0} = (1, 0) $:

 $$ \begin{bmatrix}1\\ 0\end{bmatrix}=\frac{1}{\lambda_{1}-\lambda_{2}}\left(\begin{bmatrix}\lambda_{1}\\ 1\end{bmatrix}-\begin{bmatrix}\lambda_{2}\\ 1\end{bmatrix}\right)\qquad or\qquad u_{0}=\frac{x_{1}-x_{2}}{\lambda_{1}-\lambda_{2}}. $$ 

Step 3 multiplies  $ u_0 $ by  $ A^{100} $ to find  $ u_{100} $. The eigenvectors  $ x_1 $ and  $ x_2 $ stay separate! They are multiplied by  $ (\lambda_1)^{100} $ and  $ (\lambda_2)^{100} $:

 $$ u_{100}=\frac{(\lambda_{1})^{100}x_{1}-(\lambda_{2})^{100}x_{2}}{\lambda_{1}-\lambda_{2}}. $$ 

100 steps from  $ u_{0} $

We want  $ F_{100} = \text{second component of } \boldsymbol{u}_{100} $. The second components of  $ x_1 $ and  $ x_2 $ are 1. The difference between  $ \lambda_1 = (1 + \sqrt{5}) / 2 $ and  $ \lambda_2 = (1 - \sqrt{5}) / 2 $ is  $ \sqrt{5} $. And  $ \lambda_2^{100} \approx 0 $.

 $$ 100th Fibonacci number=\frac{\lambda_{1}^{100}-\lambda_{2}^{100}}{\lambda_{1}-\lambda_{2}}=nearest integer to\frac{1}{\sqrt{5}}\left(\frac{1+\sqrt{5}}{2}\right)^{100}. $$ 

Every  $ F_k $ is a whole number. The ratio  $ F_{101}/F_{100} $ must be very close to the limiting ratio  $ (1 + \sqrt{5})/2 $. The Greeks called this number the “golden mean”. For some reason a rectangle with sides 1.618 and 1 looks especially graceful.