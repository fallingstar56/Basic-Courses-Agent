## ■ REVIEW OF THE KEY IDEAS

1. The equation  $ u' = Au $ is linear with constant coefficients in A. Start from  $ u(0) $.

2. Its solution is usually a combination of exponentials, involving every  $ \lambda $ and  $ x $:

Independent eigenvectors

 $$ \boldsymbol{u}(t)=c_{1}e^{\lambda_{1}t}\boldsymbol{x}_{1}+\cdots+c_{n}e^{\lambda_{n}t}\boldsymbol{x}_{n}. $$ 

3. The constants  $ c_{1}, \ldots, c_{n} $ are determined by  $ \boldsymbol{u}(0) = c_{1} \boldsymbol{x}_{1} + \cdots + c_{n} \boldsymbol{x}_{n} = \boldsymbol{X} \boldsymbol{c} $.

4.  $  u(t)  $ approaches zero (stability) if every  $ \lambda $ has negative real part: All  $  e^{\lambda t} \to 0  $.

5. Solutions have the short form  $ \boldsymbol{u}(t) = e^{At}\boldsymbol{u}(0) $, with the matrix exponential  $ e^{At} $.

6. Equations with  $ y'' $ reduce to  $ u' = Au $ by combining y and  $ y' $ into the vector u.

## WORKED EXAMPLES

6.3 A Solve  $ y'' + 4y' + 3y = 0 $ by substituting  $ e^{\lambda t} $ and also by linear algebra.

Solution Substituting  $ y = e^{\lambda t} $ yields  $ (\lambda^2 + 4\lambda + 3)e^{\lambda t} = 0 $. That quadratic factors into  $ \lambda^2 + 4\lambda + 3 = (\lambda + 1)(\lambda + 3) = 0 $. Therefore  $ \lambda_1 = -1 $ and  $ \lambda_2 = -3 $. The pure solutions are  $ y_1 = e^{-t} $ and  $ y_2 = e^{-3t} $. The complete solution  $ y = c_1 y_1 + c_2 y_2 $ approaches zero.

To use linear algebra we set  $ \boldsymbol{u} = (y, y') $. Then the vector equation is  $ \boldsymbol{u}' = \boldsymbol{A}\boldsymbol{u} $:

 $$ \begin{array}{l}dy/dt=y^{\prime}\\ dy^{\prime}/dt=-3y-4y^{\prime}\end{array}\quad converts to\quad\frac{d\boldsymbol{u}}{dt}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{-3}}}&{{{-4}}}\end{bmatrix}\boldsymbol{u}. $$ 

This A is a “companion matrix” and its eigenvalues are again -1 and -3:

Same quadratic

 $$ \det(\boldsymbol{A}-\lambda\boldsymbol{I})=\left|\begin{matrix}{{{-\lambda}}}&{{{1}}} \\{{{-3}}}&{{{-4-\lambda}}}\end{matrix}\right|=\lambda^{2}+4\lambda+3=0. $$ 

The eigenvectors of $A$ are $(1, \lambda_1)$ and $(1, \lambda_2)$. Either way, the decay in $y(t)$ comes from $e^{-t}$ and $e^{-3t}$. With constant coefficients, calculus leads to linear algebra $A\boldsymbol{x} = \lambda\boldsymbol{x}$.

Note In linear algebra the serious danger is a shortage of eigenvectors. Our eigenvectors  $ (1, \lambda_1) $ and  $ (1, \lambda_2) $ are the same if  $ \lambda_1 = \lambda_2 $. Then we can't diagonalize  $ A $. In this case we don't yet have two independent solutions to  $ du/dt = Au $.

In differential equations the danger is also a repeated  $ \lambda $. After  $ y = e^{\lambda t} $, a second solution has to be found. It turns out to be  $ y = te^{\lambda t} $. This “impure” solution (with an extra  $ t $) appears in the matrix exponential  $ e^{A_t} $. Example 4 showed how.