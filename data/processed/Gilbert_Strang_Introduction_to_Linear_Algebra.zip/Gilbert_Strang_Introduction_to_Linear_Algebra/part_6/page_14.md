Why is  $ AX = X\Lambda $? A multiplies its eigenvectors, which are the columns of  $ X $. The first column of  $ AX $ is  $ Ax_1 $. That is  $ \lambda_1x_1 $. Each column of  $ X $ is multiplied by its eigenvalue:

A times X

 $$ \boldsymbol{A}\boldsymbol{X}=\boldsymbol{A}\left[\begin{array}{ccc}x_{1}&\cdots&x_{n}\end{array}\right]=\left[\begin{array}{ccc}\lambda_{1}x_{1}&\cdots&\lambda_{n}x_{n}\end{array}\right]. $$ 

The trick is to split this matrix AX into X times  $ \Lambda $:

X times  $ \Lambda $

 $$ \left[\begin{array}{c c c c}\lambda_{1}\boldsymbol{x}_{1}&\cdots&\lambda_{n}\boldsymbol{x}_{n}\\ &&\\ &&\end{array}\right]=\left[\begin{array}{c c c c}\boldsymbol{x}_{1}&\cdots&\boldsymbol{x}_{n}\\ &&\\ &&\end{array}\right]\left[\begin{array}{c c c c}\lambda_{1}&&&\\ &\ddots&&\\ &&\lambda_{n}\end{array}\right]=\boldsymbol{X}\boldsymbol{\Lambda}. $$ 

Keep those matrices in the right order! Then  $ \lambda_1 $ multiplies the first column  $ x_1 $, as shown. The diagonalization is complete, and we can write  $ AX = X\Lambda $ in two good ways:

 $$ \begin{array}{l}AX=X\Lambda\quad is\quad X^{-1}AX=\Lambda\quad or\quad A=X\Lambda X^{-1}.\end{array} $$ 

The matrix X has an inverse, because its columns (the eigenvectors of A) were assumed to be linearly independent. Without n independent eigenvectors, we can't diagonalize.

A and $\Lambda$ have the same eigenvalues $\lambda_1, \ldots, \lambda_n$. The eigenvectors are different. The job of the original eigenvectors $\boldsymbol{x}_1, \ldots, \boldsymbol{x}_n$ was to diagonalize $A$. Those eigenvectors in $X$ produce $A = X \Lambda X^{-1}$. You will soon see their simplicity and importance and meaning. The $k$th power will be $A^k = X \Lambda^k X^{-1}$ which is easy to compute:

 $$ A^{k}=(X\Lambda X^{-1})(X\Lambda X^{-1})\cdots(X\Lambda X^{-1})=X\Lambda^{k}X^{-1}. $$ 

Powers of A

Example 1

 $$ \begin{bmatrix}{{{1}}}&{{{5}}} \\{{{0}}}&{{{6}}}\end{bmatrix}^{k}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{6^{k}}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{-1}}} \\{{{0}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{6^{k}-1}}} \\{{{0}}}&{{{6^{k}}}}\end{bmatrix}=A^{k}. $$ 

With $k = 1$ we get $A$. With $k = 0$ we get $A^0 = I$ (and $\lambda^0 = 1$). With $k = -1$ we get $A^{-1}$. You can see how $A^2 = [1\ 35;\ 0\ 36]$ fits that formula when $k = 2$.

Here are four small remarks before we use  $ \Lambda $ again in Example 2.

Remark 1 Suppose the eigenvalues  $ \lambda_1, \ldots, \lambda_n $ are all different. Then it is automatic that the eigenvectors  $ x_1, \ldots, x_n $ are independent. The eigenvector matrix  $ X $ will be invertible. Any matrix that has no repeated eigenvalues can be diagonalized.

Remark 2 We can multiply eigenvectors by any nonzero constants.  $ A(cx) = \lambda(cx) $ is still true. In Example 1, we can divide  $ x = (1, 1) $ by  $ \sqrt{2} $ to produce a unit vector.

MATLAB and virtually all other codes produce eigenvectors of length  $ \|x\| = 1 $.