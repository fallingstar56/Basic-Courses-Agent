The false proof suggests what is true. Suppose  $ x $ really is an eigenvector for both  $ A $ and  $ B $. Then we do have  $ ABx = \lambda\beta x $ and  $ BAx = \lambda\beta x $. When all  $ n $ eigenvectors are shared, we can multiply eigenvalues. The test  $ AB = BA $ for shared eigenvectors is important in quantum mechanics—time out to mention this application of linear algebra:

A and B share the same n independent eigenvectors if and only if AB = BA

Heisenberg's uncertainty principle In quantum mechanics, the position matrix  $ P $ and the momentum matrix  $ Q $ do not commute. In fact  $ QP - PQ = I $ (these are infinite matrices). To have  $ Px = 0 $ at the same time as  $ Qx = 0 $ would require  $ x = Ix = 0 $. If we knew the position exactly, we could not also know the momentum exactly. Problem 36 derives Heisenberg's uncertainty principle  $ \|Px\| \|Qx\| \geq \frac{1}{2} \|x\|^2 $.

## ■ REVIEW OF THE KEY IDEAS

1.  $ Ax = \lambda x $ says that eigenvectors x keep the same direction when multiplied by A.

2.  $ Ax = \lambda x $ also says that  $ \det(A - \lambda I) = 0 $. This determines n eigenvalues.

3. The eigenvalues of  $ A^{2} $ and  $ A^{-1} $ are  $ \lambda^{2} $ and  $ \lambda^{-1} $, with the same eigenvectors.

4. The sum of the  $ \lambda $'s equals the sum down the main diagonal of A (the trace). The product of the  $ \lambda $'s equals the determinant of A.

5. Projections P, reflections R, 90° rotations Q have special eigenvalues 1, 0, −1, i, −i. Singular matrices have λ = 0. Triangular matrices have λ's on their diagonal.

6. Special properties of a matrix lead to special eigenvalues and eigenvectors. That is a major theme of this chapter (it is captured in a table at the very end).

## WORKED EXAMPLES

6.1 A Find the eigenvalues and eigenvectors of A and  $ A^{2} $ and  $ A^{-1} $ and  $ A + 4I $:

 $$ A=\begin{bmatrix}2&-1\\ -1&2\end{bmatrix}\quad and\quad A^{2}=\begin{bmatrix}5&-4\\ -4&5\end{bmatrix}. $$ 

Check the trace  $ \lambda_{1} + \lambda_{2} = 4 $ and the determinant  $ \lambda_{1}\lambda_{2} = 3 $.

Solution The eigenvalues of A come from  $ \det(A - \lambda I) = 0 $:

 $$ \boldsymbol{A}=\left[\begin{array}{r r}{2}&{-1}\\ {-1}&{2}\end{array}\right]\qquad\det(\boldsymbol{A}-\lambda\boldsymbol{I})=\left|\begin{array}{r r}{\mathbf{2}-\lambda}&{-\mathbf{1}}\\ {-\mathbf{1}}&{\mathbf{2}-\lambda}\end{array}\right|=\lambda^{2}-4\lambda+3=0. $$ 

This factors into $(\lambda - 1)(\lambda - 3) = 0$ so the eigenvalues of $A$ are $\lambda_1 = 1$ and $\lambda_2 = 3$. For the trace, the sum $2 + 2$ agrees with $1 + 3$. The determinant $3$ agrees with the product $\lambda_1 \lambda_2$.