Solution  $ u_{k+1} = \begin{bmatrix} 1 & 1 \\ 1 & 0 \end{bmatrix} u_k $ is the same as for Fibonacci, because  $ L_{k+2} = L_{k+1} + L_k $ is the same rule (with different starting values). The equation becomes a 2 by 2 system:

 $$ \begin{array}{r l}{\mathrm{L e t}}&{{}\boldsymbol{u}_{k}=\left[\begin{matrix}{L_{k+1}}\\ {L_{k}}\\ \end{matrix}\right].}&{{}\mathrm{T h e~r u l e}}&{{}\begin{array}{l l}{L_{k+2}=L_{k+1}+L_{k}}&{{}\mathrm{i s}}\\ {L_{k+1}=L_{k+1}}&{{}}\\ \end{array}}\\ \end{array}\quad\boldsymbol{u}_{k+1}=\left[\begin{matrix}{1}&{1}\\ {1}&{0}\\ \end{matrix}\right]\boldsymbol{u}_{k}. $$ 

The eigenvalues and eigenvectors of A = ⟨ 1 1 0 ⟩ still come from λ 2 = λ + 1:

 $$ \lambda_{1}=\frac{1+\sqrt{5}}{2}\quad and\quad x_{1}=\begin{bmatrix}\lambda_{1}\\ 1\end{bmatrix}\quad\lambda_{2}=\frac{1-\sqrt{5}}{2}\quad and\quad x_{2}=\begin{bmatrix}\lambda_{2}\\ 1\end{bmatrix}. $$ 

Now solve  $ c_1x_1 + c_2x_2 = u_1 = (3,1) $. The solution is  $ c_1 = \lambda_1 $ and  $ c_2 = \lambda_2 $. Check:

 $$ \lambda_{1}\boldsymbol{x}_{1}+\lambda_{2}\boldsymbol{x}_{2}=\left[\begin{array}{l}\lambda_{1}^{2}+\lambda_{2}^{2}\\ \lambda_{1}+\lambda_{2}\end{array}\right]=\left[\begin{array}{l}\operatorname{trace}of A^{2}\\ \operatorname{trace}of A\end{array}\right]=\left[\begin{array}{l}3\\ 1\end{array}\right]=\boldsymbol{u}_{1} $$ 

 $ u_{100} = A^{99}u_1 $ tells us the Lucas numbers  $ (L_{101}, L_{100}) $. The second components of the eigenvectors  $ x_1 $ and  $ x_2 $ are 1, so the second component of  $ u_{100} $ is the answer we want:

Lucas number

 $$ L_{100}=c_{1}\lambda_{1}^{99}+c_{2}\lambda_{2}^{99}=\lambda_{1}^{100}+\lambda_{2}^{100}. $$ 

Lucas starts faster than Fibonacci, and ends up larger by a factor near √5.

6.2 B Find the inverse and the eigenvalues and the determinant of this matrix A:

 $$ \boldsymbol{A}=5*\mathbf{e}\mathbf{y}\mathbf{e}(4)-\mathbf{o}\mathbf{n}\mathbf{e}\mathbf{s}(4)=\left[\begin{array}{c c c c}4&-1&-1&-1\\ -1&4&-1&-1\\ -1&-1&4&-1\\ -1&-1&-1&4\end{array}\right]. $$ 

Describe an eigenvector matrix X that gives  $ X^{-1}AX = \Lambda $.

Solution What are the eigenvalues of the all-ones matrix? Its rank is certainly 1, so three eigenvalues are  $ \lambda = 0, 0, 0 $. Its trace is 4, so the other eigenvalue is  $ \lambda = 4 $. Subtract this all-ones matrix from 5I to get our matrix A:

Subtract the eigenvalues 4, 0, 0, 0 from 5, 5, 5, 5. The eigenvalues of A are 1, 5, 5, 5.

The determinant of $A$ is 125, the product of those four eigenvalues. The eigenvector for $\lambda = 1$ is $\boldsymbol{x} = (1, 1, 1, 1)$ or $(c, c, c, c)$. The other eigenvectors are perpendicular to $x$ (since $A$ is symmetric). The nicest eigenvector matrix $X$ is the symmetric orthogonal Hadamard matrix $H$ The factor $\frac{1}{2}$ produces unit column vectors.

Orthonormal eigenvectors

 $$ \boldsymbol{X}=\boldsymbol{H}=\frac{1}{2}\left[\begin{array}{r r r r}{{{1}}}&{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{-1}}}&{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}&{{{-1}}}&{{{-1}}} \\{{{1}}}&{{{-1}}}&{{{-1}}}&{{{1}}}\end{array}\right]=\boldsymbol{H}^{\mathrm{T}}=\boldsymbol{H}^{-1}. $$ 