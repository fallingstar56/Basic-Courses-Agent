(Spectral Theorem) Every symmetric matrix has the factorization $S = Q\Lambda Q^{\mathrm{T}}$ with real eigenvalues in $\Lambda$ and orthonormal eigenvectors in the columns of $Q$:

Symmetric diagonalization

 $$ \boldsymbol{S}=\boldsymbol{Q}\boldsymbol{\Lambda}\boldsymbol{Q}^{-1}=\boldsymbol{Q}\boldsymbol{\Lambda}\boldsymbol{Q}^{\mathrm{T}}\quad\mathrm{w i t h}\quad\boldsymbol{Q}^{-1}=\boldsymbol{Q}^{\mathrm{T}}. $$ 

It is easy to see that  $ Q\Lambda Q^\mathrm{T} $ is symmetric. Take its transpose. You get  $ (Q^\mathrm{T})^\mathrm{T}\Lambda^\mathrm{T}Q^\mathrm{T} $, which is  $ Q\Lambda Q^\mathrm{T} $ again. The harder part is to prove that every symmetric matrix has real  $ \lambda $'s and orthonormal  $ \boldsymbol{x} $'s. This is the "spectral theorem" in mathematics and the "principal axis theorem" in geometry and physics. We have to prove it! No choice. I will approach the proof in three steps:

1. By an example, showing real  $ \lambda $'s in  $ \Lambda $ and orthonormal  $ \boldsymbol{x} $'s in Q.

2. By a proof of those facts when no eigenvalues are repeated.

3. By a proof that allows repeated eigenvalues (at the end of this section).

Example 1 Find the  $ \lambda $'s and  $ x $'s when  $ S = \begin{bmatrix} 1 & 2 \\ 2 & 4 \end{bmatrix} $ and  $ S - \lambda I = \begin{bmatrix} 1 - \lambda & 2 \\ 2 & 4 - \lambda \end{bmatrix} $.

Solution The determinant of  $ S - \lambda I $ is  $ \lambda^2 - 5\lambda $. The eigenvalues are 0 and 5 (both real). We can see them directly:  $ \lambda = 0 $ is an eigenvalue because  $ S $ is singular, and  $ \lambda = 5 $ matches the trace down the diagonal of  $ S: 0 + 5 $ agrees with  $ 1 + 4 $.

Two eigenvectors are  $ (2, -1) $ and  $ (1, 2) $—orthogonal but not yet orthonormal. The eigenvector for  $ \lambda = 0 $ is in the nullspace of  $ A $. The eigenvector for  $ \lambda = 5 $ is in the column space. We ask ourselves, why are the nullspace and column space perpendicular? The Fundamental Theorem says that the nullspace is perpendicular to the row space—not the column space. But our matrix is symmetric! Its row and column spaces are the same. Its eigenvectors  $ (2, -1) $ and  $ (1, 2) $ must be (and are) perpendicular.

These eigenvectors have length  $ \sqrt{5} $. Divide them by  $ \sqrt{5} $ to get unit vectors. Put those unit eigenvectors into the columns of  $ Q $. Then  $ Q^{-1}SQ $ is  $ \Lambda $ and  $ Q^{-1} = Q^{\mathrm{T}} $:

 $$ Q^{-1}SQ=\frac{1}{\sqrt{5}}\begin{bmatrix}{{{2}}}&{{{-1}}} \\{{{1}}}&{{{2}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{4}}}\end{bmatrix}\frac{1}{\sqrt{5}}\begin{bmatrix}{{{2}}}&{{{1}}} \\{{{-1}}}&{{{2}}}\end{bmatrix}=\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{0}}}&{{{5}}}\end{bmatrix}=\Lambda. $$ 

Now comes the n by n case. The λ's are real when S = S^T and Sx = λx.

Real Eigenvalues All the eigenvalues of a real symmetric matrix are real.

Proof Suppose that  $ Sx = \lambda x $. Until we know otherwise,  $ \lambda $ might be a complex number  $ a + ib $ (a and b real). Its complex conjugate is  $ \overline{\lambda} = a - ib $. Similarly the components of  $ x $ may be complex numbers, and switching the signs of their imaginary parts gives  $ \overline{x} $.