To see how  $ i = \sqrt{-1} $ can help, look at  $ Q^2 $ which is  $ -I $. If  $ Q $ is rotation through  $ 90^\circ $, then  $ Q^2 $ is rotation through  $ 180^\circ $. Its eigenvalues are  $ -1 $ and  $ -1 $. (Certainly  $ -I\boldsymbol{x} = -1\boldsymbol{x} $.) Squaring  $ Q $ will square each  $ \lambda $, so we must have  $ \lambda^2 = -1 $. The eigenvalues of the  $ 90^\circ $ rotation matrix  $ Q $ are  $ +i $ and  $ -i $, because  $ i^2 = -1 $.

Those  $ \lambda $'s come as usual from  $ \det(Q - \lambda I) = 0 $. This equation gives  $ \lambda^{2} + 1 = 0 $. Its roots are i and -i. We meet the imaginary number i also in the eigenvectors:

Complex

eigenvectors

 $$ \begin{bmatrix}0&-1\\ 1&0\end{bmatrix}\begin{bmatrix}1\\ i\end{bmatrix}=-i\begin{bmatrix}1\\ i\end{bmatrix}.\qquad and\qquad\begin{bmatrix}0&-1\\ 1&0\end{bmatrix}\begin{bmatrix}i\\ 1\end{bmatrix}=i\begin{bmatrix}i\\ 1\end{bmatrix}. $$ 

Somehow these complex vectors  $ \boldsymbol{x}_1 = (1, i) $ and  $ \boldsymbol{x}_2 = (i, 1) $ keep their direction as they are rotated. Don't ask me how. This example makes the all-important point that real matrices can easily have complex eigenvalues and eigenvectors. The particular eigenvalues  $ i $ and  $ -i $ also illustrate two special properties of  $ Q $:

1. Q is an orthogonal matrix so the absolute value of each λ is |λ| = 1.

2. Q is a skew-symmetric matrix so each  $ \lambda $ is pure imaginary.

A symmetric matrix  $ (S^{\mathrm{T}} = S) $ can be compared to a real number. A skew-symmetric matrix  $ (A^{\mathrm{T}} = -A) $ can be compared to an imaginary number. An orthogonal matrix  $ (Q^{\mathrm{T}}Q = I) $ corresponds to a complex number with  $ |\lambda| = 1 $. For the eigenvalues of S and A and Q, those are more than analogies—they are facts to be proved in Section 6.4.

The eigenvectors for all these special matrices are perpendicular. Somehow  $ (i,1) $ and  $ (1,i) $ are perpendicular (Chapter 9 explains the dot product of complex vectors).

Eigenvalues of AB and A+B

The first guess about the eigenvalues of AB is not true. An eigenvalue  $ \lambda $ of A times an eigenvalue  $ \beta $ of B usually does not give an eigenvalue of AB:

False proof

 $$ AB\boldsymbol{x}=A\boldsymbol{\beta}\boldsymbol{x}=\boldsymbol{\beta}A\boldsymbol{x}=\boldsymbol{\beta}\lambda\boldsymbol{x}. $$ 

It seems that  $ \beta $ times  $ \lambda $ is an eigenvalue. When x is an eigenvector for A and B, this proof is correct. The mistake is to expect that A and B automatically share the same eigenvector x. Usually they don't. Eigenvectors of A are not generally eigenvectors of B. A and B could have all zero eigenvalues while 1 is an eigenvalue of AB:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}\end{bmatrix};\quad then\quad\boldsymbol{A}\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad\boldsymbol{A}+\boldsymbol{B}=\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{1}}}&{{{0}}}\end{bmatrix}. $$ 

For the same reason, the eigenvalues of  $ A + B $ are generally not  $ \lambda + \beta $. Here  $ \lambda + \beta = 0 $ while  $ A + B $ has eigenvalues 1 and -1. (At least they add to zero.)