Matrix Powers  $ A^{k} $

Fibonacci's example is a typical difference equation  $ u_{k+1} = Au_k $. Each step multiplies by  $ A $. The solution is  $ u_k = A^k u_0 $. We want to make clear how diagonalizing the matrix gives a quick way to compute  $ A^k $ and find  $ u_k $ in three steps.

The eigenvector matrix  $ X $ produces  $ A = X \Lambda X^{-1} $. This is a factorization of the matrix, like  $ A = LU $ or  $ A = QR $. The new factorization is perfectly suited to computing powers, because every time  $ X^{-1} $ multiplies  $ X $ we get  $ I $:

Powers of A

 $$ A^{k}u_{0}=(X\Lambda X^{-1})\cdots(X\Lambda X^{-1})u_{0}=X\Lambda^{k}X^{-1}u_{0} $$ 

I will split  $ X\Lambda^k X^{-1}u_0 $ into three steps that show how eigenvalues work:

1. Write  $ u_0 $ as a combination  $ c_1x_1 + \cdots + c_nx_n $ of the eigenvectors. Then  $ c = X^{-1}u_0 $

2. Multiply each eigenvector  $ x_{i} $ by  $ (\lambda_{i})^{k} $. Now we have  $ \Lambda^{k}X^{-1}u_{0} $

3. Add up the pieces  $ c_{i}(\lambda_{i})^{k}x_{i} $ to find the solution  $ u_{k}=A^{k}u_{0} $. This is  $ X\Lambda^{k}X^{-1}u_{0} $.

 $$ \begin{array}{r l}{\mathrm{S o l u t i o n~f o r~}u_{k+1}=A u_{k}}&{{}u_{k}=A^{k}u_{0}=c_{1}(\lambda_{1})^{k}x_{1}+\cdots+c_{n}(\lambda_{n})^{k}x_{n}.}\end{array} $$ 

In matrix language  $ A^k $ equals  $ (X\Lambda X^{-1})^k $ which is  $ X $ times  $ \Lambda^k $ times  $ X^{-1} $. In Step 1, the eigenvectors in  $ X $ lead to the  $ c' $s in the combination  $ \boldsymbol{u}_0 = c_1 \boldsymbol{x}_1 + \cdots + c_n \boldsymbol{x}_n $:

Step 1

 $$ \begin{aligned}&u_{0}=\begin{bmatrix}\\ &x_{1}&\cdots&x_{n}\\ &\end{bmatrix}\begin{bmatrix}\\ &c_{1}\\ &\vdots\\ &c_{n}\\ &\end{bmatrix}.\quad This says that\quad u_{0}=X\mathbf{c}.\\ \end{aligned} $$ 

The coefficients in Step 1 are  $ c = X^{-1}u_0 $. Then Step 2 multiplies by  $ \Lambda^k $. The final result  $ \boldsymbol{u}_k = \sum c_i(\lambda_i)^k \boldsymbol{x}_i $ in Step 3 is the product of  $ X $ and  $ \Lambda^k $ and  $ X^{-1}u_0 $:

 $$ \boldsymbol{A}^{k}\boldsymbol{u}_{0}=\boldsymbol{X}\boldsymbol{\Lambda}^{k}\boldsymbol{X}^{-1}\boldsymbol{u}_{0}=\boldsymbol{X}\boldsymbol{\Lambda}^{k}\boldsymbol{c}=\left[\begin{array}{ccc}x_{1}&\cdots&x_{n}\end{array}\right]\left[\begin{array}{c}\left(\lambda_{1}\right)^{k}\\ \ddots\\ \left(\lambda_{n}\right)^{k}\end{array}\right]\left[\begin{array}{c}c_{1}\\ \vdots\\ c_{n}\end{array}\right]. $$ 

This result is exactly  $ \boldsymbol{u}_{k}=c_{1}(\lambda_{1})^{k}\boldsymbol{x}_{1}+\cdots+c_{n}(\lambda_{n})^{k}\boldsymbol{x}_{n} $. It solves  $ \boldsymbol{u}_{k+1}=A\boldsymbol{u}_{k} $.

Example 3 Start from  $ u_{0} = (1, 0) $. Compute  $ A^{k}u_{0} $ for this faster Fibonacci:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{1}}}&{{{0}}}\end{bmatrix}\quad has\quad\lambda_{1}=\mathbf{2}\quad and\quad\boldsymbol{x}_{1}=\begin{bmatrix}{{{2}}} \\{{{1}}}\end{bmatrix},\quad\lambda_{2}=-\mathbf{1}\quad and\quad\boldsymbol{x}_{2}=\begin{bmatrix}{{{1}}} \\{{{-1}}}\end{bmatrix}. $$ 

This matrix is like Fibonacci except the rule is changed to  $ F_{k+2} = F_{k+1} + 2F_k $. The new numbers start with 0, 1, 1, 3. They grow faster because of  $ \lambda = 2 $.