Figure 6.5 shows the parabola  $ T^2 = 4D $ separating real  $ \lambda $s from complex  $ \lambda $s. Solving  $ \lambda^2 - T\lambda + D = 0 $ involves the square root  $ \sqrt{T^2 - 4D} $. This is real below the parabola and imaginary above it. The stable region is the upper left quarter of the figure—where the trace  $ T $ is negative and the determinant  $ D $ is positive.

<div style="text-align: center;"><img src="imgs/img_in_image_box_232_256_855_519.jpg" alt="Image" width="58%" /></div>


<div style="text-align: center;">Figure 6.5: A 2 by 2 matrix is stable  $ (u(t) \to 0) $ when trace < 0 and det > 0.</div>


The Exponential of a Matrix

We want to write the solution  $ u(t) $ in a new form  $ e^{At}u(0) $. First we have to say what  $ e^{At} $ means, with a matrix in the exponent. To define  $ e^{At} $ for matrices, we copy  $ e^{x} $ for numbers.

The direct definition of  $ e^x $ is by the infinite series  $ 1 + x + \frac{1}{2}x^2 + \frac{1}{6}x^3 + \cdots $. When you change  $ x $ to a square matrix  $ A_t $, this series defines the matrix exponential  $ e^{A_t} $:

Matrix exponential  $ e^{At} $

 $$ \begin{aligned}&e^{At}=I+At+\frac{1}{2}(At)^{2}+\frac{1}{6}(At)^{3}+\cdots\\ &\\ &A+A^{2}t\mp\frac{1}{2}A^{3}t^{2}\mp\cdots=A e^{At}\\ \end{aligned} $$ 

Its t derivative is  $ Ae^{At} $

Its eigenvalues are

 $$ \begin{aligned}t\quad&(I+At+\frac{1}{2}(At)^{2}+\cdots)x=(1+\lambda t+\frac{1}{2}(\lambda t)^{2}+\cdots)x\end{aligned} $$ 

The number that divides $(At)^n$ is “$n$ factorial”. This is $n! = (1)(2)\cdots(n-1)(n)$. The factorials after $1,2,6$ are $4! = 24$ and $5! = 120$. They grow quickly. The series always converges and its derivative is always $Ae^{At}$. Therefore $e^{At}u(0)$ solves the differential equation with one quick formula—even if there is a shortage of eigenvectors.

I will use this series in Example 4, to see it work with a missing eigenvector. It will produce  $ te^{\lambda t} $. First let me reach  $ Xe^{\Lambda t}X^{-1} $ in the good (diagonalizable) case.