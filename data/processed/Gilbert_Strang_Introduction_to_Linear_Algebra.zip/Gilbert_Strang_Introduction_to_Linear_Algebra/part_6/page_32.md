## Example 3 Motion around a circle with  $ y'' + y = 0 $ and  $ y = \cos t $

This is our master equation with mass $m = 1$ and stiffness $k = 1$ and $d = 0$: no damping. Substitute $y = e^{\lambda t}$ into $y'' + y = 0$ to reach $\lambda^2 + 1 = 0$. The roots are $\lambda = i$ and $\lambda = -i$. Then half of $e^{it} + e^{-it}$ gives the solution $y = \cos t$.

As a first-order system, the initial values  $ y(0) = 1 $,  $ y'(0) = 0 $ go into  $ \boldsymbol{u}(0) = (1, 0) $:

 $$  Use y^{\prime \prime}=-y\qquad\quad\frac{d\boldsymbol{u}}{dt}=\frac{d}{dt}\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}=\begin{bmatrix}{{{\mathbf{0}}}}&{{{\mathbf{1}}}} \\{{{-1}}}&{{{\mathbf{0}}}}\end{bmatrix}\begin{bmatrix}{{{y}}} \\{{{y^{\prime}}}}\end{bmatrix}=A\boldsymbol{u}. $$ 

The eigenvalues of $A$ are again the same $\lambda = i$ and $\lambda = -i$ (no surprise). $A$ is anti-symmetric with eigenvectors $\boldsymbol{x}_1 = (1, i)$ and $\boldsymbol{x}_2 = (1, -i)$. The combination that matches $\boldsymbol{u}(0) = (1, 0)$ is $\frac{1}{2}(\boldsymbol{x}_1 + \boldsymbol{x}_2)$. Step 2 multiplies the $x$'s by $e^{it}$ and $e^{-it}$. Step 3 combines the pure oscillations into $\boldsymbol{u}(t)$ to find $y = \cos t$ as expected:

 $$ \boldsymbol{u}(t)=\frac{1}{2}e^{i t}\begin{bmatrix}1\\ i\end{bmatrix}+\frac{1}{2}e^{-i t}\begin{bmatrix}1\\ -i\end{bmatrix}=\begin{bmatrix}\cos t\\ -\sin t\end{bmatrix}.\qquad\mathrm{T h i s i s}\begin{bmatrix}y(t)\\ y^{\prime}(t)\end{bmatrix}. $$ 

All good. The vector  $ \boldsymbol{u} = (\cos t, -\sin t) $ goes around a circle (Figure 6.3). The radius is 1 because  $ \cos^2 t + \sin^2 t = 1 $.

Difference Equations (optional)

To display a circle on a screen, replace  $ y'' = -y $ by a difference equation. Here are three choices using  $ \mathbf{Y}(t + \Delta t) - 2\mathbf{Y}(t) + \mathbf{Y}(t - \Delta t) $. Divide by  $ (\Delta t)^2 $ to approximate  $ y'' $.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>F</td><td style='text-align: center; word-wrap: break-word;'>Forward from  $ n - 1 $</td><td rowspan="3">$ \frac{Y_{n+1} - 2Y_n + Y_{n-1}}{(\Delta t)^2} = -Y_n - \frac{(11\ \text{F})}{(11\ \text{C})}}{(11\ \text{B})} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>C</td><td style='text-align: center; word-wrap: break-word;'>Centered at time  $ n $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>B</td><td style='text-align: center; word-wrap: break-word;'>Backward from  $ n + 1 $</td></tr></table>

Figure 6.3 shows the exact  $ y(t) = \cos t $ completing a circle at  $ t = 2\pi $. The three difference methods don't complete a perfect circle in 32 time steps of length  $ \Delta t = 2\pi/32 $. Those pictures will be explained by eigenvalues:

Forward  $ \left|\lambda\right|>1 $ (spiral out) Centered  $ \left|\lambda\right|=1 $ (best) Backward  $ \left|\lambda\right|<1 $ (spiral in)

The 2-step equations (11) reduce to 1-step systems  $ U_{n+1} = AU_n $. Instead of  $ \boldsymbol{u} = (y, y') $ the discrete unknown is  $ U_n = (Y_n, Z_n) $. We take  $ n $ time steps  $ \Delta t $ starting from  $ U_0 $:

 $$ \begin{array}{r l}{\mathrm{F o r w a r d}}&{{}Y_{n+1}=Y_{n}+\Delta t\;Z_{n}\quad\mathrm{b e c o m e s}\quad U_{n+1}=\left[\begin{array}{c c}{1}&{\Delta t}\\ {-\Delta t}&{1}\end{array}\right]\left[\begin{array}{l}{Y_{n}}\\ {Z_{n}}\end{array}\right]=A U_{n}.}\end{array} $$ 

Those are like  $ Y' = Z $ and  $ Z' = -Y $. They are first order equations involving times n and  $ n + 1 $. Eliminating Z would bring back the “forward” second order equation (11 F).