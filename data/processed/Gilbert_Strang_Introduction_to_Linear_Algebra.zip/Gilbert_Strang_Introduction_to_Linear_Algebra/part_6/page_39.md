6.3 B Find the eigenvalues and eigenvectors of  $ A $. Then write  $ \boldsymbol{u}(0) = (0, 2\sqrt{2}, 0) $ as a combination of the eigenvectors. Solve both equations  $ u' = Au $ and  $ u'' = Au $:

 $$ \frac{d\boldsymbol{u}}{dt}=\begin{bmatrix}{{{-2}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{-2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{-2}}}\end{bmatrix}\boldsymbol{u}\qquad and\qquad\frac{d^{2}\boldsymbol{u}}{dt^{2}}=\begin{bmatrix}{{{-2}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{-2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{-2}}}\end{bmatrix}\boldsymbol{u}\quad with\frac{d\boldsymbol{u}}{dt}(0)=\mathbf{0}. $$ 

 $ u' = Au $ is like the heat equation  $ \partial u/\partial t = \partial^2 u/\partial x^2 $.

Its solution u(t) will decay (A has negative eigenvalues).

u'' = Au is like the wave equation  $ \partial^2 u/\partial t^2 = \partial^2 u/\partial x^2 $.

Its solution will oscillate (the square roots of λ are imaginary).

Solution The eigenvalues and eigenvectors come from  $ \det(A - \lambda I) = 0 $:

 $$ \det(\boldsymbol{A}-\lambda\boldsymbol{I})=\begin{vmatrix}{{{-2-\lambda}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{-2-\lambda}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{-2-\lambda}}}\end{vmatrix}=(-2-\lambda)[(-2-\lambda)^{2}-2]=0. $$ 

One eigenvalue is  $ \lambda = -2 $, when  $ -2 - \lambda $ is zero. The other factor is  $ \lambda^2 + 4\lambda + 2 $, so the other eigenvalues (also real and negative) are  $ \lambda = -2 \pm \sqrt{2} $. Find the eigenvectors:

 $$ \boldsymbol{\lambda}=-\mathbf{2}\quad\left(\boldsymbol{A}+2\boldsymbol{I}\right)\boldsymbol{x}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}} \\{{{0}}}\end{bmatrix}\quad for\boldsymbol{x}_{1}=\begin{bmatrix}{{{1}}} \\{{{0}}} \\{{{-1}}}\end{bmatrix} $$ 

 $$ \boldsymbol{\lambda}=-\boldsymbol{2}-\sqrt{2}\quad(\boldsymbol{A}-\lambda\boldsymbol{I})\boldsymbol{x}=\begin{bmatrix}{{{\sqrt{2}}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{\sqrt{2}}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{\sqrt{2}}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}} \\{{{0}}}\end{bmatrix}\quad for\boldsymbol{x}_{2}=\begin{bmatrix}{{{1}}} \\{{{-\sqrt{2}}}} \\{{{1}}}\end{bmatrix} $$ 

 $$ \boldsymbol{\lambda}=-\boldsymbol{2}+\sqrt{\boldsymbol{2}}\quad(\boldsymbol{A}-\lambda\boldsymbol{I})\boldsymbol{x}=\begin{bmatrix}{{{-\sqrt{2}}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{-\sqrt{2}}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{-\sqrt{2}}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}} \\{{{0}}}\end{bmatrix}\quad for\boldsymbol{x}_{3}=\begin{bmatrix}{{{1}}} \\{{{\sqrt{2}}}} \\{{{1}}}\end{bmatrix} $$ 

The eigenvectors are orthogonal (proved in Section 6.4 for all symmetric matrices). All three  $ \lambda_{i} $ are negative. This A is negative definite and  $ e^{At} $ decays to zero (stability).

The starting  $ u(0) = (0, 2\sqrt{2}, 0) $ is  $ x_3 - x_2 $. The solution is  $ u(t) = e^{\lambda_3 t} x_3 - e^{\lambda_2 t} x_2 $.

Heat equation In Figure 6.6a, the temperature at the center starts at  $ 2\sqrt{2} $. Heat diffuses into the neighboring boxes and then to the outside boxes (frozen at  $ 0^\circ $). The rate of heat flow between boxes is the temperature difference. From box 2, heat flows left and right at the rate  $ u_1 - u_2 $ and  $ u_3 - u_2 $. So the flow out is  $ u_1 - 2u_2 + u_3 $ in the second row of Au.

Wave equation  $ d^2u/dt^2 = Au $ has the same eigenvectors  $ x $. But now the eigenvalues  $ \lambda $ lead to oscillations  $ e^{i\omega t}x $ and  $ e^{-i\omega t}x $. The frequencies come from  $ \omega^2 = -\lambda $:

 $$ \frac{d^{2}}{d t^{2}}(e^{i\omega t}\boldsymbol{x})=A(e^{i\omega t}\boldsymbol{x})\qquad\mathrm{b e c o m e s}\qquad(i\omega)^{2}e^{i\omega t}\boldsymbol{x}=\lambda e^{i\omega t}\boldsymbol{x}\quad\mathrm{a n d}\quad\omega^{2}=-\lambda. $$ 

There are two square roots of  $ -\lambda $, so we have  $ e^{i\omega t}x $ and  $ e^{-i\omega t}x $. With three eigenvectors this makes six solutions to  $ u'' = Au $. A combination will match the six components of  $ u(0) $ and  $ u'(0) $. Since  $ u' = 0 $ in this problem,  $ e^{i\omega t}x $ and  $ e^{-i\omega t}x $ produce  $ 2\cos\omega t x $.