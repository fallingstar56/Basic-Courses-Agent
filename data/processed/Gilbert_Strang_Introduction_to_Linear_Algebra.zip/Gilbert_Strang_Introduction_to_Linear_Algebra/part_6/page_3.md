## Determinant and Trace

Bad news first: If you add a row of A to another row, or exchange rows, the eigenvalues usually change. Elimination does not preserve the  $ \lambda $'s. The triangular U has its eigenvalues sitting along the diagonal—they are the pivots. But they are not the eigenvalues of A! Eigenvalues are changed when row 1 is added to row 2:

 $$ U=\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\quad has\lambda=0and\lambda=1;\quad A=\begin{bmatrix}{{{1}}}&{{{3}}} \\{{{2}}}&{{{6}}}\end{bmatrix}\quad has\lambda=0and\lambda=7. $$ 

Good news second: The product  $ \lambda_1 $ times  $ \lambda_2 $ and the sum  $ \lambda_1 + \lambda_2 $ can be found quickly from the matrix. For this  $ A $, the product is 0 times 7. That agrees with the determinant (which is 0). The sum of eigenvalues is  $ 0 + 7 $. That agrees with the sum down the main diagonal (the trace is  $ 1 + 6 $). These quick checks always work:

The product of the n eigenvalues equals the determinant.

The sum of the n eigenvalues equals the sum of the n diagonal entries.

The sum of the entries along the main diagonal is called the trace of A:

 $$ \lambda_{1}+\lambda_{2}+\cdots+\lambda_{n}=trace=a_{11}+a_{22}+\cdots+a_{nn}. $$ 

Those checks are very useful. They are proved in Problems 16–17 and again in the next section. They don’t remove the pain of computing  $ \lambda $’s. But when the computation is wrong, they generally tell us so. To compute the correct  $ \lambda $’s, go back to  $ \det(A - \lambda I) = 0 $.

The trace and determinant do tell everything when the matrix is 2 by 2. We never want to get those wrong! Here trace = 3 and det = 2, so the eigenvalues are  $ \lambda = 1 $ and 2:

 $$ \boldsymbol{A}=\left[\begin{array}{ll}{{{1}}}&{{{9}}} \\{{{0}}}&{{{2}}}\end{array}\right]\text{or}\left[\begin{array}{cc}{{{3}}}&{{{1}}} \\{{{-2}}}&{{{0}}}\end{array}\right]\text{or}\left[\begin{array}{cc}{{{7}}}&{{{-3}}} \\{{{10}}}&{{{-4}}}\end{array}\right]. $$ 

And here is a question about the best matrices for finding eigenvalues: triangular.

Why do the eigenvalues of a triangular matrix lie along its diagonal?

Imaginary Eigenvalues

One more bit of news (not too terrible). The eigenvalues might not be real numbers.

Example 5 The 90° rotation  $ Q = \begin{bmatrix} 0 & -1 \\ 1 & 0 \end{bmatrix} $ has no real eigenvectors. Its eigenvalues are  $ \lambda_1 = i $ and  $ \lambda_2 = -i $. Then  $ \lambda_1 + \lambda_2 = \text{trace} = 0 $ and  $ \lambda_1 \lambda_2 = \text{determinant} = 1 $.

After a rotation, no real vector  $ Qx $ stays in the same direction as  $ x $ ( $ x = 0 $ is useless). There cannot be an eigenvector, unless we go to imaginary numbers. Which we do.