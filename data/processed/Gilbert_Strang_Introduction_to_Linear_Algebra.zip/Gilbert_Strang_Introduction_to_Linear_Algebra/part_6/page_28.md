### 6.3 Systems of Differential Equations

1 If $Ax = \lambda x$ then $u(t) = e^{\lambda t}x$ will solve $\frac{du}{dt} = Au$. Each $\lambda$ and $x$ give a solution $e^{\lambda t}x$.

2 If $A = X\Lambda X^{-1}$ then $\boxed{u(t) = e^{At}u(0) = Xe^{\Lambda t}X^{-1}u(0) = c_1e^{\lambda_1t}x_1 + \cdots + c_n e^{\lambda_n t}x_n}$.

3 $A$ is stable and $u(t) \to 0$ and $e^{At} \to 0$ when all eigenvalues of $A$ have real part < 0.

4 Matrix exponential $e^{At} = I + At + \cdots + (At)^n/n! + \cdots = Xe^{\Lambda t}X^{-1}$ if $A$ is diagonalizable.

5 Second order equation $u'' + Bu' + Cu = 0$ is equivalent to $\begin{bmatrix} u \\ u' \end{bmatrix}' = \begin{bmatrix} 0 & 1 \\ -C & -B \end{bmatrix} \begin{bmatrix} u \\ u' \end{bmatrix}$.

Eigenvalues and eigenvectors and  $ A = X \Lambda X^{-1} $ are perfect for matrix powers  $ A^k $. They are also perfect for differential equations  $ du/dt = Au $. This section is mostly linear algebra, but to read it you need one fact from calculus: The derivative of  $ e^{\lambda t} $ is  $ \lambda e^{\lambda t} $. The whole point of the section is this: To convert constant-coefficient differential equations into linear algebra.

The ordinary equations  $ \frac{du}{dt} = u $ and  $ \frac{du}{dt} = \lambda u $ are solved by exponentials:

 $$ \frac{du}{dt}=u\ produces\ u(t)=Ce^{t}\qquad\frac{du}{dt}=\lambda u\ produces\ u(t)=Ce^{\lambda t} $$ 

At time $t = 0$ those solutions include $e^0 = 1$. So they both reduce to $u(0) = C$. This “initial value” tells us the right choice for $C$. The solutions that start from the number $u(0)$ at time $t = 0$ are $u(t) = u(0)e^t$ and $u(t) = u(0)e^{\lambda t}$.

We just solved a 1 by 1 problem. Linear algebra moves to n by n. The unknown is a vector  $ \boldsymbol{u} $ (now boldface). It starts from the initial vector  $ \boldsymbol{u}(0) $, which is given. The n equations contain a square matrix A. We expect n exponents  $ e^{\lambda t} $ in  $ \boldsymbol{u}(t) $, from  $ n\lambda $'s:

System of $n$ equations $\frac{du}{dt}=Au$ starting from the vector $\boldsymbol{u}(0)=\begin{bmatrix}u_{1}(0)\\\cdots\\u_{n}(0)\end{bmatrix}$ at $t=0$.

These differential equations are linear. If  $ \boldsymbol{u}(t) $ and  $ \boldsymbol{v}(t) $ are solutions, so is  $ \boldsymbol{C}\boldsymbol{u}(t) + \boldsymbol{D}\boldsymbol{v}(t) $. We will need  $ n $ constants like  $ C $ and  $ D $ to match the  $ n $ components of  $ \boldsymbol{u}(0) $. Our first job is to find  $ n $ “pure exponential solutions”  $ \boldsymbol{u} = e^{\lambda t} \boldsymbol{x} $ by using  $ A\boldsymbol{x} = \lambda \boldsymbol{x} $.

Notice that A is a constant matrix. In other linear equations, A changes as t changes. In nonlinear equations, A changes as u changes. We don’t have those difficulties,  $ du/dt = Au $ is “linear with constant coefficients”. Those and only those are the differential equations that we will convert directly to linear algebra. Here is the key:

Solve linear constant coefficient equations by exponentials  $ e^{\lambda t}x $, when  $ Ax = \lambda x $.