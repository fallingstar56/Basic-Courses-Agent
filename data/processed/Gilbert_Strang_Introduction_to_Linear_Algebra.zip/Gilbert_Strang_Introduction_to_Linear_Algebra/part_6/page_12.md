There are six 3 by 3 permutation matrices P. What numbers can be the determinants of P? What numbers can be pivots? What numbers can be the trace of P? What four numbers can be eigenvalues of P, as in Problem 15?

(Heisenberg's Uncertainty Principle) AB - BA = I can happen for infinite matrices with  $ A = A^{\mathrm{T}} $ and  $ B = -B^{\mathrm{T}} $. Then

 $$ \boldsymbol{x}^{\mathrm{T}}\boldsymbol{x}=\boldsymbol{x}^{\mathrm{T}}A B\boldsymbol{x}-\boldsymbol{x}^{\mathrm{T}}B A\boldsymbol{x}\leq2\|A\boldsymbol{x}\|\|B\boldsymbol{x}\|. $$ 

Explain that last step by using the Schwarz inequality  $ |u^{\mathrm{T}}v| \leq ||u||||v|| $. Then Heisenberg's inequality says that  $ \|Ax\|/\|x\| $ times  $ \|Bx\|/\|x\| $ is at least  $ \frac{1}{2} $. It is impossible to get the position error and momentum error both very small.

Find a 2 by 2 rotation matrix (other than $I$) with $A^3 = I$. Its eigenvalues must satisfy $\lambda^3 = 1$. They can be $e^{2\pi i/3}$ and $e^{-2\pi i/3}$. What are the trace and determinant?

(a) Find the eigenvalues and eigenvectors of A. They depend on c:

 $$ A=\begin{bmatrix}0.4&1-c\\ 0.6&c\end{bmatrix}. $$ 

(b) Show that A has just one line of eigenvectors when c = 1.6.

(c) This is a Markov matrix when c = .8. Then  $ A^{n} $ will approach what matrix  $ A^{\infty} $?

Eigshow in MATLAB

There is a MATLAB demo (just type eigshow), displaying the eigenvalue problem for a 2 by 2 matrix. It starts with the unit vector  $ \boldsymbol{x} = (1, 0) $. The mouse makes this vector move around the unit circle. At the same time the screen shows Ax, in color and also moving. Possibly Ax is ahead of x. Possibly Ax is behind x. Sometimes Ax is parallel to x.

At that parallel moment,  $ Ax = \lambda x $ (at  $ x_1 $ and  $ x_2 $ in the second figure).

<div style="text-align: center;"><img src="imgs/img_in_image_box_212_854_466_1049.jpg" alt="Image" width="23%" /></div>


These are not eigenvectors

<div style="text-align: center;"><img src="imgs/img_in_image_box_495_854_811_1071.jpg" alt="Image" width="29%" /></div>


The eigenvalue  $ \lambda $ is the length of Ax, when the unit eigenvector x lines up. The built-in choices for A illustrate three possibilities: 0, 1, or 2 real vectors where Ax crosses x.

The axes of the ellipse are singular vectors in 7.4—and eigenvectors if A^{T} = A.