My question is simple. Do the points  $ (Y_n, Z_n) $ stay on the circle  $ Y^2 + Z^2 = 1 $? No, they are growing to infinity in Figure 6.3. We are taking powers  $ A^n $ and not  $ e^{At} $, so we test the magnitude  $ |\lambda| $ and not the real parts of the eigenvalues.

Eigenvalues of A

 $$ \lambda=1\pm i\Delta t $$ 

Then  $ |\lambda| > 1 $ and  $ (Y_{n}, Z_{n}) $ spirals out

<div style="text-align: center;"><img src="imgs/img_in_image_box_192_346_902_584.jpg" alt="Image" width="66%" /></div>


<div style="text-align: center;">Figure 6.3: Exact  $ u = (\cos t, -\sin t) $ on a circle. Forward Euler spirals out (32 steps).</div>


The backward choice in (11 B) will do the opposite in Figure 6.4. Notice the new A:

Backward

 $$ \begin{array}{l}Y_{n+1}=Y_{n}+\Delta t Z_{n+1}\\ Z_{n+1}=Z_{n}-\Delta t\mathbf{Y}_{\mathbf{n}+\mathbf{1}}\end{array}\text{is}\begin{bmatrix}1&-\Delta t\\ \Delta t&1\end{bmatrix}\begin{bmatrix}Y_{n+1}\\ Z_{n+1}\end{bmatrix}=\begin{bmatrix}Y_{n}\\ Z_{n}\end{bmatrix}=\boldsymbol{U}_{n}. $$ 

That matrix has eigenvalues  $ 1 \pm i\Delta t $. But we invert it to reach  $ U_{n+1} $ from  $ U_n $. Then  $ |\lambda| < 1 $ explains why the solution spirals in to  $ (0,0) $ for backward differences.

On the right side of Figure 6.4 you see 32 steps with the centered choice. The solution stays close to the circle (Problem 28) if  $ \Delta t < 2 $. This is the leapfrog method, constantly used. The second difference  $ Y_{n+1} - 2Y_n + Y_{n-1} $ “leaps over” the center value  $ Y_n $ in (11).

This is the way a chemist follows the motion of molecules (molecular dynamics leads to giant computations). Computational science is lively because one differential equation can be replaced by many difference equations—some unstable, some stable, some neutral. Problem 30 has a fourth (very good) method that stays right on the circle.

Real engineering and real physics deal with systems (not just a single mass at one point). The unknown y is a vector. The coefficient of  $ y'' $ is a mass matrix M, with n masses. The coefficient of y is a stiffness matrix K, not a number k. The coefficient of  $ y' $ is a damping matrix which might be zero.

The vector equation  $ My'' + Ky = f $ is a major part of computational mechanics. It is controlled by the eigenvalues of  $ M^{-1}K $ in  $ Kx = \lambda Mx $.