21 Find the complete solution in the form  $ x_{p} + x_{n} $ to these full rank systems:

(a)  $ x + y + z = 4 $ (b)



 $$ \begin{aligned}&x+y+z=4\\&x-y+z=4.\\ \end{aligned} $$ 

If  $ Ax = b $ has infinitely many solutions, why is it impossible for  $ Ax = B $ (new right side) to have only one solution? Could  $ Ax = B $ have no solution?

23 Choose the number q so that (if possible) the ranks are (a) 1, (b) 2, (c) 3:

 $$ A=\begin{bmatrix}{{{6}}}&{{{4}}}&{{{2}}} \\{{{-3}}}&{{{-2}}}&{{{-1}}} \\{{{9}}}&{{{6}}}&{{{q}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{3}}}&{{{1}}}&{{{3}}} \\{{{q}}}&{{{2}}}&{{{q}}}\end{bmatrix}. $$ 

24 Give examples of matrices A for which the number of solutions to Ax = b is

(a) 0 or 1, depending on b

(b)  $ \infty $, regardless of b

(c) 0 or  $ \infty $, depending on b

(d) 1, regardless of b.

25 Write down all known relations between r and m and n if Ax = b has

(a) no solution for some b

(b) infinitely many solutions for every b

(c) exactly one solution for some b, no solution for other b

(d) exactly one solution for every b.

Questions 26–33 are about Gauss-Jordan elimination (upwards as well as downwards) and the reduced echelon matrix R.

26 Continue elimination from U to R. Divide rows by pivots so the new pivots are all 1. Then produce zeros above those pivots to reach R:

 $$ U=\begin{bmatrix}{{{2}}}&{{{4}}}&{{{4}}} \\{{{0}}}&{{{3}}}&{{{6}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad U=\begin{bmatrix}{{{2}}}&{{{4}}}&{{{4}}} \\{{{0}}}&{{{3}}}&{{{6}}} \\{{{0}}}&{{{0}}}&{{{5}}}\end{bmatrix}. $$ 

If $A$ is a triangular matrix, when is $R = \text{rref}(A)$ equal to $I$?

Apply Gauss-Jordan elimination to  $ Ux = 0 $ and  $ Ux = c $. Reach  $ Rx = 0 $ and  $ Rx = d $:

 $$ \begin{bmatrix}\boldsymbol{U}&\mathbf{0}\end{bmatrix}=\begin{bmatrix}1&2&3&\mathbf{0}\\ 0&0&4&\mathbf{0}\end{bmatrix}\quad and\quad\begin{bmatrix}\boldsymbol{U}&\boldsymbol{c}\end{bmatrix}=\begin{bmatrix}1&2&3&\mathbf{5}\\ 0&0&4&\mathbf{8}\end{bmatrix}. $$ 

Solve  $ Rx = 0 $ to find  $ x_n $ (its free variable is  $ x_2 = 1 $). Solve  $ Rx = d $ to find  $ x_p $ (its free variable is  $ x_2 = 0 $).