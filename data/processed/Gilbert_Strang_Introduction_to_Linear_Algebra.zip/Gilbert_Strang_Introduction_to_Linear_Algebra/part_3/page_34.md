### Problem Set 3.4

Questions 1–10 are about linear independence and linear dependence.

1 Show that  $ v_{1}, v_{2}, v_{3} $ are independent but  $ v_{1}, v_{2}, v_{3}, v_{4} $ are dependent:

 $$ \boldsymbol{v}_{1}=\begin{bmatrix}1\\ 0\\ 0\end{bmatrix}\quad\boldsymbol{v}_{2}=\begin{bmatrix}1\\ 1\\ 0\end{bmatrix}\quad\boldsymbol{v}_{3}=\begin{bmatrix}1\\ 1\\ 1\end{bmatrix}\quad\boldsymbol{v}_{4}=\begin{bmatrix}2\\ 3\\ 4\end{bmatrix}. $$ 

Solve  $ c_1v_1 + c_2v_2 + c_3v_3 + c_4v_4 = 0 $ or  $ Ax = 0 $. The  $ v' $s go in the columns of  $ A $.

2 (Recommended) Find the largest possible number of independent vectors among

 $$ \boldsymbol{v}_{1}=\begin{bmatrix}1\\ -1\\ 0\\ 0\end{bmatrix}\quad\boldsymbol{v}_{2}=\begin{bmatrix}1\\ 0\\ -1\\ 0\end{bmatrix}\quad\boldsymbol{v}_{3}=\begin{bmatrix}1\\ 0\\ 0\\ -1\end{bmatrix}\quad\boldsymbol{v}_{4}=\begin{bmatrix}0\\ 1\\ -1\\ 0\end{bmatrix}\quad\boldsymbol{v}_{5}=\begin{bmatrix}0\\ 1\\ 0\\ -1\end{bmatrix}\quad\boldsymbol{v}_{6}=\begin{bmatrix}0\\ 0\\ 1\\ -1\end{bmatrix} $$ 

3 Prove that if a = 0 or d = 0 or f = 0 (3 cases), the columns of U are dependent:

 $$ U=\begin{bmatrix}{{{a}}}&{{{b}}}&{{{c}}} \\{{{0}}}&{{{d}}}&{{{e}}} \\{{{0}}}&{{{0}}}&{{{f}}}\end{bmatrix}. $$ 

4 If $a,d,f$ in Question 3 are all nonzero, show that the only solution to $Ux=0$ is $x=0$. Then the upper triangular $U$ has independent columns.

5 Decide the dependence or independence of

(a) the vectors  $ (1,3,2) $ and  $ (2,1,3) $ and  $ (3,2,1) $

(b) the vectors  $ (1,-3,2) $ and  $ (2,1,-3) $ and  $ (-3,2,1) $.

6 Choose three independent columns of U. Then make two other choices. Do the same for A.

 $$ U=\begin{bmatrix}{{{2}}}&{{{3}}}&{{{4}}}&{{{1}}} \\{{{0}}}&{{{6}}}&{{{7}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{9}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{2}}}&{{{3}}}&{{{4}}}&{{{1}}} \\{{{0}}}&{{{6}}}&{{{7}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{9}}} \\{{{4}}}&{{{6}}}&{{{8}}}&{{{2}}}\end{bmatrix}. $$ 

7 If  $ w_{1}, w_{2}, w_{3} $ are independent vectors, show that the differences  $ v_{1} = w_{2} - w_{3} $ and  $ v_{2} = w_{1} - w_{3} $ and  $ v_{3} = w_{1} - w_{2} $ are dependent. Find a combination of the  $ v $'s that gives zero. Which matrix A in  $ [v_{1} \quad v_{2} \quad v_{3}] = [w_{1} \quad w_{2} \quad w_{3}] $ A is singular?

8 If  $ w_1, w_2, w_3 $ are independent vectors, show that the sums  $ v_1 = w_2 + w_3 $ and  $ v_2 = w_1 + w_3 $ and  $ v_3 = w_1 + w_2 $ are independent. (Write  $ c_1 v_1 + c_2 v_2 + c_3 v_3 = 0 $ in terms of the  $ w' $s. Find and solve equations for the  $ c' $s, to show they are zero.)