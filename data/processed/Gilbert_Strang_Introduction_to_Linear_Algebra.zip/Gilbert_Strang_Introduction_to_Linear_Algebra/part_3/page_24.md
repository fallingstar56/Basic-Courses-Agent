The columns are independent when the nullspace  $ \mathbf{N}(A) $ contains only the zero vector. Let me illustrate linear independence (and dependence) with three vectors in  $ \mathbf{R}^{3} $:

1. If three vectors are not in the same plane, they are independent. No combination of  $ v_{1}, v_{2}, v_{3} $ in Figure 3.4 gives zero except  $ 0v_{1} + 0v_{2} + 0v_{3} $.

2. If three vectors  $ w_{1}, w_{2}, w_{3} $ are in the same plane, they are dependent.

<div style="text-align: center;"><img src="imgs/img_in_image_box_249_303_451_450.jpg" alt="Image" width="18%" /></div>


In a plane

<div style="text-align: center;"><img src="imgs/img_in_image_box_560_376_780_461.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;">Figure 3.4: Independent vectors  $ v_1 $,  $ v_2 $,  $ v_3 $. Only  $ 0v_1 + 0v_2 + 0v_3 $ gives the vector 0. Dependent vectors  $ w_1 $,  $ w_2 $,  $ w_3 $. The combination  $ w_1 - w_2 + w_3 $ is  $ (0, 0, 0) $.</div>


This idea of independence applies to 7 vectors in 12-dimensional space. If they are the columns of A, and independent, the nullspace only contains x = 0. None of the vectors is a combination of the other six vectors.

Now we choose different words to express the same idea. The following definition of independence will apply to any sequence of vectors in any vector space. When the vectors are the columns of A, the two definitions say exactly the same thing.

DEFINITION The sequence of vectors  $ v_1, \ldots, v_n $ is linearly independent if the only combination that gives the zero vector is  $ 0v_1 + 0v_2 + \cdots + 0v_n $.

Linear independence

 $ x_{1}v_{1}+x_{2}v_{2}+\cdots+x_{n}v_{n}=0 $ only happens when all  $ x^{\prime} $s are zero.

If a combination gives 0, when the x's are not all zero, the vectors are dependent.

Correct language: “The sequence of vectors is linearly independent.” Acceptable shortcut: “The vectors are independent.” Unacceptable: “The matrix is independent.”

A sequence of vectors is either dependent or independent. They can be combined to give the zero vector (with nonzero x's) or they can't. So the key question is: Which combinations of the vectors give zero? We begin with some small examples in  $ \mathbf{R}^{2} $:

(a) The vectors  $ (1,0) $ and  $ (0,1) $ are independent.

(b) The vectors  $ (1,0) $ and  $ (1,0.00001) $ are independent.

(c) The vectors  $ (1,1) $ and  $ (-1,-1) $ are dependent.

(d) The vectors  $ (1, 1) $ and  $ (0, 0) $ are dependent because of the zero vector.

(e) In  $ R^{2} $, any three vectors  $ (a,b) $ and  $ (c,d) $ and  $ (e,f) $ are dependent.