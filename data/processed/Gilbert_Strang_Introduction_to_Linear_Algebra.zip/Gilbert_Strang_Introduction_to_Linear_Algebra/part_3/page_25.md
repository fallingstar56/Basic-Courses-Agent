Geometrically,  $ (1,1) $ and  $ (-1,-1) $ are on a line through the origin. They are dependent. To use the definition, find numbers  $ x_1 $ and  $ x_2 $ so that  $ x_1(1,1) + x_2(-1,-1) = (0,0) $. This is the same as solving Ax = 0:

 $$ \begin{bmatrix}1&-1\\ 1&-1\end{bmatrix}\begin{bmatrix}x_{1}\\ x_{2}\end{bmatrix}=\begin{bmatrix}0\\ 0\end{bmatrix}\quad for x_{1}=1and x_{2}=1. $$ 

The columns are dependent exactly when there is a nonzero vector in the nullspace.

If one of the v's is the zero vector, independence has no chance. Why not?

Three vectors in  $ R^2 $ cannot be independent! One way to see this: the matrix  $ A $ with those three columns must have a free variable and then a special solution to  $ Ax = 0 $. Another way: If the first two vectors are independent, some combination will produce the third vector. See the second highlight below.

Now move to three vectors in  $ \mathbf{R}^3 $. If one of them is a multiple of another one, these vectors are dependent. But the complete test involves all three vectors at once. We put them in a matrix and try to solve  $ Ax = 0 $.

Example 1 The columns of this A are dependent. Ax = 0 has a nonzero solution:

 $$ \boldsymbol{A}\boldsymbol{x}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{3}}} \\{{{2}}}&{{{1}}}&{{{5}}} \\{{{1}}}&{{{0}}}&{{{3}}}\end{bmatrix}\begin{bmatrix}{{{-3}}} \\{{{1}}} \\{{{1}}}\end{bmatrix}\quad is\quad-3\begin{bmatrix}{{{1}}} \\{{{2}}} \\{{{1}}}\end{bmatrix}+1\begin{bmatrix}{{{0}}} \\{{{1}}} \\{{{0}}}\end{bmatrix}+1\begin{bmatrix}{{{3}}} \\{{{5}}} \\{{{3}}}\end{bmatrix}=\begin{bmatrix}{{{0}}} \\{{{0}}} \\{{{0}}}\end{bmatrix}. $$ 

The rank is only r = 2. Independent columns produce full column rank r = n = 3.

In that matrix the rows are also dependent. Row 1 minus row 3 is the zero row. For a square matrix, we will show that dependent columns imply dependent rows.

Question How to find that solution to Ax = 0? The systematic way is elimination.

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{3}}} \\{{{2}}}&{{{1}}}&{{{5}}} \\{{{1}}}&{{{0}}}&{{{3}}}\end{bmatrix}\text{reduces to}\boldsymbol{R}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{3}}} \\{{{0}}}&{{{1}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

The solution  $ \boldsymbol{x}=(-3,1,1) $ was exactly the special solution. It shows how the free column (column 3) is a combination of the pivot columns. That kills independence!

Full column rank The columns of A are independent exactly when the rank is r = n. There are n pivots and no free variables. Only x = 0 is in the nullspace.

One case is of special importance because it is clear from the start. Suppose seven columns have five components each (m = 5 is less than n = 7). Then the columns must be dependent. Any seven vectors from  $ \mathbf{R}^5 $ are dependent. The rank of A cannot be larger than 5. There cannot be more than five pivots in five rows.  $ Ax = 0 $ has at least 7 - 5 = 2 free variables, so it has nonzero solutions—which means that the columns are dependent.