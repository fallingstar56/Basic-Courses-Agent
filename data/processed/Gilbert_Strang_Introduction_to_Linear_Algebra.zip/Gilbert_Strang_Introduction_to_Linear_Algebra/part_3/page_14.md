We are ready for the definition of linear independence, as soon as we summarize the four possibilities—which depend on the rank. Notice how r, m, n are the critical numbers.

The four possibilities for linear equations depend on the rank r

 $$ \begin{array}{l l l l l}{r=m}&{{a n d}}&{r=n}&{{S q u a r e~a n d~i n v e r t i b l e}}&{A x=b{~h a s~1~s o l u t i o n}}\\ {r=m}&{{a n d}}&{r<n}&{{S h o r t~a n d~w i d e}}&{A x=b{~h a s~\infty~s o l u t i o n s}}\\ {r<m}&{{a n d}}&{r=n}&{{T a l l~a n d~t h i n}}&{A x=b{~h a s~0~o r~1~s o l u t i o n}}\\ {r<m}&{{a n d}}&{r<n}&{{N o t~f u l l~r a n k}}&{A x=b{~h a s~0~o r~\infty~s o l u t i o n s}}\\ \end{array} $$ 

The reduced $R$ will fall in the same category as the matrix $A$. In case the pivot columns happen to come first, we can display these four possibilities for $R$. For $R\boldsymbol{x}=d$ (and the original $A\boldsymbol{x}=b$) to be solvable, $d$ must end in $m-r$ zeros. $F$ is the free part of $R$.

Four types for R

 $$ \begin{bmatrix}{{{I}}} \\{{{\quad}}}&{{{\quad}}}&{{{\quad}}}&{{{\quad}}} \\{{{I}}}&{{{F}}} \\\end{bmatrix}\quad\begin{bmatrix}{{{I}}} \\{{{0}}} \\\end{bmatrix}\quad\begin{bmatrix}{{{I}}}&{{{F}}} \\{{{0}}}&{{{0}}} \\\end{bmatrix} $$ 

Their ranks

 $$ r=m=n\quad r=m<n\quad r=n<m\quad r<m,r<n $$ 

Cases 1 and 2 have full row rank r = m. Cases 1 and 3 have full column rank r = n. Case 4 is the most general in theory and it is the least common in practice.

## ■ REVIEW OF THE KEY IDEAS

1. The rank r is the number of pivots. The matrix R has m - r zero rows.

2. Ax = b is solvable if and only if the last m - r equations reduce to 0 = 0.

3. One particular solution  $ x_{p} $ has all free variables equal to zero.

4. The pivot variables are determined after the free variables are chosen.

5. Full column rank r = n means no free variables: one solution or none.

6. Full row rank r = m means one solution if m = n or infinitely many if m < n.

## WORKED EXAMPLES

3.3 A This question connects elimination (pivot columns and back substitution) to column space-nullspace-rank-solvability (the higher level picture). A has rank 2:

 $$ \begin{array}{r l}{x_{1}+2x_{2}+3x_{3}+5x_{4}=b_{1}}&{}\\ {A\boldsymbol{x}=\boldsymbol{b}\quad\mathrm{i s}\quad}&{2x_{1}+4x_{2}+8x_{3}+12x_{4}=b_{2}}\\ {}&{3x_{1}+6x_{2}+7x_{3}+13x_{4}=b_{3}}\end{array} $$ 