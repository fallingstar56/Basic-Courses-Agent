## Questions 5–14 are about free variables and pivot variables

5 True or false (with reason if true or example to show it is false):

(a) A square matrix has no free variables.

(b) An invertible matrix has no free variables.

(c) An m by n matrix has no more than n pivot variables.

(d) An m by n matrix has no more than m pivot variables.

6 Put as many 1's as possible in a 4 by 7 echelon matrix U whose pivot columns are (a) 2, 4, 5 (b) 1, 3, 6, 7 (c) 4 and 6.

7 Put as many 1's as possible in a 4 by 8 reduced echelon matrix R so that the free columns are

(a) 2 4 5 6 (b) 1 3 6 7 8

(b) 1, 3, 6, 7, 8.

8 Suppose column 4 of a 3 by 5 matrix is all zero. Then  $ x_{4} $ is certainly a  $ \underline{\hspace{2cm}} $ variable. The special solution for this variable is the vector  $ \boldsymbol{x} = \underline{\hspace{2cm}} $.

9 Suppose the first and last columns of a 3 by 5 matrix are the same (not zero). Then ___ is a free variable. Find the special solution for this variable.

10 Suppose an m by n matrix has r pivots. The number of special solutions is ___.

The nullspace contains only x = 0 when r = ___. The column space is all of  $ \mathbb{R}^m $ when r = ___.

11 The nullspace of a 5 by 5 matrix contains only x = 0 when the matrix has ___ pivots. The column space is  $ \mathbb{R}^5 $ when there are ___ pivots. Explain why.

12 The equation  $ x - 3y - z = 0 $ determines a plane in  $ R^3 $. What is the matrix  $ A $ in this equation? Which variables are free? The special solutions are ___ and ___.

13 (Recommended) The plane  $ x - 3y - z = 12 $ is parallel to x - 3y - z = 0. One particular point on this plane is  $ (12, 0, 0) $. All points on the plane have the form

 $$ \begin{bmatrix}x\\ y\\ z\end{bmatrix}=\begin{bmatrix}0\\ 0\end{bmatrix}+y\begin{bmatrix}1\\ 0\end{bmatrix}+z\begin{bmatrix}0\\ 1\end{bmatrix}. $$ 

14 Suppose column 1 + column 3 + column 5 = 0 in a 4 by 5 matrix with four pivots. Which column has no pivot? What is the special solution? Describe  $ N(A) $.

Questions 15–22 ask for matrices (if possible) with specific properties.

15 Construct a matrix for which N(A) = all combinations of (2, 2, 1, 0) and (3, 1, 0, 1).

16 Construct A so that N(A) = all multiples of (4, 3, 2, 1). Its rank is ___.