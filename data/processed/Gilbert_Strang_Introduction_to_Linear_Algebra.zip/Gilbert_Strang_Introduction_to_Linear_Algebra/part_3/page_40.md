### 3.5 Dimensions of the Four Subspaces

1 The column space C(A) and the row space C(A^T) both have dimension r (the rank of A).

2 The nullspace  $ \mathbf{N}(A) $ has dimension n - r. The left nullspace  $ \mathbf{N}(A^{\mathrm{T}}) $ has dimension m - r.

3 Elimination produces bases for the row space and nullspace of A: They are the same as for R.

4 Elimination often changes the column space and left nullspace (but dimensions don't change).

5 Rank one matrices: A = uv^T = column times row: C(A) has basis u, C(A^T) has basis v.

The main theorem in this chapter connects rank and dimension. The rank of a matrix is the number of pivots. The dimension of a subspace is the number of vectors in a basis. We count pivots or we count basis vectors. The rank of A reveals the dimensions of all four fundamental subspaces. Here are the subspaces, including the new one.

Two subspaces come directly from A, and the other two from  $ A^{T} $

Four Fundamental Subspaces

1. The row space is $C(A^{\mathrm{T}})$, a subspace of $R^{n}$.

2. The column space is C(A), a subspace of R^{m}.

3. The nullspace is N(A), a subspace of R^{n}.

4. The left nullspace is  $ \mathbf{N}(A^{\mathrm{T}}) $, a subspace of  $ \mathbf{R}^{m} $. This is our new space.

In this book the column space and nullspace came first. We know  $ C(A) $ and  $ N(A) $ pretty well. Now the other two subspaces come forward. The row space contains all combinations of the rows. This row space of  $ A $ is the column space of  $ A^\top $.

For the left nullspace we solve  $ A^{\mathrm{T}}y = 0 $—that system is n by m. This is the nullspace of  $ A^{\mathrm{T}} $. The vectors y go on the left side of A when the equation is written  $ y^{\mathrm{T}}A = 0^{\mathrm{T}} $. The matrices A and  $ A^{\mathrm{T}} $ are usually different. So are their column spaces and their nullspaces. But those spaces are connected in an absolutely beautiful way.

Part 1 of the Fundamental Theorem finds the dimensions of the four subspaces. One fact stands out: The row space and column space have the same dimension  $ \tau $. This number  $ \tau $ is the rank of the matrix. The other important fact involves the two nullspaces:

 $ N(A) $ and  $ N(A^{\mathrm{T}}) $ have dimensions n - r and m - r, to make up the full n and m.

Part 2 of the Fundamental Theorem will describe how the four subspaces fit together (two in  $ \mathbf{R}^n $ and two in  $ \mathbf{R}^m $). That completes the “right way” to understand every  $ A\boldsymbol{x} = \boldsymbol{b} $. Stay with it—you are doing real mathematics.