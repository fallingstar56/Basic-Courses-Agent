4 Find the complete solution (also called the general solution) to

 $$ \begin{bmatrix}{{{1}}}&{{{3}}}&{{{1}}}&{{{2}}} \\{{{2}}}&{{{6}}}&{{{4}}}&{{{8}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{4}}}\end{bmatrix}\begin{bmatrix}{{{x}}} \\{{{y}}} \\{{{z}}} \\{{{t}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{3}}} \\{{{1}}}\end{bmatrix}. $$ 

5 Under what condition on  $ b_{1}, b_{2}, b_{3} $ is this system solvable? Include b as a fourth column in elimination. Find all solutions when that condition holds:

 $$ x+2y-2z=b_{1} $$ 

 $$ 2x+5y-4z=b_{2} $$ 

 $$ 4x+9y-8z=b_{3}. $$ 

6 What conditions on  $ b_{1}, b_{2}, b_{3}, b_{4} $ make each system solvable? Find x in that case:

 $$ \begin{bmatrix} {1}&{2} \\ {2}&{4} \\ {2}&{5} \\ {3}&{9} \end{bmatrix} \begin{bmatrix} {x_{1}} \\ {x_{2}} \end{bmatrix}=\begin{bmatrix} b_{1} \\ b_{2} \\ b_{3} \\ b_{4}\\ \end{bmatrix} \quad \begin{bmatrix} {1}&{2}&{3} \\ {2}&{4}&{6} \\ {2}&{5}&{7} \\ {3}&{9}&{12} \end{bmatrix} \begin{bmatrix} x_{1} \\ x_{2} \\ x_{3} \end{bmatrix}=\begin{bmatrix} b_{1} \\ b_{2} \\ b_{3} \\ b_{4}\\ \end{bmatrix}. $$ 

7 Show by elimination that  $ (b_{1}, b_{2}, b_{3}) $ is in the column space if  $ b_{3} - 2b_{2} + 4b_{1} = 0 $.

 $$ A=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{1}}} \\{{{3}}}&{{{8}}}&{{{2}}} \\{{{2}}}&{{{4}}}&{{{0}}}\end{bmatrix}. $$ 

What combination of the rows of A gives the zero row?

8 Which vectors  $ (b_{1}, b_{2}, b_{3}) $ are in the column space of  $ A $? Which combinations of the rows of  $ A $ give zero?

(a)

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{1}}} \\{{{2}}}&{{{6}}}&{{{3}}} \\{{{0}}}&{{{2}}}&{{{5}}}\end{bmatrix} $$ 

(b)

 $$ A=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{4}}} \\{{{2}}}&{{{4}}}&{{{8}}}\end{bmatrix}. $$ 

(a) The Worked Example 3.3 A reached [U c] from [A b]. Put the multipliers into L and verify that LU equals A and Lc equals b.

(b) Combine the pivot columns of A with the numbers -9 and 3 in the particular solution  $ x_{p} $. What is that linear combination and why?

Construct a 2 by 3 system  $ Ax = b $ with particular solution  $ x_p = (2, 4, 0) $ and homogeneous solution  $ x_n = \text{any multiple of } (1, 1, 1) $.

Why can't a 1 by 3 system have  $ x_{p} = (2, 4, 0) $ and  $ x_{n} = \text{any multiple of } (1, 1, 1) $?