The basis vectors  $ i = \begin{bmatrix} 1 \\ 0 \end{bmatrix} $ and  $ j = \begin{bmatrix} 0 \\ 1 \end{bmatrix} $ are independent. They span  $ R^2 $

Everybody thinks of this basis first. The vector $i$ goes across and $j$ goes straight up. The columns of the 3 by 3 identity matrix are the standard basis $i, j, k$. The columns of the $n$ by $n$ identity matrix give the “standard basis” for $\mathbf{R}^n$.

Now we find many other bases (infinitely many). The basis is not unique!

Example 7 (Important) The columns of every invertible n by n matrix give a basis for  $ \mathbf{R}^n $:

Invertible matrix

Independent columns

Column space is  $ R^{3} $

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{1}}}\end{bmatrix} $$ 

Singular matrix

Dependent columns

Column space  $ \neq R^{3} $

 $$ \boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}} \\{{{1}}}&{{{1}}}&{{{2}}}\end{bmatrix}. $$ 

The only solution to  $ Ax = 0 $ is  $ x = A^{-1}0 = 0 $. The columns are independent. They span the whole space  $ \mathbf{R}^n $—because every vector  $ \mathbf{b} $ is a combination of the columns.  $ Ax = b $ can always be solved by  $ x = A^{-1}b $. Do you see how everything comes together for invertible matrices? Here it is in one sentence:

The vectors  $ v_1, \ldots, v_n $ are a basis for  $ R^n $ exactly when they are the columns of an  $ n $ by  $ n $ invertible matrix. Thus  $ R^n $ has infinitely many different bases.

When the columns are dependent, we keep only the pivot columns—the first two columns of B above, with its two pivots. They are independent and they span the column space.

The pivot columns of A are a basis for its column space. The pivot rows of A are a basis for its row space. So are the pivot rows of its echelon form R.

Example 8 This matrix is not invertible. Its columns are not a basis for anything!

One pivot column

One pivot row  $ (r = 1) $

 $$ A=\begin{bmatrix}{{{2}}}&{{{4}}} \\{{{3}}}&{{{6}}}\end{bmatrix}reduces to R=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Column 1 of A is the pivot column. That column alone is a basis for its column space. The second column of A would be a different basis. So would any nonzero multiple of that column. There is no shortage of bases. One definite choice is the pivot columns.

Notice that the pivot column  $ (1,0) $ of this R ends in zero. That column is a basis for the column space of R, but it doesn't belong to the column space of A. The column spaces of A and R are different. Their bases are different. (Their dimensions are the same.)

The row space of A is the same as the row space of R. It contains  $ (2, 4) $ and  $ (1, 2) $ and all other multiples of those vectors. As always, there are infinitely many bases to choose from. One natural choice is to pick the nonzero rows of R (rows with a pivot). So this