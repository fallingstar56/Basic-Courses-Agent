Right reason: The same combinations of the columns are zero (or nonzero) for A and R.

Dependent in  $ A \Leftrightarrow $ dependent in R. Say that another way:  $ Ax = 0 $ exactly when  $ Rx = 0 $.

The column spaces are different, but their dimensions are the same—equal to r.

Conclusion The r pivot columns of A are a basis for its column space  $ C(A) $.

3 A has the same nullspace as R. Same dimension n - r and same basis.

Reason: The elimination steps don’t change the solutions. The special solutions are a basis for this nullspace (as we always knew). There are $n-r$ free variables, so the dimension of the nullspace is $n-r$. This is the Counting Theorem: $r+(n-r)$ equals $n$.

(dimension of column space) + (dimension of nullspace) = dimension of R^n.

4 The left nullspace of A (the nullspace of A^{T}) has dimension m - r.

Reason:  $ A^{\mathrm{T}} $ is just as good a matrix as A. When we know the dimensions for every A, we also know them for  $ A^{\mathrm{T}} $. Its column space was proved to have dimension r. Since  $ A^{\mathrm{T}} $ is n by m, the “whole space” is now  $ R^{m} $. The counting rule for A was  $ r + (n - r) = n $. The counting rule for  $ A^{\mathrm{T}} $ is  $ r + (m - r) = m $. We now have all details of a big theorem:

Fundamental Theorem of Linear Algebra, Part 1

The column space and row space both have dimension r.

The nullspaces have dimensions n - r and m - r.

By concentrating on spaces of vectors, not on individual numbers or vectors, we get these clean rules. You will soon take them for granted—eventually they begin to look obvious. But if you write down an 11 by 17 matrix with 187 nonzero entries, I don’t think most people would see why these facts are true:

Two key facts

 $$ \begin{array}{l}\text{dimension of}\boldsymbol{C}(\boldsymbol{A})=\text{dimension of}\boldsymbol{C}(\boldsymbol{A}^{\mathrm{T}})=\text{rank of}\boldsymbol{A}\\ \text{dimension of}\boldsymbol{C}(\boldsymbol{A})+\text{dimension of}\boldsymbol{N}(\boldsymbol{A})=17.\end{array} $$ 

Example 1

 $ A = \begin{bmatrix} 1 & 2 & 3 \end{bmatrix} $ has  $ m = 1 $ and  $ n = 3 $ and rank r = 1.

The row space is a line in  $ \mathbf{R}^3 $. The nullspace is the plane  $ A\boldsymbol{x} = x_1 + 2x_2 + 3x_3 = 0 $. This plane has dimension 2 (which is 3 - 1). The dimensions add to  $ \mathbf{1} + \mathbf{2} = \mathbf{3} $.

The columns of this 1 by 3 matrix are in  $ \mathbf{R}^1! $. The column space is all of  $ \mathbf{R}^1 $. The left nullspace contains only the zero vector. The only solution to  $ A^\mathrm{T} \mathbf{y} = \mathbf{0} $ is  $ \mathbf{y} = \mathbf{0} $, no other multiple of  $ [1\ 2\ 3] $ gives the zero row. Thus  $ N(A^\mathrm{T}) $ is  $ \mathbf{Z} $, the zero space with dimension 0 (which is  $ m - r $). In  $ \mathbf{R}^m $ the dimensions of  $ \mathbf{C}(A) $ and  $ N(A^\mathrm{T}) $ add to  $ 1 + \mathbf{0} = \mathbf{1} $.