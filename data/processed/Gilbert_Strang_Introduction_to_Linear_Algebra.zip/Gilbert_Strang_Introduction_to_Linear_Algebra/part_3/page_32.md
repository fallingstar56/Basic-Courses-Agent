We end here with the space Z that contains only the zero vector. The dimension of this space is zero. The empty set (containing no vectors) is a basis for Z. We can never allow the zero vector into a basis, because then linear independence is lost.

## ■ REVIEW OF THE KEY IDEAS

1. The columns of A are independent if x = 0 is the only solution to Ax = 0.

2. The vectors  $ v_{1}, \ldots, v_{r} $ span a space if their combinations fill that space.

3. A basis consists of linearly independent vectors that span the space. Every vector in the space is a unique combination of the basis vectors.

4. All bases for a space have the same number of vectors. This number of vectors in a basis is the dimension of the space.

5. The pivot columns are one basis for the column space. The dimension is r.

## WORKED EXAMPLES

3.4 A Start with the vectors  $ v_1 = (1, 2, 0) $ and  $ v_2 = (2, 3, 0) $. (a) Are they linearly independent? (b) Are they a basis for any space? (c) What space V do they span? (d) What is the dimension of V? (e) Which matrices A have V as their column space? (f) Which matrices have V as their nullspace? (g) Describe all vectors  $ v_3 $ that complete a basis  $ v_1, v_2, v_3 $ for  $ R^3 $.

## Solution

(a)  $ v_{1} $ and  $ v_{2} $ are independent—the only combination to give 0 is  $ 0v_{1} + 0v_{2} $.

(b) Yes, they are a basis for the space they span.

(c) That space V contains all vectors  $ (x, y, 0) $. It is the xy plane in  $ R^{3} $.

(d) The dimension of V is 2 since the basis contains two vectors.

(e) This V is the column space of any 3 by n matrix A of rank 2, if every column is a combination of  $ v_1 $ and  $ v_2 $. In particular A could just have columns  $ v_1 $ and  $ v_2 $.

(f) This V is the nullspace of any m by 3 matrix B of rank 1, if every row is a multiple of  $ (0,0,1) $. In particular take  $ B = [0\ 0\ 1] $. Then  $ B\boldsymbol{v}_{1} = \mathbf{0} $ and  $ B\boldsymbol{v}_{2} = \mathbf{0} $.

(g) Any third vector  $ \boldsymbol{v}_3 = (a, b, c) $ will complete a basis for  $ \mathbf{R}^3 $ provided  $ c \neq 0 $.