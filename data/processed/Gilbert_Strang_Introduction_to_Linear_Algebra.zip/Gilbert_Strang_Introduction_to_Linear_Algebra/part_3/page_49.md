3.5 B Fact: All the rows of AB are combinations of the rows of B. So the row space of AB is contained in (possibly equal to) the row space of B.  $ \text{Rank}(AB) < \text{rank}(B) $.

All columns of AB are combinations of the columns of A. So the column space of AB is contained in (possibly equal to) the column space of A.  $ \text{Rank}(AB) \leq \text{rank}(A) $.

If we multiply by an invertible matrix, the rank will not change. The rank can't drop, because when we multiply by the inverse matrix the rank can't jump back.

### Problem Set 3.5

(a) If a 7 by 9 matrix has rank 5, what are the dimensions of the four subspaces? What is the sum of all four dimensions?

(b) If a 3 by 4 matrix has rank 3, what are its column space and left nullspace?

2 Find bases and dimensions for the four subspaces associated with A and B:

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{4}}} \\{{{2}}}&{{{4}}}&{{{8}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{4}}} \\{{{2}}}&{{{5}}}&{{{8}}}\end{bmatrix}. $$ 

3 Find a basis for each of the four subspaces associated with A:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}} \\{{{0}}}&{{{1}}}&{{{2}}}&{{{4}}}&{{{6}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{2}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

4 Construct a matrix with the required property or explain why this is impossible:

(a) Column space contains  $ \left[\begin{array}{c}1 \\ 1 \\ 0\end{array}\right] $,  $ \left[\begin{array}{c}0 \\ 0 \\ 1\end{array}\right] $, row space contains  $ \left[\begin{array}{c}1 \\ 2\end{array}\right] $,  $ \left[\begin{array}{c}2 \\ 5\end{array}\right] $.

(b) Column space has basis  $ \begin{bmatrix} 1 \\ 1 \\ 3 \end{bmatrix} $, nullspace has basis  $ \begin{bmatrix} 3 \\ 1 \\ 1 \end{bmatrix} $.

(c) Dimension of nullspace = 1 + dimension of left nullspace.

(d) Nullspace contains  $ \left[\begin{array}{c}1\\ 3\end{array}\right] $, column space contains  $ \left[\begin{array}{c}3\\ 1\end{array}\right] $.

(e) Row space = column space, nullspace  $ \neq $ left nullspace.

5 If V is the subspace spanned by (11,1) and (21,0), find a matrix A that has V as its row space. Find a matrix B that has V as its nullspace. Multiply AB.

6 Without using elimination, find dimensions and bases for the four subspaces for

 $$ \boldsymbol{A}=\begin{bmatrix}{{{0}}}&{{{3}}}&{{{3}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad\boldsymbol{B}=\begin{bmatrix}{{{1}}} \\{{{4}}} \\{{{5}}}\end{bmatrix}. $$ 

7 Suppose the 3 by 3 matrix A is invertible. Write down bases for the four subspaces for A, and also for the 3 by 6 matrix  $ B = [A \quad A] $. (The basis for Z is empty.)