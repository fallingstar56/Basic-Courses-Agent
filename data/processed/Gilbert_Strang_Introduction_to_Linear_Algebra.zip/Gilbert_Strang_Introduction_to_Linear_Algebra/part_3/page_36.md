17 Find three different bases for the column space of  $ U = \begin{bmatrix} 1 & 0 & 1 & 0 & 1 \\ 0 & 1 & 0 & 1 & 0 \end{bmatrix} $. Then find two different bases for the row space of  $ U $.

18 Suppose  $ v_{1}, v_{2}, \ldots, v_{6} $ are six vectors in  $ R^{4} $

(a) Those vectors (do)(do not)(might not) span  $ \mathbf{R}^{4} $

(b) Those vectors (are)(are not)(might be) linearly independent.

(c) Any four of those vectors (are)(are not)(might be) a basis for  $ \mathbf{R}^{4} $

9 The columns of A are n vectors from  $ \mathbf{R}^m $. If they are linearly independent, what is the rank of A? If they span  $ \mathbf{R}^m $, what is the rank? If they are a basis for  $ \mathbf{R}^m $, what then? Looking ahead: The rank r counts the number of ___ columns.

Find a basis for the plane  $ x - 2y + 3z = 0 $ in  $ \mathbf{R}^3 $. Then find a basis for the intersection of that plane with the xy plane. Then find a basis for all vectors perpendicular to the plane.

21 Suppose the columns of a 5 by 5 matrix A are a basis for  $ \mathbf{R}^5 $.

(a) The equation Ax = 0 has only the solution x = 0 because ___.

(b) If $b$ is in $\mathbf{R}^5$ then $Ax = b$ is solvable because the basis vectors $\mathbf{R}^5$

Conclusion: A is invertible. Its rank is 5. Its rows are also a basis for  $ R^{5} $.

22 Suppose S is a 5-dimensional subspace of  $ \mathbb{R}^6 $. True or false (example if false):

(a) Every basis for S can be extended to a basis for  $ R^6 $ by adding one more vector.

(b) Every basis for  $ R^{6} $ can be reduced to a basis for S by removing one vector.

U comes from A by subtracting row 1 from row 3:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{2}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{1}}}&{{{3}}}&{{{2}}}\end{bmatrix}\quad and\quad\boldsymbol{U}=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{2}}} \\{{{0}}}&{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Find bases for the two column spaces. Find bases for the two row spaces. Find bases for the two nullspaces. Which spaces stay fixed in elimination?

24 True or false (give a good reason):

(a) If the columns of a matrix are dependent, so are the rows.

(b) The column space of a 2 by 2 matrix is the same as its row space.

(c) The column space of a 2 by 2 matrix has the same dimension as its row space.

(d) The columns of a matrix are a basis for the column space.