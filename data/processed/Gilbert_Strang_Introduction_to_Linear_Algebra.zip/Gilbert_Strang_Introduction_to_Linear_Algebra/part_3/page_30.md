 $ a_{11}v_{1}+\cdots+a_{m1}v_{m} $, this is the first column of a matrix multiplication  $ V A $:

Each w is a combination of the v's

 $$ W=\left[w_{1}w_{2}\ldots w_{n}\right]=\left[v_{1}\ldots v_{m}\right]\begin{bmatrix}a_{11}&a_{1n}\\ \vdots&\vdots\\ a_{m1}&a_{mn}\end{bmatrix}=VA. $$ 

We don’t know each  $ a_{ij} $, but we know the shape of  $ A $ (it is  $ m $ by  $ n $). The second vector  $ w_2 $ is also a combination of the  $ v $'s. The coefficients in that combination fill the second column of  $ A $. The key is that  $ A $ has a row for every  $ v $ and a column for every  $ w $.  $ A $ is a short wide matrix, since we assumed  $ n > m $. So  $ Ax = 0 $ has a nonzero solution.

 $ Ax = 0 $ gives  $ VAx = 0 $ which is  $ Wx = 0 $. A combination of the  $ w $'s gives zero! Then the  $ w $'s could not be a basis—our assumption  $ n > m $ is not possible for two bases.

If m > n we exchange the v's and w's and repeat the same steps. The only way to avoid a contradiction is to have m = n. This completes the proof that m = n.

The number of basis vectors depends on the space—not on a particular basis. The number is the same for every basis, and it counts the “degrees of freedom” in the space. The dimension of the space  $ \mathbf{R}^n $ is  $ n $. We now introduce the important word dimension for other vector spaces too.

DEFINITION The dimension of a space is the number of vectors in every basis.

This matches our intuition. The line through  $ v = (1, 5, 2) $ has dimension one. It is a subspace with this one vector v in its basis. Perpendicular to that line is the plane  $ x + 5y + 2z = 0 $. This plane has dimension 2. To prove it, we find a basis  $ (-5, 1, 0) $ and  $ (-2, 0, 1) $. The dimension is 2 because the basis contains two vectors.

The plane is the nullspace of the matrix  $ A = \begin{bmatrix} 1 & 5 & 2 \end{bmatrix} $, which has two free variables. Our basis vectors  $ (-5, 1, 0) $ and  $ (-2, 0, 1) $ are the “special solutions” to  $ Ax = 0 $. The next section shows that the  $ n - r $ special solutions always give a basis for the nullspace.  $ C(A) $ has dimension  $ r $ and the nullspace  $ \mathbf{N}(A) $ has dimension  $ n - r $.

Note about the language of linear algebra We never say “the rank of a space” or “the dimension of a basis” or “the basis of a matrix”. Those terms have no meaning. It is the dimension of the column space that equals the rank of the matrix.

## Bases for Matrix Spaces and Function Spaces

The words “independence” and “basis” and “dimension” are not at all restricted to column vectors. We can ask whether three matrices  $ A_{1}, A_{2}, A_{3} $ are independent. When they are in the space of all 3 by 4 matrices, some combination might give the zero matrix. We can also ask the dimension of the full 3 by 4 matrix space. (It is 12.)

In differential equations,  $ d^2y/dx^2 = y $ has a space of solutions. One basis is  $ y = e^x $ and  $ y = e^{-x} $. Counting the basis functions gives the dimension 2 for the space of all solutions. (The dimension is 2 because of the second derivative.)