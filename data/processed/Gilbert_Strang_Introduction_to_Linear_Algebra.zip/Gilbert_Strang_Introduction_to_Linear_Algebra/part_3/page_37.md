25 For which numbers c and d do these matrices have rank 2?

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{5}}}&{{{0}}}&{{{5}}} \\{{{0}}}&{{{0}}}&{{{c}}}&{{{2}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{d}}}&{{{2}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{c}}}&{{{d}}} \\{{{d}}}&{{{c}}}\end{bmatrix}. $$ 

Questions 26–30 are about spaces where the “vectors” are matrices.

26 Find a basis (and the dimension) for each of these subspaces of 3 by 3 matrices:

(a) All diagonal matrices.

(b) All symmetric matrices (AT = A).

(c) All skew-symmetric matrices (A^{T} = -A).

27 Construct six linearly independent 3 by 3 echelon matrices U1, . . . , U6.

28 Find a basis for the space of all 2 by 3 matrices whose columns add to zero. Find a basis for the subspace whose rows also add to zero.

29 What subspace of 3 by 3 matrices is spanned (take all combinations) by

(a) the invertible matrices?

(b) the rank one matrices?

(c) the identity matrix?

30 Find a basis for the space of 2 by 3 matrices whose nullspace contains  $ (2, 1, 1) $.

Questions 31–35 are about spaces where the “vectors” are functions.

31 (a) Find all functions that satisfy  $ \frac{dy}{dx}=0 $.

(b) Choose a particular function that satisfies  $ \frac{dy}{dx}=3 $.

(c) Find all functions that satisfy  $ \frac{dy}{dx}=3 $.

32 The cosine space  $ \mathbf{F}_3 $ contains all combinations  $ y(x) = A \cos x + B \cos 2x + C \cos 3x $. Find a basis for the subspace with  $ y(0) = 0 $.

33 Find a basis for the space of functions that satisfy

(a)  $ \frac{dy}{dx} - 2y = 0 $

(b)  $ \frac{dy}{dx} - \frac{y}{x} = 0. $

34 Suppose  $ y_{1}(x) $,  $ y_{2}(x) $,  $ y_{3}(x) $ are three different functions of x. The vector space they span could have dimension 1, 2, or 3. Give an example of  $ y_{1} $,  $ y_{2} $,  $ y_{3} $ to show each possibility.

35 Find a basis for the space of polynomials  $ p(x) $ of degree  $ \leq 3 $. Find a basis for the subspace with  $ p(1) = 0 $.

36 Find a basis for the space S of vectors  $ (a, b, c, d) $ with  $ a + c + d = 0 $ and also for the space T with  $ a + b = 0 $ and  $ c = 2d $. What is the dimension of the intersection  $ S \cap T $?