Apply Gauss-Jordan elimination to reduce to Rx = 0 and Rx = d:

 $$ \begin{bmatrix} \\{{{U}}}&{{{0}}} \\\end{bmatrix}=\begin{bmatrix}{{{3}}}&{{{0}}}&{{{6}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\\end{bmatrix}\quad and\quad\begin{bmatrix} \\{{{U}}}&{{{c}}} \\\end{bmatrix}=\begin{bmatrix}{{{3}}}&{{{0}}}&{{{6}}}&{{{9}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{5}}} \\\end{bmatrix}. $$ 

Solve $Ux = 0$ or $Rx = 0$ to find $x_n$ (free variable = 1). What are the solutions to $Rx = d?$

Reduce to $Ux = c$ (Gaussian elimination) and then $Rx = d$ (Gauss-Jordan):

 $$ \boldsymbol{A}\boldsymbol{x}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{2}}}&{{{3}}} \\{{{1}}}&{{{3}}}&{{{2}}}&{{{0}}} \\{{{2}}}&{{{0}}}&{{{4}}}&{{{9}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}} \\{{{x_{4}}}}\end{bmatrix}=\begin{bmatrix}{{{2}}} \\{{{5}}} \\{{{10}}}\end{bmatrix}=\boldsymbol{b}. $$ 

Find a particular solution  $ x_{p} $ and all homogeneous solutions  $ x_{n} $

Find matrices A and B with the given property or explain why you can't:

(a) The only solution of Ax =  $ \begin{bmatrix} 1 \\ 2 \\ 3 \end{bmatrix} $ is x =  $ \begin{bmatrix} 0 \\ 1 \end{bmatrix} $.

(b) The only solution of  $ Bx = \left[\begin{array}{c}0 \\ 1\end{array}\right] $ is  $ x = \left[\begin{array}{c}1 \\ 2 \\ 3\end{array}\right] $.

Find the LU factorization of A and the complete solution to Ax = b:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{1}}} \\{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{4}}}&{{{6}}} \\{{{1}}}&{{{1}}}&{{{5}}}\end{bmatrix}\quad and\quad\boldsymbol{b}=\begin{bmatrix}{{{1}}} \\{{{3}}} \\{{{6}}} \\{{{5}}}\end{bmatrix}\quad and then\quad\boldsymbol{b}=\begin{bmatrix}{{{1}}} \\{{{0}}} \\{{{0}}} \\{{{0}}}\end{bmatrix}. $$ 

The complete solution to Ax =  $ \begin{bmatrix} 1 \\ 3 \end{bmatrix} $ is  $ x = \begin{bmatrix} 1 \\ 0 \end{bmatrix} + c \begin{bmatrix} 0 \\ 1 \end{bmatrix} $. Find A.