A and U and R also have r independent columns (the pivot columns). Section 3.4 says what it means for rows or columns to be independent.

A third definition of rank, at the top level of linear algebra, will deal with spaces of vectors. The rank r is the “dimension” of the column space. It is also the dimension of the row space. The great thing is that n - r is the dimension of the nullspace.

## ■ REVIEW OF THE KEY IDEAS

1. The nullspace  $ \mathbf{N}(A) $ is a subspace of  $ \mathbf{R}^n $. It contains all solutions to Ax = 0.

2. Elimination on A produces a row reduced R with pivot columns and free columns.

3. Every free column leads to a special solution. That free variable is 1, the others are 0.

4. The rank r of A is the number of pivots. All pivots are 1's in R = rref(A).

5. The complete solution to Ax = 0 is a combination of the n - r special solutions.

6. A always has a free column if n > m, giving a nonzero solution to Ax = 0

## WORKED EXAMPLES

3.2 A Why do A and R have the same nullspace if EA = R and E is invertible?

Solution If Ax = 0 then  $ Rx = EAx = E0 = 0 $

 $$  If Rx=0then\quad Ax=E^{-1}Rx=E^{-1}0=0 $$ 

A and R also have the same row space and the same rank.

3.2 B Create a 3 by 4 matrix R whose special solutions to  $ Rx = 0 $ are  $ s_1 $ and  $ s_2 $:

 $$ \boldsymbol{s}_{1}=\left[\begin{array}{r}-3\\1\\0\\0\end{array}\right]\quad and\quad\boldsymbol{s}_{2}=\left[\begin{array}{r}-2\\0\\-6\\1\end{array}\right]\quad 軸 \quad 軸 \boldsymbol{p}ivot columns1and3\\ free variables x_{2}and x_{4} $$ 

Describe all possible matrices A with this nullspace  $ \mathbf{N}(A) $ = all combinations of  $ s_1 $ and  $ s_2 $.

Solution The reduced matrix $R$ has pivots = 1 in columns 1 and 3. There is no third pivot, so row 3 of $R$ is all zeros. The free columns 2 and 4 will be combinations of the pivot columns: 3, 0, 2, 6 in $R$ come from $-3,-0,-2,-6$ in $s_1$ and $s_2$. Every $A = ER$.

Every 3 by 4 matrix has at least one special solution. These matrices have two.

 $$ \boldsymbol{R}=\left[\begin{array}{llll}{{{1}}}&{{{3}}}&{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{6}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]\quad has\quad R\boldsymbol{s}_{1}=\mathbf{0}\quad and\quad R\boldsymbol{s}_{2}=\mathbf{0}. $$ 