## The Four Subspaces for A

We have a job still to do. The subspace dimensions for A are the same as for R. The job is to explain why. A is now any matrix that reduces to  $ R = \operatorname{rref}(A) $.

This A reduces to R

 $$ \boldsymbol{A}=\left[\begin{array}{cccc}{{{1}}}&{{{3}}}&{{{5}}}&{{{0}}}&{{{7}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{2}}} \\{{{1}}}&{{{3}}}&{{{5}}}&{{{1}}}&{{{9}}}\end{array}\right]\quad Notice\boldsymbol{C}(\boldsymbol{A})\neq\boldsymbol{C}(\boldsymbol{R})! $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_185_342_917_770.jpg" alt="Image" width="68%" /></div>


<div style="text-align: center;">Figure 3.5: The dimensions of the Four Fundamental Subspaces (for R and for A).</div>


### 1 A has the same row space as R. Same dimension r and same basis

Reason: Every row of A is a combination of the rows of R. Also every row of R is a combination of the rows of A. Elimination changes rows, but not row spaces.

Since A has the same row space as R, we can choose the first r rows of R as a basis. Or we could choose r suitable rows of the original A. They might not always be the first r rows of A, because those could be dependent. The good r rows of A are the ones that end up as pivot rows in R.

2 The column space of A has dimension r. The column rank equals the row rank.

Rank Theorem: The number of independent columns = the number of independent rows.

Wrong reason: “A and R have the same column space.” This is false. The columns of R often end in zeros. The columns of A don’t often end in zeros. Then  $ C(A) $ is not  $ C(R) $.