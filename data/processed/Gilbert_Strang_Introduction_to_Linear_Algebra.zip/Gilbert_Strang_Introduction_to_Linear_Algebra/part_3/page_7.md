## Challenge Problems

Suppose A is an m by n matrix of rank r. Its reduced echelon form is R. Describe exactly the matrix Z (its shape and all its entries) that comes from transposing the reduced row echelon form of  $ R^{\mathrm{T}} $:

 $$ \boldsymbol{R}=\boldsymbol{r}\mathbf{r}\mathbf{e}\mathbf{f}(\boldsymbol{A})\quad\mathrm{a n d}\quad\boldsymbol{Z}=(\boldsymbol{r}\mathbf{r}\mathbf{e}\mathbf{f}(\boldsymbol{A}^{\mathrm{T}}))^{\mathrm{T}}. $$ 

(Recommended) Suppose R is m by n of rank r, with pivot columns first:

(a) What are the shapes of those four blocks?

(b) Find a right-inverse B with RB = I if r = m. The zero blocks are gone.

 $$ R=\begin{bmatrix}{{{I}}}&{{{F}}} \\{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

(c) Find a left-inverse C with CR = I if r = n. The F and 0 column is gone.

(d) What is the reduced row echelon form of  $ R^{T} $ (with shapes)?

(e) What is the reduced row echelon form of  $ R^{T}R $ (with shapes)?

I think that the reduced echelon form of  $ R^{\mathrm{T}}R $ is always  $ R $ (except for extra zero rows). Can you do an example when  $ R $ is 2 by 3? Later we show that  $ A^{\mathrm{T}}A $ always has the same nullspace as  $ A $ (a valuable fact).

Suppose you allow elementary column operations on A as well as elementary row operations (which get to R). What is the “row-and-column reduced form” for an m by n matrix of rank r?