17 Construct a matrix whose column space contains  $ (1,1,5) $ and  $ (0,3,1) $ and whose nullspace contains  $ (1,1,2) $.

18 Construct a matrix whose column space contains  $ (1,1,0) $ and  $ (0,1,1) $ and whose nullspace contains  $ (1,0,1) $ and  $ (0,0,1) $.

19 Construct a matrix whose column space contains  $ (1, 1, 1) $ and whose nullspace is the line of multiples of  $ (1, 1, 1, 1) $.

20 Construct a 2 by 2 matrix whose nullspace equals its column space. This is possible.

21 Why does no 3 by 3 matrix have a nullspace that equals its column space?

22 If AB = 0 then the column space of B is contained in the ___ of A. Why?

23 The reduced form $R$ of a 3 by 3 matrix with randomly chosen entries is almost sure to be ___. What $R$ is virtually certain if the random $A$ is 4 by 3?

24 Show by example that these three statements are generally false:

(a) A and  $ A^{T} $ have the same nullspace.

(b) A and  $ A^{T} $ have the same free variables.

(c) If  $ R $ is the reduced form  $ \text{rref}(A) $ then  $ R^{\text{T}} $ is  $ \text{rref}(A^{\text{T}}) $.

25 If  $ N(A) = \text{all multiples of } x = (2, 1, 0, 1) $, what is R and what is its rank?

26 If the special solutions to  $ Rx = 0 $ are in the columns of these nullspace matrices N, go backward to find the nonzero rows of the reduced matrices R:

 $$ N=\begin{bmatrix}{{{2}}}&{{{3}}} \\{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad N=\begin{bmatrix}{{{0}}} \\{{{0}}} \\{{{1}}}\end{bmatrix}\quad and\quad N=\begin{bmatrix}\\\end{bmatrix}(empty3by1). $$ 

(a) What are the five 2 by 2 reduced matrices R whose entries are all 0's and 1's?

(b) What are the eight 1 by 3 matrices containing only 0's and 1's? Are all eight of them reduced echelon matrices R?

Explain why A and -A always have the same reduced echelon form R.

If A is 4 by 4 and invertible, describe the nullspace of the 4 by 8 matrix  $ B = [A \quad A] $.

How is the nullspace $N(C)$ related to the spaces $N(A)$ and $N(B)$, if $C = \left[\begin{array}{c} A \\ B \end{array}\right] ?$

31 Find the reduced row echelon forms R and the rank of these matrices:

(a) The 3 by 4 matrix with all entries equal to 4.

(b) The 3 by 4 matrix with  $ a_{ij} = i + j - 1 $.

(c) The 3 by 4 matrix with  $ a_{ij} = (-1)^j $.