## Elimination: The Big Picture

This page explains elimination at the vector level and subspace level, when A is reduced to R. You know the steps and I won't repeat them. Elimination starts with the first pivot. It moves a column at a time (left to right) and a row at a time (top to bottom). As it moves, elimination answers two questions:

## Question 1 Is this column a combination of previous columns?

If the column contains a pivot, the answer is no. Pivot columns are “independent” of previous columns. If column 4 has no pivot, it is a combination of columns 1, 2, 3.

## Question 2 Is this row a combination of previous rows?

If the row contains a pivot, the answer is no. Pivot rows are “independent” of previous rows. If row 3 ends up with no pivot, it is a zero row and it is moved to the bottom of R.

It is amazing to me that one pass through the matrix answers both questions. Actually that pass reaches the triangular echelon matrix U, not the reduced echelon matrix R. Then the reduction from U to R goes bottom to top. U tells which columns are combinations of earlier columns (pivots are missing). Then R tells us what those combinations are.

In other words, R tells us the special solutions to Ax = 0. We could reach R from A by different row exchanges and elimination steps, but it will always be the same R (because the special solutions are decided by A). In the language coming soon, R reveals a “basis” for three fundamental subspaces:

The column space of A—choose the pivot columns of A as a basis.

The row space of A—choose the nonzero rows of R as a basis.

The nullspace of A—choose the special solutions to Rx = 0 (and Ax = 0).

We learn from elimination the single most important number—the  $ \mathbf{rank} $ r. That number counts the pivot columns and the pivot rows. Then n - r counts the free columns and the special solutions.

I mention that reducing  $ [A\ I] $ to  $ [R\ E] $ will tell you even more about A—in fact virtually everything (including  $ EA = R $). The matrix E keeps a record, otherwise lost, of the elimination from A to R. When A is square and invertible, R is I and E is  $ A^{-1} $.