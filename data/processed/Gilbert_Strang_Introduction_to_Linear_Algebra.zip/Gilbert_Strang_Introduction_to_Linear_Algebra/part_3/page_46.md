The column space  $ C(A) $ There must be r = 3 independent columns. The fast way is to look at the first 3 columns. The systematic way is to find  $ R = \text{rref}(A) $.

Columns 1, 2, 3 of A

 $$ \begin{array}{c c c c c}{{{-1}}}&{{{1}}}&{{{0}}} \\{{{-1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{-1}}}&{{{1}}} \\{{{0}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{-1}}}\end{array}\qquad R=\underset{}{\mathrm{e c h e l o n f o r m}}{\mathrm{r o w}}=\left[\begin{array}{c c c c}{{{1}}}&{{{0}}}&{{{0}}}&{{{-1}}} \\{{{0}}}&{{{1}}}&{{{0}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right] $$ 

From $R$ we see again the special solution $x = (1, 1, 1, 1)$. The first 3 columns are basic, the fourth column is free. To produce a basis for $C(A)$ and not $C(R)$, we go back to columns 1, 2, 3 of $A$. The column space has dimension $r = 3$.

The row space  $ C(A^{\mathrm{T}}) $ The dimension must again be r = 3. But the first 3 rows of A are not independent: row 3 = row 2 - row 1. So row 3 became zero in elimination, and row 3 was exchanged with row 4. The first three independent rows are rows 1, 2, 4. Those three rows are a basis (one possible basis) for the row space.

I notice that edges 1, 2, 3 form a loop in the picture: Dependent rows 1, 2, 3. Edges 1, 2, 4 form a tree in the picture. Trees have no loops! Independent rows 1, 2, 4.

The left nullspace  $ N(A^{\mathrm{T}}) $ Now we solve  $ A^{\mathrm{T}}y = 0 $. Combinations of the rows give zero. We already noticed that row 3 = row 2 - row 1, so one solution is  $ y = (1, -1, 1, 0, 0) $. I would say: That y comes from following the upper loop in the picture. Another y comes from going around the lower loop and it is  $ y = (0, 0, -1, 1, -1) $: row 3 = row 4 - row 5. Those two y's are independent, they solve  $ A^{\mathrm{T}}y = 0 $, and the dimension of  $ N(A^{\mathrm{T}}) $ is  $ m - r = 5 - 3 = 2 $. So we have a basis for the left nullspace.

You may ask how “loops” and “trees” got into this problem. That didn’t have to happen. We could have used elimination to solve  $ A^{\mathrm{T}}y = 0 $. The 4 by 5 matrix  $ A^{\mathrm{T}} $ would have three pivot columns 1, 2, 4 and two free columns 3, 5. There are two special solutions and the nullspace of  $ A^{\mathrm{T}} $ has dimension two:  $ m - r = 5 - 3 = 2 $. But loops and trees identify dependent rows and independent rows in a beautiful way. We use them in Section 10.1 for every incidence matrix like this A.

The equations  $ Ax = b $ give “voltages”  $ x_{1}, x_{2}, x_{3}, x_{4} $ at the four nodes. The equations  $ A^{T}y = 0 $ give “currents”  $ y_{1}, y_{2}, y_{3}, y_{4}, y_{5} $ on the five edges. These two equations are Kirchhoff’s Voltage Law and Kirchhoff’s Current Law. Those words apply to an electrical network. But the ideas behind the words apply all over engineering and science and economics and business.

Graphs are the most important model in discrete applied mathematics. You see graphs everywhere: roads, pipelines, blood flow, the brain, the Web, the economy of a country or the world. We can understand their matrices A and  $ A^{T} $.