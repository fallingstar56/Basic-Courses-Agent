3.3 B Suppose you have this information about the solutions to Ax = b for a specific b. What does that tell you about m and n and r (and A itself)? And possibly about b.

1. There is exactly one solution.

2. All solutions to Ax = b have the form  $ x = \begin{bmatrix} 2 \\ 1 \end{bmatrix} + c\begin{bmatrix} 1 \\ 1 \end{bmatrix} $.

3. There are no solutions.

4. All solutions to Ax = b have the form  $ x = \begin{bmatrix} 1 \\ 1 \\ 0 \end{bmatrix} + c \begin{bmatrix} 1 \\ 0 \\ 1 \end{bmatrix} $

5. There are infinitely many solutions.

Solution In case 1, with exactly one solution, A must have full column rank r = n. The nullspace of A contains only the zero vector. Necessarily  $ m \geq n $.

In case 2, A must have n = 2 columns (and m is arbitrary). With  $ \left[\begin{array}{c}1 \\ 1\end{array}\right] $ in the nullspace of A, column 2 is the negative of column 1. Also  $ A \neq 0 $: the rank is 1. With  $ x = \left[\begin{array}{c}2 \\ 1\end{array}\right] $ as a solution,  $ b = 2(\text{column } 1) + (\text{column } 2) $. My choice for  $ x_p $ would be  $ (1, 0) $.

In case 3 we only know that $b$ is not in the column space of $A$. The rank of $A$ must be less than $m$. I guess we know $b \neq 0$, otherwise $x = 0$ would be a solution.

In case 4, A must have n = 3 columns. With  $ (1,0,1) $ in the nullspace of A, column 3 is the negative of column 1. Column 2 must not be a multiple of column 1, or the nullspace would contain another special solution. So the rank of A is 3 - 1 = 2. Necessarily A has  $ m \geq 2 $ rows. The right side b is column 1 + column 2.

In case 5 with infinitely many solutions, the nullspace must contain nonzero vectors. The rank r must be less than n (not full column rank), and b must be in the column space of A. We don’t know if every b is in the column space, so we don’t know if r = m.

3.3 C Find the complete solution  $ x = x_{p} + x_{n} $ by forward elimination on  $ [A\ b] $:

 $$ \left[\begin{array}{l l l l}{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}} \\{{{2}}}&{{{4}}}&{{{4}}}&{{{8}}} \\{{{4}}}&{{{8}}}&{{{6}}}&{{{8}}}\end{array}\right]\left[\begin{array}{l}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}} \\{{{x_{4}}}}\end{array}\right]=\left[\begin{array}{r}{{{4}}} \\{{{2}}} \\{{{10}}}\end{array}\right]. $$ 

Find numbers  $ y_1 $,  $ y_2 $,  $ y_3 $ so that  $ y_1 $ (row 1) +  $ y_2 $ (row 2) +  $ y_3 $ (row 3) = zero row. Check that  $ b = (4, 2, 10) $ satisfies the condition  $ y_1 b_1 + y_2 b_2 + y_3 b_3 = 0 $. Why is this the condition for the equations to be solvable and b to be in the column space?

Solution Forward elimination on  $ [A\ b] $ produces a zero row in  $ [U\ c] $. The third equation becomes 0 = 0 and the equations are consistent (and solvable):

 $$ \left[\begin{array}{l l l l l}{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}}&{{{4}}} \\{{{2}}}&{{{4}}}&{{{4}}}&{{{8}}}&{{{2}}} \\{{{4}}}&{{{8}}}&{{{6}}}&{{{8}}}&{{{10}}}\end{array}\right]\longrightarrow\left[\begin{array}{l l l l l l}{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{8}}}&{{{-6}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{8}}}&{{{-6}}}\end{array}\right]\longrightarrow\left[\begin{array}{l l l l l}{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{8}}}&{{{-6}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]. $$ 

Columns 1 and 3 contain pivots. The variables  $ x_{2} $ and  $ x_{4} $ are free. If we set those to zero we can solve (back substitution) for the particular solution or we continue to R.