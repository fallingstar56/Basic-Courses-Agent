37 If AS = SA for the shift matrix S, show that A must have this special form:

 $$ \begin{aligned}If\begin{bmatrix}{{{a}}}&{{{b}}}&{{{c}}} \\{{{d}}}&{{{e}}}&{{{f}}} \\{{{g}}}&{{{h}}}&{{{i}}}\end{bmatrix}\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}&=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{a}}}&{{{b}}}&{{{c}}} \\{{{d}}}&{{{e}}}&{{{f}}} \\{{{g}}}&{{{h}}}&{{{i}}}\end{bmatrix}\end{aligned}then A=\begin{bmatrix}{{{a}}}&{{{b}}}&{{{c}}} \\{{{0}}}&{{{a}}}&{{{b}}} \\{{{0}}}&{{{0}}}&{{{a}}}\end{bmatrix}, $$ 

“The subspace of matrices that commute with the shift S has dimension ___.”

38 Which of the following are bases for  $ R^{3} $?

(a)  $ (1,2,0) $ and  $ (0,1,-1) $

(b) $ (1,1,-1) $,  $ (2,3,4) $,  $ (4,1,-1) $,  $ (0,1,-1) $

(c) $ (1,2,2),(-1,2,1),(0,8,0) $

(d)  $ (1,2,2),(-1,2,1),(0,8,6) $

Suppose A is 5 by 4 with rank 4. Show that  $ Ax = b $ has no solution when the 5 by 5 matrix  $ [A\ b] $ is invertible. Show that  $ Ax = b $ is solvable when  $ [A\ b] $ is singular.

(a) Find a basis for all solutions to  $ d^{4}y/dx^{4}=y(x) $.

(b) Find a particular solution to  $ d^{4}y/dx^{4}=y(x)+1 $. Find the complete solution.

## Challenge Problems

41 Write the 3 by 3 identity matrix as a combination of the other five permutation matrices! Then show that those five matrices are linearly independent. (Assume a combination gives  $ c_1P_1 + \cdots + c_5P_5 = \text{zero matrix} $, and check entries to prove that  $ c_1 $ to  $ c_5 $ must all be zero.) The five permutations are a basis for the subspace of 3 by 3 matrices with row and column sums all equal.

Choose $\boldsymbol{x} = (x_1, x_2, x_3, x_4)$ in $\mathbf{R}^4$. It has 24 rearrangements like $(x_2, x_1, x_3, x_4)$ and $(x_4, x_3, x_1, x_2)$. Those 24 vectors, including $x$ itself, span a subspace $\mathbf{S}$. Find specific vectors $x$ so that the dimension of $\mathbf{S}$ is: (a) zero, (b) one, (c) three, (d) four.

Intersections and sums have  $ \dim(\mathbf{V}) + \dim(\mathbf{W}) = \dim(\mathbf{V} \cap \mathbf{W}) + \dim(\mathbf{V} + \mathbf{W}) $. Start with a basis  $ \mathbf{u}_1, \ldots, \mathbf{u}_r $ for the intersection  $ \mathbf{V} \cap \mathbf{W} $. Extend with  $ \mathbf{v}_1, \ldots, \mathbf{v}_s $ to a basis for  $ \mathbf{V} $, and separately with  $ \mathbf{w}_1, \ldots, \mathbf{w}_t $ to a basis for  $ \mathbf{W} $. Prove that the  $ \mathbf{u} $'s,  $ \mathbf{v} $'s and  $ \mathbf{w} $'s together are independent. The dimensions have  $ (r + s) + (r + t) = (r) + (r + s + t) $ as desired.

44 Mike Artin suggested a neat higher-level proof of that dimension formula in Problem 43. From all inputs v in V and w in W, the “sum transformation” produces  $ v + w $. Those outputs fill the space  $ V + W $. The nullspace contains all pairs  $ v = u $,  $ w = -u $ for vectors  $ u $ in  $ V \cap W $. (Then  $ v + w = u - u = 0 $.) So  $ \dim(V + W) + \dim(V \cap W) $ equals  $ \dim(V) + \dim(W) $ (input dimension from V and W) by the Counting Theorem.

dimension of outputs + dimension of nullspace = dimension of inputs.

Problem For an m by n matrix of rank r, what are those 3 dimensions? Outputs = column space. This question will be answered in Section 3.5, can you do it now?