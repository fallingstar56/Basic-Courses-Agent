3.2 C Find the row reduced form R and the rank r of A and B (those depend on c). Which are the pivot columns of A? What are the special solutions?

Find special solutions

 $$ \boldsymbol{A}=\left[\begin{array}{lll}{{{1}}}&{{{2}}}&{{{1}}} \\{{{3}}}&{{{6}}}&{{{3}}} \\{{{4}}}&{{{8}}}&{{{c}}}\end{array}\right]\quad and\quad\boldsymbol{B}=\left[\begin{array}{ll}{{{c}}}&{{{c}}} \\{{{c}}}&{{{c}}}\end{array}\right]. $$ 

Solution The matrix A has row 2 = 3 (row 1). The rank of A is r = 2 except if c = 4.

Row 4 - 4 (row 1) ends in c - 4. The pivots are in columns 1 and 3. The second variable  $ x_{2} $ is free. Notice the form of R: Row 3 has moved up into row 2.

 $$ \boldsymbol{c}\neq\boldsymbol{4}\quad\boldsymbol{R}=\left[\begin{array}{lll}{{{1}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]\quad\boldsymbol{c}=4\quad\boldsymbol{R}=\left[\begin{array}{lll}{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]. $$ 

Two pivots leave one free variable  $ x_{2} $. But when c = 4, the only pivot is in column 1 (rank one). The second and third variables are free, producing two special solutions:

 $ c \neq 4 $ Special solution  $ (-2, 1, 0) $

The 2 by 2 matrix  $ B = \begin{bmatrix} c & c \\ c & c \end{bmatrix} $ has rank r = 1 except if c = 0, when the rank is zero!

 $$ c\neq0\quad R=\left[\begin{array}{cc}{{{1}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{array}\right]\quad c=\mathbf{0}\quad R=\left[\begin{array}{cc}{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{array}\right]\quad and nullspace=\mathbf{R}^{2}. $$ 

### Problem Set 3.2

1 Reduce A and B to their triangular echelon forms U. Which variables are free?

(a)

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{2}}}&{{{4}}}&{{{6}}} \\{{{1}}}&{{{2}}}&{{{3}}}&{{{6}}}&{{{9}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{2}}}&{{{3}}}\end{bmatrix} $$ 

(b)

 $$ \boldsymbol{B}=\begin{bmatrix}{{{2}}}&{{{4}}}&{{{2}}} \\{{{0}}}&{{{4}}}&{{{4}}} \\{{{0}}}&{{{8}}}&{{{8}}}\end{bmatrix}. $$ 

2 For the matrices in Problem 1, find a special solution for each free variable. (Set the free variable to 1. Set the other free variables to zero.)

3 By further row operations on each U in Problem 1, find the reduced echelon form R. True or false with a reason: The nullspace of R equals the nullspace of U.

4 For the same A and B, find the special solutions to Ax=0 and Bx=0. For an m by n matrix, the number of pivot variables plus the number of free variables is ___.

This is the Counting Theorem:  $ r + (n - r) = n $.

(a)

 $$ A=\begin{bmatrix}{{{-1}}}&{{{3}}}&{{{5}}} \\{{{-2}}}&{{{6}}}&{{{10}}}\end{bmatrix} $$ 

(b)

 $$ B=\begin{bmatrix}{{{-1}}}&{{{3}}}&{{{5}}} \\{{{-2}}}&{{{6}}}&{{{7}}}\end{bmatrix}. $$ 