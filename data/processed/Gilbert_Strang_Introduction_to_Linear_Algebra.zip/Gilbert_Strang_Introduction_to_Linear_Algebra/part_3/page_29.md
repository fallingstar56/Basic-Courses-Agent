matrix A with rank one has only one vector in the basis:

Basis for the column space:

 $$ \begin{bmatrix}2\\ 3\end{bmatrix}.\quad Basis for the row space:\quad\begin{bmatrix}1\\ 2\end{bmatrix}. $$ 

The next chapter will come back to these bases for the column space and row space. We are happy first with examples where the situation is clear (and the idea of a basis is still new). The next example is larger but still clear.

Example 9 Find bases for the column and row spaces of this rank two matrix:

 $$ \boldsymbol{R}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{0}}}&{{{3}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

Columns 1 and 3 are the pivot columns. They are a basis for the column space (of  $ R! $). The vectors in that column space all have the form  $ \mathbf{b} = (x, y, 0) $. The column space of  $ R $ is the “xy plane” inside the full 3-dimensional xyz space. That plane is not  $ \mathbf{R}^2 $, it is a subspace of  $ \mathbf{R}^3 $. Columns 2 and 3 are also a basis for the same column space. Which pairs of columns of  $ R $ are not a basis for its column space?

The row space of $R$ is a subspace of $\mathbf{R}^4$. The simplest basis for that row space is the two nonzero rows of $R$. The third row (the zero vector) is in the row space too. But it is not in a basis for the row space. The basis vectors must be independent.

Question Given five vectors in  $ R^{7} $, how do you find a basis for the space they span?

First answer Make them the rows of A, and eliminate to find the nonzero rows of R. Second answer Put the five vectors into the columns of A. Eliminate to find the pivot columns (of A not R). Those pivot columns are a basis for the column space.

Could another basis have more vectors, or fewer? This is a crucial question with a good answer: No. All bases for a vector space contain the same number of vectors.

The number of vectors, in any and every basis, is the “dimension” of the space.

Dimension of a Vector Space

We have to prove what was just stated. There are many choices for the basis vectors, but the number of basis vectors doesn't change.

If  $ v_{1}, \ldots, v_{m} $ and  $ w_{1}, \ldots, w_{n} $ are both bases for the same vector space, then m = n.

Proof Suppose that there are more $w$'s than $v$'s. From $n > m$ we want to reach a contradiction. The $v$'s are a basis, so $w_1$ must be a combination of the $v$'s. If $w_1$ equals