9 Suppose  $ v_{1}, v_{2}, v_{3}, v_{4} $ are vectors in  $ R^{3} $

(a) These four vectors are dependent because ___.

(b) The two vectors  $ v_{1} $ and  $ v_{2} $ will be dependent if ___.

(c) The vectors  $ v_{1} $ and  $ (0,0,0) $ are dependent because ___.

10 Find two independent vectors on the plane  $ x + 2y - 3z - t = 0 $ in  $ \mathbf{R}^4 $. Then find three independent vectors. Why not four? This plane is the nullspace of what matrix?

Questions 11–14 are about the space spanned by a set of vectors. Take all linear combinations of the vectors.

11 Describe the subspace of  $ \mathbf{R}^3 $ (is it a line or plane or  $ \mathbf{R}^3 $?) spanned by

(a) the two vectors  $ (1,1,-1) $ and  $ (-1,-1,1) $

(b) the three vectors  $ (0,1,1) $ and  $ (1,1,0) $ and  $ (0,0,0) $

(c) all vectors in  $ R^{3} $ with whole number components

(d) all vectors with positive components.

12 The vector b is in the subspace spanned by the columns of A when ___ has a solution. The vector c is in the row space of A when ___ has a solution.

True or false: If the zero vector is in the row space, the rows are dependent.

13 Find the dimensions of these 4 spaces. Which two of the spaces are the same? (a) column space of A, (b) column space of U, (c) row space of A, (d) row space of U:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{3}}}&{{{1}}} \\{{{3}}}&{{{1}}}&{{{-1}}}\end{bmatrix}\quad and\quad\boldsymbol{U}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}. $$ 

14  $ v + w $ and  $ v - w $ are combinations of v and w. Write v and w as combinations of  $ v + w $ and  $ v - w $. The two pairs of vectors ___ the same space. When are they a basis for the same space?

Questions 15–25 are about the requirements for a basis.

15 If  $ v_{1}, \ldots, v_{n} $ are linearly independent, the space they span has dimension ___.

These vectors are a ___ for that space. If the vectors are the columns of an m by n matrix, then m is ___ than n. If m = n, that matrix is ___.

16 Find a basis for each of these subspaces of  $ \mathbf{R}^4 $:

(a) All vectors whose components are equal.

(b) All vectors whose components add to zero.

(c) All vectors that are perpendicular to  $ (1,1,0,0) $ and  $ (1,0,1,1) $.

(d) The column space and the nullspace of I (4 by 4).