(a) Suppose column $j$ of $B$ is a combination of previous columns of $B$. Show that column $j$ of $AB$ is the same combination of previous columns of $AB$. Then $AB$ cannot have new pivot columns, so $\operatorname{rank}(AB) \leq \operatorname{rank}(B)$.

(b) Find  $ A_1 $ and  $ A_2 $ so that  $ \text{rank}(A_1B) = 1 $ and  $ \text{rank}(A_2B) = 0 $ for  $ B = \begin{bmatrix} 1 & 1 \\ 1 & 1 \end{bmatrix} $.

Problem 48 proved that  $ \text{rank}(AB) \leq \text{rank}(B) $. Then the same reasoning gives  $ \text{rank}(B^{\mathrm{T}} A^{\mathrm{T}}) \leq \text{rank}(A^{\mathrm{T}}) $. How do you deduce that  $ \text{rank}(AB) \leq \text{rank} A $?

(Important) Suppose A and B are n by n matrices, and AB = I. Prove from  $ \operatorname{rank}(AB) \leq \operatorname{rank}(A) $ that the rank of A is n. So A is invertible and B must be its two-sided inverse (Section 2.5). Therefore BA = I (which is not so obvious!).

If A is 2 by 3 and B is 3 by 2 and AB = I, show from its rank that  $ BA \neq I $. Give an example of A and B with AB = I. For m < n, a right inverse is not a left inverse.

52 Suppose A and B have the same reduced row echelon form R.

(a) Show that A and B have the same nullspace and the same row space.

(b) We know  $ E_{1}A = R $ and  $ E_{2}B = R $. So A equals an ___ matrix times B.

53 Express A and then B as the sum of two rank one matrices:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{4}}} \\{{{1}}}&{{{1}}}&{{{8}}}\end{bmatrix}\qquad\boldsymbol{B}=\begin{bmatrix}{{{2}}}&{{{2}}} \\{{{2}}}&{{{3}}}\end{bmatrix}. $$ 

54 Answer the same questions as in Worked Example 3.2 C for

 $$ A=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{2}}}&{{{4}}}&{{{4}}} \\{{{1}}}&{{{c}}}&{{{2}}}&{{{2}}}\end{bmatrix}\qquad and\qquad B=\begin{bmatrix}{{{1-c}}}&{{{2}}} \\{{{0}}}&{{{2-c}}}\end{bmatrix}. $$ 

What is the nullspace matrix N (containing the special solutions) for A, B, C?

Block matrices  $ A = \begin{bmatrix} I & I \end{bmatrix} $ and  $ B = \begin{bmatrix} I & I \\ 0 & 0 \end{bmatrix} $ and  $ C = \begin{bmatrix} I & I & I \end{bmatrix} $.

Neat fact Every m by n matrix of rank r reduces to (m by r) times (r by n):

 $ A = (\text{pivot columns of } A) $ (first  $ r $ rows of  $ R $) = (COL)(ROW).

Write the 3 by 4 matrix A of all ones as the product of the 3 by 1 matrix from the pivot columns and the 1 by 4 matrix from R.