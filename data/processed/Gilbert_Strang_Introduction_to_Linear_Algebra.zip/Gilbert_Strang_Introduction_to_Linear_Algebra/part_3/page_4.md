32 Kirchhoff's Current Law  $ A^{\mathrm{T}}y = 0 $ says that current in = current out at every node. At node 1 this is  $ y_3 = y_1 + y_4 $. Write the four equations for Kirchhoff's Law at the four nodes (arrows show the positive direction of each y). Reduce  $ A^{\mathrm{T}} $ to R and find three special solutions in the nullspace of  $ A^{\mathrm{T}} $ (4 by 6 matrix).

<div style="text-align: center;"><img src="imgs/img_in_image_box_257_232_514_470.jpg" alt="Image" width="24%" /></div>


 $$ \boldsymbol{A}=\left[\begin{array}{cccc}{{{-1}}}&{{{1}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{-1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{0}}}&{{{-1}}}&{{{0}}} \\{{{-1}}}&{{{0}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{-1}}}&{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{-1}}}&{{{1}}}\end{array}\right] $$ 

33 Which of these rules gives a correct definition of the rank of A?

(a) The number of nonzero rows in R.

(b) The number of columns minus the total number of rows.

(c) The number of columns minus the number of free columns.

(d) The number of 1's in the matrix R.

34 Find the reduced R for each of these (block) matrices:

 $$ A=\begin{bmatrix}{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{3}}} \\{{{2}}}&{{{4}}}&{{{6}}}\end{bmatrix}\quad B=\begin{bmatrix}{{{A}}}&{{{A}}}\end{bmatrix}\quad C=\begin{bmatrix}{{{A}}}&{{{A}}} \\{{{A}}}&{{{0}}}\end{bmatrix} $$ 

35 Suppose all the pivot variables come last instead of first. Describe all four blocks in the reduced echelon form (the block B should be r by r):

 $$ R=\begin{bmatrix}{{{A}}}&{{{B}}} \\{{{C}}}&{{{D}}}\end{bmatrix}. $$ 

...ons?

(Silly problem) Describe all 2 by 3 matrices  $ A_1 $ and  $ A_2 $, with row echelon forms  $ R_1 $ and  $ R_2 $, such that  $ R_1 + R_2 $ is the row echelon form of  $ A_1 + A_2 $. Is it true that  $ R_1 = A_1 $ and  $ R_2 = A_2 $ in this case? Does  $ R_1 - R_2 $ equal  $ \mathbf{rref}(A_1 - A_2) $?

If A has r pivot columns, how do you know that  $ A^{T} $ has r pivot columns? Give a 3 by 3 example with different column numbers in pivcol for A and  $ A^{T} $.

What are the special solutions to  $ Rx = 0 $ and  $ y^T R = 0 $ for these  $ R $?

 $$ R=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{2}}}&{{{3}}} \\{{{0}}}&{{{1}}}&{{{4}}}&{{{5}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\quad R=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix} $$ 