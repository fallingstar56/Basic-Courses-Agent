Every matrix A with full column rank  $ (r = n) $ has all these properties:

1. All columns of A are pivot columns.

2. There are no free variables or special solutions.

3. The nullspace N(A) contains only the zero vector x = 0.

4. If Ax = b has a solution (it might not) then it has only one solution.

In the essential language of the next section, this A has independent columns.  $ Ax = 0 $ only happens when x = 0. In Chapter 4 we will add one more fact to the list: The square matrix  $ A^{T}A $ is invertible when the rank is n.

In this case the nullspace of $A$ (and $R$) has shrunk to the zero vector. The solution to $Ax = b$ is unique (if it exists). There will be $m - n$ zero rows in $R$. So there are $m - n$ conditions on $b$ in order to have $0 = 0$ in those rows, and $b$ in the column space. With full column rank, $Ax = b$ has one solution or no solution ($m > n$ is overdetermined).

The Complete Solution

The other extreme case is full row rank. Now  $ Ax = b $ has one or infinitely many solutions. In this case  $ A $ must be short and wide ( $ m \leq n $).  $ A $ matrix has full row rank if  $ r = m $. “The rows are independent.” Every row has a pivot, and here is an example.

Example 2 This system Ax = b has n = 3 unknowns but only m = 2 equations:

Full row rank

 $$ \begin{array}{r c c c c c c c}{x}&{+}&{y}&{+}&{z}&{=}&{3}&{}&{}\\ {x}&{+}&{2y}&{-}&{z}&{=}&{4}&{}&{}\\ \end{array}\quad(\mathrm{r a n k}\;r=m=2) $$ 

These are two planes in xyz space. The planes are not parallel so they intersect in a line. This line of solutions is exactly what elimination will find. The particular solution will be one point on the line. Adding the nullspace vectors  $ x_n $ will move us along the line in Figure 3.3. Then  $ x = x_p + x_n $ gives the whole line of solutions.

<div style="text-align: center;"><img src="imgs/img_in_image_box_322_985_703_1130.jpg" alt="Image" width="35%" /></div>


<div style="text-align: center;">Figure 3.3: Complete solution = one particular solution + all nullspace solutions.</div>
