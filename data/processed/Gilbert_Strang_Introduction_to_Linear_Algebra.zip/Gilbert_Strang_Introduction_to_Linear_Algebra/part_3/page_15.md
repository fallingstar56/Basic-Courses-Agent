1. Reduce [A b] to [U c], so that Ax = b becomes a triangular system Ux = c.

2. Find the condition on  $ b_{1}, b_{2}, b_{3} $ for Ax = b to have a solution.

3. Describe the column space of A. Which plane in  $ R^{3} $?

4. Describe the nullspace of A. Which special solutions in  $ R^{4} $?

5. Reduce [U c] to [R d]: Special solutions from R, particular solution from d.

6. Find a particular solution to  $ Ax = (0, 6, -6) $ and then the complete solution.

## Solution

1. The multipliers in elimination are 2 and 3 and -1. They take [A b] into [U c].

 $$ \begin{bmatrix}1&2&3&5&\mathbf{b}_{1}\\ 2&4&8&12&\mathbf{b}_{2}\\ 3&6&7&13&\mathbf{b}_{3}\end{bmatrix}\rightarrow\begin{bmatrix}1&2&3&5\\\ 0&0&2&2\\ 0&0&-2&-2\end{bmatrix}\begin{vmatrix}\mathbf{b}_{1}\\\mathbf{b}_{2}-\mathbf{2}\mathbf{b}_{1}\\\mathbf{b}_{3}-\mathbf{3}\mathbf{b}_{1}\end{vmatrix}\rightarrow\begin{bmatrix}1&2&3&5\\\ 0&0&2&2\\ 0&0&0&0\end{vmatrix}\begin{vmatrix}\mathbf{b}_{1}\\\mathbf{b}_{2}-\mathbf{2}\mathbf{b}_{1}\\\mathbf{b}_{3}+\mathbf{b}_{2}-5\mathbf{b}_{1}\end{vmatrix} $$ 

2. The last equation shows the solvability condition  $ b_{3} + b_{2} - 5b_{1} = 0 $. Then 0 = 0.

3. First description: The column space is the plane containing all combinations of the pivot columns  $ (1,2,3) $ and  $ (3,8,7) $. The pivots are in columns 1 and 3. Second description: The column space contains all vectors with  $ b_3 + b_2 - 5b_1 = 0 $. That makes  $ Ax = b $ solvable, so  $ b $ is in the column space. All columns of  $ A $ pass this test  $ b_3 + b_2 - 5b_1 = 0 $. This is the equation for the plane in the first description!

4. The special solutions have free variables  $ x_{2}=1 $,  $ x_{4}=0 $ and then  $ x_{2}=0 $,  $ x_{4}=1 $:

Special solutions to Ax = 0

Back substitution in  $ Ux = 0 $

or change signs of 2, 2, 1 in R

 $$ \boldsymbol{s}_{1}=\left[\begin{array}{r}-2\\ 1\\ 0\\ 0\end{array}\right]\qquad\boldsymbol{s}_{2}=\left[\begin{array}{r}-2\\ 0\\ -1\\ 1\end{array}\right] $$ 

The nullspace  $ N(A) $ in  $ R^{4} $ contains all  $ x_{n}=c_{1}s_{1}+c_{2}s_{2} $.

5. In the reduced form $R$, the third column changes from $(3,2,0)$ in $U$ to $(0,1,0)$. The right side $c = (0,6,0)$ becomes $d = (-9,3,0)$ showing $-9$ and $3$ in $x_p$:

 $$ \left[U\quad\boldsymbol{c}\right]=\left[\begin{array}{c c c c c}{{{1}}}&{{{2}}}&{{{3}}}&{{{5}}}&{{{\mathbf{0}}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{2}}}&{{{\mathbf{6}}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{\mathbf{0}}}}\end{array}\right]\longrightarrow\left[\boldsymbol{R}\quad\boldsymbol{d}\right]=\left[\begin{array}{c c c c c}{{{1}}}&{{{2}}}&{{{0}}}&{{{2}}}&{{{-9}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{1}}}&{{{\mathbf{3}}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{\mathbf{0}}}}\end{array}\right] $$ 

6. One particular solution  $ x_{p} $ has free variables = zero. Back substitute in  $ Ux = c $:

Particular solution to  $ Ax_{p} = b $

Bring -9 and 3 from the vector d

Free variables  $ x_{2} $ and  $ x_{4} $ are zero

 $$ \begin{aligned}&\boldsymbol{x}_{p}=\begin{bmatrix} \\{{{-9}}} \\{{{0}}} \\{{{3}}} \\{{{0}}} \\\end{bmatrix}\\ \end{aligned} $$ 

The complete solution to Ax = (0, 6, -6) is x = x_p + x_n = x_p + c_1 s_1 + c_2 s_2.