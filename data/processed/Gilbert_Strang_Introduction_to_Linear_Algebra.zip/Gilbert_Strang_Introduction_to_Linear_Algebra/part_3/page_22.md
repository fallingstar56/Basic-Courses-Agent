## Challenge Problems

(Recommended!) Suppose you know that the 3 by 4 matrix A has the vector  $ s = (2, 3, 1, 0) $ as the only special solution to Ax = 0.

(a) What is the rank of A and the complete solution to Ax = 0?

(b) What is the exact row reduced echelon form R of A?

(c) How do you know that Ax = b can be solved for all b?

Suppose $K$ is the 9 by 9 second difference matrix ($2$'s on the diagonal, $-1$'s on the diagonal above and also below). Solve the equation $K\boldsymbol{x}=\boldsymbol{b}=(10,\ldots,10)$. If you graph $x_{1},\ldots,x_{9}$ above the points $1,\ldots,9$ on the $x$ axis, I think the nine points fall on a parabola.

Suppose $Ax = b$ and $Cx = b$ have the same (complete) solutions for every $b$. Is it true that $A$ equals $C$?

Describe the column space of a reduced row echelon matrix R.