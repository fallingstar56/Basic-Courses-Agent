## The Four Subspaces for R

Suppose A is reduced to its row echelon form R. For that special form, the four subspaces are easy to identify. We will find a basis for each subspace and check its dimension. Then we watch how the subspaces change (two of them don't change!) as we look back at A. The main point is that the four dimensions are the same for A and R.

As a specific 3 by 5 example, look at the four subspaces for this echelon matrix R:

 $$ \begin{aligned}m&=3\\n&=5\\r&=2\end{aligned}\qquad\boldsymbol{R}=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{5}}}&{{{0}}}&{{{7}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{1}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix} $$ 

pivot rows 1 and 2

pivot columns 1 and 4

The rank of this matrix is r = 2 (two pivots). Take the four subspaces in order.

1. The row space of R has dimension 2, matching the rank.

Reason: The first two rows are a basis. The row space contains combinations of all three rows, but the third row (the zero row) adds nothing new. So rows 1 and 2 span the row space  $ C(R^{\mathrm{T}}) $.

The pivot rows 1 and 2 are independent. That is obvious for this example, and it is always true. If we look only at the pivot columns, we see the r by r identity matrix. There is no way to combine its rows to give the zero row (except by the combination with all coefficients zero). So the r pivot rows are a basis for the row space.

The dimension of the row space is the rank r. The nonzero rows of R form a basis.

2. The column space of R also has dimension r = 2.

Reason: The pivot columns 1 and 4 form a basis for  $ C(R) $. They are independent because they start with the r by r identity matrix. No combination of those pivot columns can give the zero column (except the combination with all coefficients zero). And they also span the column space. Every other (free) column is a combination of the pivot columns. Actually the combinations we need are the three special solutions!

Column 2 is 3 (column 1). The special solution is  $ (-3, 1, 0, 0, 0) $.

Column 3 is 5 (column 1). The special solution is  $ (-5,0,1,0,0,\cdot) $.

Column 5 is 7 (column 1) + 2 (column 4). That solution is  $ (-7, 0, 0, -2, 1) $.

The pivot columns are independent, and they span, so they are a basis for  $ C(R) $.

The dimension of the column space is the rank  $ \tau $. The pivot columns form a basis.