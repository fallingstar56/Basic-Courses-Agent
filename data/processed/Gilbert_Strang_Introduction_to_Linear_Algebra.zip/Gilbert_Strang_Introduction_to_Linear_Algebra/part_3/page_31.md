Matrix spaces and function spaces may look a little strange after  $ R^{n} $. But in some way, you haven’t got the ideas of basis and dimension straight until you can apply them to “vectors” other than column vectors.

Matrix spaces The vector space M contains all 2 by 2 matrices. Its dimension is 4.

One basis is

 $$ A_{1},A_{2},A_{3},A_{4}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix},\begin{bmatrix}{{{0}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{bmatrix},\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{1}}}&{{{0}}}\end{bmatrix},\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

Those matrices are linearly independent. We are not looking at their columns, but at the whole matrix. Combinations of those four matrices can produce any matrix in M, so they span the space:

Every A combines the basis matrices

 $$ c_{1}A_{1}+c_{2}A_{2}+c_{3}A_{3}+c_{4}A_{4}=\begin{bmatrix}c_{1}&c_{2}\\ c_{3}&c_{4}\end{bmatrix}=A. $$ 

A is zero only if the $c$’s are all zero—this proves independence of $A_{1}, A_{2}, A_{3}, A_{4}$.

The three matrices  $ A_1, A_2, A_4 $ are a basis for a subspace—the upper triangular matrices. Its dimension is 3.  $ A_1 $ and  $ A_4 $ are a basis for the diagonal matrices. What is a basis for the symmetric matrices? Keep  $ A_1 $ and  $ A_4 $, and throw in  $ A_2 + A_3 $.

To push this further, think about the space of all $n$ by $n$ matrices. One possible basis uses matrices that have only a single nonzero entry (that entry is 1). There are $n^2$ positions for that 1, so there are $n^2$ basis matrices:

The dimension of the whole n by n matrix space is  $ n^{2} $.

The dimension of the subspace of upper triangular matrices is  $ \frac{1}{2}n^{2} + \frac{1}{2}n $.

The dimension of the subspace of diagonal matrices is n.

The dimension of the subspace of symmetric matrices is  $ \frac{1}{2}n^2 + \frac{1}{2}n $ (why ?).

Function spaces The equations  $ d^2y/dx^2 = 0 $ and  $ d^2y/dx^2 = -y $ and  $ d^2y/dx^2 = y $ involve the second derivative. In calculus we solve to find the functions  $ y(x) $:

 $$ \begin{array}{ll}y^{\prime \prime}=0&is solved by any linear function y=cx+d\\y^{\prime \prime}=-y&is solved by any combination y=c\sin x+d\cos x\\y^{\prime \prime}=y&is solved by any combination y=ce^{x}+de^{-x}.\end{array} $$ 

That solution space for  $ y'' = -y $ has two basis functions:  $ \sin x $ and  $ \cos x $. The space for  $ y'' = 0 $ has x and 1. It is the “nullspace” of the second derivative! The dimension is 2 in each case (these are second-order equations).

The solutions of  $ y'' = 2 $ don't form a subspace—the right side b = 2 is not zero. A particular solution is  $ y(x) = x^2 $. The complete solution is  $ y(x) = x^2 + cx + d $. All those functions satisfy  $ y'' = 2 $. Notice the particular solution plus any function  $ cx + d $ in the nullspace. A linear differential equation is like a linear matrix equation  $ Ax = b $. But we solve it by calculus instead of linear algebra.