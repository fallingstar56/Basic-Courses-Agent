DEFINITION The row space of a matrix is the subspace of  $ \mathbf{R}^n $ spanned by the rows.

The row space of A is  $ C(A^{\mathrm{T}}) $. It is the column space of  $ A^{\mathrm{T}} $.

The rows of an m by n matrix have n components. They are vectors in  $ \mathbf{R}^n $—or they would be if they were written as column vectors. There is a quick way to fix that: Transpose the matrix. Instead of the rows of A, look at the columns of  $ A^\mathrm{T} $. Same numbers, but now in the column space  $ \mathbf{C}(A^\mathrm{T}) $. This row space of A is a subspace of  $ \mathbf{R}^n $.

Example 5 Describe the column space and the row space of A.

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{4}}} \\{{{2}}}&{{{7}}} \\{{{3}}}&{{{5}}}\end{bmatrix}\text{and}\boldsymbol{A}^{\mathrm{T}}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{4}}}&{{{7}}}&{{{5}}}\end{bmatrix}.\text{Here}m=3\text{and}n=2. $$ 

The column space of A is the plane in  $ \mathbf{R}^3 $ spanned by the two columns of A. The row space of A is spanned by the three rows of A (which are columns of  $ A^\mathrm{T} $). This row space is all of  $ \mathbf{R}^2 $. Remember: The rows are in  $ \mathbf{R}^n $ spanning the row space. The columns are in  $ \mathbf{R}^m $ spanning the column space. Same numbers, different vectors, different spaces.

## A Basis for a Vector Space

Two vectors can't span all of  $ R^{3} $, even if they are independent. Four vectors can't be independent, even if they span  $ R^{3} $. We want enough independent vectors to span the space (and not more). A “basis” is just right.

DEFINITION A basis for a vector space is a sequence of vectors with two properties:

The basis vectors are linearly independent and they span the space.

This combination of properties is fundamental to linear algebra. Every vector v in the space is a combination of the basis vectors, because they span the space. More than that, the combination that produces v is unique, because the basis vectors  $ v_1, \ldots, v_n $ are independent:

There is one and only one way to write v as a combination of the basis vectors.

Reason: Suppose  $ v = a_1 v_1 + \cdots + a_n v_n $ and also  $ v = b_1 v_1 + \cdots + b_n v_n $. By subtraction  $ (a_1 - b_1) v_1 + \cdots + (a_n - b_n) v_n $ is the zero vector. From the independence of the  $ v $'s, each  $ a_i - b_i = 0 $. Hence  $ a_i = b_i $, and there are not two ways to produce  $ v $.

Example 6 The columns of  $ I = \begin{bmatrix} 1 & 0 \\ 0 & 1 \end{bmatrix} $ produce the “standard basis” for  $ \mathbf{R}^2 $.