(a) If Ax = b has two solutions  $ x_{1} $ and  $ x_{2} $, find two solutions to Ax = 0.

(b) Then find another solution to Ax = 0 and another solution to Ax = b.

13 Explain why these are all false:

(a) The complete solution is any linear combination of  $ x_{p} $ and  $ x_{n} $

(b) A system Ax = b has at most one particular solution.

(c) The solution  $ x_p $ with all free variables zero is the shortest solution (minimum length  $ \|x\| $). Find a 2 by 2 counterexample.

(d) If A is invertible there is no solution  $ x_{n} $ in the nullspace.

Suppose column 5 of $U$ has no pivot. Then $x_{5}$ is a ___ variable. The zero vector (is) (is not) the only solution to $Ax = 0$. If $Ax = b$ has a solution, then it has ___ solutions.

15 Suppose row 3 of $U$ has no pivot. Then that row is ___. The equation $Ux = c$ is only solvable provided ___. The equation $Ax = b$ (is) (is not) (might not be) solvable.

Questions 16–20 are about matrices of “full rank” r = m or r = n.

16 The largest possible rank of a 3 by 5 matrix is ___. Then there is a pivot in every ___ of U and R. The solution to Ax = b (always exists) (is unique). The column space of A is ___. An example is A = ___.

17 The largest possible rank of a 6 by 4 matrix is ___. Then there is a pivot in every ___ of U and R. The solution to Ax = b (always exists) (is unique). The nullspace of A is ___. An example is A = ___.

18 Find by elimination the rank of A and also the rank of A^{T}.

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{4}}}&{{{0}}} \\{{{2}}}&{{{11}}}&{{{5}}} \\{{{-1}}}&{{{2}}}&{{{10}}}\end{bmatrix}\quad and\quad\boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{2}}} \\{{{1}}}&{{{1}}}&{{{q}}}\end{bmatrix}\quad(rank depends on q). $$ 

19 Find the rank of A and also of  $ A^{T}A $ and also of  $ AA^{T} $:

 $$ A=\begin{bmatrix}{{{1}}}&{{{1}}}&{{{5}}} \\{{{1}}}&{{{0}}}&{{{1}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{2}}}&{{{0}}} \\{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}}\end{bmatrix}. $$ 

20 Reduce A to its echelon form U. Then find a triangular L so that A = LU.

 $$ A=\begin{bmatrix}{{{3}}}&{{{4}}}&{{{1}}}&{{{0}}} \\{{{6}}}&{{{5}}}&{{{2}}}&{{{1}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{1}}}&{{{0}}} \\{{{2}}}&{{{2}}}&{{{0}}}&{{{3}}} \\{{{0}}}&{{{6}}}&{{{5}}}&{{{4}}}\end{bmatrix}. $$ 