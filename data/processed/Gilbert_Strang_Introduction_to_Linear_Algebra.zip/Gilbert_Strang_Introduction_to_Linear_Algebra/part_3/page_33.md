3.4 B Start with three independent vectors  $ w_1, w_2, w_3 $. Take combinations of those vectors to produce  $ v_1, v_2, v_3 $. Write the combinations in matrix form as  $ V = WB $:

 $$ \begin{array}{l}{{{\boldsymbol{v}_{1}=\boldsymbol{w}_{1}+\quad\boldsymbol{w}_{2}}}} \\{{{\boldsymbol{v}_{2}=\boldsymbol{w}_{1}+2\boldsymbol{w}_{2}+\quad\boldsymbol{w}_{3}}}} \\{{{\boldsymbol{v}_{3}=\quad\boldsymbol{w}_{2}+c\boldsymbol{w}_{3}}}}\end{array}\quad\mathrm{w h i c h~i s}\quad\begin{bmatrix}{{{\boldsymbol{v}_{1}}}}&{{{\boldsymbol{v}_{2}}}}&{{{\boldsymbol{v}_{3}}}}\end{bmatrix}=\begin{bmatrix} \\{{{\boldsymbol{w}_{1}}}}&{{{\boldsymbol{w}_{2}}}}&{{{\boldsymbol{w}_{3}}}}\end{bmatrix}\begin{bmatrix} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{1}}}&{{{c}}}\end{bmatrix} $$ 

What is the test on $B$ to see if $V = WB$ has independent columns? If $c \neq 1$ show that $v_1, v_2, v_3$ are linearly independent. If $c = 1$ show that the $v$'s are linearly dependent.

Solution The test on V for independence of its columns was in our first definition: The nullspace of V must contain only the zero vector. Then  $ \boldsymbol{x} = (0,0,0) $ is the only combination of the columns that gives  $ V\boldsymbol{x} = zero $ vector.

If $c = 1$ in our problem, we can see dependence in two ways. First, $v_1 + v_3$ will be the same as $v_2$. (If you add $w_1 + w_2$ to $w_2 + w_3$ you get $w_1 + 2w_2 + w_3$ which is $v_2$). In other words $v_1 - v_2 + v_3 = 0$—which says that the $v$'s are not independent.

The other way is to look at the nullspace of $B$. If $c = 1$, the vector $\boldsymbol{x} = (1, -1, 1)$ is in that nullspace, and $B\boldsymbol{x} = \boldsymbol{0}$. Then certainly $WB\boldsymbol{x} = \boldsymbol{0}$ which is the same as $V\boldsymbol{x} = \boldsymbol{0}$. So the $v$'s are dependent. This specific $\boldsymbol{x} = (1, -1, 1)$ from the nullspace tells us again that $\boldsymbol{v}_{1} - \boldsymbol{v}_{2} + \boldsymbol{v}_{3} = \boldsymbol{0}$.

Now suppose  $ c \neq 1 $. Then the matrix  $ B $ is invertible. So if  $ x $ is any nonzero vector we know that  $ Bx $ is nonzero. Since the  $ w $'s are given as independent, we further know that  $ WBx $ is nonzero. Since  $ V = WB $, this says that  $ x $ is not in the nullspace of  $ V $. In other words  $ v_1, v_2, v_3 $ are independent.

The general rule is “independent v’s from independent w’s when B is invertible” And if these vectors are in  $ R^{3} $, they are not only independent—they are a basis for  $ R^{3} $ “Basis of v’s from basis of w’s when the change of basis matrix B is invertible.”

3.4 C (Important example) Suppose  $ v_1, \ldots, v_n $ is a basis for  $ R^n $ and the  $ n $ by  $ n $ matrix  $ A $ is invertible. Show that  $ Av_1, \ldots, Av_n $ is also a basis for  $ R^n $.

Solution In matrix language: Put the basis vectors  $ v_1, \ldots, v_n $ in the columns of an invertible(!) matrix  $ V $. Then  $ Av_1, \ldots, Av_n $ are the columns of  $ AV $. Since  $ A $ is invertible, so is  $ AV $ and its columns give a basis.

In vector language: Suppose  $ c_1Av_1 + \cdots + c_nAv_n = 0 $. This is  $ Av = 0 $ with  $ v = c_1v_1 + \cdots + c_nv_n $. Multiply by  $ A^{-1} $ to reach  $ v = 0 $. By linear independence of the  $ v $'s, all  $ c_i = 0 $. This shows that the  $ Av $'s are independent.

To show that the  $ Av's\ span\ R^n $, solve  $ c_1Av_1 + \cdots + c_nAv_n = b $ which is the same as  $ c_1v_1 + \cdots + c_nv_n = A^{-1}b $. Since the  $ v' $s are a basis, this must be solvable.