### 3.4 Independence, Basis and Dimension

(1) Independent columns of A: The only solution to Ax = 0 is x = 0. The nullspace is Z.

2 Independent vectors: The only zero combination  $ c_1v_1 + \cdots + c_kv_k = 0 $ has all  $ c's = 0 $.

3 A matrix with m < n has dependent columns: At least n - m free variables / special solutions.

4 The vectors  $ v_1, \ldots, v_k $ span the space S if S = all combinations of the v's.

5 The vectors  $ v_1, \ldots, v_k $ are a basis for S if they are independent and they span S.

6 The dimension of a space S is the number of vectors in every basis for S.

7 If A is 4 by 4 and invertible, its columns are a basis for  $ \mathbb{R}^4 $. The dimension of  $ \mathbb{R}^4 $ is 4.

This important section is about the true size of a subspace. There are n columns in an m by n matrix. But the true “dimension” of the column space is not necessarily n. The dimension is measured by counting independent columns—and we have to say what that means. We will see that the true dimension of the column space is the rank r.

The idea of independence applies to any vectors  $ v_1, \ldots, v_n $ in any vector space. Most of this section concentrates on the subspaces that we know and use—especially the column space and the nullspace of  $ A $. In the last part we also study “vectors” that are not column vectors. They can be matrices and functions; they can be linearly independent (or dependent). First come the key examples using column vectors.

The goal is to understand a basis: independent vectors that “span the space”.

Every vector in the space is a unique combination of the basis vectors.

We are at the heart of our subject, and we cannot go on without a basis. The four essential ideas in this section (with first hints at their meaning) are:

1. Independent vectors

(no extra vectors)

2. Spanning a space

(enough vectors to produce the rest)

3. Basis for a space

(not too many or too few)

4. Dimension of a space

(the number of vectors in a basis)



## Linear Independence

Our first definition of independence is not so conventional, but you are ready for it.

DEFINITION The columns of A are linearly independent when the only solution to Ax = 0 is x = 0. No other combination Ax of the columns gives the zero vector.