 $ Rx = d $ shows that the particular solution with free variables = 0 is  $ x_p = (7, 0, -3, 0) $.

 $$ \left[\begin{array}{c c c c c}{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{2}}}&{{{8}}}&{{{-6}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]\longrightarrow\left[\begin{array}{c c c c c}{{{1}}}&{{{2}}}&{{{1}}}&{{{0}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}}&{{{-3}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]\longrightarrow\left[\begin{array}{c c c c c}{{{1}}}&{{{2}}}&{{{0}}}&{{{-4}}}&{{{7}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}}&{{{-3}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]. $$ 

For the nullspace part  $ x_n $ with  $ b = 0 $, set the free variables  $ x_2 $,  $ x_4 $ to 1, 0 and also 0, 1:

Special solutions

 $$ s_{1}=\left(-2,\ 1,\ 0\right)\ \mathbf{a}\mathbf{a}\mathbf{d}\ s_{2}=\left(4,\ 0\mathbf{,}4,\ 1\right) $$ 

Then the complete solution to Ax = b (and Rx = d) is  $ x_{complete} = xp + c_1s_1 + c_2s_2 $.

The rows of A produced the zero row from 2(row 1)+(row 2)-(row 3) = (0,0,0,0). Thus  $ \boldsymbol{y} = (2,1,-1) $. The same combination for  $ \boldsymbol{b} = (4,2,10) $ gives  $ 2(4)+(2)-(0)=0 $.

If a combination of the rows (on the left side) gives the zero row, then the same combination must give zero on the right side. Of course! Otherwise no solution.

Later we will say this again in different words: If every column of $A$ is perpendicular to $\boldsymbol{y} = (21, -1)$, then any combination $b$ of those columns must also be perpendicular to $\boldsymbol{y}$. Otherwise $b$ is not in the column space and $A\boldsymbol{x} = \boldsymbol{b}$ is not solvable.

And again: If y is in the nullspace of  $ A^{T} $ then y must be perpendicular to every b in the column space of A. Just looking ahead...

### Problem Set 3.3

1 (Recommended) Execute the six steps of Worked Example 3.3 A to describe the column space and nullspace of A and the complete solution to Ax = b:

 $$ \boldsymbol{A}=\left[\begin{array}{cccc}{{{2}}}&{{{4}}}&{{{6}}}&{{{4}}} \\{{{2}}}&{{{5}}}&{{{7}}}&{{{6}}} \\{{{2}}}&{{{3}}}&{{{5}}}&{{{2}}}\end{array}\right]\qquad\boldsymbol{b}=\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{4}}} \\{{{3}}} \\{{{5}}}\end{array}\right] $$ 

2 Carry out the same six steps for this matrix A with rank one. You will find two conditions on $b_{1}, b_{2}, b_{3}$ for $Ax = b$ to be solvable. Together these two conditions put $b$ into the ___ space (two planes give a line):

 $$ \boldsymbol{A}=\left[\begin{array}{l}{{{1}}} \\{{{3}}} \\{{{2}}}\end{array}\right]\quad\left[\begin{array}{lll}{{{2}}}&{{{1}}}&{{{3}}}\end{array}\right]=\left[\begin{array}{lll}{{{2}}}&{{{1}}}&{{{3}}} \\{{{6}}}&{{{3}}}&{{{9}}} \\{{{4}}}&{{{2}}}&{{{6}}}\end{array}\right]\qquad\boldsymbol{b}=\left[\begin{array}{l}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{array}\right]=\left[\begin{array}{l}{{{10}}} \\{{{30}}} \\{{{20}}}\end{array}\right] $$ 

Questions 3–15 are about the solution of Ax = b. Follow the steps in the text to  $ x_{p} $ and  $ x_{n} $. Start from the augmented matrix with last column b.

3 Write the complete solution as  $ x_{p} $ plus any multiple of s in the nullspace:

 $$ \begin{aligned}x+3y+3z&=1\\2x+6y+9z&=5\\-x-3y+3z&=5.\end{aligned} $$ 