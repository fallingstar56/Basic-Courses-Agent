39 Fill out these matrices so that they have rank 1:

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{4}}} \\{{{2}}} \\{{{4}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{9}}} \\{{{1}}} \\{{{2}}}&{{{6}}}&{{{-3}}}\end{bmatrix}\quad and\quad M=\begin{bmatrix}{{{a}}}&{{{b}}} \\{{{c}}}\end{bmatrix}. $$ 

If A is an m by n matrix with r = 1, its columns are multiples of one column and its rows are multiples of one row. The column space is a ___ in  $ \mathbf{R}^m $. The nullspace is a ___ in  $ \mathbf{R}^n $. The nullspace matrix N has shape ___.

41 Choose vectors u and v so that  $ A = uv^{\mathrm{T}} = $ column times row:

 $$ A=\begin{bmatrix}{{{3}}}&{{{6}}}&{{{6}}} \\{{{1}}}&{{{2}}}&{{{2}}} \\{{{4}}}&{{{8}}}&{{{8}}}\end{bmatrix}\quad and\quad A=\begin{bmatrix}{{{2}}}&{{{2}}}&{{{6}}}&{{{4}}} \\{{{-1}}}&{{{-1}}}&{{{-3}}}&{{{-2}}}\end{bmatrix}. $$ 

 $ A = \boldsymbol{u} \boldsymbol{v}^{\mathrm{T}} $ is the natural form for every matrix that has rank r = 1.

42 If A is a rank one matrix, the second row of R is ___. Do an example.

Problems 43–45 are about r by r invertible matrices inside A.

43 If A has rank r, then it has an r by r submatrix S that is invertible. Remove m - r rows and n - r columns to find an invertible submatrix S inside A, B, and C. You could keep the pivot rows and pivot columns:

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{1}}}&{{{2}}}&{{{4}}}\end{bmatrix}\qquad\boldsymbol{B}=\begin{bmatrix}{{{1}}}&{{{2}}}&{{{3}}} \\{{{2}}}&{{{4}}}&{{{6}}}\end{bmatrix}\qquad\boldsymbol{C}=\begin{bmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{bmatrix}. $$ 

44 Suppose P contains only the r pivot columns of an m by n matrix. Explain why this m by r submatrix P has rank r.

45 Transpose P in Problem 44. Find the r pivot columns of  $ P^{T} $ (which is r by m). Transposing back, this produces an r by r invertible submatrix S inside P and A:

For  $ A = \begin{bmatrix} 1 & 2 & 3 \\ 2 & 4 & 6 \\ 2 & 4 & 7 \end{bmatrix} $ find  $ P(3 \text{ by } 2) $ and then the invertible  $ S(2 \text{ by } 2) $.

Problems 46–51 show that rank(AB) is not greater than rank(A) or rank(B).

46 Find the ranks of AB and AC (rank one matrix times rank one matrix):

 $$ A=\begin{bmatrix}{{{1}}}&{{{2}}} \\{{{2}}}&{{{4}}}\end{bmatrix}\quad and\quad B=\begin{bmatrix}{{{2}}}&{{{1}}}&{{{4}}} \\{{{3}}}&{{{1.5}}}&{{{6}}}\end{bmatrix}\quad and\quad C=\begin{bmatrix}{{{1}}}&{{{b}}} \\{{{c}}}&{{{bc}}}\end{bmatrix}. $$ 

47 The rank one matrix  $ uv^{T} $ times the rank one matrix  $ wz^{T} $ is  $ uz^{T} $ times the number ___. This product  $ uv^{T}wz^{T} $ also has rank one unless ___ = 0.