This type of matrix has more columns than rows—it is short and wide. The columns are certainly dependent if n > m, because Ax = 0 has a nonzero solution.

The columns might be dependent or might be independent if  $ n \leq m $. Elimination will reveal the  $ r $ pivot columns. It is those  $ r $ pivot columns that are independent.

Note Another way to describe linear dependence is this: “One vector is a combination of the other vectors.” That sounds clear. Why don’t we say this from the start? Our definition was longer: “Some combination gives the zero vector, other than the trivial combination with every x = 0.” We must rule out the easy way to get the zero vector. That trivial combination of zeros gives every author a headache. If one vector is a combination of the others, that vector has coefficient x = 1.

The point is, our definition doesn’t pick out one particular vector as guilty. All columns of A are treated the same. We look at Ax = 0, and it has a nonzero solution or it hasn’t. In the end that is better than asking if the last column (or the first, or a column in the middle) is a combination of the others.

## Vectors that Span a Subspace

The first subspace in this book was the column space. Starting with columns  $ v_1, \ldots, v_n $, the subspace was filled out by including all combinations  $ x_1 v_1 + \cdots + x_n v_n $. The column space consists of all combinations  $ A x $ of the columns. We now introduce the single word “span” to describe this: The column space is spanned by the columns.

DEFINITION A set of vectors spans a space if their linear combinations fill the space.

The columns of a matrix span its column space. They might be dependent.

Example 2  $ v_1 = \begin{bmatrix} 1 \\ 0 \end{bmatrix} $ and  $ v_2 = \begin{bmatrix} 0 \\ 1 \end{bmatrix} $ span the full two-dimensional space  $ \mathbf{R}^2 $.

Example 3  $ v_{1}=\begin{bmatrix}1\\ 0\end{bmatrix},v_{2}=\begin{bmatrix}0\\ 1\end{bmatrix},v_{3}=\begin{bmatrix}4\\ 7\end{bmatrix} $ also span the full space  $ \mathbf{R}^{2} $.

Example 4  $ w_1 = \begin{bmatrix} 1 \\ 1 \end{bmatrix} $ and  $ w_2 = \begin{bmatrix} -1 \\ -1 \end{bmatrix} $ only span a line in  $ \mathbb{R}^2 $. So does  $ w_1 $ by itself.

Think of two vectors coming out from  $ (0,0,0) $ in 3-dimensional space. Generally they span a plane. Your mind fills in that plane by taking linear combinations. Mathematically you know other possibilities: two vectors could span a line, three vectors could span all of  $ \mathbf{R}^{3} $, or only a plane. It is even possible that three vectors span only a line, or ten vectors span only a plane. They are certainly not independent!

The columns span the column space. Here is a new subspace—which is spanned by the rows. The combinations of the rows produce the “row space”.