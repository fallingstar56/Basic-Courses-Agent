Example 2  $ A=\begin{bmatrix}1&2&3\\ 2&4&6\end{bmatrix} $ has m=2 with n=3 and rank r=1.

The row space is the same line through  $ (1,2,3) $. The nullspace must be the same plane  $ x_{1}+2x_{2}+3x_{3}=0 $. The line and plane dimensions still add to  $ 1+2=3 $.

All columns are multiples of the first column  $ (1,2) $. Twice the first row minus the second row is the zero row. Therefore  $ A^{\mathrm{T}}y = 0 $ has the solution  $ \boldsymbol{y} = (2, -1) $. The column space and left nullspace are perpendicular lines in  $ R^2 $. Dimensions  $ 1 + 1 = 2 $.

 $$ \text{Column space}=line through\begin{bmatrix}1\\ 2\end{bmatrix}\qquad Left nullspace=line through\begin{bmatrix}2\\ -1\end{bmatrix}. $$ 

If A has three equal rows, its rank is ___. What are two of the y's in its left nullspace?

The y's in the left nullspace combine the rows to give the zero row.

Example 3 You have nearly finished three chapters with made-up equations, and this can't continue forever. Here is a better example of five equations (one for every edge in Figure 3.6). The five equations have four unknowns (one for every node). The matrix in Ax = b is an incidence matrix. This matrix A has 1 and -1 on every row.

Differences Ax = b across edges 1, 2, 3, 4, 5 between nodes 1, 2, 3, 4

 $$ \begin{aligned}-x_{1}\quad&+x_{2}\quad&=b_{1}\\-x_{1}\quad&+x_{3}\quad&=b_{2}\\-x_{2}\quad&+x_{3}\quad&=b_{3}\\-x_{2}\quad&+x_{4}\quad&=b_{4}\\-x_{3}\quad&+x_{4}\quad&=b_{5}\end{aligned} $$ 

If you understand the four fundamental subspaces for this matrix (the column spaces and the nullspaces for A and  $ A^{T} $) you have captured the central ideas of linear algebra.

<div style="text-align: center;"><img src="imgs/img_in_image_box_209_812_497_976.jpg" alt="Image" width="27%" /></div>


 $$ \boldsymbol{A}=\left[\begin{array}{rrr}{{{-1}}}&{{{1}}} \\{{{-1}}}&{{{1}}} \\{{{-1}}}&{{{1}}} \\{{{-1}}}&{{{1}}} \\{{{-1}}}&{{{1}}} \\\end{array}\right]\quad\begin{array}{r}{{{\boldsymbol{e d g e s}}}} \\{{{1}}} \\{{{2}}} \\{{{3}}} \\{{{4}}} \\{{{5}}} \\\end{array} $$ 

<div style="text-align: center;">Figure 3.6: A “graph” with 5 edges and 4 nodes. A is its 5 by 4 incidence matrix.</div>


The nullspace  $ N(A) $ To find the nullspace we set  $ b = 0 $. Then the first equation says  $ x_1 = x_2 $. The second equation is  $ x_3 = x_1 $. Equation 4 is  $ x_2 = x_4 $. All four unknowns  $ x_1, x_2, x_3, x_4 $ have the same value  $ c $. The vectors  $ \boldsymbol{x} = (c, c, c, c) $ fill the nullspace of  $ A $.

That nullspace is a line in  $ \mathbf{R}^4 $. The special solution  $ \boldsymbol{x} = (1,1,1,1) $ is a basis for  $ \mathbf{N}(A) $. The dimension of  $ \mathbf{N}(A) $ is 1 (one vector in the basis). The rank of A must be 3, since  $ n - r = 4 - 3 = 1 $. We now know the dimensions of all four subspaces.