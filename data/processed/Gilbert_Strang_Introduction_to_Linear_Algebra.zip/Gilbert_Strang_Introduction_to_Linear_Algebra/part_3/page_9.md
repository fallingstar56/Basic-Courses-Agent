### 3.3 The Complete Solution to Ax = b

(1) Complete solution to Ax = b:  $ x = (\text{one particular solution } x_p) + (\text{any } x_n \text{ in the nullspace}) $.

2) Elimination on  $ [A \quad b] $ leads to  $ [R \quad d] $. Then Ax = b is equivalent to  $ Rx = d $.

3) Ax = b and  $ Rx = d $ are solvable only when all zero rows of R have zeros in d.

4) When  $ Rx = d $ is solvable, one very particular solution  $ x_p $ has all free variables equal to zero.

5) A has full column rank r = n when its nullspace  $ N(A) = \text{zero vector} $: no free variables.

6) A has full row rank r = m when its column space  $ C(A) $ is  $ \mathbb{R}^m $: Ax = b is always solvable.

7) The four cases are r = m = n (A is invertible) and r = m < n (every Ax = b is solvable) and r = n < m (Ax = b has 1 or 0 solutions) and r < m, r < n (0 or  $ \infty $ solutions).

The last section totally solved Ax = 0. Elimination converted the problem to  $ Rx = 0 $. The free variables were given special values (one and zero). Then the pivot variables were found by back substitution. We paid no attention to the right side b because it stayed at zero. The solution x was in the nullspace of A.

Now $b$ is not zero. Row operations on the left side must act also on the right side. $Ax = b$ is reduced to a simpler system $Rx = d$ with the same solutions. One way to organize that is to add $b$ as an extra column of the matrix. I will “augment” $A$ with the right side $(b_1, b_2, b_3) = (1, 6, 7)$ to produce the augmented matrix $[A \quad b]$:

 $$ \begin{bmatrix}{{{1}}}&{{{3}}}&{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}} \\{{{1}}}&{{{3}}}&{{{1}}}&{{{6}}}\end{bmatrix}\begin{vmatrix}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}} \\{{{x_{4}}}}\end{vmatrix}=\begin{bmatrix}{{{1}}} \\{{{6}}} \\{{{7}}}\end{bmatrix}\quad has the\quad\begin{bmatrix}{{{1}}}&{{{3}}}&{{{0}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}}&{{{6}}} \\{{{1}}}&{{{3}}}&{{{1}}}&{{{6}}}&{{{7}}}\end{bmatrix}=\begin{bmatrix}{{{A}}}&{{{b}}}\end{bmatrix}. $$ 

When we apply the usual elimination steps to A, reaching R, we also apply them to b.

In this example we subtract row 1 from row 3. Then we subtract row 2 from row 3. This produces a row of zeros in R, and it changes b to a new right side  $ d = (1, 6, 0) $:

 $$ \begin{bmatrix}{{{1}}}&{{{3}}}&{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{x_{1}}}} \\{{{x_{2}}}} \\{{{x_{3}}}} \\{{{x_{4}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}} \\{{{6}}} \\{{{0}}}\end{bmatrix}\quad has the\quad\begin{bmatrix}{{{1}}}&{{{3}}}&{{{0}}}&{{{2}}}&{{{1}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}}&{{{6}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix}=\begin{bmatrix}{{{R}}}&{{{d}}}\end{bmatrix}. $$ 

That very last zero is crucial. The third equation has become 0 = 0. So the equations can be solved. In the original matrix A, the first row plus the second row equals the third row. If the equations are consistent, this must be true on the right side of the equations also! The all-important property of the right side b was  $ 1 + 6 = 7 $. That led to 0 = 0.