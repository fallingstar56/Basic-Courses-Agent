We didn’t mention the nullspace in Chapter 2, because  $ A $ was invertible and  $ N(\mathbf{A}) $ contained only the zero vector. Reduction went from  $ [A\mathbf{b}] $ to  $ [I\mathbf{A}^{-1}\mathbf{b}] $. The matrix  $ A $ was reduced all the way to  $ I $. Then  $ Ax = b $ became  $ \mathbf{x} = A^{-1}\mathbf{b} $ which is  $ d $. This is a special case here, but square invertible matrices are the ones we see most often in practice. So they got their own chapter at the start of the book.

For small examples we can reduce  $ [A\ b] $ to  $ [R\ d] $. For a large matrix, MATLAB does it better. One particular solution (not necessarily ours) is  $ \boldsymbol{x} = A\backslash\boldsymbol{b} $ from backslash. Here is an example with full column rank. Both columns have pivots.

Example 1 Find the condition on  $ (1/b_{2}, b_{3}) $ for  $ Ax = b $ to be solvable, if

 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{2}}} \\{{{-2}}}&{{{-3}}}\end{bmatrix}\text{and}\quad\boldsymbol{b}=\begin{bmatrix}{{{b_{1}}}} \\{{{b_{2}}}} \\{{{b_{3}}}}\end{bmatrix}. $$ 

This condition puts $b$ in the column space of $A$. Find the complete $\boldsymbol{x} = \boldsymbol{x}_p + \boldsymbol{x}_n$.

Solution Use the augmented matrix, with its extra column $b$. Subtract row 1 of $\left[\begin{array}{cc}A & b\end{array}\right]$ from row 2. Then add 2 times row 1 to row 3 to reach $\left[\begin{array}{cc}R & d\end{array}\right]:$

 $$ \begin{bmatrix}1&1&b_{1}\\1&2&b_{2}\\-2&-3&b_{3}\end{bmatrix}\rightarrow\begin{bmatrix}1&1&b_{1}\\0&1&b_{2}-b_{1}\\0&-1&b_{3}+2b_{1}\end{bmatrix}\rightarrow\begin{bmatrix}1&0&2b_{1}-b_{2}\\0&1&b_{2}-b_{1}\\0&0&b_{3}+b_{1}+b_{2}\end{bmatrix}. $$ 

The last equation is 0 = 0 provided  $ b_3 + b_1 + b_2 = 0 $. This is the condition to put b in the column space. Then  $ Ax = b $ will be solvable. The rows of A add to the zero row. So for consistency (these are equations!) the entries of b must also add to zero.

This example has no free variables since $n-r=2-2$. Therefore no special solutions. The nullspace solution is $\boldsymbol{x}_{n}=\mathbf{0}$. The particular solution to $Ax=\boldsymbol{b}$ and $Rx=\boldsymbol{d}$ is at the top of the final column $d$:

Only solution to

 $$ \boldsymbol{A}\boldsymbol{x}=\boldsymbol{b}\qquad\boldsymbol{x}=\boldsymbol{x}_{p}+\boldsymbol{x}_{n}=\begin{bmatrix}2b_{1}-b_{2}\\ b_{2}-b_{1}\end{bmatrix}+\begin{bmatrix}0\\ 0\end{bmatrix}. $$ 

If  $ b_{3} + b_{1} + b_{2} $ is not zero, there is no solution to Ax = b ( $ x_{p} $ and x don't exist).

This example is typical of an extremely important case: A has full column rank. Every column has a pivot. The rank is r = n. The matrix is tall and thin (m ≥ n). Row reduction puts I at the top, when A is reduced to R with rank n:

Full column rank

 $$ R=\begin{bmatrix}I\\ 0\end{bmatrix}=\begin{bmatrix}n by n identity matrix\\ m-n rows of zeros\end{bmatrix} $$ 

There are no free columns or free variables. The nullspace is  $ \mathbf{Z} = \{zero\ vector\} $.

We will collect together the different ways of recognizing this type of matrix.