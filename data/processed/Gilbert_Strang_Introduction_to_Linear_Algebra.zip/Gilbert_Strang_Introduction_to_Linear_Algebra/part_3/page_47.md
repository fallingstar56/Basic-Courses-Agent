## Rank One Matrices (Review)

Suppose every row is a multiple of the first row. Here is a typical example:

 $$ \begin{bmatrix} {2}&{3}&{7}&{8} \\ {2a}&{3a}&{7a}&{8a} \\ {2b}&{3b}&{7b}&{8b} \end{bmatrix}=\begin{bmatrix} {1} \\ {a} \\ {b} \end{bmatrix} \begin{bmatrix} {2}&{3}&{7}&{8} \end{bmatrix}=u\mathbf{v}^{\mathrm{T}} $$ 

On the left is a matrix with three rows. But its row space only has dimension = 1. The row vector  $ \boldsymbol{v}^{\mathrm{T}} = \begin{bmatrix} 2 & 3 & 7 & 8 \end{bmatrix} $ tells us a basis for that row space. The row rank is 1.

Now look at the columns. “The column rank equals the row rank which is 1.” All columns of the matrix must be multiples of one column. Do you see that this key rule of linear algebra is true? The column vector  $ \boldsymbol{u} = (1, a, b) $ is multiplied by 2, 3, 7, 8. That nonzero vector  $ \boldsymbol{u} $ is a basis for the column space. The column rank is also 1.

Every rank one matrix is one column times one row

 $$ \boldsymbol{A}=u\boldsymbol{v}^{\mathrm{T}} $$ 

## Rank Two Matrices = Rank One plus Rank One

Here is a matrix  $ A $ of rank  $ r = 2 $. We can't see  $ r $ immediately from  $ A $. So we reduce the matrix by row operations to  $ R = \text{rref}(A) $. Some elimination matrix  $ E $ simplifies  $ A $ to  $ EA = R $. Then the inverse matrix  $ C = E^{-1} $ connects  $ R $ back to  $ A = CR $.

You know the main point already: R has the same row space as A.

Rank two

 $$ \boldsymbol{A}=\left[\begin{array}{lll}{{{1}}}&{{{0}}}&{{{3}}} \\{{{1}}}&{{{1}}}&{{{7}}} \\{{{4}}}&{{{2}}}&{{{20}}}\end{array}\right]=\left[\begin{array}{lll}{{{1}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{1}}}&{{{0}}} \\{{{4}}}&{{{2}}}&{{{1}}}\end{array}\right]\left[\begin{array}{lll}{{{1}}}&{{{0}}}&{{{3}}} \\{{{0}}}&{{{1}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right]=\boldsymbol{C}\boldsymbol{R}. $$ 

The row space of $R$ clearly has two basis vectors $\boldsymbol{v}_1^\mathrm{T} = \begin{bmatrix} 1 & 0 & 3 \end{bmatrix}$ and $\boldsymbol{v}_2^\mathrm{T} = \begin{bmatrix} 0 & 1 & 4 \end{bmatrix}$. So the (same!) row space of $A$ also has this basis: row rank = 2. Multiplying $C$ times $R$ says that row 3 of $A$ is $4\boldsymbol{v}_1^\mathrm{T} + 2\boldsymbol{v}_2^\mathrm{T}$.

Now look at columns. The pivot columns of $R$ are clearly $(1,0,0)$ and $(0,1,0)$. Then the pivot columns of $A$ are also in columns 1 and 2: $\mathbf{u}_{1} = (1,1,4)$ and $\mathbf{u}_{2} = (0,1,2)$. Notice that $C$ has those same first two columns! That was guaranteed since multiplying by two columns of the identity matrix (in $R$) won't change the pivot columns $\mathbf{u}_{1}$ and $\mathbf{u}_{2}$.

When you put in letters for the columns and rows, you see rank 2 = rank 1 + rank 1.

Matrix A Rank two

 $$ \begin{aligned}&A=\begin{bmatrix}\\ &u_{1}&u_{2}&u_{3}\\ &\end{bmatrix}\begin{bmatrix}\\ &v_{1}^{\mathrm{T}}\\&v_{2}^{\mathrm{T}}\\&zero row\\ &\end{bmatrix}=u_{1}v_{1}^{\mathrm{T}}+u_{2}v_{2}^{\mathrm{T}}=(\mathrm{rank}1)+(\mathrm{rank}1).\\ \end{aligned} $$ 

Did you see that last step? I multiplied the matrices using columns times rows. That was perfect for this problem. Every rank r matrix is a sum of r rank one matrices: Pivot columns of A times nonzero rows of R. The row  $ [0\ 0\ 0] $ simply disappeared.

The pivot columns  $ u_{1} $ and  $ u_{2} $ are a basis for the column space, which you knew.