We find  $ x_p $ and  $ x_n $ by elimination on  $ [A\ b] $. Subtract row 1 from row 2 and then subtract row 2 from row 1:

 $$ \begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{3}}} \\{{{1}}}&{{{2}}}&{{{-1}}}&{{{4}}}\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{1}}}&{{{1}}}&{{{3}}} \\{{{0}}}&{{{1}}}&{{{-2}}}&{{{1}}}\end{bmatrix}\rightarrow\begin{bmatrix}{{{1}}}&{{{0}}}&{{{3}}}&{{{2}}} \\{{{0}}}&{{{1}}}&{{{-2}}}&{{{1}}}\end{bmatrix}=\left[\begin{array}{l l}{{{R}}}&{{{d}}}\end{array}\right]. $$ 

The particular solution has free variable x3 = 0. The special solution has x3 = 1:

 $ x_{\text{particular}} $ comes directly from d on the right side:  $ x_p = (2, 1, 0) $

 $ x_{\text{special}} $ comes from the third column (free column) of  $ R\colon s = (-3, 2, 1) $

It is wise to check that  $ x_p $ and  $ s $ satisfy the original equations  $ Ax_p = b $ and  $ As = 0 $:

 $$ \begin{array}{r l r l r l r l}{{2+1}}&{=}&{{3}}&{}&{}&{{-3+2+1}}&{=}&{{0}}\\ {{2+2}}&{=}&{{4}}&{}&{}&{{-3+4-1}}&{=}&{{0}}\end{array} $$ 

The nullspace solution  $ x_n $ is any multiple of  $ s $. It moves along the line of solutions, starting at  $ x_{\text{particular}} $. Please notice again how to write the answer:

Complete solution

 $$ \boldsymbol{x}=\boldsymbol{x}_{p}+\boldsymbol{x}_{n}=\begin{bmatrix}2\\ 1\\ 0\end{bmatrix}+x_{3}\begin{bmatrix}-3\\ 2\\ 1\end{bmatrix}. $$ 

This line of solutions is drawn in Figure 3.3. Any point on the line could have been chosen as the particular solution. We chose the point with  $ x_{3}=0 $.

The particular solution is not multiplied by an arbitrary constant! The special solution needs that constant, and you understand why—to produce all  $ x_{n} $ in the nullspace.

Now we summarize this short wide case of full row rank. If m < n the equation  $ Ax = b $ is underdetermined (many solutions).

Every matrix A with full row rank  $ (r = m) $ has all these properties:

1. All rows have pivots, and R has no zero rows.

2. Ax = b has a solution for every right side b.

3. The column space is the whole space R $ ^{m} $

4. There are n - r = n - m special solutions in the nullspace of A.

In this case with m pivots, the rows are “linearly independent”. So the columns of  $ A^{T} $ are linearly independent. The nullspace of  $ A^{T} $ is the zero vector.