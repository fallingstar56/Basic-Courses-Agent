3. The nullspace of $R$ has dimension $n - r = 5 - 2$. There are $n - r = 3$ free variables. Here $x_2, x_3, x_5$ are free (no pivots in those columns). They yield the three special solutions to $Rx = 0$. Set a free variable to 1, and solve for $x_1$ and $x_4$.

 $$ \begin{array}{r}{s_{2}=\left[\begin{matrix}{-3}\\ {1}\\ {0}\\ {0}\\ {0}\\ \end{matrix}\right]\quad s_{3}=\left[\begin{matrix}{-5}\\ {0}\\ {1}\\ {0}\\ {0}\\ \end{matrix}\right]\quad s_{5}=\left[\begin{matrix}{-7}\\ {0}\\ {0}\\ {-2}\\ {1}\\ \end{matrix}\right]\quad R\boldsymbol{x}=\mathbf{0}\mathrm{~h a s~t h e~}}\\ {\boldsymbol{x}=x_{2}\boldsymbol{s}_{2}+x_{3}\boldsymbol{s}_{3}+x_{5}\boldsymbol{s}_{5}}\\ {\mathrm{T h e~n u l l s p a c e~h a s~d i m e n s i o n~3.~}}\end{array}. $$ 

Reason: There is a special solution for each free variable. With $n$ variables and $r$ pivots, that leaves $n-r$ free variables and special solutions. The special solutions are independent, because they contain the identity matrix in rows 2, 3, 5. So $N(R)$ has dimension $n-r$.

The nullspace has dimension n - r. The special solutions form a basis.

4. The nullspace of  $ R^{\mathrm{T}} $ (left nullspace of R) has dimension  $ m - r = 3 - 2 $.

Reason: The equation  $ R^{\mathrm{T}}y = 0 $ looks for combinations of the columns of  $ R^{\mathrm{T}} $ (the rows of  $ R $) that produce zero. This equation  $ R^{\mathrm{T}}y = 0 $ or  $ y^{\mathrm{T}}R = 0^{\mathrm{T}} $ is

Left nullspace Combination of rows is zero

 $$ \begin{array}{c}{{{y_{1}\left[1,\quad3,\quad5,\quad0,\quad7\right]}}} \\{{{+y_{2}\left[0,\quad0,\quad0,\quad1,\quad2\right]}}} \\{{{+y_{3}\left[0,\quad0,\quad0,\quad0,\quad0\right]}}} \\{{{\left[0,\quad0,\quad0,\quad0,\quad0\right]}}}\end{array} $$ 

The solutions  $ y_1, y_2, y_3 $ are pretty clear. We need  $ y_1 = 0 $ and  $ y_2 = 0 $. The variable  $ y_3 $ is free (it can be anything). The nullspace of  $ R^\mathrm{T} $ contains all vectors  $ y = (0, 0, y_3) $.

In all cases $R$ ends with $m - r$ zero rows. Every combination of these $m - r$ rows gives zero. These are the only combinations of the rows of $R$ that give zero, because the pivot rows are linearly independent. So $y$ in the left nullspace has $y_1 = 0, \ldots, y_r = 0$.

If A is m by n of rank r, its left nullspace has dimension m - r.

Why is this a “left nullspace”? The reason is that  $ R^{\mathrm{T}}y = 0 $ can be transposed to  $ \boldsymbol{y}^{\mathrm{T}}R = \boldsymbol{0}^{\mathrm{T}} $. Now  $ \boldsymbol{y}^{\mathrm{T}} $ is a row vector to the left of  $ R $. You see the  $ y' $s in equation (1) multiplying the rows. This subspace came fourth, and some linear algebra books omit it—but that misses the beauty of the whole subject.

In  $ R^n $ the row space and nullspace have dimensions  $ r $ and  $ n - r $ (adding to  $ n $).

In  $ R^m $ the column space and left nullspace have dimensions  $ r $ and  $ m - r $ (total  $ m $).