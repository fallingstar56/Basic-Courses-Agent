Here are the same augmented matrices for a general  $ \boldsymbol{b} = (b_1, b_2, b_3) $:

 $$ \left[\begin{array}{l l}{{{A}}}&{{{b}}}\end{array}\right]=\begin{bmatrix}{{{1}}}&{{{3}}}&{{{0}}}&{{{2}}}&{{{b_{1}}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}}&{{{b_{2}}}} \\{{{1}}}&{{{3}}}&{{{1}}}&{{{6}}}&{{{b_{3}}}}\end{bmatrix}\longrightarrow\begin{bmatrix}{{{1}}}&{{{3}}}&{{{0}}}&{{{2}}}&{{{b_{1}}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}}&{{{b_{2}}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{b_{3}-b_{1}-b_{2}}}}\end{bmatrix}=\left[\begin{array}{l l}{{{R}}}&{{{d}}}\end{array}\right] $$ 

Now we get 0 = 0 in the third equation only if b3 − b1 − b2 = 0. This is b1 + b2 = b3.

One Particular Solution  $ Ax_{p}=b $

For an easy solution  $ x_p $, choose the free variables to be zero:  $ x_2 = x_4 = 0 $. Then the two nonzero equations give the two pivot variables  $ x_1 = 1 $ and  $ x_3 = 6 $. Our particular solution to  $ Ax = b $ (and also  $ Rx = d $) is  $ x_p = (1, 0, 6, 0) $. This particular solution is my favorite: free variables = zero, pivot variables from d. The method always works.

For a solution to exist, zero rows in R must also be zero in d. Since I is in the pivot rows and pivot columns of R, the pivot variables in  $ x_{particular} $ come from d:

 $$ Rx_{p}=\left[\begin{array}{cccc}{{{1}}}&{{{3}}}&{{{0}}}&{{{2}}} \\{{{0}}}&{{{0}}}&{{{1}}}&{{{4}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\\end{array}\right]\left|\begin{array}{c}{{{1}}} \\{{{0}}} \\{{{6}}} \\{{{0}}} \\\end{array}\right|=\left[\begin{array}{c}{{{1}}} \\{{{6}}} \\{{{0}}} \\\end{array}\right]\quad\begin{array}{l}{{{Pivot variables1,6}}} \\{{{Free variables0,0}}} \\{{{Solutionx_{p}=(1,0,6,0).}}} \\\end{array} $$ 

Notice how we choose the free variables (as zero) and solve for the pivot variables. After the row reduction to R, those steps are quick. When the free variables are zero, the pivot variables for  $ x_{p} $ are already seen in the right side vector d.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$ x_{particular} $</td><td style='text-align: center; word-wrap: break-word;'>The particular solution solves</td><td style='text-align: center; word-wrap: break-word;'>$ Ax_{p} = b $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ x_{nullspace} $</td><td style='text-align: center; word-wrap: break-word;'>The  $ n - r $ special solutions solve</td><td style='text-align: center; word-wrap: break-word;'>$ Ax_{n} = 0. $</td></tr></table>

That particular solution is  $ (1,0,6,0) $. The two special (nullspace) solutions to  $ Rx = 0 $ come from the two free columns of R, by reversing signs of 3, 2, and 4. Please notice how I write the complete solution  $ x_p + x_n $ to Ax = b:

 $$ x_{p} $$ 

 $$ \boldsymbol{x}=\boldsymbol{x}_{p}+\boldsymbol{x}_{n}=\begin{bmatrix}1\\ 0\\ 6\\ 0\end{bmatrix}+x_{2}\begin{bmatrix}-3\\ 1\\ 0\\ 0\end{bmatrix}+x_{4}\begin{bmatrix}-2\\ 0\\ -4\\ 1\end{bmatrix}. $$ 

 $$ x_{n} $$ 

Question Suppose $A$ is a square invertible matrix, $m = n = r$. What are $x_p$ and $x_n$?

Answer The particular solution is the one and only solution $x_p = A^{-1}b$. There are no special solutions or free variables. $R = I$ has no zero rows. The only vector in the nullspace is $x_n = 0$. The complete solution is $x = x_p + x_n = A^{-1}b + 0$.