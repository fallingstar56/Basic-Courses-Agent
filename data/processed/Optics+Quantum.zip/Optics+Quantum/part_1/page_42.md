<div style="text-align: center;"><img src="imgs/img_in_image_box_228_174_516_449.jpg" alt="Image" width="24%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_645_186_929_495.jpg" alt="Image" width="23%" /></div>


From optical reversibility and conservation of energy, it is easy to see from the figure above, that:

 $$ \begin{aligned}&r^{2}(i_{i})+t(i_{i})t^{\prime}(i_{t})=1\\ &\\&r(i_{i})=-r^{\prime}(i_{t})\\ \end{aligned} $$ 

Stokes relations are useful to allow us find simple relations between the coefficients instead of crank through the Fresnel equations. For example: Using Stokes Relation, it is easy to see that in the Brewster angle figure on pg83 of this note, when the light on top surface is at  $ i_{B} $, the light incident on the parallel bottom surface is also at  $ i_{B} $, the Brewster angle (try to convince it yourself).

Also from stroke relation, it is easy to understand why between the reflection from the top and bottom surface, there are always  $ \frac{\lambda_{o}}{2} $ extra OPL difference (extra  $ \pi $ phase difference, the -1 between the two reflection coefficients) and I shall prove this explicitly below.

Previously, we discussed the extra  $ \frac{\lambda_{0}}{2} $ OPL difference between the