### 3. Solutions of wave equation

For constant shape propagating along certain direction with phase velocity  $ \nu : f\left[k(r - \nu t)\right] $

Special Case:

In one-dimension, the simplest form is harmonic wave:

 $$ E=E_{0}\cos(kx-\omega t) $$ 

In 3-dimension:

①plane wave:  $ E_{0}\cos(\vec{k}\bullet\vec{r}-\omega t) $

(Harmonic wave along k direction)

② spherical wave:  $ \frac{E}{r}\cos(kr-\omega t) $

 $$ \left|k\right|=\frac{2\pi}{\lambda} $$ 

 $$ \omega=2\pi\upsilon $$ 

 $$ \nu=\frac{\omega}{\left|k\right|}=\lambda\upsilon $$ 

 $$ T=\frac{1}{v} $$ 

 $$ \overline{\upsilon}=\frac{1}{\lambda} $$ 

More generally, a wave created by harmonic oscillation is generally expressed by  $ A(r)\cos[\varphi(r)-\omega t] $

 $ \varphi(r) = const \rightarrow \text{Equal phase Surface (wave front)} $

The plane and spherical waves have simple form of wave front,

(plane, sphere) and propagate with certain phase velocity  $ v = \frac{\omega}{k} $.