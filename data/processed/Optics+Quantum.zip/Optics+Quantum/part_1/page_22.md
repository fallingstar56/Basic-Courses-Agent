<div style="text-align: center;"><img src="imgs/img_in_image_box_229_168_496_379.jpg" alt="Image" width="22%" /></div>


 $ n_i > n_t $ Internal reflection

 $$ \theta_{i}<\theta_{t} $$ 

By the time  $ \theta_t $ reaches  $ 90^\circ $, there will be no transmission, all the light will be reflected, the  $ \theta_i $ when  $ \theta_t = 90^\circ $ is the critical angle of TIR:

 $$ \theta_{i}\sin\theta_{i}=n_{t}\sin n_{t} $$ 

 $$ \sin\theta_{i}=\frac{n_{t}}{n_{i}}\sin n_{t} $$ 

 $$ \theta_{_{t}}=90^{o}\rightarrow\sin\theta_{_{c}}=\frac{n_{_{t}}}{n_{_{i}}} $$ 

Application: Optical Fiber

### (2) . Prism and Dispersion

Since n is dependent on  $ \omega $, different  $ \omega $ light will have different refraction angles and can be separated in space. A prism is such a device.

Here we are going to see the ability of dispersion by a prism, and show that the dispersion power is quite limited (i.e. the prism is not a sensitive dispersion device, it is one of the simplest, however)