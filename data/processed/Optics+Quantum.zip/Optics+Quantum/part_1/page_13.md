refraction.

## 3 -1 Treatise Based on Macroscopic Observations

(1) Light travels in straight path, in homogeneous isotropic media.

Homogeneous: The media is evenly distributed, density is a constant.

Isotropic: The physical property is not directional dependent.

In inhomogeneous or anisotropic media, such as air with temperature gradient, etc., light path can be bent, which can generate phenomenon known as Mirage.

There are also cases that when light meets something that on the size of the wave length of light, deviation from straight path occurs, we are going to treat this behavior in topics of diffraction later. (Here, strictly speaking, we treat wave length of light is much smaller than the sizes in concern, or  $ \lambda \approx 0 $)

(2)Reflection and Refraction:

When light goes from one media to another, at the interface: