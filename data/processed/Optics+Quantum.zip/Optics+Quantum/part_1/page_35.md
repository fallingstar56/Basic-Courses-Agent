 $$ t_{_{p}}=\frac{E_{_{pt}}}{E_{_{pi}}}=\frac{2n_{_{i}}\cos\theta_{_{i}}}{n_{_{t}}\cos\theta_{_{i}}+n_{_{i}}\cos\theta_{_{t}}} $$ 

 $$ t_{s}=\frac{E_{S t}}{E_{S i}}=\frac{2n_{i}\cos\theta_{i}}{n_{i}\cos\theta_{i}+n_{t}\cos\theta_{t}}=\frac{2\cos\theta_{i}\sin\theta_{t}}{\sin(\theta_{i}+\theta_{t})} $$ 

 $ i_{i}, i_{t} $ are related by Snell's law.

(In the above formula, the first expression is the primary form derived using boundary conditions of Maxwell equation, the rest are different variations which can be derived from primary form using Snell's law)

There are also Irradiance ratio, and Energy ratio which are direct results from (3-7)-(3-10)

 $$ I\propto n\left|E\right|^{2}(as in equation 2-13) $$ 

Energy=I×Area∝Icosi

 $$ \frac{I_{\mathrm{Pr}}}{I_{Pi}}=I_{p}^{r}=\left|r_{p}\right|^{2},\qquad I_{s}^{r}=\left|r_{s}\right|^{2}——Reflected irradiance $$ 

 $$ I_{_{p}}^{_{t}}=\frac{n_{_{t}}}{n_{_{i}}}\Big|t_{_{p}}\Big|^{2}\quad I_{_{s}}^{_{t}}=\frac{n_{_{t}}}{n_{_{i}}}\Big|t_{_{s}}\Big|^{2}——Refracted irradiance $$ 

 $$ R_{p}=\left|r_{p}\right|^{2}\quad R_{s}=\left|r_{s}\right|^{2}——Reflected energy flow (Reflectance) $$ 

 $$ T_{_{p}}=\frac{n_{_{t}}\cos\theta_{_{t}}}{n_{_{i}}\cos\theta_{_{i}}}\Big|t_{_{p}}\Big|^{2}\quad,\quad T_{_{s}}=\frac{n_{_{t}}\cos\theta_{_{t}}}{n_{_{i}}\cos\theta_{_{i}}}\Big|t_{_{s}}\Big|^{2}\quad\text{—}\text{Refracted}\quad\text{energy}\quad\text{flow} $$ 

(Transmittance)

From conservation of energy and can be proved by Fresnel Equations:

 $$ R_{p}+T_{p}=R_{s}+T_{s}=1 $$ 