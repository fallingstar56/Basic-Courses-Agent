## Chapter 3 The propagation of Light

(Hecht, chap 4, Zhao, chap1. (1)-(3), chap3, (10))

<div style="text-align: center;"><img src="imgs/img_in_image_box_200_383_940_805.jpg" alt="Image" width="62%" /></div>


We focus on what are most relevant to geometric optics: Reflection and Refraction and Transmission in this chapter. We are not going to treat absorption and dispersion in detail here (Please refer to Hecht's 3.5 or Zhao's Vol2, P228-244 for more details on this)

We shall first give out the Phenomenal Rules (That is rules based on macroscopic observations) that govern the propagation of light through media; (Zhao’s 1.1-1.3) Then we are going to take a deeper look from microscopic point of view, such as scattering process between light and particles, to further understand the physical basis for such rules. Finally, we are going to use Maxwell equation to prove the results and derive Fresnel equations that give quantitative results on reflection and