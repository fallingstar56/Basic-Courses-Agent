approximation under weak damping; the exact frequency that makes the amplitude largest is slightly shifted from natural frequency, but the difference is negligible under weak damping).

From 2-23, it is easy to show that:

 $$ r=A e^{-i(\omega t+\phi)} $$ 

 $$  where\quad A=\frac{\frac{q_{e}E_{0}}{m}}{\sqrt{\left(\omega^{2}-\omega_{0}^{2}\right)^{2}+\gamma^{2}\omega^{2}}}\quad\quad\left(\frac{q_{e}E_{0}}{m}\rightarrow A_{0}\right) $$ 

 $$ \tan\phi=\frac{\gamma\omega}{\omega^{2}-\omega_{0}^{2}} $$ 

(d) For a oscillating dipole as given by (2-24)

 $ \Rightarrow $ Electric dipole radiation (Hecht’s 3.4.3)

If the electric dipole oscillates as:

 $$ \mu_{d}=q_{e}r=\mu_{d}^{0}e^{-i\omega t}\qquad\left(\mu_{d}^{0}=q_{e}A\right.,the\left.initial\ phase is set to0\right) $$ 

Then the E-M radiation further from the dipole can be expressed into:

 $$ E=\frac{\mu_{d}^{0}k^{2}\sin\theta}{4\pi\varepsilon_{0}}\frac{e^{i k r}e^{-i\omega t}}{r} $$ 

The derivation of this formula is a bit requiring and I shall refer you to the textbooks on E-M, such as Griffiths "Introduction to Electrodynamics", Chap.11 for derivation.

The energy flux density (Irradiance):