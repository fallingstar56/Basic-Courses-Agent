composed of P light, the deflected light then only has P component. (This means the S,P polarized light are eigenvectors of the operation of deflection by interface, we shall not go deeper than this at present)

you can prove this easily, using Fig1a, assuming the  $ E_{i\perp} $ (S light) creates P components upon deflection, and from boundary condition by Maxwell equation,  $ \vec{E}, \vec{H} $, components along  $ \vec{x} $ direction has to be continuous  $ \rightarrow $ P components of  $ \vec{E} $ has to be Zero.

This justifies of our choice of S, P to decompose any polarization.

(4). As in the book (Hecht's 4.6.1), using the boundary condition, it is straightforward to derive the reflection and refraction laws (Snell's law) for the plane wave. The previous phenomenal rules once again can be explained by using E-M theory. Moreover, the boundary condition also gives the quantitative ratio between the amplitude of the incident and deflected light: The Fresnel equations (Hecht's 4.6.2) and this will be our focus.

A more concise coordinate system, combining Fig1a, 1b into an equivalent one :