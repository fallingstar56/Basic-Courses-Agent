 $$ \frac{d i_{1}^{\prime}}{d\omega}=\frac{1}{\cos i_{1}^{\prime}}\frac{n}{\sqrt{n^{2}-\sin^{2}i_{1}}}\frac{d n}{d\omega} $$ 

 $ \frac{dn}{d\omega} $ is usually small, so the dispersion power of prism is limited.

However, we can choose angle  $ i_{1} $ to maximize the dispersion power.

 $$ \cos i_{1}^{\prime}=\pm\sqrt{1-\sin^{2}i_{1}^{\prime}}=\pm\sqrt{\left(1+\sin^{2}i_{1}\right)-n^{2}} $$ 

Choose  $ i_{1} \rightarrow 1 + \sin^{2} i_{1} = n^{2} $ will maximize the dispersion power around some spectral range.

## 3 -5 Propagation of Light from Scattering Point of View

In this part we shall understand qualitatively the propagation of light in a media. The basic idea of light propagation in a media is that the field will consist of two parts: one is the original light wave (the primary wave); another is the emissions created by the atoms/molecules of the media under the influence of the primary wave.

Recall the section in the last chapter of this note, the molecules/atoms in the light field, will oscillate with same freq. but with a phase delay with the driving field ( we shall refer to the driving field “primary wave” hence forth ), these oscillators will radiate E-M wave, and act as a secondary spherical wave source. (Note: There is difference between these secondary wavelets due to molecule/atom oscillators with those in