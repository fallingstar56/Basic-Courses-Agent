## Chapter 4 Geometric Optics

(Zhao's Chap I, 4,5,6,7,9. ; Hecht's . 5.1-5.4 ; 6.1, 6.2)

(1) Why is it called geometric?

The problems can be solved geometrically, at most by analytical geometry (such as the matrix method of ray tracing).

(2) Why it can be solved geometrically?

Treat the light as  $ \lambda \rightarrow 0 $. This means there is no concern of wave characters of light, such as interference, diffraction, etc.

We shall treat light as “rays” traveling in straight lines (the wavelength of light is negligible compared to the dimension of the problem in concern). The “ray” is a line representing the energy flow of the light wave and in isotropic media, it is same as direction of wave vector k.

(3) Why Bother?

G.O. though lacks of scientific (from theoretical point of view) significance, it is still having probably the broadest applications in technology development in optics

(4) What can we do with G.O

—— Modify the incident wavefront