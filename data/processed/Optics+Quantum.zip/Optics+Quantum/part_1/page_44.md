 $$ E_{4}=-(1-r^{2})E_{3}e^{i(\phi_{B}^{\prime}-\phi_{B})}\qquad-1\rightarrow e^{i\pi}\mathrm{\quad or\quad }e^{i(k_{0}\frac{\lambda_{0}}{2})} $$ 

Comparing with the field 3, we see that clearly the field 4 has phase difference. The difference has two parts: one is the  $ \phi_{B}^{\prime}-\phi_{B} $ which is the difference in OPL due to the extra distance covered by the bottom reflection; another is the minus sign, which can be written as an extra  $ \frac{\lambda_{0}}{2} $ in difference in OPL.

## 3 -6-4 Evanescent Wave

##### (Zhao's 10.7; Hecht's, 4.7.1)

In the previous discussion on the phase relation, we stated that below critical angle, the phase is either 0, or  $ \pi $.  $ (r, t \text{ are real, either } + \text{ or } -) $.

However at $i_i \geq i_c$ for internal reflection ($n_i \geq n_t$) $Ther_s, r_p$ becomes complex number, (it is easy to see that $at i_i > i_c$, $n^2_{t_i} - \sin^2_{i_i} < 0$, recall $\sin i_i = n_t$). The phase shift of the Reflected S, P components will range between $0 \to \pi$, as the $i_i$ increases from $i_c$ to $90^\circ$. The phase relation is given by eqn. 10.27 in Zhao's Book (pg254), which can be easily derived from (3-5) (3-6), the Fresnel equation.

At a fixed  $ i_{i}(i_{c}<i_{i}<90^{\circ}) $, the phase shift between S, P components of the reflection are different. (Fig 4.44(e) of Hecht's Book)

Also in our previous discussion of TIR, we stated that at  $ i_i > i_c $,  $ |r_s| = |r_p| = 1 $, but  $ |T_s|, |T_p| \neq 0 $. i.e. there are fields in the  $ n_t $ side, but no energy flow to