For an arbitrary form of  $ A(r), \varphi(r) $, the wave’s expression could be complicated, its phase velocity  $ \left[v = \left(\frac{\partial x}{\partial t}\right)_\varphi = \frac{-\left(\frac{\partial \varphi}{\partial t}\right)_x}{\left(\frac{\partial \varphi}{\partial x}\right)_t}\right] $ may vary over space. But as we shall see later, the complicated waveforms can be decomposed into a superposition of simple wave, such as plane waves. (Fourier Transform, Superposition Principle)

### 4. Complex Representation and Phasors

 $$ A(r)\cos\Big[\varphi\big(r\big)-\omega t\Big]\leftrightarrow A(r)e^{i\varphi\big(r\big)}e^{-i\omega t} $$ 

Plane wave:

 $$ Ae^{i\vec{k}\bullet\vec{r}}e^{-i\omega t} $$ 

Spherical wave:  $ \frac{A}{r}e^{ikr}e^{-i\omega t} $

### 5. Energy and momentum of light

Classical E-M wave photon

Energy:

 $$ S=\vec{E}\times\vec{H} $$ 

 $$ E=h\upsilon=\hbar\omega $$ 

 $ \langle S \rangle = I \propto E_0^2 \quad \text{(I: Energy flux density)} $

 $$ I=n_{\mathrm{v}}C\hbar\omega=n_{f}\hbar\omega\quad\left(n_{\mathrm{v}}\mathrm{:v o l u m e d e n s i t y;}\quad n_{f}\mathrm{:f l u x d e n s i t y}\right) $$ 

Momentum:  $ \Delta P = \frac{\Delta w}{C} $ ( $ \Delta w $: power change)

 $$ P_{p h o t o n}=\hbar\vec{k} $$ 

 $$ P_{v}=\frac{S}{C^{2}} $$ 

 $$ \left|p\right|=\frac{h}{\lambda} $$ 