the  $ n_{t} $ side.

The above peculiar behavior at TIR can be explained by the Evanescent wave. Now we briefly discuss it.

<div style="text-align: center;"><img src="imgs/img_in_image_box_201_369_532_720.jpg" alt="Image" width="27%" /></div>


 $$ E_{t}=E_{o t}e^{i(\vec{k}_{t}\bullet\vec{r}-\omega t)} $$ 

↑ transmitted wave

 $$ \vec{k}_{t}=k_{tx}\hat{i}+k_{ty}\hat{j} $$ 

 $$ k_{tx}=\left|k_{t}\right|\sin i_{2} $$ 

 $$ k_{ty}=\left|k_{t}\right|\cos i_{2} $$ 

 $ At \quad i_i > i_c \quad (\sin i_c = n_{ti}) $

 $$ \begin{aligned}\cos i_{_{_{_{_{_{_{2}}}}}}}=\pm\sqrt{1-\sin^{2}i_{_{_{_{_{_{2}}}}}}}&=\sqrt{1-\frac{\sin^{2}i_{_{_{_{_{i}}}}}}{n^{2}t_{_{_{i}}}}}=\pm i\sqrt{\frac{\sin^{2}i_{_{_{_{i}}}}}{n^{2}t_{_{i}}}-1}\\&\uparrow\\<0at\quad i_{_{_{i}}}>i_{_{_{c}}}\end{aligned} $$ 