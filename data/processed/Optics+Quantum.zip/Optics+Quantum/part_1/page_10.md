 $$ \begin{aligned}\mathcal{P}\begin{cases}=\frac{I}{C}(absorbing)\\ =\frac{2I}{C}(reflection)\end{cases}\quad\mathcal{P}:pressure\end{aligned} $$ 

6. Dipole oscillation and radiation.

Quantum



Classical:

Forced oscillation picture:

 $$ \int\limits_{\sqrt{g r o n d}}^{\text{Excited}}\hbar\omega $$ 

 $$ r=\frac{A_{0}}{\omega^{2}-\omega_{0}^{2}+i\gamma^{2}\omega}e^{-i\omega t} $$ 

Oscillation with same freq.  $ \omega $ (driving field is  $ E_{0}e^{-i\omega t} $) but with a phase lag.

Or:  $ r = A e^{-i(\omega t + \phi)} $, with

 $$ A=\frac{\frac{q_{e}E_{0}}{m}}{\sqrt{\left(\omega^{2}-\omega_{0}^{2}\right)^{2}+\gamma^{2}\omega^{2}}}\qquad\tan\phi=\frac{\gamma\omega}{\omega^{2}-\omega_{0}^{2}} $$ 

The E-M radiation flux density:

 $$ I\propto\left(\mu_{d}^{\mathrm{~0~}}\right)^{2}\omega^{4}\sin^{2}\theta,\mathrm{w h e r e}\quad\mu_{d}^{\mathrm{~0~}}=q_{e}A $$ 

At large distance from source, where  $ \sin\theta $ does not change much, dipole radiation~ spherical wave source:

 $$ E\propto\frac{e^{ikr}e^{-i\omega t}}{r} $$ 

7. Doppler Effect