(1)Linearly accelerating charges (Hecht 3.4.1, 3.4.2)

The radiation created by such sources will not be treated in detail here,

refer to Hecht's book for the brief introduction.

(2) Oscillating Charges—— Dipole radiation

This is radiation created by atoms/molecules, composed of most light sources in daily life, as well as in lab, Such as light bulbs, neon light, lasers .....

For such radiation, the  $ \underline{simple quantum} $ pictures are transition between energy levels of atom/molecule: when the electron in the atom/molecule relaxes from excited state (upstairs) to ground state (downstairs), accompanying with emission of light:

<div style="text-align: center;"><img src="imgs/img_in_image_box_205_995_999_1152.jpg" alt="Image" width="66%" /></div>


The full quantum description is out of the scope of the course, and can be found in courses, such as “Quantum Mechanics”. The simple picture is sufficient to understand the radiation (Emission) by the common light sources.

The atoms/molecules are randomly excited to the excited states by