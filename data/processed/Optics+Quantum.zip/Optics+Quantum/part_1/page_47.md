<div style="text-align: center;"><img src="imgs/img_in_image_box_202_176_516_306.jpg" alt="Image" width="26%" /></div>


There is certainly no reflection inside the  $ n_{2} $ region.

Now Split Cube in half into two prism, the amount of reflection and transmission will depend on the spacing.

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_606_496_779.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_653_612_943_780.jpg" alt="Image" width="24%" /></div>
