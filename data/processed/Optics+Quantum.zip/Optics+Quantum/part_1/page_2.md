can be understood as follows: for any energy potential in arbitrary form

<div style="text-align: center;"><img src="imgs/img_in_image_box_543_226_813_350.jpg" alt="Image" width="22%" /></div>


with equilibrium, such as

At the small region around equilibrium, the potential can be approximated by a harmonic potential, and the force will obey Hook's Law.



This can be seen by expand  $ U(x) $ into Taylor series

 $$ \begin{aligned}&U(x)=U(x_{0})+\frac{\partial U}{\partial x}\Big|_{x_{0}}\Delta x+\frac{1}{2}\frac{\partial^{2u}}{\partial x^{2}}(\Delta x)^{2}+\ldots\ldots\\ &\\ \Rightarrow\quad U(x)\sim\frac{1}{2}kx^{2}\Rightarrow F=kx\\ \end{aligned} $$ 

(b) Damped Oscillator

Introducing a resistance force:  $ f_{r} = -b \frac{dr}{dt} $

The equation comes:

 $$ m\ddot{r}+b\dot{r}+k r=0 $$ 

 $$ \begin{array}{r l r l}{\mathrm{O r}}&{{}\ddot{r}+\gamma\dot{r}+\omega_{0}^{2}r=0}&{}&{{}\mathrm{~w h e r e~}\gamma=\frac{b}{m}}\end{array} $$ 

The general solution for this equation is in the form of:

 $$ \begin{aligned}&r=A e^{-\frac{\gamma t}{2}}e^{-i\left(\omega^{\prime}t+\phi\right)},where\gamma^{2}<<\omega_{0}^{2}\\ &\omega^{\prime}=\sqrt{\omega_{0}^{2}-\left(\frac{\gamma}{2}\right)^{2}}\\ \end{aligned} $$ 