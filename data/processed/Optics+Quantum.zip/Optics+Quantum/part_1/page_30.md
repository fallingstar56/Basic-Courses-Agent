 $$ \begin{array}{r l}{\mathrm{A t}X_{_{A}},\quad}&{{}E_{_{T o t a l}}=E_{_{p r i.}}+E_{_{\mathrm{s e c o n d}}}=E_{_{0}}^{\prime}e^{i\varepsilon_{_{A}}}e^{-i\omega t}}\end{array} $$ 

 $ \varepsilon_{A} $ is the phase lag between the total wave and primary wave at point A.

At  $ X_{B} $, this  $ E_{Total} $ will act as primary wave and there will be further delay of phase, the secondary wave from  $ X_{B} $ will have phase lag compared to  $ E_{Total} $, thus generally when we treat the media as continuous:

 $$ \varepsilon=\alpha X,\alpha>0for phase Lag. $$ 

The resulting wave (sum of secondary and primary) would be:

 $$ e^{i(k_{0}+\alpha)x}e^{-i\omega t} $$ 

 $$ \therefore k=k_{0}+\alpha, $$ 

 $$ \nu=\frac{\omega}{k}<\frac{\omega}{k_{0}}=c $$ 

So the phase velocity is different than that of c even though both primary wave and secondary waves propagate with c, it is caused by the phase difference between them.

(c) Likewise, if  $ \Delta\phi < 0 $, secondary leads in phase $ ^{4} $,  $ (\alpha < 0) $

The phase velocity certainly can supersede speed of light, this does not violate relativity, since the phase velocity is not the propagation speed of physical entity.