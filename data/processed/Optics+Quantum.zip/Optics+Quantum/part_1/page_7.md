Summary on General properties of Light as E-M wave (Chapter 1 and 2).

1. From Maxwell Equation——wave equation.

 $$ \nabla^{2}\vec{E}=\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}}(\mu,\varepsilon\mathrm{i n m e d i a}) $$ 

 $$ \nabla^{2}\vec{H}=\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{H}}{\partial t^{2}} $$ 

E-M field indeed propagate as wave——E-M wave.

 $ \vec{E}, \vec{H} $  $ \vec{k} $ form a right-hand Cartesian:

<div style="text-align: center;"><img src="imgs/img_in_image_box_266_696_432_863.jpg" alt="Image" width="13%" /></div>


 $$ \left|E\right|=C\left|B\right|=\sqrt{\frac{\mu}{\varepsilon}}\left|H\right| $$ 

So, knowing  $ \vec{E} $,  $ \vec{H} $ is also known. And since the interaction between light and environment is dominated by  $ \vec{E} $, we shall use  $ \vec{E} $ to represent the light wave.

2. Speed of light, Refraction index, dispersion.

(phase velocity)

 $$ C_{_{0}}=\frac{1}{\sqrt{\mu_{_{0}}\varepsilon_{_{0}}}}\quad C=\frac{1}{\sqrt{\mu\varepsilon}} $$ 

Phase velocity

 $$ n=\frac{C_{_{0}}}{C}=\sqrt{\frac{\varepsilon\mu}{\varepsilon_{_{0}}\mu_{_{0}}}}=\sqrt{K_{_{E}}K_{_{m}}}\approx\sqrt{K_{_{E}}} $$ 

 $ \varepsilon, n $ are frequency dependent  $ \rightarrow $ dispersion