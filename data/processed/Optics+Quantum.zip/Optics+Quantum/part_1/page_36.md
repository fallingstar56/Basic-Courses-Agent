The derived Fresnel equations include all the information needed when we discuss relations between incident and deflected beams, below are some important results from the Fresnel equation .(Focus on the  $ r_{p}, r_{S} $)

## 3 -6-1 Amplitude, Brewster angle and Total Internal Reflection

The figures show the computation for the coefficients at different incident angles (Figures 4.41; 4.42 in Hecht's)

<div style="text-align: center;"><img src="imgs/img_in_chart_box_197_599_588_1010.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;">Figure 4.41 The amplitude coefficients of reflection and transmission as a function of incident angle. These correspond to external reflection  $ n_{t} > n_{i} $ at an air-glass interface ( $ n_{t_{i}} = 1.5 $).</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_616_605_994_1011.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">Figure 4.42 The amplitude coefficients of reflection as a function of incident angle. These correspond to internal reflection  $ n_{t} < n_{t} $ at an air-glass interface ( $ n_{t} = 1/1.5 $).</div>


(1) For the S component,

The  $ |r_s| $ increases monotonically with the incident angle, reaching 1 at glance angle ( $ t_s \to 0 $ at glance angle), glance angle is  $ \theta_i = 90^\circ $.

(2)For the P component, the  $ \left|r_{p}\right| $ first decrease to 0 as the incident angle increases to  $ \theta_{B} $ (Brewster angle or polarization angle), then it increases to 1 as angle increases.