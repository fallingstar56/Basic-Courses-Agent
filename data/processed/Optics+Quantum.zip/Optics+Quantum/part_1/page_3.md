This is a damped oscillation with weak damping, the amplitude decay exponentially with time and the frequency is a little shifted from the natural frequency. It corresponds to an oscillator with a dissipation, such as caused by friction, heat loss, etc.

## (c) Forced oscillator

If the oscillator is driven by an external periodic force, such as the electric force :

 $$ F=q\vec{E}=q E_{0}e^{-i\omega t} $$ 

The equation of motion would be:

 $$ \ddot{r}+\gamma\dot{r}+\omega_{0}^{2}r=\frac{q_{e}E_{0}}{m}e^{-i\omega t} $$ 

The solution of the equation at longer time(steady state):

 $$ r=\frac{q_{e}E_{0}}{m}\frac{1}{\omega_{0}^{2}-\omega^{2}-i\omega\gamma}e^{-i\omega t} $$ 

The (2-23) shows that, the dipole oscillation under periodic driving force  $ e^{-i\omega t} $, is a harmonic oscillation  $ \underline{\text{with same frequency as the driving force!}} $

Its amplitude and phase of oscillation can be estimated from (2-23) too. The phase of the force oscillation always Lag that of the driving field (this is a physical argument). The phase Lag is between  $ 0-\pi $. The amplitude is large when  $ \omega = \omega_{0} $ (resonant situation, this is a good