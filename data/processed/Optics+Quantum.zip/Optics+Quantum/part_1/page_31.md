## 3 -6 Fresnel Equations

——E-M treatment of light's propagation through interface.

(Zhao's Book , vol. 1 P245-266, Hecht's Book , 4.6)

(You can read either one, there are some differences in notation between the two books: (Left: Hecht’s book; Right: Zhao’s)  $ \varepsilon \leftrightarrow \varepsilon\varepsilon_0 $,  $ n_i \leftrightarrow n_1 $,  $ n_t \leftrightarrow n_2 $. This notes follows Hecht’s)

The phenomenal treatment earlier, though predicts the direction of deflected light (in reflection and refraction), it does not give any quantitative ratio between incident and deflected wave. Here I shall focus on the discussion of how we get this ratio. While the derivation of the direction of reflection and refraction (Snell's law) will not be covered here, but interesting students may refer to Hecht's 4.6 on details about this.

This relation for amplitude and phase, between incident and deflected waves for a plane wave is given by Fresnel Equations, which can be proved by using the boundary conditions of Maxwell equations.

We need first to specify the coordinate system, especially the individual coordinate system for the incident, reflected and refracted beams. This is important, since the signs of equations will depend on the choice of the positive directions of the coordinate system. We can