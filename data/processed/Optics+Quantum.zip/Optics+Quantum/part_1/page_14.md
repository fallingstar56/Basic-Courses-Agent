<div style="text-align: center;"><img src="imgs/img_in_image_box_330_152_874_529.jpg" alt="Image" width="45%" /></div>


Reflection:  $ i_{1}=i_{1}^{\prime} $;  $ n_{1}<n_{2} $ External reflection

 $ n_{1} > n_{2} $ Internal reflection

Refraction:  $ n_{1}\sin i_{1}=n_{2}\sin i_{2} $ ——Snell's law

All the “rays” are in the same plane. ——plane of incidence

Rays: For conveniently showing the propagation of light, we use rays to represent waves. A ray is a line in space corresponding to the direction of flow of energy. In the isotropic media, rays are simply in the direction of wave vector $ \vec{k} $, which are orthogonal trajectories of the wave front (perpendicular to the equal-phase plane).

Changes of light upon refraction (Hecht, pg. 102)

(a) Changes direction of propagation —— Snell's law.

 $$ n_{1}\sin i_{1}=n_{2}\sin i_{2} $$ 

(b) Changes the cross section of the beam of plane wave, thus varies the