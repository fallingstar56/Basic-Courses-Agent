 $$ E_{Q}=E_{0}e^{i\phi_{Q}} $$ 

 $$ E_{P}=E_{0}^{\prime}e^{i\phi_{P}} $$ 

 $$ \Delta\phi_{QP}=\phi_{p}-\phi_{Q}=\frac{2\pi}{\lambda_{_{0}}}(QP) $$ 

Thus we take the consideration on refractive index into  $ (QP) $, the OPL and treat light in any media travels at speed  $ C_{0} $, or wave length of  $ \lambda_{0} $ when calculate its phase difference.

Fermat’s Principle (Variational principle).

A light ray goes from point Q to point P must traverse an optical path length that is stationary with respect to variations of the path:

 $$ \delta(QP)=\delta\int_{Q}^{P}ndl=0 $$ 

This principle can also be used to prove the rules of deflection and refraction. (The light travels in straight path in homogeneous, isotropic media is obvious with Fermat's principle).

(Optional) The physical significance underline the principle is discussed in Hecht's Book (Fig4.34, 4.35, also see pg. 139-140, Fig.4.68). Basically, it has to be understood from superposition of waves (Interference). In the figure below: the vertical axis is the optical path length; the horizontal axis is some parameter, specifying the path (here is