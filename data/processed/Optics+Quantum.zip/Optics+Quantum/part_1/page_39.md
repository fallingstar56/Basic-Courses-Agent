the original incident  $ \vec{E} $.⁵ We see that the deflected light,  $ \vec{E}_r $ or  $ \vec{E}_t $ are only in phase (along the direction) or out of phase (reversed direction) with respect to incident  $ \vec{E} $ at normal or glance angle ( $ i_t = 0 $ or  $ 90^\circ $) where the coordinates axes are parallel or anti-parallel. For other incident angles, the angles between  $ \vec{E}_i $ and  $ \vec{E}_r $,  $ \vec{E}_t $ are generally between  $ 0 \sim \pi $ (Hecht’s Fig 4.45 4.46)

Extra comments on phase: For light propagates through interface between two media, the $r_{s}, r_{p}, t_{s}, t_{p}$ carries the phase information of reflected and transmitted light with respect to the $\hat{S}_{r}, \hat{P}_{r}, \hat{S}_{t}, \hat{P}_{t}$ direction defined as in Fig2 of this note.

<div style="text-align: center;"><img src="imgs/img_in_image_box_384_807_766_1067.jpg" alt="Image" width="32%" /></div>


At point o (we can define it as origin point,  $ \vec{r}=0 $)

 $$ E_{ip}(o)=E_{io}e^{i\phi_{op}}e^{-i\omega t}\quad E_{is}=E_{io}e^{i\phi_{os}}e^{-i\omega t}\quad\Delta\phi_{sp}=\phi_{os}-\phi_{op}=\phi_{o} $$ 

The drawing below summarize given the initial phase difference between S and P components for the incident wave, the phase difference between the S and P components of the Transmitted and