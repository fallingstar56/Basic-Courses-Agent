Huygens’s principle. These wavelets generate secondary spherical waves with $C_{0}$, the vacuum phase velocity; those in Huygens’s principle propagate at phase velocity of the media $\frac{C_{0}}{n}$. We stated that the Huygens’s secondary wavelets are superposition of secondary waves and primary waves here in the scattering picture, this point will be clear soon later)

## (1) Transmission

<div style="text-align: center;">Fig. 4.4 and 4.5 in Hecht's Book.</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_186_749_676_947.jpg" alt="Image" width="41%" /></div>


Basically, the secondary waves that propagate along the transmission direction (forward direction) can interfere in phase, constructively. The light field at point P would be summation of all the contributions and thus would be strong.

(2) Sideway scatterings

<div style="text-align: center;">Fig 4.6 in Hecht’s Book or the figure below:</div>
