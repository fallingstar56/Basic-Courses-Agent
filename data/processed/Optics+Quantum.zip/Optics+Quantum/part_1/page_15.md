irradiance I (energy/Area)

 $$ S_{1}=\overline{A}\overline{B}\cos i_{1} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_226_504_435.jpg" alt="Image" width="23%" /></div>


 $$ S_{2}=\overline{A}\overline{B}\cos i_{2} $$ 

 $$ \frac{S_{2}}{S_{1}}=\frac{\cos i_{2}}{\cos i_{1}} $$ 

(c) Changes phase velocity of light

 $$ \nu=\frac{c}{n} $$ 

If  $ \omega $ is same (think why?), the wave length in a media will depend on n,

 $$ \lambda=\frac{\lambda_{0}}{n}\qquad\lambda_{0}\mathrm{~vacuum~wave~length~} $$ 

## 3 -2 Huygens's Principle

Every point on a propagating wave front serves as a source of spherical secondary wavelet, such that the wave front at some later time is the envelope of these wavelets.

(Fig 4-26 in Hecht’s Book or Fig2-2 in Zhao’s Book)