The phase velocity of light in media is

 $$ \nu=\frac{c}{n} $$ 

However, the scattering picture as shown before, the secondary wave and primary wave all propagate in media with same  $ \omega $ and same phase velocity  $ c $, then why  $ v \neq c $?

This can be understood also from superposition of waves

Total Wave = Primary + Secondary (superposition principle)

Between primary and secondary wave, there is a phase difference.

 $$ \Delta\phi=\phi_{s}-\phi_{i} $$ 

 $ \phi_s $: secondary;  $ \phi_i $: primary $

(a)  $ \Delta\phi = 0 $  $ \nu = c $

(b)  $ \Delta \phi > 0 $ secondary lags primary

(Hecht’s book, Fig. 4.9, 4.10 and 4.11)

<div style="text-align: center;"><img src="imgs/img_in_image_box_188_1191_998_1484.jpg" alt="Image" width="68%" /></div>
