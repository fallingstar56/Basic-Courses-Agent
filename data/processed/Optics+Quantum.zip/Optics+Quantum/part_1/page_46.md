 $$ k_{ty}=\pm i\left|k_{t}\right|\sqrt{\frac{\sin^{2}i_{i}}{n^{2}t_{i}}-1}\equiv\pm i\beta $$ 

 $$ \therefore E_{t}=E_{ot}e^{\pm\beta y}e^{i(k_{tx}x-\omega t)} $$ 

Only- $ \beta $y is physical meaningful.

So the Evanescent Wave is a wave whose wave front propagate along the interface, and its amplitude drops exponentially along the direction normal to the interface. No energy flow in this normal direction (Born & Wolf. Chap.1)

The field penetrates to the forbidden area or order of  $ \lambda $

Application of Evanescent Wave

(1). Exciting only molecules at surface.

<div style="text-align: center;"><img src="imgs/img_in_image_box_244_966_696_1056.jpg" alt="Image" width="37%" /></div>


The excitation laser come at angle  $ >i_{c} $, the molecules right at the surface (a few layers of molecules) can be excited by the Evanescent Wave.

### (2) . Beam Splitter

The prisms stack together with a thin film spacer.