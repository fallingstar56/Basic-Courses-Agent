decompose the electric field into the cases shown below, with component perpendicular or parallel with the plane of incidence.

<div style="text-align: center;"><img src="imgs/img_in_image_box_231_346_561_550.jpg" alt="Image" width="27%" /></div>


<div style="text-align: center;">Fig.1a  $ \vec{E} \perp $ plane of incidence</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_623_307_991_546.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">Fig.1b  $ \vec{B} \perp $ plane of incidence</div>


(1). For any  $ \vec{E} $ in arbitrary direction perpendicular to  $ \vec{k} $, it can always decompose into  $ E_{\perp} $ and  $ E_{\parallel} $ components as shown in the figures.  $ E_{\perp} \rightarrow $ S component,  $ E_{\parallel} \rightarrow $ P component.

(2). The boundary condition of Maxwell equations are:

For  $ \bar{E} $,  $ \bar{H} $ the tangential component along the interface is continuous; (as long as there is no electric current in the interface) For  $ \bar{D} $,  $ \bar{B} $, the normal components across the interface are continuous (as long as no net charges in the interface). The proof is neglected here which is in any standard textbook on EM.

(3). From the boundary condition, it is easy to see that the reflection and refraction won’t mix  $ S(\perp) $ and  $ p(//) $ components of the polarization of light. i.e. if the incident light is S light (Fig1a above), the reflected and refracted light only contain S light; no P components if the incident light