direction of the  $ \bar{E} $ is called polarization. For the sake of simplicity, I shall treat the field pointing along one linear direction (linear polarized light) most of the time in the following discussion before we treat polarization in detail later (Hecht chap.8, Zhao's Book Chap 2.9).

Here for the later use, we need only to know some polarization state of light:

Natural Light (unpolarized light)

Linear Polarized:

Circular Polarized:

 $$ \begin{array}{ccc} \downarrow & \leftrightarrow & \\ \textcircled{0} & \textcircled{0} & \\ 0 & 0 & \end{array} $$ 

Elliptical Polarized: