For simplicity in math, take prism is equal-lateral right-angled

<div style="text-align: center;"><img src="imgs/img_in_image_box_214_241_750_441.jpg" alt="Image" width="45%" /></div>


 $$ \alpha=90^{\circ} $$ 

$i_{i}^{\prime}$ will depend on $n$ ($\omega$), the $\omega$ dependent index of refraction. The question is $\frac{di^{\prime}}{d\omega}$, we need first find relation bet. $i_{i}^{\prime}$ and $n$ ($\omega$), then from

 $$ \frac{dn}{d\omega}\rightarrow\frac{di^{\prime}}{d\omega} $$ 

From Snell's Law:

 $ n\sin i_2 = \sin i_1 $

 $ n\sin i_2' = \sin i_1' $

 $$ i_{2}^{^{\prime}}+i_{2}=90^{o}=\alpha $$ 

 $$ \sin i_{2}^{^{\prime}}=\cos i_{2} $$ 

Eliminate  $ i_{2} $, using above relations and

 $$ \cos^{2}i_{2}+\sin^{2}i_{2}=1 $$ 

 $$ \sin i_{1}^{\prime}=\sqrt{n^{2}-\sin^{2}i_{1}} $$ 

Take derivative vs.  $ \omega $

 $$ \cos i_{1}^{^{\prime}}\frac{d i_{1}^{^{\prime}}}{d\omega}=\frac{d u}{d\omega}\frac{d(\sqrt{n^{2}-\sin^{2}i_{1}})}{d n} $$ 