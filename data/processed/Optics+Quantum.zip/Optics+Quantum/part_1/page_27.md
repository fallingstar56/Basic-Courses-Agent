infinitely in all dimensions, the cancellation will be complete (the adjacent zones consist almost same amount secondary wavelets and thus the contributions to point P will be equal in magnitude but with reversed sign). In real cases such as a chunk of glass, there will be boundaries and incomplete cancellation, but the sideway scattering is still quite weak. Also if we introduce some inhomogeneity by droplet of vapors or dusts, the sideway scattering will be enhanced because of the incomplete cancellation. This explains what you see in the movies, the thieves used compressed air cans and spray it to reveal the light alarm network.

Thus inhomogeneous, such as density fluctuation in air, imperfects in crystal, or limited boundaries will give rise to sideway scattering (or it can be viewed as a break of symmetry)

## (3) Reflection at interface—— A result of symmetry breaking

<div style="text-align: center;"><img src="imgs/img_in_image_box_243_1160_1027_1330.jpg" alt="Image" width="65%" /></div>


Originally the light travels in a media, say a glass rod, and I shall break the rod into two pieces as in (b),  $ E_{1} $ and  $ E_{2} $ are reflected light