a simplification where the path can be specified by one variable)

<div style="text-align: center;">(ap)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_265_263_530_447.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_675_299_887_425.jpg" alt="Image" width="17%" /></div>


The paths around the stationary paths (specified by points A,O,B) have almost equal OPL and thus when superposed, will interfere constructively. The paths away from stationary will arrive P out-of-phase with each other and therefore tend to cancel. A more concrete example is reflection by mirror: given the initial and final points (S, P), the position on the mirror (say x) will specify the path. The contribution (represented by phasors) around the stationary path (group-I) and that from another region is shown in the figure (b).

<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_243_1005_643_1248.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_248_1321_530_1422.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_246_1443_499_1527.jpg" alt="Image" width="21%" /></div>
