## 3 -3 Fermat's Principle $ ^{3} $

## Important Concept: Optical Path Length (OPL)

It is the effective (equivalent) distance that light traveled at speed of  $ C_0 $, the vacuum speed. For propagating wave, the phase difference between two points  $ Q $,  $ P $ depends on distance of  $ \overline{QP} $ and the wave length  $ \lambda $ (or  $ k = \frac{2\pi}{\lambda} $). In different media, the  $ \lambda $ is different ( $ \lambda = \frac{\lambda_0}{n} $). The same distance may correspond to different phase change. To eliminate this inconvenience, we introduce the concept of optical path length (OPL).

Defined as:

<div style="text-align: center;"><img src="imgs/img_in_image_box_278_918_525_1176.jpg" alt="Image" width="20%" /></div>


OPL is:

 $$ (QP)=\sum_{i}n_{i}l_{i}=\int_{Q}^{P}ndl $$ 

(QP) is related to the phase difference between Q and P for a wave.