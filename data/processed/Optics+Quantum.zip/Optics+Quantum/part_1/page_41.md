It is clear at normal incidence that there is half-wavelength difference  $ \left(\frac{\lambda_{0}}{2},\pi\right) $ between reflected and incident during external reflection  $ (n_{i}<n_{t}) $; No phase difference between reflected and incident light for internal reflection  $ (n_{i}>n_{t}) $. Between the two reflected beams by the top and

<div style="text-align: center;"><img src="imgs/img_in_image_box_529_400_670_505.jpg" alt="Image" width="11%" /></div>


bottom surfaces of a media $\rightarrow$ if $n_{1}=n_{3}$, i.e. a glass plate in air, between the beams 1 (top reflection) and 2 (bottom reflection), there are always extra $\frac{\lambda_{0}}{2}$ (or $\pi$) difference (We have discussed this earlier in the scattering picture of light's propagation. Here we can make more quantitative derivation using Fresnel equations, please also refer to Fig 10-9 of Zhao's Book ). Using Fresnel equations on the reflection coefficients, we can prove (and you are encouraged to do it) that more generally at small incident angle ($\theta_{i}\sim0$): if $n_{2}$ is “sandwiched” between $n_{1}$, $n_{3}$, i.e. $n_{1}>n_{2}>n_{3}$ or $n_{1}<n_{2}<n_{3}$, there will be No half-wavelength difference between top-bottom reflection; if $n_{2}$ is larger or smaller than both $n_{1},n_{3}$, i.e. $n_{2}<(or>)$ $n_{1},n_{3}$, there will be half-wavelength difference. For transmitted light ($t_{s},t_{p}>0$), there are always in phase (at least partially) with $\vec{E}_{i}$.

## 3 -6-3 Stokes Relation

(Zhao's 10.3, p252; Hecht's 4.10, p136)