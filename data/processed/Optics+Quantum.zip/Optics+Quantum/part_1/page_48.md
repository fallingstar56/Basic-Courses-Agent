Given the incoming light, the  $ n_{i} $,  $ n_{i} $ of the media, we can determine the reflected light and transmitted light across the interface.

<div style="text-align: center;"><img src="imgs/img_in_image_box_181_375_1017_950.jpg" alt="Image" width="70%" /></div>


Orientation: Angles between them.

<div style="text-align: center;">Phase between S, P components of reflected / transmitted light →polarization of the reflected/ transmitted.</div>
