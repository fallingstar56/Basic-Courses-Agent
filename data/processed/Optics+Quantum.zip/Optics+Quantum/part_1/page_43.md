internally – externally reflected beams, using the qualitative scattering picture, i.e.

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_278_551_348.jpg" alt="Image" width="27%" /></div>


Now, with Fresnel equation and Stokes relation, we can strictly prove it:

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_457_718_778.jpg" alt="Image" width="40%" /></div>


1,2,3,4 are in forms of plane wave.

Beam1, at point A; the field is  $ E_1 = E_0 e^{-i\omega t} $.

Beam2, at point B,  $ E_{2}=E_{0}e^{i\phi_{B}}e^{-i\omega t} $

 $$ \phi_{B}=k_{0}n_{1}\overline{AB}\sin i_{i} $$ 

Beam3, at point B, the reflected of beam 2:

 $$ E_{3}=r E_{0}e^{i\phi_{B}}\left(r for\ r_{p}or\ r_{s}\right) $$ 

Beam4 at point B, the reflection of beam1 from the bottom surface:

 $$ E_{4}=t r^{\prime}t^{\prime}E_{0}e^{i\phi_{B}^{\prime}}\quad\phi_{B}^{\prime}=\frac{k_{0}n_{2}\overline{A B}}{\sin i_{t}} $$ 

From stokes relation:  $ tr't' = r'(1 - r^2) = -r(1 - r^2) $