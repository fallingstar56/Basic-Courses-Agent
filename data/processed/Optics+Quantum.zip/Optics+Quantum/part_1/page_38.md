 $$ \theta_{_{c}}=\arcsin\frac{n_{_{t}}}{n_{_{i}}},i_{_{t}}\rightarrow90^{\circ}.As\quad\theta_{_{i}}\geq\theta_{_{c}},\left|r_{_{p}}\right|,\left|r_{_{s}}\right|\rightarrow1 $$ 

 $$ \begin{array}{r l r}{\mathrm{H o w e v e r,~}t_{_{p}},t_{_{s}}\neq0}&{{}}&{\mathrm{(s e e~3-7,3-8)}}\end{array} $$ 

But energy flow of transmittance:  $ T = \frac{n_{t} \cos \theta_{t}}{n_{i} \cos \theta_{i}} |t|^{2} = 0 $ ( $ \cos i_{t} = 0 $)

This means that there is no energy flow into the optical less dense region  $ (n_{t} $ region), but there are field existing in it. We shall see that this field is created by evanescent wave.

## 3 -6-2 Phase shift

### (Fig 4.44, Hecht's)

Away from the critical angle in case of total internal reflection, the coefficients  $ r_{p}, r_{s}, t_{p}, t_{s} $ are real numbers, so the phase difference here only means the signs change (0 or  $ \pi $). At the TIR, the  $ r_{p}, r_{s} $ will become complex number (left as homework to prove) and phase is referred to the argument of the complex number. This is straightforward but I need to clarify the physical meaning of such phase difference.

(1) Away from the critical angle, the $r,t_{s}$ are either + or -, which means the deflected light are either in phase (means +, for $r,t$) or out of phase(—).

However as we stressed earlier, this +, - are referring to the individual coordinate system we assigned as in Fig.2 of this note, not referring to