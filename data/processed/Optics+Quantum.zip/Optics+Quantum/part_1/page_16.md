<div style="text-align: center;"><img src="imgs/img_in_image_box_291_159_843_437.jpg" alt="Image" width="46%" /></div>


The secondary wavelets in Huygens’s principles are imaginary points on the wave front (virtual wavelets). These secondary wavelets have the same freq. ∅ and same phase velocity of the propagating wave in media. The Huygens’s principle is a very useful tool, and can be used to derive the rules of reflection and refraction (It is basically some simple geometry and the details are in Zhao’s Book, pg. 26-30).

We are going to see that this principle is highly useful to construct the wave front, estimate the phase distribution over space etc. when we treat the diffraction. (The Huygens's — Fresnel principle)

As to the physical basis for the principle, when light interacts with the atoms/molecules of the media, the secondary wavelets can be viewed as the radiation from the forced dipole oscillation plus(superpose) the primary wave. However in vacuum, the secondary wavelets in the principle have to be viewed as imaginary points, so:

Treat the principle as a useful tool rather than the real physical existence would be most proper.