<div style="text-align: center;">Fig2.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_305_174_786_535.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_815_191_977_344.jpg" alt="Image" width="13%" /></div>


By using coordinate systems defined for  $ \vec{E}_i $,  $ \vec{E}_r $,  $ \vec{E}_\tau $ in figure 2.  $ E_{si} $,  $ E_{pi} > 0 $ means they are along the direction defined by  $ \vec{S}_i $,  $ \vec{P}_i $ or more precisely they are in phase with  $ \vec{S}_i $,  $ \vec{P}_i $;  $ E_{si} $,  $ E_{pi} < 0 $ means they are in the reverse direction, out of phase. Same arguments applies for the  $ E_{pr} $,  $ E_{sr} $ of the reflected and  $ E_{pt} $,  $ E_{st} $ of the refracted beams, and their signs relate to the defined  $ \vec{P}_r $,  $ \vec{S}_r $;  $ \vec{P}_i $,  $ \vec{S}_t $ respectively as in Fig2.

Applying boundary conditions and after straightforward but tedious computation (details skipped here), the Fresnel equations then are:

\[\begin{aligned}&r_{_{p}}=\frac{E_{\mathrm{p}_{\mathrm{r}}}}{E_{_{Pi}}}=\frac{n_{_{t}}\cos\theta_{_{i}}-n_{_{i}}\cos\theta_{_{t}}}{n_{_{t}}\cos\theta_{_{i}}+n_{_{i}}\cos\theta_{_{t}}}=\frac{\tan(\theta_{_{i}}-\theta_{_{t}})}{\tan(\theta_{_{i}}+\theta_{_{t}})}=\frac{n_{_{ti}}^{^{2}}\cos\theta_{_{i}}-\sqrt{n_{_{ti}}^{^{2}}-\sin^{2}\theta_{_{i}}}}{n_{_{ti}}^{^{2}}\cos\theta_{_{i}}+\sqrt{n_{_{ti}}^{^{2}}-\sin^{2}\theta_{_{i}}}}\\ &(r\mathord{\left/

where  $ n_{ti} \equiv \frac{n_{t}}{n_{i}} $

 $$ r_{s}=\frac{E_{S\mathrm{r}}}{E_{S i}}=\frac{n_{i}\cos\theta_{i}-n_{t}\cos\theta_{t}}{n_{i}\cos\theta_{i}+n_{t}\cos\theta_{t}}=-\frac{\sin(\theta_{i}-\theta_{t})}{\sin(\theta_{i}+\theta_{t})}=\frac{\cos\theta_{i}-\sqrt{n_{t i}^{2}-\sin^{2}\theta_{i}}}{\cos\theta_{i}+\sqrt{n_{t i}^{2}-\sin^{2}\theta_{i}}} $$ 