thermal heating or electron bombardment, and emit out light (conventional light source); or the atoms/molecules are excited coherently (we shall discuss, explain this word later) and emit out coherent light (laser)

Here, we give the classical treatment of atom/molecules as electric dipole oscillator:

<div style="text-align: center;"><img src="imgs/img_in_image_box_206_553_993_758.jpg" alt="Image" width="66%" /></div>


The dipole (defined with  $ \vec{d}=q\vec{r} $, q is the charge and the r is the displacement vector, convention is r is from negative charge to positive) oscillation reduces to the problem of solving the motion equation of  $ \underline{r} $

Such problem is treated in detail in other textbooks such as we discussed in the oscillation part in mechanics. Basically:

(a) Free harmonic oscillation with restoring force:

 $$ m\ddot{r}+k r=0 $$ 

(k: restoring term)

 $$ r=A e^{-i(\omega_{0}t+\phi)}\quad\omega_{0}=\sqrt{\frac{k}{m}} $$ 

The reason that restoring force is in form of kr, obeys Hook's Law