that results from backward scattering of molecules/atoms at depth~ $ \frac{\lambda_0}{2} $

from the interfaces.

If we bring the two parts in figure (b) together, we should get back to the situation in (a) without no net energy flow backward, meaning the reflection will diminish. This means  $ E_1 + E_2 = 0 \Rightarrow |E_1| = |E_2| $ and with a phase difference by  $ \pm\pi $

Example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_210_701_474_870.jpg" alt="Image" width="22%" /></div>


There are cases that we need to evaluate the phase difference between the fields of top reflection and the bottom reflection at certain point, for illustrating purpose, I designate Q for top reflection and P for bottom reflection.

 $$ \Delta\phi_{QP}=\frac{2\pi}{\lambda_{0}}(2nd)+\pi $$ 

The phase difference has two contributions:

$$\frac{2\pi}{\lambda_{0}}(2nd):\mathrm{Due to OPL difference};\qquad\pi:\mathrm{Half-wavelength difference}$$

(4) Different phase velocity in the media