Another way of seeing this, borrowed half-wavelength plate method used in diffraction (we shall come to this again).

<div style="text-align: center;">OPL</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_190_304_828_909.jpg" alt="Image" width="53%" /></div>


Within each half-wavelength zone, the contributions are phasors(the little arrows in the figure, representing the probability amplitude of light taking some particular path) with phase difference between  $ -\frac{\pi}{2}-\frac{\pi}{2} $ and add up sort of constructively to give none zero result (such as bigger arrow 1 and 2 above); between half-wavelength zones they are out of phase and cancel each other. The total contributions will be summation of all these zones and that will result in many cancellations. The important property of the stationary point (around zone 1) is that the contribution of this zone around the stationary is the largest (recall the definition of stationary). In