The Brewster angle

 $$ \theta_{_{i}}=\theta_{_{B}}\rightarrow\left|r_{_{p}}\right|=0 $$ 

From (3-7), it is easy to see that

 $$ \left|r_{_{p}}\right|=0\quad at\quad\theta_{_{i}}+\theta_{_{t}}=90^{o}\left(\tan(\theta_{_{i}}+\theta_{_{t}})\rightarrow\infty\right) $$ 

 $$ \because n_{i}\sin\theta_{i}=n_{t}\sin\theta_{t}=n_{t}\cos\theta_{i} $$ 

 $$ \therefore\tan\theta_{B}=\frac{n_{t}}{n_{i}} $$ 

At this Brewster angle, only S component is reflected and thus the reflected light is linearly polarized, and transmitted light will be partially polarized due to decreased amount of S. If there are multiple surfaces, the transmitted light will be almost P-polarized. The reflection and transmission is the simplest device to create liner polarized light, such as the Brewster window (a piece of glass aligned at Brewster angle with the axial of the cavity) in a laser cavity.

<div style="text-align: center;"><img src="imgs/img_in_image_box_218_1028_1000_1249.jpg" alt="Image" width="65%" /></div>


(3) Total Internal Reflection.

For external reflection  $ (n_i < n_t) $  $ \left|r_p\right|, \left|r_s\right| \to 1 $ at glance angle

For internal reflection  $ (n_{i}>n_{t}) $, there is a critical angle, where