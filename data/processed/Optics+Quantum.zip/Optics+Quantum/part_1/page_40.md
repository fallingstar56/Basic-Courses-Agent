Reflected waves can be determined by the transmission and reflection coefficients. Such phase difference between the S,P components will be important to determine the polarization of the field.

<div style="text-align: center;"><img src="imgs/img_in_image_box_197_359_937_908.jpg" alt="Image" width="62%" /></div>


$\Delta\phi_{sp}$ is the phase difference between the $5p$ components.

(2) Examples (Zhao's book p254-255, Fig 10-7, 10-8, 10-9)

The computation for the coefficients of reflection and transmission for the internal and external cases at normal incidence is simplest and the results are illustrated in the figure.

<div style="text-align: center;"><img src="imgs/img_in_image_box_198_1248_962_1516.jpg" alt="Image" width="64%" /></div>


$n_{i}<n_{t}$ , $r_{p}>0$, $r_{s}<0$ ! $t_{p},t_{s}>0$.