At smallν, (ν is the relative motion speed between observer and light source)

 $$ \frac{\Delta\upsilon}{\upsilon_{0}}=\frac{-\vec{\nu}\bullet\vec{n}_{k}}{C}\left(\Delta\upsilon=\upsilon^{\prime}-\upsilon_{0}\right) $$ 

The spectral line width broadening due to Doppler Effect:

 $$ \Delta\upsilon=\frac{2\sqrt{2\ln2}}{c}\sqrt{\frac{kT}{m}}\upsilon_{0} $$ 