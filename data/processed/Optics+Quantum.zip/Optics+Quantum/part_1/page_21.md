the figure above, the line segment of zone 1 is the longest and there will be more states (represented by little arrow phasors) and thus larger resultant contribution. The contributions from other regions (say zone 2 and 3 etc.) have similar amount but cancelled each other. So the summation will show the contribution from zone 1 only and the light appears to take paths around stationary point.

(The above reasoning is not a rigorous proof, but used to see the superposition principle behind the Fermat's principle, and the approach is idea of Feynman path integral in quantum).

The least OPL (stationary OPL) of Fermat’s principle triggers the least action Formalism of Lagrange in classical Mechanics, and path-integral formalism by Feynman in Quantum Mechanics, which implies that the variation principles may be the Mother Nature’s fundamental Law. Since we use OPL in the principle, and the time taken for the light passes certain path will be OPL/c₀, thus the Fermat principle is also termed least time principle (It is not necessarily a minimum, a stationary point can be minimum, maximum or inflection point, but it is customary to call it least…).

## 3 -4 Two examples using Snell's equation

### (1) . Total Internal Reflection (TIR)