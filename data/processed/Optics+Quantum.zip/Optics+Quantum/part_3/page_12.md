<div style="text-align: center;"><img src="imgs/img_in_image_box_237_156_699_462.jpg" alt="Image" width="38%" /></div>


The phasor method in superposition of waves usually offers an intuitive and speedy solution of waves with same frequency and parallel  $ E_{0} $.

## 5 -1-3 Standing Waves

(Hecht, 7.1.4)

An interesting puzzle: recalling the reflection by a surface at normal incident angle in discussion of Fresnel equations:

<div style="text-align: center;"><img src="imgs/img_in_image_box_198_1053_1009_1240.jpg" alt="Image" width="68%" /></div>


In the example above when $n_t > n_i$ (external reflection), the reflected light's $\bar{E}_p$ and $\bar{B}$ field are shown in the figure. From the Fresnel equation we know $E_{p_i}$ and $E_{p_r}$ are reversed in direction (so, $\bar{B}_i, \bar{B}_r$ are in same direction, since $\vec{k}_i$ and $\vec{k}_r$ reversed, and $E \times B \to k$ for traveling