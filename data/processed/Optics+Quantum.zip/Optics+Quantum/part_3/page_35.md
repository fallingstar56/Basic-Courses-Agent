on (x',y') plane? Two planes are separated by distance Z.

For multiple light sources, we are going to divide them into axial points and off-axis points, though the definition of axis is somewhat arbitrary since the origin choice is sort of arbitrary. Suppose we chose the origin and designated the axis as the figure above.

(This part is described in detail in Zhao's book, Pg. 148-157, so only a brief discussion here)

(a) Paraxial and Far-field conditions for axial point sources

 $$ E(P)=\frac{a}{r}e^{ikr}\quad take\quad\xi_{i}=0,initial\quad phase,\quad neglect\quad e^{-i\omega t}\quad term $$ 

 $$ \begin{aligned}r&=\sqrt{z^{2}+x^{\prime2}+y^{\prime2}}=\sqrt{z^{2}+\rho^{2}}\quad\rho^{2}=x^{\prime2}+y^{\prime2}\\&\quad=z(1+\frac{\rho^{2}}{2z^{2}}\cdots)\end{aligned} $$ 

$\rho$ is the distance to origin in $(x',y')$ plane, the observing plane, under paraxial condition: $\rho^2 \ll Z^2$ and by Taylor expansion neglecting higher order terms, we get above expression of $r$.

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z(1+\rho^{2}_{/2z^{2}})}e^{ik(z+\frac{\rho^{2}}{2z})} $$ 

Paraxial condition:  $ \rho^{2} \ll z^{2} $

Then  $ \frac{a}{r} \approx \frac{a}{z} $ constant in  $ (x', y') $ plane.