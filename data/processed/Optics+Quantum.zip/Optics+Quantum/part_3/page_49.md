coherence length in those cases, we shall discuss coherence length in detail later)

<div style="text-align: center;"><img src="imgs/img_in_image_box_201_286_879_625.jpg" alt="Image" width="56%" /></div>


<div style="text-align: center;">图 4-3 迈克耳孙干涉仪产生的各种干涉条纹</div>


<div style="text-align: center;">(a)</div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;">(c)</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_212_675_838_975.jpg" alt="Image" width="52%" /></div>


<div style="text-align: center;">(2) Application of Michelson-interferometer.</div>


<div style="text-align: center;">Precise length measurement——down to fraction of  $ \lambda_{0} $</div>


The principle is same as we already discussed. As the mirror moves by  $ \lambda_{0}/2 $ (here n=1), there will be a fringe shift, i.e. each fringe will move to the position previously occupied by the adjacent fringe. One only need to count the number of such fringe movement, say N of it move across the observing position, the counting usually is achieved by a photo-electric detector.