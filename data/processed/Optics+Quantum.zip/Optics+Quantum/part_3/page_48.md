splitter).

The optical path difference for observing either equal thickness pattern or equal inclination:  $ \Delta L_{12} \approx 2d \cos \theta $.

Due to the half-wavelength difference existed between beam1, 2(one is internal, the other is external reflection by the splitter)

 $$ \begin{aligned}\rightarrow\Delta L&=m\lambda_{0}\rightarrow fringes of darkness(minima)\\&=(m+1/2)\lambda_{0}\rightarrow\text{bright fringes(maxima)}\end{aligned} $$ 

The relative distance and orientation between M1 and M2 can be precisely adjusted (i.e. we can control the thickness and wedge angle of the thin film), if both d, θ are varying the resultant interference pattern would be complicated. For simplicity, we shall restrict to the fringes of equal inclination for constant d, and fringes of equal thickness for constant θ.

But we have already discussed above situations, they are the equal thickness pattern formed by wedged spacing M1,M2,or equal inclination pattern formed by parallel M1,M2 , and nothing new here.

Thus, the patterns showed in fig4-3,4-4 in Zhao’s book,pg312 for various M1,M2’ arrangement. It is quite self-evident and need little further explanation. It can be used as an example to illustrate the equal-thickness, inclination patterns discussed earlier (the case f and j where for the large spacing between mirrors, there is lack of interference. This is happens because the optical path length difference is larger than