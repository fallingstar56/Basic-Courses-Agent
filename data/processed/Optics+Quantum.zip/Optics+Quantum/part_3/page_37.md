 $$ E(x^{\prime},y^{\prime})=\frac{a}{z}e^{ikr}=\frac{a}{z}e^{ik(r_{0}+\frac{x^{2}+y^{2}}{2z})}e^{-ik\frac{xx^{\prime}+yy^{\prime}}{z}}=\frac{a}{z}e^{ik(r_{0}^{\prime}+\frac{x^{\prime2}+y^{\prime2}}{2z})}e^{-ik\frac{xx^{\prime}+yy^{\prime}}{z}} $$ 

(ii)  $ (x',y') $ satisfy paraxial,  $ (x,y) $ satisfy both paraxial and far-field condition

i.e.

 $$ x^{2},y^{2},x^{\prime2},y^{\prime2}\ll z^{2}\quad and\quad z\gg\frac{x^{2}}{\lambda},\frac{y^{2}}{\lambda} $$ 

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z}e^{ikr_{0}}e^{-\frac{ik}{z}(xx^{\prime}+yy^{\prime})} $$ 

If  $ (x,y) $ satisfy paraxial ,  $ (x',y') $ satisfy both paraxial and far-field.

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z}e^{ikr_{0}^{\prime}}e^{-\frac{ik}{z}(xx^{\prime}+yy^{\prime})} $$ 

(5-22) is in form of plane wave, whose k is not normal to the  $ (x,y),(x',y') $ plane (or parallel to z)

 $$ k_{_{x}}=k\cos\alpha^{\prime}=-\frac{kx}{z};\quad k_{_{y}}=k\cos\beta^{\prime}=-\frac{ky}{z} $$ 

It is a plane wave along  $ r_{0} $

The  $ e^{-\frac{ik}{z}(xx' + yy')} $ phase term would be important when we come to Fourier Optics, we shall see there the  $ (x, y), (x', y') $ forms a Fourier Transform.

(2) Solving Young’s Experiment with Wavefront Distribution

 $$ S_{1}\quad(\frac{d}{2},0);\quad S_{2}\quad(-\frac{d}{2},0);\quad z=D\quad and\quad d^{2}\ll D^{2},\quad\rho^{2}=x^{\prime2}+y^{\prime2}\ll D^{2} $$ 