different focal length for the meridional rays and saggittal rays. The image of an object point will be degraded into ellipse (or line, circle) in the image plane.

## (4) Field Curvature

This is caused by that only with in the paraxial region, the Object-Image conjugate surface can be approximated by plane, more generally it is curves, so the image formed on a plane will degrade.

## (5) Distortion

The  $ M_{T} $, the transverse magnification is not a constant across the imagery plane. (Fig 6.33, Hecht)

Generally, due to aberration: Originally point object  $ \leftrightarrow $ point image, the correspondence breaks. The object point is blurred and distorted in the image, thus reduce the quality and resolution of the image. The correction of Aberration can be achieved by suitable combination of lenses, but can only minimize some of the aberrations, not all of them.

### 4 -13-2. Chromatic Aberration

This is caused by the dispersion phenomenon, the dependence of  $ n(\lambda) $ on the frequency of light, so that different  $ \omega $ of light will have different focal length.

The chromatic Aberration can be reduced by using achromatic