interference pattern:

<div style="text-align: center;"><img src="imgs/img_in_image_box_184_221_838_507.jpg" alt="Image" width="54%" /></div>


 $$ h_{m}=\frac{m\lambda_{0}}{2n} $$ 

 $ \Delta h \nearrow $ fringes moves toward the intersection

 $ \Delta h \searrow $ fringes moves away from the intersection.

For a fixed point in space, say  $ X_{0} $ in the above figure, as  $ \Delta h $ changes by every  $ \frac{\lambda_{0}}{2n} $, there will be a maxima (one interference fringe) moves across it. If a photo detector is placed at  $ X_{0} $, and measure the intensity at  $ X_{0} $; by counting the number of fringes passing through it, while there is a change of h, one can calculate  $ \Delta h $

Example: a change in height by  $ \Delta h $, the detector at  $ X_0 $, records a signal as:

<div style="text-align: center;"><img src="imgs/img_in_image_box_203_1122_743_1288.jpg" alt="Image" width="45%" /></div>


 $$ \Delta h=\frac{\lambda_{0}}{2n}\times3 $$ 

④ Newton Rings (please read it by yourself Hecht’s pg. 406 or Zhao’s pg291-293)