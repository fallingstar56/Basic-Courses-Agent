Far-field condition  $ \frac{k\rho^2}{2z} \ll \pi $ or  $ z \gg \rho^2 / \lambda $ then  $ e^{ikr} \sim e^{ikz} $. In optical frequency region, far-field condition is usually stronger than the paraxial, because of the small wavelength.

Under both paraxial and Far-field condition, the spherical wavefront on  $ (x'-y') $ becomes a plane wave.

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z}e^{ikz} $$ 

(b) For off-axis point

<div style="text-align: center;"><img src="imgs/img_in_image_box_543_624_883_730.jpg" alt="Image" width="28%" /></div>


 $$ E(x^{\prime},y^{\prime})=\frac{a}{r}e^{ikr} $$ 

 $$ r=\sqrt{z^{2}+\left(x-x^{\prime}\right)^{2}+\left(y-y^{\prime}\right)^{2}},\quad r_{0}^{\prime}=\sqrt{z^{2}+x^{2}+y^{2}},\quad r_{0}=\sqrt{z^{2}+x^{\prime2}+y^{\prime2}} $$ 

 $$ \rho_{\Delta}^{2}=(x^{\prime}-x)^{2}+(y^{\prime}-y)^{2};r=z\sqrt{1+(\frac{\rho_{\Delta}}{z})^{2}},Taylor expansion: $$ 

 $$ \begin{aligned}r=z+\frac{x^{\prime2}+y^{\prime2}}{2z}+\frac{x^{2}+y^{2}}{2z}-\frac{xx^{\prime}+yy^{\prime}}{z}+\cdots\\=r_{0}+\frac{x^{2}+y^{2}}{2z}-\frac{xx^{\prime}+yy^{\prime}}{z}\\=r_{0}^{\prime}+\frac{x^{\prime2}+y^{\prime2}}{2z}-\frac{xx^{\prime}+yy^{\prime}}{z}\end{aligned} $$ 

(i)  $ (x,y),(x',y') $ satisfy paraxial condition:

 $$ x^{2},y^{2},x^{\prime2},y^{\prime2}\ll z^{2} $$ 

 $$ \frac{a}{r}\approx\frac{a}{z} $$ 