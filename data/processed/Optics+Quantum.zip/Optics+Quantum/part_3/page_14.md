(5-6) is the expression for a standing wave. It is standing in a sense that the spatial distribution sinkx, does not move with time (the nodes and the antinodes are fixed in space, in contrast to the traveling wave); the amplitude changes with time as coswt (see figure 7.10, 7.11 in Hecht's book and Fig 7.14 shows a setup to verify the existence of the standing wave).

For an open end standing wave (i.e. only has boundary condition at one end, such as waves reflected by one mirror as shown):

 $ \frac{E_{I}}{E_{R}} \rightarrow \sqrt{\frac{1}{2}} $, the resulting standing waves in  $ kx\cos\omega t $, there is no restriction on the value of k, it can take any values.

Another important case is the light field in a cavity:

<div style="text-align: center;"><img src="imgs/img_in_chart_box_185_948_487_1141.jpg" alt="Image" width="25%" /></div>


such as the two mirror cavity separated by

L. The boundary condition would be  $ E(x=0x=L)=0 $, the resultant stable

wave is still in the form of  $ \sin kx \cos \omega t $, but with restriction on k. where

 $ 2L = m\lambda = \frac{2\pi m}{k}, m = 0, 1, 2 \cdots \cdots (5 - 7) $

This is directly from the boundary condition E(x=L)=0→kl=mπ. The reason that I wrote it in form of (5-7) is that it represents a clear physical