Seidel (monochromatic or 3rd order) Aberration is introduced by including the  $ \frac{\theta^{3}}{3!} $ term into consideration.

## (1) Spherical Aberration

Fig 6.15, 6.16 of Hecht

Basically for the rays parallel with O.A. (optical axis), or Rays from

on-axis point, they will be focused to

Different image location depending on the distance of rays from O.A.

Thus, the objective point will degrade into circles in image plane.

The spherical Aberration can be minimized by choosing combination of converging-diverging lenses or for the special pair of Image-object, the stigmatic points of the lens system.

## (2) Coma

Fig 6.21, 6.22, Hecht.

This is the aberration for the points close to O.A, its marginal rays will form image different from the principle rays. The point object will form a series of circles in image plane.

## (3) Astigmatism

Fig 6.26, 6.27, Hecht's book

For the object points far away from the O.A., it's caused by the