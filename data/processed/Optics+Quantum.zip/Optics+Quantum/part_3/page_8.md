<div style="text-align: center;"><img src="imgs/img_in_image_box_176_152_1014_835.jpg" alt="Image" width="70%" /></div>


<div style="text-align: center;">In both cases, the total intensity (energy) from contribution of two paths is not simple summation of the energy of each path:  $ I \neq I_{1} + I_{2} $, such phenomenon is called interference, and we shall see it arises from superposition of waves (not the superposition of irradiance or intensity). Whether the superposition of waves displays interference or not depends on the coherence among component waves.</div>


## 5 -1 Superposition of Waves

This is a fundamental postulate like that superposition of forces and the fields (here the wave is just E-M field anyway). The math view of the