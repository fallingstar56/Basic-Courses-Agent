This is left for the student to read themselves and derive the result yourself (Zhao's, P177-179)

## 5 -4 Amplitude Splitting Interferometer--Interference by Thin film

<div style="text-align: center;"><img src="imgs/img_in_image_box_231_537_828_918.jpg" alt="Image" width="50%" /></div>


<div style="text-align: center;">O is a point light source emitting single (or nearly single) frequency light. There will be top and bottom reflection from the two surfaces of the thin film, the reflection light can meet at certain point P and under right conditions, there will be interference at P. The top and bottom reflection by surfaces can be treated as coming from two point sources  $ O_{A}^{\prime}, O_{B}^{\prime} $  $ O_{A}^{\prime} $ : is the mirror image of O formed by surface A.  $ O_{B}^{\prime} $ : is it the mirror image of O by surface B?</div>


The answer is no for  $ O'_{B} $. The interference is between beams reflected

of the top and bottom surface. For beam2 from bottom reflection, it

actually (1) refracted at surface A ( $ T_{A}' $); (2) Reflected by surface B( $ R_{B} $);