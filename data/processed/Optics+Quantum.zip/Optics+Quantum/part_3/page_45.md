① m the fringe (max. or min. depending on  $ \lambda/2 $ difference)

 $$ 2nh\cos i_{m}=m\lambda_{0}\rightarrow\cos i_{m}=\frac{m\lambda_{0}}{2nh} $$ 

For $i=0$, corresponds to the highest m, $m_{\max}=\frac{2nh}{\lambda_{0}}$ larger m, smaller $i_{m}$.

② spacing between the circles.

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_529_505_784.jpg" alt="Image" width="20%" /></div>


 $ r_m = f \cdot \tan i_m \approx f_i_m $ For small  $ i_m $

 $$ \begin{aligned}&\therefore\Delta r_{m}=r_{m+1}-r_{m}=f\left(i_{m+1}-i_{m}\right)\\&\because\cos i_{m+1}^{\prime}-\cos i_{m}^{\prime}=\frac{\lambda_{0}}{2nh}\\&\approx(\frac{d\cos i}{di})_{i_{m}^{\prime}}(i_{m+1}^{\prime}-i_{m}^{\prime})=-\sin i_{m}^{\prime}(i_{m+1}^{\prime}-i_{m}^{\prime})\end{aligned} $$ 

i' is the angle in the film, i is the angle in the air, they are related by Snell's Law. i ≈ ni' for small I, and using the angle I, we express spacing between interference patterns:

 $$ \therefore\Delta r_{m}=nf(\frac{-\lambda_{0}}{2h\sin i_{m}}) $$ 

This shows the larger $h$, the smaller spacing between the fringes, and the larger $i_{m}$, and the smaller spacing. (The outer circles, or fringes