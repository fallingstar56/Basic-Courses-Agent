Entrance window: The image of the field stops with respect to the optical elements preceding (to the left in our conventional setup) it.

Exit window: The image of the field stops with respect to the optical elements after (to the right in out convention) it.

The field of view will be determined by the angle spanned by the center of the entrance pupil to the entrance window. Its image conjugate would be angle spanned by the center of the exit pupil to exit window.

In Summary of the image system by geometrical lenses, we see that the multiple lens system is equivalent to one single thick lens (though in practice it is straightforward to work out one lens at a time). The problem regarding to energy flow through the system is dealt with by aperture stop and field stop for on and off axis points. All these are summarize in the figure:

<div style="text-align: center;"><img src="imgs/img_in_image_box_230_1130_884_1444.jpg" alt="Image" width="54%" /></div>
