The key to the intensity distribution is the phase relation. For thin film, easy to derive: (I bet you can do this geometric problem)

 $$ \Delta L(p)=2nh\cos i\quad(5-23) $$ 

 $$ \begin{aligned}&\therefore\begin{cases}\Delta L=m\lambda_{0(vacuumwavwlength)},or,h=\frac{m\lambda_{0}}{2n\cos i}&\max(or\min)\\\Delta L=(m+1/2)\lambda_{0},or,h=\frac{(m+1/2)\lambda_{0}}{2n\cos i}&\min(or\max)\end{cases}\leftarrow\binom{n_{1}>n<n_{2}}{n_{1}<n>n_{2}}\end{aligned} $$ 

Thus, there are some straightforward conclusions we draw from (5-23)

① Whether the point on surface is maximum or minimum depends on whether there is half-wavelength difference between the reflected beams.

② At constant angle i,  $ \Delta L $ only depends on thickness h. A special case is when i=0:  $ \Delta L = 2nh $; or define  $ \Delta h = h_{m+1} - h_{m} $ (The height diff. between adjacent max. and min.), for a wedge shaped thin film:

 $$ \Delta h=\lambda_{0}/2n=\Delta x\alpha\quad(5-24) $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_237_947_935_1169.jpg" alt="Image" width="58%" /></div>


Generally as $i$ (angle) fixed, the max. or min. of interference which depends on $\Delta L$ will be contour of equal thickness. This could be used to check the relative flatness of surface down to the precision on the order of $\lambda_0$.

③ Movement of the fringes vs. change of thickness.

This is related to precision measurement of motion using change of