## (5) Entrance Window and Exit Window

In the above simple example of two lenses, determine the field stop is relative easy. For complicated lens system, as in the aperture stop case, we need a systematic way to find field stop. This part is also very similar to the relation between aperture stop to those of entrance and exit pupil. We use similar image formation to find out entrance and exit window from field stop. Also first illustrate with example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_263_641_853_977.jpg" alt="Image" width="49%" /></div>


<div style="text-align: center;">In the example, the iris is the aperture stop, and entrance pupil is the image formed by it with the optical elements to the left of it which is only  $ L_{1} $ in this case. We shall also make image of  $ L_{2} $ with respect to the optical elements to the left of it and the image is  $ L'_{2} $. The angle spanned by center of the entrance pupil to those of  $ L_{1} $ and  $ L'_{2} $ are also explicitly displayed and in this case, the  $ L'_{2} $ forms smaller angle and thus limits the field of view. The  $ L_{2} $ will be the field stop and its image  $ L'_{2} $ is called entrance window.</div>
