## 5 -1-2 Superposition of Waves with same  $ \omega $, Parallel

In this case, we can treat the vector field as scalar since the vectors are parallel:

 $$ E_{j}=E_{oj}e^{i\phi_{j}(p)}e^{-i\omega t} $$ 

 $$ E=\left[\sum_{j}E_{oj}e^{i\phi_{j}(p)}\right]e^{-i\omega t} $$ 

The superposed wave E then is:

 $$ \begin{aligned}&E=E_{o}e^{i\phi(p)}e^{-i\omega t}\quad with same frequency,and\\ &\\ &E_{o}e^{i\phi(p)}=\sum_{j}E_{oj}e^{i\phi_{j}(p)}\\ &\\ &E_{0}^{2}=\sum_{j}E_{oj}^{2}+2\sum_{i>j}\sum_{j}E_{oj}E_{oi}\cos\Big[\phi_{j}(p)-\phi_{i}(p)\Big]\\ &\\ &\tan\Big[\phi(p)\Big]=\frac{\sum_{j}E_{oj}\sin\phi_{j}}{\sum_{j}E_{oj}\cos\phi_{j}}\quad(5-5)\\ \end{aligned} $$ 

(5-4) is just (5-3), a result of superposition; the (5-5) can be relatively easily derived by phasor method.