closest zero, i.e.

 $$ \begin{aligned}&\frac{T_{1st0}^{\prime}\Delta\omega}{2}=\pi\rightarrow T_{1st0}^{\prime}=\frac{2\pi}{\Delta\omega}\\&\Delta T^{\prime}=T_{1st0}^{\prime}-T_{\max}^{\prime}=\frac{2\pi}{\Delta\omega}\\&\Delta T^{\prime}\Delta\omega=2\pi or\Delta T^{\prime}\Delta\upsilon=1\\ \end{aligned} $$ 

As we can see that as  $ \Delta\omega $ increases, the maxima increase while the width narrows. The modulation envelope as given by (5-10) is in form of wave packet, this wave packet moves at a speed of (defined by the moving speed of maximum):  $ T' = 0 \rightarrow \frac{x}{\nu_g} - t = 0 \therefore \frac{x}{t} = \nu_g $

The (5-11) is a key feature and direct result of sinc function, which is the result of adding waves with different frequencies whose distribution is a square function (In language of Fourier Transform, we will see exactly same result later).

In summary what I have demonstrated here are:

(1)A superposition of many waves with continuous freq. distribution, results in a wave packet.

(2) The wave packet moves at group velocity  $ V_{g} $

(3) The width of the wave packet (or distribution of the wave packet, for instance, at a fixed space point, x, the width of wave packet  $ \Delta T' \rightarrow $ duration of time  $ \Delta t $) depends on the width of frequency distribution  $ \Delta\omega(or\Delta v) $ with  $ \Delta T\Delta\upsilon \approx 1 $