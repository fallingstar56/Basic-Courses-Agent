Similarly, in the derivation instead of  $ \int_{\frac{\Delta\omega}{2}}^{\frac{\Delta\omega}{2}} d\omega $ we use  $ \int_{-\frac{\Delta k}{2}}^{\frac{\Delta k}{2}} dk $,

and define  $ \Delta x' = x - v_{g}t $ we get similar results  $ \Delta x' \Delta k \approx 2\pi $

Comments: In the real world, the single frequency monochromatic light does not exist, it is only a mathematical idealization. The light we encounter always have a distribution over certain freq. range (or wavelength) even the narrowest light source we have today, say a laser, its output has frequency range for about ~kHz, for narrow  $ \Delta\omega $ or  $ \Delta k $ implies larger  $ \Delta $ or  $ \Delta x $:

<div style="text-align: center;"><img src="imgs/img_in_image_box_180_739_1008_938.jpg" alt="Image" width="69%" /></div>


<div style="text-align: center;">Quasi monochromatic light</div>


The reverse relation (5-11) between  $ \Delta T\Delta\upsilon(or\Delta\omega) $ or  $ \Delta x\Delta k $ has deep physical implication in Uncertainty Principle in Quantum Mechanics, and its mathematical root is in Fourier Transform. We shall come back to this later when we discuss the Fourier Optics. (Here, an ascute student will discover that the derivation leading to relation (5-10), i.e.  $ \int_{-\frac{\Delta\omega}{2}}^{\frac{\Delta\omega}{2}} e^{iT'\omega} d\omega $ is basically a Fourier Transform of the square distribution of frequency.  $ \int_{-\infty}^{+\infty} f(\omega)e^{i(kx-\omega t)}d\omega $ where  $ f(w) $ is in form of square function shown earlier)