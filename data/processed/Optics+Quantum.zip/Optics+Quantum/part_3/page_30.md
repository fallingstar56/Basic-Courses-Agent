 $$ I_{1}\approx I_{2}\quad or\quad A_{1}\approx A_{2}=A $$ 

Then  $ I(P)=2A^{2}(1+\cos\delta)=4A^{2}\cos^{2}\frac{\delta}{2} $ (5−15)

To evaluate  $ \delta $:

 $$ \delta=\phi_{1}(P)-\phi_{2}(P)=\frac{2\pi}{\lambda}(r_{1}-r_{2}) $$ 

So for every points in the field, by knowing the phase difference from  $ (5-16) $, we know the intensity by  $ (5-15) $ or  $ (5-12) $. We shall concentrate on the maxima and minima of the interference pattern

Then it is easy to see, for

 $$ \left\{\begin{aligned}r_{1}-r_{2}&=m\lambda\quad&m&=0,\pm1,\pm2\cdots,I(P)is\quad&\max imum\\ r_{1}-r_{2}&=(m+\frac{1}{2})\lambda\quad&m&=0,\pm1,\pm2\cdots,I(P)is\quad&\min imum\end{aligned}\right. $$ 

The contour of points P’s satisfying the above relations are hyperbola surfaces, with Q₁, Q₂ at their foci (S₁, S₂ in the Fig 9.3 in Hecht’s):

<div style="text-align: center;"><img src="imgs/img_in_image_box_211_1076_930_1336.jpg" alt="Image" width="60%" /></div>


The interference pattern on an observing screen would generally be hyperbolic curves, i.e.