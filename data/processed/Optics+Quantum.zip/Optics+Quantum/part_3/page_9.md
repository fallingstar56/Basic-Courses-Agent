principle of superposition is originated from the wave equation discussed earlier.

 $$ \nabla^{2}U=\frac{1}{V^{2}}\frac{\partial^{2}u}{\partial t^{2}} $$ 

If the v is independent of U then:  $ U = \sum_{i} a_{i} U_{i} $ is the solution of the wave equation provided  $ U_{i} $ is the solution,  $ a_{i} $ is a coefficient.

The field (or waves) shall be added to get the total field (wave), and the system response to the field will be treated linear as long as the field is not too strong, this is the domain of linear optics.

## 5 -1-1 Superposition principle in linear optics

A general light wave can be written as:  $ E = E_0 e^{i\phi(p)} e^{-i\omega t} $ where  $ E_0 $ the amplitude;  $ \phi(p) $ the spatial phase (including the initial phase);  $ \omega t $ the oscillation with time or temporal phase.

For plane wave:  $ \phi(p) = \vec{k} \cdot \vec{r} + \phi_0 $ spherical wave:  $ \phi(p) = kr + \phi_0 $

However, common detectors only detect the irradiance (or intensity) of the light, which we know:  $ I = \left\langle E^2 \right\rangle_T \propto E_0^2 $

Since we are interested in the relative irradiance in most cases, and we

shall let: (as if chosen proper unit)

 $$ I=\left|E\right|^{2}=E_{0}^{2} $$ 