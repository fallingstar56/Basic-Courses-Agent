taken as constant (dispersion effect is small within this range), then:

 $$ \begin{aligned}&\int_{\frac{\Delta\omega}{2}}^{\frac{\Delta\omega}{2}}e^{i(\frac{x}{V_{g}}-t)\omega}d\omega,\quad Set T^{\prime}\equiv(\frac{x}{V_{g}}-t)\\ &=\frac{1}{iT^{\prime}}[e^{iT\cdot\frac{\Delta\omega}{2}}-e^{-iT\cdot\frac{\Delta\omega}{2}}]\\ &=\frac{2\sin(T^{\prime}\frac{\Delta\omega}{2})}{T^{\prime}}\cdots\\ &=\Delta\omega\sin c(T^{\prime}\frac{\Delta\omega}{2})\cdots\cdots(5-10)\\ \end{aligned} $$ 

 $$ \sin c(x)\equiv\frac{\sin x}{x} $$ 

 $$ E=\frac{\sin(T^{\prime}\frac{\Delta\omega}{2})}{\frac{T^{\prime}}{2}}E_{0}e^{i(k_{0}x-\omega_{0}t)} $$ 

The modulation envelope given by  $ (5-10) $ has the shape:

<div style="text-align: center;"><img src="imgs/img_in_image_box_178_926_980_1238.jpg" alt="Image" width="67%" /></div>


It has maximum at T' = 0, maximum =  $ \Delta \omega $ It has 0 value when T' \neq 0, and  $ \frac{T' \Delta \omega}{2} = m \pi (m = 0, \pm 1 \cdots) $

The width of band is defined as the space between the maximum and