Both the source and receiving field plane satisfy paraxial condition.

 $$ E_{1}(x^{\prime},y^{\prime})=\frac{a}{D}\exp[ik(\cdots)]\exp(-\frac{ik}{D}\frac{d}{2}x^{\prime}) $$ 

 $$ E_{2}(x^{\prime},y^{\prime})=\frac{a}{D}\exp[ik(\cdots)]\exp(\frac{ik}{D}\frac{d}{2}x^{\prime}) $$ 

 $$ E(x^{\prime},y^{\prime})=\frac{a}{D}\exp[ik(\cdots)]2\cos(\frac{kd}{2D}x^{\prime}) $$ 

 $$ I(x^{\prime},y^{\prime})=4A^{2}\cos^{2}(\frac{k d}{2D}x^{\prime}),A=\frac{a}{D} $$ 

Same as we derived earlier, the result in (5-19).

The derivation also shows that under paraxial approximation, the I(x',y') only depends on x', i.e. the interference pattern are lines along y direction, which confirms what we stated earlier that under paraxial conditions, the hyperbolic curves in the two-point sources interference pattern  $ \sim $ straight lines.

(3) The interference pattern by two plane waves

<div style="text-align: center;"><img src="imgs/img_in_image_box_261_1242_562_1501.jpg" alt="Image" width="25%" /></div>
