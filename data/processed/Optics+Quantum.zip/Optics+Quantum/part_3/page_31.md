<div style="text-align: center;"><img src="imgs/img_in_image_box_177_150_1013_356.jpg" alt="Image" width="70%" /></div>


Under paraxial condition, i.e.  $ x^{12}, y^{12} \ll D^{2} $, then the curves are approximately close to straight lines.

## 5 -3-2 Young's Experiment

<div style="text-align: center;"><img src="imgs/img_in_image_box_217_641_1010_981.jpg" alt="Image" width="66%" /></div>


Paraxial condition:  $ d^{2} \ll D^{2}, X'^{2}, Y'^{2} \ll D^{2} $

Let's first treat the ideal case, where S, S1, S2 are treated as point sources (As we shall see later, that the sizes of S consisting of incoherent sources will give rise to spatial Coherence; the sizes of S₁, S2 will lead to the problem of diffraction).

The cleverness of Young’s setup is to eliminate the effect of random phase fluctuation in conventional incoherent light sources. For two incoherent light sources, the  $ \delta(P) $, phase difference at P, consists of