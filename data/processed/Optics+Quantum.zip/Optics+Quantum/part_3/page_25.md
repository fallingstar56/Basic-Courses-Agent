The interference is essentially a redistribution of energy, creating peaks and valleys (maximum and minimum) in intensity over the space, but the average irradiance o $\bar{I}$ over the space is $I_{1}+I_{2}$, since $<\cos\delta(p)>_{\text{space}}=0$. Interference does not violate the conservation of energy.

## (b) Contrast (visibility)

 $$ \gamma\equiv\frac{I_{\max}-I_{\min}}{I_{\max}+I_{\min}} $$ 

For the two sources case, substitute  $ I_{max} $  $ I_{min} $

 $$ \gamma=\frac{2\sqrt{I_{1}I_{2}}}{I_{1}+I_{2}} $$ 

 $$ I_{0}\equiv I_{1}+I_{2} $$ 

 $$ I=I_{0}(1+\gamma\cos\delta) $$ 

γ is a measure the contrast between maximum and minimum in the intensity distribution in interference. Larger γ means larger contrast, easier to observe interference.

 $$ \begin{aligned}&\gamma\rightarrow1\qquad if\qquad I_{min}\quad\rightarrow0\\ &\\ &\gamma\rightarrow0\qquad if\qquad I_{min}\quad\rightarrow I_{max}\\ \end{aligned} $$ 

For the two coherent sources,  $ \gamma \to 1 $ (or  $ I_{\min} \to 0 $) if the amplitude of the two sources are equal:  $ E_{01} = E_{02} $ ( $ I_1 = I_2 $).