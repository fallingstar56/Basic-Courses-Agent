field can be derived from Maxwell equation:

 $$ \nabla\times\boldsymbol{E}\propto\frac{-\partial\boldsymbol{B}}{\partial t}\Rightarrow\boldsymbol{B}\propto-\cos kx\sin\omega t $$ 

Thus what are nodes for the E field (sinkx=0), are antinodes for B (coskx=1); what are antinodes for E are nodes for B. This is the relation for  $ \vec{E}, \vec{B} $ of standing waves, and this explains the puzzle stated at the beginning of this section.

Not only in the light (such as light field in a cavity, which is fundamental in laser), standing wave also plays crucial roles in other waves, such as sound waves. Most music instruments are based on it. Also if you ever tried to entertain your friends by inhaling helium (He) gas, your sound would be much higher pitched (high frequency). Can you explain this using what you have learned?

## 5 -1-4 The addition of waves of different frequency

(Hecht, 7.2)

## (a) Beats

Simple case: two waves with different frequency, travel in same direction, parallel E field, same  $ \vec{E}_{0} $

 $$ \omega_{1}=\omega_{0}+\Delta\omega\qquad\omega_{2}=\omega_{0}-\Delta\omega\qquad k_{1}=k_{0}+\Delta k\quad k_{2}=k_{0}-\Delta k\quad(true for\Delta\omega<< $$ 