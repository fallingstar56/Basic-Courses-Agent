 $$ \delta(P)=\frac{kd}{D}x^{\prime}\quad(5-17) $$ 

\begin{array}{l} \text{From (5-12)} \quad I(P)=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}} \cos(\frac{kd}{D}x') \end{array}

I1 ≈ I2 under paraxial condition, d2 ⇔ D2 ,

Then  $ I_{1} \approx \left( \frac{A_{1}}{r_{0}} \right)^{2} \approx I_{2} $,  $ r_{0} $ is the center of  $ \overline{S_{1}S_{2}} $ to P.

 $$ I(P)\approx4I_{1}\cos^{2}(\frac{kd}{2D}x^{\prime}) $$ 

 $$ \begin{aligned}\triangle L=&\frac{d}{D}x^{\prime}=m\lambda,m=0,\pm1\cdots,\rightarrow\quad m^{th}\quad\max ima\\=&(m+\frac{1}{2})\lambda;m=0\pm1\rightarrow\quad m^{th}\quad\min nima\end{aligned} $$ 

The interference pattern by double slits is something like:

## ……

The spacing between the adjacent maxima (or minima) is given by:

 $ \frac{kd}{D}\Delta x' = 2\pi $, and this will give:

 $$ \triangle x^{\prime}=\frac{\lambda D}{d}\approx\frac{\lambda}{\triangle\theta} $$ 