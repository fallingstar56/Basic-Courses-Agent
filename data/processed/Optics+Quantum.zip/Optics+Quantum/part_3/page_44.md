## 5 -4-2 Fringes of equal inclination

Such interference is when we observe it at infinite distance from the film. Basically this is interference by two parallel beams, which can be collected by a lens on its back focal plane.

<div style="text-align: center;"><img src="imgs/img_in_image_box_177_426_472_697.jpg" alt="Image" width="24%" /></div>


 $$ \Delta L=(ARC)-(AB)=2nh\cos i $$ 

For the simple case where h is constant, the interference pattern will only depend on the angle i, the fringes on the focal plane  $ \Sigma $ would be concentric circles.

<div style="text-align: center;"><img src="imgs/img_in_image_box_194_960_679_1509.jpg" alt="Image" width="40%" /></div>
