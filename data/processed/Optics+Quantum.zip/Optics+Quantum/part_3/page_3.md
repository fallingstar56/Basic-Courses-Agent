Knowing the cardinal points, determine the pupils and windows, then for any give object, we can find out the location and size of the image; estimate how bright the image will be; and what the field of view is.

## 4 -13 Aberration

Though this is very important in practical applications, such as optical design and engineering, but its complication and details in technique are far beyond the scope of this course, and also beyond my modest ability.

So I’ll choose only to briefly introduce the concept of Aberration and the somewhat details are left for you to read in the book. (Hecht, 6.3, Zhao’s pg106-119)

### 4 -13-1. Monochromatic Aberration

This is introduced while the paraxial Approximation breaks down, by those non-paraxial rays and rays from off-axis points.

From the earlier analysis, we essentially apply  $ n_{i_{1}}\theta_{i_{1}}=n_{i_{1}}\theta_{i_{1}} $ where assume  $ \theta $ is small and  $ \sin\theta\approx\theta $. For oblique rays, this is not exact, and

 $$ \sin\theta=\theta-\frac{\theta^{3}}{3!}+\frac{\theta^{5}}{5!}\cdots\cdots $$ 

(Taylor expansion)