5-2-1. Interference – General Considerations

1 $ \begin{array}{c}E_{1}\\E_{2}\\p\end{array} $

2 $ \begin{array}{c}E_{1}\\E_{2}\\p\end{array} $

3 $ \begin{array}{c}E_{1}\\E_{2}\\p\end{array} $

We have seen that in the superposition requires  $ E = \sum_{j} E_j $, but not necessarily  $ I = \sum_{i} I_i $.

From (5-3) in the previous section, we have:

 $$ I(P)=\sum_{i}E_{oj}^{2}+2\sum_{j}\sum_{i}\bar{E}_{oj}\bar{E}_{oi}\overline{\cos[\phi_{j}(p)-\phi_{i}(p)]} $$ 

In this relation, the bar over the cosine term means time average, which is the case in realistic measurement of intensity of the light.

The interference requires that the cross terms are not vanishing, we shall see this requires the condition of coherence (next section). First let see some direct conclusion from the intensity formula:

(a) For interference between two sources:

 $$ I=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}\cos\delta(P) $$ 

 $$ \delta(P)=\phi_{1}(P)-\phi_{2}(P) $$ 

 $$ I_{\max}=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}=(E_{O1}+E_{O2})^{2}>I_{1}+I_{2} $$ 

 $$ I_{\min}=I_{1}+I_{2}-2\sqrt{I_{1}I_{2}}=(E_{O1}-E_{O2})^{2}<\left|I_{1}-I_{2}\right| $$ 