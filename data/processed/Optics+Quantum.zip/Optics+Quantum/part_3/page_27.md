change with time, at least within the time interval of the measurement).

For condition (2), if we have different frequencies in hand, it effectively introduces a time varying phase factor into  $ \delta(\mathrm{P}), ((\Delta\omega)t) $, and time average may become 0

For condition (3), to guarantee that  $ \bar{E}_i \cdot \bar{E}_j \neq 0 $, it is obvious necessary to have parallel component. In the superposition of two perpendicular

<div style="text-align: center;"><img src="imgs/img_in_image_box_555_553_681_660.jpg" alt="Image" width="10%" /></div>


vectors, E₁, E₂, E = E₁ + E₂ \quad \text{‘‘} \quad \text{, clearly}

|E|^{2} = |E_1|^{2} + |E_2|^{2} \quad \text{no cross term, no interference.}

\quad \text{The above are ideal coherent conditions which may not be satisfied}

\quad \text{rigorously in practice, since the light sources are only}

\quad \text{quasi-monochromatic, the phases cannot be stationary infinitely.}



The modified Coherent Condition:

(1) nearly same frequency

(2)  $ \triangle\phi_{i}(P)+\triangle\xi_{i} $ is stationary over the detection period

(3)  $ \bar{E} $ has parallel component

Now the phase difference is:  $ \delta = \Delta \phi(p) + \Delta \omega t + \Delta \xi $. The conditions (1), (2) that make nonzero cross term will depend on the detection period,  $ \tau $ (the time that intensity is averaged). During the time period of average, if  $ \tau \ll 2\pi / \Delta \omega $ or  $ \Delta \omega \tau \ll 2\pi $, the time varying of frequency difference is