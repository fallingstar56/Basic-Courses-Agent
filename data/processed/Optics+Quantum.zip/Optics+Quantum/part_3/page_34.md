$\Delta\theta=\frac{d}{D}$ is the angle spanned by the center of receiving screen with $S_{1}$, $S_{2}$.

## 5 -3-3 A more Strict and Systematic Treatment

## (1) Wavefront distribution (Zhao's P148-158)

As stated earlier, the key question in interference is to evaluate  $ \delta(P)=\phi_{j}(P)-\phi_{i}(P) $ then we have to know  $ \phi_{i}(P) $, the general expression for phase distribution of a point source over space. Previously, we state that wavefront is a constant phase surface, here we generalize it referring to any surface in the field, and we are interested in the field distribution E (P) across this surface.

Any light sources can be visualize as consisting of many point sources, so the basic question would be , what is E(P) on a wavefront in a field created by point sources.

<div style="text-align: center;"><img src="imgs/img_in_image_box_188_1093_866_1459.jpg" alt="Image" width="56%" /></div>


<div style="text-align: center;">O, Q,…… are point sources on (x,y) plane, what are the field distribution</div>
