$\triangle\phi(P)+\triangle\xi$ , where $\triangle\xi$ , the initial phase difference randomly change , and $<\cos\delta>_{T}=0$ , no interference. In the Young’s Experiment, such random initial phase change is cancelled out. i.e.:

 $$ E(S_{1})=A_{1}e^{i(k\overline{s}\overline{s}_{1}+\xi)}e^{-i\omega t}\quad A_{1}=\left.\frac{A_{s}}{\overline{S S}_{1}}\right. $$ 

 $$ E(S_{2})=A_{2}e^{i(k\overline{s}\overline{s}_{2}+\xi)}e^{-i\omega t}\quad A_{2}=\left.\frac{A_{s}}{\overline{S}\overline{S}_{2}}\right. $$ 

 $$ E_{S1}(P)=\frac{A_{1}}{r_{1}}e^{i[k(\overline{S S_{1}}+r_{1})+\xi]}e^{-i\omega t} $$ 

 $$ E_{S2}(P)=\frac{A_{2}}{r_{2}}e^{i[k(\overline{S}\overline{S}_{2}+r_{2})+\xi]}e^{-i\omega t} $$ 

Though  $ \xi $ is a random number,  $ \delta(P) $ is not depending on it, i.e.  $ S_{1}, S_{2} $ are coherent.

Using the figure above, we can prove

 $$ I(x^{\prime},y^{\prime})=4A^{2}\cos^{2}(\frac{kd}{2D}x^{\prime}) $$ 

A is the amplitude at point P by  $ S_{1} $ or  $ S_{2} $ (they are equal under paraxial condition).

 $$ \delta(P)=k(r_{1}-r_{2})=k_{\triangle}L\qquad\quad\mathrm{(H e r e,~w e~t a k e~\overline{{S S}}_{1}=\overline{{S S}}_{2}~)} $$ 

 $$ \triangle L=r_{1}-r_{2}\approx d\sin\theta_{m}\doteq d\theta_{m}\quad for\quad x^{\prime}\ll D $$ 

 $$ \theta_{m}\approx x_{}^{\prime}/_{D}\rightarrow\triangle L=\frac{d}{D}x_{}^{\prime} $$ 