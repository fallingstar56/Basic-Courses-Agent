In the derivation, we hold  $ v_g = const $, which is an approximation, true for  $ \Delta \omega r \Delta k $ is small. If  $ \Delta \omega $ is large then  $ v_g $ is no longer a constant

Example: Femeto second (fs $10^{-15}$ second) pulse: duration of wave of wave packet in time is~ $fs$. Is a superposition of waves with freq. distribution on the order of $\Delta T\Delta v\approx1\rightarrow\Delta v\approx10^{15}$ HZ

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_554_319_639.jpg" alt="Image" width="7%" /></div>


When it propagate along a dispersive media (i.e.  $ \frac{dn}{dk} \neq 0or\frac{dn}{d\omega} \neq 0 $) the width will broadened:

<div style="text-align: center;"><img src="imgs/img_in_image_box_180_841_963_1000.jpg" alt="Image" width="65%" /></div>


The broadening is due to different  $ v_{g} $ in a dispersive media:

<div style="text-align: center;"><img src="imgs/img_in_image_box_192_1117_586_1323.jpg" alt="Image" width="33%" /></div>


The broadening of wave packet

With the superposition of many waves with diff. freq. we conclude our discussion on this issue. However there are other situations, namely: