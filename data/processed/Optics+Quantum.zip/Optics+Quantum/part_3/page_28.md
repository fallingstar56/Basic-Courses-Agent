small and the average will not be zero, that is the reason for small frequency difference as required by (1);  $ \Delta\phi(p) $ the phase difference due to spatial difference usually can be maintained at fixed value by fix the OPL the light travels so that will not be a problem here;  $ \Delta\xi $ depends on the nature of the light source, it has to be stationary within detection period  $ \tau $.

The detection period τ has to be longer than the time resolution (response time) of the detectors  $ t_{res} $ (it is the smallest time interval allowed by the detector to make meaningful measurement), i.e.

 $ \tau > t_{res} \quad (t_{res} \sim 10^{-1} \text{s for eye}, 10^{-9} \text{s for PMT the photo multiplier tube}) $

In the visible light region, the time period of optical oscillation is on the order of  $ T = \frac{2\pi}{\omega} \sim 10^{-14} - 10^{-15} s $, and  $ \tau \gg T $. Thus the average  $ I = <E^2> \tau $, the cos $ \omega $ term is averaged out in the process, that is the reason we have  $ I \propto E_0^2 $.

For condition (1) with different frequency components add up, we have seen that will result in modulation of the envelope of amplitude .(wave packet or beat), the amplitude envelope varies approximately with  $ \cos(\triangle\omega t) $, for small  $ \triangle\omega $,  $ \tau < \frac{2\pi}{\triangle\omega} $, then within the detection time  $ \cos(\triangle\omega t) $ varies little and will not average to zero. For condition (2), the stability of the phase difference, the  $ \triangle\xi_{i} $ term, is