In vacuum, n=1,  $ \frac{dn}{dk}=0 $,  $ V_g = C_0 $, group and phase velocity are same

But in Optical media, with dispersion ( $ \frac{dn}{dk} \neq 0 $),  $ V_g \neq v $

(b) Adding more waves with diff. freq.

Let's study a case where the freq. distribution is given by a square function:

 $$ \begin{aligned}&\begin{bmatrix} \\{{{\frac{\Delta W}{2}}}}&{{{+\frac{\Delta W}{2}}}} \\{{{\frac{1}{2}}}}&{{{0}}} \\\end{bmatrix}\\ \end{aligned} $$ 

Center freq.  $ \omega_{0} $,  $ k_{0} $

Width of distribution  $ \triangle\omega,\triangle k $

Then the superposition of waves with freq. distribution given by the above is:

 $$ \begin{aligned}&E=\sum E_{0}\delta\omega e^{i[(k_{0}+k)x-(\omega_{0}+\omega)t]}\quad&-\frac{\Delta k}{2}\leq k\leq\frac{\Delta k}{2}\\&=E_{0}e^{i(k_{0}x-\omega_{0}t)}\int_{\frac{\Delta\omega}{2}}^{\frac{\Delta\omega}{2}}e^{i(kx-\omega t)}d\omega\quad&-\frac{\Delta\omega}{2}\leq\omega\leq\frac{\Delta\omega}{2}\\ \end{aligned} $$ 

There are some explanations of the symbols I used above which is slightly different from the conventional use through this note. Here $E_0$ is the density of the field (it is in unit of field/frequency, such as Volt. Sec. /meter) the $E_0\delta\omega$ is the field strength within small interval $\delta\omega$. k is a small variation around $k_0$ (so is the $\omega$), so we have the following relation: $k=\omega/V_g$. For the small $\Delta\omega$ or $\Delta k$, $V_g$ can be