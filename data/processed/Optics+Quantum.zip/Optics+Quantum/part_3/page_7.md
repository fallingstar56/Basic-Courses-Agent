# Wave Optics Interference, Interferometer, Coherence Diffraction- Fourier Optics

Fundamental principle:

Superposition of waves

Central problem: (the kernel question)

Phase distribution over a wave front.

We shall first look at interference (Hecht chap7.1-7.2, Zhao's Chap2 section 1-4), focusing on the principle of superposition illustrating the importance of phase relation in interference, and the evaluation of phase distribution over a wavefront, the using Young's Experiment as example. Later we shall look into some interferometer devices (Zhao's, chap3; Hecht 9.3, 9.4, 9.6) and the important concept of coherence.

## Chapter 5 Interference, Interferometer and Coherence

Let's start this important chapter with some examples to illustrate the phenomena we call interference, which is the hallmark behavior of wave.