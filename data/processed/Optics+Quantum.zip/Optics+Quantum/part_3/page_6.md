doublet, as discussed in Hecht's 6.3.2.

The reflecting mirrors (planar or spherical) do not have chromatic aberration; since in those cases the focal-length does not depend on n (see Hecht's 5.4)