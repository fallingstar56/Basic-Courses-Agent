ω0)

 $$ \begin{aligned}&E=E_{0}\Big\{e^{i\left[\left(k_{0}+\Delta k\right)x-\left(\omega_{0}+\Delta\omega\right)t\right]}+e^{i\left[\left(k_{0}-\Delta k\right)x-\left(\omega_{0}-\Delta\omega\right)t\right]}\Big\}\\&=E_{0}\Big[e^{i\left(\Delta k x-\Delta\omega t\right)}+e^{-i\left(\Delta k x-\Delta\omega t\right)}\Big]e^{i\left(k_{0}x-\omega_{0}t\right)}\\&=E_{0}\bullet2\cos(\Delta k x-\Delta\omega t)e^{i\left(k_{0}x-\omega_{0}t\right)}\\ \end{aligned} $$ 

E is a wave propagating like a plane harmonic wave $e^{i(k_0x-\omega_0t)}$ , but with a modulation on its amplitude(also called envelop) $\cos(\Delta kx-\Delta\omega t)$. The energy will be in forms of:

 $$ \cos^{2}(\Delta kx-\Delta\omega t)=\frac{1+\cos(2\Delta kx-2\Delta\omega t)}{2} $$ 

The  $ 2\Delta\omega = \omega_2 - \omega_1 $ is called beat frequency.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_241_814_1029_1245.jpg" alt="Image" width="66%" /></div>


The traveling speed of this modulation envelop is Group Velocity:

 $$ \begin{aligned}&\therefore V_{g}=\frac{d\omega}{dk}=\frac{C_{0}}{n(k)}-\frac{C_{0}}{n^{2}}k\frac{dn}{dk}\\ &=\frac{C_{0}}{n}(1-\frac{k}{n}\frac{dn}{dk})\\ \end{aligned} $$ 