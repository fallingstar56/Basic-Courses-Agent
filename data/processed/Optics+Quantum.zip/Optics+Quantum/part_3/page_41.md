<div style="text-align: center;"><img src="imgs/img_in_image_box_285_155_488_370.jpg" alt="Image" width="17%" /></div>


beams) A.

To observe the interference pattern, we can use optical elements to make image formation of the interference pattern as the figures above shown. Since the equal optical path length for all the rays between object-image (Fermat's principle), the image formation process will not introduce any extra phase difference, and the image pattern would be a (magnified or shrink) copy of the same interference pattern.

## 5 -4-1 Fringes of Equal Thickness

This is the interference pattern on the surface of a thin film.

<div style="text-align: center;"><img src="imgs/img_in_image_box_310_1041_705_1278.jpg" alt="Image" width="33%" /></div>


 $ \delta(p) $ is the phase difference at point p on the surface created by two beams. (or beams from  $ Q'_{A}, Q'_{B} $, the image of Q):

 $$ \delta(p)=k_{0}\Delta L(p)\quad\left(\pm\pi\quad if\quad\begin{array}{c}n_{1}>n<n_{2}\\ n_{1}<n>n_{2}\end{array}\right) $$ 

 $$ \Delta L(p)=(Q A)+(A B P)-(Q P). $$ 