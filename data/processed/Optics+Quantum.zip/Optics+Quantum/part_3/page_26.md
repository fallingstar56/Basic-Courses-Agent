### 5 -2-2. Conditions for Coherence

The sources are considered coherent if:

(1) Phase term  $ <\cos\delta(p)>_{T}=\frac{1}{T}\int_{t}^{t+T}\cos[\delta(p)]dt\neq0 $ i.e. have stationary phase difference  $ \delta(P)=\phi_{j}(P)-\phi_{i}(P) $

(2) Same frequency

(3) Have parallel  $ \bar{E} $ components.

The above conditions are needed for nonzero cross terms in intensity formula. The sources satisfying the above conditions are called Coherent (means well-correlated)

For condition (1),  $ \delta(\mathrm{P}) $ consists two parts:

 $$ \delta(P)=\phi_{j}(P)-\phi_{i}(P)+\xi_{j}-\xi_{i} $$ 

 $ \phi_j(P) - \phi_i(P) $ is the phase difference due to space distribution (such as  $ \vec{k} \cdot (\vec{r}_1 - \vec{r}_2) $ for plane wave, or  $ k(r_1 - r_2) $ for spherical wave) and  $ \xi_j - \xi_i $ is the phase difference due to initial phase. There should also be time dependent part  $ \omega t $, but under same frequency condition, that is cancelled.

The spatial part, for fixed arrangement of sources and observer,  $ \phi_j^0(P) - \phi_i^0(P) $ usually has fixed relations;  $ \Delta\xi = \xi_j - \xi_i $ will however depend on the nature of the light source, it could be random, and the stationary  $ \delta(P) $ requires that  $ \Delta\xi $ has to be stable too (stable means do not