(a) We showed superposition of harmonic waves with diff. freq.→wave packet of certain shape.

Reversely, for an arbitrary function, we can decompose it into harmonic components→Fourier analysis and Fourier Transform.

(b)We studied the superposition of waves with  $ \vec{E} $ parallel, the superposition of perpendicular  $ \vec{E} $ fields will result in so called polarization states of the field, depending on the frequency we may have:

 $$ \left\{\begin{aligned}same\_{o}\rightarrow linear,circular,elliptical\_{p}olarized\_{l}ight\\  diff.\omega\rightarrow Lessajous\_{F}igure\end{aligned}\right. $$ 

We shall treat these topics in the later classes. In the treatment of interference, we only need to consider the superposition of waves with parallel  $ \vec{E} $ field, so in this chapter, we can temporarily forget the vector nature of the light field.

## 5 -2 Interference and Coherence

In the following parts, I shall focus on simpler case that all fields are along the same direction so that I can use scalar instead of vector to represent the field. The vector nature of the field will be considered when we treat polarization.