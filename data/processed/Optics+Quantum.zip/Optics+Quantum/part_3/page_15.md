picture, as I shall demonstrate below.

From the superposition of wave, the field inside the cavity bounded by M1, M2 is the superposition of the incident wave and the reflected ones (multiple times) by M1 and M2. Another equivalent way to look at this 2-Mirror, L length cavity is taking it as circle with 2L periphery, the waves travels along in circle. The only stable ones are the waves that after one round passage overlap exactly with the original ones i.e.  $ 2L = m\lambda $,  $ m = 0,1,2\cdots\cdots $ or  $ \_2nL = m\lambda_0 $ in terms of Optical Path length.

<div style="text-align: center;"><img src="imgs/img_in_image_box_232_697_392_849.jpg" alt="Image" width="13%" /></div>


These waves are standing waves; for those do not satisfy (5-7) the superposition will result in a null field (E=0). For length=L cavity, the standing waves of first 3 lowest m (called modes) are:

<div style="text-align: center;"><img src="imgs/img_in_image_box_211_1089_419_1153.jpg" alt="Image" width="17%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_202_1181_414_1274.jpg" alt="Image" width="17%" /></div>


 $$ m=1\quad or\quad k=\frac{\pi}{2},\lambda=2L $$ 

 $$ m=2\quad or\quad k=\frac{\pi}{2L}\quad\lambda=L $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_1293_410_1377.jpg" alt="Image" width="18%" /></div>


 $$ m=3\quad\text{or}\quad k=\frac{\pi}{3L}\quad\lambda=\frac{2L}{3} $$ 

The standing waves have form of (5-6), and then the expression for the B