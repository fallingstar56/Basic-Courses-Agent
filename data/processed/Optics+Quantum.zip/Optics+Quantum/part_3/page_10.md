Our common sense sometimes misleadingly makes us to perceive that in the cases of multiple light sources, the resultant irradiance is  $ I = \sum_{i} I_{i} $

This is the case for illumination by incoherent sources such as light bulbs, candles, etc. However,  $ I = \sum_{i} I_{i} $ is generally wrong, as demonstrated by the two examples at the beginning of the chapter. It is the summation of the field E, not I that is physically correct, as stated in the principle of superposition:

<div style="text-align: center;"><img src="imgs/img_in_image_box_288_661_523_784.jpg" alt="Image" width="19%" /></div>


Suppose we have many different field sources contributing to a point p, then from superposition principle, the total field at p is:

 $$ \vec{E}_{p}=\sum_{j}\vec{E}_{j}(p)=\sum_{j}\vec{E}_{0j}e^{i\phi_{j}(p)}e^{-i\omega_{j}t} $$ 

We shall first study simpler case where different components have same frequency and in such case  $ \omega_{j} = \omega $, the intensity can be easily computed with (5-1):

 $$ I=|\vec{E}|^{2}=(\sum_{j}\vec{E}_{j})\cdot(\sum_{k}\vec{E}_{k})=\sum_{j}E_{0j}^{2}+2\sum_{j}\sum_{k<j}\vec{E}_{0j}\cdot\vec{E}_{0k}\cos[\phi_{j}(p)-\phi_{k}(p)] $$ 

The first term on the right hand side  $ \sum_{j} E_{0j}^{2} = \sum_{j} I_{j} $ is the summation of intensity. There is an extra cross term that will give rise to interference.