E-M waves). So it seems if we superpose the incident and reflecting waves, $E = \vec{E}_i + \vec{E}_r$ diminishes, while $B = \vec{B}_i + \vec{B}_r$ increases. Recall that for traveling waves, $E = cB$, there seems existing an apparent paradox. The reason is that the superposition of two traveling waves travelling in opposite directions will result in a standing wave, not a traveling wave.

The general solution to the wave equation takes form of  $ \psi(x,t)=C_{1}f(x-vt)+C_{2}g(x+vt) $

So when two waves travel in opposite direction, the summation also satisfies the wave equation. For this case, the resultant wave will be a standing wave. (I follow the Hecht's derivation and use sines for wave; if you use cosines or Euler formula, same results)

For the wave propagates along -x:  $ E_{I}=E_{0I}\sin(kx+\omega t+\varepsilon_{I}) $

The reflected wave propagates along +x:  $ E_{R}=E_{0R}\sin(kx-\omega t+\varepsilon_{R}) $

The Reflecting Mirror at x=0, the boundary condition at x=0, requires  $ E = E_{I} + E_{R} = 0 $

Let’s consider the simple case where  $ r=1 $ or  $ E_{0I}=E_{0R} $, we can set  $ \varepsilon_I=0 $ (which is arbitrary anyway, we always have the freedom to set the initial phase of ONE wave as zero), and the  $ E_I+E_R\big|_{(x=0)}=0\to\varepsilon_R=0 $ and the superposition of wave is:

 $$ \begin{aligned}&E=E_{0}\left[\sin(kx+\omega t)+\sin(kx-\omega t)\right]\\&=2E_{0}\sin kx\cos\omega t\\ \end{aligned} $$ 