LectureNote on GP3

By Shuo Jiang

Tsinghua University

## Contents

Chapter 1 General Properties of Wave ..... - 3     
1-1 Physical Feature: ..... - 3     
1-2 Mathematical Description of Wave-----Differential Wave Equation ..... - 3     
1-3 Harmonic waves (a quick summary) ..... - 5     
1-4 Phase and Phase velocity ..... - 11     
1-5 Superposition Principle ..... - 12     
1-6 Complex Representation and Phasors ..... - 14     
1-7 Plane waves and Spherical waves ..... - 21     
1-8 Doppler Effect: ..... - 23     
Chapter2 Light as Electro-Magnetic Wave ..... - 32     
2-1 Maxwell Equation and Electro-Magnetic Wave ..... - 32     
2-2 Speed of light ..... - 34     
2-3 Transverse Wave ..... - 36     
2-4 Energy carried by E-M wave ..... - 38     
2-5 Momentum of E-M Field ..... - 41     
2-6 Photons ..... - 45     
2-7 Radiation (light) sources——A classical treatment ..... - 45     
2-8 One Word on Polarization ..... - 51     
Chapter 3 The propagation of Light ..... - 58     
3-1 Treatise Based on Macroscopic Observations ..... - 59     
3-2 Huygens's Principle ..... - 61     
3-3 Fermat's Principle ..... - 63     
3-4 Two examples using Snell's equation ..... - 67     
3-5 Propagation of Light from Scattering Point of View ..... - 70     
3-6 Fresnel Equations ..... - 77     
3-6-1 Amplitude, Brewster angle and Total Internal Reflection ..... - 82     
3-6-2 Phase shift ..... - 84     
3-6-3 Stokes Relation ..... - 87     
3-6-4 Evanescent Wave ..... - 90     
Chapter 4 Geometric Optics ..... - 95     
4-1 Jargons in geometric optic ..... - 97     
4-2 Fermat's Principle ..... - 100     
4-3 Refraction at a Single Spherical Surface ..... - 102     
4-4 Paraxial Approximation ..... - 103     
4-5 Finite Imagery and Transverse Magnification ..... - 110     
4-6 Multiple Surfaces and Lagrange-Helmholtz Relation ..... - 113     
4-7 Thin Lens ..... - 115     
4-8 Thin lens combination ..... - 120     
4-9 Thick Lenses and Lens System ..... - 121     
4-10 Graphical Method of Image Formation ..... - 127     
4-11 Analytical Ray Tracing and Matrix Method ..... - 130     
4-12 Apertures ..... - 139 -

4-13 Aberration ..... - 149     
Chapter 5 Interference, Interferometer and Coherence ..... - 153     
5-1 Superposition of Waves ..... - 154     
5-1-1 Superposition principle in linear optics ..... - 155     
5-1-2 Superposition of Waves with same ω, Parallel ∇₀ ..... - 157     
5-1-3 Standing Waves ..... - 158     
5-1-4 The addition of waves of different frequency ..... - 162     
5-2 Interference and Coherence ..... - 169     
5-3 Wavefront Splitting Interference ..... - 175     
5-3-1 Interference of Two Point Sources ..... - 175     
5-3-2 Young’s Experiment ..... - 177     
5-3-3 A more Strict and Systematic Treatment ..... - 180     
5-4 Amplitude Splitting Interferometer--Interference by Thin film ..... - 185     
5-4-1 Fringes of Equal Thickness ..... - 187     
5-4-2 Fringes of equal inclination ..... - 190     
5-4-3 Michelson Interferometer ..... - 192     
5-5 Multiple Beam interference and Fabry-Perot interferometer ..... - 197     
5-5-1 Fabry-Perot Interferometer ..... - 201     
5-6 Coherent Theory ..... - 206     
5-6-1 Extended Monochromatic Source and Spatial Coherence ..... - 208     
5-6-2 Effect of Non-Monochromatic Light---Temporal Coherence ..... - 211     
5-6-3 Correlation Function — Formal treatment of Coherence ..... - 217     
Chapter 6 Diffraction ..... - 229     
6-1 What’s Diffraction ..... - 229     
6-1-1 Definition ..... - 229     
6-1-2 Fraunhoffer and Fresnel Diffraction ..... - 232     
6-2 Huygens-Fresnel Principle (HFP) and Kirchhoff equation ..... - 234     
6-3 Fresnel Diffraction through an open aperture ..... - 235     
6-3-1 Method of Half-Wavelength (λ/2) Plate ..... - 236     
6-3-2 Phasor Treatment and Vibrational Spirals (curves) ..... - 241     
6-3-4 Babinet Principle ..... - 245     
6-3-5 Fresnel Zone Plate ..... - 246     
6-4 Fraunhoffer Diffraction by Single Slit ..... - 249     
6-4-1 Single Slit ..... - 250     
6-4-2 Rectangular Aperture ..... - 253     
6-4-3 The Characteristic of Diffraction Distribution ..... - 255     
6-4-4 Fraunhoffer Diffraction by Circular Aperture and Image Resolution ..... - 258     
6-5 Diffraction by Many Slits (Fraunhoffer Type) ..... - 262     
6-5-1 Fraunhoffer-Diffraction by Many Slits ..... - 262     
6-5-2 Diffraction Grating and Grating Spectrometer ..... - 272     
Chapter 7 Fourier Optics ..... - 285     
7-1 Fourier Expansion (Fourier Series) and Fourier integrals ..... - 285     
7-1-1 Fourier Expansion of a Periodic Function ..... - 287 -

7-1-2 Non-periodic functions – Fourier Transform (Fourier Integral) ..... 293  
7-1-3. Dirac Delta Function  $ \delta(x) $ ..... 304  
7-1-4 Properties of Fourier Transform ..... 307  
7-2 Fraunhoffer Diffraction from Fourier Optics' point of view ..... 315  
7-2-1 Fraunhoffer Diffraction ..... 316  
7-2-2 Abbe imaging principle and image processing by spatial Filtering ..... 323  
Chapter 8 Polarization and Propagation of Light in Crystal ..... 337  
8-1 Polarization Type of Light ..... 337  
8-2 Polarizer ..... 344  
8-3 Jones Vector for Polarized Light and Jones Matrix ..... 349  
8-3-1 Jones Vector ..... 349  
8-3-2 Jones matrix for operation on polarized light ..... 351  
8-4 Propagation of light in Crystal-Birefringence ..... 352  
8-4-1 Phenomena of Birefringence (Double refraction) ..... 352  
8-4-2 Microscopic explanation of Birefringence ..... 355  
8-5 Crystal Optical Elements ..... 364  
8-5-1 Birefrigent polarizers ..... 364  
8-5-2 Wave plate—phase retarder ..... 364  
8-5-4 Jones Matrix for polarizer and wave plate ..... 372  
8-6 Optical activity (Circular Birefringence) ..... 380  
8-6-1 Definition ..... 380  
8-6-2 Optical Activity in Crystal ..... 381  
8-6-3 Circular Birefringence ..... 382  
8-6-4 Optical activity in solution ..... 385  
8-6-5 Induced Circular Birefringence—Faraday effect ..... 386  
Chapter 9 Absorption, Dispersion and Scattering of light ..... 389  
9-1 Absorption of Light—Beer's Law (Lambert Law) ..... 389  
9-2 Complex index of refraction ..... 392  
9-3 Classical E-M theory on dispersion and absorption ..... 393  
Chapter 10 Quantum property of light ..... 397  
10-1 Photon—Light Quanta ..... 397  
10-2 Blackbody Radiation ..... 398  
10-3 Photon-Electric effect ..... 408  
10-4 Compton Effect and Momentum of Photon ..... 410  
10-5 Angular Momentum of Photon (Spin) ..... 412  
10-5 de Broglie's Matter wave ..... 413  
10-6 Uncertainty Principle ..... 419  
Chapter 11 Introduction to Quantum Mechanics ..... 422  
11-1 Young's Double Slits Experiment Revisited ..... 423  
11-2 Physical Meaning of the Matter Wave---Probability Wave ..... 433  
11-3 Uncertainty Principle ..... 441  
11-4 Fundamental Postulates of Quantum Mechanics ..... 454  
(1) Ehrenfest Theorem ..... 472

(2) Good Quantum Number and Stationary State ..... - 474     
11.5 Some Examples to Illustrate the Postulates ..... - 483     
Example1. Light passing linear polarizer ..... - 483     
Example 2: Young's double slits experiment with electron scattering photon ..... - 490     
Example3: Stern-Gerlach Experiment and Electron Spin ..... - 500     
Example4: Expression of state vector in position and momentum representation and particle in free space ..... - 517     
Supplement (A): Quantization Rules ..... - 542     
Supplement (B): Uncertainty ..... - 544     
Supplement (C): C.S.C.O ..... - 547     
Chapter 12 Simple Systems ..... - 553     
12-1 Schrodinger Equation in Space Representation and General Property of Wave Function Solution ..... - 554     
12-2 Infinite Square Potential Well ..... - 560     
12-3 Potential Step and Barrier ..... - 564     
12-3-1 Potential Step ..... - 565     
12-3-2 Potential Barrier ..... - 575     
12-4 Finite Square Potential Well ..... - 580     
12.5 Harmonic Oscillator ..... - 585     
12-6 Hydrogen Atom ..... - 596     
Chapter 13 Identical Particles and Permutation Symmetry ..... - 622     
13-1 Non-identical and Identical Particles ..... - 622     
13-2 Exchange Deneneracy and Permutation Symmetry Requirement in Identical Particles ..... - 631     
13-3 Examples ..... - 638     
13-3-1 Multi-electron Atom ..... - 639     
13-3-2 Collisions between Identical Particles ..... - 646     
Chapter 14 Application of Quantum Theory to Molecule and Solid State ..... - 658     
14-1 Molecular Obital and Bonding in  $ H_{2}^{+} $ ..... - 658     
14.2 Free Electron Gas and Kronig-Penney Model for Solids ..... - 672     
References for Quantum Part: ..... - 673     
Math Supplement on Matrix Representation of Vector ..... - 674 -

Optics

## Question: Classical or Quantum?

Why bother to treat the light field classically (classical optics) since we have a more accurate description quantum mechanically. (Quantum optics)

Answer:

1. Quantum theory is though more accurate, but also more complicated.

In many cases, the classical theory is much simple, as well as

2. Accurate: If we treat the statistical behavior (such as average) of large number of photons, the classical Electro-Magnetic theory is good enough.

For Example: In spectroscopy, the light field (laser or conventional source) is treated classically, i.e. the effect of many photons can be represented very accurately by the classical electro-magnetic field; the atoms/molecules are treated quantum mechanically and this is called semi-classical theory.

In most of this course, we are going to deal with the situations where  $ \underline{\text{Light can be treated as Electro-Magnetic wave}} $ (obeying Maxwell equation).

It is instructive to first review some general properties of wave as Chapter 2 in Hecht's book

## Chapter 1 General Properties of Wave

## 1 -1 Physical Feature:

Classically:

Particle: Localized quantity (or property), recall a mass point.

Wave: non-localized, recall a sound wave etc.

Such classical distinction between wave & particle will fail in quantum theory.

## 1 -2 Mathematical Description of Wave-----Differential Wave Equation

 $ \psi(x,t) $: 1-dimension wave function, represents a spatial distribution and time evolution of wave:

 $$ \frac{\partial^{2}\psi(x,t)}{\partial x^{2}}=\frac{1}{\nu^{2}}\frac{\partial^{2}\psi(x,t)}{\partial t^{2}} $$ 

v in the  $ (1-1) $ is the velocity of the wave.

For 3-dimensional case, wave equation is:

 $$ \nabla^{2}\psi(r,t)=\frac{1}{\nu^{2}}\frac{\partial^{2}\psi(r,t)}{\partial t^{2}} $$ 

 $$ \nabla^{2}\equiv\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}} $$ 

Laplacian operator

If a function  $ \psi(r,t) $ is a solution of the wave equation, and its second partial derivative vs. space and time is non-trivial, then  $ \psi(r,t) $ represents a wave.

A special example (as well as a common case in the course):

Wave propagates with a constant shape and phase velocity.

 $ \psi(x,t) = f(x \mp vt) $ (Fig. 2.3, 2.4, pg13. Hecht)

<div style="text-align: center;"><img src="imgs/img_in_chart_box_270_736_627_1082.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_271_1097_644_1418.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">If you put this back to (1-1), it certainly satisfy the wave equation.</div>


The most general solution for wave equation (1-1) will be in the form of  $ \psi(x,t)=F(x-vt)+G(x+vt) $ where the functional form of F and G need to be determined by the initial conditions and boundary value, which will not be fully discussed in our course. It requires Fourier Transform we shall discuss in the later part of the course $ ^{1} $. We shall focus on some simple forms of the solution, as the next section concerns.

## 1 -3 Harmonic waves (a quick summary)

(1) This is the simplest as well as a very important form of wave.

(2) Any other wave function  $ \psi(x,t) $ can be represented as a superposition of such harmonic waves. (Fourier Expansion)

For a harmonic wave (1-dimension):

 $$ \psi(x,t)=A\cos k(x-v t) $$ 

Or  $ \psi(x,t)=A\cos(kx-\omega t) $

Then:  $ \omega = k\nu \Rightarrow \nu = \frac{\omega}{k} $

 $$  Where\ k=\frac{2\pi}{\lambda}=2\pi\overline{v};\omega=2\pi\upsilon=\frac{2\pi}{T} $$ 

The k is wave vector (in l-D is just a number);  $ |k| $ is the angular

wave number;  $ \bar{\nu} = \frac{1}{\lambda} $ is the wave number; T is the period;  $ \upsilon = \frac{1}{T} $ is the frequency;  $ \omega $ is the angular frequency;  $ \nu = \frac{\omega}{k} $ is the phase velocity.

Given any two of $\omega$, $k$, $v$ (or $v$, $\lambda$, $v$ ..... ), you can calculate the other.

A wave has both spatial and temporal period.

<div style="text-align: center;"><img src="imgs/img_in_image_box_290_618_783_810.jpg" alt="Image" width="41%" /></div>


Fixed spatial point,  $ x = x_{0} $

Fig 1.

<div style="text-align: center;"><img src="imgs/img_in_image_box_324_845_711_985.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;">Fig2.7 (pg17, Hecht) can be used as depicting generation of a harmonic wave from a harmonic oscillation source.</div>


*Comment1: the harmonic waves represented by (1-3) are an idealized case, i.e. it is not realizable in real case. It is a wave with single frequency. To have this frequency defined, the wave train has to extend from  $ -\infty $ to  $ +\infty $ in space and time domain (that is how mathematically defining a periodic function). Such wave is called  $ \underline{\text{Monochromatic Wave}} $. (Since color is related to frequency, and single frequency is also called

monochromatic)

The monochromatic wave is an idealization (as mass point with fixed energy in mechanics) because nothing last forever. Any real waves are at best quasi-chromatic, and usually are a superposition of monochromatic waves:

Example: limited wave train

<div style="text-align: center;"><img src="imgs/img_in_image_box_263_593_898_783.jpg" alt="Image" width="53%" /></div>


A wave train with limited length L (It only lasts from 0 to L att = 0), and thus strictly speaking is not a wave with single frequency (or wavelength). By looking at it, it is not hard to see that as the L gets large, the wave train will be pretty much a ideal harmonic wave with single frequency at certain  $ k_{0} $; but if L is very small, it is far from it. The detailed math will be presented later in the due course (Fourier transform), here I shall just present the result. For such wave train, it can be expressed as a superposition of many harmonic waves with different wave vectors k:

 $$ \psi(x)\Big|_{t=0}=\int\limits_{-\infty}^{+\infty}\varphi(k)\cos(kx)dk $$ 

Above is the Fourier Expansion of the wave function  $ \psi(x) $, and  $ \varphi(k) $

is the weighting factor of the  $ k^{th} $ component, it is the expansion coefficient and also termed Fourier transform of  $ \psi(x) $. There is a famous and important relation between the distribution width between original wave function  $ \psi(x) $ and its Fourier Transform  $ \varphi(k) $:

 $$ \Delta k\Delta x\approx2\pi $$ 

And in the above wave train  $ \Delta x = L $

As L→large,  $ \Delta k \approx 0 \rightarrow \psi(x) \rightarrow \cos kx $

we see as L becomes large, the wave train approaches a harmonic wave, and this is called quasi-monochromatic.

Comment 2: The phase signs and relation with phase lead or lag

In this course, very often we will compare the phase difference between two or more waves, from their phase difference we may say certain wave is leading or lagging in phase comparing with others. Here I shall discuss in detail about the relation of phase difference and lagging-leading in phase.

(1)We use sinusoidal function (or complex function) to represent a wave, there is a choice of sign for the phase part:

 $ E(z,t) = A\cos(kz - \omega t + \delta) $ is the  $ \underline{\text{conventional}} $ choice for a traveling wave along the +z direction (another choice is to put a minus sign inside the Cosine, since  $ \cos(\theta) = \cos(-\theta) $ this will give same physical results with physical reality attached to different signs). In this choice, the phase

difference between this wave and the $E_0 = A_0 \cos(kz - \omega t)$ is $\delta$. The figure above only shows the E(z,t), (for comparison, you can add the $E_0$ yourself on the picture). It is clear from the picture that $E(z,t) = A \cos(kz - \omega t + \delta)$. Lags in phase comparing with $E_0 = A_0 \cos(kz - \omega t)$. The delay (choose a same phase point, let's choose the maxim point of the sinusoidal wave in the figure) in the $z$ coordinate is $kz' - \omega t + \delta = 0 = kz - \omega t$ (for same $t$), $\Delta z = z' - z = -\delta / k$. (The $\delta$ value will be set between $- \pi < \delta < \pi$, this can be satisfied always by adding $n2\pi$ to the phase part, $n = \pm 1, \pm 2...$)



<div style="text-align: center;"><img src="imgs/img_in_image_box_222_219_545_339.jpg" alt="Image" width="27%" /></div>


Conclusion: If the wave expressed in forms of  $ \cos(kz - \omega t + \delta) $ or  $ e^{i(kz - \omega t + \delta)} $, the positive phase difference  $ \delta(\delta > 0) $ value means lags in phase and negative phase difference  $ \delta(\delta < 0) $ value means leads in phase.

(2)For a wave propagates along the -z direction, If we express it in forms of  $ E(z,t) = A\cos(kz + \omega t - \delta) $:

<div style="text-align: center;"><img src="imgs/img_in_image_box_245_1321_468_1464.jpg" alt="Image" width="18%" /></div>


Now the wave is traveling from right to left (-z direction, confirm it youself), the phase difference between E(z,t) and  $ E_{0}=A_{0}\cos(kz+\omega t) $ is  $ -\delta $. If the  $ \delta>0 $,  $ -\delta<0 $ (noticed it is the  $ -\delta $ is the phase difference between the two waves), this means negative phase difference is lagging in phase (as shown in the figure, noticed that the wave is now moving towards -Z direction); and the positive phase difference is leading in phase  $ (-\delta>0) $. This reverses the relation between the signs in phase difference and lag-lead in phase for the wave propagates along -Z direction; this is of course because the  $ -\delta $ is the phase difference instead of  $ \delta $ as in the case for wave propagates along +z.

To avoid the possible confusion due to the sign change in  $ \delta $ for the two cases, I should express the wave propagates along the -z direction as:

 $$ E(z,t)=A\cos[-(kz+\omega t-\delta)]=A\cos(-kz-\omega t+\delta)\;. $$ 

This express the same wave propagates from right to left along the  $ -Z $. Now the  $ -k $ shows the direction of the wave and the  $ + \delta $ is the phase difference between it and the  $ E_0 = A_0 \cos(-kz - \omega t) $. In this convention, the positive phase difference  $ (+\delta > 0) $ means lags in phase; and negative phase difference  $ (+\delta < 0) $ means leads in phase. This is same as in the case of wave propagates along the  $ +z $.

## 1 -4 Phase and Phase velocity

 $$ \psi(x,t)=A\cos(kx-\omega t+\varepsilon_{_{0}}) $$ 

A: is the amplitude

Phase:  $ kx - \omega t + \varepsilon_{0} \equiv \phi(x, t) $;  $ \varepsilon_{0} $ is called initial phase

Phase velocity: Refer to fig.1 above.

For the two points on the two curves at different times  $ (x_{0},t_{0}) $,  $ (x_{0}+\Delta x,t_{0}+\Delta t) $ they have equal phase, thus equal  $ \varphi(x,t) $ means:

 $$ k x_{_{0}}-\omega t_{_{0}}+\varepsilon_{_{0}}=k(x_{_{0}}+\Delta x)-\omega(t_{_{0}}+\Delta t)+\varepsilon_{_{0}} $$ 

 $$ \frac{\Delta x}{\Delta t}=\frac{\omega}{k}=v_{\varphi} $$ 

$$(\frac{\partial x}{\partial t})_{\varphi} = \frac{\omega}{k} = \nu_{\varphi} \quad \leftarrow \text{Propagation speed of points with equal case.}$$

phase.

Another more general derivation is given in Hecht’s Book (pg19)

 $$ \left(\frac{\partial x}{\partial t}\right)_{\varphi}=\frac{-(\frac{\partial\varphi}{\partial t})_{x}}{(\frac{\partial\varphi}{\partial x})_{t}}=\frac{\omega}{k}=v_{\varphi} $$ 

(The reason for the minus sign in the second part is from math on partial derivative, it can be proved by using chain rule:  $ d\varphi = \left(\frac{\partial\varphi}{\partial x}\right)_t dx + \left(\frac{\partial\varphi}{\partial t}\right)_x dt $, please carry out yourself)

## 1 -5 Superposition Principle

It is valid because the wave equation is  $ \underline{\text{linear.}} $

If  $ \psi_{1}, \psi_{2} $ are solutions to wave equation (1-1) or (1-2), then  $ \psi = \psi_{1} + \psi_{2} $ is also a solution. (Note, it is also assumed that  $ \nu $ is a constant, independent of  $ \psi_{1}, \psi_{2} $, this is certainly true in cases where light travels in vacuum but in cases where  $ \nu $ depends on  $ \psi $,complication arises, we will see in the later section on group velocity)

<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_199_748_501_1023.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_522_749_823_1019.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_199_1048_499_1318.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_523_1047_824_1315.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;">The figure (Hecht’s figure 2.14) shows the superposition of waves with different phase difference. The case (a) with equal phase (phase difference is 0 or  $ 2n\pi $) is called constructive; the case (d) with opposite</div>


phase (phase difference by  $ \pi $ or  $ (2n+1)\pi $) is called destructive.
As the most important principle in this course (also possibly the most important principle in quantum mechanics), I'd like to add some comments.
This principle is based on the experimental experience, not derivable from other fundamental laws (The argument in the notes states that the linear differential equation means linear superposition of waves would be also a solution, this is true but not the proof of the superposition principle). The superposition of waves is like the superposition principle of the electric and magnetic field in electro-magnetic theory which is all rooted from superposition principle of forces in Mechanics.
This superposition principle of the field is a little different from the superposition of responses of a system:
The superposition of responses of a linear system means the response of the system is also a superposition of each individual component. Example: For a linear dielectric media, the polarilability (the response of the diploes in media to the electric field) is to the first order:  $ P = \varepsilon_{0} \chi E $, this is a linear response since  $ P(E1 + E2...) = P(E1) + P(E2) + \ldots $ directly from superposition of the E field.
At stronger field, the higher orders of the E field in response cannot be neglected, i.e.  $ P = \varepsilon_{0} \chi E + \alpha E^{2} + \ldots $, then the response of the system in such cases is clearly not linear any more, (the superposition of the fields

is still true) we need nonlinear optics to solve such problems which is out of the scope of this course. The systems considered in this class are all treated as linear systems, i.e. the E fields are all weak enough to safely neglect higher order contributions in the response.

## 1 -6 Complex Representation and Phasors

Sinusoidal representation of harmonic waves, though simple in itself, it can be awkward in algebra manipulation, such as addition and multiplication, the complex representation of waves is  $ \underline{\text{physically equivalent}} $ but  $ \underline{\text{mathematically simple}} $ description of waves.

 $$ \begin{array}{l} \text{Euler formula: } e^{i\theta} = \cos\theta + i\sin\theta \\ \text{A(p)cos}\left[\varphi(p,t)\right] \quad \varphi(p,t) \xlongequal{1-\dim} kx + \varphi_{0} - wt \\ \quad = \varphi(p) - wt \\ \quad \Delta\varphi\left[x_{1}-x_{0}\right),t_{0} \quad \stackrel{x_{1}>x_{0}}{>} o \\ \quad \text{The phase at } x_{1} \gg x_{0} \quad \text{actually} \\ \quad \underline{\text{Lacks}} \quad \text{in phase compared with } x_{0}. \\ \quad \Delta\varphi\left[(x_{1}-x_{0}),t_{0}\right] < \bullet \quad \text{for } x_{1}<x_{0} \\ \quad \text{but the phase at } x_{1} \quad \text{Leads that at } x_{0}. \\ \quad \text{Similar arguments applies for} \\ \quad \times \text{fixed, } t \text{ varies.} \end{array} $$ 

So with this complex convention  $ (e^{i\varphi(p,t)} $ instead of  $ e^{-i\varphi(p,t)} $ as we discussed previously with sinusoidal case)

 $$ \Delta\varphi(p,t)>0\quad\longrightarrow\longrightarrow\quad\mathrm{L a g s~i n~p h a s e} $$ 

 $$ \Delta\varphi(p,t)<0\quad\overrightarrow{\quad}\quad\mathrm{~L~e~a~d~s~i~n~p~h~a~s~} $$ 

Thus, the complex representation is

(1) Equivalent to the cosine representation, as long as we bear in mind the physical wave correspond to the real part of the complex.

(2) The complex will simplify the calculation.

Comments on the Equivalence of Euler expression and sinusoidal expression for waves:

The complex expression of waves (Euler formula) is very useful; it simplifies many calculations comparing with the sinusoidal expressions of waves. I stated above that as long as you are aware that the real part of the complex expression corresponds to the physical wave, you can use the complex during the calculation, and if necessary (a lot of times it is not necessary) you take the real part of the complex result to express the physical wave. This statement needs a little bit polish in a sense that it depends on the calculation:

If the required calculation would not mix the real and imaginary parts, such as adding, subtracting and differentiating waves, you can use the complex expression with confidence. It generates same results as the sinusoidal expression. (By taking the real part of the complex)

However, if the calculation mixes the real and imaginary parts, such as multiply, generally two expressions will give different results, and you need to stick to the sinusoidal expressions (Not many calculations in this course belong to this class). Example: two waves at a fixed spatial point with same frequency, we calculate their product at that point over time:  $ E_1 = A_1 \cos(\omega t + \delta_1) $;  $ E_2 = A_2 \cos(\omega t + \delta_2) $. The corresponding complex expressions are:  $ \tilde{E}_1 = A_1 e^{i(\omega t + \delta_1)} $ and  $ \tilde{E}_2 = A_2 e^{i(\omega t + \delta_2)} $. Then (* means complex conjugate):

 $$ E_{1}E_{2}=E_{1}E_{2}^{*}=A_{1}A_{2}\cos(\omega t+\delta_{1})\cos(\omega t+\delta_{2})=\frac{1}{2}A_{1}A_{2}[\cos(\delta_{1}-\delta_{2})+\cos(2\omega t+\delta_{1}+\delta_{2})] $$ 

 $$ \tilde{E}_{1}\tilde{E}_{2}=A_{1}A_{2}e^{i(2\omega t+\delta_{1}+\delta_{2})}\xrightarrow{r e a l}\neq E_{1}E_{2} $$ 

 $$ \tilde{E}_{1}\tilde{E}_{2}^{*}=A_{1}A_{2}e^{i(\delta_{1}-\delta_{2})}\xrightarrow{r e a l}\neq E_{1}E_{2} $$ 

In the above calculation, using complex expression would give incorrect answers. Fortunately such calculation is not often in real physics, in most cases where we are interested in the multiplications, we are interested in its time average! I.e. we are interested in:

 $$ <E_{1}E_{2}>_{T}=\frac{1}{T}\int\limits_{0}^{T}E_{1}E_{2}dt $$ 

 $$ <E_{1}E_{2}>_{T}=\frac{1}{T}\int_{0}^{T}E_{1}E_{2}dt=\frac{1}{2}A_{1}A_{2}\frac{1}{T}\int_{0}^{T}[\cos(\delta_{1}-\delta_{2})+\cos(2\omega t+\delta_{1}+\delta_{2})]dt $$ 

If the average time  $ T \gg $ the time period of the oscillation, i.e.  $ T \gg \frac{2\pi}{\omega} $, the second term in the integral will become  $ \sim $0 after divided by T, then:

 $$ <E_{1}E_{2}>_{T}=\frac{1}{2}A_{1}A_{2}\cos(\delta_{1}-\delta_{2})=\frac{1}{2}\mathrm{Re}\left\{\tilde{E}_{1}\tilde{E}_{2}^{*}\right\} $$ 

Thus we can use complex expression  $ \tilde{E}_1\tilde{E}_2^* $ to evaluate the time average of the product, up to a constant factor 1/2. This is the basis that I will use complex expression to calculate the time average product of the fields in this course. One particular example is the average energy flux of the light is :

 $ <E_1E_1>_{T}=\frac{1}{2}A_1^2=\frac{1}{2}\tilde{E}_1\tilde{E}_1^* $

Here I use E to represent real physical field and  $ \tilde{E} $ to represent its complex expression. In this course, all the calculations involved satisfy the condition that the two representations would give same results (i.e. superposition, differentiation, time average of products etc.), so in my lecture notes, I just use E to represent the field in both cases to save bookkeeping time.

The reason I shall use Euler formula (the complex exponential form) to represent wave is not only due to math simplification as it may bring, but also the complex form of wave is a must later in the quantum mechanics, so we’d better get used to it as early as possible.

Phasor: vector representation of the complex representation, just like the

vector representation of any complex number.

 $$ \psi(p,t)=A(p)e^{i\varphi(p)}e^{-i\omega t} $$ 

phasors :

<div style="text-align: center;"><img src="imgs/img_in_image_box_451_330_689_469.jpg" alt="Image" width="20%" /></div>


与 if +iwt

 $$ 2it-i w t $$ 

This is very useful in summation of multiple waves with same frequency:

 $$ A(p)e^{i\varphi(p)}e^{-i\omega t}=(\sum_{j}A_{j}(p)e^{i\varphi_{j}(p)})e^{-i\omega t} $$ 

The geometrical expression is provided in the figure below

<div style="text-align: center;"><img src="imgs/img_in_image_box_392_784_760_1024.jpg" alt="Image" width="30%" /></div>


Example: Adding two waves.

I shall use this example to illustrate describing waves with sinusoidal functions, complex formula and phasor method, showing they are indeed equivalent.

The problem is a simple but important one: adding two waves with same frequency but with a phase difference. The two 1-D waves are:

 $$ \psi_{1}=A\cos(kx-\omega t) $$ 

 $$ \psi_{2}=A\cos(k x-\omega t+\phi) $$ 

For simplicity I also set the two waves with same amplitude, but a phase difference  $ \phi $. I shall consider their superposition at a certain point and will choose that point as origin, i.e. x=0 point. Thus the waves at that point will be (adding two oscillations at that point):  $ \psi_1 = A \cos(-\omega t) $,  $ \psi_2 = A \cos(-\omega t + \phi) $, and their sum will be:

### I. Sinusoidal expression

 $$ \psi=\psi_{1}+\psi_{2}=A\cos(-\omega t)+A\cos(-\omega t+\phi) $$ 

 $$  Using cosine formula:\cos\alpha+\cos\beta=2\cos(\frac{\alpha+\beta}{2})\cos(\frac{\alpha-\beta}{2}) $$ 

(in case you forgot above formula, try proving it with Euler formula)

 $$ \psi=2A\cos(-\frac{\phi}{2})\cos(-\omega t+\frac{\phi}{2})=2A\cos(\frac{\phi}{2})\cos(\omega t-\frac{\phi}{2}) $$ 

The instantaneous intensity is:

 $$ |\psi|^{2}=4A^{2}\cos^{2}(\frac{\phi}{2})\cos^{2}(\omega t-\frac{\phi}{2}) $$ 

The average of the intensity (assume  $ T \gg \frac{2\pi}{\omega} $, then average over  $ \cos^2 $ term will give  $ 1/2 $ because  $ \cos^2 \alpha = \frac{1 + \cos 2\alpha}{2} $):

 $$ I=<\left|\psi\right|^{2}>=2A^{2}\cos^{2}(\frac{\phi}{2}) $$ 

This simple calculation will be used often later, and its physical interpretation is clear. It shows adding two waves with same frequency, amplitude but with a phase difference will result in another wave of same frequency and a phase difference in half; what is more important is the effect of phase difference on the amplitude. When the phase difference is 0 (in phase) the amplitude is largest, the two waves add constructively; when the phase difference is  $ \pi $, the two wave cancel each other result in 0 amplitude, add up destructively.

### II. Euler Formula

Now let me work the same problem with complex expression:

 $$ \tilde{\psi}_{1}=A e^{-i\omega t};\quad\tilde{\psi}_{2}=A e^{-i\omega t}e^{i\phi} $$ 

 $$ \tilde{\psi}=\tilde{\psi}_{1}+\tilde{\psi}_{2}=A e^{-i\omega t}(1+e^{i\phi})=A e^{-i\omega t}e^{i\frac{\phi}{2}}(e^{-i\frac{\phi}{2}}+e^{i\frac{\phi}{2}})=2A\cos\frac{\phi}{2}e^{-i\omega t}e^{i\frac{\phi}{2}} $$ 

If we take the real part, we will get back the sinusoidal result.

Average intensity is proportional to:

 $$ I\propto\tilde{\psi}\tilde{\psi}^{*}=|\tilde{\psi}|^{2}=4A^{2}\cos^{2}(\frac{\phi}{2}) $$ 

(Take 1/2 of it will give us the average intensity as I discussed in the comment in last section)

### III. Phasor method

<div style="text-align: center;"><img src="imgs/img_in_image_box_392_242_722_380.jpg" alt="Image" width="27%" /></div>


The red phasor represents  $ \tilde{\psi}_{1} $, green represents  $ \tilde{\psi}_{2} $, the blue is the summation. In the convention we choose  $ (e^{-i\omega t}) $, the phasor will rotate clockwise with  $ \omega $. It is a simple geometry problem to find the expression of the blue phasor:

Its argument (angle) is  $ \frac{\phi}{2} $ (it lags in phase comparing the red one  $ \tilde{\psi}_1 $ by this  $ \frac{\phi}{2} $), it also rotates clockwise with same angular frequency  $ \omega $, so the phase part is:  $ e^{-i\omega t} e^{i\frac{\phi}{2}} $

Its amplitude is given by cosine laws of triangle:

 $$ |\tilde{\psi}|=\sqrt{A^{2}+A^{2}+2A^{2}\cos\phi}=\sqrt{2A^{2}(1+\cos\phi)}=\sqrt{4A^{2}\cos^{2}(\frac{\phi}{2})} $$ 

I hope through this simple example I convince you the equivalence of these methods. The complex or phasor (the phasor one is just geometrical variation of the complex method) method will be preferred in this course because the complex expression of wave finds wider application in physics as I mentioned earlier.

## 1 -7 Plane waves and Spherical waves

(Hecht's p25-31. Zhao's p140-p148)

The simple harmonic wave treated above is 1-dimensional.

Its equivalence in 3-dimensional case is harmonic plane wave.

General harmonic wave has the form of: (monochromatic wave)

 $$ \psi(r,t)=A(r)e^{i\varphi(r,t)}=A(r)e^{i\varphi(r)}e^{-i\omega t} $$ 

Concept of wave front: the surface that the phases of points on it are equal.

1-7-1 A harmonic plane wave (in 3-D) is defined as:

(1). The amplitude A(r) is constant for all r.

(2). The wave front at certain time is a plane  $ \perp $ propagation vector k

 $ \varphi(r) = k \bullet \vec{r} $ satisfies the requirement, geometrically,  $ \vec{k} \cdot \vec{r} = $ constant is a plane perpendicular to vector k.

Thus a harmonic plane wave is:

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_158_456_460.jpg" alt="Image" width="19%" /></div>


(Fig 2.20, pg 25 Hecht)

 $$ \psi(r,t)=A e^{i(\vec{k}\bullet\vec{r}-\omega t)}=A e^{i(k_{x}x+k_{y}y+k_{z}z-\omega t)} $$ 

Where

 $$ \left|k\right|=\sqrt{k_{x}^{2}+k_{y}^{2}+k_{z}^{2}}=\frac{2\pi}{\lambda} $$ 

 $$ \nu_{\varphi}=\frac{\omega}{k} $$ 

The more general plane waves that are solutions of equation (1-2)

 $ \nabla \psi(r,t) = \frac{\partial^2 \psi}{\partial t^2} $ is given in (2-66) of Hecht's book, which can be

treated as superposition of harmonic plane waves.

1-7-2 Spherical waves: waves from an isotropic point source.

The wave equation for an isotropic point source:  $ \underline{\text{(Hecht eqn. 2.70)}} $

$$\frac{1}{r}\frac{\partial^{2}}{\partial r^{2}}=\frac{1}{\nu^{2}}\frac{\partial^{2}\psi}{\partial t^{2}}\ \text{in spherical coordinate.}$$

The general solution is of the form of  $ \underline{\text{(Hecht's eqn. 2.73)}} $

The spherical wave has characters:

(1). Wave front is a sphere

(2). The amplitude  $ \propto \frac{1}{r} $

The special case of harmonic spherical wave is:

 $$ \psi(r,t)=\frac{A}{r}e^{i(k r\mp\omega t)} $$ 

Here the A/r in (1-8) is the amplitude of the field, and drops as distance increases. The A is called source strength whose physical meaning is related to the power emitted by the source (energy flow out of the source/unit time), which can be readily seen using energy flow formula (Poynting vector next chapter). The drop of the amplitude with distance r is a requirement of energy conservation as we shall see that the energy flux (energy flow/unit area.unit time) will be proportional to the square of the amplitude for the wave.

At large r, spherical wave and plane wave would be similar.

## 1 -8 Doppler Effect:

When we talk about the frequency of a wave above, we presume that the observer is stationary relative to the wave source. If the source and the observer are in relative motion, the observed frequency will be different from that in stationary---Doppler Effect. This is familiar phenomenon even in daily life, as well as has scientific significance.

<div style="text-align: center;"><img src="imgs/img_in_image_box_298_184_586_376.jpg" alt="Image" width="24%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_682_177_1048_275.jpg" alt="Image" width="30%" /></div>


What are the frequencies experienced by 2 and 3 in the above figure? It is going to be shifted from  $ \upsilon_{0} $, the  $ \upsilon_{0} $ is the frequency experienced by 1 which is stationary to the light source.

The shift in frequency is given by:

 $$ \frac{\Delta\upsilon}{\upsilon_{0}}=\pm\frac{\nu}{\nu_{0}}=\frac{-\vec{\nu}\bullet\hat{n}_{0}}{\left|\vec{\nu}_{0}\right|} $$ 

 $ \hat{n}_{0} $ is a unit vector representing direction of wave vector k. We see that in 1-D case what is important is the motion along the direction of wave propagation.

The derivation of the Doppler Effect had been extensively carried out in my notes on special relativity and one version is supplied below in supplement. There is also 2-D Doppler Effect and we will not consider here in this course.

The Doppler Effect finds its way in many scientific applications, among them are:

(1). Big Bang Theory

From the Doppler shift, we can conclude that the expansion of the universe. The further the star away from earth, the faster it is moving away.

(2). Doppler broadening of spectral line.

—A nuisance to spectroscopic and the ways to overcome it.

<div style="text-align: center;"><img src="imgs/img_in_image_box_173_548_998_882.jpg" alt="Image" width="69%" /></div>


what is the absorption spectra

would look like for a ensemble of

such atoms at Room T.

Ideally, if all atoms are motionless, they

will absorb at single frey.

So ideally the atomic absorption line of the simplified energy structure involved (only two levels: ground and excited) should be a single dip in spectrum. However, atoms are moving around:

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_1158_941_1270.jpg" alt="Image" width="59%" /></div>


For atom 2 which moves towards light, it will experience a shift to higher frequency (blue shift, all the frequencies here are referring to the frequency stationary to the source), If the light frequency is  $ \upsilon_{0} $, atoms 2 would feel as if  $ \upsilon_{0} + \Delta \upsilon $, it will then not absorb at this frequency. It will

absorb at light frequency  $ \nu_0 - \Delta \nu $. Similarly, atom 3 would absorb at  $ \nu = \nu_0 + \Delta \nu $, where  $ \Delta \nu $ is given by (1-9), the Doppler shift formula. The absorption would be something shown in the figure below.

As there is a distribution (Boltzmann distribution) of velocities that atoms are traveling at certain T, the absorption spectrum will reflect such distribution, and the spectral line would be broadened. This is called Doppler broadening

<div style="text-align: center;"><img src="imgs/img_in_image_box_281_570_826_826.jpg" alt="Image" width="45%" /></div>


The real situation involves many atoms/molecules whose velocity has a continuous distribution at certain temperature. From Boltzmann distribution of velocity of atoms/molecules (here only consider 1-D, the direction along the light propagation), we can derive line width due to Doppler broadening.

<div style="text-align: center;"><img src="imgs/img_in_image_box_187_1184_507_1326.jpg" alt="Image" width="26%" /></div>


 $$ \rho(\nu)=e^{\frac{-\frac{1}{2}mv^{2}}{(\frac{kT}{}})} $$ 

 $$ \Delta\nu=\frac{2\sqrt{(2\ln2)kT}}{\sqrt{m}} $$ 

 $ \rho(v) $ is the probability density of atoms at velocity v, i.e. the number of atoms dN with velocity v in the small interval dv around it is:

 $$ d N=\rho(v)d v $$ 

k: Boltzmann constant.

m: mass of single particle.

 $ \Delta v $ is the full width at half maximum (FWHM)

Then the line width (FWHM) due to Doppler Broadening is:

 $$ \frac{\Delta\nu}{\nu_{0}}=\frac{\Delta\nu}{\nu}=\frac{2\sqrt{2\ln2}}{\nu}\sqrt{\frac{kT}{m}} $$ 

Such broadening can be quite nuisance to spectroscopicist, since it will smear out many fine structures of close lying atomic/molecular energy levels.

For example: the hyperfine structure of atomic lines.

Use  $ ^{87}Rb $ as example.

<div style="text-align: center;"><img src="imgs/img_in_image_box_176_1013_1000_1524.jpg" alt="Image" width="69%" /></div>


but due to Doppler broadening, only two broad features observed in conventional spectroscopy.

observed broad feature.

(Fine structures are buried under it)

There are ways to overcome the Doppler broadening, the most straightforward is to cool the atom/molecule to low temperature; another clever technique is saturated absorption.

##  $ ^{*} $Supplement1: Saturated absorption to get rid of Doppler broadening

As the figure below demonstrates, this is using the effect we call saturation, i.e. if the atoms are shined with a strong light, it will absorb that light, so that the number of atoms at ground state will decrease $ ^{2} $. Now if we introduce another weaker light beam simultaneously passing the atoms, this weak light beam will be much less absorbed due to the decrease of the available ground state atoms.

<div style="text-align: center;"><img src="imgs/img_in_image_box_180_603_973_996.jpg" alt="Image" width="66%" /></div>


In the above figure, the laser (ECDL in the figure) generate an output whose frequency can be scanned (means adjusted continuously). The laser output was separated into 3 parts by the beam splitter: The strongest one (90% of energy, the thick red line) will be acting like saturation beam; two weaker lights will pass the atomic cell as reference and probe beam. The trick is to arrange the saturation beam overlapping with one of the weaker beam (the lower one in the figure, and this weak beam is termed probe in this case) in the head-to-head configuration. The other weak beam that does not overlap with saturation is then the reference beam.

The reference beam will then experience no saturation effect and its absorption would be the regular one with Doppler broadening: As the figure below shows (which shows F=2 and F=1 transition for both R 87 and Rb85 isotopes so total of four bands). Under each of these bands there are fine structures hidden, say under the leftmost

band corresponding to Rb87  $ F = 2 \rightarrow F' $, there are should be 3 fine structures:  $ F = 2 \rightarrow F' = 3, 2, 1 $. They are hidden because each one is Doppler broadened.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_267_481_863_815.jpg" alt="Image" width="50%" /></div>


The probe beam due to its overlapping with the saturation beam will experience saturation effect, and most important because of the head-to-head configuration, only certain atoms with suitable velocity can “enjoy” saturation effect, this will decrease of absorption in reference beams from certain atoms will show dips in the absorption of the probe beam and thus reveal the fine structure of the atom. Below is the absorption spectrum of the same  $ F = 2 \rightarrow F' $ Rb87 of the probe beam, notice those dips in the spectrum.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_194_1090_604_1391.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;">*Supplement 2: Prove Doppler Effect using special relativity</div>


Considering the case that the light propagates from left-to-right; the observer is moving with velocity u against light (from right-to-left). (Here I only consider the motion of observer along the direction of light propagation; I shall neglect the effect of so called transverse motion, i.e. the motion perpendicular with respect to the light propagation, because the transverse effect is usually much smaller)

First I will define two reference frames, S is the frame in which the light source is stationary, and the observer is moving with  $ -u $ (observer is at the right-side of the light source and moving toward the light source). The S' system is in which the observer is stationary and the light source is moving with velocity u. The Lorentz Transformation between the two frames is:

 $$ x^{^{\prime}}=\frac{x+ut}{\sqrt{1-\frac{u^{2}}{c^{2}}}}\quad and\quad t^{^{\prime}}=\frac{t+\frac{ux}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}} $$ 

 $$ \Delta x^{^{\prime}}=\frac{\Delta x+u\Delta t}{\sqrt{1-\frac{u^{2}}{c^{2}}}}\quad and\quad\Delta t^{^{\prime}}=\frac{\Delta t+\frac{u\Delta x}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}} $$ 

 $$ x=\frac{x^{^{\prime}}-ut^{^{\prime}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}}\quad and\quad t=\frac{t^{^{\prime}}-\frac{ux^{^{\prime}}}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}} $$ 

 $$ \Delta x=\frac{\Delta x^{^{\prime}}-u\Delta t^{^{\prime}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}}\quad and\quad\Delta t=\frac{\Delta t^{^{\prime}}-\frac{u\Delta x^{^{\prime}}}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}} $$ 

Where  $ (x, t) $,  $ (x', t') $ are spatial-temporal coordinates for the same event in two frames, and the  $ (\Delta x, \Delta t) $,  $ (\Delta x', \Delta t') $ are the difference between the two events observed in the two frames.

Next we shall define the two events relevant to the problem (in all problems involving relativity, defining the relevant events are always important). Considering two adjacent equal phase wavefronts from the light source, wavefront 1 and wavefront 2 (the phase difference between them is of course  $ 2\pi $): Event 1 is when the wavefront 1 passes the observer; Event 2 is when the wavefront 2 passes the observer. The time period experienced by the observer  $ \Delta t' $ is what we are interested, its reciprocal will be the frequency experienced by the observer with relative motion to the light source. To calculate  $ \Delta t' $, I will first calculate  $ \Delta t $ and then use L-transform.

In the frame S, event 1 happens at (x1, t1), now the wavefront 1 passes the observer at (x1, t1), at this moment the wavefront 2 is at distance cT from x1, where T

is the period between the two equal-phase wavefront in S (i.e. T is the period of light observed by a stationary observer relative to light source and  $ \upsilon_0 = \frac{1}{T} $ is the frequency in this frame); i.e. the wavefront2 is at (x1-cT, t1) at event 1. At event 2, the wavefront 2 (travels at velocity c along +x) will meet observer (travels with -u) at (x2, t2):

 $$ \Delta t=t2-t1 $$ 

 $$ x2-x1=-u\Delta t\quad and\quad x2-(x1-cT)=c\Delta t $$ 

 $$ \Delta t=\frac{c}{c+u}T $$ 

Now from the L-Transform, in the frame of S' (observer is stationary), applying  $ \Delta x' = 0 $ or directly from above  $ x2 - x1 = -u\Delta t $, will give):

 $$ \Delta t^{^{\prime}}=\frac{\Delta t+\frac{u\Delta x}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}}=\frac{\Delta t+\frac{u(-u\Delta t)}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}}=\Delta t\sqrt{1-\frac{u^{2}}{c^{2}}}=\sqrt{1-\frac{u^{2}}{c^{2}}}\frac{c}{c+u}T=\sqrt{\frac{c-u}{c+u}}T=\sqrt{\frac{1-u/c}{1+u/c}}T $$ 

 $ \nu' = \frac{1}{\Delta t'} = \sqrt{\frac{1 + \beta}{1 - \beta}} \nu_0 \quad \text{where } \beta \equiv \frac{u}{c}, \text{ if } \beta << 1, \text{ use Taylor expansion (only to first order)} $:

 $$ \upsilon^{\prime}=\sqrt{\frac{1+\beta}{1-\beta}}\upsilon_{0}\approx\upsilon_{0}(1+\beta) $$ 

 $$ \frac{\upsilon^{\prime}-\upsilon_{0}}{\upsilon_{0}}=\frac{u}{c} $$ 

This is the relation of Doppler shift given in the notes when observer is traveling against light source. The case when the observer traveling along the light source (with +u along +x) has same derivation (just replace -u with +u) and you may write the explicit results yourself.

## Chapter2 Light as Electro-Magnetic Wave

## 2 -1 Maxwell Equation and Electro-Magnetic Wave

## (1) The Maxwell Equations

In  $ \underline{vacuum} $, no free charge and current, M-equations are:

 $$ \nabla\cdot\vec{E}=0 $$ 

 $$ \nabla\cdot\vec{H}=0 $$ 

 $$ \nabla\times\vec{E}=-\mu_{0}\frac{\partial\vec{H}}{\partial t} $$ 

 $$ \nabla\times\vec{H}=\varepsilon_{0}\frac{\partial\vec{E}}{\partial t} $$ 

 $ \vec{E} $,  $ \vec{H} $ are vectors representing electric field and magnetic field.

Where:

 $$ \mu_{0}\vec{H}=\vec{B} $$ 

 $$ \varepsilon_{0}\vec{E}=\vec{D} $$ 

 $ \mu_0 $ : permeability

 $$ 4\pi\times10^{-7}\ \mathrm{Henry}/\mathrm{meter} $$ 

 $ \varepsilon_0 $: permittivity

 $$ 8.854 \times 10^{-12} \text{ Faraday/meter} $$ 

Once again, I stress that above relations apply to the vacuum case. For the general property of the E-M field, please see the textbook of E-M theory for some detailed quantitative description. For the quantitative derivation, see the textbook for Electrodynamics (Jackson's Classical

## Electrodynamics)

Comment: Above I expressed M-equations using E and H vectors, which is not the usual fundamental forms. (The reason I use E, H is because they are mostly specified in real experiments, since you manipulate E by potential and H by free current) The equations in the note are correct and so are the derivations from there. They are one of the variations of the fundamental M-equations in a homogeneous media, applying the media relation (for linear media) between E and D, B and H:

 $$ \vec{D}=\varepsilon\vec{E};\ \vec{B}=\mu\vec{H}\ \left(\mathrm{in some books}\ \varepsilon=\varepsilon_{r}\varepsilon_{0};\mu=\mu_{r}\mu_{0};\varepsilon_{r}=1+\chi_{e}=K_{E};\mu_{r}=1+\chi_{m}=K_{M}\right) $$ 

Here just for self-containment, I also include the M-equations in its fundamental forms:

 $$ \nabla\bullet\vec{E}=\rho\bigg/\varepsilon_{0};\quad\nabla\bullet\vec{B}=0 $$ 

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t};\ \nabla\times\vec{B}=\mu_{0}j+\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}}{\partial t} $$ 

In vacuum, the charge and current would be simply the free charge and current. In a media, however, the charge and current should include bound charges and induced currents. To simplify the matter to only count the free charge and current, two auxiliary vectors are introduced; the D and H, and the M-equations in a media are usually in the form of:

 $$ \nabla\bullet\vec{D}=\rho_{_{free}};\quad\nabla\bullet\vec{B}=0 $$ 

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t};\ \nabla\times\vec{H}=j_{free}+\frac{\partial\vec{D}}{\partial t} $$ 

With the E, D and B, H relation given above.

(2) Electro-Magnetic Wave

Since.  $ \nabla \times (\nabla \times) = \nabla (\nabla \bullet \nabla^2 (\nabla \cdot \nabla \times)) = \nabla \times (\nabla \times) = \nabla \times (\nabla \times) = \nabla \times (\nabla \times) $

Then:  $ \nabla \times (\nabla \times \vec{E}) = \nabla \left( \nabla \bullet \vec{E} \right) - \nabla^2 \vec{E} = -\nabla^2 \vec{E} $

From Maxwell Equation:

 $$ \nabla\times(\nabla\times\vec{E})=-\mu_{0}\frac{\partial\left(\nabla\times\vec{H}\right)}{\partial t}=-\varepsilon_{0}\mu_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}} $$ 

 $$ \therefore\nabla^{2}\vec{E}=\varepsilon_{0}\mu_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}} $$ 

Likewise:

 $$ \nabla^{2}\vec{H}=\varepsilon_{0}\mu_{0}\frac{\partial^{2}\vec{H}}{\partial t^{2}} $$ 

(2-5), (2-6) are just standard wave equations.

So,  $ \vec{E} $,  $ \vec{H} $ are some forms of wave, they are E-M wave.

## 2 -2 Speed of light

From (2-5), (2-6) it is easy to see that

 $$ C_{0}=\frac{1}{\sqrt{\varepsilon_{0}\mu_{0}}} $$ 

(2-7)——speed of light in vacuum

In a media with dielectric, magnetic coefficient

 $$ \varepsilon,\mu:\varepsilon=\varepsilon_{r}\varepsilon_{0}=K_{E}\varepsilon_{0};\mu=\mu_{r}\mu_{0}=K_{M}\mu_{0} $$ 

Similar derivation using relations of vector operator  $ \nabla $

 $$ \begin{aligned}&\nabla^{2}\vec{E}=\varepsilon\mu\frac{\partial^{2}\vec{E}}{\partial t^{2}}\quad&\nabla^{2}\vec{H}=\varepsilon\mu\frac{\partial^{2}\vec{H}}{\partial t^{2}}\\ &C=\frac{1}{\sqrt{\varepsilon\mu}}\\ &\frac{C_{0}}{C}=\sqrt{\frac{\varepsilon\mu}{\varepsilon_{0}\mu_{0}}}=\sqrt{K_{E}K_{M}}=n\approx\sqrt{K_{E}}\quad&(2-8)\\ \end{aligned} $$ 

n is called the index of refraction (or refractive index).

n is a function of  $ \omega $, the dependence of n with frequency of light is called  $ \underline{\text{dispersion}} $. In a media, light travels at less speed than vacuum, and light with different freq. travels at different speed.

Explain (as an exercise) the seemingly difference between the measured n and  $ \sqrt{\varepsilon\mu} $, where  $ \varepsilon $,  $ \mu $ are  $ \underline{\text{static}} $ dielectric and magnetic coefficient. (Hecht's pg66)

<div style="text-align: center;">TABLE 3.2 Maxwell's Relation</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="3">Gases at 0°C and 1 atm</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Substance</td><td style='text-align: center; word-wrap: break-word;'>$ \sqrt{K_{E}} $</td><td style='text-align: center; word-wrap: break-word;'>n</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Air</td><td style='text-align: center; word-wrap: break-word;'>1.000294</td><td style='text-align: center; word-wrap: break-word;'>1.000293</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Helium</td><td style='text-align: center; word-wrap: break-word;'>1.000034</td><td style='text-align: center; word-wrap: break-word;'>1.000036</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Hydrogen</td><td style='text-align: center; word-wrap: break-word;'>1.000131</td><td style='text-align: center; word-wrap: break-word;'>1.000132</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Carbon dioxide</td><td style='text-align: center; word-wrap: break-word;'>1.00049</td><td style='text-align: center; word-wrap: break-word;'>1.00045</td></tr></table>

<div style="text-align: center;">Liquids at  $ 20^{\circ} $C</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Substance</td><td style='text-align: center; word-wrap: break-word;'>$ \sqrt{K_{E}} $</td><td style='text-align: center; word-wrap: break-word;'>n</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Benzene</td><td style='text-align: center; word-wrap: break-word;'>1.51</td><td style='text-align: center; word-wrap: break-word;'>1.501</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Water</td><td style='text-align: center; word-wrap: break-word;'>8.96</td><td style='text-align: center; word-wrap: break-word;'>1.333</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Ethyl alcohol (ethanol)</td><td style='text-align: center; word-wrap: break-word;'>5.08</td><td style='text-align: center; word-wrap: break-word;'>1.361</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Carbon tetrachloride</td><td style='text-align: center; word-wrap: break-word;'>4.63</td><td style='text-align: center; word-wrap: break-word;'>1.461</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Carbon disulfide</td><td style='text-align: center; word-wrap: break-word;'>5.04</td><td style='text-align: center; word-wrap: break-word;'>1.628</td></tr></table>

<div style="text-align: center;">Solids at room temperature</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Substance</td><td style='text-align: center; word-wrap: break-word;'>$ \sqrt{K_{E}} $</td><td style='text-align: center; word-wrap: break-word;'>n</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Diamond</td><td style='text-align: center; word-wrap: break-word;'>4.06</td><td style='text-align: center; word-wrap: break-word;'>2.419</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Amber</td><td style='text-align: center; word-wrap: break-word;'>1.6</td><td style='text-align: center; word-wrap: break-word;'>1.55</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Fused silica</td><td style='text-align: center; word-wrap: break-word;'>1.94</td><td style='text-align: center; word-wrap: break-word;'>1.458</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Sodium chloride</td><td style='text-align: center; word-wrap: break-word;'>2.37</td><td style='text-align: center; word-wrap: break-word;'>1.50</td></tr></table>

Values of  $ K_E $ correspond to the lowest possible frequencies, in some cases as low as 60 Hz, whereas  $ n $ is measured at about  $ 0.5 \times 10^{15} $ Hz. Sodium D light was used ( $ \lambda = 589.29 $ nm).

(Hecht Optics 4th edition)

For the detailed treatment of  $ n^{\prime} $'s dependence on  $ \omega $, will leave for later class.

## 2 -3 Transverse Wave

Let's first assume the E, H are in forms of plane wave. (A plane wave form certainly satisfy the Maxwell equations)

 $$ E(\vec{r},t)=A_{0}e^{i(\vec{k}\bullet\vec{r}-\omega t)} $$ 

Then  $ \nabla E = i\vec{k}E $

 $$ \frac{\partial E}{\partial t}=-i\omega E $$ 

The operators  $ \nabla $, and  $ \frac{\partial}{\partial t} $ act on plane waves as if:

$$\frac{\partial}{\partial t}\rightarrow-i\omega,\text{ which means the operator act on plane wave just like}\text{ multiply it with}-i\omega.$$

 $ \nabla \rightarrow i\vec{k} $, which means the operator act on plane wave just like multiply it with  $ i\vec{k} $.

From Maxwell Equation (2-3)

 $$ \nabla\times\vec{E}=-\mu\frac{\partial\vec{H}}{\partial t} $$ 

Then:  $ i\vec{k} \times \vec{E} = \mu i\omega\vec{H} $

 $$ \therefore\vec{k}\times\vec{E}=\mu\omega\vec{H} $$ 

Similarly from other M-equations:  $ \vec{k} \times \vec{H} = -\varepsilon \omega \vec{E} $

 $$ \vec{k}\bullet\vec{E}=\vec{k}\bullet\vec{H}=0 $$ 

Thus:

(1)  $ \vec{E}, \vec{H}, \vec{k} $ are mutually perpendicular, and form a right-hand Cartesian coordinate system.

 $$ \vec{E}\times\vec{H}\rightarrow\vec{k} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_214_675_394_822.jpg" alt="Image" width="15%" /></div>


(2)Relation between  $ \vec{E} $,  $ \vec{H} $'s amplitude.

From (2-9)  $ \vec{k} \times \vec{E} = kE = \mu \omega H $

 $$ \Longrightarrow E=\frac{\mu\omega}{k}H=\mu c H=c B $$ 

 $$ \begin{aligned}&\because\quad c=\frac{1}{\sqrt{\varepsilon\mu}}\\ &\\ &\Rightarrow E=\sqrt{\frac{\mu}{\varepsilon}}H\approx\sqrt{\frac{\mu_{0}}{\varepsilon}}H=\sqrt{\frac{\mu_{0}}{K_{E}\varepsilon_{0}}}H\\ \end{aligned} $$ 

 $$ \because n=\sqrt{K_{_{E}}} $$ 

 $$ H=\frac{n}{\sqrt{\frac{\mu_{0}}{\varepsilon_{0}}}}E $$ 

 $$ \sqrt{\frac{\mu_{0}}{\varepsilon_{0}}}=377\Omega $$ 

vacuum Impendence

So the magnetic field usually much smaller than the  $ \vec{E} $, and that’s why people usually concentrate on the electric aspect of the Electro-Magnetic waves. But this is not a very good argument since E and B field are in different units. The correct argument that why most materials respond strongly to electric field is because: The force of interaction between the charges with the field, which is the Lorentz force:

 $ F = q(\vec{E} + \vec{v} \times \vec{B}) $, since  $ |E| = c|B| $, and generally  $ v \ll c $, so the first term in Lorentz force which corresponds to the interaction of charge with the E field is much larger than the second term. (E and v x B have same units now and comparison becomes meaningful)

## 2 -4 Energy carried by E-M wave

The energy carried by E-M wave is specified by Poynting vector, defined as:

 $$ \vec{S}=\vec{E}\times\vec{H}\ (\mathrm{In\ unit\ ofWatts/m^{2}}) $$ 

It is the energy flow per unit area, per unit time, and is also called energy flux density (flux the flow across a surface per unit time, here we have

flow across a surface per unit time and per unit area, so is called flux density).

For plane waves:

 $$ \vec{S}=\vec{E}_{0}\times\vec{H}_{0}\cos^{2}(\vec{k}\bullet\vec{r}-\omega t) $$ 

It’s time Average:

 $$ \langle S\rangle=\frac{1}{2}\vec{E}_{0}\times\vec{H}_{0}=\frac{1}{2}E_{0}H_{0}\frac{\vec{k}}{\left|\boldsymbol{k}\right|} $$ 

 $$ \left(\left\langle\cos^{2}\omega t\right\rangle_{t}=\frac{1}{2}\mathrm{i f}t\gg2\pi\Big/\omega\mathrm{s e e p r o b l e m s e t}1\right) $$ 

In isotropic media, the direction of energy flow is same as the propagation direction of the wave front.

Define  $ \langle \vec{S} \rangle $ 's value (or module) is:

 $$ I=\frac{1}{2}E_{0}H_{0}=\frac{1}{2}n c_{0}\varepsilon_{0}E_{0}^{2}=\frac{1}{2}\frac{n}{c_{0}\mu_{0}}E_{0}^{2}\propto E_{0}^{2} $$ 

“I” has the name of  $ \underline{\text{radiant flux density}} $; it measures the energy flow per unit time and unit area. Sometimes it is also called “irradiance” or “excitance”, depending whether the energy flow into or out of some surface. Sometimes “I” is also called intensity, this is loosely fine and is what I will use in this course, since intensity, rigorously speaking is defined differently. For the thorough discussion on the various terms on Radiometry which will not be covered in this course, please refer to Zhao’s Book, pg120-137.

In the following sections when we are only interested in the relative intensity in same media, the propotinonal constatnt in front will be same, so I will often just use  $ I = |E|^2 = |E_0|^2 $.

One word of comment: this will make dimension analysis a nightmare since I neglect the unit of the proportion constant, and when you really care about the absolute value of intensity, of course you should use formula in (2-13).

*Supplement: Energy of the E-M field and energy flux (the Poynting vector)

I did not give the derivation in the notes above, since this is usually given in E-M class. The derivation below is mainly for self-containment.

The energy of the field can be understood from the work-energy theorem, i.e. the work done by (or to) the field equals the energy change of the field. The force here during the interaction between the field and the matter would be Lorentz force:

Suppose the field is created by certain charge-current configuration and if some free charges move a small distance, dl, and then the work done by the field is:

 $$ d W_{work}=\vec{F}\cdot d\vec{l}=q(\vec{E}+\vec{v}\times\vec{B})\cdot\vec{v}dt=q\vec{E}\cdot\vec{v}dt,with q=\rho d V,and\rho\vec{v}=\vec{j} $$ 

Where  $ \rho $ volume charge density and j is the current density. Then the total power (dW/dt) is:

$$P_{workpower} = \iiint_V \vec{E} \cdot \vec{j} dV \, , \quad j = \nabla \times H - \frac{\partial D}{\partial t} \quad (I \text{ did not put the little arrow on the vector for time saving, and I hope this would not cause confusion})$$

 $$ E\cdot j=E\cdot(\nabla\times H-\frac{\partial D}{\partial t})=E\cdot\nabla\times H-E\cdot\frac{\partial D}{\partial t} $$ 

 $$ \because\nabla\cdot(E\times H)=H\cdot\nabla\times E-E\cdot\nabla\times H\quad(general product rule of \nabla) $$ 

 $$ \therefore E\cdot j=-\nabla\cdot(E\times H)+H\cdot\nabla\times E-E\cdot\frac{\partial D}{\partial t}=-\nabla\cdot(E\times H)-H\cdot\frac{\partial B}{\partial t}-E\cdot\frac{\partial D}{\partial t} $$ 

 $$ H\cdot\frac{\partial B}{\partial t}=\mu H\cdot\frac{\partial H}{\partial t}=\frac{1}{2}\mu\frac{\partial(H\cdot H)}{\partial t}=\frac{1}{2}\frac{\partial(H\cdot B)}{\partial t} $$ 

 $$ similarly\quad E\cdot\frac{\partial D}{\partial t}=\frac{1}{2}\frac{\partial(D\cdot E)}{\partial t} $$ 

 $$ E\cdot j=-\nabla\cdot(E\times H)-\frac{1}{2}\frac{\partial(D\cdot E)}{\partial t}-\frac{1}{2}\frac{\partial(H\cdot B)}{\partial t} $$ 

 $$ \frac{dW}{dt}=\iiint\limits_{V}E\cdot jdV=-\iint\limits_{S}E\times H\cdot dS-\frac{d}{dt}(\iiint\limits_{V}(\frac{1}{2}D\cdot E+\frac{1}{2}H\cdot B)dV) $$ 

The last equation carries a clear physical meaning. The left-hand states that the work done by the field, the right-hand states the E-M energy changes in the field. The equation states the work done by the field equals to the energy decrease of the field, no surprise there! Take a closer look of the energy change of the field, the last term is clearly the change of energy of the field stored inside the volume (I hope this is obvious to you, if not, recall that the energy density of the electric and magnetic field are 1/2D.E and 1/2H.B respectively). The first term on the right-hand side is the energy flow out of the surface bounded the volume, with an energy flow density (the flux density) ExH, which is called Poynting vector. The physical meaning of it is the energy flow across a perpendicular surface with unit area per unit time. This is the energy flow carried by a traveling electro-magnetic wave!

## 2 -5 Momentum of E-M Field

<div style="text-align: center;"><img src="imgs/img_in_image_box_291_1152_520_1308.jpg" alt="Image" width="19%" /></div>


Light is incident or a surface. The surface will absorb the light. Light will generate a pressure (radiant pressure) on the surface, or equivalently transform momentum to the surface.

From E-M Theory (detailed proof is in Jackson's "Classical Electrodynamics" section 6.7. A simple argument can be found in 年绪成 波动与光子 3.2.2 ), the change of momentum in the E-M field is proportional to the energy absorbed by the surface. This is not surprise since we learned from special relativity that the momentum and energy of the light are related by the famous: p=E/c

 $$ \Delta p=\frac{\Delta W}{c}\hat{u}_{\bar{k}} $$ 

 $$ \Delta W=SA\Delta t $$ 

$\Delta W$ is the energy absorbed (lost by the light to the surface), $S$ is the value of Poynting vector and $A$ is the area, $\hat{u}_{\bar{k}}$ is unit vector along light propagation.

Thus:

 $$ \vec{F}=\frac{\Delta p}{\Delta t}=\frac{S A}{c}\vec{u}_{k} $$ 

 $$ P_{r e s s u r e}=\frac{F}{A}=\frac{S}{C} $$ 

Radiant Pressure:  $ <P_{\text{ressure}} \geq \frac{\langle S \rangle}{C} = \frac{I}{C} $ (2-16) (<> means time average)

Momentum change is:  $ \Delta p = p_v(c\Delta tA) $ ( $ p_v $: Momentum Density; A: area)

 $$ \Rightarrow p_{v}=\frac{S}{C^{2}} $$ 

From the photon picture, each photon carries energy:

 $$ E=h\upsilon=\hbar\omega $$ 

Then from 2-14, the momentum of each photon would be :

 $$ \begin{aligned}&p=\frac{E}{c}=\frac{h}{\lambda}=\hbar k\\ &\\ Or\quad\vec{p}=\hbar\vec{k}\\ \end{aligned} $$ 

If the photon number density is n (number of photons per volume), then the energy flux density will be: $S = n\hbar\omega c$, and the momentum density will be $p_v = n\hbar k$, and we will have exactly same relation as (2-17) from this photon’s point of view.

Comments:

(1) The momentum of light (E-M field ) is simple to visualize using the photon picture, just as air pressure is created from collision of molecules with the surface, the light pressure is created by the change of photon momentum.

(2) Classically, the momentum of the E-M field can be understood from Lorentz Force:

 $$ F=q(\vec{E}+\vec{\nu}\times\vec{B})\qquad\qquad\mathrm{f o r~c h a r g e d~p a r t i c l e} $$ 

The force due to electric field will drive the particle on the surface into forced oscillator parallel to the surface (Recall the  $ \vec{E}, \vec{B} $ are parallel to the surface in the normal illumination case here).  $ \vec{v} $ is the speed of such oscillation of the charged particle, and  $ \vec{v} \times \vec{B} $ will be a force in the direction of  $ \vec{k} $, the direction of wave propagation, it is this force responsible for the radiant pressure and momentum change of the field.

(Note: if $\vec{v}$, $\vec{B}$ are random, $\vec{v} \times \vec{B}$ can be either in direction of $\vec{k}$ or $-\vec{k}$; the reason that radiant pressure (or force) is in the direction of $\vec{k}$ is because: $\vec{v}$ is the speed of a forced oscillation driven by $\vec{E}$, it is partially in phase with $\vec{E}$, we are going to prove that the phase lag between $\vec{v}$ and $\vec{E}$ is between $-\frac{\pi}{2} - \frac{\pi}{2}$. So $\vec{v}$ is somewhat in the direction of $\vec{E}$, and $\vec{E} \times \vec{B} \to \vec{k}$)

(3) Application of radiant pressure:

a. Optical cooling :

 $ \xrightarrow{\text{photon}} \quad \leftarrow \quad O $

 $ \xrightarrow{\text{atom/molecule}} $

Absorption of photon will slow down the atom/molecule.

b. Laser separation of isotopes.

## 2 -6 Photons

Photon is the elementary “particles” of the E-M field, here I shall only provide the result without detailed explanations.

Energy:

 $$ E=h\upsilon=\hbar\omega $$ 

Momentum:

 $$ \vec{p}=\hbar\vec{k} $$ 

Photon flux:

 $$ \Phi=\frac{P}{E}=\frac{P}{hv} $$ 

 $ \Phi $ is the number of photon/unit time; P is optical power here (such as that measured by a power meter)

Photon density:

 $$ n_{_{p}}\cdot C\cdot Area=\Phi $$ 

 $ (n_{p} $ is number of photon/ unit volume $

The nature of photon, its quantum behavior will be out of the scope of this class. It will be treated in specific class such as photon statistics, and quantum optics. For the wave-particle duality of light, we shall discuss that in the quantum section of this course.

## 2 -7 Radiation (light) sources——A classical treatment

Radiations are generated by : Accelerated charges.

The accelerated charges will radiate E-M wave.

(1)Linearly accelerating charges (Hecht 3.4.1, 3.4.2)

The radiation created by such sources will not be treated in detail here,

refer to Hecht's book for the brief introduction.

(2) Oscillating Charges—— Dipole radiation

This is radiation created by atoms/molecules, composed of most light sources in daily life, as well as in lab, Such as light bulbs, neon light, lasers .....

For such radiation, the  $ \underline{simple quantum} $ pictures are transition between energy levels of atom/molecule: when the electron in the atom/molecule relaxes from excited state (upstairs) to ground state (downstairs), accompanying with emission of light:

<div style="text-align: center;"><img src="imgs/img_in_image_box_205_995_999_1152.jpg" alt="Image" width="66%" /></div>


The full quantum description is out of the scope of the course, and can be found in courses, such as “Quantum Mechanics”. The simple picture is sufficient to understand the radiation (Emission) by the common light sources.

The atoms/molecules are randomly excited to the excited states by

thermal heating or electron bombardment, and emit out light (conventional light source); or the atoms/molecules are excited coherently (we shall discuss, explain this word later) and emit out coherent light (laser)

Here, we give the classical treatment of atom/molecules as electric dipole oscillator:

<div style="text-align: center;"><img src="imgs/img_in_image_box_206_553_993_758.jpg" alt="Image" width="66%" /></div>


The dipole (defined with  $ \vec{d}=q\vec{r} $, q is the charge and the r is the displacement vector, convention is r is from negative charge to positive) oscillation reduces to the problem of solving the motion equation of  $ \underline{r} $

Such problem is treated in detail in other textbooks such as we discussed in the oscillation part in mechanics. Basically:

(a) Free harmonic oscillation with restoring force:

 $$ m\ddot{r}+k r=0 $$ 

(k: restoring term)

 $$ r=A e^{-i(\omega_{0}t+\phi)}\quad\omega_{0}=\sqrt{\frac{k}{m}} $$ 

The reason that restoring force is in form of kr, obeys Hook's Law

can be understood as follows: for any energy potential in arbitrary form

<div style="text-align: center;"><img src="imgs/img_in_image_box_543_226_813_350.jpg" alt="Image" width="22%" /></div>


with equilibrium, such as

At the small region around equilibrium, the potential can be approximated by a harmonic potential, and the force will obey Hook's Law.



This can be seen by expand  $ U(x) $ into Taylor series

 $$ \begin{aligned}&U(x)=U(x_{0})+\frac{\partial U}{\partial x}\Big|_{x_{0}}\Delta x+\frac{1}{2}\frac{\partial^{2u}}{\partial x^{2}}(\Delta x)^{2}+\ldots\ldots\\ &\\ \Rightarrow\quad U(x)\sim\frac{1}{2}kx^{2}\Rightarrow F=kx\\ \end{aligned} $$ 

(b) Damped Oscillator

Introducing a resistance force:  $ f_{r} = -b \frac{dr}{dt} $

The equation comes:

 $$ m\ddot{r}+b\dot{r}+k r=0 $$ 

 $$ \begin{array}{r l r l}{\mathrm{O r}}&{{}\ddot{r}+\gamma\dot{r}+\omega_{0}^{2}r=0}&{}&{{}\mathrm{~w h e r e~}\gamma=\frac{b}{m}}\end{array} $$ 

The general solution for this equation is in the form of:

 $$ \begin{aligned}&r=A e^{-\frac{\gamma t}{2}}e^{-i\left(\omega^{\prime}t+\phi\right)},where\gamma^{2}<<\omega_{0}^{2}\\ &\omega^{\prime}=\sqrt{\omega_{0}^{2}-\left(\frac{\gamma}{2}\right)^{2}}\\ \end{aligned} $$ 

This is a damped oscillation with weak damping, the amplitude decay exponentially with time and the frequency is a little shifted from the natural frequency. It corresponds to an oscillator with a dissipation, such as caused by friction, heat loss, etc.

## (c) Forced oscillator

If the oscillator is driven by an external periodic force, such as the electric force :

 $$ F=q\vec{E}=q E_{0}e^{-i\omega t} $$ 

The equation of motion would be:

 $$ \ddot{r}+\gamma\dot{r}+\omega_{0}^{2}r=\frac{q_{e}E_{0}}{m}e^{-i\omega t} $$ 

The solution of the equation at longer time(steady state):

 $$ r=\frac{q_{e}E_{0}}{m}\frac{1}{\omega_{0}^{2}-\omega^{2}-i\omega\gamma}e^{-i\omega t} $$ 

The (2-23) shows that, the dipole oscillation under periodic driving force  $ e^{-i\omega t} $, is a harmonic oscillation  $ \underline{\text{with same frequency as the driving force!}} $

Its amplitude and phase of oscillation can be estimated from (2-23) too. The phase of the force oscillation always Lag that of the driving field (this is a physical argument). The phase Lag is between  $ 0-\pi $. The amplitude is large when  $ \omega = \omega_{0} $ (resonant situation, this is a good

approximation under weak damping; the exact frequency that makes the amplitude largest is slightly shifted from natural frequency, but the difference is negligible under weak damping).

From 2-23, it is easy to show that:

 $$ r=A e^{-i(\omega t+\phi)} $$ 

 $$  where\quad A=\frac{\frac{q_{e}E_{0}}{m}}{\sqrt{\left(\omega^{2}-\omega_{0}^{2}\right)^{2}+\gamma^{2}\omega^{2}}}\quad\quad\left(\frac{q_{e}E_{0}}{m}\rightarrow A_{0}\right) $$ 

 $$ \tan\phi=\frac{\gamma\omega}{\omega^{2}-\omega_{0}^{2}} $$ 

(d) For a oscillating dipole as given by (2-24)

 $ \Rightarrow $ Electric dipole radiation (Hecht’s 3.4.3)

If the electric dipole oscillates as:

 $$ \mu_{d}=q_{e}r=\mu_{d}^{0}e^{-i\omega t}\qquad\left(\mu_{d}^{0}=q_{e}A\right.,the\left.initial\ phase is set to0\right) $$ 

Then the E-M radiation further from the dipole can be expressed into:

 $$ E=\frac{\mu_{d}^{0}k^{2}\sin\theta}{4\pi\varepsilon_{0}}\frac{e^{i k r}e^{-i\omega t}}{r} $$ 

The derivation of this formula is a bit requiring and I shall refer you to the textbooks on E-M, such as Griffiths "Introduction to Electrodynamics", Chap.11 for derivation.

The energy flux density (Irradiance):

 $$ I\propto E_{0}^{2}\propto(\mu_{d}^{0})^{2}\omega^{4}\sin^{2}\theta r^{-2} $$ 

Far away from the dipole oscillator, the E-M field generated by it can be approximated by a spherical wave (by taking  $ \sin\theta $ as constant), so the oscillating dipoles are sources of spherical waves. This is an important result and the physical basis for the Huygens’s principle that will be discussed in the next chapter. (2-26) also shows us two features on dipole emission: A) There will be no emission along the direction of dipole (think about antenna which is manmade dipole, no emission along the direction of antenna). B) The emission is proportional to  $ 4^{th} $ power of frequency, and this is the reason that blue light is scattered more and part of the reason the sky is blue.

The classical theory treatment of dipole oscillation and radiation gives quantitative correct answers to many questions, but it has drawbacks, for example, it cannot explain the discreteness of the energy levels (or resonant freq.  $ \omega_{0} $) in atoms/molecules; the physical nature of the dissipation term  $ \gamma $ in atom/molecules. All these puzzles have to resort to the quantum theory.

## 2 -8 One Word on Polarization

Previous, we mentioned (proved) the E-M wave is a transverse wave, i.e. the  $ \vec{E}, \vec{B} $ are vectors are  $ \perp $ to the  $ \vec{k} $, the direction of propagation. The

direction of the  $ \bar{E} $ is called polarization. For the sake of simplicity, I shall treat the field pointing along one linear direction (linear polarized light) most of the time in the following discussion before we treat polarization in detail later (Hecht chap.8, Zhao's Book Chap 2.9).

Here for the later use, we need only to know some polarization state of light:

Natural Light (unpolarized light)

Linear Polarized:

Circular Polarized:

 $$ \begin{array}{ccc} \downarrow & \leftrightarrow & \\ \textcircled{0} & \textcircled{0} & \\ 0 & 0 & \end{array} $$ 

Elliptical Polarized:

Summary on General properties of Light as E-M wave (Chapter 1 and 2).

1. From Maxwell Equation——wave equation.

 $$ \nabla^{2}\vec{E}=\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}}(\mu,\varepsilon\mathrm{i n m e d i a}) $$ 

 $$ \nabla^{2}\vec{H}=\mu_{0}\varepsilon_{0}\frac{\partial^{2}\vec{H}}{\partial t^{2}} $$ 

E-M field indeed propagate as wave——E-M wave.

 $ \vec{E}, \vec{H} $  $ \vec{k} $ form a right-hand Cartesian:

<div style="text-align: center;"><img src="imgs/img_in_image_box_266_696_432_863.jpg" alt="Image" width="13%" /></div>


 $$ \left|E\right|=C\left|B\right|=\sqrt{\frac{\mu}{\varepsilon}}\left|H\right| $$ 

So, knowing  $ \vec{E} $,  $ \vec{H} $ is also known. And since the interaction between light and environment is dominated by  $ \vec{E} $, we shall use  $ \vec{E} $ to represent the light wave.

2. Speed of light, Refraction index, dispersion.

(phase velocity)

 $$ C_{_{0}}=\frac{1}{\sqrt{\mu_{_{0}}\varepsilon_{_{0}}}}\quad C=\frac{1}{\sqrt{\mu\varepsilon}} $$ 

Phase velocity

 $$ n=\frac{C_{_{0}}}{C}=\sqrt{\frac{\varepsilon\mu}{\varepsilon_{_{0}}\mu_{_{0}}}}=\sqrt{K_{_{E}}K_{_{m}}}\approx\sqrt{K_{_{E}}} $$ 

 $ \varepsilon, n $ are frequency dependent  $ \rightarrow $ dispersion

### 3. Solutions of wave equation

For constant shape propagating along certain direction with phase velocity  $ \nu : f\left[k(r - \nu t)\right] $

Special Case:

In one-dimension, the simplest form is harmonic wave:

 $$ E=E_{0}\cos(kx-\omega t) $$ 

In 3-dimension:

①plane wave:  $ E_{0}\cos(\vec{k}\bullet\vec{r}-\omega t) $

(Harmonic wave along k direction)

② spherical wave:  $ \frac{E}{r}\cos(kr-\omega t) $

 $$ \left|k\right|=\frac{2\pi}{\lambda} $$ 

 $$ \omega=2\pi\upsilon $$ 

 $$ \nu=\frac{\omega}{\left|k\right|}=\lambda\upsilon $$ 

 $$ T=\frac{1}{v} $$ 

 $$ \overline{\upsilon}=\frac{1}{\lambda} $$ 

More generally, a wave created by harmonic oscillation is generally expressed by  $ A(r)\cos[\varphi(r)-\omega t] $

 $ \varphi(r) = const \rightarrow \text{Equal phase Surface (wave front)} $

The plane and spherical waves have simple form of wave front,

(plane, sphere) and propagate with certain phase velocity  $ v = \frac{\omega}{k} $.

For an arbitrary form of  $ A(r), \varphi(r) $, the wave’s expression could be complicated, its phase velocity  $ \left[v = \left(\frac{\partial x}{\partial t}\right)_\varphi = \frac{-\left(\frac{\partial \varphi}{\partial t}\right)_x}{\left(\frac{\partial \varphi}{\partial x}\right)_t}\right] $ may vary over space. But as we shall see later, the complicated waveforms can be decomposed into a superposition of simple wave, such as plane waves. (Fourier Transform, Superposition Principle)

### 4. Complex Representation and Phasors

 $$ A(r)\cos\Big[\varphi\big(r\big)-\omega t\Big]\leftrightarrow A(r)e^{i\varphi\big(r\big)}e^{-i\omega t} $$ 

Plane wave:

 $$ Ae^{i\vec{k}\bullet\vec{r}}e^{-i\omega t} $$ 

Spherical wave:  $ \frac{A}{r}e^{ikr}e^{-i\omega t} $

### 5. Energy and momentum of light

Classical E-M wave photon

Energy:

 $$ S=\vec{E}\times\vec{H} $$ 

 $$ E=h\upsilon=\hbar\omega $$ 

 $ \langle S \rangle = I \propto E_0^2 \quad \text{(I: Energy flux density)} $

 $$ I=n_{\mathrm{v}}C\hbar\omega=n_{f}\hbar\omega\quad\left(n_{\mathrm{v}}\mathrm{:v o l u m e d e n s i t y;}\quad n_{f}\mathrm{:f l u x d e n s i t y}\right) $$ 

Momentum:  $ \Delta P = \frac{\Delta w}{C} $ ( $ \Delta w $: power change)

 $$ P_{p h o t o n}=\hbar\vec{k} $$ 

 $$ P_{v}=\frac{S}{C^{2}} $$ 

 $$ \left|p\right|=\frac{h}{\lambda} $$ 

 $$ \begin{aligned}\mathcal{P}\begin{cases}=\frac{I}{C}(absorbing)\\ =\frac{2I}{C}(reflection)\end{cases}\quad\mathcal{P}:pressure\end{aligned} $$ 

6. Dipole oscillation and radiation.

Quantum



Classical:

Forced oscillation picture:

 $$ \int\limits_{\sqrt{g r o n d}}^{\text{Excited}}\hbar\omega $$ 

 $$ r=\frac{A_{0}}{\omega^{2}-\omega_{0}^{2}+i\gamma^{2}\omega}e^{-i\omega t} $$ 

Oscillation with same freq.  $ \omega $ (driving field is  $ E_{0}e^{-i\omega t} $) but with a phase lag.

Or:  $ r = A e^{-i(\omega t + \phi)} $, with

 $$ A=\frac{\frac{q_{e}E_{0}}{m}}{\sqrt{\left(\omega^{2}-\omega_{0}^{2}\right)^{2}+\gamma^{2}\omega^{2}}}\qquad\tan\phi=\frac{\gamma\omega}{\omega^{2}-\omega_{0}^{2}} $$ 

The E-M radiation flux density:

 $$ I\propto\left(\mu_{d}^{\mathrm{~0~}}\right)^{2}\omega^{4}\sin^{2}\theta,\mathrm{w h e r e}\quad\mu_{d}^{\mathrm{~0~}}=q_{e}A $$ 

At large distance from source, where  $ \sin\theta $ does not change much, dipole radiation~ spherical wave source:

 $$ E\propto\frac{e^{ikr}e^{-i\omega t}}{r} $$ 

7. Doppler Effect

At smallν, (ν is the relative motion speed between observer and light source)

 $$ \frac{\Delta\upsilon}{\upsilon_{0}}=\frac{-\vec{\nu}\bullet\vec{n}_{k}}{C}\left(\Delta\upsilon=\upsilon^{\prime}-\upsilon_{0}\right) $$ 

The spectral line width broadening due to Doppler Effect:

 $$ \Delta\upsilon=\frac{2\sqrt{2\ln2}}{c}\sqrt{\frac{kT}{m}}\upsilon_{0} $$ 

## Chapter 3 The propagation of Light

(Hecht, chap 4, Zhao, chap1. (1)-(3), chap3, (10))

<div style="text-align: center;"><img src="imgs/img_in_image_box_200_383_940_805.jpg" alt="Image" width="62%" /></div>


We focus on what are most relevant to geometric optics: Reflection and Refraction and Transmission in this chapter. We are not going to treat absorption and dispersion in detail here (Please refer to Hecht's 3.5 or Zhao's Vol2, P228-244 for more details on this)

We shall first give out the Phenomenal Rules (That is rules based on macroscopic observations) that govern the propagation of light through media; (Zhao’s 1.1-1.3) Then we are going to take a deeper look from microscopic point of view, such as scattering process between light and particles, to further understand the physical basis for such rules. Finally, we are going to use Maxwell equation to prove the results and derive Fresnel equations that give quantitative results on reflection and

refraction.

## 3 -1 Treatise Based on Macroscopic Observations

(1) Light travels in straight path, in homogeneous isotropic media.

Homogeneous: The media is evenly distributed, density is a constant.

Isotropic: The physical property is not directional dependent.

In inhomogeneous or anisotropic media, such as air with temperature gradient, etc., light path can be bent, which can generate phenomenon known as Mirage.

There are also cases that when light meets something that on the size of the wave length of light, deviation from straight path occurs, we are going to treat this behavior in topics of diffraction later. (Here, strictly speaking, we treat wave length of light is much smaller than the sizes in concern, or  $ \lambda \approx 0 $)

(2)Reflection and Refraction:

When light goes from one media to another, at the interface:

<div style="text-align: center;"><img src="imgs/img_in_image_box_330_152_874_529.jpg" alt="Image" width="45%" /></div>


Reflection:  $ i_{1}=i_{1}^{\prime} $;  $ n_{1}<n_{2} $ External reflection

 $ n_{1} > n_{2} $ Internal reflection

Refraction:  $ n_{1}\sin i_{1}=n_{2}\sin i_{2} $ ——Snell's law

All the “rays” are in the same plane. ——plane of incidence

Rays: For conveniently showing the propagation of light, we use rays to represent waves. A ray is a line in space corresponding to the direction of flow of energy. In the isotropic media, rays are simply in the direction of wave vector $ \vec{k} $, which are orthogonal trajectories of the wave front (perpendicular to the equal-phase plane).

Changes of light upon refraction (Hecht, pg. 102)

(a) Changes direction of propagation —— Snell's law.

 $$ n_{1}\sin i_{1}=n_{2}\sin i_{2} $$ 

(b) Changes the cross section of the beam of plane wave, thus varies the

irradiance I (energy/Area)

 $$ S_{1}=\overline{A}\overline{B}\cos i_{1} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_226_504_435.jpg" alt="Image" width="23%" /></div>


 $$ S_{2}=\overline{A}\overline{B}\cos i_{2} $$ 

 $$ \frac{S_{2}}{S_{1}}=\frac{\cos i_{2}}{\cos i_{1}} $$ 

(c) Changes phase velocity of light

 $$ \nu=\frac{c}{n} $$ 

If  $ \omega $ is same (think why?), the wave length in a media will depend on n,

 $$ \lambda=\frac{\lambda_{0}}{n}\qquad\lambda_{0}\mathrm{~vacuum~wave~length~} $$ 

## 3 -2 Huygens's Principle

Every point on a propagating wave front serves as a source of spherical secondary wavelet, such that the wave front at some later time is the envelope of these wavelets.

(Fig 4-26 in Hecht’s Book or Fig2-2 in Zhao’s Book)

<div style="text-align: center;"><img src="imgs/img_in_image_box_291_159_843_437.jpg" alt="Image" width="46%" /></div>


The secondary wavelets in Huygens’s principles are imaginary points on the wave front (virtual wavelets). These secondary wavelets have the same freq. ∅ and same phase velocity of the propagating wave in media. The Huygens’s principle is a very useful tool, and can be used to derive the rules of reflection and refraction (It is basically some simple geometry and the details are in Zhao’s Book, pg. 26-30).

We are going to see that this principle is highly useful to construct the wave front, estimate the phase distribution over space etc. when we treat the diffraction. (The Huygens's — Fresnel principle)

As to the physical basis for the principle, when light interacts with the atoms/molecules of the media, the secondary wavelets can be viewed as the radiation from the forced dipole oscillation plus(superpose) the primary wave. However in vacuum, the secondary wavelets in the principle have to be viewed as imaginary points, so:

Treat the principle as a useful tool rather than the real physical existence would be most proper.

## 3 -3 Fermat's Principle $ ^{3} $

## Important Concept: Optical Path Length (OPL)

It is the effective (equivalent) distance that light traveled at speed of  $ C_0 $, the vacuum speed. For propagating wave, the phase difference between two points  $ Q $,  $ P $ depends on distance of  $ \overline{QP} $ and the wave length  $ \lambda $ (or  $ k = \frac{2\pi}{\lambda} $). In different media, the  $ \lambda $ is different ( $ \lambda = \frac{\lambda_0}{n} $). The same distance may correspond to different phase change. To eliminate this inconvenience, we introduce the concept of optical path length (OPL).

Defined as:

<div style="text-align: center;"><img src="imgs/img_in_image_box_278_918_525_1176.jpg" alt="Image" width="20%" /></div>


OPL is:

 $$ (QP)=\sum_{i}n_{i}l_{i}=\int_{Q}^{P}ndl $$ 

(QP) is related to the phase difference between Q and P for a wave.

 $$ E_{Q}=E_{0}e^{i\phi_{Q}} $$ 

 $$ E_{P}=E_{0}^{\prime}e^{i\phi_{P}} $$ 

 $$ \Delta\phi_{QP}=\phi_{p}-\phi_{Q}=\frac{2\pi}{\lambda_{_{0}}}(QP) $$ 

Thus we take the consideration on refractive index into  $ (QP) $, the OPL and treat light in any media travels at speed  $ C_{0} $, or wave length of  $ \lambda_{0} $ when calculate its phase difference.

Fermat’s Principle (Variational principle).

A light ray goes from point Q to point P must traverse an optical path length that is stationary with respect to variations of the path:

 $$ \delta(QP)=\delta\int_{Q}^{P}ndl=0 $$ 

This principle can also be used to prove the rules of deflection and refraction. (The light travels in straight path in homogeneous, isotropic media is obvious with Fermat's principle).

(Optional) The physical significance underline the principle is discussed in Hecht's Book (Fig4.34, 4.35, also see pg. 139-140, Fig.4.68). Basically, it has to be understood from superposition of waves (Interference). In the figure below: the vertical axis is the optical path length; the horizontal axis is some parameter, specifying the path (here is

a simplification where the path can be specified by one variable)

<div style="text-align: center;">(ap)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_265_263_530_447.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_675_299_887_425.jpg" alt="Image" width="17%" /></div>


The paths around the stationary paths (specified by points A,O,B) have almost equal OPL and thus when superposed, will interfere constructively. The paths away from stationary will arrive P out-of-phase with each other and therefore tend to cancel. A more concrete example is reflection by mirror: given the initial and final points (S, P), the position on the mirror (say x) will specify the path. The contribution (represented by phasors) around the stationary path (group-I) and that from another region is shown in the figure (b).

<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_243_1005_643_1248.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_248_1321_530_1422.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_246_1443_499_1527.jpg" alt="Image" width="21%" /></div>


Another way of seeing this, borrowed half-wavelength plate method used in diffraction (we shall come to this again).

<div style="text-align: center;">OPL</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_190_304_828_909.jpg" alt="Image" width="53%" /></div>


Within each half-wavelength zone, the contributions are phasors(the little arrows in the figure, representing the probability amplitude of light taking some particular path) with phase difference between  $ -\frac{\pi}{2}-\frac{\pi}{2} $ and add up sort of constructively to give none zero result (such as bigger arrow 1 and 2 above); between half-wavelength zones they are out of phase and cancel each other. The total contributions will be summation of all these zones and that will result in many cancellations. The important property of the stationary point (around zone 1) is that the contribution of this zone around the stationary is the largest (recall the definition of stationary). In

the figure above, the line segment of zone 1 is the longest and there will be more states (represented by little arrow phasors) and thus larger resultant contribution. The contributions from other regions (say zone 2 and 3 etc.) have similar amount but cancelled each other. So the summation will show the contribution from zone 1 only and the light appears to take paths around stationary point.

(The above reasoning is not a rigorous proof, but used to see the superposition principle behind the Fermat's principle, and the approach is idea of Feynman path integral in quantum).

The least OPL (stationary OPL) of Fermat’s principle triggers the least action Formalism of Lagrange in classical Mechanics, and path-integral formalism by Feynman in Quantum Mechanics, which implies that the variation principles may be the Mother Nature’s fundamental Law. Since we use OPL in the principle, and the time taken for the light passes certain path will be OPL/c₀, thus the Fermat principle is also termed least time principle (It is not necessarily a minimum, a stationary point can be minimum, maximum or inflection point, but it is customary to call it least…).

## 3 -4 Two examples using Snell's equation

### (1) . Total Internal Reflection (TIR)

<div style="text-align: center;"><img src="imgs/img_in_image_box_229_168_496_379.jpg" alt="Image" width="22%" /></div>


 $ n_i > n_t $ Internal reflection

 $$ \theta_{i}<\theta_{t} $$ 

By the time  $ \theta_t $ reaches  $ 90^\circ $, there will be no transmission, all the light will be reflected, the  $ \theta_i $ when  $ \theta_t = 90^\circ $ is the critical angle of TIR:

 $$ \theta_{i}\sin\theta_{i}=n_{t}\sin n_{t} $$ 

 $$ \sin\theta_{i}=\frac{n_{t}}{n_{i}}\sin n_{t} $$ 

 $$ \theta_{_{t}}=90^{o}\rightarrow\sin\theta_{_{c}}=\frac{n_{_{t}}}{n_{_{i}}} $$ 

Application: Optical Fiber

### (2) . Prism and Dispersion

Since n is dependent on  $ \omega $, different  $ \omega $ light will have different refraction angles and can be separated in space. A prism is such a device.

Here we are going to see the ability of dispersion by a prism, and show that the dispersion power is quite limited (i.e. the prism is not a sensitive dispersion device, it is one of the simplest, however)

For simplicity in math, take prism is equal-lateral right-angled

<div style="text-align: center;"><img src="imgs/img_in_image_box_214_241_750_441.jpg" alt="Image" width="45%" /></div>


 $$ \alpha=90^{\circ} $$ 

$i_{i}^{\prime}$ will depend on $n$ ($\omega$), the $\omega$ dependent index of refraction. The question is $\frac{di^{\prime}}{d\omega}$, we need first find relation bet. $i_{i}^{\prime}$ and $n$ ($\omega$), then from

 $$ \frac{dn}{d\omega}\rightarrow\frac{di^{\prime}}{d\omega} $$ 

From Snell's Law:

 $ n\sin i_2 = \sin i_1 $

 $ n\sin i_2' = \sin i_1' $

 $$ i_{2}^{^{\prime}}+i_{2}=90^{o}=\alpha $$ 

 $$ \sin i_{2}^{^{\prime}}=\cos i_{2} $$ 

Eliminate  $ i_{2} $, using above relations and

 $$ \cos^{2}i_{2}+\sin^{2}i_{2}=1 $$ 

 $$ \sin i_{1}^{\prime}=\sqrt{n^{2}-\sin^{2}i_{1}} $$ 

Take derivative vs.  $ \omega $

 $$ \cos i_{1}^{^{\prime}}\frac{d i_{1}^{^{\prime}}}{d\omega}=\frac{d u}{d\omega}\frac{d(\sqrt{n^{2}-\sin^{2}i_{1}})}{d n} $$ 

 $$ \frac{d i_{1}^{\prime}}{d\omega}=\frac{1}{\cos i_{1}^{\prime}}\frac{n}{\sqrt{n^{2}-\sin^{2}i_{1}}}\frac{d n}{d\omega} $$ 

 $ \frac{dn}{d\omega} $ is usually small, so the dispersion power of prism is limited.

However, we can choose angle  $ i_{1} $ to maximize the dispersion power.

 $$ \cos i_{1}^{\prime}=\pm\sqrt{1-\sin^{2}i_{1}^{\prime}}=\pm\sqrt{\left(1+\sin^{2}i_{1}\right)-n^{2}} $$ 

Choose  $ i_{1} \rightarrow 1 + \sin^{2} i_{1} = n^{2} $ will maximize the dispersion power around some spectral range.

## 3 -5 Propagation of Light from Scattering Point of View

In this part we shall understand qualitatively the propagation of light in a media. The basic idea of light propagation in a media is that the field will consist of two parts: one is the original light wave (the primary wave); another is the emissions created by the atoms/molecules of the media under the influence of the primary wave.

Recall the section in the last chapter of this note, the molecules/atoms in the light field, will oscillate with same freq. but with a phase delay with the driving field ( we shall refer to the driving field “primary wave” hence forth ), these oscillators will radiate E-M wave, and act as a secondary spherical wave source. (Note: There is difference between these secondary wavelets due to molecule/atom oscillators with those in

Huygens’s principle. These wavelets generate secondary spherical waves with $C_{0}$, the vacuum phase velocity; those in Huygens’s principle propagate at phase velocity of the media $\frac{C_{0}}{n}$. We stated that the Huygens’s secondary wavelets are superposition of secondary waves and primary waves here in the scattering picture, this point will be clear soon later)

## (1) Transmission

<div style="text-align: center;">Fig. 4.4 and 4.5 in Hecht's Book.</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_186_749_676_947.jpg" alt="Image" width="41%" /></div>


Basically, the secondary waves that propagate along the transmission direction (forward direction) can interfere in phase, constructively. The light field at point P would be summation of all the contributions and thus would be strong.

(2) Sideway scatterings

<div style="text-align: center;">Fig 4.6 in Hecht’s Book or the figure below:</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_261_169_1023_534.jpg" alt="Image" width="64%" /></div>


Seconding waves

 $ L_{1}, L_{2}, L_{3} $ are

OPL to P, differ by

 $ \lambda_{2} $

What I will try to show is that in a homogeneous media, the sideway scattering is small due to cancellation. Suppose a plane wave travels in the media as the arrowed line shows, this primary wave will drive the dipoles and create secondary emission, that is in principle can generate E-M wave sideways. These secondary waves superpose constructively along the direction of primary wave as shown above in (1). However I will argue below that in the sideway direction (the one shown above is perpendicular to the direction of primary wave), the superposition will result in cancellation.



I divide the regions into half-wavelength zones: represented by some belts within which there are many secondary wavelets generated by the driving light. The OPL from the boundary to sideway point P, the Li differs by  $ \frac{\lambda_{0}}{2} $. The contribution to the sideway point P is non-zero within each zone but are out of phase to the adjacent zones and cancel each other, thus the total  $ E_{P} \approx 0 $. If the media is homogeneous

infinitely in all dimensions, the cancellation will be complete (the adjacent zones consist almost same amount secondary wavelets and thus the contributions to point P will be equal in magnitude but with reversed sign). In real cases such as a chunk of glass, there will be boundaries and incomplete cancellation, but the sideway scattering is still quite weak. Also if we introduce some inhomogeneity by droplet of vapors or dusts, the sideway scattering will be enhanced because of the incomplete cancellation. This explains what you see in the movies, the thieves used compressed air cans and spray it to reveal the light alarm network.

Thus inhomogeneous, such as density fluctuation in air, imperfects in crystal, or limited boundaries will give rise to sideway scattering (or it can be viewed as a break of symmetry)

## (3) Reflection at interface—— A result of symmetry breaking

<div style="text-align: center;"><img src="imgs/img_in_image_box_243_1160_1027_1330.jpg" alt="Image" width="65%" /></div>


Originally the light travels in a media, say a glass rod, and I shall break the rod into two pieces as in (b),  $ E_{1} $ and  $ E_{2} $ are reflected light

that results from backward scattering of molecules/atoms at depth~ $ \frac{\lambda_0}{2} $

from the interfaces.

If we bring the two parts in figure (b) together, we should get back to the situation in (a) without no net energy flow backward, meaning the reflection will diminish. This means  $ E_1 + E_2 = 0 \Rightarrow |E_1| = |E_2| $ and with a phase difference by  $ \pm\pi $

Example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_210_701_474_870.jpg" alt="Image" width="22%" /></div>


There are cases that we need to evaluate the phase difference between the fields of top reflection and the bottom reflection at certain point, for illustrating purpose, I designate Q for top reflection and P for bottom reflection.

 $$ \Delta\phi_{QP}=\frac{2\pi}{\lambda_{0}}(2nd)+\pi $$ 

The phase difference has two contributions:

$$\frac{2\pi}{\lambda_{0}}(2nd):\mathrm{Due to OPL difference};\qquad\pi:\mathrm{Half-wavelength difference}$$

(4) Different phase velocity in the media

The phase velocity of light in media is

 $$ \nu=\frac{c}{n} $$ 

However, the scattering picture as shown before, the secondary wave and primary wave all propagate in media with same  $ \omega $ and same phase velocity  $ c $, then why  $ v \neq c $?

This can be understood also from superposition of waves

Total Wave = Primary + Secondary (superposition principle)

Between primary and secondary wave, there is a phase difference.

 $$ \Delta\phi=\phi_{s}-\phi_{i} $$ 

 $ \phi_s $: secondary;  $ \phi_i $: primary $

(a)  $ \Delta\phi = 0 $  $ \nu = c $

(b)  $ \Delta \phi > 0 $ secondary lags primary

(Hecht’s book, Fig. 4.9, 4.10 and 4.11)

<div style="text-align: center;"><img src="imgs/img_in_image_box_188_1191_998_1484.jpg" alt="Image" width="68%" /></div>


 $$ \begin{array}{r l}{\mathrm{A t}X_{_{A}},\quad}&{{}E_{_{T o t a l}}=E_{_{p r i.}}+E_{_{\mathrm{s e c o n d}}}=E_{_{0}}^{\prime}e^{i\varepsilon_{_{A}}}e^{-i\omega t}}\end{array} $$ 

 $ \varepsilon_{A} $ is the phase lag between the total wave and primary wave at point A.

At  $ X_{B} $, this  $ E_{Total} $ will act as primary wave and there will be further delay of phase, the secondary wave from  $ X_{B} $ will have phase lag compared to  $ E_{Total} $, thus generally when we treat the media as continuous:

 $$ \varepsilon=\alpha X,\alpha>0for phase Lag. $$ 

The resulting wave (sum of secondary and primary) would be:

 $$ e^{i(k_{0}+\alpha)x}e^{-i\omega t} $$ 

 $$ \therefore k=k_{0}+\alpha, $$ 

 $$ \nu=\frac{\omega}{k}<\frac{\omega}{k_{0}}=c $$ 

So the phase velocity is different than that of c even though both primary wave and secondary waves propagate with c, it is caused by the phase difference between them.

(c) Likewise, if  $ \Delta\phi < 0 $, secondary leads in phase $ ^{4} $,  $ (\alpha < 0) $

The phase velocity certainly can supersede speed of light, this does not violate relativity, since the phase velocity is not the propagation speed of physical entity.

## 3 -6 Fresnel Equations

——E-M treatment of light's propagation through interface.

(Zhao's Book , vol. 1 P245-266, Hecht's Book , 4.6)

(You can read either one, there are some differences in notation between the two books: (Left: Hecht’s book; Right: Zhao’s)  $ \varepsilon \leftrightarrow \varepsilon\varepsilon_0 $,  $ n_i \leftrightarrow n_1 $,  $ n_t \leftrightarrow n_2 $. This notes follows Hecht’s)

The phenomenal treatment earlier, though predicts the direction of deflected light (in reflection and refraction), it does not give any quantitative ratio between incident and deflected wave. Here I shall focus on the discussion of how we get this ratio. While the derivation of the direction of reflection and refraction (Snell's law) will not be covered here, but interesting students may refer to Hecht's 4.6 on details about this.

This relation for amplitude and phase, between incident and deflected waves for a plane wave is given by Fresnel Equations, which can be proved by using the boundary conditions of Maxwell equations.

We need first to specify the coordinate system, especially the individual coordinate system for the incident, reflected and refracted beams. This is important, since the signs of equations will depend on the choice of the positive directions of the coordinate system. We can

decompose the electric field into the cases shown below, with component perpendicular or parallel with the plane of incidence.

<div style="text-align: center;"><img src="imgs/img_in_image_box_231_346_561_550.jpg" alt="Image" width="27%" /></div>


<div style="text-align: center;">Fig.1a  $ \vec{E} \perp $ plane of incidence</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_623_307_991_546.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">Fig.1b  $ \vec{B} \perp $ plane of incidence</div>


(1). For any  $ \vec{E} $ in arbitrary direction perpendicular to  $ \vec{k} $, it can always decompose into  $ E_{\perp} $ and  $ E_{\parallel} $ components as shown in the figures.  $ E_{\perp} \rightarrow $ S component,  $ E_{\parallel} \rightarrow $ P component.

(2). The boundary condition of Maxwell equations are:

For  $ \bar{E} $,  $ \bar{H} $ the tangential component along the interface is continuous; (as long as there is no electric current in the interface) For  $ \bar{D} $,  $ \bar{B} $, the normal components across the interface are continuous (as long as no net charges in the interface). The proof is neglected here which is in any standard textbook on EM.

(3). From the boundary condition, it is easy to see that the reflection and refraction won’t mix  $ S(\perp) $ and  $ p(//) $ components of the polarization of light. i.e. if the incident light is S light (Fig1a above), the reflected and refracted light only contain S light; no P components if the incident light

composed of P light, the deflected light then only has P component. (This means the S,P polarized light are eigenvectors of the operation of deflection by interface, we shall not go deeper than this at present)

you can prove this easily, using Fig1a, assuming the  $ E_{i\perp} $ (S light) creates P components upon deflection, and from boundary condition by Maxwell equation,  $ \vec{E}, \vec{H} $, components along  $ \vec{x} $ direction has to be continuous  $ \rightarrow $ P components of  $ \vec{E} $ has to be Zero.

This justifies of our choice of S, P to decompose any polarization.

(4). As in the book (Hecht's 4.6.1), using the boundary condition, it is straightforward to derive the reflection and refraction laws (Snell's law) for the plane wave. The previous phenomenal rules once again can be explained by using E-M theory. Moreover, the boundary condition also gives the quantitative ratio between the amplitude of the incident and deflected light: The Fresnel equations (Hecht's 4.6.2) and this will be our focus.

A more concise coordinate system, combining Fig1a, 1b into an equivalent one :

<div style="text-align: center;">Fig2.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_305_174_786_535.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_815_191_977_344.jpg" alt="Image" width="13%" /></div>


By using coordinate systems defined for  $ \vec{E}_i $,  $ \vec{E}_r $,  $ \vec{E}_\tau $ in figure 2.  $ E_{si} $,  $ E_{pi} > 0 $ means they are along the direction defined by  $ \vec{S}_i $,  $ \vec{P}_i $ or more precisely they are in phase with  $ \vec{S}_i $,  $ \vec{P}_i $;  $ E_{si} $,  $ E_{pi} < 0 $ means they are in the reverse direction, out of phase. Same arguments applies for the  $ E_{pr} $,  $ E_{sr} $ of the reflected and  $ E_{pt} $,  $ E_{st} $ of the refracted beams, and their signs relate to the defined  $ \vec{P}_r $,  $ \vec{S}_r $;  $ \vec{P}_i $,  $ \vec{S}_t $ respectively as in Fig2.

Applying boundary conditions and after straightforward but tedious computation (details skipped here), the Fresnel equations then are:

\[\begin{aligned}&r_{_{p}}=\frac{E_{\mathrm{p}_{\mathrm{r}}}}{E_{_{Pi}}}=\frac{n_{_{t}}\cos\theta_{_{i}}-n_{_{i}}\cos\theta_{_{t}}}{n_{_{t}}\cos\theta_{_{i}}+n_{_{i}}\cos\theta_{_{t}}}=\frac{\tan(\theta_{_{i}}-\theta_{_{t}})}{\tan(\theta_{_{i}}+\theta_{_{t}})}=\frac{n_{_{ti}}^{^{2}}\cos\theta_{_{i}}-\sqrt{n_{_{ti}}^{^{2}}-\sin^{2}\theta_{_{i}}}}{n_{_{ti}}^{^{2}}\cos\theta_{_{i}}+\sqrt{n_{_{ti}}^{^{2}}-\sin^{2}\theta_{_{i}}}}\\ &(r\mathord{\left/

where  $ n_{ti} \equiv \frac{n_{t}}{n_{i}} $

 $$ r_{s}=\frac{E_{S\mathrm{r}}}{E_{S i}}=\frac{n_{i}\cos\theta_{i}-n_{t}\cos\theta_{t}}{n_{i}\cos\theta_{i}+n_{t}\cos\theta_{t}}=-\frac{\sin(\theta_{i}-\theta_{t})}{\sin(\theta_{i}+\theta_{t})}=\frac{\cos\theta_{i}-\sqrt{n_{t i}^{2}-\sin^{2}\theta_{i}}}{\cos\theta_{i}+\sqrt{n_{t i}^{2}-\sin^{2}\theta_{i}}} $$ 

 $$ t_{_{p}}=\frac{E_{_{pt}}}{E_{_{pi}}}=\frac{2n_{_{i}}\cos\theta_{_{i}}}{n_{_{t}}\cos\theta_{_{i}}+n_{_{i}}\cos\theta_{_{t}}} $$ 

 $$ t_{s}=\frac{E_{S t}}{E_{S i}}=\frac{2n_{i}\cos\theta_{i}}{n_{i}\cos\theta_{i}+n_{t}\cos\theta_{t}}=\frac{2\cos\theta_{i}\sin\theta_{t}}{\sin(\theta_{i}+\theta_{t})} $$ 

 $ i_{i}, i_{t} $ are related by Snell's law.

(In the above formula, the first expression is the primary form derived using boundary conditions of Maxwell equation, the rest are different variations which can be derived from primary form using Snell's law)

There are also Irradiance ratio, and Energy ratio which are direct results from (3-7)-(3-10)

 $$ I\propto n\left|E\right|^{2}(as in equation 2-13) $$ 

Energy=I×Area∝Icosi

 $$ \frac{I_{\mathrm{Pr}}}{I_{Pi}}=I_{p}^{r}=\left|r_{p}\right|^{2},\qquad I_{s}^{r}=\left|r_{s}\right|^{2}——Reflected irradiance $$ 

 $$ I_{_{p}}^{_{t}}=\frac{n_{_{t}}}{n_{_{i}}}\Big|t_{_{p}}\Big|^{2}\quad I_{_{s}}^{_{t}}=\frac{n_{_{t}}}{n_{_{i}}}\Big|t_{_{s}}\Big|^{2}——Refracted irradiance $$ 

 $$ R_{p}=\left|r_{p}\right|^{2}\quad R_{s}=\left|r_{s}\right|^{2}——Reflected energy flow (Reflectance) $$ 

 $$ T_{_{p}}=\frac{n_{_{t}}\cos\theta_{_{t}}}{n_{_{i}}\cos\theta_{_{i}}}\Big|t_{_{p}}\Big|^{2}\quad,\quad T_{_{s}}=\frac{n_{_{t}}\cos\theta_{_{t}}}{n_{_{i}}\cos\theta_{_{i}}}\Big|t_{_{s}}\Big|^{2}\quad\text{—}\text{Refracted}\quad\text{energy}\quad\text{flow} $$ 

(Transmittance)

From conservation of energy and can be proved by Fresnel Equations:

 $$ R_{p}+T_{p}=R_{s}+T_{s}=1 $$ 

The derived Fresnel equations include all the information needed when we discuss relations between incident and deflected beams, below are some important results from the Fresnel equation .(Focus on the  $ r_{p}, r_{S} $)

## 3 -6-1 Amplitude, Brewster angle and Total Internal Reflection

The figures show the computation for the coefficients at different incident angles (Figures 4.41; 4.42 in Hecht's)

<div style="text-align: center;"><img src="imgs/img_in_chart_box_197_599_588_1010.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;">Figure 4.41 The amplitude coefficients of reflection and transmission as a function of incident angle. These correspond to external reflection  $ n_{t} > n_{i} $ at an air-glass interface ( $ n_{t_{i}} = 1.5 $).</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_616_605_994_1011.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">Figure 4.42 The amplitude coefficients of reflection as a function of incident angle. These correspond to internal reflection  $ n_{t} < n_{t} $ at an air-glass interface ( $ n_{t} = 1/1.5 $).</div>


(1) For the S component,

The  $ |r_s| $ increases monotonically with the incident angle, reaching 1 at glance angle ( $ t_s \to 0 $ at glance angle), glance angle is  $ \theta_i = 90^\circ $.

(2)For the P component, the  $ \left|r_{p}\right| $ first decrease to 0 as the incident angle increases to  $ \theta_{B} $ (Brewster angle or polarization angle), then it increases to 1 as angle increases.

The Brewster angle

 $$ \theta_{_{i}}=\theta_{_{B}}\rightarrow\left|r_{_{p}}\right|=0 $$ 

From (3-7), it is easy to see that

 $$ \left|r_{_{p}}\right|=0\quad at\quad\theta_{_{i}}+\theta_{_{t}}=90^{o}\left(\tan(\theta_{_{i}}+\theta_{_{t}})\rightarrow\infty\right) $$ 

 $$ \because n_{i}\sin\theta_{i}=n_{t}\sin\theta_{t}=n_{t}\cos\theta_{i} $$ 

 $$ \therefore\tan\theta_{B}=\frac{n_{t}}{n_{i}} $$ 

At this Brewster angle, only S component is reflected and thus the reflected light is linearly polarized, and transmitted light will be partially polarized due to decreased amount of S. If there are multiple surfaces, the transmitted light will be almost P-polarized. The reflection and transmission is the simplest device to create liner polarized light, such as the Brewster window (a piece of glass aligned at Brewster angle with the axial of the cavity) in a laser cavity.

<div style="text-align: center;"><img src="imgs/img_in_image_box_218_1028_1000_1249.jpg" alt="Image" width="65%" /></div>


(3) Total Internal Reflection.

For external reflection  $ (n_i < n_t) $  $ \left|r_p\right|, \left|r_s\right| \to 1 $ at glance angle

For internal reflection  $ (n_{i}>n_{t}) $, there is a critical angle, where

 $$ \theta_{_{c}}=\arcsin\frac{n_{_{t}}}{n_{_{i}}},i_{_{t}}\rightarrow90^{\circ}.As\quad\theta_{_{i}}\geq\theta_{_{c}},\left|r_{_{p}}\right|,\left|r_{_{s}}\right|\rightarrow1 $$ 

 $$ \begin{array}{r l r}{\mathrm{H o w e v e r,~}t_{_{p}},t_{_{s}}\neq0}&{{}}&{\mathrm{(s e e~3-7,3-8)}}\end{array} $$ 

But energy flow of transmittance:  $ T = \frac{n_{t} \cos \theta_{t}}{n_{i} \cos \theta_{i}} |t|^{2} = 0 $ ( $ \cos i_{t} = 0 $)

This means that there is no energy flow into the optical less dense region  $ (n_{t} $ region), but there are field existing in it. We shall see that this field is created by evanescent wave.

## 3 -6-2 Phase shift

### (Fig 4.44, Hecht's)

Away from the critical angle in case of total internal reflection, the coefficients  $ r_{p}, r_{s}, t_{p}, t_{s} $ are real numbers, so the phase difference here only means the signs change (0 or  $ \pi $). At the TIR, the  $ r_{p}, r_{s} $ will become complex number (left as homework to prove) and phase is referred to the argument of the complex number. This is straightforward but I need to clarify the physical meaning of such phase difference.

(1) Away from the critical angle, the $r,t_{s}$ are either + or -, which means the deflected light are either in phase (means +, for $r,t$) or out of phase(—).

However as we stressed earlier, this +, - are referring to the individual coordinate system we assigned as in Fig.2 of this note, not referring to

the original incident  $ \vec{E} $.⁵ We see that the deflected light,  $ \vec{E}_r $ or  $ \vec{E}_t $ are only in phase (along the direction) or out of phase (reversed direction) with respect to incident  $ \vec{E} $ at normal or glance angle ( $ i_t = 0 $ or  $ 90^\circ $) where the coordinates axes are parallel or anti-parallel. For other incident angles, the angles between  $ \vec{E}_i $ and  $ \vec{E}_r $,  $ \vec{E}_t $ are generally between  $ 0 \sim \pi $ (Hecht’s Fig 4.45 4.46)

Extra comments on phase: For light propagates through interface between two media, the $r_{s}, r_{p}, t_{s}, t_{p}$ carries the phase information of reflected and transmitted light with respect to the $\hat{S}_{r}, \hat{P}_{r}, \hat{S}_{t}, \hat{P}_{t}$ direction defined as in Fig2 of this note.

<div style="text-align: center;"><img src="imgs/img_in_image_box_384_807_766_1067.jpg" alt="Image" width="32%" /></div>


At point o (we can define it as origin point,  $ \vec{r}=0 $)

 $$ E_{ip}(o)=E_{io}e^{i\phi_{op}}e^{-i\omega t}\quad E_{is}=E_{io}e^{i\phi_{os}}e^{-i\omega t}\quad\Delta\phi_{sp}=\phi_{os}-\phi_{op}=\phi_{o} $$ 

The drawing below summarize given the initial phase difference between S and P components for the incident wave, the phase difference between the S and P components of the Transmitted and

Reflected waves can be determined by the transmission and reflection coefficients. Such phase difference between the S,P components will be important to determine the polarization of the field.

<div style="text-align: center;"><img src="imgs/img_in_image_box_197_359_937_908.jpg" alt="Image" width="62%" /></div>


$\Delta\phi_{sp}$ is the phase difference between the $5p$ components.

(2) Examples (Zhao's book p254-255, Fig 10-7, 10-8, 10-9)

The computation for the coefficients of reflection and transmission for the internal and external cases at normal incidence is simplest and the results are illustrated in the figure.

<div style="text-align: center;"><img src="imgs/img_in_image_box_198_1248_962_1516.jpg" alt="Image" width="64%" /></div>


$n_{i}<n_{t}$ , $r_{p}>0$, $r_{s}<0$ ! $t_{p},t_{s}>0$.

It is clear at normal incidence that there is half-wavelength difference  $ \left(\frac{\lambda_{0}}{2},\pi\right) $ between reflected and incident during external reflection  $ (n_{i}<n_{t}) $; No phase difference between reflected and incident light for internal reflection  $ (n_{i}>n_{t}) $. Between the two reflected beams by the top and

<div style="text-align: center;"><img src="imgs/img_in_image_box_529_400_670_505.jpg" alt="Image" width="11%" /></div>


bottom surfaces of a media $\rightarrow$ if $n_{1}=n_{3}$, i.e. a glass plate in air, between the beams 1 (top reflection) and 2 (bottom reflection), there are always extra $\frac{\lambda_{0}}{2}$ (or $\pi$) difference (We have discussed this earlier in the scattering picture of light's propagation. Here we can make more quantitative derivation using Fresnel equations, please also refer to Fig 10-9 of Zhao's Book ). Using Fresnel equations on the reflection coefficients, we can prove (and you are encouraged to do it) that more generally at small incident angle ($\theta_{i}\sim0$): if $n_{2}$ is “sandwiched” between $n_{1}$, $n_{3}$, i.e. $n_{1}>n_{2}>n_{3}$ or $n_{1}<n_{2}<n_{3}$, there will be No half-wavelength difference between top-bottom reflection; if $n_{2}$ is larger or smaller than both $n_{1},n_{3}$, i.e. $n_{2}<(or>)$ $n_{1},n_{3}$, there will be half-wavelength difference. For transmitted light ($t_{s},t_{p}>0$), there are always in phase (at least partially) with $\vec{E}_{i}$.

## 3 -6-3 Stokes Relation

(Zhao's 10.3, p252; Hecht's 4.10, p136)

<div style="text-align: center;"><img src="imgs/img_in_image_box_228_174_516_449.jpg" alt="Image" width="24%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_645_186_929_495.jpg" alt="Image" width="23%" /></div>


From optical reversibility and conservation of energy, it is easy to see from the figure above, that:

 $$ \begin{aligned}&r^{2}(i_{i})+t(i_{i})t^{\prime}(i_{t})=1\\ &\\&r(i_{i})=-r^{\prime}(i_{t})\\ \end{aligned} $$ 

Stokes relations are useful to allow us find simple relations between the coefficients instead of crank through the Fresnel equations. For example: Using Stokes Relation, it is easy to see that in the Brewster angle figure on pg83 of this note, when the light on top surface is at  $ i_{B} $, the light incident on the parallel bottom surface is also at  $ i_{B} $, the Brewster angle (try to convince it yourself).

Also from stroke relation, it is easy to understand why between the reflection from the top and bottom surface, there are always  $ \frac{\lambda_{o}}{2} $ extra OPL difference (extra  $ \pi $ phase difference, the -1 between the two reflection coefficients) and I shall prove this explicitly below.

Previously, we discussed the extra  $ \frac{\lambda_{0}}{2} $ OPL difference between the

internally – externally reflected beams, using the qualitative scattering picture, i.e.

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_278_551_348.jpg" alt="Image" width="27%" /></div>


Now, with Fresnel equation and Stokes relation, we can strictly prove it:

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_457_718_778.jpg" alt="Image" width="40%" /></div>


1,2,3,4 are in forms of plane wave.

Beam1, at point A; the field is  $ E_1 = E_0 e^{-i\omega t} $.

Beam2, at point B,  $ E_{2}=E_{0}e^{i\phi_{B}}e^{-i\omega t} $

 $$ \phi_{B}=k_{0}n_{1}\overline{AB}\sin i_{i} $$ 

Beam3, at point B, the reflected of beam 2:

 $$ E_{3}=r E_{0}e^{i\phi_{B}}\left(r for\ r_{p}or\ r_{s}\right) $$ 

Beam4 at point B, the reflection of beam1 from the bottom surface:

 $$ E_{4}=t r^{\prime}t^{\prime}E_{0}e^{i\phi_{B}^{\prime}}\quad\phi_{B}^{\prime}=\frac{k_{0}n_{2}\overline{A B}}{\sin i_{t}} $$ 

From stokes relation:  $ tr't' = r'(1 - r^2) = -r(1 - r^2) $

 $$ E_{4}=-(1-r^{2})E_{3}e^{i(\phi_{B}^{\prime}-\phi_{B})}\qquad-1\rightarrow e^{i\pi}\mathrm{\quad or\quad }e^{i(k_{0}\frac{\lambda_{0}}{2})} $$ 

Comparing with the field 3, we see that clearly the field 4 has phase difference. The difference has two parts: one is the  $ \phi_{B}^{\prime}-\phi_{B} $ which is the difference in OPL due to the extra distance covered by the bottom reflection; another is the minus sign, which can be written as an extra  $ \frac{\lambda_{0}}{2} $ in difference in OPL.

## 3 -6-4 Evanescent Wave

##### (Zhao's 10.7; Hecht's, 4.7.1)

In the previous discussion on the phase relation, we stated that below critical angle, the phase is either 0, or  $ \pi $.  $ (r, t \text{ are real, either } + \text{ or } -) $.

However at $i_i \geq i_c$ for internal reflection ($n_i \geq n_t$) $Ther_s, r_p$ becomes complex number, (it is easy to see that $at i_i > i_c$, $n^2_{t_i} - \sin^2_{i_i} < 0$, recall $\sin i_i = n_t$). The phase shift of the Reflected S, P components will range between $0 \to \pi$, as the $i_i$ increases from $i_c$ to $90^\circ$. The phase relation is given by eqn. 10.27 in Zhao's Book (pg254), which can be easily derived from (3-5) (3-6), the Fresnel equation.

At a fixed  $ i_{i}(i_{c}<i_{i}<90^{\circ}) $, the phase shift between S, P components of the reflection are different. (Fig 4.44(e) of Hecht's Book)

Also in our previous discussion of TIR, we stated that at  $ i_i > i_c $,  $ |r_s| = |r_p| = 1 $, but  $ |T_s|, |T_p| \neq 0 $. i.e. there are fields in the  $ n_t $ side, but no energy flow to

the  $ n_{t} $ side.

The above peculiar behavior at TIR can be explained by the Evanescent wave. Now we briefly discuss it.

<div style="text-align: center;"><img src="imgs/img_in_image_box_201_369_532_720.jpg" alt="Image" width="27%" /></div>


 $$ E_{t}=E_{o t}e^{i(\vec{k}_{t}\bullet\vec{r}-\omega t)} $$ 

↑ transmitted wave

 $$ \vec{k}_{t}=k_{tx}\hat{i}+k_{ty}\hat{j} $$ 

 $$ k_{tx}=\left|k_{t}\right|\sin i_{2} $$ 

 $$ k_{ty}=\left|k_{t}\right|\cos i_{2} $$ 

 $ At \quad i_i > i_c \quad (\sin i_c = n_{ti}) $

 $$ \begin{aligned}\cos i_{_{_{_{_{_{_{2}}}}}}}=\pm\sqrt{1-\sin^{2}i_{_{_{_{_{_{2}}}}}}}&=\sqrt{1-\frac{\sin^{2}i_{_{_{_{_{i}}}}}}{n^{2}t_{_{_{i}}}}}=\pm i\sqrt{\frac{\sin^{2}i_{_{_{_{i}}}}}{n^{2}t_{_{i}}}-1}\\&\uparrow\\<0at\quad i_{_{_{i}}}>i_{_{_{c}}}\end{aligned} $$ 

 $$ k_{ty}=\pm i\left|k_{t}\right|\sqrt{\frac{\sin^{2}i_{i}}{n^{2}t_{i}}-1}\equiv\pm i\beta $$ 

 $$ \therefore E_{t}=E_{ot}e^{\pm\beta y}e^{i(k_{tx}x-\omega t)} $$ 

Only- $ \beta $y is physical meaningful.

So the Evanescent Wave is a wave whose wave front propagate along the interface, and its amplitude drops exponentially along the direction normal to the interface. No energy flow in this normal direction (Born & Wolf. Chap.1)

The field penetrates to the forbidden area or order of  $ \lambda $

Application of Evanescent Wave

(1). Exciting only molecules at surface.

<div style="text-align: center;"><img src="imgs/img_in_image_box_244_966_696_1056.jpg" alt="Image" width="37%" /></div>


The excitation laser come at angle  $ >i_{c} $, the molecules right at the surface (a few layers of molecules) can be excited by the Evanescent Wave.

### (2) . Beam Splitter

The prisms stack together with a thin film spacer.

<div style="text-align: center;"><img src="imgs/img_in_image_box_202_176_516_306.jpg" alt="Image" width="26%" /></div>


There is certainly no reflection inside the  $ n_{2} $ region.

Now Split Cube in half into two prism, the amount of reflection and transmission will depend on the spacing.

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_606_496_779.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_653_612_943_780.jpg" alt="Image" width="24%" /></div>


Given the incoming light, the  $ n_{i} $,  $ n_{i} $ of the media, we can determine the reflected light and transmitted light across the interface.

<div style="text-align: center;"><img src="imgs/img_in_image_box_181_375_1017_950.jpg" alt="Image" width="70%" /></div>


Orientation: Angles between them.

<div style="text-align: center;">Phase between S, P components of reflected / transmitted light →polarization of the reflected/ transmitted.</div>


## Chapter 4 Geometric Optics

(Zhao's Chap I, 4,5,6,7,9. ; Hecht's . 5.1-5.4 ; 6.1, 6.2)

(1) Why is it called geometric?

The problems can be solved geometrically, at most by analytical geometry (such as the matrix method of ray tracing).

(2) Why it can be solved geometrically?

Treat the light as  $ \lambda \rightarrow 0 $. This means there is no concern of wave characters of light, such as interference, diffraction, etc.

We shall treat light as “rays” traveling in straight lines (the wavelength of light is negligible compared to the dimension of the problem in concern). The “ray” is a line representing the energy flow of the light wave and in isotropic media, it is same as direction of wave vector k.

(3) Why Bother?

G.O. though lacks of scientific (from theoretical point of view) significance, it is still having probably the broadest applications in technology development in optics

(4) What can we do with G.O

—— Modify the incident wavefront

Example: Change the wave front and Image formation:

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_289_1000_460.jpg" alt="Image" width="67%" /></div>


In experiments in physics, there are numerous occasions that we need to detect the light emitting or scattered from an object, not even considering that our own eyes are a pair of complicated lens (or camera) system. The most common set up would be:

<div style="text-align: center;"><img src="imgs/img_in_image_box_187_810_1003_1096.jpg" alt="Image" width="68%" /></div>


molecules, cells,

Stars



eyes, photo multiplier,

CCD, camera film ...

(a) Intensity—— such as molecular spectroscopy

We need to measure or record

(b) Image

For purpose (a), we need to collect as much light as possible.

For purpose (b), we need a device to convert every point of the object into

every single point of the image, while keeping the proportion (one to one correspondence without distortion).

<div style="text-align: center;"><img src="imgs/img_in_image_box_267_292_952_471.jpg" alt="Image" width="57%" /></div>


In sections below, we are going to study what are these devices, why they work and what are their limitations.

## 4 -1 Jargons in geometric optic

——Focal points, concave, convex, real, virtual images, objects, object-Image conjugates

Take examples that we are already familiar with,

a) convex lens

 $$ 0\quad\text{or}\quad\downarrow $$ 

light passes through a convex lens will be more converged

<div style="text-align: center;"><img src="imgs/img_in_image_box_286_1158_1047_1416.jpg" alt="Image" width="63%" /></div>


Optical axis: The line passes the center of the lens and

perpendicular to it.

$f_{o}$ : a special point on the optical axis; lights from $f_{o}$ after optical elements will be parallel beams. Or $f_{o}$ has image at $\infty$ (infinity).

$f_{i}$: another special point on optical axis; beams parallel to the optical axis after pass optical element will focus to $f_{i}$. Or object at $\infty$ will have its image at $f_{i}$.

 $$ \mathbb{Z}\quad\text{or}\quad\mathbb{Z} $$ 

b) concave lens:

Light passes through a concave lens will be more diverged. The  $ f_{o} $ is a virtual object on the optical axis whose image is at infinity;  $ f_{i} $ is the virtual image whose corresponding object is at infinity.

<div style="text-align: center;"><img src="imgs/img_in_image_box_379_921_843_1246.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">C)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_381_143_794_580.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;">D)</div>


1) Real, Virtual Object:

In case (C), (D), object AB are real objects for $L_{1}$. Real means for the optical elements (such as $L_{1}$), the incoming lights from the object are diverging.

In case (C), if we insert a second lens into the system  $ (L_{2}) $, at the axial location as shown,  $ A'B' $ (the real image of AB through  $ L_{1} $) now becomes a virtual object for  $ L_{2} $, the incoming light to the  $ L_{2} $ (another saying is that  $ L_{2} $ sees the incoming light) are converging.

In case (D),  $ A'B' $ (the virtual image of AB through  $ L_{1} $) is a real object for  $ L_{2} $.

2) Real, Virtual Image

A'B' is a real image in case (c) formed by  $ L_{1} $, the lights that form the image are converging. The real image can be projected on a real screen.

A'B' in case (D) is a virtual image by  $ L_{1} $, the lights “forming” it are diverging.

If the objective points and image points have a 1 to 1 relation (i.e. each objective point corresponds to one and the only one image point), it means all the light from the object after passing through the optical element (lens here) will converge to its image point (for the real image case; or diverge to virtual image point). The corresponding objective and image points are called conjugate points.

In (C), (D):

 $$ A\xleftarrow{L_{1}}\rightarrow A^{\prime} $$ 

 $$ B\xleftarrow{L_{1}}\boldsymbol{B}^{\prime} $$ 

They are conjugate points by

## 4 -2 Fermat's Principle

→The OPL for all light rays between conjugate points are equal.

It is fairly easy to prove for real object and real image ease. The light rays connecting the object point O and image point I through the optical element have to be stationary. The OPL of these different rays cannot be

maximum or minimum, have to be a constant. For virtual object or image, their OPL have to be counted as negative (try proving this as an exercise, hint: set up using extra lens to make virtual image as object again and forming real image with second lens), and the refractive index n in OPL=nl, has to be taken corresponding to the objective or image side respectively.

So if any interface can satisfy the constant OPL between points Q and  $ Q' $, they will be a pair of Object – Image conjugate with respect to that interface. Such interface can be derived by requiring:

(Hecht's 5.2.1, Zhao's 4.4)

<div style="text-align: center;"><img src="imgs/img_in_image_box_223_832_568_978.jpg" alt="Image" width="28%" /></div>


$$\left.\frac{\overline{QM}}{\overline{QM}}+\overline{MQ^{\prime}}=const\right\rangle\text{contour of point M for real or virtual image(object)}$$

The contour of M, satisfying the above equation is generally an aspheric curve (or surface, such as elliptical, hyperbolic...). These aspheric optical elements are more difficult to manufacture in great precision than spherical ones.

Since spherical optical elements are widely used and easier to make, we are going to study in detail of such optical lenses or mirrors, to see

under what condition that the spherical ones can be treated as ideal.

Ideal optical Element:

(1) All light rays from one point source can be transformed into another point. 1↔1 relation between image and object, so to the lines and planes.

(2) The optical element can cover wide range of objective distance, not only for a specific pair of object —— image points.

(3) No distortion, i.e. keep the original shape of the object, a constant magnification value in image plane.

## 4 -3 Refraction at a Single Spherical Surface

(Fig 5.6 Hecht’s or Fig 5.1 Zhao’s)

<div style="text-align: center;"><img src="imgs/img_in_image_box_196_999_991_1345.jpg" alt="Image" width="66%" /></div>


We need to find relation between $S_{o}, S_{i}$. If it is independent of $\phi$ (or $h, i_{1}$, $i_{2}, \ldots$) then all rays coming from $Q$ can be converged into $Q', i.e. Q, Q'$

are conjugate. The position of the image is most generally in a functional form:  $ S_i = F(S_0, n_i, n_0, r, \phi, i_1, i_2, \ldots) $. Of course, not all the variables are independent, they are related by Snell's law, triangular relations etc.

Neglect the detail derivation (refer to Hecht's 5.2.2), we get:

 $$ \frac{S_{0}^{2}}{n_{0}^{2}(S_{0}+r)^{2}}-\frac{S_{i}^{2}}{n_{i}^{2}(S_{i}-r)^{2}}=-4r\sin^{2}\frac{\phi}{2}\left[\frac{1}{n_{0}^{2}(S_{0}+r)}+\frac{1}{n_{i}^{2}(S_{i}-r)}\right] $$ 

Generally,  $ S_0 $ and  $ S_i $ are dependent on  $ \phi $ (that is where the ray hit the surface), so rays from  $ S_0 $ of different angle generally interact the axis at different distance, except for a special pair  $ S_0 $,  $ S_i $ where  $ \left\{\begin{array}{l} S_0^2 \\ n_0^2(S_0 + r)^2 - \frac{S_i^2}{n_i^2(S_i - r)^2} = 0 \\ \frac{1}{n_0^2(S_0 + r)} + \frac{1}{n_i^2(S_i - r)} = 0 \end{array}\right. $

Such $S_{0}, S_{i}$ defines the location of Stigmatic Points for the spherical surface (these special pair can achieve so called broad beam image formation. i.e. all light from the object at O are converged to the image point I).

So (4-1) shows that the spherical surface is not an ideal optical element except for a special pair of points.

## 4 -4 Paraxial Approximation

Under paraxial condition for points on the axis, i.e.

 $$ h^{2}\ll S_{0}^{2},\quad S_{i}^{2},\quad r^{2}\quad or\quad\mu^{2},\mu^{\prime}^{2},\phi^{2}\ll1 $$ 

Then

 $$ \sin^{2}\frac{\phi}{2}\approx\left(\frac{\phi}{2}\right)^{2}\approx0\qquad\qquad\mathrm{in}(4-1) $$ 

 $$ \therefore\frac{S_{0}^{2}}{n_{0}^{2}(S_{0}+r)^{2}}-\frac{S_{i}^{2}}{\left(S_{i}-r\right)^{2}n_{i}^{2}}=0 $$ 

 $$ \frac{S_{0}}{n_{0}(S_{0}+r)}=\frac{S_{i}}{\left(S_{i}-r\right)n_{i}} $$ 

 $$ n_{_{0}}+\frac{n_{_{0}}r}{S_{_{0}}}=n_{_{i}}-\frac{n_{_{i}}r}{S_{_{i}}} $$ 

 $$ \therefore\frac{n_{i}}{S_{i}}+\frac{n_{0}}{S_{0}}=\frac{n_{i}-n_{0}}{r} $$ 

 $ f_{i} $

For image focal point,  $ f_i: S_0 \to \infty $,  $ S_i \to f_i $

 $$ \frac{n_{i}}{f_{i}}=\frac{n_{i}-n_{0}}{r} $$ 

 $$ f_{i}=\frac{n_{i}r}{n_{i}-n_{0}} $$ 

Similarly for object focal point:  $ S_{i} \to \infty $,  $ S_{0} \to f_{0} $

 $$ f_{0}=\frac{n_{0}r}{n_{i}-n_{0}} $$ 

(4-3) object-image relation can be rewritten in the more familiar formula

(Gauss's formula):

 $$ \frac{f_{0}}{S_{0}}+\frac{f_{i}}{S_{i}}=1 $$ 

Under paraxial condition, that each point on the axis  $ S_{0} $, will form an image at  $ S_{i} $ on the axis based on (4-6)

 $ ^{*} $Sign convention for spherical refraction and thin lenses (Light entering the lens from Left side)


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$ S_{0}, f_{0} $</td><td style='text-align: center; word-wrap: break-word;'>+ left of vertex A</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_{i}, f_{i} $</td><td style='text-align: center; word-wrap: break-word;'>+ right of A</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>R</td><td style='text-align: center; word-wrap: break-word;'>+ c is right of A</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ y_{0}, y_{i} $</td><td style='text-align: center; word-wrap: break-word;'>+ above the optical axis</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ x_{o} $</td><td style='text-align: center; word-wrap: break-word;'>+ left of  $ f_{0} $ (x is used in Newton formular)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ x_{i} $</td><td style='text-align: center; word-wrap: break-word;'>+ right of  $ f_{i} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \mu $</td><td style='text-align: center; word-wrap: break-word;'>+ optical axis to ray is counter clock wise.</td></tr></table>

Choose the convention and stick to it, then from the computation to determine the positions of the image relative to the optical elements. This is the basics of geometric optics.

Example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_230_151_557_273.jpg" alt="Image" width="27%" /></div>


 $$ f_{i}=\frac{n_{i}r}{n_{i}-n_{o}}\quad>0 $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_199_341_509_479.jpg" alt="Image" width="26%" /></div>


 $$ f_{i}=\frac{n_{i}r}{n_{i}-n_{o}}<0 $$ 

The calculation based on the above sign convention is straightforward in this simple case. What I want to demonstrate is that they agree with the geometric method (draw directly from Snell’s law). Also noticed that the converging or diverging of the convex and concave surface depend on relative value between  $ n_{i}, n_{0} $ if  $ n_{i} < n_{o} $, the above situations are reversed.

Example for a refracted surface:

<div style="text-align: center;"><img src="imgs/img_in_image_box_238_1018_905_1259.jpg" alt="Image" width="56%" /></div>


<div style="text-align: center;">Where is the image of o after inserting a glass slide with thickness  $ d_{o} $, or where is the new position the eye thinks the light originated?</div>


(1) Geometric solution

Both rays A and B are parallel with each other A//B

 $$ OO^{\prime}=PP^{\prime}=\frac{AB}{\tan i_{1}} $$ 

 $$ AB=AC-BC=d_{_{0}}\tan i_{_{i}}-d_{_{0}}\tan i_{_{2}} $$ 

If  $ i_{1} $ is very small (paraxial approximation)

 $$ AB\approx d_{0}(i_{1}-i_{2})=\frac{n^{\prime}-n}{n^{\prime}}d_{0}i_{1}\quad n i_{1}=n^{\prime}i_{2} $$ 

 $$ \therefore OO^{\prime}=\frac{n^{\prime}-n}{n^{\prime}}d_{0} $$ 

∴ O' moves to  $ \frac{n' - n}{n'}d_{0} $ closer to the eye.

(2) By image formation formula:

The two flat surfaces of the Slide are spherical surfaces with  $ R \to \infty $

For surface 1, object O from n (refraction index) toward side n'

through 1.

The distance between O and surface l is  $ S_{o} $

(>0 according to our convention)

 $$ \frac{n}{S_{_{o_{1}}}}+\frac{n^{\prime}}{S_{_{i_{1}}}}=0(\frac{n^{\prime}-n}{r\rightarrow\infty}) $$ 

 $$ \therefore S_{_{i_{1}}}=-\frac{n^{\prime}}{n}S_{_{o_{1}}} $$ 

 $ i_{1} $ is the image formed by O through surface 1.

 $ S_{i_1} < 0 $, means  $ i_1 $ is at the same side as  $ O $, i.e. it is a virtual image,

 $ \frac{n'}{n} S_{o_1} $ to the left of 1.

For surface 2,  $ i_{1} $ becomes a real object (The incident light towards surface 2 are diverging)

The distance between surface 2 and  $ i_{1} $ is  $ S_{o_{2}} = d_{o} - S_{i_{1}} = d_{o} + \frac{n'}{n} S_{o_{1}} $

(Notice this is n' the incident light to 2 is from n' side)

 $$ \frac{n^{\prime}}{S_{o_{2}}}+\frac{n}{S_{i_{2}}}=0 $$ 

 $$ S_{_{i_{2}}}=-\frac{n}{n^{\prime}}S_{_{o_{2}}}=-S_{_{o_{1}}}-\frac{n}{n^{\prime}}d_{_{0}} $$ 

i is also a virtual image (S i < 0 ), to the left of 2, with distance

 $$ S_{o_{1}}+\frac{n}{n^{\prime}}d_{0} $$ 

 $$ \therefore\Delta S=\left|S_{_{i_{2}}}\right|-\left(S_{_{o_{1}}}+d\right)=-\frac{n^{\prime}-n}{n}d $$ 

Summary on Image Formation by a Spherical Refracting Surface

Generally a spherical surface is not an ideal optical element for image formation. However, under Paraxial Approximation, it is close to ideal.

Relation between image-object conjugate is given by:

 $$ \frac{n_{_{i}}}{S_{_{i}}}+\frac{n_{_{o}}}{S_{_{o}}}=\frac{n_{_{i}}-n_{_{o}}}{r} $$ 

 $$ \mathrm{Or}\frac{f_{o}}{S_{o}}+\frac{f_{i}}{S_{i}}=1 $$ 

Where  $ f_{o}=\frac{n_{o}r}{n_{i}-n_{o}}\quad f_{i}=\frac{n_{i}r}{n_{i}-n_{o}} $

* Important Note:

a) The definition of +,- sign for  $ s_{o}, s_{i}, f_{i}, f_{o}, r $ (the sign convention)

b) Their correspondence to the real, virtual object (or Image, focal point);

c) And their location with respect to the spherical surface.

<div style="text-align: center;"><img src="imgs/img_in_image_box_237_783_508_972.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_194_983_556_1223.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_617_817_984_1253.jpg" alt="Image" width="30%" /></div>


The above conclusion is easily verified by Snell's law (on diverging or converging behavior of light) and the formula of  $ f_{o}, f_{i} $ given earlier.

The real object (image)  $ \leftrightarrow+(S_{o},S_{i}) $

Virtual object (image)  $ \leftrightarrow-(S_{o},S_{i}) $

Their location with respect to the surface is given sign convention and summarized in the notes above and also in table 5.1 Hecht's:


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="2">$  \dot{s}.1  $ Sign Convention for Spherical  $ \mathbf{s} $.acting Surfaces and Thin Lenses $ ^{*} $ (Light Entering from the Left)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  s_{o}, f_{o}  $</td><td style='text-align: center; word-wrap: break-word;'>+ left of  $  V  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  x_{o}  $</td><td style='text-align: center; word-wrap: break-word;'>+ left of  $  F_{o}  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  s_{i}, f_{i}  $</td><td style='text-align: center; word-wrap: break-word;'>+ right of  $  V  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  x_{i}  $</td><td style='text-align: center; word-wrap: break-word;'>+ right of  $  F_{i}  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  R  $</td><td style='text-align: center; word-wrap: break-word;'>+ if  $  C  $ is right of  $  V  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  y_{o}, y_{i}  $</td><td style='text-align: center; word-wrap: break-word;'>+ above optical axis</td></tr></table>

## 4 -5 Finite Imagery and Transverse Magnification

This is the question of image formation for points off the optical axis:

<div style="text-align: center;"><img src="imgs/img_in_image_box_208_916_823_1156.jpg" alt="Image" width="51%" /></div>


Due to the spherical symmetry,  $ P - P' $  $ S - S' $ are also object-Image conjugate.

If the $\phi$ is very small (paraxial condition), then Curve $PQS$ and its conjugate image $\widehat{P'Q'S'}$ will be close to a plane perpendicular ($\perp$) to the optical axis. Equivalently this requires:

 $$ y_{o}^{2},y_{i}^{2}<<S_{o}^{2},S_{i}^{2},r^{2} $$ 

The transverse magnification is:

<div style="text-align: center;"><img src="imgs/img_in_image_box_206_327_714_494.jpg" alt="Image" width="42%" /></div>


 $$ y_{o}=S_{o}\tan i\approx S_{o}i $$ 

 $$ y_{i}=-S_{i}\tan i^{\prime}\approx-S_{i}i^{\prime} $$ 

 $$ \therefore\frac{y_{i}}{y_{o}}=-\frac{S_{i}}{S_{o}}\frac{i^{\prime}}{i}=-\frac{S_{i}}{S_{o}}\frac{n_{o}}{n_{i}} $$ 

 $$ V\equiv\frac{y_{i}}{y_{o}}=-\frac{n_{o}S_{i}}{n_{i}S_{o}} $$ 

 $$ |\nu|>1\qquad\mathrm{m a g n i f i e d~I m a g e}\qquad|\nu|<1\qquad\mathrm{m i n i m i z e d~I m a g e} $$ 

 $$ \nu>0\quad\mathrm{E r e c t e d~I m a g e}\qquad\nu<0\quad\mathrm{I n v e r t e d~I m a g e} $$ 

The  $ S_o $,  $ S_i $ obeys relation of  $ \frac{f_o}{S_o} + \frac{f_i}{S_i} = 1 $ or  $ S_o $,  $ S_i $ can be determined geometrically.

Focal Plane of spherical Refracted Surface: It is simply a plane passing through the focal points and perpendicular to the optical axis under paraxial condition. The light ray out such plane is represented in the figures below for concave (diverging) and convex (converging) surfaces.

Convex  $ (N_{1}>N_{0}) $

<div style="text-align: center;"><img src="imgs/img_in_image_box_186_202_766_1465.jpg" alt="Image" width="48%" /></div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>c</td><td style='text-align: center; word-wrap: break-word;'>f_{i}</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f_{i}</td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

Based on the above argument, it is easy to see that two special

objective, image planes are objective (image) focal plane. The points on the objective focal plane will form image at  $ \infty $ (or the light form this point source will be collimated after the interface, with its direction determined by the line connecting the point and the center of sphere).

The optical center, defined as the rays passing it will not change direction at the interface. For spherical surface, it is clearly the center of sphere.

## 4 -6 Multiple Surfaces and Lagrange - Helmholtz Relation

(Zhao’s Book, 5.4 p53)

We have worked an example of image formation by two surfaces. For the case of multiple surfaces separated with some distance, the general way is:

① treat each surface from left to right in turn (Assume light is from the left);

② use sign convention as we defined earlier;

③clarify which is object and with is image, usually the image of the previous surface will behave as object for the next surface;

④ identify the refraction index n for object and image.

Fig5-4. with the sign convention, easy to see:

 $$ S_{o_{2}}=d_{12}-S_{i} $$ 

 $$ S_{o_{3}}=d_{23}-S_{i_{2}} $$ 

Lagrange-Helmholtz relation:

Though there is no simple relation between the position of object and image for multiple surfaces. The energy conservation generates a simple relation between angular and linear size of the conjugate object-image.

①. First, need to define signs for angle spanned by the object and image.

<div style="text-align: center;"><img src="imgs/img_in_image_box_314_818_456_869.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_317_884_454_936.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_646_825_786_878.jpg" alt="Image" width="11%" /></div>


 $$ \frac{u_{1}}{u_{2}} $$ 

 $$ M>0 $$ 

 $$ u^{\prime}<0 $$ 

optical axis  $ \rightarrow $ ray

counter clockwise

Optical axis → ray

clockwise

Then it is easy to prove L-H relation. At small  $ \mu_{o}, \mu_{i} $

 $$ \underline{\mu_{o}}=-\frac{S_{i}}{\dot{\underline{\mu}}}=\underline{y_{i} n_{i}} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_479_1254_668_1343.jpg" alt="Image" width="15%" /></div>


 $$ \mu_{_{i}}\qquad S_{_{o}}\quad y_{_{o}}n_{_{o}} $$ 

 $$ \because\frac{y_{i}}{y_{o}}=-\frac{S_{i}n_{o}}{S_{o}n_{i}} $$ 

 $$ n_{o}y_{o}\mu_{o}=n_{i}y_{i}\mu_{i}=n_{i_{2}}y_{i_{2}}\mu_{i_{2}}\cdots\cdots $$ 

We can use L-H relation to easily determine the angular  $ \left(\mu\right) $ and linear size  $ (y) $ between conjugates.

<div style="text-align: center;"><img src="imgs/img_in_image_box_223_377_762_524.jpg" alt="Image" width="45%" /></div>


No matter how complex it is, can use L-H relation to get φi or yi.

## 4 -7 Thin Lens

<div style="text-align: center;"><img src="imgs/img_in_image_box_205_853_989_1159.jpg" alt="Image" width="65%" /></div>


This is equivalent to an object – Image formation through 2 interfaces.

 $$ \frac{f_{o_{1}}}{S_{o_{1}}}+\frac{f_{i_{1}}}{S_{i_{1}}}=1\qquad\quad\frac{f_{o_{2}}}{S_{o_{2}}}+\frac{f_{i_{2}}}{S_{i_{2}}}=1 $$ 

 $$ S_{o_{2}}=d-S_{i_{1}} $$ 

The image through the first surface will act as object to the second

surface and its objective distance is provided by (4-10). This derivation and the previous example on the image formation by the glass slide follows a simple logic and important procedure of working the problems of image formation through multiple optical elements (here optical elements are refractive surfaces; later can be lens, mirrors etc.). The procedure is just working the problem of image formation one element at a time. The image of the first element will act as object to the second and it proceeds like this. Knowing the arrangement of the elements, the (4-10) provides means to calculate objective distance.

Now back to the thin lens case, we need a relation between  $  S_o(=S_{o_1})  $ and  $  S_i(=S_{i_2})  $

 $$ \begin{aligned}&S_{i_{1}}=-\frac{f_{i_{1}}S_{o_{1}}}{f_{o_{1}}-S_{o_{1}}}\quad&S_{i_{2}}=-\frac{f_{i_{2}}S_{o_{2}}}{f_{o_{2}}-S_{o_{2}}}\\ &\\ &S_{o_{2}}=d-S_{i_{1}}=d+\frac{f_{i_{1}}S_{o_{1}}}{f_{o_{1}}-S_{o_{1}}}\\ &\\ &\therefore S_{i_{2}}=\frac{-f_{i_{2}}}{f_{o_{2}}-S_{o_{2}}}(d+\frac{f_{i_{1}}S_{o_{1}}}{f_{o_{1}}-S_{o_{1}}})\\ \end{aligned} $$ 

It is hard to find a simple relation between $S_{i}$, and $S_{o_{1}}$, as $d \neq 0$.

As for the thin lens whose  $ d \rightarrow 0 $ :

 $$ S_{i_{2}}=\frac{-f_{i_{2}}f_{i_{1}}S_{o_{1}}}{(f_{o_{2}}-S_{o_{2}})(f_{o_{1}}-S_{o_{1}})} $$ 

 $$ \frac{f_{i_{2}}f_{i_{1}}}{S_{i_{2}}}+\frac{f_{o_{2}}f_{o_{1}}}{S_{o_{1}}}=f_{o_{2}}+f_{i_{1}} $$ 

Focal point:

 $$ \begin{aligned}&S_{o}\rightarrow\infty,S_{i}\rightarrow f_{i}\rightarrow f_{i}=\frac{f_{i_{1}}f_{i_{2}}}{f_{o_{2}}+f_{i_{1}}}\\ &\\ &S_{o}\rightarrow f_{o},S_{i}\rightarrow\infty_{i}\rightarrow f_{o}=\frac{f_{o_{1}}f_{o_{2}}}{f_{o_{2}}+f_{i_{1}}}\\ &\\ &\frac{f_{o}}{S_{o}}+\frac{f_{i}}{S_{i}}=1\\ \end{aligned} $$ 

This is similar to that of a single spherical Interface, but with different expression for f.

 $$ f_{o}=\frac{n_{o}}{\frac{n_{L}-n_{o}}{r_{1}}+\frac{n_{i}-n_{L}}{r_{2}}} $$ 

 $$ \frac{f_{o}}{f_{i}}=\frac{n_{o}}{n_{i}} $$ 

when  $ n_{0}=n_{i}\approx1 $ :

 $$ f_{o}=f_{i}=\frac{1}{(n_{L}-1)(\frac{1}{r_{1}}-\frac{1}{r_{2}})} $$ 

In a non-air media (say immerse the lens into water), the formula becomes:

 $$ f_{o}=f_{i}=\frac{n}{(n_{L}-n)(\frac{1}{r_{1}}-\frac{1}{r_{2}})} $$ 

Whether a lens (with fixed  $ r_{1}, r_{2}, n_{L} $) is converging ( $ f > 0 $) or diverging ( $ f < 0 $) depends on the value of  $ n_{L} $ and  $ n_{media} $.

Summary of formula for the thin lens:

Gaussian Formula:  $ \frac{f_{o}}{S_{o}}+\frac{f_{i}}{S_{i}}=1 $

Newton Formula:

 $$ x_{o}x_{i}=f_{o}f_{i} $$ 

(Its proof can be done easily with geometric method)

 $$ S_{o}=x_{o}+f_{o} $$ 

 $$ S_{i}=x_{i}+f_{i} $$ 

Transverse Magnification:

 $$ \nu=-\frac{n_{o}S_{i}}{n_{i}S_{o}}=-\frac{f_{o}}{x_{o}}=-\frac{x_{i}}{f_{i}} $$ 

<div style="text-align: center;">Meanings associated with the signs of thin lens and spherical surfaces.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="2">Quantity</td><td colspan="2">Sign</td></tr><tr><td style='text-align: center; word-wrap: break-word;'></td><td colspan="2">+</td><td style='text-align: center; word-wrap: break-word;'>-</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_{o} $</td><td colspan="2">Real object</td><td style='text-align: center; word-wrap: break-word;'>Virtual</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_{i} $</td><td colspan="2">Real Image</td><td style='text-align: center; word-wrap: break-word;'>Virtual</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f</td><td colspan="2">Converging lens</td><td style='text-align: center; word-wrap: break-word;'>Diverging</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ y_{o} $</td><td colspan="2">Erect object</td><td style='text-align: center; word-wrap: break-word;'>Inverted</td></tr></table>


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$ y_{i} $</td><td style='text-align: center; word-wrap: break-word;'>Erect Image</td><td style='text-align: center; word-wrap: break-word;'>Inverted</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ M_{T} $</td><td style='text-align: center; word-wrap: break-word;'>Erect Image</td><td style='text-align: center; word-wrap: break-word;'>inverted</td></tr></table>

Image of real objects formed by thin lens

<div style="text-align: center;"> $ (n_i = n_o) $conve $ \mathbf{x}(f_i, f_o > 0) $</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Object</td><td style='text-align: center; word-wrap: break-word;'>Image</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Location</td><td style='text-align: center; word-wrap: break-word;'>Type</td><td style='text-align: center; word-wrap: break-word;'>Location</td><td style='text-align: center; word-wrap: break-word;'>Orientation</td><td style='text-align: center; word-wrap: break-word;'>T.M</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \infty &gt; S_o &gt; 2f $</td><td style='text-align: center; word-wrap: break-word;'>Real</td><td style='text-align: center; word-wrap: break-word;'>$ f &lt; S_i &lt; 2f $</td><td style='text-align: center; word-wrap: break-word;'>Inverted</td><td style='text-align: center; word-wrap: break-word;'>Minimized</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_o = 2f $</td><td style='text-align: center; word-wrap: break-word;'>Real</td><td style='text-align: center; word-wrap: break-word;'>2f</td><td style='text-align: center; word-wrap: break-word;'>Inverted</td><td style='text-align: center; word-wrap: break-word;'>Equal</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ 2f &gt; S_o &gt; f $</td><td style='text-align: center; word-wrap: break-word;'>Real</td><td style='text-align: center; word-wrap: break-word;'>$ \infty &gt; S_i &gt; 2f $</td><td style='text-align: center; word-wrap: break-word;'>Inverted</td><td style='text-align: center; word-wrap: break-word;'>Magnified</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_o = f $</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>$ \infty $</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_o &lt; f $</td><td style='text-align: center; word-wrap: break-word;'>Virtual</td><td style='text-align: center; word-wrap: break-word;'>$ -S_i &gt; S_o $</td><td style='text-align: center; word-wrap: break-word;'>Erect</td><td style='text-align: center; word-wrap: break-word;'>Magnified</td></tr></table>

 $$ \frac{1}{s_{0}}+\frac{1}{s_{i}}=\frac{1}{f} $$ 

 $$ V\equiv\frac{y_{i}}{y_{0}}=-\frac{s_{i}}{s_{0}} $$ 

Concave  $ (f_{i}, f_{o} < 0) $


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Object</td><td colspan="4">Image</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Location</td><td style='text-align: center; word-wrap: break-word;'>Type</td><td style='text-align: center; word-wrap: break-word;'>Location</td><td style='text-align: center; word-wrap: break-word;'>Orientation</td><td style='text-align: center; word-wrap: break-word;'>T.M</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Any</td><td style='text-align: center; word-wrap: break-word;'>Virtual</td><td style='text-align: center; word-wrap: break-word;'>$ \left|S_{i}\right|&lt;\left|f\right| $</td><td style='text-align: center; word-wrap: break-word;'>Erect</td><td style='text-align: center; word-wrap: break-word;'>Minimized</td></tr></table>


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>where</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

## 4 -8 Thin lens combination

For a combination of thin lenses of two or more, it is same as the way we have worked for the multiple spherical surfaces cases, where we can work one lens at a time.

For the special use, where the separation between lenses d = 0, it is easy to prove that:

 $$ \begin{aligned}&\frac{1}{S_{o}}+\frac{1}{S_{i}}=\frac{1}{f_{1}}+\frac{1}{f_{2}}+...\\ &\\ &\left(n_{i}=n_{o}\right)\\ &\\ &\therefore\frac{1}{f}=\frac{1}{f_{1}}+\frac{1}{f_{2}}+...\\ &\\ &D\equiv\frac{1}{f}\\ &\\ &D=D_{1}+D_{2}+...\\ \end{aligned} $$ 

D: dioptric power, in unit of Diopter  $ \left(\frac{1}{m}\right) $

* The close contact combination of thin lenses is equivalent to a single thin lens, with effective focal length given by (4-17)

For combination of thin lenses with nonzero separation will be equivalent

to a single thick lens.

# 4-9 Thick Lenses and Lens System

(Hecht's 6.1)

<div style="text-align: center;"><img src="imgs/img_in_image_box_208_525_654_784.jpg" alt="Image" width="37%" /></div>


Basic Parameters for a lens:

 $$ n_{L},\quad n_{L},\quad d_{l},\quad R_{2},\quad R_{1}, $$ 

(Radius)

(Thickness)

(index of Refraction)



## Cardinal Points for a lens:

(a) Thin lens: optical center,  $ f_{o}, f_{i} $

(b) Thick lens:

Principal points:  $ H_{1}, H_{2} $

Focal points:  $ f_{o}, f_{i} $

Nodal points:  $ N_{1}, N_{2} $

We shall see that knowing the basic parameters will allow us to determine the location of the cardinal points; then we can calculate the relation between object —— Image conjugates. This is the basic problem in thick lens image formation.

## (1) Definition of the Cardinal points

Focal points: same as spherical interfaces or thin lens  $ (S_o \to \infty, S_i \to f_i $,

 $ S_i \to \infty, S_o \to f_o $)

Principal plane and points (H1, H2): (Fig 6.1, 6.2, Hecht's)

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_729_554_931.jpg" alt="Image" width="27%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_602_761_1035_960.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;">The principal plane (the dotted curves in the figure, under paraxial condition, it is approximately a plane) is defined by collection of intersection points of rays (extended shown in dotted lines) from the focal point and its output. The principal points are the intersection of such planes with the optical axis (defined by the vertex of the two surfaces). The effective focal length in the thick lens case will be measured between the focal points and principal points (see below).</div>


## Nodal points

If  $ n_{o}=n_{i} $, the nodal points overlap with primary points

(2) Cardinal points in terms of basic parameters  $ (n_{i}, n_{o}, n_{L}, R, d) $

 $$  If n_{_{o}}=n_{_{i}}\approx1,f_{_{o}}=f_{_{i}}=f $$ 

(a)

 $$ \frac{1}{f}=\left(n_{_{L}}-1\right)\left[\frac{1}{R_{_{1}}}-\frac{1}{R_{_{2}}}+\frac{(n_{_{L}}-1)d_{_{L}}}{n_{_{L}}R_{_{1}}R_{_{2}}}\right] $$ 

 $ f_{o} $ : is measured from  $ H_{1} $ It is + to the left of  $ H_{1} $

f: is measured from H2. It is + to the Right of H2.

(b)

 $$ \overline{V_{_{1}}H_{_{1}}}=h_{_{1}}=\frac{-f(n_{_{L}}-1)d_{_{L}}}{R_{_{2}}n_{_{L}}} $$ 

 $$ \overline{V_{_{2}}H_{_{2}}}=h_{_{2}}=\frac{-f(n_{_{L}}-1)d_{_{L}}}{R_{_{1}}n_{_{L}}} $$ 

 $ h_{1}, h_{2}: +\mathrm{if} \quad H_{j} \mathrm{is} \mathrm{to} \mathrm{the} \mathrm{right} \mathrm{of} \quad V_{j} \quad (\mathrm{note} \mathrm{this} \mathrm{definition} \mathrm{is} \mathrm{different}  $

in Zhao's book)

For the thin lens,  $ (d_{L} \rightarrow 0) $ (4-19) is reduced to lens-Maker formula,  $ H_{1} $,  $ H_{2} $ collapse into one point and overlap with the optical center. These formula will be proved later using matrix method.

(3) Object – Image Relation

 $$ \frac{1}{S_{_{o}}}+\frac{1}{S_{_{i}}}=\frac{1}{f}\quad for\quad n_{_{o}}=n_{_{i}} $$ 

 $$ \mathrm{Or}\quad x_{0}x_{i}=f^{2} $$ 

 $$ M_{_{T}}=\frac{y_{_{i}}}{y_{_{o}}}=\frac{-x_{_{i}}}{f}=\frac{-f}{x_{_{o}}}=\frac{-S_{_{i}}}{S_{_{o}}} $$ 

Where  $ S_{0} $ is measured from  $ H_{1} $, + if to the left of  $ H_{1} $

S_{i} is measured from H_{2}, + if to the right of H_{2}.

These formula can most easily be proved by geometric method.

The physical meaning of the primary planes:

 $$  From(4-21):f=\frac{S_{o}S_{i}}{S_{i}+S_{o}} $$ 

If  $ S_{0} $ is on the  $ H_{1} $ plane, i.e.  $ S_{0}=0 $, then  $ S_{i}=0 $ too for non-zero focal length.

This means the image point is on the back principal plane H2.

∴ H1 and H2 are conjugate planes with magnification M:

 $$ M_{_{T}}=-\frac{x_{_{i}}}{f}=\frac{-f}{x_{_{o}}}=1\quad where\quad\begin{aligned}x_{_{o}}&=-f\\ x_{_{i}}&=-f\end{aligned} $$ 

(4) Combination of lenses

<div style="text-align: center;"><img src="imgs/img_in_image_box_179_182_989_466.jpg" alt="Image" width="68%" /></div>


Basic problem: Knowing the cardinal points of individual lens and their configurations (the order and the separation etc.), calculate the equivalent cardinal points of the whole system $f,H_{1},H_{2}$ (or $\overline{H_{11}H_{1}}$, $\overline{H_{22}H_{2}}$):

 $$ M_{_{T}}=(\frac{-S_{_{i_{1}}}}{S_{_{o_{1}}}})(\frac{-S_{_{i_{2}}}}{S_{_{o_{2}}}})=-\frac{S_{_{i}}}{S_{_{o}}} $$ 

 $$ F o r S_{o_{1}},S_{i_{1}},S_{i_{2}},S_{o_{2}}:\frac{1}{S_{o_{n}}}+\frac{1}{S_{i_{n}}}=\frac{1}{f_{n}} $$ 

 $$ S_{o_{2}}=d_{12}-S_{i} $$ 

 $$ As\quad S_{o_{1}}\rightarrow\infty,S_{o}\rightarrow S_{o_{1}};S_{i_{1}}\rightarrow f_{1},S_{i}\rightarrow S_{i_{2}}\rightarrow f $$ 

 $$ S_{o_{2}}=d_{12}-S_{i_{1}}=d_{12}-f_{1} $$ 

 $$ \begin{aligned}&\therefore-f=\frac{f_{1}S_{i_{2}}}{S_{o_{2}}}=\frac{f_{1}}{S_{o_{2}}}(\frac{S_{o_{2}}f_{2}}{S_{o_{2}}-f_{2}})\\ &\\&=\frac{f_{1}f_{2}}{S_{o_{2}}-f_{2}}=\frac{f_{1}f_{2}}{d_{12}-f_{1}-f_{2}}\\ \end{aligned} $$ 

 $$ \overline{H_{11}H_{1}}=\frac{fd}{f_{2}}\quad\overline{H_{22}H_{2}}=\frac{-fd}{f_{1}} $$ 

The sign for  $ \overline{H_{11}H_{1}} $,  $ \overline{H_{22}H_{2}} $ are: + if to the right of  $ H_{11} $,  $ H_{22} $ respectively.

Noticed that the definition for sign of $H_{1}$ is different from Zhao's Book, that is why there is a sign change for $\overline{H_{11}H_{1}}$ between the two books.

The object – Image Relation for the combined lens system is equivalent to the single lens system whose cardinal points are given by (4-23), (4-24)

However in real computation, the strategy is still working one lens at a time, applying the image of the first lens as object to the second lens and so on.

Example: (Zhao's Book P80)

<div style="text-align: center;"><img src="imgs/img_in_image_box_247_987_860_1194.jpg" alt="Image" width="51%" /></div>


 $$ f=\frac{1}{f_{1}}+\frac{1}{f_{2}}-\frac{d}{f_{1}f_{2}}=\frac{3}{2}a $$ 

 $$ to the right of O_{1} $$ 

 $$ \overline{H_{22}H_{2}}=\overline{O_{2}H_{2}}=\frac{-fd}{f_{1}}=-a\qquad\text{to the left of}\ O_{2} $$ 

## 4 -10 Graphical Method of Image Formation

By using the definition of focal points, optical center, or other cardinal points, we can determine the light rays passing through these cardinal points, and thus the image formed after the optical elements. The graphical method is just geometric drawings by a pair of special rays (the rays passing the cardinal points) out of an objective point and finds its intersection after the lens to get the image point.

(a) Spherical Surface

<div style="text-align: center;"><img src="imgs/img_in_image_box_184_803_990_1140.jpg" alt="Image" width="67%" /></div>


For the on-axis point B

<div style="text-align: center;"><img src="imgs/img_in_image_box_203_162_993_468.jpg" alt="Image" width="66%" /></div>


By using the fact that A parallel beam (but not collinear with optical axis) will be focused to point on the focal plane.

You should be able to work for the concave cases.

b) Thin lens

<div style="text-align: center;"><img src="imgs/img_in_image_box_239_794_672_1110.jpg" alt="Image" width="36%" /></div>


For the on axis points, similar to what been discussed for the spherical surface

<div style="text-align: center;"><img src="imgs/img_in_image_box_221_178_748_399.jpg" alt="Image" width="44%" /></div>


<div style="text-align: center;">You need to work for the negative lens (concave) for yourself.</div>


c) Thick lens

<div style="text-align: center;"><img src="imgs/img_in_image_box_197_612_813_864.jpg" alt="Image" width="51%" /></div>


Here we used fact that the $H_{1}, H_{2}$ are a pair of object – Image conjugate plane, with transverse Magnification $\nu=1$. (See proof on pg.124 of the note)

It is also easy to see that if  $ f_o = f_i $ (Means  $ n_i = n_o $ for the thick lens) The Nodal points are simply the intersections of optical axis with the primary plane, the beam 3, 3' are parallel each other. If  $ n_i \neq n_o $ (or  $ f_o \neq f_i $), the Nodal points will not be on the primary planes: (see figure below)

<div style="text-align: center;"><img src="imgs/img_in_image_box_192_192_793_469.jpg" alt="Image" width="50%" /></div>


 $$ \overline{N_{1}N_{2}}=\overline{H_{1}H_{2}}=d $$ 

## 4 -11 Analytical Ray Tracing and Matrix Method

As we have demonstrated earlier, two spherical surfaces  $ \rightarrow $ lens (Thin or Thick). Multiple lenses combination is equivalent to a single thick lens. As the number of refraction surfaces (or optical elements) increases, the analysis either by graphical method or algebra to get the equivalent lens, or work surfaces (or element) one by one becomes complicated and tedious.

Here we discuss a new approach to the problem, still under paraxial approximation for simplicity.

(a) Introduction of Matrix

 $$ \left\{\begin{aligned}x_{1}&=a_{11}y_{1}+a_{12}y_{2}\\ x_{2}&=a_{21}y_{1}+a_{22}y_{2}\end{aligned}\right. $$ 

 $$ \begin{aligned}&\begin{bmatrix}x_{1}\\ x_{2}\end{bmatrix}=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}y_{1}\\ y_{2}\end{bmatrix}\\ &\xrightarrow{vector}2*2 matrix\\ \end{aligned} $$ 

Column vector

(or 1X2 matrix)

(Transform Matrix)

 $$ \begin{aligned}If\begin{cases}y_{1}=b_{11}Z_{1}+b_{12}Z_{2}\\y_{2}=b_{21}Z_{1}+b_{22}Z_{2}\end{cases}\quad or\quad\begin{bmatrix}y_{1}\\y_{2}\end{bmatrix}=\begin{bmatrix}b_{11}&b_{12}\\b_{21}&b_{22}\end{bmatrix}\begin{bmatrix}Z_{1}\\Z_{2}\end{bmatrix}\end{aligned} $$ 

Then:

 $$ \begin{bmatrix}x_{1}\\ x_{2}\end{bmatrix}=\hat{A}\hat{B}\begin{bmatrix}Z_{1}\\ Z_{2}\end{bmatrix}=\hat{C}\begin{bmatrix}Z_{1}\\ Z_{2}\end{bmatrix} $$ 

(AB: Matrices product)

Where

 $$ C\equiv\begin{bmatrix}C_{11}&C_{12}\\ C_{21}&C_{22}\end{bmatrix}\quad C_{ij}=\sum_{k}a_{ik}b_{kj} $$ 

 $$ \left(C_{11}=a_{11}b_{11}+a_{12}b_{21};C_{12}\ldots\ldots\right) $$ 

Noticed that generally  $ AB \neq BA $ (matrix product is not commutative)

(b) Ray Tracing

Purpose: Finding the trajectory of light rays propagating through space.

We already know the basics of light propagation:

1) It travels rectilinearly in the same homogeneous isotropic media.

2) It changes direction upon interface between two media.

<div style="text-align: center;"><img src="imgs/img_in_image_box_198_172_830_387.jpg" alt="Image" width="53%" /></div>


For rays in the same plane as the optical axis, thus the problem is basically in 2-dimensional space, the location of each point on the ray (thus the trajectory) can be determined by specifying two independent variables, such as (x,y) Cartesian coordinate. Then the general form of propagation of light would be:

 $$ \begin{bmatrix}x^{\prime}\\ y^{\prime}\end{bmatrix}=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}x_{0}\\ y_{0}\end{bmatrix} $$ 

With the matrix known, we can determine the transformation of the original light ray  $ \begin{bmatrix} x_0 \\ y_0 \end{bmatrix} $, and we shall see that the rectilinear propagation of light, and refraction at interfaces can call be represented in matrix form.

There are obviously other ways to specify the variables (Fig.6.7 Hecht's). The variables for a point on a ray are specified by variables:

y: distance from optical axis; and

 $ \alpha $ : the angle between ray and optical axis.

<div style="text-align: center;"><img src="imgs/img_in_image_box_194_165_481_291.jpg" alt="Image" width="24%" /></div>


y: + if above O.A

 $ \alpha:+ $ if O.A to ray is counter-clockwise (or ray has positive slope)

Under Paraxial approx., using Snell’s Law: (refer to Fig 6.7)

<div style="text-align: center;"><img src="imgs/img_in_image_box_229_625_991_973.jpg" alt="Image" width="64%" /></div>


We first investigate the transform brought by the spherical surface refraction. (The point on the surface at the incident beam side is  $ \begin{bmatrix} \alpha_{i_1} \\ y_{i_1} \end{bmatrix} $, its counterpart on the transmitted side would be  $ \begin{bmatrix} \alpha_{i_1} \\ y_{i_1} \end{bmatrix} $. It is the relation between  $ \begin{bmatrix} \alpha_{i_1} \\ y_{i_1} \end{bmatrix} \leftrightarrow \begin{bmatrix} \alpha_{i_1} \\ y_{i_1} \end{bmatrix} $ that we want. The subscript meaning:  $ i_1 $ incident at surface 1;  $ t_1 $ transmitted at surface 1...)

 $$ n_{i_{1}}\theta_{i_{1}}=n_{t_{1}}\theta_{t_{1}} $$ 

 $$ n_{i_{1}}(\alpha_{i_{1}}+\alpha_{1})=n_{t_{1}}(\alpha_{t_{1}}+\alpha_{1}) $$ 

 $$ \begin{aligned}&\alpha_{_{1}}\approx\frac{y_{_{1}}}{R}\\ &\\ &\therefore n_{_{t_{i}}}\alpha_{_{t_{i}}}=n_{_{i}}\alpha_{_{i_{i}}}-(\frac{n_{_{t_{i}}}-n_{_{i_{i}}}}{R_{_{1}}})y_{_{1}}=n_{_{i_{i}}}\alpha_{_{i_{i}}}-D_{_{1}}y_{_{1}};D_{_{1}}\equiv\frac{n_{_{t_{i}}}-n_{_{i_{i}}}}{R_{_{1}}}\\ &\\ &Or for refraction\begin{cases}n_{_{t_{i}}}\alpha_{_{t_{i}}}=n_{_{i_{i}}}\alpha_{_{i_{i}}}-D_{_{1}}y_{_{1}}\\ \quad y_{_{t_{i}}}=y_{_{i_{i}}}}\end{cases}(4-27)\\ \end{aligned} $$ 

Similarly for the propagation in the same media, we have:

Transfer $ \left\{\begin{array}{l}\alpha_{i_{2}}=\alpha_{t_{1}}\\y_{i_{2}}=y_{t_{1}}+d_{21}\alpha_{t_{1}}\end{array}\right. $  $ d_{21} $ is the thickness of lens

① Definition of Refraction Matrix

 $$ \begin{bmatrix}n_{t_{1}}\alpha_{t_{1}}\\ y_{t_{1}}\end{bmatrix}=\begin{bmatrix}1&-D_{1}\\ 0&1\end{bmatrix}\begin{bmatrix}n_{i_{1}}\alpha_{i_{1}}\\ y_{i_{1}}\end{bmatrix} $$ 

 $ R_{1} $ refraction matrix:  $ \begin{bmatrix} 1 & -D_{1} \\ 0 & 1 \end{bmatrix} $

② Transfer matrix

 $$ \begin{bmatrix}{{{n_{i_{2}}\alpha_{i_{2}}}}} \\{{{y_{i_{2}}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{\frac{d_{21}}{n_{t_{1}}}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{n_{t_{1}}\alpha_{t_{1}}}}} \\{{{y_{t_{1}}}}}\end{bmatrix} $$ 

 $ \Gamma_{21} $ Transfer Matrix:  $ \begin{bmatrix} 1 & 0 \\ \frac{d_{21}}{n_{t_1}} & 1 \end{bmatrix} $

③ For a lens system, the initial ray  $ \tau_{i} $ will be refracted by the front

surface, propagate inside the lens (transfer from surface 1 to surface 2), then refracted again by the back surface. The whole process (the output ray) can be represented by:

 $$ \tau_{_{t_{2}}}=R_{2}\Gamma_{_{21}}R_{_{1}}\tau_{_{i}} $$ 

The process is reading backward on the right hand side above. Then matrix representing the lens would be.

 $$ A_{21}=R_{2}\Gamma_{21}R_{1} $$ 

Put (4-28), (4-29) into it:

 $$ \begin{aligned}&A_{21}=\begin{bmatrix}{{{a_{11}}}}&{{{a_{12}}}} \\{{{a_{21}}}}&{{{a_{22}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{-D_{2}}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{\frac{d_{21}}{n_{t_{1}}}}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{-D_{1}}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\\ &=\begin{bmatrix}{{{1-\frac{D_{2}d_{21}}{n_{t_{1}}}}}}&{{{-D_{1}-D_{2}+\frac{D_{2}D_{1}d_{21}}{n_{t_{1}}}}}} \\{{{\frac{d_{21}}{n_{t_{1}}}}}}&{{{1-\frac{D_{1}d_{21}}{n_{t_{1}}}}}}\end{bmatrix}&(4-31\\ \end{aligned} $$ 

The matrix $A_{21}$ for a lens is fixed(and so will be the light rays passing through it) once we know all the basic parameters $(R_{1}, R_{2}, d_{21}, n_{i}, n_{0}, n_{i})$ and from the matrix elements, we should be able to derive the location of the cardinal points.

Here I give a proof of (4-20), (4-21) earlier in this note, give out focal point; and primary plane's position, using the figure below. The initial ray is a light parallel with the optical axis and it will pass the focal point on image side. Using the definition of focal point and principal point, we can

have their formula.

<div style="text-align: center;"><img src="imgs/img_in_image_box_216_254_795_565.jpg" alt="Image" width="48%" /></div>


The initial input ray is just  $ \begin{bmatrix} 0 \\ y_{i_1} \end{bmatrix} $

 $$ \begin{aligned}&\begin{bmatrix}n_{t_{2}}\alpha_{t_{2}}\\ y_{t_{2}}\end{bmatrix}=A\begin{bmatrix}0\\ y_{i_{1}}\end{bmatrix}=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}0\\ y_{i_{1}}\end{bmatrix}\\ &\\ &\Rightarrow n_{t_{2}}\alpha_{t_{2}}=a_{12}y_{i_{1}}.\\ \end{aligned} $$ 

 $$ \begin{aligned}&y_{t_{2}}=a_{22}y_{i_{1}}.\\ &\\ &\overline{V_{2}H_{2}}=\frac{\Delta y}{\alpha_{t_{2}}}=\frac{y_{i_{1}}-y_{t_{2}}}{\alpha_{t_{2}}}=\frac{(1-a_{22})}{\frac{a_{12}}{n_{t_{2}}}}=\frac{n_{t_{2}}(a_{22}-1)}{-a_{12}}\\ &\\ &\overline{V_{2}f_{i}}=\frac{-y_{t_{2}}}{\alpha_{t_{2}}}=\frac{-n_{t_{2}}a_{22}}{a_{12}}\\ &\\ &f_{i}\equiv\overline{H_{2}f_{i}}=\frac{-n_{t_{2}}a_{22}}{a_{12}}+\frac{n_{t_{2}}(a_{22}-1)}{a_{12}}=\frac{-n_{t_{2}}}{a_{12}}\\ &\\ &Or\quad a_{12}=\frac{-n_{t_{2}}}{f}\quad(4-33)\\ \end{aligned} $$ 

A lot of times, the other side of the lens is just air and thus  $ n_{t}, \approx 1 $, and

4-33 will become  $ a_{12} = -\frac{1}{f} $.

Similarly  $ \overline{V_{1}H_{1}}=\frac{n_{i_{1}}(1-a_{11})}{-a_{12}} $

If plug in the expression for  $ a_{11}, a_{12}, a_{22}, a_{21} $, then the relations (4-32)-(4.34) will be exactly as the equation of the locations for focal points and primary planes of thick lens given earlier without proof (4-20), (4-21).

### ④. Object —— Image conjugate points

 $ \tau_{obj} $ is the origin of a ray from a point of object

 $ \tau_{image} $ is the destination point of the conjugate ray on the image?

 $$ \tau_{image}=\Gamma_{I2}A_{21}\Gamma_{10}\tau_{obj} $$ 

⑤. General form of A for the multi-lenses system.

 $$ A=\ldots\Gamma_{43}R_{3}\Gamma_{32}R_{2}\Gamma_{21}R_{1} $$ 

As the example of Hecht’s Book (pg. 251, Hecht, Fig 6.10), the 4 lenses-7 surface system, by writing explicitly each $R_{i}$, $\Gamma_{ij}$ and by production of the matrices, fairly straight-forward to generate the final matrix $A_{\Gamma1}$, which is equivalent to a thick lens; and from its matrix element, the cardinal points of the equivalent lens can be easily calculated.

Such evaluation is more easily solved by computer program. There is

commercial available software for ray tracing, such as “Optical Labs”

“Optical Ray” etc.

## ⑤ Thin Lens Matrix

Knowing the matrix representation  $ A_{21} $ (4-31) for thick lens, it is a simple matter to get the representation in thin lens case, where  $ \Gamma_{21} $ is 1, unit matrix  $ \begin{bmatrix} 1 & 0 \\ 0 & 1 \end{bmatrix} $, and d = 0

Then for thin lens  $ A_{21}=R_{2}R_{1}=\begin{bmatrix}1&-D_{1}-D_{2}\\ 0&1\end{bmatrix} $ (4-35)

And  $ \frac{1}{f}=D_{1}+D_{2} $, the same as lens-maker formula derived earlier.

For the thin lens combination:

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_854_653_1002.jpg" alt="Image" width="33%" /></div>


 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{-D_{2}}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{d}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{-D_{1}}}} \\{{{0}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{1-\frac{d}{f_{2}}}}}&{{{-\frac{1}{f_{1}}-\frac{1}{f_{2}}+\frac{d}{f_{1}f_{2}}}}} \\{{{d}}}&{{{\frac{-d}{f_{1}}+1}}}\end{bmatrix} $$ 

 $$ D_{1}=f_{1}^{-1}\quad D_{2}=f_{2}^{-1} $$ 

 $$ \frac{1}{f}=-a_{12}=\frac{1}{f_{1}}+\frac{1}{f_{2}}-\frac{d}{f_{1}f_{2}} $$ 

Same as (4-23) of the Note

 $$ \overline{O_{1}H_{1}}=\frac{fd}{f_{2}}=\frac{n_{i}(1-a_{11})}{-a_{12}} $$ 

 $$ \overline{O_{2}H_{2}}=-\frac{n_{t_{2}}(Q_{22}-1)}{a_{12}}=\frac{-fd}{f_{1}} $$ 

Same as (4-24)

## 4 -12 Apertures

(Hecht's 5.3)

Up to now, we have focused on the image formation for an optical system, i.e. given the information of the object, finding the location and magnification of its image etc. There is another important topic: Intensity. How much energy will be collected by the optical system? Each lens itself is an aperture only allowing a portion of light passing through it. People also purposely insert apertures (called iris) in the system in order to limit the size of the incoming light beam, so that the paraxial approximation will hold and this will reduce so called aberration and forming better quality picture. These apertures (the lens and the iris) will limit the amount of energy passing and this is what we shall study in this section.

## (1) The Aperture Stop (for axial point sources)

Aperture stops (AS) is the aperture that determines the energy flow through the system. It is the limiting apertures in the system so that if the light from an axial point can pass through AS, it will pass the system.

This is better illustrated by examples:

<div style="text-align: center;"><img src="imgs/img_in_image_box_276_247_768_427.jpg" alt="Image" width="41%" /></div>


In the above optical system with 3 lenses and one iris, the iris (a small hole inserted to limit the size of light beam) is the aperture stop, i.e. the light passing though it will pass through other lens and thus the whole system. We cannot say this to other lens, i.e. the light passing  $ L_{1} $ may not pass the whole system, because it may be blocked by other lens or the iris.

Each aperture (in the figure above, the apertures are  $ L_{1} $,  $ L_{2} $,  $ L_{3} $ and iris) only admit certain amount of light by limiting the steric angle of the energy flow:

<div style="text-align: center;"><img src="imgs/img_in_image_box_255_1056_670_1258.jpg" alt="Image" width="34%" /></div>


The potion of energy flow through the aperture is proportional to the steric angle spanned by it:

 $$ E_{_{T}}/E_{_{0}}=\frac{\pi(R\sin\theta)^{2}}{4\pi R^{2}}\approx\frac{\theta^{2}}{4}=\frac{\Omega}{4\pi} $$ 

Ω is the steric angle spanned by the aperture. The aperture stop is the one that has the smallest steric angle and thus limiting the light passage.

However, determining the AS is not straightforward, as the example shown above, just by looking at the setup we cannot tell which one will be the AS. You have to draw the rays corresponding to the limiting case for each optical element to find the AS. Still referring to the above example, the angle spanned by the first lens  $ L_{1} $ is easy to evaluate, but angles spanned by others may not. Clearly we need more systematic and error proof way for this, and for this purpose we introduce the concept of “pupil”.

## (2) Entrance Pupil and Exit Pupil

Starting with a simpler example with less optical element:

<div style="text-align: center;"><img src="imgs/img_in_image_box_249_1036_768_1157.jpg" alt="Image" width="43%" /></div>


For the 2 lens with one iris setup, we need to determine first which the aperture stop is. This is done by image formation. As always, we use the configuration that light comes from left. Taking the image of each optical element with respect to the lens (or multiple lens system) to the left of it, such images are called pupils. In the simpler example, the iris

and the lens 2 will form image with respect to Lens 1 only. In the earlier example, the iris and lens 3 has to form image with respect to the lens system by lens 1 and lens 2. Once such images (pupils) are determined, it is easy to find out the AS:

<div style="text-align: center;"><img src="imgs/img_in_image_box_254_414_911_686.jpg" alt="Image" width="55%" /></div>


<div style="text-align: center;"> $ L_{2}^{\prime}, A^{\prime} $ are the images of lens and iris A formed by lens 1. The corresponding conjugate of the limiting points are also shown in the figure, such as  $ D_{1}, D_{1}^{\prime} $, etc. Using the property of the object-image conjugate, i.e. the light from the objective point will pass through its image conjugate and vice versa. It is easy to draw the limiting rays for an on axis source S with the help of the pupils (image  $ L_{2}^{\prime}, A^{\prime} $ in this case); such rays are shown as colored arrows in the figure above. Now it is obvious that the blue one (corresponding the iris) span the smallest angle and thus limiting the energy flow, and iris is the aperture stop here.</div>


You can imagine cases where  $ L_{2} $ or even  $ L_{1} $ are the aperture stop for a different arrangement. The detailed determination always depends on the relative position, size, focal lengths and where the point source S is

etc. , the point I want to illustrate is that by such image formation with the optical element to the left, we have systematic method to determine the AS.

Entrance Pupil: The image of the aperture stop form by it with the optical element preceding it (to the left of it with our conventional setup).

Knowing the entrance pupil (determined by the method illustrated by the example above), (4-36) is used to estimate the percentage of energy passed system.

There is also a symmetrical pupil for exit:

Exit Pupil: The image formed by the AS by the optical elements after it (to the right of it).

The light that passes through the entrance pupil will pass through the aperture stop and then leave the system through the exit pupil.

## (3) F number

This is related to the brightness of the image. The size of the image is proportional to square of the linear magnification:

Image Area  $ \propto M_{T}^{2} = \frac{f^{2}}{x_{o}^{2}} $

In many cases where S_o >> f , so will be the x_o = S_o - f , and the area of

image will be approximately proportional to  $ f^{2} $

The energy flow through the system as we had seen previously will be proportional to the square of the diameter of the lens or the aperture stop:  $ E_{r} \propto D^{2} $. So the energy flow density or energy per unit time per unit area on the image will be proportional to  $ \frac{D^{2}}{f^{2}} $

The f number of the lens system is defined as:

 $$ f^{\#}\equiv\frac{f}{D} $$ 

The reason defined as 4-37 as reciprocal of the energy flow density is in photography, this f number is used to determine the exposure time. The larger the f number (the smaller the energy flow rate) means longer the exposure time to get a bright picture.

## (4) Field Stop

Previously we focus on the axial point sources and concern how much energy will pass the optical system. Here we shall consider off-axis point and estimate how much energy will pass through system for these off axis point, this relates to the problem of field of view for the imaging system.

For a single lens system, the lens itself will be the aperture stop, the entrance and exit pupil as well. The light from off axis points can be

collected by the lens and the its field of view is only limited by the paraxial requirement and slow decrease of steric angle spanned by the lens as the point moves further away from axis thus the decrease of energy collected.

For the multiple lens system, the limitation of field of view can arise from an extra factor, so called field stop. This is better illustrated by an example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_293_611_871_985.jpg" alt="Image" width="48%" /></div>


<div style="text-align: center;">In the example of two-lens setup, the second lens AB is the aperture stop and its entrance pupil is the image by lens 1 A'B' as shown in the figure. For the off axis point O' and O", we shall focus on their chief ray, the chief ray is defined as lines connect the off axis points and the center of the entrance pupil (the colored lines in the figure). This chief ray is approximately the direction of energy of input light to the system, it passes through the center of entrance pupil and it may pass through the exit pupil to have an output. If it passes the exit pupil, then</div>


we will say the point can be "seen" by the system. That is to say we select the chief ray as criteria for off-axis point to determine whether it can be "seen". Of course even when chief ray is passing, the off-axis point still suffers some energy loss (in the figure the light from o"-A' may not pass).

In the figure above, the chief rays of both O' and O'' will clear the system, but the O'' is the limiting case. For any point further away from the O'', the chief ray of such points will be unable to pass the lens 1 and thus will not pass the exit pupil to have an output. We call the lens 1 in this example the field stop. The field stop will decide the field of view and in our example, the angle  $ \theta $ spanned by the center of entrance pupil (axial point of A'B') and the field stop (lens1) is the field of view in this example.

Of course here we determine the field of view solely by the chief ray. For the off-axial point further away than O', there will still be some light from them can pass through the system, for instance, the ray such as O'B' can clear the system, but you can see those point will suffer energy loss since most of its energy cannot pass, so the field of view is not a clear cut(the jargon for such phenomena is vignetting) which agrees with our experience (you do not experience sudden complete darkness from side of your eyes, do you?).

## (5) Entrance Window and Exit Window

In the above simple example of two lenses, determine the field stop is relative easy. For complicated lens system, as in the aperture stop case, we need a systematic way to find field stop. This part is also very similar to the relation between aperture stop to those of entrance and exit pupil. We use similar image formation to find out entrance and exit window from field stop. Also first illustrate with example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_263_641_853_977.jpg" alt="Image" width="49%" /></div>


<div style="text-align: center;">In the example, the iris is the aperture stop, and entrance pupil is the image formed by it with the optical elements to the left of it which is only  $ L_{1} $ in this case. We shall also make image of  $ L_{2} $ with respect to the optical elements to the left of it and the image is  $ L'_{2} $. The angle spanned by center of the entrance pupil to those of  $ L_{1} $ and  $ L'_{2} $ are also explicitly displayed and in this case, the  $ L'_{2} $ forms smaller angle and thus limits the field of view. The  $ L_{2} $ will be the field stop and its image  $ L'_{2} $ is called entrance window.</div>


Entrance window: The image of the field stops with respect to the optical elements preceding (to the left in our conventional setup) it.

Exit window: The image of the field stops with respect to the optical elements after (to the right in out convention) it.

The field of view will be determined by the angle spanned by the center of the entrance pupil to the entrance window. Its image conjugate would be angle spanned by the center of the exit pupil to exit window.

In Summary of the image system by geometrical lenses, we see that the multiple lens system is equivalent to one single thick lens (though in practice it is straightforward to work out one lens at a time). The problem regarding to energy flow through the system is dealt with by aperture stop and field stop for on and off axis points. All these are summarize in the figure:

<div style="text-align: center;"><img src="imgs/img_in_image_box_230_1130_884_1444.jpg" alt="Image" width="54%" /></div>


Knowing the cardinal points, determine the pupils and windows, then for any give object, we can find out the location and size of the image; estimate how bright the image will be; and what the field of view is.

## 4 -13 Aberration

Though this is very important in practical applications, such as optical design and engineering, but its complication and details in technique are far beyond the scope of this course, and also beyond my modest ability.

So I’ll choose only to briefly introduce the concept of Aberration and the somewhat details are left for you to read in the book. (Hecht, 6.3, Zhao’s pg106-119)

### 4 -13-1. Monochromatic Aberration

This is introduced while the paraxial Approximation breaks down, by those non-paraxial rays and rays from off-axis points.

From the earlier analysis, we essentially apply  $ n_{i_{1}}\theta_{i_{1}}=n_{i_{1}}\theta_{i_{1}} $ where assume  $ \theta $ is small and  $ \sin\theta\approx\theta $. For oblique rays, this is not exact, and

 $$ \sin\theta=\theta-\frac{\theta^{3}}{3!}+\frac{\theta^{5}}{5!}\cdots\cdots $$ 

(Taylor expansion)

Seidel (monochromatic or 3rd order) Aberration is introduced by including the  $ \frac{\theta^{3}}{3!} $ term into consideration.

## (1) Spherical Aberration

Fig 6.15, 6.16 of Hecht

Basically for the rays parallel with O.A. (optical axis), or Rays from

on-axis point, they will be focused to

Different image location depending on the distance of rays from O.A.

Thus, the objective point will degrade into circles in image plane.

The spherical Aberration can be minimized by choosing combination of converging-diverging lenses or for the special pair of Image-object, the stigmatic points of the lens system.

## (2) Coma

Fig 6.21, 6.22, Hecht.

This is the aberration for the points close to O.A, its marginal rays will form image different from the principle rays. The point object will form a series of circles in image plane.

## (3) Astigmatism

Fig 6.26, 6.27, Hecht's book

For the object points far away from the O.A., it's caused by the

different focal length for the meridional rays and saggittal rays. The image of an object point will be degraded into ellipse (or line, circle) in the image plane.

## (4) Field Curvature

This is caused by that only with in the paraxial region, the Object-Image conjugate surface can be approximated by plane, more generally it is curves, so the image formed on a plane will degrade.

## (5) Distortion

The  $ M_{T} $, the transverse magnification is not a constant across the imagery plane. (Fig 6.33, Hecht)

Generally, due to aberration: Originally point object  $ \leftrightarrow $ point image, the correspondence breaks. The object point is blurred and distorted in the image, thus reduce the quality and resolution of the image. The correction of Aberration can be achieved by suitable combination of lenses, but can only minimize some of the aberrations, not all of them.

### 4 -13-2. Chromatic Aberration

This is caused by the dispersion phenomenon, the dependence of  $ n(\lambda) $ on the frequency of light, so that different  $ \omega $ of light will have different focal length.

The chromatic Aberration can be reduced by using achromatic

doublet, as discussed in Hecht's 6.3.2.

The reflecting mirrors (planar or spherical) do not have chromatic aberration; since in those cases the focal-length does not depend on n (see Hecht's 5.4)

# Wave Optics Interference, Interferometer, Coherence Diffraction- Fourier Optics

Fundamental principle:

Superposition of waves

Central problem: (the kernel question)

Phase distribution over a wave front.

We shall first look at interference (Hecht chap7.1-7.2, Zhao's Chap2 section 1-4), focusing on the principle of superposition illustrating the importance of phase relation in interference, and the evaluation of phase distribution over a wavefront, the using Young's Experiment as example. Later we shall look into some interferometer devices (Zhao's, chap3; Hecht 9.3, 9.4, 9.6) and the important concept of coherence.

## Chapter 5 Interference, Interferometer and Coherence

Let's start this important chapter with some examples to illustrate the phenomena we call interference, which is the hallmark behavior of wave.

<div style="text-align: center;"><img src="imgs/img_in_image_box_176_152_1014_835.jpg" alt="Image" width="70%" /></div>


<div style="text-align: center;">In both cases, the total intensity (energy) from contribution of two paths is not simple summation of the energy of each path:  $ I \neq I_{1} + I_{2} $, such phenomenon is called interference, and we shall see it arises from superposition of waves (not the superposition of irradiance or intensity). Whether the superposition of waves displays interference or not depends on the coherence among component waves.</div>


## 5 -1 Superposition of Waves

This is a fundamental postulate like that superposition of forces and the fields (here the wave is just E-M field anyway). The math view of the

principle of superposition is originated from the wave equation discussed earlier.

 $$ \nabla^{2}U=\frac{1}{V^{2}}\frac{\partial^{2}u}{\partial t^{2}} $$ 

If the v is independent of U then:  $ U = \sum_{i} a_{i} U_{i} $ is the solution of the wave equation provided  $ U_{i} $ is the solution,  $ a_{i} $ is a coefficient.

The field (or waves) shall be added to get the total field (wave), and the system response to the field will be treated linear as long as the field is not too strong, this is the domain of linear optics.

## 5 -1-1 Superposition principle in linear optics

A general light wave can be written as:  $ E = E_0 e^{i\phi(p)} e^{-i\omega t} $ where  $ E_0 $ the amplitude;  $ \phi(p) $ the spatial phase (including the initial phase);  $ \omega t $ the oscillation with time or temporal phase.

For plane wave:  $ \phi(p) = \vec{k} \cdot \vec{r} + \phi_0 $ spherical wave:  $ \phi(p) = kr + \phi_0 $

However, common detectors only detect the irradiance (or intensity) of the light, which we know:  $ I = \left\langle E^2 \right\rangle_T \propto E_0^2 $

Since we are interested in the relative irradiance in most cases, and we

shall let: (as if chosen proper unit)

 $$ I=\left|E\right|^{2}=E_{0}^{2} $$ 

Our common sense sometimes misleadingly makes us to perceive that in the cases of multiple light sources, the resultant irradiance is  $ I = \sum_{i} I_{i} $

This is the case for illumination by incoherent sources such as light bulbs, candles, etc. However,  $ I = \sum_{i} I_{i} $ is generally wrong, as demonstrated by the two examples at the beginning of the chapter. It is the summation of the field E, not I that is physically correct, as stated in the principle of superposition:

<div style="text-align: center;"><img src="imgs/img_in_image_box_288_661_523_784.jpg" alt="Image" width="19%" /></div>


Suppose we have many different field sources contributing to a point p, then from superposition principle, the total field at p is:

 $$ \vec{E}_{p}=\sum_{j}\vec{E}_{j}(p)=\sum_{j}\vec{E}_{0j}e^{i\phi_{j}(p)}e^{-i\omega_{j}t} $$ 

We shall first study simpler case where different components have same frequency and in such case  $ \omega_{j} = \omega $, the intensity can be easily computed with (5-1):

 $$ I=|\vec{E}|^{2}=(\sum_{j}\vec{E}_{j})\cdot(\sum_{k}\vec{E}_{k})=\sum_{j}E_{0j}^{2}+2\sum_{j}\sum_{k<j}\vec{E}_{0j}\cdot\vec{E}_{0k}\cos[\phi_{j}(p)-\phi_{k}(p)] $$ 

The first term on the right hand side  $ \sum_{j} E_{0j}^{2} = \sum_{j} I_{j} $ is the summation of intensity. There is an extra cross term that will give rise to interference.

## 5 -1-2 Superposition of Waves with same  $ \omega $, Parallel

In this case, we can treat the vector field as scalar since the vectors are parallel:

 $$ E_{j}=E_{oj}e^{i\phi_{j}(p)}e^{-i\omega t} $$ 

 $$ E=\left[\sum_{j}E_{oj}e^{i\phi_{j}(p)}\right]e^{-i\omega t} $$ 

The superposed wave E then is:

 $$ \begin{aligned}&E=E_{o}e^{i\phi(p)}e^{-i\omega t}\quad with same frequency,and\\ &\\ &E_{o}e^{i\phi(p)}=\sum_{j}E_{oj}e^{i\phi_{j}(p)}\\ &\\ &E_{0}^{2}=\sum_{j}E_{oj}^{2}+2\sum_{i>j}\sum_{j}E_{oj}E_{oi}\cos\Big[\phi_{j}(p)-\phi_{i}(p)\Big]\\ &\\ &\tan\Big[\phi(p)\Big]=\frac{\sum_{j}E_{oj}\sin\phi_{j}}{\sum_{j}E_{oj}\cos\phi_{j}}\quad(5-5)\\ \end{aligned} $$ 

(5-4) is just (5-3), a result of superposition; the (5-5) can be relatively easily derived by phasor method.

<div style="text-align: center;"><img src="imgs/img_in_image_box_237_156_699_462.jpg" alt="Image" width="38%" /></div>


The phasor method in superposition of waves usually offers an intuitive and speedy solution of waves with same frequency and parallel  $ E_{0} $.

## 5 -1-3 Standing Waves

(Hecht, 7.1.4)

An interesting puzzle: recalling the reflection by a surface at normal incident angle in discussion of Fresnel equations:

<div style="text-align: center;"><img src="imgs/img_in_image_box_198_1053_1009_1240.jpg" alt="Image" width="68%" /></div>


In the example above when $n_t > n_i$ (external reflection), the reflected light's $\bar{E}_p$ and $\bar{B}$ field are shown in the figure. From the Fresnel equation we know $E_{p_i}$ and $E_{p_r}$ are reversed in direction (so, $\bar{B}_i, \bar{B}_r$ are in same direction, since $\vec{k}_i$ and $\vec{k}_r$ reversed, and $E \times B \to k$ for traveling

E-M waves). So it seems if we superpose the incident and reflecting waves, $E = \vec{E}_i + \vec{E}_r$ diminishes, while $B = \vec{B}_i + \vec{B}_r$ increases. Recall that for traveling waves, $E = cB$, there seems existing an apparent paradox. The reason is that the superposition of two traveling waves travelling in opposite directions will result in a standing wave, not a traveling wave.

The general solution to the wave equation takes form of  $ \psi(x,t)=C_{1}f(x-vt)+C_{2}g(x+vt) $

So when two waves travel in opposite direction, the summation also satisfies the wave equation. For this case, the resultant wave will be a standing wave. (I follow the Hecht's derivation and use sines for wave; if you use cosines or Euler formula, same results)

For the wave propagates along -x:  $ E_{I}=E_{0I}\sin(kx+\omega t+\varepsilon_{I}) $

The reflected wave propagates along +x:  $ E_{R}=E_{0R}\sin(kx-\omega t+\varepsilon_{R}) $

The Reflecting Mirror at x=0, the boundary condition at x=0, requires  $ E = E_{I} + E_{R} = 0 $

Let’s consider the simple case where  $ r=1 $ or  $ E_{0I}=E_{0R} $, we can set  $ \varepsilon_I=0 $ (which is arbitrary anyway, we always have the freedom to set the initial phase of ONE wave as zero), and the  $ E_I+E_R\big|_{(x=0)}=0\to\varepsilon_R=0 $ and the superposition of wave is:

 $$ \begin{aligned}&E=E_{0}\left[\sin(kx+\omega t)+\sin(kx-\omega t)\right]\\&=2E_{0}\sin kx\cos\omega t\\ \end{aligned} $$ 

(5-6) is the expression for a standing wave. It is standing in a sense that the spatial distribution sinkx, does not move with time (the nodes and the antinodes are fixed in space, in contrast to the traveling wave); the amplitude changes with time as coswt (see figure 7.10, 7.11 in Hecht's book and Fig 7.14 shows a setup to verify the existence of the standing wave).

For an open end standing wave (i.e. only has boundary condition at one end, such as waves reflected by one mirror as shown):

 $ \frac{E_{I}}{E_{R}} \rightarrow \sqrt{\frac{1}{2}} $, the resulting standing waves in  $ kx\cos\omega t $, there is no restriction on the value of k, it can take any values.

Another important case is the light field in a cavity:

<div style="text-align: center;"><img src="imgs/img_in_chart_box_185_948_487_1141.jpg" alt="Image" width="25%" /></div>


such as the two mirror cavity separated by

L. The boundary condition would be  $ E(x=0x=L)=0 $, the resultant stable

wave is still in the form of  $ \sin kx \cos \omega t $, but with restriction on k. where

 $ 2L = m\lambda = \frac{2\pi m}{k}, m = 0, 1, 2 \cdots \cdots (5 - 7) $

This is directly from the boundary condition E(x=L)=0→kl=mπ. The reason that I wrote it in form of (5-7) is that it represents a clear physical

picture, as I shall demonstrate below.

From the superposition of wave, the field inside the cavity bounded by M1, M2 is the superposition of the incident wave and the reflected ones (multiple times) by M1 and M2. Another equivalent way to look at this 2-Mirror, L length cavity is taking it as circle with 2L periphery, the waves travels along in circle. The only stable ones are the waves that after one round passage overlap exactly with the original ones i.e.  $ 2L = m\lambda $,  $ m = 0,1,2\cdots\cdots $ or  $ \_2nL = m\lambda_0 $ in terms of Optical Path length.

<div style="text-align: center;"><img src="imgs/img_in_image_box_232_697_392_849.jpg" alt="Image" width="13%" /></div>


These waves are standing waves; for those do not satisfy (5-7) the superposition will result in a null field (E=0). For length=L cavity, the standing waves of first 3 lowest m (called modes) are:

<div style="text-align: center;"><img src="imgs/img_in_image_box_211_1089_419_1153.jpg" alt="Image" width="17%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_202_1181_414_1274.jpg" alt="Image" width="17%" /></div>


 $$ m=1\quad or\quad k=\frac{\pi}{2},\lambda=2L $$ 

 $$ m=2\quad or\quad k=\frac{\pi}{2L}\quad\lambda=L $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_1293_410_1377.jpg" alt="Image" width="18%" /></div>


 $$ m=3\quad\text{or}\quad k=\frac{\pi}{3L}\quad\lambda=\frac{2L}{3} $$ 

The standing waves have form of (5-6), and then the expression for the B

field can be derived from Maxwell equation:

 $$ \nabla\times\boldsymbol{E}\propto\frac{-\partial\boldsymbol{B}}{\partial t}\Rightarrow\boldsymbol{B}\propto-\cos kx\sin\omega t $$ 

Thus what are nodes for the E field (sinkx=0), are antinodes for B (coskx=1); what are antinodes for E are nodes for B. This is the relation for  $ \vec{E}, \vec{B} $ of standing waves, and this explains the puzzle stated at the beginning of this section.

Not only in the light (such as light field in a cavity, which is fundamental in laser), standing wave also plays crucial roles in other waves, such as sound waves. Most music instruments are based on it. Also if you ever tried to entertain your friends by inhaling helium (He) gas, your sound would be much higher pitched (high frequency). Can you explain this using what you have learned?

## 5 -1-4 The addition of waves of different frequency

(Hecht, 7.2)

## (a) Beats

Simple case: two waves with different frequency, travel in same direction, parallel E field, same  $ \vec{E}_{0} $

 $$ \omega_{1}=\omega_{0}+\Delta\omega\qquad\omega_{2}=\omega_{0}-\Delta\omega\qquad k_{1}=k_{0}+\Delta k\quad k_{2}=k_{0}-\Delta k\quad(true for\Delta\omega<< $$ 

ω0)

 $$ \begin{aligned}&E=E_{0}\Big\{e^{i\left[\left(k_{0}+\Delta k\right)x-\left(\omega_{0}+\Delta\omega\right)t\right]}+e^{i\left[\left(k_{0}-\Delta k\right)x-\left(\omega_{0}-\Delta\omega\right)t\right]}\Big\}\\&=E_{0}\Big[e^{i\left(\Delta k x-\Delta\omega t\right)}+e^{-i\left(\Delta k x-\Delta\omega t\right)}\Big]e^{i\left(k_{0}x-\omega_{0}t\right)}\\&=E_{0}\bullet2\cos(\Delta k x-\Delta\omega t)e^{i\left(k_{0}x-\omega_{0}t\right)}\\ \end{aligned} $$ 

E is a wave propagating like a plane harmonic wave $e^{i(k_0x-\omega_0t)}$ , but with a modulation on its amplitude(also called envelop) $\cos(\Delta kx-\Delta\omega t)$. The energy will be in forms of:

 $$ \cos^{2}(\Delta kx-\Delta\omega t)=\frac{1+\cos(2\Delta kx-2\Delta\omega t)}{2} $$ 

The  $ 2\Delta\omega = \omega_2 - \omega_1 $ is called beat frequency.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_241_814_1029_1245.jpg" alt="Image" width="66%" /></div>


The traveling speed of this modulation envelop is Group Velocity:

 $$ \begin{aligned}&\therefore V_{g}=\frac{d\omega}{dk}=\frac{C_{0}}{n(k)}-\frac{C_{0}}{n^{2}}k\frac{dn}{dk}\\ &=\frac{C_{0}}{n}(1-\frac{k}{n}\frac{dn}{dk})\\ \end{aligned} $$ 

In vacuum, n=1,  $ \frac{dn}{dk}=0 $,  $ V_g = C_0 $, group and phase velocity are same

But in Optical media, with dispersion ( $ \frac{dn}{dk} \neq 0 $),  $ V_g \neq v $

(b) Adding more waves with diff. freq.

Let's study a case where the freq. distribution is given by a square function:

 $$ \begin{aligned}&\begin{bmatrix} \\{{{\frac{\Delta W}{2}}}}&{{{+\frac{\Delta W}{2}}}} \\{{{\frac{1}{2}}}}&{{{0}}} \\\end{bmatrix}\\ \end{aligned} $$ 

Center freq.  $ \omega_{0} $,  $ k_{0} $

Width of distribution  $ \triangle\omega,\triangle k $

Then the superposition of waves with freq. distribution given by the above is:

 $$ \begin{aligned}&E=\sum E_{0}\delta\omega e^{i[(k_{0}+k)x-(\omega_{0}+\omega)t]}\quad&-\frac{\Delta k}{2}\leq k\leq\frac{\Delta k}{2}\\&=E_{0}e^{i(k_{0}x-\omega_{0}t)}\int_{\frac{\Delta\omega}{2}}^{\frac{\Delta\omega}{2}}e^{i(kx-\omega t)}d\omega\quad&-\frac{\Delta\omega}{2}\leq\omega\leq\frac{\Delta\omega}{2}\\ \end{aligned} $$ 

There are some explanations of the symbols I used above which is slightly different from the conventional use through this note. Here $E_0$ is the density of the field (it is in unit of field/frequency, such as Volt. Sec. /meter) the $E_0\delta\omega$ is the field strength within small interval $\delta\omega$. k is a small variation around $k_0$ (so is the $\omega$), so we have the following relation: $k=\omega/V_g$. For the small $\Delta\omega$ or $\Delta k$, $V_g$ can be

taken as constant (dispersion effect is small within this range), then:

 $$ \begin{aligned}&\int_{\frac{\Delta\omega}{2}}^{\frac{\Delta\omega}{2}}e^{i(\frac{x}{V_{g}}-t)\omega}d\omega,\quad Set T^{\prime}\equiv(\frac{x}{V_{g}}-t)\\ &=\frac{1}{iT^{\prime}}[e^{iT\cdot\frac{\Delta\omega}{2}}-e^{-iT\cdot\frac{\Delta\omega}{2}}]\\ &=\frac{2\sin(T^{\prime}\frac{\Delta\omega}{2})}{T^{\prime}}\cdots\\ &=\Delta\omega\sin c(T^{\prime}\frac{\Delta\omega}{2})\cdots\cdots(5-10)\\ \end{aligned} $$ 

 $$ \sin c(x)\equiv\frac{\sin x}{x} $$ 

 $$ E=\frac{\sin(T^{\prime}\frac{\Delta\omega}{2})}{\frac{T^{\prime}}{2}}E_{0}e^{i(k_{0}x-\omega_{0}t)} $$ 

The modulation envelope given by  $ (5-10) $ has the shape:

<div style="text-align: center;"><img src="imgs/img_in_image_box_178_926_980_1238.jpg" alt="Image" width="67%" /></div>


It has maximum at T' = 0, maximum =  $ \Delta \omega $ It has 0 value when T' \neq 0, and  $ \frac{T' \Delta \omega}{2} = m \pi (m = 0, \pm 1 \cdots) $

The width of band is defined as the space between the maximum and

closest zero, i.e.

 $$ \begin{aligned}&\frac{T_{1st0}^{\prime}\Delta\omega}{2}=\pi\rightarrow T_{1st0}^{\prime}=\frac{2\pi}{\Delta\omega}\\&\Delta T^{\prime}=T_{1st0}^{\prime}-T_{\max}^{\prime}=\frac{2\pi}{\Delta\omega}\\&\Delta T^{\prime}\Delta\omega=2\pi or\Delta T^{\prime}\Delta\upsilon=1\\ \end{aligned} $$ 

As we can see that as  $ \Delta\omega $ increases, the maxima increase while the width narrows. The modulation envelope as given by (5-10) is in form of wave packet, this wave packet moves at a speed of (defined by the moving speed of maximum):  $ T' = 0 \rightarrow \frac{x}{\nu_g} - t = 0 \therefore \frac{x}{t} = \nu_g $

The (5-11) is a key feature and direct result of sinc function, which is the result of adding waves with different frequencies whose distribution is a square function (In language of Fourier Transform, we will see exactly same result later).

In summary what I have demonstrated here are:

(1)A superposition of many waves with continuous freq. distribution, results in a wave packet.

(2) The wave packet moves at group velocity  $ V_{g} $

(3) The width of the wave packet (or distribution of the wave packet, for instance, at a fixed space point, x, the width of wave packet  $ \Delta T' \rightarrow $ duration of time  $ \Delta t $) depends on the width of frequency distribution  $ \Delta\omega(or\Delta v) $ with  $ \Delta T\Delta\upsilon \approx 1 $

Similarly, in the derivation instead of  $ \int_{\frac{\Delta\omega}{2}}^{\frac{\Delta\omega}{2}} d\omega $ we use  $ \int_{-\frac{\Delta k}{2}}^{\frac{\Delta k}{2}} dk $,

and define  $ \Delta x' = x - v_{g}t $ we get similar results  $ \Delta x' \Delta k \approx 2\pi $

Comments: In the real world, the single frequency monochromatic light does not exist, it is only a mathematical idealization. The light we encounter always have a distribution over certain freq. range (or wavelength) even the narrowest light source we have today, say a laser, its output has frequency range for about ~kHz, for narrow  $ \Delta\omega $ or  $ \Delta k $ implies larger  $ \Delta $ or  $ \Delta x $:

<div style="text-align: center;"><img src="imgs/img_in_image_box_180_739_1008_938.jpg" alt="Image" width="69%" /></div>


<div style="text-align: center;">Quasi monochromatic light</div>


The reverse relation (5-11) between  $ \Delta T\Delta\upsilon(or\Delta\omega) $ or  $ \Delta x\Delta k $ has deep physical implication in Uncertainty Principle in Quantum Mechanics, and its mathematical root is in Fourier Transform. We shall come back to this later when we discuss the Fourier Optics. (Here, an ascute student will discover that the derivation leading to relation (5-10), i.e.  $ \int_{-\frac{\Delta\omega}{2}}^{\frac{\Delta\omega}{2}} e^{iT'\omega} d\omega $ is basically a Fourier Transform of the square distribution of frequency.  $ \int_{-\infty}^{+\infty} f(\omega)e^{i(kx-\omega t)}d\omega $ where  $ f(w) $ is in form of square function shown earlier)

In the derivation, we hold  $ v_g = const $, which is an approximation, true for  $ \Delta \omega r \Delta k $ is small. If  $ \Delta \omega $ is large then  $ v_g $ is no longer a constant

Example: Femeto second (fs $10^{-15}$ second) pulse: duration of wave of wave packet in time is~ $fs$. Is a superposition of waves with freq. distribution on the order of $\Delta T\Delta v\approx1\rightarrow\Delta v\approx10^{15}$ HZ

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_554_319_639.jpg" alt="Image" width="7%" /></div>


When it propagate along a dispersive media (i.e.  $ \frac{dn}{dk} \neq 0or\frac{dn}{d\omega} \neq 0 $) the width will broadened:

<div style="text-align: center;"><img src="imgs/img_in_image_box_180_841_963_1000.jpg" alt="Image" width="65%" /></div>


The broadening is due to different  $ v_{g} $ in a dispersive media:

<div style="text-align: center;"><img src="imgs/img_in_image_box_192_1117_586_1323.jpg" alt="Image" width="33%" /></div>


The broadening of wave packet

With the superposition of many waves with diff. freq. we conclude our discussion on this issue. However there are other situations, namely:

(a) We showed superposition of harmonic waves with diff. freq.→wave packet of certain shape.

Reversely, for an arbitrary function, we can decompose it into harmonic components→Fourier analysis and Fourier Transform.

(b)We studied the superposition of waves with  $ \vec{E} $ parallel, the superposition of perpendicular  $ \vec{E} $ fields will result in so called polarization states of the field, depending on the frequency we may have:

 $$ \left\{\begin{aligned}same\_{o}\rightarrow linear,circular,elliptical\_{p}olarized\_{l}ight\\  diff.\omega\rightarrow Lessajous\_{F}igure\end{aligned}\right. $$ 

We shall treat these topics in the later classes. In the treatment of interference, we only need to consider the superposition of waves with parallel  $ \vec{E} $ field, so in this chapter, we can temporarily forget the vector nature of the light field.

## 5 -2 Interference and Coherence

In the following parts, I shall focus on simpler case that all fields are along the same direction so that I can use scalar instead of vector to represent the field. The vector nature of the field will be considered when we treat polarization.

5-2-1. Interference – General Considerations

1 $ \begin{array}{c}E_{1}\\E_{2}\\p\end{array} $

2 $ \begin{array}{c}E_{1}\\E_{2}\\p\end{array} $

3 $ \begin{array}{c}E_{1}\\E_{2}\\p\end{array} $

We have seen that in the superposition requires  $ E = \sum_{j} E_j $, but not necessarily  $ I = \sum_{i} I_i $.

From (5-3) in the previous section, we have:

 $$ I(P)=\sum_{i}E_{oj}^{2}+2\sum_{j}\sum_{i}\bar{E}_{oj}\bar{E}_{oi}\overline{\cos[\phi_{j}(p)-\phi_{i}(p)]} $$ 

In this relation, the bar over the cosine term means time average, which is the case in realistic measurement of intensity of the light.

The interference requires that the cross terms are not vanishing, we shall see this requires the condition of coherence (next section). First let see some direct conclusion from the intensity formula:

(a) For interference between two sources:

 $$ I=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}\cos\delta(P) $$ 

 $$ \delta(P)=\phi_{1}(P)-\phi_{2}(P) $$ 

 $$ I_{\max}=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}=(E_{O1}+E_{O2})^{2}>I_{1}+I_{2} $$ 

 $$ I_{\min}=I_{1}+I_{2}-2\sqrt{I_{1}I_{2}}=(E_{O1}-E_{O2})^{2}<\left|I_{1}-I_{2}\right| $$ 

The interference is essentially a redistribution of energy, creating peaks and valleys (maximum and minimum) in intensity over the space, but the average irradiance o $\bar{I}$ over the space is $I_{1}+I_{2}$, since $<\cos\delta(p)>_{\text{space}}=0$. Interference does not violate the conservation of energy.

## (b) Contrast (visibility)

 $$ \gamma\equiv\frac{I_{\max}-I_{\min}}{I_{\max}+I_{\min}} $$ 

For the two sources case, substitute  $ I_{max} $  $ I_{min} $

 $$ \gamma=\frac{2\sqrt{I_{1}I_{2}}}{I_{1}+I_{2}} $$ 

 $$ I_{0}\equiv I_{1}+I_{2} $$ 

 $$ I=I_{0}(1+\gamma\cos\delta) $$ 

γ is a measure the contrast between maximum and minimum in the intensity distribution in interference. Larger γ means larger contrast, easier to observe interference.

 $$ \begin{aligned}&\gamma\rightarrow1\qquad if\qquad I_{min}\quad\rightarrow0\\ &\\ &\gamma\rightarrow0\qquad if\qquad I_{min}\quad\rightarrow I_{max}\\ \end{aligned} $$ 

For the two coherent sources,  $ \gamma \to 1 $ (or  $ I_{\min} \to 0 $) if the amplitude of the two sources are equal:  $ E_{01} = E_{02} $ ( $ I_1 = I_2 $).

### 5 -2-2. Conditions for Coherence

The sources are considered coherent if:

(1) Phase term  $ <\cos\delta(p)>_{T}=\frac{1}{T}\int_{t}^{t+T}\cos[\delta(p)]dt\neq0 $ i.e. have stationary phase difference  $ \delta(P)=\phi_{j}(P)-\phi_{i}(P) $

(2) Same frequency

(3) Have parallel  $ \bar{E} $ components.

The above conditions are needed for nonzero cross terms in intensity formula. The sources satisfying the above conditions are called Coherent (means well-correlated)

For condition (1),  $ \delta(\mathrm{P}) $ consists two parts:

 $$ \delta(P)=\phi_{j}(P)-\phi_{i}(P)+\xi_{j}-\xi_{i} $$ 

 $ \phi_j(P) - \phi_i(P) $ is the phase difference due to space distribution (such as  $ \vec{k} \cdot (\vec{r}_1 - \vec{r}_2) $ for plane wave, or  $ k(r_1 - r_2) $ for spherical wave) and  $ \xi_j - \xi_i $ is the phase difference due to initial phase. There should also be time dependent part  $ \omega t $, but under same frequency condition, that is cancelled.

The spatial part, for fixed arrangement of sources and observer,  $ \phi_j^0(P) - \phi_i^0(P) $ usually has fixed relations;  $ \Delta\xi = \xi_j - \xi_i $ will however depend on the nature of the light source, it could be random, and the stationary  $ \delta(P) $ requires that  $ \Delta\xi $ has to be stable too (stable means do not

change with time, at least within the time interval of the measurement).

For condition (2), if we have different frequencies in hand, it effectively introduces a time varying phase factor into  $ \delta(\mathrm{P}), ((\Delta\omega)t) $, and time average may become 0

For condition (3), to guarantee that  $ \bar{E}_i \cdot \bar{E}_j \neq 0 $, it is obvious necessary to have parallel component. In the superposition of two perpendicular

<div style="text-align: center;"><img src="imgs/img_in_image_box_555_553_681_660.jpg" alt="Image" width="10%" /></div>


vectors, E₁, E₂, E = E₁ + E₂ \quad \text{‘‘} \quad \text{, clearly}

|E|^{2} = |E_1|^{2} + |E_2|^{2} \quad \text{no cross term, no interference.}

\quad \text{The above are ideal coherent conditions which may not be satisfied}

\quad \text{rigorously in practice, since the light sources are only}

\quad \text{quasi-monochromatic, the phases cannot be stationary infinitely.}



The modified Coherent Condition:

(1) nearly same frequency

(2)  $ \triangle\phi_{i}(P)+\triangle\xi_{i} $ is stationary over the detection period

(3)  $ \bar{E} $ has parallel component

Now the phase difference is:  $ \delta = \Delta \phi(p) + \Delta \omega t + \Delta \xi $. The conditions (1), (2) that make nonzero cross term will depend on the detection period,  $ \tau $ (the time that intensity is averaged). During the time period of average, if  $ \tau \ll 2\pi / \Delta \omega $ or  $ \Delta \omega \tau \ll 2\pi $, the time varying of frequency difference is

small and the average will not be zero, that is the reason for small frequency difference as required by (1);  $ \Delta\phi(p) $ the phase difference due to spatial difference usually can be maintained at fixed value by fix the OPL the light travels so that will not be a problem here;  $ \Delta\xi $ depends on the nature of the light source, it has to be stationary within detection period  $ \tau $.

The detection period τ has to be longer than the time resolution (response time) of the detectors  $ t_{res} $ (it is the smallest time interval allowed by the detector to make meaningful measurement), i.e.

 $ \tau > t_{res} \quad (t_{res} \sim 10^{-1} \text{s for eye}, 10^{-9} \text{s for PMT the photo multiplier tube}) $

In the visible light region, the time period of optical oscillation is on the order of  $ T = \frac{2\pi}{\omega} \sim 10^{-14} - 10^{-15} s $, and  $ \tau \gg T $. Thus the average  $ I = <E^2> \tau $, the cos $ \omega $ term is averaged out in the process, that is the reason we have  $ I \propto E_0^2 $.

For condition (1) with different frequency components add up, we have seen that will result in modulation of the envelope of amplitude .(wave packet or beat), the amplitude envelope varies approximately with  $ \cos(\triangle\omega t) $, for small  $ \triangle\omega $,  $ \tau < \frac{2\pi}{\triangle\omega} $, then within the detection time  $ \cos(\triangle\omega t) $ varies little and will not average to zero. For condition (2), the stability of the phase difference, the  $ \triangle\xi_{i} $ term, is

depending on the Coherent time  $ \tau_0 $ of the source. For conventional thermal sources,  $ \tau_0 \sim 10^{-12} - 10^{-8} s $; for lasers,  $ \tau_0 \sim 10^{-6} - 10^{-5} s $.

For  $ \tau \gg \tau_0 $ \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \quad \

## 5 -3 Wavefront Splitting Interference

## 5 -3-1 Interference of Two Point Sources

 $ Q_{1}.Q_{2} $ is two point sources, radiate spherical waves, with same amplitude and equal initial phase, same frequency.

Then the field from such point sources is in spherical wave form:

 $$ E_{i}=\frac{A_{io}}{r}e^{+ikr_{i}}e^{-i\omega t} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_182_987_580_1216.jpg" alt="Image" width="33%" /></div>


 $ I(P)=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}\cos\delta $ This is just (5-12) given before.

 $$ I_{1}(P)=A_{1}^{2}=\left(\frac{A_{10}}{r_{1}}\right)^{2},\quad I_{2}(P)=A_{2}^{2}=\left(\frac{A_{20}}{r_{2}}\right)^{2} $$ 

For  $ r_{1}, r_{2} \gg d $, d is separation between Q1, Q2.

 $$ I_{1}\approx I_{2}\quad or\quad A_{1}\approx A_{2}=A $$ 

Then  $ I(P)=2A^{2}(1+\cos\delta)=4A^{2}\cos^{2}\frac{\delta}{2} $ (5−15)

To evaluate  $ \delta $:

 $$ \delta=\phi_{1}(P)-\phi_{2}(P)=\frac{2\pi}{\lambda}(r_{1}-r_{2}) $$ 

So for every points in the field, by knowing the phase difference from  $ (5-16) $, we know the intensity by  $ (5-15) $ or  $ (5-12) $. We shall concentrate on the maxima and minima of the interference pattern

Then it is easy to see, for

 $$ \left\{\begin{aligned}r_{1}-r_{2}&=m\lambda\quad&m&=0,\pm1,\pm2\cdots,I(P)is\quad&\max imum\\ r_{1}-r_{2}&=(m+\frac{1}{2})\lambda\quad&m&=0,\pm1,\pm2\cdots,I(P)is\quad&\min imum\end{aligned}\right. $$ 

The contour of points P’s satisfying the above relations are hyperbola surfaces, with Q₁, Q₂ at their foci (S₁, S₂ in the Fig 9.3 in Hecht’s):

<div style="text-align: center;"><img src="imgs/img_in_image_box_211_1076_930_1336.jpg" alt="Image" width="60%" /></div>


The interference pattern on an observing screen would generally be hyperbolic curves, i.e.

<div style="text-align: center;"><img src="imgs/img_in_image_box_177_150_1013_356.jpg" alt="Image" width="70%" /></div>


Under paraxial condition, i.e.  $ x^{12}, y^{12} \ll D^{2} $, then the curves are approximately close to straight lines.

## 5 -3-2 Young's Experiment

<div style="text-align: center;"><img src="imgs/img_in_image_box_217_641_1010_981.jpg" alt="Image" width="66%" /></div>


Paraxial condition:  $ d^{2} \ll D^{2}, X'^{2}, Y'^{2} \ll D^{2} $

Let's first treat the ideal case, where S, S1, S2 are treated as point sources (As we shall see later, that the sizes of S consisting of incoherent sources will give rise to spatial Coherence; the sizes of S₁, S2 will lead to the problem of diffraction).

The cleverness of Young’s setup is to eliminate the effect of random phase fluctuation in conventional incoherent light sources. For two incoherent light sources, the  $ \delta(P) $, phase difference at P, consists of

$\triangle\phi(P)+\triangle\xi$ , where $\triangle\xi$ , the initial phase difference randomly change , and $<\cos\delta>_{T}=0$ , no interference. In the Young’s Experiment, such random initial phase change is cancelled out. i.e.:

 $$ E(S_{1})=A_{1}e^{i(k\overline{s}\overline{s}_{1}+\xi)}e^{-i\omega t}\quad A_{1}=\left.\frac{A_{s}}{\overline{S S}_{1}}\right. $$ 

 $$ E(S_{2})=A_{2}e^{i(k\overline{s}\overline{s}_{2}+\xi)}e^{-i\omega t}\quad A_{2}=\left.\frac{A_{s}}{\overline{S}\overline{S}_{2}}\right. $$ 

 $$ E_{S1}(P)=\frac{A_{1}}{r_{1}}e^{i[k(\overline{S S_{1}}+r_{1})+\xi]}e^{-i\omega t} $$ 

 $$ E_{S2}(P)=\frac{A_{2}}{r_{2}}e^{i[k(\overline{S}\overline{S}_{2}+r_{2})+\xi]}e^{-i\omega t} $$ 

Though  $ \xi $ is a random number,  $ \delta(P) $ is not depending on it, i.e.  $ S_{1}, S_{2} $ are coherent.

Using the figure above, we can prove

 $$ I(x^{\prime},y^{\prime})=4A^{2}\cos^{2}(\frac{kd}{2D}x^{\prime}) $$ 

A is the amplitude at point P by  $ S_{1} $ or  $ S_{2} $ (they are equal under paraxial condition).

 $$ \delta(P)=k(r_{1}-r_{2})=k_{\triangle}L\qquad\quad\mathrm{(H e r e,~w e~t a k e~\overline{{S S}}_{1}=\overline{{S S}}_{2}~)} $$ 

 $$ \triangle L=r_{1}-r_{2}\approx d\sin\theta_{m}\doteq d\theta_{m}\quad for\quad x^{\prime}\ll D $$ 

 $$ \theta_{m}\approx x_{}^{\prime}/_{D}\rightarrow\triangle L=\frac{d}{D}x_{}^{\prime} $$ 

 $$ \delta(P)=\frac{kd}{D}x^{\prime}\quad(5-17) $$ 

\begin{array}{l} \text{From (5-12)} \quad I(P)=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}} \cos(\frac{kd}{D}x') \end{array}

I1 ≈ I2 under paraxial condition, d2 ⇔ D2 ,

Then  $ I_{1} \approx \left( \frac{A_{1}}{r_{0}} \right)^{2} \approx I_{2} $,  $ r_{0} $ is the center of  $ \overline{S_{1}S_{2}} $ to P.

 $$ I(P)\approx4I_{1}\cos^{2}(\frac{kd}{2D}x^{\prime}) $$ 

 $$ \begin{aligned}\triangle L=&\frac{d}{D}x^{\prime}=m\lambda,m=0,\pm1\cdots,\rightarrow\quad m^{th}\quad\max ima\\=&(m+\frac{1}{2})\lambda;m=0\pm1\rightarrow\quad m^{th}\quad\min nima\end{aligned} $$ 

The interference pattern by double slits is something like:

## ……

The spacing between the adjacent maxima (or minima) is given by:

 $ \frac{kd}{D}\Delta x' = 2\pi $, and this will give:

 $$ \triangle x^{\prime}=\frac{\lambda D}{d}\approx\frac{\lambda}{\triangle\theta} $$ 

$\Delta\theta=\frac{d}{D}$ is the angle spanned by the center of receiving screen with $S_{1}$, $S_{2}$.

## 5 -3-3 A more Strict and Systematic Treatment

## (1) Wavefront distribution (Zhao's P148-158)

As stated earlier, the key question in interference is to evaluate  $ \delta(P)=\phi_{j}(P)-\phi_{i}(P) $ then we have to know  $ \phi_{i}(P) $, the general expression for phase distribution of a point source over space. Previously, we state that wavefront is a constant phase surface, here we generalize it referring to any surface in the field, and we are interested in the field distribution E (P) across this surface.

Any light sources can be visualize as consisting of many point sources, so the basic question would be , what is E(P) on a wavefront in a field created by point sources.

<div style="text-align: center;"><img src="imgs/img_in_image_box_188_1093_866_1459.jpg" alt="Image" width="56%" /></div>


<div style="text-align: center;">O, Q,…… are point sources on (x,y) plane, what are the field distribution</div>


on (x',y') plane? Two planes are separated by distance Z.

For multiple light sources, we are going to divide them into axial points and off-axis points, though the definition of axis is somewhat arbitrary since the origin choice is sort of arbitrary. Suppose we chose the origin and designated the axis as the figure above.

(This part is described in detail in Zhao's book, Pg. 148-157, so only a brief discussion here)

(a) Paraxial and Far-field conditions for axial point sources

 $$ E(P)=\frac{a}{r}e^{ikr}\quad take\quad\xi_{i}=0,initial\quad phase,\quad neglect\quad e^{-i\omega t}\quad term $$ 

 $$ \begin{aligned}r&=\sqrt{z^{2}+x^{\prime2}+y^{\prime2}}=\sqrt{z^{2}+\rho^{2}}\quad\rho^{2}=x^{\prime2}+y^{\prime2}\\&\quad=z(1+\frac{\rho^{2}}{2z^{2}}\cdots)\end{aligned} $$ 

$\rho$ is the distance to origin in $(x',y')$ plane, the observing plane, under paraxial condition: $\rho^2 \ll Z^2$ and by Taylor expansion neglecting higher order terms, we get above expression of $r$.

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z(1+\rho^{2}_{/2z^{2}})}e^{ik(z+\frac{\rho^{2}}{2z})} $$ 

Paraxial condition:  $ \rho^{2} \ll z^{2} $

Then  $ \frac{a}{r} \approx \frac{a}{z} $ constant in  $ (x', y') $ plane.

Far-field condition  $ \frac{k\rho^2}{2z} \ll \pi $ or  $ z \gg \rho^2 / \lambda $ then  $ e^{ikr} \sim e^{ikz} $. In optical frequency region, far-field condition is usually stronger than the paraxial, because of the small wavelength.

Under both paraxial and Far-field condition, the spherical wavefront on  $ (x'-y') $ becomes a plane wave.

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z}e^{ikz} $$ 

(b) For off-axis point

<div style="text-align: center;"><img src="imgs/img_in_image_box_543_624_883_730.jpg" alt="Image" width="28%" /></div>


 $$ E(x^{\prime},y^{\prime})=\frac{a}{r}e^{ikr} $$ 

 $$ r=\sqrt{z^{2}+\left(x-x^{\prime}\right)^{2}+\left(y-y^{\prime}\right)^{2}},\quad r_{0}^{\prime}=\sqrt{z^{2}+x^{2}+y^{2}},\quad r_{0}=\sqrt{z^{2}+x^{\prime2}+y^{\prime2}} $$ 

 $$ \rho_{\Delta}^{2}=(x^{\prime}-x)^{2}+(y^{\prime}-y)^{2};r=z\sqrt{1+(\frac{\rho_{\Delta}}{z})^{2}},Taylor expansion: $$ 

 $$ \begin{aligned}r=z+\frac{x^{\prime2}+y^{\prime2}}{2z}+\frac{x^{2}+y^{2}}{2z}-\frac{xx^{\prime}+yy^{\prime}}{z}+\cdots\\=r_{0}+\frac{x^{2}+y^{2}}{2z}-\frac{xx^{\prime}+yy^{\prime}}{z}\\=r_{0}^{\prime}+\frac{x^{\prime2}+y^{\prime2}}{2z}-\frac{xx^{\prime}+yy^{\prime}}{z}\end{aligned} $$ 

(i)  $ (x,y),(x',y') $ satisfy paraxial condition:

 $$ x^{2},y^{2},x^{\prime2},y^{\prime2}\ll z^{2} $$ 

 $$ \frac{a}{r}\approx\frac{a}{z} $$ 

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z}e^{ikr}=\frac{a}{z}e^{ik(r_{0}+\frac{x^{2}+y^{2}}{2z})}e^{-ik\frac{xx^{\prime}+yy^{\prime}}{z}}=\frac{a}{z}e^{ik(r_{0}^{\prime}+\frac{x^{\prime2}+y^{\prime2}}{2z})}e^{-ik\frac{xx^{\prime}+yy^{\prime}}{z}} $$ 

(ii)  $ (x',y') $ satisfy paraxial,  $ (x,y) $ satisfy both paraxial and far-field condition

i.e.

 $$ x^{2},y^{2},x^{\prime2},y^{\prime2}\ll z^{2}\quad and\quad z\gg\frac{x^{2}}{\lambda},\frac{y^{2}}{\lambda} $$ 

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z}e^{ikr_{0}}e^{-\frac{ik}{z}(xx^{\prime}+yy^{\prime})} $$ 

If  $ (x,y) $ satisfy paraxial ,  $ (x',y') $ satisfy both paraxial and far-field.

 $$ E(x^{\prime},y^{\prime})=\frac{a}{z}e^{ikr_{0}^{\prime}}e^{-\frac{ik}{z}(xx^{\prime}+yy^{\prime})} $$ 

(5-22) is in form of plane wave, whose k is not normal to the  $ (x,y),(x',y') $ plane (or parallel to z)

 $$ k_{_{x}}=k\cos\alpha^{\prime}=-\frac{kx}{z};\quad k_{_{y}}=k\cos\beta^{\prime}=-\frac{ky}{z} $$ 

It is a plane wave along  $ r_{0} $

The  $ e^{-\frac{ik}{z}(xx' + yy')} $ phase term would be important when we come to Fourier Optics, we shall see there the  $ (x, y), (x', y') $ forms a Fourier Transform.

(2) Solving Young’s Experiment with Wavefront Distribution

 $$ S_{1}\quad(\frac{d}{2},0);\quad S_{2}\quad(-\frac{d}{2},0);\quad z=D\quad and\quad d^{2}\ll D^{2},\quad\rho^{2}=x^{\prime2}+y^{\prime2}\ll D^{2} $$ 

Both the source and receiving field plane satisfy paraxial condition.

 $$ E_{1}(x^{\prime},y^{\prime})=\frac{a}{D}\exp[ik(\cdots)]\exp(-\frac{ik}{D}\frac{d}{2}x^{\prime}) $$ 

 $$ E_{2}(x^{\prime},y^{\prime})=\frac{a}{D}\exp[ik(\cdots)]\exp(\frac{ik}{D}\frac{d}{2}x^{\prime}) $$ 

 $$ E(x^{\prime},y^{\prime})=\frac{a}{D}\exp[ik(\cdots)]2\cos(\frac{kd}{2D}x^{\prime}) $$ 

 $$ I(x^{\prime},y^{\prime})=4A^{2}\cos^{2}(\frac{k d}{2D}x^{\prime}),A=\frac{a}{D} $$ 

Same as we derived earlier, the result in (5-19).

The derivation also shows that under paraxial approximation, the I(x',y') only depends on x', i.e. the interference pattern are lines along y direction, which confirms what we stated earlier that under paraxial conditions, the hyperbolic curves in the two-point sources interference pattern  $ \sim $ straight lines.

(3) The interference pattern by two plane waves

<div style="text-align: center;"><img src="imgs/img_in_image_box_261_1242_562_1501.jpg" alt="Image" width="25%" /></div>


This is left for the student to read themselves and derive the result yourself (Zhao's, P177-179)

## 5 -4 Amplitude Splitting Interferometer--Interference by Thin film

<div style="text-align: center;"><img src="imgs/img_in_image_box_231_537_828_918.jpg" alt="Image" width="50%" /></div>


<div style="text-align: center;">O is a point light source emitting single (or nearly single) frequency light. There will be top and bottom reflection from the two surfaces of the thin film, the reflection light can meet at certain point P and under right conditions, there will be interference at P. The top and bottom reflection by surfaces can be treated as coming from two point sources  $ O_{A}^{\prime}, O_{B}^{\prime} $  $ O_{A}^{\prime} $ : is the mirror image of O formed by surface A.  $ O_{B}^{\prime} $ : is it the mirror image of O by surface B?</div>


The answer is no for  $ O'_{B} $. The interference is between beams reflected

of the top and bottom surface. For beam2 from bottom reflection, it

actually (1) refracted at surface A ( $ T_{A}' $); (2) Reflected by surface B( $ R_{B} $);

(3) transmitted by surface A(T_A'). The final virtual object (source) O_B' is actually: O→O'_At (image of O by refracting surface A)→O_B.

(Reflecting or mirror image by surface B)→O'_B (the image of OB2 by refracting surface A).

(1) Neglecting the multiple reflecting by the two surfaces A.B, which is true at R<<1. At P, it is essentially a double beam interference, or interference by two point sources, OA'OB'.

(2) The interference field by OA', OB' extends all over the space. For arbitrary point in space, P, there will be interference due to

 $$ I(p)=I_{1}^{2}+I_{2}^{2}+2\sqrt{I_{1}I_{2}}\cos\delta(p) $$ 

$$\delta(p)=k(\overline{Q'}_{A}P-\overline{Q'}_{B}P)\pm\pi\ (this\pm\pi\ \text{term will depend on whether there\ is\ half-\lambda\ difference\ between\ beam\ 1,2).)$$

The interference pattern is equivalent to those generated by two point sources as we discussed before, the maxims and minims are rotating hyperbola curves.

Here in the interference by thin film, we take a look for two special region of the total interference field.

<div style="text-align: center;"><img src="imgs/img_in_image_box_751_1217_904_1369.jpg" alt="Image" width="12%" /></div>


① Interference at the top surface of the film.

② Interference pattern at infinity.(interference pattern created by parallel

<div style="text-align: center;"><img src="imgs/img_in_image_box_285_155_488_370.jpg" alt="Image" width="17%" /></div>


beams) A.

To observe the interference pattern, we can use optical elements to make image formation of the interference pattern as the figures above shown. Since the equal optical path length for all the rays between object-image (Fermat's principle), the image formation process will not introduce any extra phase difference, and the image pattern would be a (magnified or shrink) copy of the same interference pattern.

## 5 -4-1 Fringes of Equal Thickness

This is the interference pattern on the surface of a thin film.

<div style="text-align: center;"><img src="imgs/img_in_image_box_310_1041_705_1278.jpg" alt="Image" width="33%" /></div>


 $ \delta(p) $ is the phase difference at point p on the surface created by two beams. (or beams from  $ Q'_{A}, Q'_{B} $, the image of Q):

 $$ \delta(p)=k_{0}\Delta L(p)\quad\left(\pm\pi\quad if\quad\begin{array}{c}n_{1}>n<n_{2}\\ n_{1}<n>n_{2}\end{array}\right) $$ 

 $$ \Delta L(p)=(Q A)+(A B P)-(Q P). $$ 

The key to the intensity distribution is the phase relation. For thin film, easy to derive: (I bet you can do this geometric problem)

 $$ \Delta L(p)=2nh\cos i\quad(5-23) $$ 

 $$ \begin{aligned}&\therefore\begin{cases}\Delta L=m\lambda_{0(vacuumwavwlength)},or,h=\frac{m\lambda_{0}}{2n\cos i}&\max(or\min)\\\Delta L=(m+1/2)\lambda_{0},or,h=\frac{(m+1/2)\lambda_{0}}{2n\cos i}&\min(or\max)\end{cases}\leftarrow\binom{n_{1}>n<n_{2}}{n_{1}<n>n_{2}}\end{aligned} $$ 

Thus, there are some straightforward conclusions we draw from (5-23)

① Whether the point on surface is maximum or minimum depends on whether there is half-wavelength difference between the reflected beams.

② At constant angle i,  $ \Delta L $ only depends on thickness h. A special case is when i=0:  $ \Delta L = 2nh $; or define  $ \Delta h = h_{m+1} - h_{m} $ (The height diff. between adjacent max. and min.), for a wedge shaped thin film:

 $$ \Delta h=\lambda_{0}/2n=\Delta x\alpha\quad(5-24) $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_237_947_935_1169.jpg" alt="Image" width="58%" /></div>


Generally as $i$ (angle) fixed, the max. or min. of interference which depends on $\Delta L$ will be contour of equal thickness. This could be used to check the relative flatness of surface down to the precision on the order of $\lambda_0$.

③ Movement of the fringes vs. change of thickness.

This is related to precision measurement of motion using change of

interference pattern:

<div style="text-align: center;"><img src="imgs/img_in_image_box_184_221_838_507.jpg" alt="Image" width="54%" /></div>


 $$ h_{m}=\frac{m\lambda_{0}}{2n} $$ 

 $ \Delta h \nearrow $ fringes moves toward the intersection

 $ \Delta h \searrow $ fringes moves away from the intersection.

For a fixed point in space, say  $ X_{0} $ in the above figure, as  $ \Delta h $ changes by every  $ \frac{\lambda_{0}}{2n} $, there will be a maxima (one interference fringe) moves across it. If a photo detector is placed at  $ X_{0} $, and measure the intensity at  $ X_{0} $; by counting the number of fringes passing through it, while there is a change of h, one can calculate  $ \Delta h $

Example: a change in height by  $ \Delta h $, the detector at  $ X_0 $, records a signal as:

<div style="text-align: center;"><img src="imgs/img_in_image_box_203_1122_743_1288.jpg" alt="Image" width="45%" /></div>


 $$ \Delta h=\frac{\lambda_{0}}{2n}\times3 $$ 

④ Newton Rings (please read it by yourself Hecht’s pg. 406 or Zhao’s pg291-293)

## 5 -4-2 Fringes of equal inclination

Such interference is when we observe it at infinite distance from the film. Basically this is interference by two parallel beams, which can be collected by a lens on its back focal plane.

<div style="text-align: center;"><img src="imgs/img_in_image_box_177_426_472_697.jpg" alt="Image" width="24%" /></div>


 $$ \Delta L=(ARC)-(AB)=2nh\cos i $$ 

For the simple case where h is constant, the interference pattern will only depend on the angle i, the fringes on the focal plane  $ \Sigma $ would be concentric circles.

<div style="text-align: center;"><img src="imgs/img_in_image_box_194_960_679_1509.jpg" alt="Image" width="40%" /></div>


① m the fringe (max. or min. depending on  $ \lambda/2 $ difference)

 $$ 2nh\cos i_{m}=m\lambda_{0}\rightarrow\cos i_{m}=\frac{m\lambda_{0}}{2nh} $$ 

For $i=0$, corresponds to the highest m, $m_{\max}=\frac{2nh}{\lambda_{0}}$ larger m, smaller $i_{m}$.

② spacing between the circles.

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_529_505_784.jpg" alt="Image" width="20%" /></div>


 $ r_m = f \cdot \tan i_m \approx f_i_m $ For small  $ i_m $

 $$ \begin{aligned}&\therefore\Delta r_{m}=r_{m+1}-r_{m}=f\left(i_{m+1}-i_{m}\right)\\&\because\cos i_{m+1}^{\prime}-\cos i_{m}^{\prime}=\frac{\lambda_{0}}{2nh}\\&\approx(\frac{d\cos i}{di})_{i_{m}^{\prime}}(i_{m+1}^{\prime}-i_{m}^{\prime})=-\sin i_{m}^{\prime}(i_{m+1}^{\prime}-i_{m}^{\prime})\end{aligned} $$ 

i' is the angle in the film, i is the angle in the air, they are related by Snell's Law. i ≈ ni' for small I, and using the angle I, we express spacing between interference patterns:

 $$ \therefore\Delta r_{m}=nf(\frac{-\lambda_{0}}{2h\sin i_{m}}) $$ 

This shows the larger $h$, the smaller spacing between the fringes, and the larger $i_{m}$, and the smaller spacing. (The outer circles, or fringes

with small m are closely spaced)

③ fringes change vs. change in thickness h

The center  $ (i_m = 0) $ corresponds to the highest order of m.  $ m = \frac{2nh}{\lambda_0} $

As h increase by  $ \frac{\lambda_0}{2n} $, m increases by 1, and the order of fringe will

change from

\[\begin{array}{c c c c c}{{{\dot{m}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-1}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-2}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-1}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-2}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-3}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-4}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-5}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-6}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-7}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-8}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m-9}}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-1}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-2}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-3}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-4}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-5}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-6}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-7}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-8}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-9}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-10}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-11}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-12}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-13}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-14}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-15}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-16}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-17}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-18}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-19}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-20}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-21}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-22}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-23}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-24}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-25}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-26}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-27}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-28}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-29}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-30}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-31}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-32}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-33}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-34}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-35}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-36}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-37}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-38}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-39}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-40}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-41}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-42}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-43}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-44}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-45}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-46}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-47}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-48}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-49}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-50}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-51}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-52}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-53}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-54}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-55}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-56}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-57}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-58}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-59}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-60}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-61}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-62}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-63}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-64}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-65}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-66}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-67}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-68}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-69}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-70}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-71}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-72}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-73}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-74}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-75}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-76}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-77}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-78}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-79}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-80}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-81}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-82}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-83}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\qquad}}} \\{{{\dot{m}-84}}}&{{{\left(\begin{array}{c}\end{array}\right)}}}&{{{\cdots}}}&{{{\qquad}}}&{{{\qquad}}}&{{{\

Thus a new fringe is created from the center. As we have discussed in the case of equal thickness. The change of number of fringes can be used to determine the change of h.

## 5 -4-3 Michelson Interferometer

The Michelson Interferometer is essentially a two-beam interferometer. It records the interference pattern of the two beams reflected by two mirrors. It is one of the most well-known and widely used interferometers.

<div style="text-align: center;"><img src="imgs/img_in_image_box_265_153_895_559.jpg" alt="Image" width="52%" /></div>


Compensator: ① Negate the effect of dispersion

② Optical path difference arises from the actual path difference, or other optical path varying device.

A conceptual rearrangement of M-interferometer (shown in the equal inclination configuration):

<div style="text-align: center;"><img src="imgs/img_in_image_box_174_900_1062_1408.jpg" alt="Image" width="74%" /></div>


The interference patterns are equivalent to those generated by thin film of space between M1, M2' (M2' is the mirror image of M2 by the beam

splitter).

The optical path difference for observing either equal thickness pattern or equal inclination:  $ \Delta L_{12} \approx 2d \cos \theta $.

Due to the half-wavelength difference existed between beam1, 2(one is internal, the other is external reflection by the splitter)

 $$ \begin{aligned}\rightarrow\Delta L&=m\lambda_{0}\rightarrow fringes of darkness(minima)\\&=(m+1/2)\lambda_{0}\rightarrow\text{bright fringes(maxima)}\end{aligned} $$ 

The relative distance and orientation between M1 and M2 can be precisely adjusted (i.e. we can control the thickness and wedge angle of the thin film), if both d, θ are varying the resultant interference pattern would be complicated. For simplicity, we shall restrict to the fringes of equal inclination for constant d, and fringes of equal thickness for constant θ.

But we have already discussed above situations, they are the equal thickness pattern formed by wedged spacing M1,M2,or equal inclination pattern formed by parallel M1,M2 , and nothing new here.

Thus, the patterns showed in fig4-3,4-4 in Zhao’s book,pg312 for various M1,M2’ arrangement. It is quite self-evident and need little further explanation. It can be used as an example to illustrate the equal-thickness, inclination patterns discussed earlier (the case f and j where for the large spacing between mirrors, there is lack of interference. This is happens because the optical path length difference is larger than

coherence length in those cases, we shall discuss coherence length in detail later)

<div style="text-align: center;"><img src="imgs/img_in_image_box_201_286_879_625.jpg" alt="Image" width="56%" /></div>


<div style="text-align: center;">图 4-3 迈克耳孙干涉仪产生的各种干涉条纹</div>


<div style="text-align: center;">(a)</div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;">(c)</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_212_675_838_975.jpg" alt="Image" width="52%" /></div>


<div style="text-align: center;">(2) Application of Michelson-interferometer.</div>


<div style="text-align: center;">Precise length measurement——down to fraction of  $ \lambda_{0} $</div>


The principle is same as we already discussed. As the mirror moves by  $ \lambda_{0}/2 $ (here n=1), there will be a fringe shift, i.e. each fringe will move to the position previously occupied by the adjacent fringe. One only need to count the number of such fringe movement, say N of it move across the observing position, the counting usually is achieved by a photo-electric detector.

Then  $ \Delta d = N \left( \frac{\lambda_{0}}{2} \right) $ (5-28)

 $ \Delta d $ is the optical path length difference. It can be either real change of the mirror's position, or it can be variation of index of refraction. Thus, the Michelson-Interferometer offers an accurate method to measure the n, index of refraction of some transparent materials, and it can be used in other related ways, such as monitoring the gas density by the change of n.

Example: Wavelength meters ---determination of the wavelength. A commercial wave meter, such as those made by Burleigh Inc. is essentially a Michelson-Interferometer.

 $$ \begin{array}{r l}{\mathrm{A s}}&{{}\Delta d=N(\frac{\lambda_{0}}{2})}\end{array} $$ 

It seems if we change  $ \Delta d $ by a precise amount and count N correctly, we shall be able to get  $ \lambda_{0} $. However, the very precise control of  $ \Delta d $ is not easy (Though now days, step-motor with nm precision becomes available but very expensive).

The measurement of  $ \lambda_{0} $ by a wavelength meter is achieved with the help of another stable light source, a He-Ne laser is stabilized at a fixed temperature, whose wavelength  $ \lambda^{r_{0}} $ is known. The light of reference He-Ne and unknown wavelength light are fed into a Michelson-Interferometer, each will generate an interference pattern of its own. Scan a mirror, say M, by  $ \Delta d $, there would be fringes

change in the patterns.  $ \Delta d = N\left(\frac{\lambda_0}{2}\right) = Nr\left(\frac{\lambda_0^r}{2}\right) $  $ \frac{\lambda_0}{\lambda_0^r} = \frac{Nr}{N} $

A wavelength meter consisting of Michelson-Interferometer with one scanning arm, a stable reference laser source and the electronic counting circuit, the measurement accuracy can be  $ \frac{\Delta\lambda}{\lambda} \sim 10^{-6} $

## 5 -5 Multiple Beam interference and Fabry-Perot interferometer

---effect of narrowing in distribution of energy

In the previous study of amplitude-splitting device, we only consider the double beam because the higher order reflection is negligible due to the low reflection by the surface. Here we are going to treat the interference generated by multiple reflections by two high reflecting surfaces, when the r (the reflection coefficient) is large.

First look a puzzle:

<div style="text-align: center;"><img src="imgs/img_in_image_box_213_1140_880_1403.jpg" alt="Image" width="56%" /></div>


 $$ \begin{array}{l} R=r^{2} = 99\% \quad R=99\% \\ T=t^{2}=1\% \quad T=1\% \end{array} $$ 

We shall see that the transmitted light can reach  $ I_{0} $ under ideal condition, contrary to the  $ (1\%)^{2}I_{0} $ as intuition tells.

<div style="text-align: center;"><img src="imgs/img_in_image_box_253_148_588_407.jpg" alt="Image" width="28%" /></div>


 $$ n_{1}=n_{2} $$ 

With  $ n_{1}=n_{2} $, and we have Stokes Relation.

 $$ r=-r^{\prime},r^{2}+tt^{\prime}=1 $$ 

 $$ \begin{aligned}&Reflection\begin{cases}\\ &A_{1}=A r\\&A_{2}=A tr^{\prime}t^{\prime}\\&A_{3}=A tr^{\prime3}t^{\prime}\\&\vdots\\ &\end{cases}\quad&Transmitted\quad&\begin{cases}\\ &A_{1}^{\prime}=A t t^{\prime}\\&A_{2}^{\prime}=A tr^{\prime}r^{\prime}t^{\prime}=A t t^{\prime}r^{\prime2}\\&A_{3}^{\prime}=A t t^{\prime}r^{\prime4}\\ &\end{cases}\\ \end{aligned} $$ 

The amplitude distribution for Reflected and Transmitted light are given above.

The Optical path length difference between adjacent beams:

 $$ \Delta L=2n h\cos i, $$ 

 $$ \delta=k_{0}\Delta L=\frac{4\pi nh\cos i}{\lambda_{0}} $$ 

The complex amplitude of wave is: (neglect the common factor, such as  $ e^{-i\omega t} $)

 $$ R\left\{\begin{aligned}\tilde{U}_{1}=-A r^{\prime}\\ \tilde{U}_{2}=A t t^{\prime}r^{\prime}e^{i\delta}\\ \tilde{U}_{3}=A t t^{\prime}r^{\prime}e^{2i\delta}\end{aligned}\right.\qquad T\left\{\begin{aligned}\tilde{U}_{1}^{\prime}=A t t^{\prime}\\ \tilde{U}_{2}^{\prime}=A t t^{\prime}r^{\prime2}e^{i\delta}\\ \tilde{U}_{3}^{\prime}=A t t^{\prime}r^{\prime4}e^{i2\delta}\end{aligned}\right. $$ 

We shall treat the Transmission first and the intensity of Reflection can be derived from conservation of energy.

 $$ I_{R}+I_{T}=I_{0} $$ 

 $$ \tilde{U}_{_{T}}=\sum_{i}U_{_{i^{\prime}}}=A t t^{\prime}(1+r^{2}e^{i\delta}+r^{4}e^{2i\delta}\cdots\cdots)=\frac{A t t^{\prime}}{1-r^{2}e^{i\delta}} $$ 

 $$ I_{_{T}}=\tilde{U}_{_{T}}U_{_{T}}^{*}=\frac{A^{2}(t t^{\prime})^{2}}{(1-r^{2}e^{i\delta})(1-r^{2}e^{-i\delta})}=\frac{I_{_{0}}(1-r^{2})^{2}}{1+r^{4}-2r^{2}\cos\delta}=I_{_{0}}\left[\frac{1}{1+\frac{4R\sin^{2}\delta/2}{(1-R)^{2}}}\right] $$ 

 $$ R\equiv r^{2} $$ 

Define coefficient of Finesse:  $  F \equiv \frac{4R}{(1 - R)^2}  $ (5-31)

 $$ I_{_{T}}=I_{_{0}}\left/\left(1+F\sin^{2}\delta\right.\right/2) $$ 

 $$ I_{_{R}}=I_{_{0}}-I_{_{T}}=I_{_{0}}\left/\left(1+\frac{1}{F\sin^{2}\frac{\delta_{_{2}}}{}}\right)\right. $$ 

As R<<1, F≈4R and  $ I_{T}=I_{0}\left[1-2R(1-\cos\delta)\right] $,  $ I_{R}=2I_{0}R(1-\cos\delta) $,

exactly the intensity distribution for a double beam Interference

 $ (I=I_{0}(1+\gamma\cos\delta)) $ which is a limiting case.

From（5-30） and (5-32), it is easy to see that:

For $I_T$, it's maximum at $\sin\delta/2=0$, or $\delta=2m\pi$, or $\Delta L=2n h\cos i=m\lambda_0$. This is when all the transmitted waves are exactly in phase, and constructively superposed together.

For the  $ I_R $, the same condition  $ \sin \delta/2 = 0 \rightarrow I_R = 0 $ This is when all the reflected waves are all in phase, except  $ \text{ONE---} $ the first reflected beam. (This arises from the half-wavelength difference between reflected beam by top and bottom surface, as expressed by stokes relation  $ r = -r' $ also refers to Fig9.38, Hecht). The reflected beam is out of phase with

the rest of the reflection, and cancel with others. This is the answer for the question raised at the beginning of this section. It is possible under ideal situation $ ^{6} $ that light 100% pass and at meantime no reflection.

As R (or r, or F) increase, there are more beams taken part in the interference. The interference fringe  $ (I_{T}, or, I_{R} $ vs.  $ \delta $, the phase difference) sharpens, or in other words, the energy tends to concentrate in smaller phase space as interfering beams increase:

<div style="text-align: center;"><img src="imgs/img_in_chart_box_222_602_847_982.jpg" alt="Image" width="52%" /></div>


This is a general character of interference by multiple sources. You may try to use phasor method to see this point (say 10000 phasor, with a small difference in phase angle (say  $ \frac{2\pi}{10000} $)  $ \underline{\text{between adjacent pair}} $, these ten-thousand components will add up to zero). One analogy with daily life experience is working with peoples: It is relatively easy to make two people to do the same thing, say push something in one direction at same time (constructive); it is much harder to do the same with thousands of

people. A slight change of the environment (breeze of wind, beautiful

lady passing by...) will cause significant disturbance and may destroy

constructiveness, so the constructive condition for multi-party is more

sensitive to the parameters.

## 5 -5-1 Fabry-Perot Interferometer

Here is a device applying the multi-beam interference discussed above. The Fabry_Perot (FP) interferometer is essentially a pair of flat (very flat indeed) plate, parallel with each other with spacing h. If the spacing h is fixed, it is called “etalon”, and is widely used in lasers as wavelength narrowing device. If h is scanned over a range, it is called Fabry-Perot interferometer or spectrometer.

<div style="text-align: center;"><img src="imgs/img_in_image_box_238_956_553_1156.jpg" alt="Image" width="26%" /></div>


The flatness of the plate is on the order of  $ \frac{\lambda}{100} $ (to let more beams into interference, the random up-down on the surface can destroy the interference by introducing random OPL)

The most important parameters for F-P is its  $ F $ (or equivalently R) and h, the Finesse coefficient and spacing. As we already see that the F

determines the number of beams taking part in interference, thus affecting the energy distribution in phase space; the h determines the condition of constructive interference, thus the peaks' position in the phase space.

(1) Full Width at Half Maxima (FWHW) in phase space

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_407_727_661.jpg" alt="Image" width="40%" /></div>


As derived in the Zhao’s Book, pg337 or Hecht’s 9.6.1, pg423:

 $$ \varepsilon=\frac{2(1-R)}{\sqrt{R}}=4\bigg/\sqrt{F} $$ 

Define finesse  $ \varphi $

 $$ \wp\equiv\frac{\Delta\delta}{\varepsilon}=\frac{2\pi}{\varepsilon}=\pi\sqrt{F}\Big/2 $$ 

φ is the ratio between spacing of peaks and the width of individual peak, it is closely related to the resolution of the instrument. The larger φ means narrower ε or large Δδ, the peaks are well resolved in phase space. However, these are in terms of δ, the phase, we need to translate it in measurable parameters, such as h, λ, angle i... These are related with δ by (5-30),  $ \delta = \frac{4\pi nh\cos i}{\lambda_0} $

(2) Etalon

The h is fixed for an etalon, for single freq. light input, the transmitted

interference pattern would be like that of equal-inclination---concentric rings. Different freq. light corresponds to rings at different angles. Here we are considering the case that the incident angle is fixed, say i=0, normal incidence, and let the incoming light have a broad frequency distribution.

We shall see that the etalon acts as a freq. selector (filter), only certain frequencies can pass etalon.

<div style="text-align: center;"><img src="imgs/img_in_image_box_329_613_732_718.jpg" alt="Image" width="33%" /></div>


The transmitted peaks (i=0) occur at  $ \delta_{m}=2m\pi $

 $$ \mathrm{Or}\quad\lambda_{_{m}}=\frac{2nh}{m}\quad\mathrm{or}\quad\upsilon_{_{m}}=\frac{c}{\lambda_{_{m}}}=\frac{mc}{2nh} $$ 

So the output would be a group of equally spaced lines in frequency domain, with free spectral range defined as:

 $$ \Delta v=v_{_{m+1}}-v_{_{m}}=\frac{c}{2nh} $$ 

Which is the spacing between peaks corresponds to adjacent order of interference.

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_1245_737_1443.jpg" alt="Image" width="42%" /></div>


<div style="text-align: center;">Evaluate dv, the FWHM of line in v domain:</div>


 $$ \delta=4\pi n h/\lambda\qquad d\delta=-\frac{4\pi n h}{\lambda^{2}}d\lambda_{m} $$ 

 $$  At FWHM,\ d\delta=\varepsilon=\frac{4}{\sqrt{F}}\rightarrow d\lambda_{m}=\frac{-\lambda^{2}\varepsilon}{4\pi nh}=\frac{-2\lambda^{2}}{\pi m\lambda\sqrt{F}}=\frac{-\lambda}{\wp m} $$ 

 $$ d\upsilon_{m}=-\frac{c}{\lambda^{2}}d\lambda_{m}=\frac{c}{\wp m\lambda} $$ 

I used  $ \upsilon = \frac{c}{\lambda} \rightarrow d\upsilon = -\frac{c}{\lambda^2} d\lambda $ to get frequency interval from wavelength interval.

 $$ \mathrm{Then}\frac{Free\_{S}pectral\_{R}ange}{FWHM}=\frac{(5-37)}{(5-38)}=\wp\quad(\mathrm{using}\ 2nh=m\lambda_{m}) $$ 

There is no surprise here, recall the definition of  $ \phi $ in phase space,

the above procedure is same but carried now in frequency domain.

## (3) F-P interferometer or spectrometer

In this case, the h is not fixed but scanning, i.e. changes in a range, moving forward backward periodically. This is achieved by mounting one of the mirrors on a piezo driven by some voltage.

<div style="text-align: center;"><img src="imgs/img_in_image_box_247_1123_976_1347.jpg" alt="Image" width="61%" /></div>


If the light from source S is monochromatic, then there are only for certain values of h that the light can pass the F-P and be detected.

<div style="text-align: center;"><img src="imgs/img_in_image_box_282_151_834_601.jpg" alt="Image" width="46%" /></div>


The FWHM of the output line can be derived:

 $$ d\delta=\frac{4\pi n}{\lambda}dh=\varepsilon=\frac{4}{\sqrt{F}}\quad d h=\frac{\lambda}{2n\wp} $$ 

Now, let's consider the light from source S has various frequency components. As the F-P scanning, different frequency components will pass F-P at different h.

<div style="text-align: center;"><img src="imgs/img_in_image_box_245_955_754_1287.jpg" alt="Image" width="42%" /></div>


 $$ h_{_{m}}=\frac{m\lambda}{2n},h_{_{m}}^{\prime}=\frac{m\lambda^{\prime}}{2n}\qquad\delta\lambda=\lambda^{\prime}-\lambda=\frac{2n\delta h_{_{m}}}{m} $$ 

The $\lambda,\lambda'$ can be resolved if the $\delta h$ caused by $\delta\lambda$ equals or larger ($\geq$) than the FWHM of the single line, this is the Rayleigh criteria.

Replace  $ dh_{m} $ for  $ \delta h_{m} $, We have the minimum resolvable wave

length bandwidth:

 $$ \delta\lambda=\frac{\lambda}{m\phi} $$ 

The resolving power is defined as:

 $$ R\equiv\frac{\lambda}{\delta\lambda}=m\wp $$ 

## 5 -6 Coherent Theory

(Hecht, Chap 12 Zhao’s chap3 §1 §4 pg272-281; pg315-328)

We have discussed the “ideal” case for various interference devices.

The “ideal” is referring to:

(1) Point Source

(2) Monochromatic light (Single frequency)

Such conditions as we already mentioned and shall further discuss, lead to complete coherence.

Now we are starting to investigate the more realistic situations, involving

① Extended source → Spatial coherence

② Non-monochromatic light → Temporal coherence

For a conventional extended sources (“conventional” is in contrast to coherent sources as laser)

O1 ● (1) Each point emits light incoherently i.e. no

O2 ● fixed phase relationship between light from

O3 ● O1,O2.....

(2) The light emitted by each point is not monochromatic, i.e. there is a frequency distribution.

Generally, such extended sources will lead to a decrease in the contrast in interference pattern. This gives rise to what we shall study: a Partial Coherence (a reduced coherence).

As we already learned from interference of two sources:

 $$ \begin{aligned}&I=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}\cos\delta=(I_{1}+I_{2})(1+\gamma\cos\delta)\\ &\gamma=\frac{I_{\max}-I_{\min}}{I_{\max}+I_{\min}}\\ \end{aligned} $$ 

As we mentioned before, that even for a complete coherent source,  $ \gamma $ depends on  $ I_{1} $ and  $ I_{2} $, it could be small if  $ I_{1} \ll I_{2} $

<div style="text-align: center;"><img src="imgs/img_in_image_box_186_960_496_1132.jpg" alt="Image" width="26%" /></div>


 $$ \left.\begin{array}{r l}{\gamma=1}&{{~I_{1}=I_{2}~}}\\ {\gamma\rightarrow0}&{{~I_{1}<<I_{2}~}}\end{array}\right\}{f o r\_{c}oherent\_{s}ources} $$ 

To avoid confusion, or to separate the reduction of  $ \gamma $ by intensity difference of the complete coherent sources, with the reduction of  $ \gamma $ due to partial coherent sources, we shall assume  $ I_{1}=I_{2} $ in our following discussion, so that the decrease of  $ \gamma $ from 1 will be completely caused by the lack of coherence of the sources.

If  $ I_{1}=I_{2} $, then the  $ \gamma $ of interference pattern shows:

 $ \left\{\begin{array}{ll}\gamma=1 & \text{complete\_coherent\_source} \\ 0<\gamma<1 & \text{partial\_coherent} \\ \gamma=0 & \text{incoherent}\end{array}\right. $

5-6-1 Extended Monochromatic Source and Spatial Coherence

<div style="text-align: center;"><img src="imgs/img_in_image_box_178_505_547_908.jpg" alt="Image" width="31%" /></div>


 $ \Delta x_{a,b}(spacing\ bet\ max\ in\ pattern\ a\ or\ b)=\frac{D}{d}\lambda $

 $$ I_{_{a}}=I_{_{0}}(1+\cos2\pi f x) $$ 

where  $ f = \frac{1}{\Delta x} $

 $ I_{0}=I_{1}+I_{2} $

intensity on screen by s1,s2

For the off-axis source  $ O_{b} $, if s is small, the interference pattern originating from it would be similar to that of  $ O_{a} $, with same cosine variation, but different center, or basically a shifted fringe, with same spatial frequency(refer to the figure above):

 $$ I_{b}=I_{0}\Big[1+\cos2\pi f(X-X_{0})\Big] $$ 

For Ob, X0 (the position of 0th order maximum, marked by B in the figure)

is the position where the OPL from  $ O_{b} $ through  $ S_{1}, S_{2} $, to  $ X_{0} $ is equal, i.e.:

 $$ \begin{array}{r l}{\overline{{O_{b}S_{1}}}+\overline{{S_{1}B}}=\overline{{O_{b}S_{2}}}+\overline{{S_{2}B}}}\\ {\overline{{O_{b}S_{1}}}-\overline{{O_{b}S_{2}}}=\overline{{S_{2}B}}-\overline{{S_{1}B}}}\end{array}\qquad\mathrm{(\Delta L=0=0\lambda)}\quad\mathrm{~B~i s~p o s i t i o n~o f~t h e~0^{t h}~o r d e r} $$ 

fringe.

For s and  $ X_{0} \ll d $, it can be simplified to:

 $$ \begin{aligned}&d\frac{S}{R}=\frac{dX_{0}}{D}(s,X_{0}<<d)\\&X_{0}=\frac{D}{R}S\\ \end{aligned} $$ 

For an extended sources with width b,  $ [or \operatorname{S}(-\frac{b}{2},\frac{b}{2})] $ then the total intensity on the screen would be  $ I = \sum_{i} I_i \Delta s = \int I(s) ds $, the  $ I_i $ or  $ I_s $ is the intensity contribution per unit length from source s.

● Here we take a direct summation of individual intensity component and this may cause alarm. Recall that we had stressed that the principle of superposition is the summation of field, not the intensity (or irradiance). We can sum intensity directly here is because there is no coherence between points  $ O_{a}, O_{b} $ ..... so: overall pattern(intensity) generated by these incoherent points is:

 $$ I(x)=I_{0}\int\limits_{-\frac{b}{2}}^{\frac{b}{2}}[1+\cos2\pi f(x-\frac{D}{R}s)]ds=bI_{0}[1+\frac{\sin(\frac{\pi bd}{R\lambda})}{\pi db/R\lambda}\cos2\pi fx] $$ 

Clearly (see equation 5-41) then:

 $$ \gamma=\left|\frac{\sin\mu}{\mu}\right|\quad when\quad\mu=\frac{\pi b d}{R\lambda} $$ 

<div style="text-align: center;"><img src="imgs/img_in_chart_box_188_151_562_374.jpg" alt="Image" width="31%" /></div>


The function of  $ \gamma $ is not strange to us. We have come across to similar functions dealing with wave packet, group velocity, where superposition of waves with a frequency distribution→wave packet. The math in both cases are same, essentially a Fourier Transform of square function. Clearly, as

 $$ \mu=\frac{\pi b d}{R\lambda}=\pi{~o r~}b=\frac{R\lambda}{d}\qquad(5-45)\qquad then\gamma=0 $$ 

Though as  $ \mu > \pi, \gamma $ is non-zero (there is still some up-downs beyond  $ \pi $) but will be negligible. Then if the source length  $ b > \frac{R\lambda}{d} $. the contrast of the interference pattern  $ \gamma \to 0 $, i.e. the secondary wave sources  $ S_1, S_2 $ will be incoherent.

Relation (5-45) can be rearranged to:  $ d = \frac{R}{b} \lambda $ (5-46)

This is for a fixed extended source b, at distance R from it, if the two secondary sources are separated by  $ d > \frac{R}{b}\lambda $, they are incoherent (i.e. you cannot put double slit there and expect to see interference):

Let  $ \frac{d}{R} = \Delta \theta_0 \rightarrow b \Delta \theta_0 = \lambda $

<div style="text-align: center;">(5-47)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_612_157_774_267.jpg" alt="Image" width="13%" /></div>


So if the  $ \Delta\theta $ is the angle spanned by  $ S_{1} $,  $ S_{2} $ with the center of source with extension b. The spatial coherent condition for  $ S_{1}, S_{2} $ is:  $ \Delta\theta < \Delta\theta_{0} $

This explains why using sunlight directly to illuminate the two slit in Young’s Experiment fails to observe interference pattern; it also explains the decrease of  $ \gamma $ in equal thickness fringes using extended sources (P306, Zhao’s). An example of application is Michelson stellar interferometer. (P280, Zhao’s; 12.4.1 in Hecht)

Once again: Spatial coherence is caused by the size of incoherent source.

5-6-2 Effect of Non-Monochromatic Light---Temporal Coherence

<div style="text-align: center;"><img src="imgs/img_in_image_box_178_1018_737_1499.jpg" alt="Image" width="46%" /></div>


O is a point source with frequency distribution (for simplicity, it is a distribution with square function). For each frequency component, it has equal intensity, i.e.  $ i_{0}(k) = I_{0} / \Delta k $

 $ i_{0} $ is the intensity density (per unit wavelength interval or frequency interval),  $ I_{1} $,  $ I_{2} $ is the intensity by  $ S_{1} $,  $ S_{2} $ to a point on observing screen. The interference pattern on the observing screen caused by component with wave vector k is:

 $$ i_{k}(\Delta L)=(I_{1}+I_{2})(1+\cos k\Delta L) $$ 

The total intensity from all frequency (or wavelength) components will be a superposition of such i(k)s, since we neglect the coherence between sources with different frequency. The summation would be exactly same as we treated earlier in spatial coherence cases,

 $$ \begin{aligned}I(\triangle L)&=\int_{0}^{\infty}i(k)dk\\&=\int_{k_{0}-\frac{\triangle k}{2}}^{k_{0}+\frac{\triangle k}{2}}I_{\frac{0}{\triangle k}}(1+\cos k\triangle L)dk\\&=I_{0}[1+\frac{\sin\frac{\triangle k\triangle l}{2}}{\frac{\triangle k\triangle l}{2}}\cos(k\triangle L)]\end{aligned} $$ 

 $$ \gamma=\left|\frac{\sin\mu}{\mu}\right|\qquad\qquad\mu=\frac{\triangle k\triangle L}{2} $$ 

 $$ \begin{aligned}&\gamma=0\quad when\quad\frac{\triangle k\triangle L}{2}=\pi\\&\Delta L_{m}=\frac{2\pi}{\Delta k}=\frac{1}{\Delta(\frac{1}{\lambda})}=\frac{\lambda^{2}}{\left|\Delta\lambda\right|}\\ \end{aligned} $$ 

 $ \Delta L_{m} $ is the maximum difference in OPL.

For  $ \Delta L > \Delta L_m, \gamma \to 0 $ then there will be no interference. This  $ \Delta L_m $ is clearly caused by the non-monochromatic source.

## Coherent time and Coherent length:

To understand the  $ \Delta L_{m} $, (or equivalently the non-zero width in  $ \omega $ or v distribution), we have to look into the microscopic point of view of light emitting by the conventional source.

In short, we can state that the non-zero frequency bandwidth  $ \Delta\omega $ is caused by the limited lifetime of the excited states in atones/molecules. For a conventional light source, the excited atoms/molecules emit light when it transits from an excited state to the ground state. However, the excited state has limited lifetime  $ \tau $. This is the time that the electrons in molecules exist at the excited state, the classical picture is the time that a dipole stays excited and doing oscillation. For the excited dipoles lasting for a lifetime instead of forever, the light emitted will be in forms of wave train (or wave packet) with duration of  $ \tau $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_230_1212_567_1513.jpg" alt="Image" width="28%" /></div>


The excited molecules/atoms radiate such wave-trains, with duration of the lifetime of the excited states. Also the lifetime  $ \tau $ is not a constant, it has certain distribution.

 $$ \begin{array}{c} \leftarrow\tau_{1}\rightarrow\leftarrow\tau_{2}\rightarrow\cdots\cdots\cdots\cdots\rightarrow\\ \cdots\cdots\cdots\cdots\cdots\cdots  \quad \leftarrow\tau_{3}\rightarrow\cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \end{array} $$ 

In the figure,  $ \tau $ the lifetime or the duration of wave train; the frequency  $ \omega $ is given by  $ \Delta E = \hbar \omega $. Different wave train has its duration and very important its own initial phase, where initial phases between different wave trains are unrelated (incoherent). The distribution of the excited state lifetime  $ \tau $ is :

(equivalently, the probability of finding the atom at the excited state at time  $ \tau $)

 $$ \rho(\tau)=\frac{1}{\tau_{_{0}}}e^{-\frac{\tau}{\tau_{_{0}}}} $$ 

 $$ \mathrm{When}\quad<\tau>=\frac{\int\tau\rho(\tau)d\tau}{\int\rho(\tau)d\tau}=\tau_{0} $$ 

∴  $ \tau_{0} $ is the average of lifetime of the excited state, or the average duration of the wave-trains temporal duration. The average space duration, or the OPL duration is then:

 $$ L_{0}=c\tau_{0} $$ 

 $ \tau_{0} $: coherent time,  $ L_{0} $: coherent length.

Thus, for  $ \Delta L_{12} $ (The OPL difference between two points from the source)

<div style="text-align: center;"><img src="imgs/img_in_image_box_193_210_358_322.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_394_232_607_322.jpg" alt="Image" width="17%" /></div>


If  $ \Delta L_{12} > L_{0} $, the wave trains through path 1 and 2 to reach point P will be likely from different wave trains with random phase relation(average speaking) and thus 1 and 2 are not coherent

 $$ \triangle L_{12}=(r_{1}+R_{1})-(r_{2}+R_{2})>L_{0} $$ 

There will be no interference at P, or 1,2 are incoherent for point P.

Clearly this  $ L_0 = c\tau_0 $ should relate to the maximum OPL difference  $ \Delta L_m = \lambda^2 / \Delta \lambda $ we derived in (5-47).

For a wave train with duration  $ \tau $, it is not a single frequency wave. As we discussed at very beginning of this course and in superposition of waves with different frequencies, the wave train is a result of superposition of many harmonic waves with certain frequency distribution.

 $ f(t) $: wave train



<div style="text-align: center;"><img src="imgs/img_in_image_box_180_1102_397_1171.jpg" alt="Image" width="18%" /></div>


 $$ f(t)\propto\int_{-\infty}^{+\infty}g(\omega)e^{-i\omega t}d\omega $$ 

 $ g(\omega) $: frequency distribution

This is not strange to us by now, since in our earlier discussion on the wave packet, we have demonstrated that a square frequency distribution

of $g(\omega)$, the superposition gives rise to a wave packet in forms of $\frac{\sin \mu}{\mu}$ (or $\sin c(\mu)$), with a spread of $\Delta T'$ and $\Delta t \Delta \omega = 2\pi$ or $\Delta t \Delta \upsilon = 1$.

(In the previous discussion $T'=\frac{x}{v_{g}}-t$, for fixed space coordinate: $\Delta T'=\Delta t=\tau$ for a wave train)

Thus  $ \tau\Delta\upsilon=1 $ (5-50)

Comment: In the previous discussion of superposition waves with different frequencies, is a square function $g(\omega)$, $f(t)$ is in form of $\frac{\sin \mu}{\mu}$; here the $f(t)$ is inform of square function, then $g(\omega)$ would be in forms of $\frac{\sin \mu}{\mu}$. So $\Delta T_{\Delta U} \approx 1$ still holds. Generally the exact form of $f(t)$ will depend on $g(\omega)$, and vice versa, but relation (5-50) generally holds for the uncertainties in the conjugate variables for which we shall see it is a general property of Fourier Transform.

For a wave train with average duration  $ \tau_{0} $ as emitted by atoms/molecules:

 $$ \tau_{0}\triangle v=1 $$ 

 $$ \triangle v=-\frac{\triangle\lambda}{\lambda^{2}}C $$ 

 $$ \tau_{_{0}}=\frac{\lambda^{2}}{\left|\triangle\lambda\right|c} $$ 

 $$ \therefore\quad L_{0}=\frac{\lambda^{2}}{\left|\triangle\lambda\right|} $$ 

Compare with (5-47), $L_{0}$ the coherent length and $\Delta L_{m}$ maximal OPL difference are clearly the same. This helps us understanding that

## 5 -6-3 Correlation Function — Formal treatment of Coherence

<div style="text-align: center;"><img src="imgs/img_in_image_box_175_366_623_548.jpg" alt="Image" width="37%" /></div>


 $$ \begin{aligned}&\left\{\begin{aligned}&E_{1}\\ &E_{2}\\ &\end{aligned}\right.\quad field at source S_{1},S_{2}\\&\left\{\begin{aligned}&E_{1p}\\ &E_{2p}\\ &\end{aligned}\right.\quad field at P by propagation from S_{1},S_{2}\end{aligned} $$ 

 $$ t_{1}=\frac{L_{1}}{C}\qquad t_{2}=\frac{L_{2}}{C}\quad are propagation time from source to field point P. $$ 

The reason that we can observe the interference at field point P is because the sources are coherent, and the contrast of interference at P will depend on the degree of coherence between S₁, S₂. So it should be able to express this degree of coherence (as we have mentioned earlier of this section, the contrast γ) between S₁, S₂, by the  $ \bar{E} $ field at S₁, S₂. Note: it is the field at the source S₁, S₂ we are talking about, not the field at point P generated by S1, S2, though the two are closely related.

Basically, given the property of the field at S_{1}, S_{2}, then the interference problem in all space should be solved, whether the interference is observable (or same saying whether the sources are

coherent for certain observer) should be able to be expressed by the field of the sources. The correlation function just does that.

The field at P is closely related with those of the sources:

 $$ E_{1p}\propto E_{1}(t-t_{1}) $$ 

 $$ E_{2p}\propto E_{2}(t-t_{2}) $$ 

Basically the field at P is delayed by the time required for the wave to travel to it. This is same as our wave description before, i.e.:  $ E_{1p} \propto E_1(t - t_1) = e^{-i[\omega(t - t_1) - \varphi_0]} = e^{-i\omega t} e^{i\omega t_1} e^{i\varphi_0} = e^{-i\omega t} e^{i k l_1} e^{i\varphi_0} $

The $\propto$ is due to change in the amplitude along the propagation (for spherical , it is $\propto\frac{1}{r}$), the field at P clearly varies as $E_{i}(t-t_{i})$. If we put aside the change in amplitude (the distance between $S_{1}$-P is about same as $S_{2}$-P, so the amplitudes are approximately same; and we care more about the phases which is more sensitive to the optical path length):

 $$ E_{1p}=E_{1}(t-t_{1})\qquad E_{2p}=E_{2}(t-t_{1}) $$ 

Repeat the above once more: (to make sure you understand the definition of each symbol)

 $ E_{1p} $,  $ E_{2p} $ are the fields at P generated by source 1,2;

 $ E_{1} $  $ E_{2} $ are the fields at sources 1,2,

 $ t_{1} $  $ t_{2} $ are the traveling time from 1,2 to p.

The time averages intensity at point P then is:

 $$ \begin{aligned}&I(p)=<E_{p}\cdot E_{p}>=<(E_{1p}+E_{2p})\cdot(E_{1p}+E_{2p})^{*}>\\ &=<\left|E_{1}(t-t_{1})\right|^{2}+\left|E_{2}(t-t_{2})\right|^{2}+2\operatorname{Re}(E_{1}(t-t_{1})E_{2}(t-t_{2})^{*}>\\ &=<\left|E_{1}(t-t_{1})\right|^{2}>+<\left|E_{2}(t-t_{2})\right|^{2}>+<2\operatorname{Re}(E_{1}(t-t_{1})E_{2}(t-t_{2})^{*}>\\ &=I_{1}+I_{2}+2\operatorname{Re}<E_{1}(t^{\prime})E_{2}(t^{\prime}+\tau)^{*}>\\ &=I_{1}+I_{2}+2\operatorname{Re}<E_{1}(t)E_{2}(t+\tau)^{*}>\quad(5-52)\\ \end{aligned} $$ 

where  $ t' = t - t_{1} $;  $ \tau = t_{1} - t_{2} $

Define:

 $$ \tau_{_{12}}(\tau)=<E_{_{1}}(t)E_{_{2}}(t+\tau)^{*}>_{_{T}}=\frac{1}{T}\int_{_{0}}^{T}E_{_{1}}(t)E_{_{2}}(t+\tau)^{*}dt $$ 

This is the Correlation Function between sources that carries information on interference. Because the interference term from (5-52) is:  $ 2\operatorname{Re}\tau_{12}(\tau) $,  $ \tau_{12}(\tau) $ is defined as above.

Comment: I need the sources are statistically stationary for the above derivation, i.e. the time averaged value is independent of the starting time chosen by the observer, that is why I changed t' to t in the last relation of 5-52. The correlation function is a function of time delay  $ \tau $ only.

Auto correlation  $ \tau_{ii} $ is one special case of the definition (5-53), it is a measurement of coherent time of the single source.

 $$  Clearly\quad\tau_{11}(0)=I_{1},\tau_{22}(0)=I_{2} $$ 

Define Normalized correlation function:

 $$ \gamma_{12}(\tau)=\frac{\tau_{12}(\tau)}{\sqrt{\tau_{11}(0)\tau_{22}(0)}}=\frac{\tau_{12}(\tau)}{\sqrt{I_{1}I_{2}}} $$ 

Thus (5-52) becomes

 $$ \begin{aligned}&I=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}\operatorname{Re}[\gamma_{12}(\tau)]\\&\gamma_{12}(\tau)=\left|\gamma_{12}(\tau)\right|e^{i\delta}\quad(5-55)\\ \end{aligned} $$ 

Then clearly the contrast from definition is:

 $$ \gamma=\frac{2\sqrt{I_{1}I_{2}}}{I_{1}+I_{2}}\left|\gamma_{12}(\tau)\right| $$ 

Contrast by complete Coherence, but different Contrast depends on the degree of coherence between sources.



 $ I_i $, equal 1 if  $ I_1 = I_2 $

 $ |\gamma_{12}(\tau)|=1 $: complete coherent sources

 $ 0 < |\gamma_{12}(\tau)| < 1 $: partial coherent

 $ |\gamma_{12}(\tau)|=0 $: incoherent

Evaluation of coherence between sources thus becomes an evaluation of the normalized correlation function  $ \gamma_{12}(\tau) $ between the sources.

Example : Correlation function treatment of coherent time.

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_1070_955_1226.jpg" alt="Image" width="61%" /></div>


The interference pattern at P generated by a point source S, the light from S takes different paths 1 and 2. Previously, we evaluate I(P) by  $ \Delta L $, now we rework the problem by evaluating it with  $ \gamma_{12}(\tau) $, the two methods will be shown equivalent.

 $$ \tau_{_{S S}}=<E_{_{S}}(t)E_{_{S}}^{*}(t+\tau)> $$ 

We consider auto correlation function of S since only one source here.

$$E(t)=E_{0}e^{-i\omega t}e^{i\varphi_{0}(t)}\quad\text{and}\quad\varphi_{0}(t)\quad\text{is the initial phase. If the source is the ideal monochromatic, the light wave will be simple harmonic and the calculation is simple (try this yourself). Here let's work out a realistic case where the source emit light in wave trains, for each wave train its initial phase }\varphi_{0}\quad\text{takes certain value, random for different wave-trains.}$$

The point source S has the characteristic of emitting light as we discussed earlier; i.e. it emits a series of wave-trains with distribution in temporal duration, the average time is  $ \tau_{0} $, the temporal distribution  $ \tau' $ is given by (5-48):  $ \rho(\tau') = \frac{1}{\tau_{0}} e^{-\frac{\tau'}{\tau_{0}}} $,  $ \tau_{0} $ is the average of  $ \tau' $ s.

 $$ \begin{array}{l}\leftrightarrow\sim\sim\sim\sim\sim\sim\\\leftarrow\tau_{1}^{^{\prime}}\rightarrow\leftarrow\tau_{2}^{^{\prime}}\rightarrow\leftarrow\sim\sim\sim\sim\sim\\\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\end{array} $$ 

 $$ \begin{aligned}&\gamma_{12}(\tau)=\gamma_{ss}(\tau)=\frac{<E_{s}(t)E_{s}^{*}(t+\tau)>}{\left|E_{s}\right|^{2}}\\ &=<e^{i\omega\tau}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>\\ &=e^{i\omega\tau}<e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>\\ \end{aligned} $$ 

e iωτ is interference due to variation in OPL (equivalent to kΔL)

Let’s focus on evaluation of  $ <e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}> $, assume we have N wave-trains, total time would be  $ T=\sum_{i=1}^{N}\tau_{i}^{\prime}\approx N\tau_{0} $, then:

 $$ \begin{aligned}&<e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>_{T}\\&=\frac{1}{N\tau_{_{0}}}\int\limits_{_{0}}^{^{N\tau_{_{0}}}}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}dt\\&=\frac{1}{N\tau_{_{0}}}\int\limits_{_{0}}^{\tau_{_{1}}}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)}dt+\int\limits_{\tau_{_{1}}}^{\tau_{_{1}}^{^{\prime}}+\tau_{_{2}}^{^{\prime}}}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)}dt+\cdots\cdots\\ \end{aligned} $$ 

If  $ \tau < \tau_{1}^{\prime} $, then the first integral is:

 $$ \int\limits_{0}^{\tau_{1}^{\prime}}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)}d t=\int\limits_{0}^{\tau_{1}^{\prime}-\tau}e^{i0}d t+\int\limits_{\tau_{1}^{\prime}-\tau}^{\tau_{1}^{\prime}}e^{i\Delta_{1}}d t=\tau_{1}^{\prime}-\tau+\tau e^{i\Delta_{1}} $$ 

$\Delta_1$ is the initial phase difference between $1^\mathrm{st}$ and $2^\mathrm{nd}$ wave train and it is a random number of which we know nothing about its value. However this term will average to zero in the process of summation, so we can drop such $\tau e^{i\Delta_j}$ term in final results after summation of all the wave trains.

If $\tau > \tau_1^\prime$, $\int_0^{\tau_1^\prime} e^{i[\varphi_0(t) - \varphi_0(t+\tau)} dt = \tau_1^\prime e^{i\Delta_1}$, this time only has the random number part, and it will be similarly averaged out in the summation process. Thus, only those long wave trains with $\tau < \tau_j^\prime$ survives, contribute to the average by $\tau_j' - \tau$:

 $$ <e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>=\frac{1}{N\tau_{0}}\sum_{\tau_{j}^{^{\prime}}>\tau}(\tau_{j}^{^{\prime}}-\tau) $$ 

Let’s say the number of trains with length  $ \tau_j' $ is  $ n_j $, then  $ \frac{n_j}{N} = \rho(\tau') d\tau' $:

 $$ \begin{aligned}&<e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>={\frac{1}{N\tau_{0}}}\sum_{\tau_{j}^{\prime}>\tau}(\tau_{j}^{\prime}-\tau)={\frac{1}{\tau_{0}}}\int\limits_{\tau}^{\infty}\rho(\tau^{\prime})(\tau^{\prime}-\tau)d\tau^{\prime}\\ &=\frac{1}{\tau_{0}}\int\limits_{\tau}^{\infty}\frac{1}{\tau_{0}}e^{-\frac{\tau^{\prime}}{\tau_{0}}}(\tau^{\prime}-\tau)d\tau^{\prime}\\ &=e^{-\frac{\tau}{\tau_{0}}}\\ \end{aligned} $$ 

The integration is evaluated by method of integration by part and details are skipped here. The result of this phase evaluation combined with other term will give us the expression for the normalized auto-correlation:

 $$ \begin{aligned}&\gamma_{_{ss}}(\tau)=e^{-\frac{\tau}{\tau_{_{0}}}}e^{i\omega\tau}\quad(5-56)\\ &I(P)=I_{_{1}}+I_{_{2}}+2\sqrt{I_{_{1}}I_{_{2}}}\operatorname{Re}(\gamma_{_{ss}}(\tau))=I_{_{1}}+I_{_{2}}+2\sqrt{I_{_{1}}I_{_{2}}}e^{-\frac{\tau}{\tau_{_{0}}}}\cos\omega\tau\\ \end{aligned} $$ 

The  $ \cos\omega\tau=\cos k\Delta L $ (recall  $ \Delta L=c\tau $) is the variation of intensity due to OPL difference.  $ e^{-\frac{\tau}{\tau_0}} $ is the reduction of coherence due to limited coherent time. As  $ \tau $ (or the  $ \Delta L $ for point P) increases,  $ |\gamma(\tau)| $decrease exponentially according to (5-56).

We can see that at  $ \tau = \tau_{0} $, the coherent time,  $ \gamma = e^{-1} $. This appears a little different from our previous discussion in the temporal coherence, where at  $ \tau = \tau_{0} $,  $ \gamma = 0 $. The difference is because the models involved in the derivations are a little different. In the derivation in temporal coherence and leads to relation (5-47), the frequency distribution is a square function.

i.e.  $  g(w)  $ is  $ \boxed{\leftarrow\triangle w} $, the resultant distribution in  $ \tau $ is given by the Fourier Transform of  $  g(w)  $ and is in form of  $  \frac{\sin \mu}{\mu}  $,

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_1125_457_1197.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_177_1316_833_1507.jpg" alt="Image" width="55%" /></div>


The model leads to the  $ \gamma_{12}(t) $ in (5-56) here takes the distribution of time

 $ \tau' $ in a more realistic form of  $ \frac{1}{\tau_0}e^{-\frac{\tau'}{\tau_0}} $

<div style="text-align: center;"><img src="imgs/img_in_image_box_654_217_920_386.jpg" alt="Image" width="22%" /></div>


whose

frequency spectrum g(w)[which is the reverse Fourier Transform of

 $ \rho(\tau) $ ] is in a form of Lorentian:

 $$ g\left(w\right)\propto\frac{1}{\omega^{2}-\omega_{0}^{2}+a\omega} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_266_592_471_762.jpg" alt="Image" width="17%" /></div>


## Summary on Interference

1 Principle of superposition

 $$ \begin{array}{r l r l r l}&{\stackrel{!}{\mathcal{Z}}}&{\stackrel{\bullet}{\bullet}}&&{\mathcal{E}_{1},\mathcal{E}_{2},\cdots}&{\qquad\vec{E}=\displaystyle\sum_{j}\vec{E}_{j}(p)}\\ &{\stackrel{\Im}{\bullet}}&&{\stackrel{\bullet}{\mathcal{P}}}&&{}\\ &{\stackrel{\cdot}{\cdot}}&&{}&&{}\end{array} $$ 

 $$ \vec{E}_{j}(p)=\vec{E}_{o j}e^{i\phi_{j}(p)}e^{-i\omega t} $$ 

 $$ \vec{E}(p)=\vec{E}_{o}e^{i\phi_{j}(p)}e^{-i\omega t} $$ 

2 Interference and Coherence

 $$ \begin{aligned}I(p)=&\left|\vec{E}\right|^{2}\\=&\sum_{j=1}^{N}E_{o j}^{2}+\sum_{j=1}^{N}\sum_{i=1}^{N}\vec{E}_{o j}\cdot\vec{E}_{o i}<\cos[\phi_{j}(p)-\phi_{j}(p)]>\\&\text{Interference term}\end{aligned} $$ 

Interference Term  $ \neq 0 \rightarrow $ coherent conditions:

(1)  $ \vec{E}_{j} $ all have same  $ \omega $

(2)  $ \vec{E}_{j} $ have parallel component with each other

(3) Stationary  $ \delta = \phi_{j}(p) - \phi_{i}(p) $

Two beam Interference  $ I(p)=I_{1}(p)+I_{2}(p)+2\sqrt{I_{1}(p)I_{2}(p)}\cos\delta $

3. Wave front distribution

To know:  $ I_{1}(p), I_{2}(p), \delta = \phi_{1}(p) - \phi_{2}(p) $

We need  $ E_{j}(p)=E_{oj}(p)e^{i\phi_{j}(p)} $

paraxial condition:  $ E_{oj}(p) $ (the



amplitude) is independent of position of p; paraxial and Farfield condition:

 $ \phi_{j}(p) $ is in form of a plane wave.

## 4 Two beam Interference

Point source:  $ \delta = k\Delta L $  $ \Delta L $ is difference in OPL

 $ \Delta L = m\lambda $ bright fringe  $ \Delta L = (m + 1/2)\lambda $ dark fringe (Reversed if exist  $ \lambda/2 $ diff. in reflection)

This applies to Young’s Experiment, amplitude splitting devices, such as Equal thickness and Equal inclination fringes for thin film.

(1) Young’s Experiment:  $ \Delta L = \frac{dx'}{D} $ (And other wavefront splitting devices)

(2)Thin film:  $ \Delta L = 2nh\cos i $ (Amplitude splitting) Equal Thickness: I fixed usually i=0

(Thin film wedge; Newton Ring)  $ \Delta L = 2nh = m\lambda $  $ \Delta h = \lambda / 2n $

Equal Inclination: h is fixed

Rings  $ \Delta L = 2nh\cos i = m\lambda $

Be familiar with the change of fringe patterns with change of

parameters.

5. Michelson Interferometer.

(1) Realization of various interference patterns

(2) Precision measurement of physical quantities: distance, refraction index, wavelength .....

6. Fabry-Perot Interferometer.

(1) The most important two parameters are:

h: thickness     R: reflectance     or  $ F=\frac{4R}{(1-R)^{2}} $ (and the Finesse defined below)

(2) Transmission Intensity and its FWHM

 $$ I_{t}=I_{0}/(1+F\sin^{2}\delta/2)\qquad\delta=2k n h\cos i $$ 

 $$  It\quad has\quad maximum\quad at:\quad2nh\cos i=m\lambda\quad\varepsilon(FWHM)=\frac{4}{\sqrt{F}} $$ 

 $$ \wp=\frac{2\pi}{\varepsilon}=\frac{\pi}{2}\sqrt{F} $$ 

(3) Etalon: (h is fixed)

Function as wavelength selector  $ \lambda_{m}=\frac{2nh}{m}(i=0) $ or  $ v_{m}=\frac{mc}{2nh} $

Free spectral Range:  $ \Delta v = \frac{c}{2nh} $  $ dv_{m} = \frac{c}{\varphi m\lambda} = \frac{c}{\varphi 2nh} = \frac{\Delta v}{\varphi} $

∴ h determines the wavelength; Finesse  $ \phi $ determines the FWHM

(4) Spectrometer: (h is scanning)

 $ 2nh = m\lambda $ h determines the order m for a  $ \lambda $.

 $$ \delta\lambda=\frac{\lambda}{m\wp}\quad(\delta\nu=\frac{c}{\wp m\lambda})\quad R=\frac{\lambda}{\delta\lambda}=m\wp $$ 

7. Coherence

(1) Spatial Coherence:

Caused by extended incoherent sources.  $ b\Delta\theta=\lambda $

(2) Coherent time and length.

Caused by the limited temporal duration of the wave train, or

equivalently by the frequency distribution of the source.

Temporal duration and frequency distribution are related by Fourier Transform.

 $$ \mathrm{Coherent~time}\quad\tau_{0}\triangle v\doteq1\quad\mathrm{coherent~length}\quad L_{0}=C\tau_{0}/n=\frac{\lambda^{2}}{\left|\Delta\lambda\right|} $$ 

(3) Degree of coherence and Correlation function

 $$ \gamma=\frac{I_{\max}-I_{\min}}{I_{\max}+I_{\min}}=\frac{2\sqrt{I_{1}I_{2}}}{I_{1}+I_{2}}\left|\gamma_{12}(\tau)\right| $$ 

$$\gamma_{12}(\tau)=\frac{\tau_{12}(\tau)}{\sqrt{I_{1}I_{2}}}=\frac{<E_{1}(t)E_{2}^{*}(t+\tau)>}{\sqrt{I_{1}I_{2}}}\quad\mathrm{E1~E2~are~the~fields~at~the~sources.}$$

$$\left\{\begin{array}{ll}\gamma_{12}(\tau)=1 & \text{compelete\_coherent}\\ 0<\gamma_{12}(\tau)<1 & \text{partial\_coherent}\\ \gamma_{12}(\tau)=0 & \text{incoherent}\end{array}\right.$$

For normalized auto-correlation function:

 $$ \gamma_{_{ss}}\equiv\frac{<E_{_{s}}(t)E_{_{s}}^{*}(t+\tau)>}{I_{_{s}}},\quad I_{_{s}}=<|E_{_{s}}|^{2}> $$ 

## Chapter 6 Diffraction

The topics will be covered in this chapter are:

1. What's Diffraction(Zhao's, chap2 §5.1 Hecht's 10.1)

2. Huygens Fresnel Principle (Kirchhoff equation) (Zhao’s chap2 §5.2, pg186; Hecht, 10.4)

3. Fresnel Diffraction (Zhao's chap2 §6, pg194-206; Hecht, 10.3.1-10.3.5)

4. Fraunhoffer Diffraction (Zhao's chap2 §7, pg209-230; Hecht, 10.2.1)

5. Grating (Zhao's chap4, Hecht's, 10.2.2-10.2.7)

## 6 -1 What's Diffraction

## 6 -1-1 Definition

In Young’s Experiment, we used points to represent the two coherent sources. However in any reality, the sources themselves (aperture or slit in the experiments) have limited sizes, then an instant question is: what is the field distribution after such opening :

<div style="text-align: center;"><img src="imgs/img_in_image_box_238_1311_942_1443.jpg" alt="Image" width="59%" /></div>


From geometric optics, if p is in the region spanned by angle d/R, then its

 $  \text{Ip}^\infty | \text{Ep}|^2 = |\text{Es}/(\text{R} + \text{r})|^2  $. If  $  p  $ is outside the angle  $  d/R  $, then  $  \text{Ip} = 0  $. Is this true?

This is not always true as clearly demonstrated in the experiment shown in Figure below:

<div style="text-align: center;"><img src="imgs/img_in_image_box_215_348_985_668.jpg" alt="Image" width="64%" /></div>


From the experimental observation, it is easy to conclude that

(1) The distribution of energy on an observing plane I(p) is generally an interference pattern. The energy distribution has highs and lows.

(2) Light does not propagate in a rectilinear form, its distribution "spread out" along the direction wherever it meets restriction.

(3) The more restriction, the light seems spread out more.

This gives the definition of diffraction.

Diffraction (literally or phenomenally): Deviation of light from a rectilinear propagation

Diffraction $ ^{7} $ (physical): interference of waves.(a continuous coherence sources)

The simplest model to treat diffraction is Huygens-Fresnel Principle (H-F-P): On the unobstructed wave front, every point serves as a source of spherical secondary wavelets (same  $ \omega $). The complex amplitude of the optical field at any point beyond is a superposition of all the wavelets. It is basically Huygens Principle + Superposition of waves. Simple picture of H-F-P in determining E(p) through a hole:

a) For  $ \overline{AB}<\lambda/2 $. Then  $ \Delta L $ of difference in OPL between any two paths,  $ \Delta L<\overline{AB}<\lambda/2 $ All secondary waves add at P constructively  $ \overline{AB} $ behaves as a point source.

b) As  $ \overline{AB} $ increases, the interference at P from all the secondary wavelets can either constructive or destructive-diffraction, meaning intensity there may be high or low.

c) As  $ \overline{AB} \gg \lambda $ such interference would cause light APPEAR to travel in linear form and we get geometric optics prediction. (We shall see that the diffraction arising from the boundary is much smaller comparing to the light in the geometric allowed zone, which is the  $ 0^{th} $ order diffraction)

<div style="text-align: center;"><img src="imgs/img_in_image_box_211_1250_534_1474.jpg" alt="Image" width="27%" /></div>


Simple as its physical picture appear to be, solving the field at p

exactly for an arbitrary setup is actually an extreme complicate and difficult job, except for some simple cases which we are going to study in this course, namely the Fraunhoffer Diffraction and field of on-axis points in Fresnel diffraction.

## 6 -1-2 Fraunhoffer and Fresnel Diffraction

To evaluate  $ E(p) $, the field at p we need to know:

(1) field distribution of the secondary wavelets on  $ \sum $ (diffraction

<div style="text-align: center;"><img src="imgs/img_in_image_box_318_696_562_872.jpg" alt="Image" width="20%" /></div>


screen)

(2) The field at p generated by each secondary wavelets by principles of superposition

The simple calculation is obtainable if the incoming and outgoing waves are planar wave, and such is Fraunhoffer Diffraction or Far-field diffraction. This requires that both the light source and the observation plane are infinitely distant from the diffraction screen, or at least both paraxial and far field requirements are satisfied. This can be easily achieved in experiment by lenses:

<div style="text-align: center;"><img src="imgs/img_in_image_box_210_155_769_472.jpg" alt="Image" width="46%" /></div>


<div style="text-align: center;">Then (1) The field Amplitude of the secondary wavelets on  $ \sum $ is constant. (2) The OPL used in the calculation (we shall explain this in detail later) only depends linearly on the two aperture variables  $ d, \theta $, such linearity is the mathematical criterion for the Fraunhoffer diffraction.</div>


Applying the far-field criterion (in the optical  $ \lambda $ region, far field includes the paraxial)

 $ R \gg \frac{d^{2}}{\lambda} $ d the size of the  $ \sum $ (6-1)

R is the smaller distance between S and P to  $ \sum $

As we shall see Fraunhoffer diffraction has many important applications and is also instrumental in the Fourier transform optics. Other arrangement does not satisfy (6-1) is called Fresnel diffraction. Fraunhoffer diffraction is only a special case for it. However, the treatment is more involving for the Fresnel type diffraction. We shall give a brief introduction for the Fresnel diffraction first, the goal is to illustrate: how to use H-F-P, and we only concerns the P on the central axis in this case. We are not going to treat the detailed distribution of the interference

pattern for the off axis points in Fresnel-diffraction case.

## 6 -2 Huygens-Fresnel Principle (HFP) and Kirchhoff equation

As we stated earlier that the HFP is basically the Huygens principle combined with superposition of the waves (The waves coming from the secondary wavelets).

It is Kirchhoff who derived a correct mathematical representation for the HFP, which we only give out as a result $ ^{8} $. For the more detailed derivation of the Kirchhoff theory, please refer to Hecht’s 10.4

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_774_1015_1233.jpg" alt="Image" width="65%" /></div>


 $$ U(p)=\oint\limits_{a r e a}^{o p e n}d U(p)=K\oint\limits_{(\Sigma_{0})}^{}\frac{e^{i k r}}{r}\tilde{U}_{0}(Q)d\Sigma $$ 

 $ K = -\frac{i}{\lambda} $ (we shall give a proof on this later)

 $$ F(\theta,\theta_{0})=\frac{1}{2}(\cos\theta_{0}+\cos\theta) $$ 

Here I shall use U(p) as symbol for the field, instead of E(p) because we treat the field as a scalar field, this works when the vector feature of the field can be neglected (such as cases where the polarization all along same direction). Most part in (6-2) is quite intuitive: The field at P would depend on the area of the opening and the surface integral is over the open portion of the diffraction screen; It also depends on the field at the opening and its propagation like a spherical source dictated by Huygens principle; the  $ F(\theta_{0},\theta) $ is called obliquity factor whose origin is not intuitive (like that of HFP) but can be derived with the Kirchhoff scalar theory. (6-2) is going to be the starting point for us to deal with diffraction.

## 6 -3 Fresnel Diffraction through an open aperture

<div style="text-align: center;"><img src="imgs/img_in_image_box_170_1211_693_1513.jpg" alt="Image" width="43%" /></div>


A point source S

A screen  $ \Sigma $ with aperture

What is the field at P,

U(P)?

(Here P is a point on-axis defined by S and center of  $ \Sigma $)

## 6 -3-1 Method of Half-Wavelength ( $ \lambda/2 $) Plate

Direct application of (6-2) on this problem for the general setup would result in a nasty integral, the r has to be expressed as function of x,y of the surface area. We shall use an approximation method to evaluate such integral and this is the method of half-wavelength plate. Divide the opening aperture into orbital zone. The OPL from the edge of each neighboring zones to the field point P differs by  $ \lambda/2 $.

 $ \tilde{U}(P)=\sum_{j=1}^{n}\tilde{U}_{j}(P) $ (Integral over area reduces to summation of zones)

 $ \tilde{U}_{j}(p) $ is the contribution to P by the jth  $ \lambda/2 $ plate (zone).

 $$ r_{j}=r_{j-1}+\frac{\lambda}{2} $$ 

To evaluate  $ \tilde{U}_{j}(P) $, we need to first evaluate  $ d(\tilde{U}_{j}(P)) $, the contribution to P by a very small zone on the jth  $ \lambda/2 $ plate.

According to the HFP and Kirchhoff equation:

 $$ d\tilde{U}_{j}(P)=K f(\theta,\theta_{0})\tilde{U}_{j0}\frac{e^{i k r}}{r}d\Sigma $$ 

First the field at the diffraction screen is:

 $$ \tilde{U}_{_{j0}}=\frac{A_{_{0}}}{R}e^{ikR} $$ 

For the spherical surface, the obliquity factor is:

 $$ \cos\theta_{0}=1,f(\theta,\theta_{0})=\frac{1}{2}(1+\cos\theta)(6-5) $$ 

Next we evaluate the small area element (a belt shown by dashed lines in the figure)  $ d\Sigma $ :

 $$ =2\pi R^{2}\sin\alpha d\alpha $$ 

 $$ \because\cos\alpha=R^{2}+(R+b)^{2}-r^{2}/2R(R+b) $$ 

 $$ \sin\alpha d\alpha=\frac{r}{R(R+b)}dr $$ 

 $$ \therefore d\Sigma=\frac{2\pi Rr}{R+b}dr $$ 

Put all above into (6-3), it becomes:

 $$ \begin{aligned}d\tilde{U}_{_{j(P)}}=\tilde{U}_{_{j0}}Kf(\theta,\theta_{_{0}})\frac{2\pi R}{R+b}e^{ikr}dr\\=C_{_{j}}e^{ikr}dr\end{aligned} $$ 

 $$ \begin{aligned}&\tilde{U}_{j}(P)=\int_{r_{j-1}}^{r_{j}}dU_{j}(P)\\ &=C_{j}\int_{r_{j-1}}^{r_{j}}e^{ikr}dr\\ &=\frac{C_{j}}{ik}e^{ikr}\begin{vmatrix}r_{j}\\ r_{j-1}\end{vmatrix}\\ &r_{j}=b+\frac{j}{2}\lambda,j=1,2,\ldots\\ &e^{ikr}\begin{vmatrix}r_{j}\\ r_{j-1}\end{vmatrix}=e^{ikb}[(-1)^{j}-(-1)^{j-1}]\\ &=2e^{ikb}(-1)^{j}\\ \end{aligned} $$ 

(neglect $f(\theta,\theta_{0})$'s dependence on the $\lambda/2$-plate, treat it as a constant within the $\lambda/2$-plate)

 $$ \begin{aligned}&\tilde{U}_{_{j}}(P)=\frac{2C_{_{j}}}{ik}e^{ikb}(-1)^{^{j}}\quad(6-7)\\ &=A_{_{j}}(-1)^{^{j}}\\ &\tilde{U}(P)=\sum_{j=1}^{N}\tilde{U}_{_{j}}(P)=\sum_{j=1}^{N}(-1)^{^{j}}A_{_{j}}\\ \end{aligned} $$ 

The neighboring  $ \lambda/2 $ cancels each other in the contribution to field point P.

Absolute Amplitude of P Contribution of  $ 1^{st} $,  $ 2^{nd} $ ...  $ \lambda/2 $-plate.

 $$ \begin{aligned}|U(P)|=&\frac{\left|A_{1}\right|}{2}+(\frac{\left|A_{1}\right|}{2}-\left|A_{2}\right|+\frac{\left|A_{3}\right|}{2})+(\frac{\left|A_{3}\right|}{2}-\left|A_{4}\right|+\frac{\left|A_{5}\right|}{2})+\frac{\left|A_{5}\right|}{2}\ldots\pm\frac{\left|A_{m}\right|}{2}\\ \approx&\frac{\left|A_{1}\right|}{2}\pm\frac{\left|A_{m}\right|}{2}\quad(6-9)\end{aligned} $$ 

The terms enclosed in the bracket ( ) is close to zero due to the cancellation between adjacent zones. The signs in the final expression are + if m is an odd number, - if m is even.

The expression of  $ |A_{j}| $ can be seen from (6-6), (6-7)

 $$ A_{j}=\frac{2\lambda}{i}Kf(\theta,\theta_{0})\frac{A_{0}e^{ik(R+b)}}{R+b} $$ 

It is depending on $f(\theta,\theta_0)$, the rest can be treated as constant for the current setup. For the adjacent $\lambda/2$ plate, $f(\theta,\theta_0)$ is almost a constant (the change of $\theta$ is negligible), $f(\theta,\theta_0)$ slowly decreases as the order of $\lambda/2$-plate increases. $f(\theta,\theta_0) \searrow$ as $j \nearrow$. It reaches 0 as $j$ approaches the other pole of the spherical surface.

Based on the above arguments, we conclude:

(1) In the case of free propagation (Aperture is infinitely large), (6-8)

includes all the sums that cover all the  $ \lambda/2 $-plates on a spherical surface, where the last  $ \lambda/2 $-plate:

 $$ \begin{aligned}&f(\theta,\theta_{0})=\frac{1}{2}(1+\cos\theta)=0\rightarrow A_{m}=0\\&(\cos\theta=-1)\\ \end{aligned} $$ 

 $$ \mathrm{Then}\ U(P)_{free}=-\frac{A_{1}}{2}\quad\mathrm{or}\quad|U(P)_{free}|=\frac{|A_{1}|}{2} $$ 

i.e. The field strength at point P in the free propagation is half the field generated by the first  $ \lambda/2 $-plate at P.

(2) As the aperture size changes, or as we move the P away or towards the aperture, the number of  $ \lambda/2 $-plates contained by the aperture shall vary.

If the aperture for point P contains odd number of λ/2-plates, then the P is bright with  $ |U(P)| \approx \frac{|A_1|}{2} + \frac{|A_m|}{2} \approx |A_1| = 2 |U_{free}| $ ( $ f(\theta, \theta_0) $ does not change much)

 $$ \Rightarrow I(P)\approx4I_{0},\quad I_{0}is intensity for free propagation $$ 

Intensity will be 4 times higher at point P in the presence of aperture than that of free propagation, which is counter intuitive.

Since the energy is conserved (the energy flux through a plane should be same), then there must be a redistribution of energy across the observation plane at P. The pattern of Fresnel diffraction by a circular aperture on an observing screen would be rings with bright and dark circles.

If the aperture contains Even number of  $ \lambda/2 $-plates for point P, then

 $ |U_{p}|\approx\frac{|A_{1}|}{2}-\frac{|A_{m}|}{2} $ is small.

For the on-axis point P, its intensity distribution has been discussed. For the off-axis point, the calculation would be much more involving and will not be treated here. It is enough to know the Bright-Dark ring pattern of the Fresnel Diffraction by a circular aperture.

(3) From the derivation, we can also draw conclusion on the coefficient K in the Kirchhoff equation (We stated that  $ K = \frac{-i}{\lambda} $ before and we can prove it now):

From (6-11):  $  U(P) = -\frac{A_{1}}{2} = \frac{A_{0}}{R + b} e^{ik(R + b)}  $ for free propagation.

 $ A_{1} $ is given by (6-10),

 $$ \begin{aligned}&A_{1}=\frac{2\lambda}{i}Kf(\theta,\theta_{0})\frac{A_{0}e^{ik(R+b)}}{R+b}\\&f(\theta,\theta_{0})=1\\&\Rightarrow K=\frac{-i}{\lambda}=\frac{e^{-i\frac{\pi}{2}}}{\lambda}\\ \end{aligned} $$ 

This is indeed what the expression for K. The  $ e^{-i\frac{\pi}{2}} $ in the coefficient indicates extra phase difference for the superposition of the secondary wavelets in the HFP. This is exactly what we discussed that there is an extra  $ \frac{\pi}{2} $ phase lag for the secondary wave generated by the array of secondary oscillators (Recall what we discussed for wave's propagation in a media; Hecht 4.2.3).

## 6 -3-2 Phasor Treatment and Vibrational Spirals (curves)

What happened if the opening does not contain an integer of  $ \lambda/2 $-plates?

For the on-axis point P, such problem can be solved by the phasor method.

<div style="text-align: center;"><img src="imgs/img_in_image_box_226_594_732_739.jpg" alt="Image" width="42%" /></div>


 $ r - r_{0} = m\left(\frac{\lambda}{2}\right) $, m is a real number, not necessarily an integer as in  $ \lambda/2 $-plates case.

We still start from HFP:  $  U(P) = \frac{K}{r_{0}} \iint_{\Sigma} \tilde{U}_{0} f(\theta, \theta_{0}) e^{ikr} d\Sigma  $

Now we divide the wave front at aperture  $ \Sigma $ into many small zones  $ d\Sigma $, each small zone contributes to P with amplitude and phase  $ dA(P)e^{i\delta} $;

 $$ d A(P)=\frac{K}{r_{0}}f(\theta,\theta_{0})\tilde{U}_{0}d\Sigma,\delta=k\Delta r $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_234_1237_514_1561.jpg" alt="Image" width="23%" /></div>


And integral U(P) can be estimated

then by phasor method.

In the figure left I showed the contribution of first  $ \lambda/2 $ plate by dividing the integral into many (N) phasors. The deviation from a perfect circle is due to the decrease of  $ f(\theta,\theta_{0}) $

As  $ N \rightarrow \infty $, the arrow form a continuous curve(very close to a circle).

As the increase of aperture(or as P moves closer), the phasor diagram will be:

<div style="text-align: center;"><img src="imgs/img_in_image_box_271_529_712_888.jpg" alt="Image" width="37%" /></div>


(The spiral in the above figure is overly exaggerated, for the many lower order half-wavelength zones, it is very close to a circle)

 $$ A_{0}\approx\frac{\left|OZ_{1}\right|}{2}=\frac{\left|A_{1}\right|}{2} $$ 

 $ A_{0} $ is the field at free propagation.

Two  $ \lambda/2 $-zone-plates in aperture:  $ |U(P)|=|OZ_{2}| $

Three λ/2-plates in aperture:  $ |U(P)| = |\overrightarrow{OZ_3}| $

The figure above over exaggerates the deviation from circle. Because the

slow decrease of the obliquity factor, the  $ Z_{2}, Z_{4} $ should be very close to O

and  $ Z_{1}, Z_{3} $ is about  $ A_{0} $ away from O.

For an arbitrary phase difference between the center of the aperture and the edge, represented by A on the vibrational curve, with phase difference by  $ \beta $; then  $ |U(P)|=|OA| $ and can be easily evaluated by treating (approximately) the spiral as a circle with radius  $ A_0 $ (As long as we can treat  $ f(\theta, \theta_0) $ as constant)

Example:  $ r - r_{0} = \frac{1}{3}\lambda $

What is |U(P)| for

<div style="text-align: center;"><img src="imgs/img_in_image_box_613_466_866_590.jpg" alt="Image" width="21%" /></div>


Fresnel diffraction?

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_705_597_941.jpg" alt="Image" width="33%" /></div>


 $$ \Delta phase=k\Delta r=\frac{2\pi}{\lambda}\frac{1}{3}\lambda=\frac{2}{3}\pi $$ 

 $$ |U(p)|=A=2A_{0}\sin(\frac{1}{3}\pi) $$ 

6-3-3 Circular Obstacle

S

<div style="text-align: center;"><img src="imgs/img_in_image_box_395_1296_448_1401.jpg" alt="Image" width="4%" /></div>


From  $ \lambda/2 $ plate method:

<div style="text-align: center;"><img src="imgs/img_in_image_box_228_226_738_501.jpg" alt="Image" width="42%" /></div>


The obstacle

blocks $l\ \lambda/2$ plates, so the contribution to field point $P$ is from $(l+1)^{\mathrm{th}}\ \lambda/2$ plate to $(l+\mathrm{m})^{\mathrm{th}}$:

 $$ \begin{aligned}&|U_{P}|=|A_{l+1}|-|A_{l+2}|\ldots\\ &=\frac{|A_{l+1}|}{2}\pm\frac{|A_{l+m}|}{2}\\ &=\frac{|A_{l+1}|}{2}\\ \end{aligned} $$ 

 $ A_{l+m}=0 $ since it is the plate with  $ f(\theta,\theta_{0})=\frac{1}{2}(1+\cos\theta)=\frac{1}{2}(1-1)=0 $

Thus the point P is always bright, with irradiance as if the obstacle does not exist, similar to that of free propagation. This is another counter intuitive result, but confirmed by the experiment, very important in the demonstration of wave characters of light.

In terms of vibrational curves, the field at point P over an obstacle is:

<div style="text-align: center;"><img src="imgs/img_in_image_box_356_172_481_227.jpg" alt="Image" width="10%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_290_251_433_380.jpg" alt="Image" width="12%" /></div>


 $$ r-r_{0}=\Delta L $$ 

 $$ U(P)=\mid\overline{AO_{s}}\mid $$ 

The position of A is determined by  $ \Delta L $ which in turn is determined by the size of obstacle and position of P.

## 6 -3-4 Cabinet Principle

This is a more general result in diffraction and not limited to the Fresnel diffraction, it is originated from HFP.

From HFP:  $ U_{\Sigma_0}(P) = C \iint_{\Sigma_0} U_0(Q) e^{ikr} / r dr \Sigma $

Let  $ \Sigma_{0}=\Sigma_{a}+\Sigma_{b} $

Then:  $ U_{\Sigma_{a}}(P)+U_{\Sigma_{b}}(P)=U_{\Sigma_{0}}(P) $

 $ \Sigma_{a}, \Sigma_{b}, \Sigma_{0} $ are transparent parts of screen to add up, for example:

 $$ \begin{array}{r c l}{{}}&{{}}&{{}}\\ \hline{{}}&{{}}&{{}}\\ \hline{{}}&{{}}&{{}}\\ \hline{{}}&{{}}&{{}}\end{array}+\begin{array}{r c l}{{}}&{{}}&{{}}\\ {{}}&{{}}&{{}}\\ {{}}&{{}}&{{}}\end{array}=\text{open space} $$ 

For the illustration above, where  $ \Sigma_{0} $ is free space, then  $ \Sigma_{a} $,  $ \Sigma_{b} $ are said to be “complementary” to each other, this means the transparent region on one exactly matches the opaque region on the other and vice

versa.

The Babinet principle offers a way to estimate the diffraction pattern of the complementary screens, i.e. if the diffraction by one screen is known; then diffraction by the complementary screen is also known. A special case is that if the  $ U_{\Sigma_{0}}(P)=0 $ for a space point P in open space case, then  $ U_{\Sigma_{a}}(P)=-U_{\Sigma_{b}}(P) $ and  $ I_{\Sigma_{a}}(P)=I_{\Sigma_{b}}(P) $, the complementary screen generate same intensity and thus same pattern at P.

The Fresnel diffraction by the complementary aperture and obstacle offers an illustration to the Babinet Principle:

<div style="text-align: center;"><img src="imgs/img_in_image_box_274_724_580_1023.jpg" alt="Image" width="25%" /></div>


 $$ U_{\Sigma_{0}}=\overrightarrow{A_{0}} $$ 

 $$ U_{\Sigma_{a}}=\overrightarrow{A_{a}} $$ 

 $$ \overrightarrow{A_{a}}+\overrightarrow{A_{b}}=\overrightarrow{A_{0}} $$ 

 $$ U_{\Sigma_{b}}=\overrightarrow{A_{b}} $$ 

## 6 -3-5 Fresnel Zone Plate

Imagine for a device as depicted in the picture below, a zone plate for a pair of source and field point P, if all the light passing through the plate

are from the odd  $ -\lambda/2 $ plates, with the even plates blocked (case b in the figure; or vice versa as case a in the figure). Then there will be no cancellation between the  $ \lambda/2 $ plates, the light field at P would be strongly enhanced and the intensity could be much larger than the free propagation case. The Fresnel zone plate thus has the power to concentrate energy into certain points just as a focusing lens does. It is indeed used as lens in the wavelength region where no material is suitable for conventional lens.

<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_275_607_516_842.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_568_605_819_832.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">As the example of 10 odd−λ/2 plates (or even −λ/2 plates), make light field at P about 20A₀, and intensity 400I₀.</div>


The central question is then given $S_0(\text{source})$, $P(\text{field point})$, and their distance to the aperture, what is the radius of the $m^{\text{th}}$ $\lambda/2$ plate? Knowing this we can make the zone plate (A derivation is given in Hecht's book, 10.3.5).

Here gives another derivation as in Zhao’s book:

<div style="text-align: center;"><img src="imgs/img_in_image_box_237_172_810_404.jpg" alt="Image" width="48%" /></div>


For the  $ m^{th}\lambda/2 $ plate,  $ r = b + \frac{m}{2}\lambda $, m=1, 2, ...

What is  $ \rho_{m} $ then?

 $$ \rho_{m}^{2}=R^{2}-(R-x)^{2}=x(2R-x) $$ 

Neglect  $ x^{2} \therefore \rho_{m}^{2} = 2Rx $

 $$ \rho_{m}^{2}+(b+x)^{2}=r^{2}=(b+\frac{m}{2}\lambda)^{2}\approx b^{2}+m b\lambda $$ 

Neglect  $ x^{2} $,  $ \rho_{m}^{2} + (b + x)^{2} = 2Rx + b^{2} + 2bx $

 $$ \Longrightarrow x=\frac{mb\lambda}{2(R+b)} $$ 

 $$ \rho_{m}^{2}=\frac{Rb}{R+b}m\lambda $$ 

 $$ \rho_{_{m}}=\sqrt{m}\rho_{_{1}},\quad\rho_{_{1}}=\sqrt{\frac{Rb\lambda}{R+b}} $$ 

 $ \rho_1 = \sqrt{b\lambda} $ if  $ R \to \infty $ (i.e. plane wave as incoming light)

Another way to write (6-14) is then:

 $$ \frac{1}{R}+\frac{1}{b}=\frac{m\lambda}{\rho_{m}^{2}}=\frac{\lambda}{\rho_{1}^{2}} $$ 

If we define  $ f = \frac{\rho_{1}^{2}}{\lambda} $, (6-16) will be in forms of Gaussian formula for image formation, i.e. P is an image of point source S.

 $$ f=\frac{\rho_{1}^{2}}{\lambda}\quad(6-17) $$ 

This f is the primary focus of zone plate. It is heavily depending on  $ \lambda $, so it has chromatic aberration. Fresnel zone plate also has many secondary foci, at position of f/3, f/5, f/7 ... .(please reasoning this by yourself) as well as virtual foci (see Zhao's pg. 206).

(Such phenomena could also be understood from Fourier Transform optic, which will be discussed later.)

## 6 -4 Fraunhoffer Diffraction by Single Slit

As we stated earlier in the section of introduction that the Fraunhoffer diffraction is a special case in which both the source, and the field point P satisfy far field and paraxial condition. With respect to the diffraction screen  $ \Sigma $. i.e.:

<div style="text-align: center;"><img src="imgs/img_in_image_box_239_1078_720_1237.jpg" alt="Image" width="40%" /></div>


S, P are far away from  $ \Sigma $,  $ r, R \gg \frac{a^{2}}{\lambda} $, under this condition, the incoming wave towards the  $ \Sigma $, and outgoing wave towards P can both be treated as plane wave, which result in much simplified calculation.

## 6 -4-1 Single Slit

The 1-dimension slit is an over simplification, and real object would be at least approximately 2-dimensional. So the 1-d slit treated here is a special case for the more general 2-d apertures. It offers a good starting point to treat Fraunhoffer type diffraction.

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_517_1038_865.jpg" alt="Image" width="67%" /></div>


<div style="text-align: center;">a is the width of 1-d. slit (In reality as we shall see that can be a long slit with large extension along y direction, and with width a along x direction). The slit puts restriction along x direction and we shall observe diffraction (deviation from rectilinear propagation of light) along this direction too. So we need to find the pattern (field distribution) on the observing screen $U(P)$ or $\tilde{U}(\theta),\tilde{U}(x)$.</div>


From HFP (Kirchhoff equation):

 $$ \tilde{U}(P)=\tilde{U}(\theta)=-\frac{i}{\lambda f_{2}}\iint_{\Sigma}\tilde{U}_{0}e^{i k r}d x\quad(6-1) $$ 

↑Why is this $f_{2}$ here? It is clearly resulting from drop of amplitude of the secondary wavelets on the

screen to the field point P. But then why not  $ r_{0} $? (This is due to the lens,  $ L_{2} $, Please think yourself on the reasoning). Also the symbol of integral should cover both dx and dy, but the integration over y will just give us some constant (this will be clearer in 2-D case), and thus effective integration is only over dx.

Using the Fermat's principle in image formation, the OPL after the dashed line in the figure are all same, so the difference in OPL is given by this simple relation:

 $$ r=r_{0}-x\sin\theta $$ 

x is position on the slit,  $ \theta $ is relation to the position of diffraction pattern on the observing x' plane,  $ \theta \approx \frac{x'}{f_2} $. This simple relation (linear form in x) of the parameters is the characteristic of Fraunhoffer Diffraction.

 $$ \begin{aligned}&\tilde{U}(\theta)=-\frac{i}{\lambda f_{2}}e^{i k r_{0}}\int_{-\frac{a}{2}}^{\frac{a}{2}}e^{-i k x\sin\theta}d x\\ &=C a\frac{\sin\alpha}{\alpha}\\ \end{aligned} $$ 

↖familiar sinc function, the Fourier transform of a square distribution, actually the integral lead to 6-19 is just such Fourier transform!

 $$ \alpha=\frac{ka\sin\theta}{2}=\frac{\pi a\sin\theta}{\lambda} $$ 

When  $ \theta = 0, \alpha = 0 \rightarrow \tilde{U}(0) = aC $

↑The diffraction pattern at zero angle.

 $$ \tilde{U}(\theta)=\tilde{U}(0)\frac{\sin\alpha}{\alpha} $$ 

 $$ I(\theta)=\tilde{U}(\theta)\tilde{U}^{*}(\theta)=I_{0}\frac{\sin^{2}\alpha}{\alpha^{2}} $$ 

Zhao’s book also provides (pg. 212) a derivation by phasor method.

The intensity distribution (6-21) and the diffraction fringe are shown in the figures below.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_283_656_882_1019.jpg" alt="Image" width="50%" /></div>


<div style="text-align: center;">Single Slit Fraunhoffer Fringe</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_336_1088_982_1460.jpg" alt="Image" width="54%" /></div>


In the case of setup without lenses, same result can be derived. The derivation only outlined below:

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_271_1018_583.jpg" alt="Image" width="65%" /></div>


 $$ U(x^{\prime})=-\frac{i}{\lambda}\int U_{_{0}}\frac{e^{ikr}}{r}dx=-\frac{i}{\lambda r_{_{0}}}\int U_{_{0}}e^{ikr}dx $$ 

But from relation (5-21) of this note (or (2.17) in Zhao’s book, pg. 156), x

satisfies both paraxial and far field condition.

 $$ e^{ikr}\doteq e^{ikr_{0}}e^{-\frac{ik}{z}xx}, $$ 

 $$ \therefore U(x^{\prime})=-\frac{ie^{ikr_{0}}}{\lambda r_{0}}U_{0}\int e^{-i\frac{k}{z}xx^{\prime}}dx $$ 

and  $ \sin\theta\approx\frac{x'}{z} $, this will lead to same result as (6-19).

## 6 -4-2 Rectangular Aperture

The derivation in Zhao’s book is with lens setup, and follows what we discussed in the first-half of single slit; the Hecht’s derivation without lens, and is essentially what we discussed in the latter half of the above section. They both give same results and I only present the case without the lens. The derivation is a direct extension of what we did in the 1-d

case.

Fig 10.23 Hecht's book: (with little change in labeling of coordinate system)

<div style="text-align: center;"><img src="imgs/img_in_image_box_271_350_983_719.jpg" alt="Image" width="59%" /></div>


The contribution of  $ (x,y) $ point on the aperture to the field point  $ (x',y') $ is (The  $ (x,y) $ point satisfies paraxial and far field condition as in Fraunhoffer diffraction).

 $$ \begin{aligned}&dU(x^{\prime},y^{\prime})=-\frac{i}{\lambda}U_{0}\frac{e^{ikr}}{r}\\&=-\frac{iU_{0}}{\lambda r_{0}}e^{ikr_{0}}e^{-i\frac{k}{z_{0}}(xx^{\prime}+yy^{\prime})}\\&\therefore U(x^{\prime},y^{\prime})=C\int_{\frac{a}{2}}^{\frac{a}{2}}e^{-i\frac{k}{z_{0}}xx^{\prime}}dx\int_{\frac{b}{2}}^{\frac{b}{2}}e^{-i\frac{k}{z_{0}}yy^{\prime}}dy=abC\frac{\sin\alpha}{\alpha}\frac{\sin\beta}{\beta}\\&where\quad\begin{array}{l}\alpha=\frac{kax^{\prime}}{2z_{0}}\approx\frac{ka\sin\theta_{1}}{2}\\\beta=\frac{kby^{\prime}}{2z_{0}}\approx\frac{kb\sin\theta_{2}}{2}\end{array}\quad(6-22)\end{aligned} $$ 

The $\theta_{1},\theta_{2}$ are the angle of direction of diffraction ($r_{0}$) with its projection on the $y^{\prime}z$ plane and $x^{\prime}z$ plane, this is exactly same as in

Zhao’s derivation.

 $$ \begin{aligned}&\tilde{U}(x^{\prime},y^{\prime})=\tilde{U}(0,0)\frac{\sin\alpha}{\alpha}\frac{\sin\beta}{\beta};\tilde{U}(0,0)=ab\frac{U_{0}e^{ikr_{0}}}{\lambda i}\quad\textcircled{m}\frac{1}{(6-23)}\\&I(x^{\prime},y^{\prime})=I_{0}(\frac{\sin\alpha}{\alpha})^{2}(\frac{\sin\beta}{\beta})^{2}\\ \end{aligned} $$ 

## 6 -4-3 The Characteristic of Diffraction Distribution

Basically the diffraction field depends on  $ \frac{\sin\alpha}{\alpha} $ or  $ \left(\frac{\sin\alpha}{\alpha}\right)^{2} $

(1) Major Maximum.

 $$  Only at\ \alpha=0,i.e.\ \frac{\pi a\sin\theta}{\lambda}=0or\ \theta=0 $$ 

This can be easily understood that for the normal irradiance on the diffraction screen as depicted in the previous setup, at  $ \theta=0 $, all the secondary wavelet on the diffraction screen will have the same OPL in the Fraunhoffer diffraction, they interfere constructively along this direction.

More generally, the major maximum (or the zeroth order in diffraction pattern) occurs at the image point determined by geometric optics, since Fermat's Principle makes sure that the OPLs are the same in this case.

(2) Minimum.

They occur at:  $ \alpha = \pm \pi, \pm 2\pi, \ldots = m\pi, m = \pm 1, \pm 2, \ldots $

m=0 corresponds to the major maximum, the zeroth order.

or  $ a\sin\theta = m\lambda, m = \pm1, \pm2, \ldots $

This can be understood by the destructive interference between pairs of light beam with OPL different by  $ \Delta L = \frac{\lambda}{2} $.  $ a \sin \theta = m \lambda $ means that the slit contains even number of such  $ \lambda/2 $ zones and the resulting diffraction would be minimum due to cancellation (Recall the  $ \frac{\lambda}{2} $ plate in Fresnel Diffraction).

<div style="text-align: center;"><img src="imgs/img_in_image_box_308_657_569_899.jpg" alt="Image" width="21%" /></div>


i.e.

zone 1 cancels zone2.

(3) Minor Maxima

<div style="text-align: center;"><img src="imgs/img_in_image_box_222_1069_656_1407.jpg" alt="Image" width="36%" /></div>


Between adjacent minima, there are minor maxima. Their location can be determined by condition:

 $$ \frac{d}{d\alpha}(\frac{\sin^{2}\alpha}{\alpha^{2}})=0\rightarrow\tan\alpha=\alpha $$ 

Besides  $ \alpha=0 $, the rest  $ \alpha $ corresponds the minor maxima, which can be solved by graphical method,  $ \alpha=1.43\pi,\pm2.46\pi,\ldots $ (refer to figure of the sinc function on pg 250 of this note). At these minor maxima, they are small (only a few percent) compared to the major maxima.

## (4) Half-Angular Width

The Width of the major maximum is defined as width between max, and the first minimum (between  $ \alpha = 0 $ and  $ \alpha = \pi $).

 $$ \Delta\alpha=\frac{\Delta(\pi a\sin\theta)}{\lambda}=\pi\rightarrow a\Delta\sin\theta\approx a\Delta\theta=\lambda $$ 

(6-24) gives results that the relation between the widths of diffraction

slit and angular distribution width of the diffraction maximum.

This is not surprising, and we actually come across to similar results before (i.e.  $ b\Delta\theta \approx \lambda $ in spatial coherence,  $ \Delta T\Delta\upsilon = 1 $ in temporal coherence). As we can see from relation (6-19):

 $$ \tilde{U}(\theta)\propto\int_{-\frac{a}{2}}^{\frac{a}{2}}e^{-i k\sin\theta x}d x\leftarrow\mathrm{Fourier Transform}. $$ 

 $ k\sin\theta $ (or  $ k\theta $) and x are two variables of functions  $ (U(\theta), g(x); g(x)) $ is a square function in single slit case, two-dimensional square function in rectangular aperture case) related by the Fourier Transform, and the relation 6-24 just reflects the usual distribution width relation among the conjugate variables in Fourier Transform.

 $$ F(u)\propto\int_{-\infty}^{+\infty}g(v)e^{i u v}d v;g(v)\propto\int_{-\infty}^{+\infty}F(u)e^{i u v}d u $$ 

Δu, Δv is distribution width in F(u) and g(v).

Then  $ \Delta u\Delta v \doteq 2\pi $; here  $ \Delta x \approx a;\Delta(k\theta) = k\Delta\theta; $

 $ \Delta x\Delta(k\theta)\doteq2\pi\rightarrow a\Delta\theta=\lambda $

Relation 6-24 indicates:

a) As a is large, $\Delta\theta \rightarrow 0$, this approaches the geometric limit, $U(\theta)$ only has values along the original propagation direction of the incoming wave from source.

b) As a is small, comparable to  $ \lambda, \Delta\theta \neq 0 $. The smaller a (or the restriction along one direction becomes more serious), the larger  $ \Delta\theta $ (or the more obvious of diffraction), which is the general observation for diffraction.

Sometimes we may use term of Full Angular Width (which is width of maximum from one minimum side to the other), which is obviously  $ 2\Delta\theta=\frac{2\lambda}{a} $. The full linear width:  $ \Delta l=f\cdot2\Delta\theta $, where f is the focal length of the imaging lens.

## 6 -4-4 Fraunhoffer Diffraction by Circular Aperture and Image Resolution

The diffraction screen is a circular aperture with radius a, or diameter D (figure 10.21, Hecht’s), the source and observer satisfy the Fraunhoffer type diffraction. The derivation for this case is a little complicated, the

integral will result in Bessel function (one type of so called special functions) and is skipped here (see Hecht's 10.2.5 for detail). The diffraction pattern observed on the screen is in forms of bright and dark circular rings. Its distribution is given by:

 $$ I(\theta)=I_{0}(\frac{2J_{1}(x)}{x})^{2},\mathrm{a n d}x=\frac{kD\sin\theta}{2}=\frac{\pi D\sin\theta}{\lambda} $$ 

 $ J_{1}(x) $ is the first order Bessel function and its value for different x are given in the Hecht book, table 10.1, also the figure 10.22 in Hecht's:

<div style="text-align: center;"><img src="imgs/img_in_image_box_198_720_578_929.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">The I(θ) pattern is plotted as Fig. 10.23 in Hecht's.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_175_1101_449_1493.jpg" alt="Image" width="23%" /></div>


Basically it is a ring pattern, with the center  $ \theta=0 $ region) be a bright disk which is called Airy Disk. The Airy disk has half angular width  $ \Delta\theta $ (defined as before, the angular difference between maximum and first zero),

 $$ \Delta\theta=1.22\frac{\lambda}{D} $$ 

This diffraction puts a limit to the image resolution. In our discussion in the geometric optics where the diffraction is omitted, an ideal image formation will establish a 1 to 1 relation between object and image point, i.e. an object point will form an image which is also a point.

Considering the diffraction caused by the optical elements, the lens itself would behave as a circular aperture for the incoming light and would cause diffraction. So the image for a point after the lens, is not a point but an Airy Disk as we showed above (we can neglect the higher order in the diffraction pattern due to their small intensity). This will give rise to the image resolution problem. That is if the two images formed by two point objects are too close together, their Airy Disk will overlap and cannot be distinguished. We adopt the Rayleigh criteria for the image resolution, i.e. if the angular separation between the two images (Airy Disk) center (the angle spanned by the image with respect to the center of lens)  $ \Delta\varphi $ is larger than the  $ \Delta\theta $, the half angular width of Airy Disk, then

the two images are resolvable (see figure 10.24, 10.25 in Hecht's and the figure below).

<div style="text-align: center;"><img src="imgs/img_in_image_box_236_302_986_1217.jpg" alt="Image" width="63%" /></div>


<div style="text-align: center;">Fig 10.25 in Hecht's</div>


<div style="text-align: center;">So the minimum angular separation between the image points is:</div>


 $$ \Delta\varphi_{\min}=\Delta\theta=1.22\frac{\lambda}{D} $$ 

 $ \lambda $ is the wavelength of light and D is the diameter of the lens. To improve

the resolution power of the image formation, we can either decrease the wavelength (such as the electron microscope in biology) or use large diameter lens (large D telescope in astronomy)

## 6 -5 Diffraction by Many Slits (Fraunhoffer Type)

## 6 -5-1 Fraunhoffer-Diffraction by Many Slits

<div style="text-align: center;"><img src="imgs/img_in_image_box_244_655_897_1061.jpg" alt="Image" width="54%" /></div>


Multiple Slits, slit's width: a; Spacing between slits: d. The slits are arranged periodically.

Question: What is the amplitude and intensity pattern for a point on the observing screen  $ P_{\theta} $?

 $ U(P) $ have contributions from :

(1) Diffraction of single slit.

All the slits though shifted in space, create same single slit

diffraction pattern. But the intensity at  $ P_{\theta} $ is not the summation of the irradiance of the slits. Because →

(2) Interference among slits.

Let's start from the HFP and Kirchhoff equation to derive the expression for the field at point P:

 $$ \begin{aligned}&\tilde{U}(x^{\prime})=\tilde{U}(\theta)=C\int_{\Sigma}\tilde{U}_{0}(x)e^{i k r}d x\\ &=\sum_{j=0}^{n-1}C\int_{\Sigma_{j}}\tilde{U}_{0}(x_{j})e^{i k r_{j}}d x_{j}\\ \end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_270_474_896_820.jpg" alt="Image" width="52%" /></div>


 $$ C=-\frac{i}{\lambda f}\overline{f(0,\theta_{0})} $$ 

 $ r_{j}=L_{j}-x_{j}\sin\theta,L_{j} $ is the OPL to point P measured from center of each slit.

 $$ \tilde{U}(\theta)=C\int_{-\frac{a}{2}}^{+\frac{a}{2}}\tilde{U}_{0}(x)e^{-i k x\sin\theta}d x(\sum_{j=0}^{N-1}e^{i k L_{j}}) $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_269_971_943_1259.jpg" alt="Image" width="56%" /></div>


 $ \mu(\theta) $, Single Slit Diffraction Multi-slits

(same for all slit in this case) Interference Term

 $ \mu(\theta) $ is the diffraction for a single slit with width a, i.e.  $ \tilde{U}_0(x) $ is:

<div style="text-align: center;"><img src="imgs/img_in_image_box_258_1355_641_1534.jpg" alt="Image" width="32%" /></div>


 $$ \mu(\theta)=a_{0}\frac{\sin\alpha}{\alpha}\quad\alpha=\frac{ka\sin\theta}{2}=\frac{\pi a\sin\theta}{\lambda} $$ 

or more generally, is the Fourier transform of  $ \tilde{U}_{0}(x) $

Multi-slits interference term is:

 $$ \begin{aligned}&\widetilde{N}(\theta)=\sum_{j=0}^{N-1}e^{i k L_{j}}\\&L_{j}=L_{0}+j d\sin\theta,j=0,1,...,N-1\\&\widetilde{N}(\theta)=e^{i k L_{0}}[1+e^{i k\Delta L}+...+e^{i k(N-1)\Delta L}]\\&\Delta L=d\sin\theta,k\Delta L=2\frac{d\sin\theta}{\lambda}\pi=2\beta\\&\therefore\widetilde{N}(\theta)=e^{i k L_{0}}\frac{1-e^{i2N\beta}}{1-e^{i2\beta}}\\&=e^{i k L_{0}}\frac{e^{i N\beta}(e^{-i N\beta}-e^{i N\beta})}{e^{i\beta}(e^{-i\beta}-e^{i\beta})}\\&=e^{i k L_{0}}e^{i(N-1)\beta}\frac{\sin N\beta}{\sin\beta}=e^{i\varphi(\theta)}\frac{\sin N\beta}{\sin\beta}\\&\widetilde{U}(\theta)=\widetilde{M}(\theta)\widetilde{N}(\theta)\\&=a_{0}\frac{\sin\alpha}{\alpha}\frac{\sin N\beta}{\sin\beta}e^{i\varphi(\theta)}\\ \end{aligned} $$ 

With  $ \alpha=\frac{a\sin\theta}{\lambda}\pi;\beta=\frac{d\sin\theta}{\lambda}\pi $ given above.

 $$ \begin{aligned}I(\theta)&=I_{0}(\frac{\sin^{2}\alpha}{\alpha^{2}})(\frac{\sin N\beta}{\sin\beta})^{2}\\&\uparrow\end{aligned} $$ 

 $ I_{0}=a_{0}^{2} $, the irradiance by single slit at  $ \theta=0 $

<div style="text-align: center;"><img src="imgs/img_in_chart_box_237_140_855_1003.jpg" alt="Image" width="51%" /></div>


<div style="text-align: center;">(Figure 10.17 in Hecht's. Noticed the notation difference, and I apologize for using different set from his;  $ \alpha,\beta $ in the figure is reversed from definition in this note, also he used a for spacing between slit and b for single slit width.)</div>


With relations 6-32, and definition of  $ \alpha, \beta $, it is easy to derive all the properties of many slits diffraction.

The observations of multi-slits diffraction:

<div style="text-align: center;">(1) Several principal maxima (principal peaks).</div>


(2) The principal peaks have narrower width and higher intensity as N increases.

(3)Between the principal maxima, there are N-1 minima and N-2 subsidiary maxima.

(4) Total diffraction pattern of many slits diffraction is the many-slits interference monitored by the envelope of single slit diffraction.

<div style="text-align: center;"><img src="imgs/img_in_image_box_250_554_1013_911.jpg" alt="Image" width="64%" /></div>


The explanation lies within  $ \tilde{U}(\theta) \propto \frac{\sin \alpha}{\alpha} \frac{\sin N\beta}{\sin \beta} $, whereas  $ \theta $ varies,  $ \frac{\sin N\beta}{\sin \beta} $ changes faster compared to  $ \frac{\sin \alpha}{\alpha} $; So  $ \frac{\sin N\beta}{\sin \beta} $ term is responsible for the principal maxima, minima and sub maxima; the  $ \frac{\sin \alpha}{\alpha} $ acts as modulation to it.

(1) Principal maxima (PM):

 $$ \begin{aligned}&\frac{\sin N\beta}{\sin\beta}\quad is maximum\rightarrow\quad\sin\beta=0\quad or\quad\beta=m\pi;m=0,\pm1,\ldots\\&\frac{\sin N\beta}{\sin\beta}=N,\quad d\sin\theta=m\lambda\quad(\end{aligned} $$ 

In (6-33)  $ m \neq 0 $ non-zero integers, d has to be  $ >\lambda $. If  $ d < \lambda $, only  $ m = 0, \theta = 0 $ will satisfy (6-33), only the zeros order maximum in  $ d < \lambda $ case, the  $ 0^{\text{th}} $ order as we shall see has little use in application.

The (6-33) determines the position of the principal maxima, and its intensity  $ \propto N^{2}(I_{0}\frac{\sin^{2}\alpha}{\alpha^{2}}) $, the intensity is  $ N^{2} $ times that of the single slit diffraction. (Instead of N times if no interference, the energy is more concentrate in the phase space. We actually already encountered similar situation in Fabry-Perot interferometer cases, which is a result of multi-beam interference) Also as in Fabry-Perot cases, as more beams take part in interference (large R in F-P case, large N in multi-slits here), the width of energy distribution narrows. But first we study the position of minimum.

(2) Minimum between the maxima.

 $$ \begin{aligned}&\sin N\beta=0,\sin\beta\neq0\\&\therefore N\beta=n\pi,\quad n=\pm1,\ldots,\pm N-1\quad(6-34)\\&\beta=\frac{n}{N}\pi\quad&N-1&zeroes between adjacent maxima.\end{aligned} $$ 

For the  $ m^{th} $ principle maxima, the closest zeros at:  $ \beta_{\pm} = (m \pm \frac{1}{N})\pi $

## (3) Width of the Principal Maxima

The width is defined as the difference between the maximum to its closest zero.

 $$ \begin{aligned}&\Delta\beta=\beta_{m}-\beta_{-}=\beta_{+}-\beta_{m}=\frac{\beta_{+}-\beta_{-}}{2}=\frac{1}{N}\pi\\ &\quad\searrow\\ &\Delta(\frac{\pi d\sin\theta}{\lambda})=\frac{\pi d}{\lambda}\Delta(\sin\theta)=\frac{\pi d}{\lambda}\cos\theta\Delta\theta=\frac{1}{N}\pi\\ &\therefore\cos\theta\Delta\theta=\frac{\lambda}{Nd}\qquad(6-35)\\ \end{aligned} $$ 

For $\theta$ is small, $\cos\theta\approx1$, 6-35 reduces to $\Delta\theta=\frac{\lambda}{Nd}$. Thus width $\Delta\theta$ is reversely depends on N as expected.

## (4) Subsidiary Maxima

Between zero points, there has to be a subsidiary maximum, N-1

zeroes between adjacent principle maxima  $ \rightarrow $ N-2 sub. max. The

exact location of the sub. max. can be found by evaluating

 $ \frac{d}{d\theta}(\frac{\sin^{2}N\beta}{\sin^{2}\beta})=0 $, but since their intensity is only a small percentage of

that of the principle maxima, we shall neglect them most of the time.

## (5) Missing orders – Effect of single slit diffraction

For a certain  $ \theta $, if at this diffraction angle:

 $$ \beta=m_{1}\pi\rightarrow\theta\leftarrow\alpha=m_{2}\pi $$ 

 $$ m_{1}=\stackrel{0,\pm1,\ldots}{\uparrow}\qquad m_{2}=\stackrel{\pm1,\ldots}{\uparrow} $$ 

principal max zeroes in single slits diffraction

 $$ \begin{aligned}&\sin\theta=\frac{m_{1}\lambda}{d}=\frac{m_{2}\lambda}{a}\\ &\therefore\frac{m_{1}}{m_{2}}=\frac{d}{a}\\ \end{aligned} $$ 

Say  $ \frac{d}{a}=3 $, then the 3rd principal max. would overlap with 1st order

zeroes of single diffraction → missing 3rd order principal max.

Examples1: cosine slit, (Zhao's book pg. 14, Vol. II)

Now take a look the case that  $ \tilde{U}(x) $ for single slit is a cosine type function instead of a square function.

 $$ \tilde{U}(x_{i})=\left\{\begin{aligned}&1+\cos\frac{2\pi}{d}x_{i},-\frac{d}{2}<x_{i}<\frac{d}{2}\\ &0\end{aligned}\right. $$ 

 $$ x_{i}=x-x_{i0} $$ 

 $ x_{i0} $ is the center of i^{th} slit.

Here the multi-slits are N slits with light transmission given above, and its graph is shown below; the slit width is d and the spacing between slits is also d.

<div style="text-align: center;"><img src="imgs/img_in_image_box_229_888_1053_1066.jpg" alt="Image" width="69%" /></div>


using 6-29:

 $$ \tilde{U}(\theta)=\tilde{\mu}(\theta)\widetilde{N}(\theta),\widetilde{N}(\theta)=\frac{\sin N\beta}{\sin\beta};\beta=\frac{\pi d\sin\theta}{\lambda} $$ 

 $ \tilde{\mu}(\theta) $ the single slit diffraction is:

 $$ \begin{aligned}&\widetilde{\mu}(\theta)=C\int_{\frac{d}{2}}^{\frac{d}{2}}(1+\cos\frac{2\pi}{d}x)e^{-ik\sin\theta x}dx\\ &=C\int_{\frac{d}{2}}^{\frac{d}{2}}1+\frac{1}{2}e^{i\frac{2\pi}{d}x}+\frac{1}{2}e^{-i\frac{2\pi}{d}x})e^{-ik\sin\theta x}dx\\ &=C[\frac{\sin\beta}{\beta}+\frac{1}{2}\frac{\sin(\beta-\pi)}{\beta-\pi}+\frac{1}{2}\frac{\sin(\beta+\pi)}{\beta+\pi}]\\ \end{aligned} $$ 

 $$ \begin{aligned}\tilde{U}(\theta)\propto&\frac{\sin\beta}{\beta}\frac{\sin N\beta}{\sin\beta}+\frac{1}{2}\frac{\sin(\beta-\pi)}{\beta-\pi}\frac{\sin N\beta}{\sin\beta}+\frac{1}{2}\frac{\sin(\beta+\pi)}{\beta+\pi}\frac{\sin N\beta}{\sin\beta}\\&\downarrow\quad\quad\quad\quad\downarrow\quad\quad\quad\quad\downarrow\\&only nonzero\quad&only nonzero\quad&only nonzero\\&around\quad\beta=0\quad&around\quad\beta=\pi\quad&around\quad\beta=-\pi\end{aligned} $$ 

So only  $ 0,\pm1 $ order of the principal maxima from  $ \frac{\sin N\beta}{\sin\beta} $ survives,

the rest are missing orders due to single slit modulation.

Also from missing order relation:  $ \frac{m_{1}}{m_{2}}=\frac{d}{a} $, if  $ d=a $, then only  $ m_{1}=0, m_{2}=0 $ survives. The resulting diffraction pattern would be that given in Zhao's, Vol. II, Fig 1-9.

In this example, you may also start with relation (6-28)

 $$ \tilde{U}(\theta)=C\int_{-\frac{Nd}{2}}^{\frac{Nd}{2}}(1+\cos\frac{2\pi}{d}x)e^{-ik\sin\theta x}dx $$ 

which would generate same results. This can also be looked at from view point of Fourier Transform later.

Example 2. problem 5, pg. 17, Zhao's Vol. II.

<div style="text-align: center;"><img src="imgs/img_in_image_box_283_175_553_365.jpg" alt="Image" width="22%" /></div>


 $$ \begin{aligned}&\widetilde{U}(\theta)=\widetilde{\mu}(\theta)\widetilde{N}(\theta)\\&\widetilde{\mu}(\theta)=C\frac{\sin\alpha}{\alpha},\alpha=\frac{\pi a\sin\theta}{\lambda}\\&\widetilde{N}(\theta)=e^{i\varphi(\theta)}[1+e^{i k2d\sin\theta}+e^{i k3d\sin\theta}]\\&=e^{i\varphi(\theta)}[1+e^{i4\beta}+e^{i6\beta}],\beta=\frac{\pi d\sin\theta}{\lambda}=\frac{kd\sin\theta}{2}\\&I(\theta)=\widetilde{\mu}(\theta)\widetilde{\mu}^{*}(\theta)\widetilde{N}(\theta)\widetilde{N}^{*}(\theta)\\&\quad\underbrace{}_{I_{0}(\frac{\sin\alpha}{\alpha})^{2}}[1+e^{i4\beta}+e^{i6\beta}][1+e^{-i4\beta}+e^{-i6\beta}]\end{aligned} $$ 

or you may use phasor method:

<div style="text-align: center;"><img src="imgs/img_in_image_box_243_848_458_1040.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;">Example 3: problem 6, Zhao's book, pg. 17.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_249_1182_371_1374.jpg" alt="Image" width="10%" /></div>


Here since the single slit diffraction  $ \tilde{\mu}(\theta) $ is different for the two silts, then generally,  $ \tilde{U}(\theta) $ will not be in form of  $ \tilde{\mu}(\theta)\tilde{N}(\theta) $. You can

start from HFP, relation (6-28):

 $$ \begin{aligned}&\widetilde{U}(\theta)=C\int\widetilde{U}_{0}(x)e^{ikr}dx\\ &=(\int_{-a}^{+a}e^{-ikx\sin\theta}dx)e^{ikL_{0}}+(\int_{-\frac{a}{2}}^{+\frac{a}{2}}e^{-ikx\sin\theta}dx)e^{ikL_{1}}\\ \end{aligned} $$ 

 $$ L_{1}=L+d\sin\theta.\ldots.. $$ 

Or we can treat the slit like 3 slit case:

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_478_333_679.jpg" alt="Image" width="8%" /></div>


and the work will be exactly as example 2.

[Here each single slit has same  $ \tilde{\mu}(\theta) $, and the  $ \tilde{U}(\theta) $ can be expressed into  $ \tilde{\mu}(\theta)\tilde{N}(\theta) $]

## 6 -5-2 Diffraction Grating and Grating Spectrometer

### 6 -5-2-1. Diffraction Grating

Diffraction Grating: A repetitive array of some diffraction elements, which periodically alter the phase, amplitude or both of the emergent wave.

The many slit diffraction studied earlier is a simple example of such grating, in the previous section we worked square type and cosine (sine) type of transmitting gratings, there are many other types of arrangement

fall into this category, such as well-ordered crystals, give rise to X-ray diffraction.

The derivation in the last section provides the basic of discussion of grating. More generally for the Fraunhoffer type diffraction by multiple equivalent elements, we have from (6-32):

 $$ \tilde{U}(\theta)=\tilde{\mu}(\theta)\tilde{N}(\theta) $$ 

 $ \tilde{U}(\theta) $ is the diffraction field.

 $ \tilde{\mu}(\theta) $ is the diffraction due to single element.

 $ \tilde{N}(\theta) $ is the interference between elements.

### 6 -5-2-2. Grating Spectrometer (Transmitting Case)

Spectrometer is a device that separates the frequency component of light; it is essentially a dispersive device like a prism. The light with different frequency will appear at different place (or time) so that its spectrum can be analyzed (a spectrum is a recording of intensity of frequency components).

## (1) Grating equation:

From the previous discussion, the  $ m^{th} $ principal maximum (P.M) due to the  $ \tilde{N}(\theta) $ the multiple-interference term is:

 $$ d\sin\theta=m\lambda,m=0,\pm1,\ldots $$ 

(6-33) is called grating equation and is most important in application of grating. It gives us the dispersive relation between frequency (here

wavelength) and space distribution. In case of  $ m \neq 0 $, i.e. higher order diffraction maxima occur at different angle  $ \theta $ with different  $ \lambda $. That is the higher order principle maxima have dispersive power. The zero $ ^{th} $ order, however is not dispersive, all wavelengths are at the same angle. So the higher order principal maxima are useful in separation of light with different frequency, while the zero $ ^{th} $ is useless on this.

In order to have the higher order  $ m \neq 0 $, from 6-33, put a limit on the applicable wavelength for a certain grating with grating period d:

 $$ \lambda_{max}\leq\frac{d}{m} $$ 

 $ \lambda_{\text{max}} $ is the maximum dispersible wavelength for the m $ ^{th} $ order of P.M.

Here we only consider the dispersion arise from many-slits interference, and treat the single element diffraction factor almost as constant, since it varies much slower with respect to  $ \theta $ comparing with the P.M.

The diffraction pattern for different wavelength at different order m is

like in the figure below:

<div style="text-align: center;"><img src="imgs/img_in_chart_box_249_1183_552_1373.jpg" alt="Image" width="25%" /></div>


The effect of single diffraction elements on the P.M. of various  $ \lambda $ components within same order is almost same (of course this is an

approximation as long as the two wavelengths are close).

That's why we only consider the  $ \tilde{N}(\theta) $ part here for  $ \theta $ varies over a limited range. Certainly the single diffraction element has its effect. You go to higher order of P.M, the intensity drops due to the decrease of  $ \tilde{\mu}(\theta) $. Even within the same order, if  $ \theta $ varies over large range for various  $ \lambda $,  $ \tilde{\mu}(\theta) $ can be quite different.

Though the single slit diffraction also has some dispersion power for the sub-maxima, however not only it suffers great intensity loss (the secondary maxima is only a small percent of Major maximum in single slit diffraction, the major maximum however is not dispersive.), but has less resolution compared with the multi-slits interference term as well. So the high resolution of grating is due to interference among multiple slits. This is in close analogy to the two beam interference like Young's double slits and the multi-beam interference in Fabry-Perot. The double slit Young's Experiment, though different freq. of light appears at different location, but the resolution is poor, very low Finesse, F; F-P on the other hand has much higher F due to multi-beam interference.

We shall see that the grating in many ways, is very much like the F-P interferometer.

(2) Chromatic Dispersion of Grating

 $$ D_{\theta}=\frac{\delta\theta}{\delta\lambda}\quad\mathrm{Angular~Dispersion} $$ 

The larger  $ D_{\theta} $, the more effective to separate different freq. of light

 $$ d\cos\theta_{m}\delta\theta=m\delta\lambda $$ 

From (6-33):

 $$ \delta\theta=\frac{m\delta\lambda}{d\cos\theta_{m}} $$ 

 $$ \therefore D_{\theta}=\frac{m}{d\cos\theta_{m}} $$ 

 $$ D_{l}\equiv\frac{\delta l}{\delta\lambda}=f D_{\theta}=\frac{m f}{d\cos_{\theta}} $$ 

 $ D_{l} $ is called linear dispersion and f is the focal length of the lens in use.

<div style="text-align: center;"><img src="imgs/img_in_image_box_270_603_681_822.jpg" alt="Image" width="34%" /></div>


Dₗ is usually in unit of mm/Å, (i.e. if the wavelength of light differs by 1 Å, how much the mᵗʰ P.M separated in space in millimeter). Sometimes in the specification of a spectrometer, it usually specifies the 1/Dₗ in unit of Å/1mm.

(3) Chromatic Resolution

The P.M is not a single line, it has width.

The half angular width of the P.M's is given by (6-35)

 $$ \Delta\theta=\frac{\lambda}{Nd\cos\theta} $$ 

The  $ \delta\theta $, the angular separation of two different  $ \lambda $ is given by (6-38)

and Rayleigh criteria for resolution are:

 $$ \delta\theta\geq\Delta\theta $$ 

This condition gives the minimum resolvable wavelength difference  $ \delta\lambda_{m} $ and resolving power.

 $$ \begin{aligned}&\frac{m\delta\lambda_{m}}{d\cos\theta}=\frac{\lambda}{Nd\cos\theta}\\ &\delta\lambda_{_{m}}=\frac{1}{mN}\lambda\\ &\frac{\lambda}{\delta\lambda_{_{m}}}=mN\\ \end{aligned} $$ 

m is the order of the P.M., and N is total number of the diffraction elements

(4) Free Spectral Range.

 $$ d\sin\theta=m\lambda $$ 

The maximum dispersible  $ \lambda_{\max}=d $ (1st order,  $ \theta=90^{\circ} $). It is the maximum dispersible wavelength corresponding to the maximum diffraction angle.

As $\theta$ decreases from $90^{\circ}$, it corresponds to smaller $\lambda$, there is a one-to-one correspondence between diffraction angle and wavelength, such one-to-one relationship enable us to tell the wavelength from measuring diffraction angle. But this nice one-to-one relationship ceases to exist when it reaches certain wavelength which I call $\lambda_{\min}$ for this order, where $d = \lambda_{\max}^{1st} = 2\lambda_{\min}^{1st} = 2\lambda_{\max}^{2nd}$, i.e. the first order of $\lambda_{\max}$ overlaps with the second order and $\lambda_{\max}^{2nd} = \lambda_{\min}^{1st}$. This is better be illustrated by an example,

For a grating with 1200 lines/mm→d~8000Å. Then the maximum measurable in the first order is  $ \lambda_{\text{max}}^{1st} \sim 8000 $ Å, between 8000 Å-4000 Å, each λ only corresponds to a single θ, there is 1↔1 relation between λ,θ. However as λ reaches below 4000 Å, each λ may correspond to multiple values of θ. θ₁ for the first order, θ₂ for the second order …. Reversely, below  $ \lambda_{\text{min}}^{1st} = 4000 $ Å, each θ may correspond various λ, λ₁ for 1st order, λ₂ for 2nd order …. This will cause confusion and make the spectral analysis impossible. This puts a limit to the range of wavelength of the input light. The spectral analysis would be unambiguous if the incoming light’s wavelength falls within the free-spectral-range of the spectrometer.

The free spectral range is the wavelength (or freq.) range that corresponds to the same order of m, so that within this range, the 1↔1 relation between λ,θ holds.

 $$ \begin{aligned}&d\sin\theta_{max}=m\lambda_{m}=(m+1)\lambda_{m+1}\\ &\quad\Delta\lambda_{fsr}=\lambda_{m}-\lambda_{m+1}=\frac{\lambda_{m+1}}{m}=\frac{\lambda_{m}}{m+1}\\ \end{aligned} $$ 

 $ \lambda_m $ is the max. dispersible wavelength for the  $ m^{\text{th}} $ order

In frequency ( $ v_m = \frac{c}{\lambda_m} $), then:

 $$ \Delta v_{fsr}=\frac{V_{m}}{m}\quad(6-42) $$ 

(v is the smallest freq. in the mth order)

Thus, as it seems that the chromatic resolution can be improved by

increasing the order of the grating m, as in (6-40), the free spectral range

narrows.

Comparison between Grating and Fabry-Perot

Dispersion

Relation

Chromatic

 $$ \frac{\delta\theta}{\delta\lambda}=\frac{m}{d\cos\theta}\quad 夢 \quad\frac{\delta h}{\delta\lambda}=\frac{m}{2n} $$ 

Resolution

Free Spectral Range  $ \Delta v_{fsr} = \frac{C}{d \sin \theta} \quad \Delta v_{fsr} = \frac{C}{2nh} = \frac{V_{m}}{m} = \frac{V_{m}}{m} $

It is clear that for grating, its finesse is N, the total number of diffraction elements, or equivalently the number of elements taking part in interference. The higher N there is, the more interfering elements and the higher finesse are. This is analogous to the F-P, since in F-P, F is determined by R, higher R, and more reflected beams in interference.

The Finesse of grating is N can also be proven by the definition of it, the ratio between separation of principle maxima and its half angular width.

 $ \Delta\beta = \pi $ for the adjacent P.M.

 $$ \delta\beta=\frac{\pi}{N}\ (\mathrm{see~6-34})\ \mathrm{half~angular~width~in}\ \beta $$ 

 $$ \mathrm{The~F_{grating}=\frac{\Delta\beta}{\delta\beta}=N~} $$ 

The F-P interferometer usually has higher F, or better chromatic resolution, due to large m and F, but it has much smaller free spectral range (2nh~cm,  $ \Delta\nu_{fsr} \sim 10^{10} $ Hz for F-P;  $ d\sin\theta \sim \mu m $,  $ \Delta\nu_{fsr} \sim 10^{14} $ Hz for grating)

So the grating spectrometer can scan larger spectral range and is very useful in spectroscopy.

### 6 -5-2-3. Blazed Grating

(Fig 10.36, 10.37, 10.38, Hecht's)

Purpose: Overlap the major maximum of the single element diffraction (maximum of the  $ \frac{\sin\alpha}{\alpha} $ term) with the higher order of the principal maxima.

In the conventional transmitting type grating, the maximum of single element diffraction overlaps with the non-dispersive zero $ ^{th} $ order of P.M;

the dispersive part of higher order P.M suffers intensity loss due to the smaller  $ \mu(\theta) $, thus most energy is wasted. This can be rectified in blazed grating and most practical spectrometer uses this type of grating.

## (1) General treatment of reflecting grating

Let's first consider a plain mirror type reflection, but treat it using diffraction method.

 $ \theta_{m},\theta_{i} $ are diffracted and incident angles and they are measured from the  $ \overline{N} $, the direction of base normal.

<div style="text-align: center;"><img src="imgs/img_in_image_box_175_660_1049_1386.jpg" alt="Image" width="73%" /></div>


 $$ \begin{aligned}&\Delta L=\overline{A}\overline{B}-\overline{C}\overline{D}\\ &=d(\sin\theta_{m}\mp\sin\theta_{i})\\ \end{aligned} $$ 

The zero $ ^{th} $ P.M. is at  $ \theta_{m} = \theta_{i} $, for the flat reflecting surface as drawn above, this is also the direction of the major maximum of the single element

diffraction (recall that the single element maximum is always in the direction according to the geometric optics). In this case, it is not different much from the transmitting grating. It is also interesting to see the geometric mirror reflection can be derived from wave-optics multi-elements diffraction, and this is left as exercise for students (using fact of d=a, the spacing between elements equals elements width and missing order).

The blazed grating as depicted in the figure below (also in Fig 2.3, Zhao's book or 10.37, 10.38, Hecht's) will shift the major maximum of the single element from zero $ ^{th} $ order P.M. It works as follow:

<div style="text-align: center;"><img src="imgs/img_in_image_box_231_778_1059_1206.jpg" alt="Image" width="69%" /></div>


The incident light is along  $ \vec{n} $, the facet normal (this is one of the typical arrangement of incoming light, we can call it type 1 illumination)

Where is the major maximum of single element diffraction?

Where is the zero $ ^{th} $ order of P.M?

The major maximum of diffraction by single element is also the

direction of incident light, $\theta_{b}$ above the base normal $\vec{N}$; The zero$^{th}$ order P.M. is $\theta_{b}$ below the $\vec{N}$, as indicated by dashed arrow, according to 6-44, setting $m=0$ there and find the diffracted angle for the $0^{th}$ P.M.(or $- \theta_{b}$, - means below $\vec{N}$)

Now, the direction  $ +\theta_b $ (above  $ \overline{N} $) would correspond to higher order of P.M. for certain  $ \lambda $, using 6-44, but with  $ \theta $ on the same side of  $ \overline{N} $:  $ d2\sin\theta_b = m\lambda $ (6-45)

Now the major maximum of single element diffraction overlaps with higher order of P.M. for certain wavelength of light. For example, if we need to analyze the light around 600nm, and using  $ 1^{st} $ order (m=1), the grating constant d=800nm, then the blazed angle can be determined with (6-45) for type 1 illumination, it is  $ \arcsin(\frac{600}{1600}) $.

There is another arrangement for incoming light (type 2 illumination):

<div style="text-align: center;"><img src="imgs/img_in_image_box_221_1001_1011_1410.jpg" alt="Image" width="66%" /></div>


<div style="text-align: center;"> $ \theta_{i}=0 $ in this case. The incoming light is along the base normal direction.</div>


The zero $ ^{th} $ order P.M. is also along  $ \theta = 0 $

The major max. of single element diffraction:  $ 2\theta_{b} $

The  $ m^{th} $ P.M. in this direction is:

 $$ d(\sin2\theta_{b}-\sin\theta_{i})=d\sin2\theta_{b}=m\lambda $$ 

In the example above but for type 2 illumination, the blazed angle will be  $ \frac{1}{2}\arcsin(\frac{600}{800}) $.

Starting with (6-44), we can derive the chromatic dispersion, resolution, ... for the reflection type grating, they will be the same as those in transmitting case.

### 6 -5-2-4. Blazed Grating Spectrometer

<div style="text-align: center;"><img src="imgs/img_in_image_box_193_899_832_1228.jpg" alt="Image" width="53%" /></div>


<div style="text-align: center;">Figure 10.32 The Littrow autocollimation mounting.</div>


The working principles have been discussed in the sections above. Refer to the book for description and use the homework as practice.

## Chapter 7 Fourier Optics

(Zhao's, Chap 5, §1-§5; Hecht's 7.3, 7.4.1; Chap 11: 11.2, 11.3)

Here I only intend to introduce the Fourier optics quite briefly. The detailed derivation and discussion are both out of the scope this course, and should be addressed in a complete course, and out of the range of my expertise.

First I shall make a brief discussion on Fourier Transform, simply give out the important results without rigorous math derivation. Then I shall continue to its application in optics, especially focus on the relation with Fraunhoffer diffraction.

It is a nice and important example and is sufficient enough to illustrate many important concepts.

## 7 -1 Fourier Expansion (Fourier Series) and Fourier integrals

(Hecht 7.3, 7.4.1, 11.2; Zhao's §5, chap 5, Vol II)

For an arbitrary function, say $f(x)$, $x$ is some general variable, it is sometimes very useful expanding it into series, i.e. into components of simpler functions. One famous one is Taylor expansion, $f(x)$ is expanded into polynomial form, with the coefficient of component $x^{m}$ corresponds to $\frac{d^{m}f}{dx^{m}}$.

Such expansion can be useful in physics. As we already mentioned before, that for a potential  $ V(x) $, close to the equilibrium point, it can be approximated by  $ Ax^{2} $, a harmonic potential.

<div style="text-align: center;"><img src="imgs/img_in_image_box_201_359_358_470.jpg" alt="Image" width="13%" /></div>


much like harmonic potential.

Another very useful expansion is to express $f(\mu)$ in terms of sinusoidal functions $\sin\kappa\mu$, $\cos\kappa\mu$ or $e^{i\kappa\mu}$, here $\mu$ is some general variable, $\kappa$ is the general angular frequency, where $\kappa=2\pi f$, $f$ is the generalized frequency.

If  $ \mu \to t $, then  $ \kappa \to \omega, e^{i\kappa\mu} \to e^{i\omega t} $ harmonic oscillation.

If  $ \mu \rightarrow x $, the spatial dependent of wave,  $ \kappa \rightarrow k = \frac{2\pi}{\lambda} $,  $ e^{i\kappa\mu} \rightarrow e^{i\kappa x} $

wave vector

If $\mu \to x$, the general coordinate of a spatial distribution, such as a pattern on the screen, then $\kappa$ is the spatial angular frequency of the distribution, $\kappa = 2\pi f = 2\pi f = 2\pi \frac{1}{d}$, where $f$ the spatial freq., $d$ is the

<div style="text-align: center;"><img src="imgs/img_in_image_box_368_1211_643_1301.jpg" alt="Image" width="23%" /></div>


spatial period,

Such expansion of  $ f(x) $ generally takes the form of:

 $$ f(x)=\sum_{n=-\infty}^{+\infty}C_{n}e^{ikx},\left\{\begin{aligned}C_{n}&=\frac{1}{2}(A_{n}-iB_{n})\\ C_{-n}&=\frac{1}{2}(A_{n}+iB_{n})\end{aligned}\right.,n>0 $$ 

 $$ C_{0}=A_{0}/2 $$ 

The expansion is Fourier expansion (see below for detail).

## 7 -1-1 Fourier Expansion of a Periodic Function

 $ f(x) $ is a periodic function of  $ x $, i.e.  $ f(x + \lambda) = f(x) $,  $ \lambda $ is the period, then  $ k = 2\pi f = \frac{2\pi}{\lambda} $.

For such periodic function, $f(x)$ can be expanded into series of $\sin(nkx), \cos(nkx)$, or $e^{inkx}$, the harmonic components with different frequency, the frequency is a multiple of the fundamental frequency $k$.

i.e.:

 $$ f(x)=\frac{A_{0}}{2}+\sum_{n=1}^{\infty}A_{n}\cos n k x+\sum_{n=1}^{\infty}B_{n}\sin n k x $$ 

n is integer.

 $$ \begin{aligned}\mathbf{or}\quad&f(x)=\sum_{n=-\infty}^{+\infty}C_{n}e^{ikx},\left\{\begin{aligned}C_{n}=&\frac{1}{2}(A_{n}-iB_{n})\\ C_{-n}=&\frac{1}{2}(A_{n}+iB_{n})\end{aligned}\right.,n>0\\&C_{0}=A_{0}/2\end{aligned} $$ 

Of course there is one issue whether such series expansion convergent, i.e. the series closely resemble the original function  $ f(x) $. This question is a complexed mathematical problem and we shall not consider it here. The Strategy is “assume” such series exist and convergent (For the functions

you encounter in physics, the above is true. Actually for piece-wise continuous function, Fourier series (or integral) exist).

The question now is what are the coefficients  $ A_{n}, B_{n} $ of each frequency component  $ \left[\frac{A_{0}}{2}\right. $ is the DC component (direct current)]. They can be evaluated by applying the orthogonal condition of sine, cosine functions, i.e.:

 $$ \begin{aligned}&\int\limits_{0}^{\lambda}\sin akx\cos bkxdx=0,a,b are integers\\&\int\limits_{0}^{\lambda}\sin akx\sin bkxdx=\frac{\lambda}{2}\delta_{ab}\\&\int\limits_{0}^{\lambda}\cos akx\cos bkxdx=\frac{\lambda}{2}\delta_{ab}\\&\begin{cases}\delta_{ab}=0(a\neq b)\\\delta_{ab}=1(a=b)\end{cases}the Kronecker delta.\end{aligned} $$ 

Then the  $ A_{n}, B_{n} $ can be calculated easily:

 $$ \begin{array}{l l}\int\limits_{0}^{\lambda}f(x)\cos m k x d x=\frac{\lambda}{2}A_{m}&\int\limits_{0}^{\lambda}f(x)d x=\frac{\lambda}{2}A_{0}\\ \int\limits_{0}^{\lambda}f(x)\sin m k x d x=\frac{\lambda}{2}B_{m}\end{array} $$ 

 $$ \begin{cases}A_{m}=\displaystyle\frac{2}{\lambda}\int\limits_{0}^{\lambda}f(x)\cos mkxdx\leftarrow\quad(7-4.1)\\B_{m}=\displaystyle\frac{2}{\lambda}\int\limits_{0}^{\lambda}f(x)\sin mkxdx\end{cases} $$ 

When we find the Fourier series expression for a function, we can use Euler formula to re-express the expansion in terms of  $ e^{imkx} $, and here m can take both positive and negative values, the expansion coefficients are

in (7-2), but can be more readily expressed using orthogonal relations:

 $$ \int\limits_{-\frac{\lambda}{2}}^{\frac{\lambda}{2}}e^{i(m-n)kx}dx=\lambda\delta_{mn} $$ 

 $$ C_{n}=\frac{1}{\lambda}\int\limits_{-\frac{\lambda}{2}}^{\frac{\lambda}{2}}f(x)e^{-inkx}dx $$ 

This procedure is really analogous to finding the components of a vector in an orthonormal basis. Here the function  $ f(x) $ is analogous to arbitrary vector; the sinusoidal functions are “base vectors”, and (7-3) is the orthogonal condition for the base vectors. (7-4) is like finding the components by dot product.

If $f(x)$ possess certain symmetry, i.e. if $f(x)$ is even function with respect to $(x)$, $f(x)=f(-x)$, then clearly $B_m=0$ (only cosine left); if $f(x)$ the odd function: $A_m=0$ (only sine left).

The symmetry sometimes simplifies the evaluation.

<div style="text-align: center;">Example 1. For the square wave in Hecht's Fig 7.18</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_208_1212_835_1479.jpg" alt="Image" width="52%" /></div>


 $$ f(x)=\left\{\begin{aligned}&+1(0<x<\frac{\lambda}{2})\\ &-1(\frac{\lambda}{2}<x<\lambda)\end{aligned}\right. $$ 

The Fourier expansion of f(x) then is (see the Hecht's book for detail)

 $$ f(x)=\frac{4}{\pi}(\sin kx+\frac{1}{3}\sin3kx+\frac{1}{5}\sin5kx+\ldots)\quad k=\frac{2\pi}{\lambda} $$ 

Figure below shows the Matlab graphical results, a single harmonic  $ \sin kx $ is a poor approximation for the square wave, however, as the number of harmonic increases, the summation looks more like the square wave (the figure is the Matlab result for first 2, 3 and 10 sine components)

<div style="text-align: center;"><img src="imgs/img_in_chart_box_211_785_835_1036.jpg" alt="Image" width="52%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_212_1056_836_1264.jpg" alt="Image" width="52%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_210_151_760_601.jpg" alt="Image" width="46%" /></div>


Example 2. The response of a low pass filter to the square wave input as given in the last example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_210_853_627_971.jpg" alt="Image" width="35%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_508_1019_855_1151.jpg" alt="Image" width="29%" /></div>


 $ V_{in} $ is the input in forms of

then what is  $ V_{out} $, the RC circuit forms a low pass filter that cuts freq. at

 $ \omega_{0}=\sqrt{RC} $



The square wave by Fourier analysis can be treated as superposition of many harmonic components, and the expansion is given in the previous example, basically it contains  $ \omega,3\omega,5\omega\ldots $ components. The low pass filter will truncate higher frequency component, say  $ m\omega $, (i.e.

 $ \omega_0 = m\omega $, the  $ V_{out} $ then would be a summation of the truncated series and would distort from the original the output, and  $ V_{out} $ would be something like given in the figure above.

Example 3. Forced oscillator under periodic driving force.

Earlier in the course, we discussed the oscillation of a oscillator driven by a harmonic force, i.e.:

 $ m\ddot{x}+\gamma\dot{x}+kx=F(t) $, where  $ F(t)=F\cos\omega t $ Harmonic driving force.

 $ x \propto A \cos(\omega t + \phi) $

Now, what happens if the $F(t)$ is periodic not necessarily harmonic?

The solution to the problem is simple, since we can expand $F(t)$ into

Fourier Series, which has components of $\cos\omega t$, $\sin\omega t$, $\cos2\omega t$, $\sin2\omega t,....$

For each $\cos m\omega t$, the solution is known, the final solution would be

superposition of them.

From the discussions above, we can see that the usefulness of Fourier Expansion. The system response to harmonic functions, i.e.  $ \sin \kappa x, \cos \kappa x $ or  $ e^{i\kappa x} $ sometimes are much easier to evaluate; then for the linear system knowing its harmonic response, (linear here means: if the system response to input signals  $ S_1 $ is  $ R(S_1) $; then for the multiple inputs, the response is:  $ R(S_1 + S_2 + S_3 + \ldots) = R(S_1) + R(S_2) + R(S_3) + \ldots $) the response to summation of input equals to the summation of response to the individual components. Then using Fourier Expansion, the system's

response to other functions will be known too.

For such periodic function $f(x)$, with frequency $\kappa$, the harmonic components in Fourier expansion are discrete, i.e. only $m\kappa$, the integer multiple of $\kappa$, another way to say this is that its Fourier Spectrum is discrete.

Not only periodic function, but also functions  $ f(x) $ that only defines in a limited space, has discrete Fourier Spectrum. To see this, take a look of the example

 $$ f(x)=\left\{\begin{aligned}&x(|x|<\frac{L}{2})\\ &undefined(|x|>\frac{L}{2})\end{aligned}\right. $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_626_677_972_848.jpg" alt="Image" width="29%" /></div>


For such $f(x)$, it can be treated as periodic, with period of $L$ (or $mL$) (certainly many ways to construct such periodic function, but in the $|x|<\frac{L}{2}$ region, $f(x)$ is fixed). Then the Fourier Expansion for periodic function applies here too, with fundamental frequency of $\kappa=\frac{2\pi}{L}$ (or $\frac{2\pi}{mL}$ depending on the construction).

## 7 -1-2 Non-periodic functions – Fourier Transform (Fourier Integral)

We shall see in this section that for the non-periodic functions, the Fourier spectrum would become continuous, i.e. for component  $ e^{ikx} $, its

κ can take any value, not discrete any more. And the Fourier Series represented in (7-1), (7-2) becomes Fourier Integral, and the Fourier Expansion would become Fourier Transform.

A non-periodic function can be thought as a periodic function with period  $ \lambda \to \infty $. For example, as given in Hecht's 7.3, Fig 7.32, a square wave

<div style="text-align: center;"><img src="imgs/img_in_image_box_186_464_1012_636.jpg" alt="Image" width="69%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_179_672_417_817.jpg" alt="Image" width="20%" /></div>


This is a periodic function as $\lambda \to \infty$. With limited $\lambda$, the Fourier Expansion into $e^{i\kappa x}$, $\kappa = 2\pi/\lambda$ components (here and what follows I shall choose $\kappa$ to represent angular frequency for the general variable, and reserve $k$ for the wave vector of light), with discrete spectrum, as shown in periodic case. As $\lambda$ increases, $\kappa = \frac{2\pi}{\lambda}$ decreases, the spacing between the discrete $n\kappa$ components which is simple $\kappa$, and decreases. As $\lambda \to \infty$, $\Delta\kappa \to 0$ ($\Delta\kappa = (n+1)\kappa - n\kappa = \kappa$).

i.e. the Fourier spectrum becomes continuous, see figure below (Fig 7.32(c) Hecht’s) for such trend, The discrete coefficients $C_n$ for $e^{inkx}$ components will become a function of $\kappa$, i.e. $C_n \to F(\kappa)$ representing the distribution of the $\kappa$ components.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_193_172_689_444.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_192_495_692_769.jpg" alt="Image" width="42%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_187_835_717_1113.jpg" alt="Image" width="44%" /></div>


<div style="text-align: center;">(c)</div>


<div style="text-align: center;">Mathematically, it can easily be proved by:</div>


For non-periodic function $f(x)$, it is a limiting case for $\lambda \to \infty$. Starting with limited $\lambda$:

 $$ f(x)=\sum_{n=-\infty}^{+\infty}C_{n}e^{in\kappa x}\quad Fourier Expansion7.2 $$ 

where  $ C_{n}=\frac{1}{\lambda}\int_{-\frac{\lambda}{2}}^{\frac{\lambda}{2}}f(x)e^{-i n k x}dx $ (7.4.2)

Let  $ \lambda C_{n}=F_{n}\equiv F(\kappa_{n})=\int\limits_{-\frac{\lambda}{2}}^{\frac{\lambda}{2}}f(x)e^{-i\kappa_{n}x}dx $

where  $ \kappa_{n}=n\kappa $

 $$ f(x)=\frac{1}{\lambda}\sum_{n=-\infty}^{+\infty}F(\kappa_{n})e^{i\kappa_{n}x}=\frac{1}{2\pi}\sum_{n=-\infty}^{+\infty}F(\kappa_{n})e^{i\kappa_{n}x}\Delta\kappa_{n} $$ 

where  $ \Delta\kappa_{n}=\kappa_{n+1}-\kappa_{n}=\kappa=\frac{2\pi}{\lambda} $

Now as $\lambda \to \infty$, $\Delta \kappa_n \to 0$, and we should treat $\kappa_n$ as continuous variable $\kappa$ and $\Delta \kappa_n \to d\kappa$, the $\sum_{n=-\infty}^{+\infty} \to \int_{-\infty}^{+\infty}$. The above relation becomes:

 $$ f(x)=\frac{1}{2\pi}\int_{-\infty}^{+\infty}F(\kappa)e^{i\kappa x}d\kappa $$ 

 $$ F(\kappa)=\int_{-\infty}^{+\infty}f(x)e^{-i\kappa x}dx $$ 

(These are same as Zhao’s 5.5, but with  $ d\kappa $ rather than  $ df $, which  $ d\kappa = 2\pi df $)

(7-5) and (7-6) are the definition of Fourier Transform between $f(x)$ and $F(\kappa)$. $F(\kappa)$ is called the Fourier Transform of $f(x)$, knowing $f(x)$, its Fourier Transform can be evaluated by (7-6); Relation (7.5) is the reverse Fourier Transform, i.e. knowing $F(\kappa) \to f(x)$ by (7.5).

Another useful definition of Fourier Transform is to take symmetric

form for Fourier Transform and reverse transform.

 $$ f(x)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}F(\kappa^{\prime})e^{i\kappa^{\prime}x}d\kappa^{\prime} $$ 

 $$ F(\kappa^{\prime})=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}f(x)e^{-i\kappa^{\prime}x}dx $$ 

(7.5'), (7.6') is another definition for the transform, and will be frequently used by me. The two definitions in (7.5), (7.6) and (7.5') are equivalent, except a difference in common factor. Say if $f(x)$ is fixed then $F(\kappa')$ in (7.5') is $\frac{1}{\sqrt{2\pi}}F(\kappa)$ in (7.5)

Sometimes we shall use short hand:

 $ F(k) = \mathcal{F}[f(x)] $ to represent 7.6' for  $ f(x) $'s Fourier Transform.

 $ f(x) = \mathcal{F}^{-1}[F(\kappa)] = \mathcal{F}^{-1} \mathcal{F}[f(x)] $ to represent reverse Fourier Transform.

Using (7.5'), (7.6'), it is straight forward to evaluate the Fourier Transform $F(\kappa)$ given $f(x)$ or reverse. Some examples of typical function $f(x)$, and its Fourier transform are given in Zhao's book, Table V-3, pg. 92, Vol. II and copied below. Noticed that there is a trivial difference in Fourier Transform given here and in Zhao's book, section §5. There he uses frequency $f$, rather than angular freq. $\kappa=2\pi f$ as here for the variable in Fourier Transform, the results are same, up to a common factor depending on using (7.5) or (7.5').

<div style="text-align: center;">表 V-3 典型函数的傅里叶变换</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>原 菌 数</td><td style='text-align: center; word-wrap: break-word;'>频 谱</td><td style='text-align: center; word-wrap: break-word;'>有效宽度</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(1) 方垒函数</td><td style='text-align: center; word-wrap: break-word;'>$ G(f) = A_0 \frac{\sin\alpha}{a} $</td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x = a $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ g(x) = \begin{cases} A, &amp; \text{当} |x| &lt; a/2 \\ 0, &amp; \text{当} |x| &gt; a/2 \end{cases} $</td><td style='text-align: center; word-wrap: break-word;'>$ a = \pi f_a $</td><td style='text-align: center; word-wrap: break-word;'>$ \Delta f = 1/a $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(1&#x27;)</td><td style='text-align: center; word-wrap: break-word;'>当  $ |x| &lt; a/2 $</td><td rowspan="2"><img src="imgs/img_in_image_box_701_430_834_604.jpg" alt="Image"" /></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ g(x) = \begin{cases} <img src="imgs/img_in_image_box_667_1099_752_1239.jpg" alt="Image"" /> &amp; \text{当} |x| &gt; a/2 \\ <img src="imgs/img_in_image_box_775_998_917_1180.jpg" alt="Image"" /> &amp; \text{当} |x| &lt; a/2 \end{cases} $</td><td style='text-align: center; word-wrap: break-word;'>$ G(f) = A_a \frac{\sin\alpha}{a&#x27;} $</td></tr></table>

续表


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>原 函 数</td><td style='text-align: center; word-wrap: break-word;'>频 谱</td><td style='text-align: center; word-wrap: break-word;'>有效宽度</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(2) 准单色函数</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  g(x) = \begin{cases} A \cos x &amp; f(x), &amp; \text{当} |x| &lt; L/2 \\ 0, &amp; \text{当} |x| &gt; L/2 \end{cases}  $</td><td style='text-align: center; word-wrap: break-word;'>$  G(f) = \frac{1}{2} AL \left( \frac{\sin a_{+}}{a_{+}} + \frac{\sin a_{-}}{a_{-}} \right)  $</td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x = L $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(3) 正向准单色函数</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  g(x) = \begin{cases} A(1 + \gamma \cos x / 0.x), &amp; \text{当} |x| &lt; L/2 \\ 0, &amp; \text{当} |x| &gt; L/2 \end{cases}  $</td><td style='text-align: center; word-wrap: break-word;'>$  G(f) = AL \left[ \frac{\sin a_{0}}{a_{0}} + \frac{\gamma}{2} \left( \frac{\sin a_{+}}{a_{+}} + \frac{\sin a_{-}}{a_{-}} \right) \right]  $</td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x = L $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{2} \frac{1}{2} \frac{1}{2} \frac{1}{2} \</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

綝


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>原函数</td><td style='text-align: center; word-wrap: break-word;'>频谱</td><td style='text-align: center; word-wrap: break-word;'>有效宽度</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(4) 高斯函数 $ g(x) = A \exp(-ax^2) $</td><td style='text-align: center; word-wrap: break-word;'>$ G(f) = A \sqrt{\frac{\pi}{a}} \exp(-\pi) $</td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x = 2 / \sqrt{\frac{a}{a}} $  $ \Delta f = 2 \sqrt{\frac{a}{a}} / \pi $  $ \Delta f \Delta x = 4 / \pi $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(5) 洛伦兹函数 $ g(x) = \frac{A}{a^2 + x^2} $</td><td style='text-align: center; word-wrap: break-word;'>$ G(f) = \frac{A \pi}{a} \exp(-2 \pi a) f $</td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x = 2a $  $ \Delta f = 1 / a \pi $  $ \Delta f \Delta x = 2 / \pi $</td></tr></table>

脈


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>原 函 数</td><td style='text-align: center; word-wrap: break-word;'>频 谱</td><td style='text-align: center; word-wrap: break-word;'>有效宽度</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(8) 角形函数</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ g(x)=\begin{cases}A\left(1-\frac{|x|}{a}\right),&amp; 当 |x|&lt;a\\0,&amp; 当 |x|&gt;a\end{cases} $ <img src="imgs/img_in_image_box_499_1042_649_1236.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'>$ G(f)=A\alpha^{1}\left(\frac{\sin\alpha}{a}-\right)^{2} $ <img src="imgs/img_in_image_box_407_390_572_620.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x=\alpha $  $ \Delta f=1/a $  $ \Delta f \Delta x=1 $</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(7) 椭圆形函数</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_776_1155_869_1374.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'>当  $ |x|&lt;a $ 当  $ |x|&gt;a $ <img src="imgs/img_in_image_box_746_891_906_1058.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'>$ G(f)=A\pi\alpha^{1}\frac{f_{1}(a)}{a} $  $ a=2\pi f_{0} $  $ f_{1} $ 为一阶贝塞耳函数 <img src="imgs/img_in_image_box_735_430_891_614.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x=2a, $  $ \Delta f=0.6/a $  $ \Delta f \Delta x=1.2 $</td></tr></table>

燊煐


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>原 函 数</td><td style='text-align: center; word-wrap: break-word;'>频 谱</td><td style='text-align: center; word-wrap: break-word;'>有效宽度</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>(8) 阻尼振荡函数 $ g(x)=\begin{cases}A e^{-x\cos2\pi f_s x},&amp;当x&gt;0\\0,&amp;当x&lt;0\end{cases} $</td><td style='text-align: center; word-wrap: break-word;'>$ G(f)=\frac{A}{2}\left[\frac{1}{\tau+i2\pi(f-f_s)}+\frac{1}{\tau+i2\pi(f+f_s)}\right] $</td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x=1/\tau $  $ \Delta f=\tau/2\pi $  $ \Delta f\Delta x=1/2\pi $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_511_1060_684_1270.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_467_521_617_808.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x=1/\tau $  $ \Delta f=\tau/2\pi $  $ \Delta f\Delta x=1/2\pi $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>[F8]</td><td style='text-align: center; word-wrap: break-word;'>[F6]</td><td style='text-align: center; word-wrap: break-word;'>$ \Delta x=1/\tau $  $ \Delta f=\tau/2\pi $  $ \Delta f\Delta x=1/2\pi $</td></tr></table>

The examples (1)-(3) in the Table V-3, we actually already worked them out when dealing with superposition of waves or Fraunhoffer diffraction by the gratings. The $F(\kappa)$, the Fourier Transform in (1)-(3) looks exactly as the Fraunhoffer diffraction pattern. This should be obvious if you recall how we derive the Fraunhoffer diffraction in the previous chapter, and I shall read address this later. Here, you should realize that such similarity between Fourier Transform $F(\kappa)$ and F-diffraction is no coincidence.

Example (4), (8) are basically:

Gaussian  $ \rightleftharpoons $ Gaussian (The Fourier Transform of Gaussian is still a

Gaussian).

Lorentian  $ \Leftrightarrow $ exponential.

What is clear from these examples are:

(1)  $ F(\kappa) $ is generally a complex function,

i.e.  $  F(\kappa) = |F(\kappa)| e^{i\phi(\kappa)}  $

The dotted line in Table V-3 in example 8,9 are  $ \phi(\kappa) $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_751_991_966_1199.jpg" alt="Image" width="18%" /></div>


(2) If  $ \Delta x $ is the width of  $ f(x) $

 $ \Delta \kappa $ is the width of  $ F(\kappa) $

Then  $ \Delta x \Delta \kappa = \text{constant} $. The value will depend on definition of  $ \Delta x $,  $ \Delta \kappa $. The proof is:

Define  $ \Delta x $ in  $ f(x) $ as:

 $$ \Delta x=\frac{1}{f(0)}\int_{-\infty}^{+\infty}f(x)dx $$ 

 $$ \Delta\kappa\mathrm{~i n~}F(\kappa)\mathrm{~a s:} $$ 

 $$ \Delta\kappa=\frac{1}{F(0)}\int_{-\infty}^{+\infty}F(\kappa)d\kappa $$ 

 $$ F(\kappa)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}f(x)e^{-i\kappa x}dx $$ 

 $$ \rightarrow F(0)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}f(x)dx $$ 

 $$ f(x)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}F(\kappa)e^{i\kappa x}d\kappa $$ 

 $$ \rightarrow f(0)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}F(\kappa)d\kappa $$ 

 $$ \Delta x\Delta\kappa=2\pi\frac{F(0)}{f(0)}\frac{f(0)}{F(0)}=2\pi $$ 

 $$ \mathrm{O r}~\Delta x\Delta f=1~\left(\kappa=2\pi f\right) $$ 

This is the uncertainty relation we referred to a few times earlier.

### 7 -1-3. Dirac Delta Function  $ \delta(x) $

What happens for a square wave, or a cosine wave train as in Table V-3, Zhao’s, (1), (2), if the width of  $ \Delta x $ increases, clearly  $ \Delta \kappa $, the width of  $ F(\kappa) $ will decrease. What if to an extreme case, that  $ \Delta x \to \infty $, basically the square wave would become a constant A, the cosine wave train would become a  $ \cos \kappa_0 x $, their  $ F(\kappa) $ the Fourier transform would become with zero width, infinite amplitude, it would become a Dirac

Delta Function. Dirac Delta Function is a special function describes a

singular physical distribution, it is extremely useful in representing some

physical idealization, such as mass point, single freq. , point charge etc.

(1) Definition of  $ \delta(x) $.

 $$ \begin{aligned}&\delta(x)=\begin{cases}\infty(x=0)\\0(x\neq0)\end{cases}\\ &\int_{-\infty}^{+\infty}\delta(x)dx=1\\ \end{aligned} $$ 

(2)Properties of  $ \delta(x) $.

(a)  $ \delta(x)=\delta(-x) $ even function.

(b)

 $$ \int_{-\infty}^{+\infty}f(x)\delta(x)d x=f(0). $$ 

(c)

c)  $ \int_{-\infty}^{+\infty}f(x')\,\delta(x-x')\,dx'=f(x) $

 $ f(x)\otimes\delta(x) $ convolution.

(d)

 $$ \delta(ax)=\frac{1}{\left|a\right|}\delta(x) $$ 

(e)  $ \delta'(x) = \frac{d\delta(x)}{dx} $, it has property of:

 $$ \int\delta^{\prime}(x)f(x)dx=-f^{\prime}(0)\quad(prove with integration by part) $$ 

These properties are easy to derive from the definition.

(3) Other representation of  $ \delta(x) $.

 $$ \mathcal{F}[\delta(x)]=F(\kappa)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}\underbrace{\delta(x)e^{-i\kappa x}}_{}dx=\frac{1}{\sqrt{2\pi}}\quad(7-9-1) $$ 

 $$ \begin{aligned}&\delta(x)=\mathcal{F}^{-1}[F(\kappa)]\\ &=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}\frac{1}{\sqrt{2\pi}}e^{i\kappa x}d\kappa\\ &=\frac{1}{2\pi}\int_{-\infty}^{+\infty}e^{i\kappa x}d\kappa\\ \end{aligned} $$ 

(7-9-2) is a useful representation of  $ \delta(x) $

The above derivation clearly shows:

 $$ \begin{aligned}\delta(x)&\rightleftharpoons\frac{1}{\sqrt{2\pi}}\quad&(or\quad\delta(x)&\rightleftharpoons1if(7.5),(7.6)are used.This is\\&&the results in Zhao^{\prime}s book).\end{aligned} $$ 

It is also easy to show that, if  $ f(x)=\frac{1}{\sqrt{2\pi}} $, then  $ \mathcal{F}[f(x)]=\frac{1}{2\pi}\int_{-\infty}^{+\infty}e^{-i\kappa x}dx=\delta(-\kappa)=\delta(\kappa) $. So  $ \frac{1}{\sqrt{2\pi}}\rightleftharpoons\delta(x) $ (or  $ 1\rightleftharpoons2\pi\delta(x) $ if (7-5), (7-6) are used, this same as Zhao's book,  $ 1\rightleftharpoons\delta(f) $,  $ \because\delta(\kappa)=\frac{1}{2\pi}\delta(f) $).

This means that for the extremely broad distribution in $f(x)$, for example $f(x)=\mathrm{constant}$, $\Leftrightarrow \delta(\kappa)$ a single frequency in the transform. If the $f(x)=\delta(x)$, a single point in $x$, transform to a constant in $\kappa$ domain, means infinite broad $\kappa$ distribution; Exactly as we stated at the beginning of this session.

 $$ \mathrm{I f}f(x)=\cos\kappa_{0}x=\frac{1}{2}[e^{i\kappa_{0}x}+e^{-i\kappa_{0}x}], $$ 

then the  $ \mathcal{F}[f(x)]\to\delta(\kappa-\kappa_{0})+\delta(\kappa+\kappa_{0}) $ (This can be proved either by the definition of Fourier transform or using the phase shift

property we shall discuss)

Please refer to Zhao’s book Vol.2, Table V-4 on pg. 106. (1)~(5) in the table are straightforward; the (6), (7) of the table are explained in the book by example 5 on pg. 105.

(Note, there is an error in Zhao’s Table V-4, (7), it should be  $ \frac{1}{x_0}G(f)\sum_{n=-\infty}^{\infty}\delta(f-\frac{n}{x_0}) $, not  $ \frac{1}{x_0}G(f)=\sum_{n=-\infty}^{+\infty}\delta(f-\frac{n}{x_0}) $).

There are other representation of  $ \delta(x) $, by using extreme cases of Gaussian, Lorentian or exponential decay, there are listed in Zhao's book pg. 103.

## 7 -1-4 Properties of Fourier Transform

(Zhao’s book, Chap 5, §5.3)

Many of the properties below are self-evident and I shall discuss a little bit of differential property and convolution in detail.

Two functions $g(x), h(x)$ of variable $x$, their Fourier Transforms are $G(\kappa), H(\kappa)$. [or $G(f), H(f)$ as in Zhao's book].

(1) Linearity:

 $$ ag(x)\pm bh(x)\xlongequal{\nwarrow}aG(\kappa)+bH(\kappa)(7-10) $$ 

Means Fourier Transform

(2) Conservation Theory (Parseval's Formula)

 $$ \int_{-\infty}^{+\infty}\left|g\right|^{2}d x=\int_{-\infty}^{+\infty}\left|G(\kappa)\right|^{2}d\kappa $$ 

This can be treated as a result from conservation of energy, so that the total energy analyzed in space is same as analyzed in frequency domain. The formula can be easily derived directly from definition of Fourier Transform.

 $$ \begin{aligned}&|g|^{2}=g(x)g^{*}(x)\\&g^{*}(x)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}G^{*}(\kappa)e^{-i\kappa x}d\kappa\\&\int_{-\infty}^{+\infty}g g^{*}\ dx=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}g(x)[\int_{-\infty}^{+\infty}G^{*}(\kappa)e^{-i\kappa x}d\kappa]dx\\&=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}G^{*}(\kappa)[\int_{-\infty}^{+\infty}g(x)e^{-i\kappa x}dx]d\kappa\\&=\int_{-\infty}^{+\infty}G^{*}(\kappa)G(\kappa)d\kappa\\ \end{aligned} $$ 

A note on this, relation (7-11) is right if we take the definition for Fourier Transforms as given by (7.5'), (7.6'). If we use that of (7.5), (7.6). recall that  $ F(\kappa') = \frac{1}{\sqrt{2\pi}} F(\kappa) $ (Define by 7.6 and 7.6'), then relation (7.11)  $ \rightarrow \int_{-\infty}^{+\infty} |g(x)|^2 dx = \frac{1}{2\pi} \int_{-\infty}^{+\infty} |G(\kappa)|^2 d\kappa $.

(3) Expansion of the variable:

 $$ g(ax)\rightleftharpoons\frac{1}{\left|a\right|}G(\frac{\kappa}{a}) $$ 

(4) Phase Shift

 $$ g(x\pm x_{0})\rightleftharpoons e^{\pm i\kappa x_{0}}G(\kappa)\quad(7-13) $$ 

Inversely:  $ e^{\pm i\kappa_{0}x}g(x)\rightleftharpoons G(\kappa\mp\kappa_{0}) $

This relation is useful to get quick result of Fourier transform. The proof is straightforward from definition.

(5) Relation of complex Conjugate:

 $$ \begin{array}{l}g^{*}(x)\rightleftharpoons G^{*}(-\kappa)\\ g^{*}(-x)\rightleftharpoons G^{*}(\kappa)\end{array} $$ 

(6) Fourier Transform of Derivatives

If  $  g(x) \rightleftharpoons G(\kappa)  $

What’s the Fourier Transform  $  G_1(\kappa)  $ for  $  \frac{dg(x)}{dx}  $?

 $$ \begin{aligned}&G(\kappa)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}g(x)e^{-i\kappa x}dx\\ &G_{1}(\kappa)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}\frac{dg(x)}{dx}e^{-i\kappa x}dx\\ &=\frac{1}{\sqrt{2\pi}}e^{-i\kappa x}g(x)\big|_{-\infty}^{+\infty}+\frac{i\kappa}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}g(x)e^{-i\kappa x}dx\\ \end{aligned} $$ 

If  $  g(x) = 0  $ as  $  x \to \pm \infty  $ (which is true in many physical problems).

Then:  $  G_{1}(\kappa) = i\kappa G(\kappa)  $

Similarly:  $  G_{n}(\kappa) = (i\kappa)^{n} G(\kappa)  $

Fourier Transform of  $ \frac{d^{n}g(x)}{dx^{n}} $

We can immediately see that Fourier Transform would be useful in solving Differential Equations. This is better to be illustrated with example and one of the homework.

Example: Solving wave equation:

 $$ \frac{\partial^{2}y}{\partial x^{2}}=\frac{1}{\nu^{2}}\frac{\partial^{2}y}{\partial t^{2}} $$ 

 $ y(x,t) $ is a wave. At  $ t=0,y(x,0)=f(x) $ ( $ f(x) $ is a function of x, this is the initial condition).

The partial differential equation generally is difficult to solve directly,

but we can apply Fourier Transform to simplify it.

The procedures are:

① Taking Fourier Transform on both side of the equation(x ⇌ κ)

 $$ \begin{aligned}&\int_{-\infty}^{+\infty}\frac{\partial^{2}y}{\partial x^{2}}e^{-i\kappa x}dx=\frac{1}{\nu^{2}}\int_{-\infty}^{+\infty}\frac{\partial^{2}y}{\partial t^{2}}e^{-i\kappa x}dx\\ &(i\kappa)^{2}Y(\kappa,t)=\frac{1}{\nu^{2}}\frac{\partial^{2}}{\partial t^{2}}[\int_{-\infty}^{+\infty}ye^{-i\kappa x}dx]\\ &=\frac{1}{\nu^{2}}\frac{\partial^{2}Y(\kappa,t)}{\partial t^{2}}\\ \end{aligned} $$ 

 $ Y(\kappa,t) $ is Fourier Transform of  $ y(x,t) $ with respect to x.

② Solving Differential equation

 $ (i\kappa)^2Y(\kappa,t)=\frac{\partial^2Y(\kappa,t)}{\nu^2\partial t^2} $ This is a much simpler problem, an ODE instead of partial differential equation.

The initial condition for  $ t = 0, y(x, 0) = f(x) $,

 $$ Y(\kappa,0)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}f(x)e^{-i\kappa x}dx=F(\kappa) $$ 

 $$ Y(\kappa,t)=Y(\kappa,0)e^{\pm i\nu\kappa t}=F(\kappa)e^{\pm i\nu\kappa t} $$ 

③ Do an Inverse Fourier Transform to get  $ y(x,t) $ from  $ Y(\kappa,t) $

 $$ \begin{aligned}&y(x,t)=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}F(\kappa)e^{\pm i\kappa t}e^{i\kappa x}d\kappa\\&=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}F(\kappa)e^{i\kappa(x\pm vt)}d\kappa\\&=f(x\pm vt)\\ \end{aligned} $$ 

(You can also directly use (7-13),

the phase shift to get this)

This is exactly the traveling wave form we give at the very beginning of this course.

This demonstrates a typical application of Fourier transform, which can be summarized by the chart below:

<div style="text-align: center;"><img src="imgs/img_in_image_box_211_301_891_676.jpg" alt="Image" width="57%" /></div>


(7) Convolution Theorem

(Hecht's 11.3.2)

The convolution of functions is defined as:

 $$ g(x)\otimes h(x)=\int_{-\infty}^{+\infty}g(x^{\prime})h(x-x^{\prime})dx^{\prime} $$ 

The convolution happens a lot in real physical problems.

Examples to illustrate the convolution:

A. Line shape in Doppler broadened spectrum

<div style="text-align: center;"><img src="imgs/img_in_image_box_245_1230_997_1514.jpg" alt="Image" width="63%" /></div>


If the spectral lines within the Doppler profile are  $ \delta $ lines, i.e. no width, in forms of  $ \delta(\omega-\omega') $, then the absorption line shape would just be the Doppler profile, because  $ \int D(\omega') \delta(\omega - \omega') d\omega' = D(\omega) $. However the real transition in atom/molecule, the line width is not zero, it has line width due to so-called life time broadening (This is essentially caused by the limited life time of the excited states. If you understand what I am talking, excellent; If not, does not matter for the present). So the lines should indeed be not a single  $ \delta $ form line, but a Lorentian type, say  $ L(\omega - \omega') $. The total absorption line shape recorded would then be:

 $$ F(\omega)=\int_{-\infty}^{+\infty}D(\omega^{\prime})L(\omega-\omega^{\prime})d\omega^{\prime}=D(\omega)\otimes L(\omega) $$ 

Same is true for the inhomogeneous broadening of spectrum in solution (liquid) or in crystal.

B. Temporal Response of Detecting System.

<div style="text-align: center;"><img src="imgs/img_in_image_box_220_1058_986_1340.jpg" alt="Image" width="64%" /></div>


Let's suppose we know the  $ \delta(t) $ input generates a response signal in detector, $ S_{0}(t) $, this $ S_{0}(t) $ is the time resolution function of the detecting

system $ ^9 $. We shall assume the system is linear and stationary. Stationary means, the response would be same no matter of the arrival time of signal i.e.  $ \delta(t-t_0) \to S_0(t-t_0) $ same response just shifted in time. (We have discussed linear before). For arbitrary input pulse  $ f(t) $, then what's the response  $ S(t) $?

Since  $ f(t) = \int_{-\infty}^{+\infty} f(t') \delta(t-t') dt' $, so that  $ f(t) $ can be thought as superposition of many  $ \delta $ pulses with  $ f(t') $ as weighting coefficient. Applying the linear and stationary property, the response will be:

 $$ S(t)=\int_{-\infty}^{+\infty}f(t^{\prime})S_{0}(t-t^{\prime})dt^{\prime}=S(t)\otimes f(t) $$ 

This is a very important result telling you that all the signal output of measurement is a convolution between the input signal (f(t) here) and the response function of the instrument. Only when the response function much “narrower” (that is approximately like a delta function) than the input, the output can faithfully reproduce the input.

### C. Image Formation

Consider a linear imaging system with magnification = 1, so that ideally a point source at  $ (x_{0}, y_{0}) $ position  $ \delta(x - x_{0}, y - y_{0}) $ on the objective screen, would form a image at  $ (x_{0}, y_{0}) $ on the screen,  $ \delta(X - x_{0}, Y - y_{0}) $. However, due to diffraction, the image pattern is not a point, but an Airy ring pattern, we use  $ S(x_{0}, y_{0}, X, Y) $ to represent the image pattern formed by a point source at  $ (x_{0}, y_{0}) $ from objective plane. Now if the system is

stationary, that is all $(x_{0},y_{0})$'s form similar pattern only shifted in space. Then $S(x_{0},y_{0},X,Y)$ would be in form of $S(X-x_{0},Y-y_{0})$, which is the response of a $\delta$ input like we discussed in the above.

If the object has form of  $ f(x,y) $, then the image  $ I(x,y) $ would be:

 $$ \begin{aligned}&I(X,Y)=\int f(x^{\prime},y^{\prime})S(X-x^{\prime},Y-y^{\prime})dx^{\prime}dy^{\prime}\\ &=f(x,y)\otimes S(X,Y)\\ \end{aligned} $$ 

The image is a convolution of the object and response function of image formation system (response can be limited due to diffraction), that is why you may get a blurred image. See Fig 11.17 Hecht's for a graphical illustration.

The examples should demonstrate the importance of convolution of functions in physical application. The evaluation of the convolution defined by 7-17, however is not easy if carried out directly. Like solving differential equation case, this can be solved easily in transform space.

Convolution Theorem (Proof left as an exercise):

 $$ \mathrm{If}\quad g(x)\rightleftharpoons G(\kappa);h(x)\rightleftharpoons H(\kappa) $$ 

Then  $  g(x) \otimes h(x) \rightleftharpoons G(\kappa)H(\kappa)  $

So the Fourier Transform of convolution is simply the product of individual transform. So that the convolution can be evaluated by

① work out  $  G(\kappa), H(\kappa)  $

②  $  G(\kappa)H(\kappa) \rightleftharpoons g(x) \otimes h(x)  $ (inverse Fourier Transform).

Example, pg. 104, Zhao’s, (7) in Table V-4.

 $$ \begin{array}{r l r}&{}&{\displaystyle\sum_{n=-\infty}^{+\infty}g(x-n x_{0})=g(x)\otimes\displaystyle\sum_{n=-\infty}^{+\infty}\delta(x-n x_{0})}\\ &{}&{\mathrm{T h e~f u n c t i o n}}\\ &{}&{\displaystyle\rightleftharpoons G(\kappa)\frac{1}{x_{0}}\displaystyle\sum_{n=-\infty}^{+\infty}\delta(\frac{\kappa}{2\pi}-\frac{n}{x_{0}})}\end{array} $$ 

(8) Correlation Theory.

 $$ \begin{aligned}&g(x)*h(x)=\int_{-\infty}^{+\infty}g^{*}(x\prime)h(x+x\prime)dx^{\prime}\\ &=\int_{-\infty}^{+\infty}g^{*}(x\prime-x)h(x\prime)dx^{\prime}\\ &g(x)*h(x)\rightleftharpoons G^{*}(\kappa)H(\kappa)\quad(7-20)\\ \end{aligned} $$ 

Examples of correlation are given in section of Coherent Theory.

## 7 -2 Fraunhoffer Diffraction from Fourier Optics' point of view

The phenomena of interference and diffraction all are arise from the superposition principle of waves. In the treatment, we frequently use equation in forms of:

 $$ \tilde{U}(x^{\prime},y^{\prime},z^{\prime},t)=\iiint\tilde{U}(x,y,z,t)dxdydz $$ 

In such integrals, the  $ \tilde{U}(x,y,z,t) \propto e^{i(kr-\omega t)} $ or can be expanded in forms of  $ e^{i(kr-\omega t)} $. So we would expect Fourier Transform would be very useful in evaluating such problems.

Examples:

① Superposition of waves with different frequency at certain fixed space point, the above integral would become

 $$ G(t)=\int_{-\infty}^{+\infty}g(\omega)e^{-i\omega t}d\omega\longleftarrow\qquad\mathrm{Fourier Transform}\quad G(t)\rightleftharpoons g(\omega) $$ 

② In the superposition of waves to get diffraction pattern

 $$ U(X,Y)=\int\limits_{\Sigma\atop\blacktriangle}U_{\Sigma}e^{-i k r_{\Sigma}}d r_{\Sigma} $$ 

Diffraction screen

 $$ \tilde{U}(X,Y)\rightleftharpoons\tilde{U}_{\Sigma}(x,y) $$ 

i.e. The diffraction pattern on the observing screen would be the Fourier Transform of  $ \tilde{U}_{\Sigma}(x,y) $, the field distribution at the diffraction screen. We shall investigate this in detail in the following discussion, and show that the Fraunhoffer diffraction pattern is indeed the Fourier Transform of the spatial distribution of the diffraction screen (or grating).

## 7 -2-1 Fraunhoffer Diffraction

#### (Zhao’s §2;4. Vol. II)

Previously, we studied the Fraunhoffer Diffraction by some diffraction screens, such as single slit, multi-slits, or cosine gratings etc. We also noticed that the Fraunhoffer diffraction pattern bears great similarity to the Fourier Transform of the diffracting screen. We shall show it here that the Fraunhoffer pattern indeed corresponds to the Fourier Transform of the diffraction screen. i.e. (refer to figure below), every points on the receiving screen in the Fraunhoffer diffraction setup  $ (x', y') $ corresponds to  $ (\kappa_x, \kappa_y) $, where  $ (\kappa_x, \kappa_y) $ are the components of spatial angular frequencies of the diffraction screen  $ (x, y) $ in Fourier Transform;

Or another way to put it:  $ \tilde{U}(x', y') = \tilde{U}(\kappa_x, \kappa_y) = \mathcal{F}[U_0(x, y)] $

## 7 -2-1-1 Setup without Lens

<div style="text-align: center;"><img src="imgs/img_in_image_box_210_277_1004_716.jpg" alt="Image" width="66%" /></div>


For simplicity, we first consider 1-dimension case.

Define: Aperture function.

 $$ t(x)=\frac{\tilde{U}_{\Sigma_{0}}(x)}{\tilde{U}_{i_{0}}(x)} $$ 

If the incoming wave is plane wave normal to  $ \Sigma $,  $ \tilde{U}_{i_{0}}(x)=\mathrm{const} $.

Then  $ \tilde{U}_{\Sigma_{0}}(x)\propto t(x) $.

The aperture function $t(x)$ certainly depends on the diffraction screen, for some typical $\Sigma$'s that we have investigated are:

∑ Single slit

<div style="text-align: center;"><img src="imgs/img_in_image_box_391_1215_785_1348.jpg" alt="Image" width="33%" /></div>


Double point in

<div style="text-align: center;"><img src="imgs/img_in_image_box_520_1386_754_1519.jpg" alt="Image" width="19%" /></div>


 $$ t(x)=\delta(x-x_{0})+\delta(x+x_{0}) $$ 

Young’s Experiment

multi-slits

<div style="text-align: center;"><img src="imgs/img_in_image_box_356_273_669_410.jpg" alt="Image" width="26%" /></div>


$$t(x)=\prod_{k=1}^{n}\otimes\sum_{n=1}^{N}\delta(x-nd)\quad\text{A convolution of single slit with delta functions}$$

cosine grating

<div style="text-align: center;"><img src="imgs/img_in_image_box_366_620_691_712.jpg" alt="Image" width="27%" /></div>


 $$ t(x)=t_{0}+t_{1}\cos\kappa_{0}x $$ 

 $ t(x) $ [or  $ t(x,y) $ for 2-dimensional case] of course will take different forms for other diffraction screens. For an arbitrary  $ \Sigma $ with aperture function  $ t(x) $, the Fraunhoffer diffraction pattern as in setup of figure (on previous page) will be given by the Kirchhoff equation:

 $$ U(x^{\prime})=\frac{C}{R_{0}}\int_{-\infty}^{+\infty}U_{0\Sigma}e^{i k r}d x $$ 

From our previous argument that under paraxial and far field approximation,

 $$ e^{ikr}=e^{ikr_{0}}e^{-i\left(k\frac{xx^{\prime}}{Z_{0}}\right)}=e^{ikZ_{0}}e^{-i\frac{kxx^{\prime}}{Z_{0}}} $$ 

Then if  $ \tilde{U}_{\Sigma_{0}} \propto t(x) $

 $$ U(x^{\prime})\propto\frac{e^{ikZ_{0}}}{Z_{0}}\int\limits_{-\infty}^{\infty}t(x)e^{-ikx x^{\prime}/Z_{0}}dx $$ 

Relation (7-23) is very much like the Fourier Transform of  $ t(x) $ except for a proportional factor:

 $$ \mathcal{F}[t(x)]\propto\int_{-\infty}^{+\infty}t(x)e^{-i\kappa x}d x $$ 

If we define  $ \kappa = \frac{kx'}{Z_0} = k \sin \theta $

Then  $ \tilde{U}(x') = \tilde{U}(\kappa) \propto \mathcal{F}[t(x)] $

Thus, we proved that the diffraction pattern  $ \tilde{U}(x) $ on the receiving screen in Fraunhoffer diffraction is simply proportional to the Fourier transform (or Fourier frequency spectrum) of the aperture function of the diffraction screen  $ t(x) $.

Note ① All the reasoning are rooted from the simple relation of the phase distribution by the secondary spherical wavelets in Huygens-Fresnel principle, given by relation (7-22), this relation is the mathematical definition for the Fraunhoffer diffraction, it holds under paraxial and far field approximation.

② Do not confuse  $ \kappa $ with  $ k $; The  $ \kappa $ is the angular spatial frequency of the diffraction screen  $ t(x) $;  $ k $ is the wave vector (or angular spatial frequency) of the light wave. They are related by equation (7-24). If we use a fixed wavelength light in diffraction, i.e. fixed  $ k = \frac{2\pi}{\lambda} $, then different  $ \kappa $ will correspond to different diffraction angle  $ \theta $.

③ The relation between spatial point $x'$ or $\theta$ on the receiving screen with the angular spatial frequency $\kappa$ of the diffraction screen is given by (7-24), clearly knowing $\tilde{U}(\kappa)=\mathcal{F}[t(x)]$, we would know the diffraction pattern; and reversely knowing the diffraction pattern, we

would know the Fourier transform of $t(x)$. That's why Fraunhoffer Diffraction is called a Fourier Transform Analyzer.

## 7 -2-1-2 Setups with Lens (most common in a real setup)

<div style="text-align: center;"><img src="imgs/img_in_image_box_191_457_1005_805.jpg" alt="Image" width="68%" /></div>


 $ r_{0} $ is the OPL from center of x screen(the diffraction screen) to field point  $ P(x') $.

Still from Kirchhoff equation:

 $$ \tilde{U}(x^{\prime})\propto\frac{1}{f}\int_{-\infty}^{+\infty}t(x)e^{i k r_{0}}e^{-i k x\sin\theta}d x $$ 

Let  $ \kappa = k \sin \theta = \frac{kx'}{f} $ (7-27)

(7.26) becomes  $ \tilde{U}(x') \propto \frac{1}{f} \int_{-\infty}^{+\infty} t(x) e^{ikr_0} e^{-ikx} dx $

Is this a Fourier Transform of $t(x)$? The answer is actually: Not exactly. Because $r_0$ is not a constant, it depends on the $x'$. However we can make it a constant by putting the $\Sigma$ at the front focal point of the lens, i.e. let $S = |f|$ too, then $r_0$ will be independent of $x'$ (Please think

about this reasoning yourself, which just involves geometric optics and Fermat principle. Hint,  $ r_0 $ is the OPL from center of  $ \Sigma $ to the  $ P(x') $, at  $ S = |f| $, for different  $ P(x') $,  $ r_0 = 2f $ is constant).

So if  $ S = |f| $, then we shall have as in previous part,

 $$ U(x^{\prime})=U(\kappa)\propto\mathcal{F}[t(x)]\qquad(7-28) $$ 

The relation between  $ x', \kappa $ is given by (7-27).

For the two dimensional case, similar to the derivation for1-D

 $$ \begin{aligned}&e^{ikr}=e^{ikZ_{0}}e^{-ik\frac{xx^{\prime}+yy^{\prime}}{Z_{0}}}=e^{ikZ_{0}}e^{-ik(\sin\theta_{1}x+\sin\theta_{2}y)}\\&U(x^{\prime},y^{\prime})\propto\int t(x,y)e^{-i\frac{k}{Z_{0}}(xx^{\prime}+yy^{\prime})}dxdy\\&\propto\mathcal{F}[t(x,y)]\\ \end{aligned} $$ 

 $$ \kappa_{x}=\frac{kx^{\prime}}{Z_{0}},\kappa_{y}=\frac{ky^{\prime}}{Z_{0}} $$ 

Examples: From this Fourier transform picture, we can retake a look of the simple Fraunhoffer diffraction we have already studied, the  $ t(x) $'s are for the single, multiple slits, etc.

(1) single

 $$ \begin{array}{r l}{\frac{1}{2}\int_{-\frac{\pi}{2}}^{\pi}\frac{A}{\frac{\pi}{2}}}&{{}\operatorname{s l i t},}\end{array} $$ 

The Fourier transform is given in Table V-3, case (1) (Zhao’s pg. 91)

 $$ \mathcal{F}[t(x)]=Aa\frac{\sin\alpha}{\alpha}\qquad\alpha=\pi fa $$ 

Where  $ f = \frac{\kappa}{2\pi} $ and using relation 7-24, 7-27  $ \kappa = k \sin \theta $.

Fraunhoffer:  $ \tilde{U}(\theta)\propto\mathcal{F}[t(x)]=Aa\frac{\sin\alpha}{\alpha},\alpha=\frac{k a\sin\theta}{2}=\frac{\pi a\sin\theta}{\lambda} $

Exactly the single slit Fraunhoffer diffraction.

(2) multiple silts



$$t(x)=\prod_{k=1}^{n}\otimes\sum_{n=1}^{N}\delta(x-nd)\quad\text{convolution between square and "comb"}$$

function.

Using convolution theorem, we know the F-Transform of the square function well; and the “comb” function’s transform can be evaluated by using phase shift of F-Transform, the result is:

 $$ \mathcal{F}[t(x)]=A a\frac{\sin\alpha}{\alpha}\sum_{n=1}^{N}e^{-i\kappa n d}\quad\kappa=k\sin\theta $$ 

 $$ \tilde{U}(\theta)\propto\mathcal{F}[t(x)]=Aa\frac{\sin\alpha}{\alpha}\frac{\sin N\beta}{\sin\beta}\quad\alpha=\frac{ka\sin\theta}{2}\qquad\beta=\frac{kd\sin\theta}{2} $$ 

Same as derived before.

For the double  $ \delta $ slit (an idealization for Young’s double slit) or cosine grating case, you should be able to work out by yourself the diffraction pattern from the Fourier Transform.

Actually, given some sort of aperture function$t(x)$, its Fraunhoffer diffraction pattern are given by the $\mathcal{F}[t(x)]$. The general strategy will be finding the transform $\mathcal{F}[t(x)]=\tilde{U}(\kappa)$, then using the relation of $\kappa=2\pi f=k\sin\theta$, the $\tilde{U}(\theta)$ (or $\tilde{U}(xˈ)$) can be easily determined.

All of the above we basically reworked a problem (Fraunhoffer

diffraction) with Fourier transform Method. This Fourier Transform technique as we shall see in the next section will be applied in the image processing (There the  $ t(x) $ would be some structure on the objective screen).

# 7-2-2 Abbe imaging principle and image processing by spatial Filtering

(Zhao's, §3,6, Vol. II, Chap5)

7-2-2-1 Abbe Imaging Principle (Fig. 3-1, pg. 70, Zhao's)

(1) Geometric optical treatment for image formation.

Objective point  $ \leftrightarrow $ image point (conjugate).

Basically, the lights from a spherical point source after passing the lens will be converging to (or diverging from for virtual image case) another point source.

(2) Wave Optical treatment – Abbe imaging principle.

In short, the imaging formation can be regarded as two steps.

A. Fraunhoffer diffraction by the object forms diffraction pattern on the Transform screen (The Screen is at the back focal plane of the lens, it is usually a virtual plane, not necessarily a real physical existence). The diffraction pattern on this transform screen will be the Fourier transform

of the original object.

B. The interference by the diffraction pattern on the imaging plane. (Huygens-Fresnel Principle, we shall see that this process will be another Fourier Transform of the transform screen and will bring back the form of original object on the imaging screen, equivalently an image of the object is formed).

## 7 -2-2-2 4-F system

The Abbe imaging principle is basically (1) Fourier transform of the original object to get is spatial frequency component. (2) Combining all the spatial frequency components to form an image. This process of decompose first, recombine second can be easily achieved by the 4-F system and using the fact that we have discussed that the Fraunhoffer diffraction pattern is the Fourier Transform of the original object.

The 4F setup is as following: The object (O) is placed at the front focal distance to the 1st lens; A transform plane (T) is at the back focal plane of the 1st lens, this T-plane can be a real one in case of spatial filtering or a virtual one for complete passage of light. This T-plane is also at the front focal distance of the 2nd lens and the final image plane (I) is at the back focal plane of the 2nd lens. The O-L₁-T forms the first half (a 2F) and T-L₂-I forms the second half.

<div style="text-align: center;"><img src="imgs/img_in_image_box_212_171_991_569.jpg" alt="Image" width="65%" /></div>


<div style="text-align: center;">Fig 7.2.3</div>


We shall see that  $ \tilde{U}_{I}(x',y')=\tilde{U}_{0}(-x,-y) $, basically we get an inverted image on the image screen, this is also the results by using Geometrical method. The wave method (or Fourier transform method) leads us to more insights and provides means to modify the image by spatial filtering.

According to the Abbe principle, the image is formed in two steps (refer to figure above):

(1) The separation of spatial frequency of object on Transform screen.

This is achieved by the Fraunhoffer diffraction pattern of the O(object)-plane on T(transform)-plane. (The first 2F, recall this half is exactly a Fraunhoffer diffraction setup).

i.e.

 $$ \tilde{U}_{1}(\xi,\eta)=\mathcal{F}[\tilde{U}_{0}(x,y)] $$ 

 $ \tilde{U}_1(\xi,\eta) $ is the field distribution on input side of the T plane.

(2) Spatial frequency Synthesis.

This is another Fourier Transform, this time it is the transform of the  $ \tilde{U}_{2}(\xi,\eta) $, the output of the intermediate T screen:

 $$ \tilde{U}_{2}(\xi,\eta)=\tilde{t}_{T}(\xi,\eta)\tilde{U}_{1}(\xi,\eta) $$ 

It acts as the input for the  $ 2^{nd} $ lens and the output is also a Fraunhoffer diffraction:

 $$ \tilde{U}_{I}(x^{\prime},y^{\prime})=\mathcal{F}[\tilde{U}_{2}(\xi,\eta)] $$ 

Take a simple case where  $ \tilde{t}_{T}(\xi,\eta)=1 $ (no altering of Fourier spatial frequency, the T plane is just a virtual one with no physical plane in its position):

 $$ \tilde{U}_{2}(\xi,\eta)=\tilde{U}_{1}(\xi,\eta)=\mathcal{F}[\tilde{U}_{0}(x,y)], $$ 

Then  $ \tilde{U}_{I}(x',y') = FF[\tilde{U}_{0}(x,y)] = \tilde{U}_{0}(-x,-y) $

(This can be proved by definition of Fourier Transform, please confirm it as an exercise)

## 7 -2-2-3 High spatial frequency loss and diffraction limit of resolution

As shown in (7-34) that  $ \tilde{U}_{I}(x',y')=\tilde{U}_{0}(-x,-y) $, it seems that a perfect image is formed. However this is only possible that All the spatial frequency components can be collected by the system ( $ \int_{-\infty}^{+\infty} $ in Fourier Transform). i.e. no loss of spatial frequency components. However, in the conventional setup, this is impossible.

Recall (7-24), (7-27) the relation between the spatial frequency  $ \kappa $ and diffraction angle  $ \theta $.

$$2\pi f = \kappa = k \sin \theta = \frac{2\pi}{\lambda} \sin \theta \quad (f = \frac{1}{d}, \quad d \quad \text{is the spatial period of the object})$$

 $$ \rightarrow f=\frac{\sin\theta}{\lambda}\text{or}d\sin\theta=\lambda\quad(7-35) $$ 

 $$ \because\sin\theta\leq1\Rightarrow d\geq\lambda\qquad(7-36) $$ 

i.e. The conventional imaging system cannot resolve structures less than the wave length of light in use. The (7-36) is for  $ \theta \leq 90^{\circ} $, but in any real setup,  $ \theta $ can be even smaller. For the setup like:

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_667_501_847.jpg" alt="Image" width="20%" /></div>


 $$ \theta\leq\theta_{0},\tan\theta_{0}=\frac{D}{2Z}\approx\sin\theta_{0} $$ 

 $$ \therefore\kappa=k\sin\theta\leq k\frac{D}{2Z} $$ 

 $$ \because\kappa=2\pi f=\frac{2\pi}{d} $$ 

 $$ \therefore d\geq\frac{\lambda2Z}{D} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_742_1148_1009_1272.jpg" alt="Image" width="22%" /></div>


D is the diameter of the aperture stop of the

imaging system, d is the minimum resolvable feature.

Then  $ \phi=\frac{d}{Z}\geq\frac{2\lambda}{D} $



This is about same as the diffraction limited resolution by a circular

aperture in imaging system as we discussed before. (See Airy Rings by circular aperture).

From the above discussion, the diffraction limited resolution is caused by the loss of high spatial frequency component during the process; the high spatial frequency (large  $ \kappa $) component which carries the information on the fine structure of the object corresponds to large diffraction angle and cannot be collected by the system.

$d\sin\theta=\lambda$ (7-35) tells us when the $d$ is smaller than $\lambda$ (or $\kappa>k$; $\kappa=\frac{2\pi}{d}$ is the spatial frequency; $k=\frac{2\pi}{\lambda}$ is wave vector of light), these high spatial frequency components correspond to an evanescent wave. This can be seen as follows:

 $$  For\ d\leq\lambda\rightarrow(\kappa=\frac{2\pi}{d})\xrightarrow{\kappa=k\sin\theta}\sin\theta\geq1. $$ 

We shall see that this corresponds to an evanescent wave that decays fast along the propagation.

The diffracted wave corresponding to spatial frequency  $ \kappa $ propagates as:



<div style="text-align: center;"><img src="imgs/img_in_image_box_174_1090_402_1267.jpg" alt="Image" width="19%" /></div>


 $$ \tilde{U}(x,y,z)=A e^{i k\sin\theta x+k\cos\theta Z} $$ 

 $$  Where\ \sin\theta=\frac{\kappa}{k},\ k\sin\theta=\kappa=\frac{2\pi}{d} $$ 

If  $ \sin\theta \geq 1 $, then  $ \cos\theta = \sqrt{1 - \sin^2\theta} = \sqrt{1 - \left(\frac{\kappa}{k}\right)^2} = \sqrt{1 - \left(\frac{\lambda}{d}\right)^2} = i\alpha_z $ would be imaginary, where we define:

 $$ k_{z}=k\cos\theta=i k\alpha_{z}\qquad\alpha_{z}=\sqrt{\left(\frac{\lambda}{d}\right)^{2}-1}\quad for\quad\lambda>d $$ 

Then  $ \tilde{U}(x,y,z)=Ae^{-k\alpha_{z}Z}e^{i\kappa x} $.

This wave quickly drops propagating along Z, when Z reaches a few  $ \lambda $, the loss will be significant. That is why you cannot detect these high spatial frequency components at far-field.

To overcome this draw back, the solution lies in the “near field” optics, the detector is placed very close to (within a few  $ \lambda $ distance) the object, and the decaying evanescent wave of high spatial freq. components will also be picked up. This is a relatively new technique, thanks for the Nano-positioning device available in recent years. “Near field” imaging can overcome the diffraction limit and increase the resolution.

## 7 -2-2-4 Image Process by spatial filtering

### (P 75-77, P123-126 Zhao's Vol. II)

In the above discussion, we want to collect as much diffracted spatial frequency component as possible. Sometimes however we want to alter (or improve) the image by intentionally filter out some spatial frequency component. This is achieved by inserting a spatial filter at the transform plane T, 4F system. Thus the aperture function is not  $ \tilde{t}_{T}=1 $ anymore, but will be generally  $ \tilde{t}_{T}(\xi,\eta) $.

(refer to Zhao's book, pg. 75, fig 3-3 for some simple spatial filter device)

Some simple illustration of spatial filtering is given in Fig 3-5, pg. 76, Zhao's book.

Put it into mathematical formula.

 $$ \begin{array}{c c}{\tilde{U}_{2}=\tilde{t}_{T}U_{1}=\tilde{t}_{T}\mathcal{F}[\tilde{U}_{0}(x,y)]}\\ \end{array} $$ 

Spatial filtered

 $$ \begin{aligned}&\tilde{U}_{I}(x^{\prime},y^{\prime})=\mathcal{F}\{\tilde{t}_{T}\mathcal{F}[\tilde{U}_{0}(x,y)]\}\\ &=\mathcal{F}[\tilde{t}_{T}]\otimes\mathcal{F}\mathcal{F}[\tilde{U}_{0}(x,y)]\\ &=\mathcal{F}[\tilde{t}_{T}]\otimes\tilde{U}_{0}(-x^{\prime},-y^{\prime})\\ \end{aligned} $$ 

This final image will be the Fourier Transform of  $ \tilde{t}_{T} $, convolved with the inverted object.

See example 4.5 on pg. 121-122, Zhao’s book for the altering image by spatial filtering and experimental examples for image processing on pg. 123-126, Zhao’s book.

1. Huygens-Fresnel Principle (HFP) and Kirchhoff equation.

 $$ \tilde{U}(p)=C\oint\limits_{\Sigma}f(\theta,\theta_{0})U_{\Sigma}\frac{e^{i k r}}{r}d s $$ 

 $$ C=-\frac{i}{\lambda},f(\theta,\theta_{0})=\frac{1}{2}(\cos\theta+\cos\theta_{0}) $$ 

Generally solving such equation (integral) is very hard.

### 2. Fresnel Diffraction

<div style="text-align: center;"><img src="imgs/img_in_image_box_177_779_833_994.jpg" alt="Image" width="55%" /></div>


 $$ \mathrm{U}(\mathrm{P})=\frac{|\mathrm{A}_{1}|}{2}\pm\frac{|\mathrm{A}_{\mathrm{m}}|}{2}\quad\begin{array}{c} +\\\mathrm{~m~}\ \mathrm{i s}\ \mathrm{o d d}\\-\ \mathrm{~m~}\ \mathrm{i s}\ \mathrm{e v e n}\end{array} $$ 

Free propagation  $ |A_{0}|=\frac{|A_{1}|}{2} $

 $$ \rho_{\mathrm{m}}=\sqrt{\mathrm{m}}\rho_{1}\qquad\rho_{1}=\sqrt{\frac{\mathrm{Rb}\lambda}{\mathrm{R}+\mathrm{b}}}\quad\mathrm{i f}\mathrm{~R}\rightarrow\infty,\quad\rho_{1}=\sqrt{\mathrm{b}\lambda} $$ 

ρm is the radius of MTh  $ \lambda/2 $ plate.

<div style="text-align: center;"><img src="imgs/img_in_image_box_179_274_900_722.jpg" alt="Image" width="60%" /></div>


### 3. Fraunhoffer diffraction

Based on Kirchhoff equation with simplification:

 $$ \frac{1}{r}\rightarrow\frac{1}{z_{0}}(\frac{1}{f})\quad e^{i k r}\rightarrow e^{i k r_{0}}e^{-i\frac{k}{z_{0}}(x x^{\prime}+y y^{\prime})}\quad[\mathrm{o r}\quad\frac{k}{f}(x x^{\prime}+y y^{\prime})] $$ 

This is possible if both paraxial and far-field conditions are satisfied.

### 3.1 Single Slit

<div style="text-align: center;"><img src="imgs/img_in_image_box_223_1299_477_1381.jpg" alt="Image" width="21%" /></div>


 $$ \mathrm{U}(\theta)=\mathrm{A a}\frac{\sin\alpha}{\alpha}\qquad\mathrm{I}(\theta)=\mathrm{I}_{0}(\frac{\sin^{2}\alpha}{\alpha^{2}}) $$ 

 $$ \alpha=\frac{\arcsin\theta}{\lambda}\pi $$ 

Major maximum:  $ \alpha = 0 $ or  $ \theta = 0 $

minimum:  $ \alpha = m\pi \rightarrow \sin\theta = m\lambda $

Half angular width:  $ \Delta\alpha = \pi \rightarrow a\Delta\theta = \lambda $

Similar Results for rectangular aperture and circular aperture.

Resolution by circular aperture:  $ \delta\theta = \Delta\theta = 1.22 \frac{\lambda}{D} $ (Rayleigh Criteria, D is

diameter of lens)

3.2 Many Slits



<div style="text-align: center;"><img src="imgs/img_in_image_box_284_851_1040_982.jpg" alt="Image" width="63%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_178_1032_454_1146.jpg" alt="Image" width="23%" /></div>


single slit diffraction many slits interference

 $$ \alpha=\frac{\arcsin\theta}{\lambda}\pi\qquad\quad\beta=\frac{\mathrm{d}\sin\theta}{\lambda}\pi $$ 

Principal maximum:  $ \beta = m\pi \rightarrow \mathrm{d}\sin\theta = m\lambda $

 $$  minimum:\beta=\frac{n}{N}\pi\qquad n=\pm1,\cdots,\pm(N-1) $$ 

Half angular width(PM):  $ \Delta\beta=\frac{1}{N}\pi\rightarrow\Delta\theta=\frac{\lambda}{Nd\cos\theta} $

Missing orders: Modulation due to  $ \frac{\sin\alpha}{\alpha} $ term

### 4. Grating (Application of many slits diffraction)

Dispersion Relation:  $ d\sin\theta = m\lambda $ (transmitting)

 $$ \mathrm{d}(\sin\theta_{\mathrm{m}}\pm\sin\theta_{\mathrm{i}})=\mathrm{m}\lambda\quad(Reflecting) $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_373_639_452_687.jpg" alt="Image" width="6%" /></div>


chromatic dispersion:  $ D_{\theta} = \frac{\delta\theta}{\delta\lambda} = \frac{m}{d\cos\theta_{m}} $

 $$ \mathbf{D}_{\mathrm{l}}=\mathbf{f}\mathbf{D}_{\theta} $$ 

Chromatic Resolution:  $ \frac{\lambda}{\delta\lambda_{\mathrm{m}}} = \mathrm{mN} $

Free Spectral Range:  $ \Delta\nu_{\mathrm{fsr}} = \frac{C}{\mathrm{d}\sin\theta} $

5. Fourier Transform

 $$ \mathrm{f}(\mathrm{x})=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}\mathrm{F}(\mathrm{K})\mathrm{e}^{\mathrm{i}\mathrm{Kx}}\mathrm{dK} $$ 

 $$ \mathrm{F}(\mathrm{K})=\frac{1}{\sqrt{2\pi}}\int_{-\infty}^{+\infty}\mathrm{f}(\mathrm{x})\mathrm{e}^{-\mathrm{i}\mathrm{Kx}}\mathrm{d}\mathrm{x} $$ 

 $$ \Delta x\Delta K\approx2\pi $$ 

Dirac ∂ function and its property

Properties of Fourier Transform.

Typical Transforms in Zhao’s Table V-3, V-4

6. Fourier Optics

6.1 Fraunhoffer Diffraction.

With proper setup, the Fraunhoffer Diffraction pattern is the Fourier Transform of the diffracting object.

 $ \widetilde{\mathbf{U}}(\mathbf{x}^{\prime},\mathbf{y}^{\prime})=\widetilde{\mathbf{U}}(\mathbf{K}_{\mathbf{x}},\mathbf{K}_{\mathbf{y}})=F[\mathbf{U}_{\Sigma_{0}}(\mathbf{x},\mathbf{y})] $,  $ F $ is shorthand for Fourier

Transform

 $$ \mathrm{U}_{\Sigma_{0}}=\mathrm{t}(\mathrm{x},\mathrm{y})\widetilde{\mathrm{U}}_{\mathrm{i}0}(\mathrm{x},\mathrm{y})\propto\mathrm{t}(\mathrm{x},\mathrm{y}) $$ 

 $$ \mathrm{K}_{\mathrm{x}}=\frac{\mathrm{k}}{\mathrm{z}_{0}}\mathrm{x}^{\prime}=\mathrm{ksin}\theta_{1} $$ 

 $$ \mathrm{K}_{\mathrm{y}}=\frac{\mathrm{k}}{\mathrm{z}_{0}}\mathrm{y}^{\prime}=\mathrm{ksin}\theta_{2} $$ 

6.2 Abbe imaging Principle and 4-F system

<div style="text-align: center;"><img src="imgs/img_in_image_box_210_172_908_393.jpg" alt="Image" width="58%" /></div>


 $$ \tilde{U}_{1}(\xi,\eta)=F[\tilde{U}_{\Sigma0}(x,y)];\tilde{U}_{I}(x^{\prime},y^{\prime})=F[\tilde{U}_{2}(\xi,\eta)] $$ 

### 6.3 Diffraction limited resolution

d ≥ λ ——due to loss of high special frequency components

## Chapter 8 Polarization and Propagation of Light in Crystal

(Chap 8, Hecht; Chap 7, Zhao)

The light field in the classical E-M theory is a vector field. The  $ \vec{E} $ component has direction, this direction of  $ \vec{E} $ is called polarization of light. We neglect this vector feature before by treating it as scalar (using symbol  $ \vec{U} $) in cases such vector nature can be neglected. In this chapter we shall give it a detailed look. The polarization is not only in itself an important property of light which has many applications, it is also related in quantum the spin of photon, and the Jones vector treatment on polarization uses same mathematical tools as in quantum. The polarization indeed is a two-level system in quantum mechanics, and our treatment here will pay dividents later in study of quantum mechanics.

## 8 -1 Polarization Type of Light

## (1) Natural light (Unpolarized light)

The direction of  $ \bar{E} $ is randomly distributed, say at some fixed space, measuring the polarization at different times, the result is something like the figure shown:

<div style="text-align: center;"><img src="imgs/img_in_image_box_249_1346_403_1542.jpg" alt="Image" width="12%" /></div>


Question: The  $ \bar{E} $ field as shown appears to be averaged to zero for the natural light, then why the average intensity of natural light  $ \neq 0 $?

The answer is that each component is incoherent! It is from independent emission of atoms/molecules, belongs to independent wave trains. So there is no fixed phase relation and it is intensity that sums up, a scalar summation instead of vector summation.

(2) Partial polarized light.

<div style="text-align: center;"><img src="imgs/img_in_image_box_220_693_355_937.jpg" alt="Image" width="11%" /></div>


The direction is random and the amplitude depends on direction.

The description of the partial polarized light is actually most difficult in math (compare to the polarized light introduced below). The accurate description in classical physics is Stokes vector which will not be treated in our course, but briefly discussed in Hecht's; the formal treatment would be density matrix method in statistical mechanics and will not be introduced here. A very useful picture from the density matrix method is that we can treat the partial polarized light as a combination of natural light plus a polarized light. That is why it is called partial polarized.



Above are two types of unpolarized light. For polarized light, the

direction of  $ \bar{E} $ has fixed relation over space and time. i.e. it is

predictable. These polarized light can be:

(3) Linear polarized light.

☑ does not change direction over space and time, always along same line

<div style="text-align: center;"><img src="imgs/img_in_image_box_190_453_629_846.jpg" alt="Image" width="36%" /></div>


Apparently all linear

polarized light can be

superposition of two

orthogonal linear

polarized light (with same

frequency)

 $$ \vec{\mathrm{E}}_{1}=\vec{\mathrm{E}}_{10}\mathrm{c o s}(\mathrm{k}z-\omega\mathrm{t})=\mathrm{E}_{\mathrm{x}1}\hat{\mathrm{i}}\mathrm{c o s}(\mathrm{k}z-\omega\mathrm{t})+\mathrm{E}_{\mathrm{y}1}\hat{\mathrm{j}}\mathrm{c o s}(\mathrm{k}z-\omega\mathrm{t}) $$ 

 $$ \vec{\mathrm{E}}_{2}=\vec{\mathrm{E}}_{20}\mathrm{c o s}(\mathrm{k}z-\omega\mathrm{t})=\mathrm{E}_{x2}\hat{\mathrm{i}}\mathrm{c o s}(\mathrm{k}z-\omega\mathrm{t})+\mathrm{E}_{y2}\hat{\mathrm{j}}\mathrm{c o s}(\mathrm{k}z-\omega\mathrm{t}) $$ 

 $$ \mathrm{E}_{\mathrm{x i}}=|\mathrm{E}_{\mathrm{i}0}|\cos\theta_{\mathrm{i}},\mathrm{E}_{\mathrm{y i}}=|\mathrm{E}_{\mathrm{i}0}|\sin\theta_{\mathrm{i}} $$ 

i, j are unit vectors along  $ \vec{H}, \vec{V} $ (or  $ \vec{x}, \vec{y} $) direction.

Previously in the discussion of superposition of waves, we stated that for the sum of waves to show interference, they have to have parallel components of polarization, and the phase difference between the waves determine the intensity. Here we shall see that adding waves with perpendicular (“orthogonal” more precisely) polarization generally changes the polarization of light; the phase difference between the

orthogonal components will determine the polarization state (type).

For a linear polarized light, the phase difference between the two orthogonal components is either  $ 0(\vec{E}_{1} $ in the figure) or  $ \pi(\vec{E}_{2}) $.

## (4) Circular Polarized light

What happens if the two orthogonal polarized light $E_{\mathrm{H}}^{\mathrm{i}}, E_{\mathrm{v}}^{\mathrm{j}}$ with phase difference $\varepsilon \neq 0, \pi$.

i.e.  $ \vec{E}_{H} = E_{x} \hat{i} \cos(kz - \omega t) $

 $$ \vec{\mathrm{E}}_{\mathrm{v}}=\mathrm{E}_{\mathrm{y}}\hat{\mathrm{j}}\mathrm{c o s}(\mathrm{k}z-\omega\mathrm{t}+\varepsilon) $$ 

Then what is  $ \vec{E} = \vec{E}_H + \vec{E}_V $?

We will have circular polarized light if  $ \varepsilon = \pm \pi / 2 $ and  $ E_x = E_y $, a quite special case in this sense.

For  $ \varepsilon = -\frac{\pi}{2} $ (V leads H) at a fixed space point, say z = 0, looking into the direction of light's propagation.

<div style="text-align: center;"><img src="imgs/img_in_image_box_188_1000_567_1511.jpg" alt="Image" width="31%" /></div>


 $$ \mathrm{E}_{\mathrm{x}}\hat{\mathrm{i c o s}}(-\omega\mathrm{t})\qquad\mathrm{f o r}\mathrm{x}=0 $$ 

 $$ \mathrm{E}_{\mathrm{y}}\hat{\mathrm{j}}\mathrm{c o s}(-\omega\mathrm{t}+\varepsilon) $$ 

 $$ \varepsilon=-\frac{\pi}{2} $$ 

clearly  $ E^{2}=|E_{x}|^{2}+|E_{y}|^{2} $

is not changing over time.

But its direction is

rotating clockwise with

This is called right circular polarized

If fixed in time, say t=0, the polarization over place:

<div style="text-align: center;"><img src="imgs/img_in_image_box_160_430_748_924.jpg" alt="Image" width="49%" /></div>


We define right-circular polarized in the sense of how it changes over time.

Similarly for  $ \varepsilon=\pi/2 $

<div style="text-align: center;"><img src="imgs/img_in_image_box_175_1170_450_1327.jpg" alt="Image" width="23%" /></div>


At fixed space over time, left circular polarized light is shown in the figure.

Note  $ \varepsilon > 0 $ means lag in phase  $ (E_{\mathrm{v}} $ lags  $ E_{\mathrm{H}}) $

 $ \varepsilon < 0 $ means lead in phase  $ (E_{\mathrm{v}} $ leads  $ \mathrm{E}_{\mathrm{H}}) $

This is in accordance of the convention we choose by adopting  $ e^{i(kz - \alpha t + \varepsilon)} $ as wave. So it is conventional to say that if the V component leads in phase by  $ \frac{\pi}{2} $, it is right circular (of course the amplitudes for the H,V components are equal); if V lags by  $ \frac{\pi}{2} $, then it is left circular.

## (5) Elliptical polarized light

For the superposition of  $ \varepsilon \neq \pm\pi/2, 0, \pm\pi $ or  $ E_H \neq E_v, \varepsilon = \pm\pi/2 $, the polarization state will be what is called elliptical. Linear polarized and circular polarized light are special cases for such superposition.

(Fig. 8.7, Hecht. Fig. 9~10, Zhao’s P244, Vol. 1, or Fig. 3~5, Pg. 191, Vol. 2)

Looking into the direction of propagation, at fixed space and the

polarization  $ \vec{E} $ changes over time:

<div style="text-align: center;"><img src="imgs/img_in_image_box_176_955_1058_1128.jpg" alt="Image" width="74%" /></div>


(6)Superposition of orthogonal oscillation with different frequencies

 $$ \begin{aligned}&\vec{\mathrm{E}}_{\mathrm{H}}=\mathrm{E}_{\mathrm{H}}\hat{\mathrm{i}}\mathrm{c}\mathrm{o}\mathrm{s}(\mathrm{h}\mathrm{k}_{0}\mathrm{z}-\mathrm{h}\omega_{0}\mathrm{t})\\&\vec{\mathrm{E}}_{\mathrm{V}}=\mathrm{E}_{\mathrm{V}}\hat{\mathrm{j}}\mathrm{c}\mathrm{o}(\mathrm{v}\mathrm{k}_{0}\mathrm{z}-\mathrm{v}\omega_{0}\mathrm{t}+\varepsilon)\qquad\mathrm{h},\mathrm{v}\mathrm{a}\mathrm{r}\mathrm{e}\mathrm{i n t e g}\mathrm{e}\mathrm{r s}\\&\vec{\mathrm{E}}=\vec{\mathrm{E}}_{\mathrm{H}}+\vec{\mathrm{E}}_{\mathrm{V}}\\ \end{aligned} $$ 

The superposition at fix space point (say z=0) would be what is known as Lessajou Figure. For example h=2, v=1,  $ \varepsilon = -\frac{\pi}{4} $,  $ \vec{E} $ would change with

time as:

<div style="text-align: center;"><img src="imgs/img_in_image_box_253_190_575_445.jpg" alt="Image" width="27%" /></div>


Generally if  $ \omega_{\mathrm{H}} = \mathrm{h}\omega_{0} $,  $ \omega_{\mathrm{V}} = \mathrm{v}\omega_{0} $, the Lessajou Figure would have v tangential points along  $ \vec{H} $ direction, and h tangential points along  $ \vec{V} $ direction.

Note: Do not confuse the polarization of light with the field or intensity distribution of light (or the illumination pattern of light) over space. Think the questions: will the shape of light intensity distribution be a line for linear light? Be a circle for circular light? These two (polarization vs. intensity distribution) has no connections! (The H-V in polarization is just two direction, not real x,y displacement)

For a light beam with round cross section, i.e.:

Light beam

<div style="text-align: center;"><img src="imgs/img_in_image_box_133_1254_1059_1531.jpg" alt="Image" width="77%" /></div>


Clearly to check the polarization of light, we cannot only use the intensity distribution of the field. The simplest device to check the polarization is polarizer.

## 8 -2 Polarizer

(Hecht 8.2)

We have introduced type of polarization and we shall need to know how to prepare and test them. For this purpose we need polarization devices. The simplest is linear polarizer which we shall discuss here first; and other devices (such as wave plate) later.

Polarizer: If the input is natural light, the output is some form of polarized light.

The most simple and common one is linear polarized light.

<div style="text-align: center;"><img src="imgs/img_in_image_box_173_1283_831_1482.jpg" alt="Image" width="55%" /></div>


Different types of polarizer are based on different working principles: light scattering, reflection, selective absorption and bypassing through birefringent crystals.

####### 8 -2-1. Polarization by Scattering (Hecht 8.5.1, Zhao’s Pg. 253, Vol. 2)

The linearly polarized incoming light drives the electrons in atoms/molecules to a forced oscillation, and become oscillating dipoles. The dipole is along the direction of linear polarization of the driving light. The scattered light is from the E-M wave emitted by these dipole oscillators. Such emission has same polarization of the driving light, the emission is also directional dependent.

(Fig 8.30, Hecht) The emitting wave is max. in direction ⊥ dipole and zero for direction ∥ to the dipole.

<div style="text-align: center;"><img src="imgs/img_in_image_box_200_1091_645_1312.jpg" alt="Image" width="37%" /></div>


If the incoming light is natural light as in Fig 8.31 Hecht's, along the direction perpendicular to the propagation of the original driving light, the scattered light would be linearly polarized. Try looking the sky

through a linear polarizer and you will see this effect.

<div style="text-align: center;"><img src="imgs/img_in_image_box_216_227_479_526.jpg" alt="Image" width="22%" /></div>


### 8 -2-2. Polarization by Reflection-Brewster angle

<div style="text-align: center;"><img src="imgs/img_in_image_box_192_719_926_939.jpg" alt="Image" width="61%" /></div>


The reflected light at  $ \theta_{B} $ would be S polarized. The transmitted light would be partial polarized.

From scattering point of view, it provides an explanation that why no P component of light is reflected, i.e. the direction of reflection is along the oscillating dipoles that are responsible for reflection.

8-2-3. Polarization by dichroic materials —— Selective absorption

The material absorbs light of certain polarization, and transmits the orthogonal polarization.

### 8 -2-4. Malus's Law

Fig 8.10 Hecht:

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_294_682_509.jpg" alt="Image" width="40%" /></div>


For a natural light with irradiance  $ I_0 $, after passing through an linear polarizer, only linear polarized component left, with  $ I = \frac{1}{2} I_0 $.

<div style="text-align: center;">Fig 8.11:</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_214_794_930_1083.jpg" alt="Image" width="60%" /></div>


If a second linear polarizer inserted, with direction of transmission has angle  $ \theta $ with the linear polarized light (the output of the first polarizer), then final transmission would be:

 $$ \mathrm{I}(\theta)=\mathrm{I}(0)\cos^{2}\theta $$ 

This is called Malus Law. Its derivation is very simple and you can do easily.

### 8 -2-5. Distinction of different polarization with linear polarizer

Linear polarizer's output

Natural light

 $ I = \frac{1}{2} I_0 \quad \text{for all} \quad \theta $

Linear polarized

<div style="text-align: center;"><img src="imgs/img_in_image_box_403_285_869_449.jpg" alt="Image" width="39%" /></div>


 $$  I_{max}=I_{0},I_{min}=0 $$ 

Circular polarized  $ I=\frac{1}{2}I_{0} $

<div style="text-align: center;"><img src="imgs/img_in_image_box_359_626_795_803.jpg" alt="Image" width="36%" /></div>


Elliptical polarized

<div style="text-align: center;"><img src="imgs/img_in_image_box_280_878_678_1083.jpg" alt="Image" width="33%" /></div>


Partial polarized

<div style="text-align: center;"><img src="imgs/img_in_image_box_226_1175_553_1340.jpg" alt="Image" width="27%" /></div>


Using only linear polarizer cannot distinguish circular with natural light, elliptical with partial polarized light. The separation of these will be clear when we come to wave-plate later, and we shall also see there how any

polarization state can be prepared, not only the linear one.

## 8 -3 Jones Vector for Polarized Light and Jones Matrix

In this section, I shall give the useful representation of polarization using matrix, and it is called Jones vector.

## 8 -3-1 Jones Vector

As we have seen that for polarized light, it is from superposition of perpendicular oscillation (with same  $ \omega $), different phase, and amplitude result in different polarization.

 $$ \vec{\mathrm{E}}=\mathrm{A}\hat{\mathrm{i}}+\mathrm{B}\hat{\mathrm{j}} $$ 

 $$ \mathbf{A}=\mathbf{A}_{\mathbf{x}}\mathbf{e}^{\mathrm{i}\varphi_{\mathbf{x}}}\quad\mathbf{B}=\mathbf{B}_{\mathbf{y}}\mathbf{e}^{\mathrm{i}\varphi_{\mathbf{y}}} $$ 

Jones vector applies matrix representation of a vector by a  $ 1 \times 2 $ column matrix.

 $$ \left|\vec{\mathrm{E}}\right\rangle=\left[\begin{matrix}{\mathrm{A}}\\ {\mathrm{B}}\\ \end{matrix}\right]=\mathrm{e}^{\mathrm{i}\varphi_{\mathrm{x}}}\left[\begin{matrix}{\mathrm{A}_{\mathrm{x}}}\\ {\mathrm{B}_{\mathrm{y}}\mathrm{e}^{\mathrm{i}\Delta}}\\ \end{matrix}\right]\qquad\quad\Delta=\varphi_{\mathrm{y}}-\varphi_{\mathrm{x}}, $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_471_1134_685_1336.jpg" alt="Image" width="17%" /></div>


The reason using  $ \left|\vec{E}\right\rangle $ as a symbol for vector is in accordance with Dirac notation that we shall use in quantum, here just treat it as a shorthand for vector.

(a) Some normalized polarization in x(H), y(V) basis.

Normalized:  $ |A|^2 + |B|^2 = 1 $

 $ \begin{bmatrix}1\\ 0\end{bmatrix} $ x(H) polarized

 $ \begin{bmatrix}0\\ 1\end{bmatrix} $ y(V) polarized

\frac{1}{\sqrt{2}}\begin{bmatrix}1\\ -i\end{bmatrix} right circular  $ \quad\frac{1}{\sqrt{2}}\begin{bmatrix}1\\ i\end{bmatrix} $ left circular

\frac{1}{\sqrt{2}}\begin{bmatrix}1\\ 1\end{bmatrix}\quad45^{\circ}\quad\text{linear polarized}\quad\text{k V}

\frac{1}{\sqrt{2}}\begin{bmatrix}1\\ -1\end{bmatrix}\quad-45^{\circ}\quad\text{linear polarized}\quad\text{↑y}





 $$ \frac{1}{\sqrt{5}}\begin{bmatrix}2\\ -i\end{bmatrix} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_290_521_477_644.jpg" alt="Image" width="15%" /></div>


 $$ \frac{1}{\sqrt{5}}\begin{bmatrix}1\\ 2i\end{bmatrix} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_651_519_811_706.jpg" alt="Image" width="13%" /></div>


(b) Orthogonal polarization

 $$ \left\langle\mathrm{E}_{2}\right|\mathrm{E}_{1}\rangle=\vec{\mathrm{E}}_{2}^{*}\vec{\mathrm{E}}_{1}=\left[\mathrm{A}_{2}^{*}\quad\mathrm{B}_{2}^{*}\right]\left[\begin{aligned}\mathrm{A}_{1}\\ \mathrm{B}_{1}\end{aligned}\right]=\mathrm{A}_{1}\mathrm{A}_{2}^{*}+\mathrm{B}_{1}\mathrm{B}_{2}^{*}=0 $$ 

Easy to confirm that the top 4 pairs are 4 pairs of orthogonal normalized (orthonormal) polarization.

(c) Basis: In 2-D, 2 linear independent vectors can form a basis in which an arbitrary polarization can be decomposed into its components, and we generally choose a pair of orthonormal vectors as basis.

 $ \begin{bmatrix} \mathbf{A} \\ \mathbf{B} \end{bmatrix} = \mathbf{A} \begin{bmatrix} 1 \\ 0 \end{bmatrix} + \mathbf{B} \begin{bmatrix} 0 \\ 1 \end{bmatrix} $ in H, V linear polarized basis

$$\begin{bmatrix} \mathrm{A} \\ \mathrm{B} \end{bmatrix} = \frac{1}{2} (\mathrm{A} + \mathrm{i} \mathrm{B}) \begin{bmatrix} 1 \\ -\mathrm{i} \end{bmatrix} + \frac{1}{2} (\mathrm{A} - \mathrm{i} \mathrm{B}) \begin{bmatrix} 1 \\ \mathrm{i} \end{bmatrix}$$ in circular ( R-L ) basis

Generally given Jones vector  $ |E\rangle = \begin{bmatrix} A \\ B \end{bmatrix} $ (say in H, V basis), another

orthonormal basis formed by  $ |E_a\rangle $,  $ |E_b\rangle $ (say in R, L circular basis)

 $$ \left\langle\mathrm{E}_{\mathrm{a}}\left|\mathrm{E}_{\mathrm{b}}\right\rangle=\mathrm{E}_{\mathrm{a}}^{*}\mathrm{E}_{\mathrm{b}}=\delta_{\mathrm{ab}}\right\}=\left\langle1,\mathrm{a}=\mathrm{b}\right\rangle=0,\mathrm{a}\neq\mathrm{b} $$ 

 $$ \left|\mathbf{E}\right\rangle=\mathbf{a}_{0}\left|\mathbf{E}_{\mathrm{a}}\right\rangle+\mathbf{b}_{0}\left|\mathbf{E}_{\mathrm{b}}\right\rangle $$ 

Then  $ \langle\mathrm{E}_{\mathrm{a}}|\mathrm{E}\rangle=\mathrm{a}_{0} $

 $$ \left\langle\mathrm{E}_{\mathrm{b}}\left|\mathrm{E}\right\rangle=\mathrm{b}_{0}\right.\quad(8-5) $$ 

This is what I used to get the arbitrary vector from H-V basis to the R-L basis, since we know the representations of basis vectors, and the rest is simple matrix production.

## 8 -3-2 Jones matrix for operation on polarized light

Any operation that alters the polarization of light can be represented by a matrix: Jones matrix, which sometimes is called operator too.

 $$ \hat{O}=\begin{bmatrix}\mathbf{a}_{11}&\mathbf{a}_{12}\\ \mathbf{a}_{21}&\mathbf{a}_{22}\end{bmatrix} $$ 

 $$ \begin{aligned}&\left|\mathrm{E}_{\mathrm{in}}\right\rangle=\begin{bmatrix}\mathrm{A}\\ \mathrm{B}\end{bmatrix}\\ &\\ &\left|\mathrm{E}_{\mathrm{out}}\right\rangle=\hat{O}\left|\mathrm{E}_{\mathrm{in}}\right\rangle=\begin{bmatrix}\mathrm{A}^{\prime}\\ \mathrm{B}^{\prime}\end{bmatrix}\quad& \mathrm{A}^{\prime}=\mathrm{a}_{11}\mathrm{A}+\mathrm{a}_{12}\mathrm{B}\\ & \quad \mathrm{B}^{\prime}=\mathrm{a}_{21}\mathrm{A}+\mathrm{a}_{22}\mathrm{B}\\ \end{aligned} $$ 

Jones matrix for Reflection and Transmission of light at interface:

The problem has been solved before, recall Fresnel equation for  $ r_{s} $,  $ r_{p} $,  $ t_{s} $,  $ t_{p} $.

 $ \begin{cases}

\mathrm{E}_{\mathrm{p}}^{\mathrm{r}} = \mathrm{r}_{\mathrm{p}} \mathrm{E}_{\mathrm{p}}^{\mathrm{i}} \\

\mathrm{E}_{\mathrm{s}}^{\mathrm{r}} = \mathrm{r}_{\mathrm{s}} \mathrm{E}_{\mathrm{s}}^{\mathrm{i}}

\end{cases} $ p, s remains as p, s after reflection and transmission.

 $$ \begin{bmatrix}\mathrm{E}_{\mathrm{p}}^{\mathrm{r}}\\ \mathrm{E}_{\mathrm{s}}^{\mathrm{r}}\end{bmatrix}=\begin{bmatrix}\mathbf{r}_{\mathrm{p}}&0\\ 0&\mathbf{r}_{\mathrm{s}}\end{bmatrix}\begin{bmatrix}\mathrm{E}_{\mathrm{p}}^{\mathrm{i}}\\ \mathrm{E}_{\mathrm{s}}^{\mathrm{i}}\end{bmatrix} $$ 

The Jones matrix for Reflection in s, p basis is simply

 $$ \hat{R}=\begin{bmatrix}{{{\mathbf{r}_{\mathrm{p}}}}}&{{{0}}} \\{{{0}}}&{{{\mathbf{r}_{\mathrm{s}}}}}\end{bmatrix} $$ 

Similarly  $ \hat{T} = \begin{bmatrix} t_{p} & 0 \\ 0 & t_{s} \end{bmatrix} $

For any incoming polarized light, i.e. knowing  $ \begin{bmatrix} E_p^i \\ E_s^i \end{bmatrix} $, it is fairly easy to work out the polarized state of reflected and transmitted light.

We shall see the Jones matrix for other operations later once we introduce the important polarization device called wave plate. For that we need to know some basics of light propagation in crystal.

## 8 -4 Propagation of light in Crystal-Birefringence $ ^{10} $

## 8 -4-1 Phenomena of Birefringence (Double refraction)

(Zhao’s Chap 7, § 1.1, Hecht’s 8.4)

Fig. 8.19, 8.20 and 8.21 in Hecht's:

<div style="text-align: center;"><img src="imgs/img_in_image_box_222_172_724_631.jpg" alt="Image" width="42%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_197_687_568_969.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_594_695_941_972.jpg" alt="Image" width="29%" /></div>


(1) For crystal Calcite, the incoming light splits into two beams inside the calcite. (The double images in Fig 8.19 are formed by the two lights in the crystal). The two beams inside the crystal appear to experience two different index of refraction n.

(2) The two beams inside the crystal, one obeys the law of refraction, and is called “o” (o for ordinary) light; the other often violates the law of refraction, and is called “e” (extraordinary) light. The e, o lights are both linear polarized, and the direction of polarization is orthogonal to each other, i.e.  $ \vec{E}_{o} \perp \vec{E}_{e} $.

(3) The optical axis of the crystal.

Inside the crystal, there is a special direction, that along this direction, the o, e lights propagate with same speed and are not separated. Such special direction is called the optical axis. Some crystals have only one optical axis (or one special direction) and are called uniaxial crystals.

Some have two optical axis and are called biaxial crystals.

(4) polarization of o, e light with respect to optical axis.

For an uniaxial crystal, the o, e light's polarization are orthogonal and have fixed relations with respect to the optical axis (OA).

First we need to define “principal section” and “principal plane”.

<div style="text-align: center;"><img src="imgs/img_in_image_box_294_780_908_1062.jpg" alt="Image" width="51%" /></div>


Principal section: plane formed by the O.A. and Normal of the interface

Principal plane: plane formed by O.A and o, e light.

Incident plane: plane formed by incident light and the Normal.

If the principal section overlaps with the incident plane, then all planes overlap, i.e. i, o, e, OA and normal are in one plane.

Now we can give the polarization of o, e light:

The polarization of a light,  $ \vec{E}_{0}\perp $ principal plane.

The polarization of e light,  $ \vec{E}_{e} \parallel $ principal plane.

## 8 -4-2 Microscopic explanation of Birefringence

The difference between crystal and isotropic media is obviously because that crystals are generally electrical anisotropic.

As we have discussed earlier in the course, the refraction index is a macroscopic manifestation of the interaction between the light, and more specifically, the electrical field of the light with atoms/molecules. We have shown how the light field driving the atoms/molecules into oscillating dipoles, and emit out secondary wave. The resultant superposition of the secondary wave with the primary driving wave causes a change in the phase velocity and thus is the origin of index of refraction.

Example: Imagining for an isotropic (no directional preference) media, where molecules are arranged randomly as shown:

<div style="text-align: center;"><img src="imgs/img_in_image_box_226_1235_831_1405.jpg" alt="Image" width="50%" /></div>


A-B is a diatomic molecule and is random aligned. Clearly no

difference in the interaction of the o, e light with such media. However in a well arranged media, such as:

<div style="text-align: center;"><img src="imgs/img_in_image_box_228_245_800_424.jpg" alt="Image" width="48%" /></div>


The e, o light will interact with media differently and will experience different index of refraction.

In another simple 3-D model of crystal made of elements A, B, C, with lattice structure shown as: (AB plane is perpendicular to the paper)

<div style="text-align: center;"><img src="imgs/img_in_image_box_254_811_942_1192.jpg" alt="Image" width="57%" /></div>


It is easy to conclude that (let’s assume for simplicity light interacts strongly if its polarization parallel with the bond) $ ^{11} $:

(1) o light interact with A-B bond equally in all 3 lights' propagation

and the media appear “isotropic” to o light.

(2) The interaction of e light with media is anisotropic, it may interact with A-C (as in light 1) or A-C + A-B (in light 2) or A-B (in light 3), depends on the direction of light’s propagation (anisotropic).

(3) The interaction between o, e with lattice is same in light 3, most different in light 1.

(4) A-C-A is the optical axis for such crystal, along this direction, o, e has same index of reflection. n° = n° (as the definition of OA). Index of reflection for o light n° will be same for all directions of light’s propagation, while n° will generally depend on the direction of propagation. n° = n° along OA, n° - n° = max ⊥ OA (as in light 1).

Thus the cause of birefringence is due to: crystal lattice and anisotropic interaction between light and atoms/molecules.

Depend on the symmetry of crystal lattice, different crystals fall into:

<div style="text-align: center;"><img src="imgs/img_in_image_box_222_1031_791_1507.jpg" alt="Image" width="47%" /></div>


For the isotropic (cubic crystal lattice), the light propagation is same as the isotropic media that we have discussed. We shall only concern the light propagation in uniaxial crystals here, and leave out the biaxial crystal due to its complexity. (Actually in biaxial crystal, no ordinary light, both are extraordinary).

Since the o (ordinary) light obeys law of refraction  $ (n_{1}\sin i = n_{0}\sin i) $ with a single index of refraction  $ n_{0} $, we need only to concern with e light, and see how it propagates inside an uniaxial crystal.

The wavefront of e light is shown in Fig 1.5(b), Zhao's Pg. 168.

<div style="text-align: center;"><img src="imgs/img_in_image_box_445_762_722_954.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;">OA</div>


The velocity (here we use a general term velocity, instead of phase velocity, we shall see that for e light, there are two velocities, the phase velocity and ray velocity later) is an ellipsoid.

The velocity equals  $ v_{0} $ along the O.A. (same as that for o light), and equals  $ v_{e} $ (or  $ v_{\perp} $) in direction  $ \perp $ to OA. (Along these two directions. The phase and ray velocity are equal, this is why I use the general term of velocity here)

Define: Negative crystal

 $$ \begin{array}{r l r}&{\mathbf{n_{e}}=\frac{\mathbf{c}}{\mathbf{v_{e}}}}\\ {\mathbf{v_{e}}>\mathbf{v_{o}}}&{\mathrm{~o r~}}&{\mathbf{n_{e}}<\mathbf{n_{o}}}\\ &{\mathbf{n_{o}}=\frac{\mathbf{c}}{\mathbf{v_{o}}}}\end{array} $$ 

Positive crystal  $ v_{e} < v_{o} $ or  $ n_{e} > n_{o} $

● Huygens's method (drawing) to get lights propagation (dtails in Zhao's book Vol. 2 Chap. 7; 1.3)

e light is parallel or perpendicular with OA:

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_419_500_593.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_561_405_819_592.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_413_638_651_858.jpg" alt="Image" width="20%" /></div>


Above are the three special and simplest forms of light propagation in uniaxial crystal. They are also simplest to understand using Huygen's principle. These 3 special cases will be all we need for the manipulation of polarization.

For the general case (not required for this course), if the angle between e light and OA are not 0° or 90°, the direction of propagation of energy (ray direction) and the direction of equal-phase wave front no longer overlaps. (Direction of wave vector  $ \vec{k} $).

<div style="text-align: center;"><img src="imgs/img_in_image_box_193_153_832_526.jpg" alt="Image" width="53%" /></div>


Ray direction: direction of energy flow, given by the Poyning vector  $ \vec{S} = \vec{E} \times \vec{H} $, perpendicular to E,H.

Wave vector  $ \vec{k} $: Normal direction to the equal phase wave front. It is perpendicular to the D,H in a media, and in anisotropic media, the D, E are not along same direction as we shall see below.

● Phase velocity, ray velocity, phase velocity surface, ray velocity surface. (optional for this course)

<div style="text-align: center;"><img src="imgs/img_in_image_box_301_1042_813_1386.jpg" alt="Image" width="43%" /></div>


<div style="text-align: center;">Fig.8-1</div>


 $$ \angle\overline{\mathrm{O A}}\overline{\mathrm{k}}_{\mathrm{e}}=\theta\quad,\quad\angle\overline{\mathrm{O A}}\overline{\mathrm{S}}_{\mathrm{e}}=\xi\quad,\quad\angle\overline{\mathrm{S}}_{\mathrm{e}}\overline{\mathrm{k}}_{\mathrm{e}}=\alpha=\xi-\theta\quad,\quad\angle\overline{\mathrm{S}}_{\mathrm{e}}\overline{\mathrm{N}}=\mathrm{i}_{2}\quad, $$ 

 $$ \angle\overline{\mathrm{k}_{\mathrm{e}}}\overline{\mathrm{N}}=\mathrm{i}_{2}^{\prime}=\mathrm{i}_{2}+\alpha $$ 

The direction of energy propagating (Poynting vector  $ \vec{S}_{e} $) is different from wave vector  $ \vec{k}_{e} $.

This is caused by that in crystal, generally  $ \vec{D} $,  $ \vec{E} $ are not parallel.

D: electric displacement.

 $$ \vec{\mathrm{D}}=\varepsilon_{0}\vec{\mathrm{E}}+\vec{\mathrm{P}} $$ 

where

 $ \vec{\mathrm{P}} = \varepsilon_{0} \tilde{\chi} \vec{\mathrm{E}} $ (8-10)

polarizability Susceptibility tensor

Thus

 $$ \begin{aligned}\vec{\mathrm{D}}&=(1+\tilde{\chi})\varepsilon_{0}\vec{\mathrm{E}}\\&=\tilde{\varepsilon}\varepsilon_{0}\vec{\mathrm{E}}\\ Dielectric&t e n s o r\end{aligned} $$ 

In isotropic media,  $ \tilde{\varepsilon}=1+\tilde{\chi} $ is a scalar, and (8-11) shows that  $ \vec{\mathrm{D}}\parallel\vec{\mathrm{E}} $ in isotropic media.

In the anisotropic media,  $ \tilde{\varepsilon} $ is generally a tensor.  $ (3\times3\ \mathrm{matrix}) $

 $$ \vec{\mathrm{D}}=\begin{bmatrix}\mathrm{D}_{\mathrm{x}}\\ \mathrm{D}_{\mathrm{y}}\\ \mathrm{D}_{\mathrm{z}}\end{bmatrix}=\boldsymbol{\varepsilon}_{0}\tilde{\boldsymbol{\varepsilon}}\vec{\mathrm{E}}=\begin{bmatrix}\boldsymbol{\varepsilon}_{11}&\boldsymbol{\varepsilon}_{12}&\boldsymbol{\varepsilon}_{13}\\ \boldsymbol{\varepsilon}_{21}&\boldsymbol{\varepsilon}_{22}&\boldsymbol{\varepsilon}_{23}\\ \boldsymbol{\varepsilon}_{31}&\boldsymbol{\varepsilon}_{32}&\boldsymbol{\varepsilon}_{33}\end{bmatrix}\begin{bmatrix}\mathrm{E}_{\mathrm{x}}\\ \mathrm{E}_{\mathrm{y}}\\ \mathrm{E}_{\mathrm{z}}\end{bmatrix} $$ 

By properly choosing x, y, z direction in crystal, we can have  $ \tilde{\varepsilon} $ in

diagonal form, i.e.

 $$ \widetilde{\varepsilon}=\begin{bmatrix}{{{\varepsilon_{\mathrm{x}}}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{\varepsilon_{\mathrm{y}}}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{\varepsilon_{\mathrm{z}}}}}\end{bmatrix} $$ 

For isotropic crystal  $ \varepsilon_{\mathrm{x}}=\varepsilon_{\mathrm{y}}=\varepsilon_{\mathrm{z}} $

For uniaxial crystal  $ \varepsilon_{\mathrm{x}}=\varepsilon_{\mathrm{y}}\neq\varepsilon_{\mathrm{z}} $

For biaxial crystal  $ \varepsilon_{x} \neq \varepsilon_{y} \neq \varepsilon_{z} $

Clearly in anisotropic media,  $ \vec{D}, \vec{E} $ are not parallel.

From the Maxwell equation of E-M wave in crystal, for plane wave in forms of  $ \vec{\mathrm{A}}\mathrm{e}^{\mathrm{i}(\vec{\mathrm{k}}\cdot\vec{\mathrm{r}}-\theta\mathrm{k})} $ (the derivation is quite messy and thus omitted here) We have  $ \vec{\mathrm{D}}\times\vec{\mathrm{H}}\rightarrow\vec{\mathrm{k}} $,  $ \vec{\mathrm{E}}\times\vec{\mathrm{H}}\rightarrow\vec{\mathrm{S}} $,  $ \vec{\mathrm{E}},\vec{\mathrm{D}}\perp\vec{\mathrm{H}} $

<div style="text-align: center;"><img src="imgs/img_in_chart_box_220_453_660_762.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;">Fig 8.2</div>


So the propagation of energy (S) and propagation of equal-phase wavefront (k) is different in direction and velocity in anisotropic media.

For e light in uniaxial crystal, we need to define and distinguish two velocities: Ray velocity  $ v_{r} $, and phase velocity  $ v_{N} $

 $$ \mathbf{v}_{\mathrm{N}}=\mathbf{v}_{\mathrm{r}}\cos\alpha\quad(8-12) $$ 

Note that in Zhao’s book, Fig 1-5, 1-7, 1-8, 1-9, 1-10, the velocities used to draw the ellipse are ray velocities.

For the $e$ light, in definition of $\mathbf{n}_{o}=\frac{\mathbf{c}}{\mathbf{v}_{o}}, \mathbf{n}_{e}=\frac{\mathbf{c}}{\mathbf{v}_{e}}$, the $\mathbf{v}_{o}$ (or $\mathbf{v}_{\parallel}$), $\mathbf{v}_{e}$ (or $\mathbf{v}_{\perp}$) are phase velocities according to definition of $n$. However in cases of propagation along or perpendicular to $OA$, the ray velocity and phase velocity are equal. (See Fig 1-12, Zhao’s).

As derived in the Zhao’s book, Pg. 174, the angle between  $ \vec{S} $ and  $ \vec{k} $

with OA (Refer to Fig 8-1 in this note) has relation:

 $$ \cot\theta=\frac{\mathrm{n}_{\mathrm{o}}^{2}}{\mathrm{n}_{\mathrm{e}}^{2}}\cot\xi\qquad(8-13) $$ 

Example: For positive crystal n > n o , ξ < θ .

For the index of refraction of e light, whose phase velocity forms angle  $ \theta $ with the optical axis:

 $$ \begin{array}{l} \text{n}(\theta)=\displaystyle {\frac{c}{\mathbf{v}_{n}(\theta)}} \text{⚫ phase velocity} \\ \displaystyle = \frac{\mathbf{n}_{o} \mathbf{n}_{e}}{\sqrt{\mathbf{n}_{e}^{2} \cos^{2}\theta + \mathbf{n}_{o}^{2} \sin^{2}\theta}} \end{array} $$ 

 $ \therefore n(\theta) $ is the index of refraction defined by phase velocity. For the ordinary light, we have  $ n\sin i_1 = n_0\sin i_2 $——Snell's Law.

For e light, a similar relation exists between incident angle i₁ and angle between normal ∇ with wave vector ∇, i'₂ = i₂ + α (refer to Fig 8-1 of this note)

 $$ \begin{array}{r l}{\mathrm{n}\sin\mathrm{i}_{1}=\mathrm{n}(\theta)\sin\mathrm{i}_{2}^{\prime}\quad}&{{}\quad(8-14)}\end{array} $$ 

This however is not Snell's law, since n(θ) is not a constant, it varies as i' varies. The relation 8-14 will take a simple form if θ = 90° for all i₁, i'₂, as depicted in fig 1-10, Pg. 172 (Zhao's), n(θ) is constant = nₑ for the e light in this case.

<div style="text-align: center;"><img src="imgs/img_in_image_box_334_1325_629_1584.jpg" alt="Image" width="24%" /></div>


So (8-14) is just Snell's law in this case.

More generally, (8-14) is quite complicated to solve. However there are simple cases if say $\mathrm{i}_{1}=0$, normal incident light. Here from (8-14), $\mathrm{i}_{1}=0\to\mathrm{i}_{2}^{\prime}=0$. So that direction of $\vec{\mathrm{k}}$ is known and the $\theta$ will be known, then from (8-13) we can get $\xi,\alpha$, please refer to example on Pg. 175, Zhao's.

## 8 -5 Crystal Optical Elements

## 8 -5-1 Birefrigent polarizers

Using Birefrigent crystals, we can also get linear polarized light at the output.

For any input, the polarization can be decomposed into o, e component, and the o, e (linearly polarized) light propagate differently through crystal and can be separated.

(1) Rochon prism and Wollaston prism.

Fig 2-1, 2-2, Pg. 182-183, Zhao's

(2) Nicole prism and Glan-Foucault prism.

Fig 8.26, 8.27 Hecht

8-5-2 Wave plate——phase retarder

<div style="text-align: center;"><img src="imgs/img_in_image_box_205_1404_752_1571.jpg" alt="Image" width="45%" /></div>


e light polarization is along the OA direction. Both o and e light travel in the crystal perpendicular to the OA, thus:

o light propagates with  $ v_{0} $ and  $ n_{0} $

(phase velocity)

e light propagate with  $ v_{e} $ and  $ n_{e} $

This induces a different OPL for o, e light after distance d, thus induces a phase difference between o, e light. A phase difference for two perpendicular components means: change of polarization. Thus a common usage of wave plate is to change the polarization state of light.

 $$ \varphi_{_{0}}=\frac{2\pi}{\lambda_{_{0}}}\mathbf{n}_{_{0}}\mathbf{d}\quad phase\ lag\ of\ o\ light\ after\ passing\ d.(\varphi>0\ means $$ 

phase lag, also note my sign is different from the Zhao’s and is consistent with the sign convention for phases used in the notes. The physics meaning is same as Zhao’s, also relation 2.1 in Zhao’s p185 is wrong, the n_{e}, n_{o} is reversed)

 $$ \begin{aligned}&\varphi_{\mathrm{e}}=\frac{2\pi}{\lambda_{0}}\mathrm{n}_{\mathrm{e}}\mathrm{d}\\ &\\ \Delta\varphi=\varphi_{\mathrm{e}}-\varphi_{\mathrm{o}}=\frac{2\pi}{\lambda_{0}}(\mathrm{n}_{\mathrm{e}}-\mathrm{n}_{\mathrm{o}})\mathrm{d}\\ \end{aligned} $$ 

 $ \Delta\varphi > 0 \rightarrow \text{o component leads in phase.} $

 $ \Delta\varphi < 0 \rightarrow o $ component lags in phase.

Quarter wave plate ( $ \lambda/4 $ plate):  $ \Delta\varphi = \pm \frac{\pi}{2} $,  $ (n_e - n_0)d = \pm \frac{\lambda}{4} $

Half wave plate ( $ \lambda/2 $ plate):  $ \Delta\varphi = \pm \pi $,  $ (n_e - n_o)d = \pm \frac{\lambda}{2} $

Fast, Slow axis: Best illustrated by example: For $\frac{\lambda}{4}$ plate with $\Delta\varphi=\frac{\pi}{2}$, $n_e>n_0$ (positive crystal), the $o$ component leads $e$ component and $o$ light travels faster than $e$, so the $\bar{o}$ direction is called fast axis, $\bar{e}$ direction (it is also the OA direction) is slow axis.

For  $ \Delta\varphi=-\frac{\pi}{2} $, the situation just reversed. Same apply for  $ \frac{\lambda}{2} $ plate.

In summary, for a phase retarder: (wave plate)

(1) optical axis parallel with surface

(2) o, e direction. The direction of polarization of o, e light. e direction is along the O.A. (according to the definition of e light polarization || principal plane)

(3) Fast, slow axis of wave plate

The light with polarization along fast axis travels fast, or leads in phase.

For positive crystal  $ (n_e > n_o) $  $ \Delta\varphi = \frac{2\pi}{\lambda}(n_e - n_o)d > 0 $, o direction is the fast axis.

For negative crystal  $ (n_e < n_o) \Delta \varphi = \frac{2\pi}{\lambda} (n_e - n_o) d < 0 $, e light leads in phase, e direction (or O.A.) is the fast axis.

## 8 -5-2-1  $ \frac{\lambda}{4} $ wave plate

 $ \Delta\varphi=\pm\pi/2 $ (positive crystal gives  $ \pi/2 $; negative crystal gives  $ -\pi/2 $)

The basic question is what happens for light with different polarizations passing  $ \frac{\lambda}{4} $ plate? It can be worked out following systematic steps below:

(1) Decompose the incoming light into o, e components for the  $ \frac{\lambda}{4} $

plate.

<div style="text-align: center;"><img src="imgs/img_in_image_box_276_569_587_824.jpg" alt="Image" width="26%" /></div>


There shall be a phase difference  $ \delta_{\mathrm{in}} = \varphi_e - \varphi_o $ between  $ A_e^{\mathrm{in}} $,  $ A_o^{\mathrm{in}} $ components of the input depending on the incoming light polarization state. The polarization state expressed as o, e components will be  $ \left[\begin{array}{c} A_e^{\mathrm{in}} \\ A_o^{\mathrm{in}} \end{array} \right] $. (above choosing e as X axis is arbitrary and I shall stick to this convention)

(2) After passing  $ \lambda/4 $,  $ A_e^{out} = A_e^{in} $,  $ A_o^{out} = A_o^{in} $, but there shall be an extra phase difference  $ \pm\pi/2 $. (Phase difference between e,o components)

In Jones vector term:  $ \begin{bmatrix} A_e^{in} \\ A_o^{in} e^{-i(\delta_in \pm \pi/2)} \end{bmatrix} $ is the output.

Example in Zhao’s Pg. 195-196.

An example (essentially question 7, Pg. 201, Zhao's):

<div style="text-align: center;"><img src="imgs/img_in_image_box_199_204_984_586.jpg" alt="Image" width="65%" /></div>


The polarization analysis for the incoming light passing the wave plate and the reflection is easy to analysis, and details skipped here. The mirror reflection will change the right circular input into the left circular output (think about reasoning yourself). For the reflected light (left circular), the natural coordinate should be o-e' (this is different for the initial input, where the coordinate is o-e), in the o-e' coordinate,  $ \delta_{\text{in}} = \varphi_e' - \varphi_o = -\frac{\pi}{2} $, then  $ \delta_{\text{out}} = 0 $, so it is linear polarized light with polarization along the dashed line above (bisect o, e' axis) which is  $ \perp $ with input.

In summary,  $ \frac{\lambda}{4} $ plate is used to realize the transformation among polarization states of light. i.e., linear  $ \longleftrightarrow $ circular or elliptical etc.

## 8 -5-2-2  $ \frac{\lambda}{2} $ plate

 $ \lambda/2 $ plate “flips” the direction of polarization (output, input have same polarization type, with a directional change) symmetric to the o or e

axis, the derivation is quite simple following the procedure listed above.

<div style="text-align: center;"><img src="imgs/img_in_image_box_354_215_803_323.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_348_352_818_456.jpg" alt="Image" width="39%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_358_489_819_593.jpg" alt="Image" width="38%" /></div>


With the linear polarizer, quarter wave plate and half wave plate, we can create any desired polarization in practice, as well as analyze the polarization state of light.

## 8 -5-2-3 Interferometer using polarizer and wave plate (optional)

Fig. 4-1, 4-2, Zhao's, Pg. 202-207

This part is described in detail in Zhao's book, place refer to the book for detail.

Generally speaking, the wave plate will induce a phase difference between o, e (they are orthoganol) components and will not create interference (Recall the condition for interference). Thus need the linear polarizer to project the o, e components along the linear polarization and interference will be generated. The interference pattern would mainly depend on the phase difference created by the wave plate,

$$\Delta = \frac{2\pi}{\lambda} (\mathrm{n_e} - \mathrm{n_o}) \mathrm{d},$$ and for two important configuration as shown in Fig 4-2,

Pg. 205, Zhao's.

 $$ \begin{cases}\mathbf{P}_{1}\perp\mathbf{P}_{2}&\quad\mathbf{I}_{2}=\mathbf{A}_{1}^{2}(1-\cos\Delta)/2\\\mathbf{P}_{1}\parallel\mathbf{P}_{2}&\quad\mathbf{I}_{2}=\mathbf{A}_{1}^{2}(1+\cos\Delta)/2\end{cases} $$ 

 $$ \Delta=\frac{2\pi}{\lambda}(\mathrm{n}_{\mathrm{e}}-\mathrm{n}_{\mathrm{o}})\mathrm{d} $$ 

 $$ (8-18) $$ 

a) If d is fixed,  $ \Delta $ depends on  $ \lambda $, so is the transmission  $ I_{2} $. This is a birefrigent color filter.

b) If  $ \lambda $ is fixed,  $ \Delta $ depends on  $ (\mathrm{n}_{\mathrm{e}}-\mathrm{n}_{\mathrm{o}})\mathrm{d} $, so is the  $ I_{2} $

 $ \left\{\begin{array}{l}\left(\mathrm{n}_{\mathrm{e}}-\mathrm{n}_{\mathrm{o}}\right)\text { fixed }\longrightarrow\quad \text { equal thickness interference } \\ d\text { is fixed, } \left(\mathrm{n}_{\mathrm{e}}-\mathrm{n}_{\mathrm{o}}\right)\text { varies }\longrightarrow\quad \text { photo elasticity }\end{array}\right. $

## 8 -5-3 Induced Birefringence

## 8 -5-3-1 Mechanical Induced Birefringence——photo elasticity

Basically, this is caused by the external or internal mechanical force act on a media, and makes the original isotropic media into anisotropic (molecules oriented somewhat orderly).

See Fig 4.4, 4.5, Zhao's Pg. 208.

The setup is simply the interferometer by wave plate + linear polarizer we just discussed above, which can be used to display the interference pattern arising from mechanical stress.

## 8 -5-3-2 Electro-Induced Birefringence

## (1) Kerr effect

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_1554_958_1684.jpg" alt="Image" width="58%" /></div>


 $ P_{1} \perp P_{2} $, without applied voltage, liquid cell is isotropic, so no output light.

With applied field, the original isotropic liquid will become anisotropic, the molecules will align with the field. The liquid cell behaves similar to uniaxial crystal, with optical axis (OA) in the direction of the external  $ \bar{E} $ field. (This is easy to visualize using the microscopic model discussed earlier, Pg. 282 of this note).

 $$ \begin{aligned}&\Delta\mathbf{n}\equiv\mathbf{n}_{\mathrm{e}}-\mathbf{n}_{\mathrm{o}}=\mathbf{n}_{\parallel}-\mathbf{n}_{\perp}=\mathbf{K}\mathbf{E}^{2}\lambda_{0}=\mathbf{K}\lambda_{0}(\frac{\mathbf{V}}{\mathbf{d}})^{2}\\ &\\ &\Delta\varphi=\frac{2\pi}{\lambda_{0}}\Delta\mathbf{n}\mathbf{l}=2\pi\mathbf{K}\mathbf{l}(\frac{\mathbf{V}}{\mathbf{d}})^{2}\quad(8-19)\\ \end{aligned} $$ 

Table 8.3, Hecht's Pg. 364 listed some Kerr constants K.

(2) Pockel's effect.

<div style="text-align: center;"><img src="imgs/img_in_image_box_251_1075_1047_1311.jpg" alt="Image" width="66%" /></div>


Without external field, no birefringence since light propagate along the O.A.—→no output.

With the external field, the uniaxial crystal becomes biaxial, and

birefringence occurs. It has been shown that:

 $$ \Delta n\propto V $$ 

∴ pocket's effect is a linear electro-optic effect.

 $$ \Delta\varphi=\pi\frac{\mathbf{V}}{\mathbf{V}_{\lambda/2}} $$ 

V_{\lambda/2} is the voltage required for a specific crystal to create an equivalent effect of  $ \lambda/2 $ wave plate, or phase change of  $ \pi $ between o, e light.

Table 8-4, Hecht's, Pg. 365 listed some  $ V_{\lambda/2} $.

Both Kerr and Pockets effect are widely used in devices as fast “optical shutter” or “optical modulator”, such as the Q-switch in pulsed laser is essentially a Pockets device.

## 8 -5-4 Jones Matrix for polarizer and wave plate

Table 8.6, Hecht's, Pg. 370.

 $$  Linear Polarizer\left\{\begin{aligned}P&horizontal\quad\longleftrightarrow\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\\ P&vertical\quad\longleftrightarrow\begin{bmatrix}{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\\ P&\pm45^{\circ}\quad vs.\ x\quad\begin{aligned}45^{\circ}\quad&\quad\frac{1}{2}\begin{bmatrix}{{{1}}}&{{{\pm1}}} \\{{{\pm1}}}&{{{1}}}\end{bmatrix}\\&\quad-45^{\circ}\quad\end{aligned}\end{aligned}\right. $$ 

 $$ \begin{aligned}&\frac{\lambda}{4}\text{plate}\left\{\begin{aligned}\\ &\text{fast axis horizontal}\quad\mathrm{e}^{\mathrm{i}\pi/4}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{\mathrm{i}}}}\end{bmatrix}\\&\text{fast axis vertical}\quad\mathrm{e}^{\mathrm{i}\pi/4}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{-\mathrm{i}}}}\end{bmatrix}\\&\text{fast axis}\pm45^{\circ}\quad\mathrm{e}^{\mathrm{i}\frac{\pi}{4}}\begin{bmatrix}{{{1}}}&{{{\mp\mathrm{i}}}} \\{{{\mp\mathrm{i}}}}&{{{1}}}\end{bmatrix}\end{aligned}\right.\\ \end{aligned} $$ 

Circular polarizer right

 $$ \frac{1}{2}\begin{bmatrix}{{{1}}}&{{{i}}} \\{{{-i}}}&{{{1}}}\end{bmatrix} $$ 

Circular polarizer left

 $$ \frac{1}{2}\begin{bmatrix}1&-i\\ i&1\end{bmatrix} $$ 

Actually for arbitrary angle  $ \theta $ of the axis, (including the  $ \pm45^{\circ} $ listed above) can be derived with the horizontal or vertical matrices (Please also refer to the supplementary material on Dirac notation).

Below is a simple derivation:

<div style="text-align: center;"><img src="imgs/img_in_image_box_286_925_729_1300.jpg" alt="Image" width="37%" /></div>


A rotation of vector  $ \vec{A} $ in x-y coordinate by  $ -\theta $, the coordinate for the new vector  $ \vec{A}' $ in x-y is equivalent to  $ \vec{A} $ be coordinate in  $ x' $-y coordinate system  $ x' $-y', which is rotated  $ \theta $ with respect to x-y.

 $ x', y' $: component of  $ \vec{A} $ in  $ x' $-y' coordinate system will be

 $$ \mathrm{x}_{\mathrm{A}}^{\prime}=\cos\theta\mathrm{x}_{\mathrm{A}}+\sin\theta\mathrm{y}_{\mathrm{A}} $$ 

 $$ \mathrm{y}_{\mathrm{A}}^{\prime}=-\sin\theta\mathrm{x}_{\mathrm{A}}+\cos\theta\mathrm{y}_{\mathrm{A}}. $$ 

 $$ \therefore\begin{bmatrix}\mathbf{x}_{\mathrm{A}}^{\prime}\\ \mathbf{y}_{\mathrm{A}}^{\prime}\end{bmatrix}=\begin{bmatrix}\cos\theta&\sin\theta\\ -\sin\theta&\cos\theta\end{bmatrix}\begin{bmatrix}\mathbf{x}_{\mathrm{A}}\\ \mathbf{y}_{\mathrm{A}}\end{bmatrix} $$ 

 $$ \hat{R}_{\theta}=\begin{bmatrix}\cos\theta&\sin\theta\\ -\sin\theta&\cos\theta\end{bmatrix} $$ 

 $ \hat{R}_{\theta} $ is the rotational matrix of rotating coordinate system by  $ \theta $, the coordinate in the new rotated coordinate system  $ \begin{bmatrix} x' \\ y' \end{bmatrix} $ is related to the  $ \begin{bmatrix} x \\ y \end{bmatrix} $ of the original coordinate system by (8-21). (This is equivalent to the vector rotated by  $ -\theta $ with fixed coordinate system).

If the transformation by an optical element (an operation represented by matrix) in one coordinate system is:

 $$ \begin{bmatrix}\mathbf{x}_{\text{out}}\\ \mathbf{y}_{\text{out}}\end{bmatrix}=\quad\hat{o}\begin{bmatrix}\mathbf{x}_{\text{in}}\\ \mathbf{y}_{\text{in}}\end{bmatrix} $$ 

In a rotated coordinate system, then

 $$ \begin{bmatrix}\mathbf{x}^{\prime}\\ \mathbf{y}^{\prime}\end{bmatrix}=\quad\hat{R}_{\theta}\begin{bmatrix}\mathbf{x}\\ \mathbf{y}\end{bmatrix}\qquad\quad or\qquad\begin{bmatrix}\mathbf{x}\\ \mathbf{y}\end{bmatrix}=\quad\hat{R}_{\theta}^{-1}\begin{bmatrix}\mathbf{x}^{\prime}\\ \mathbf{y}^{\prime}\end{bmatrix} $$ 

 $ \hat{R}_{\theta}^{-1} $ is the reverse operation of  $ \hat{R}_{\theta} $, for rotation it is easy to see is just  $ \hat{R}_{-\theta}(\hat{R}_{\theta}^{-1}=\hat{R}_{-\theta}=\hat{R}_{\theta}^{T}) $.

Then (8-23) becomes:

 $$ \hat{R}_{\theta}^{-1}\begin{bmatrix}\mathbf{x}_{\text{out}}^{\prime}\\ \mathbf{y}_{\text{out}}^{\prime}\end{bmatrix}=\hat{o}\hat{R}_{\theta}^{-1}\begin{bmatrix}\mathbf{x}_{\text{in}}^{\prime}\\ \mathbf{y}_{\text{in}}^{\prime}\end{bmatrix} $$ 

 $$ \begin{aligned}\begin{bmatrix}\mathbf{x}_{\text{out}}^{\prime}\\ \mathbf{y}_{\text{out}}^{\prime}\end{bmatrix}&=\quad\widehat{R}_{\theta}\widehat{o}\widehat{R}_{\theta}^{-1}\begin{bmatrix}\mathbf{x}_{\text{in}}^{\prime}\\ \mathbf{y}_{\text{in}}^{\prime}\end{bmatrix}\end{aligned} $$ 

 $$ \therefore\quad\hat{o}^{\prime}=\quad\hat{R}_{\theta}\hat{o}\hat{R}_{\theta}^{-1} $$ 

ô' is the operation matrix in the new coordinate system.

Confirm this with +45 linear polarizer ↗, knowing ↔ case is

L₀ = [1 0] , +45 in the rotated 45° coordinate system is

just same ; then in the ↔ system(or H-V basis), which is

simply the rotated -45° of the original (x-y), put θ = -45° into (8-24),

we can find the expression for the +45 linear polarizer in H-V basis:

<div style="text-align: center;"><img src="imgs/img_in_image_box_460_391_620_496.jpg" alt="Image" width="13%" /></div>


 $$ \begin{aligned}\mathrm{L}_{45^{\circ}}&=\begin{bmatrix}{{{\cos45^{\circ}}}}&{{{-\sin45^{\circ}}}} \\{{{\sin45^{\circ}}}}&{{{\cos45^{\circ}}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{\cos45^{\circ}}}}&{{{\sin45^{\circ}}}} \\{{{-\sin45^{\circ}}}}&{{{\cos45^{\circ}}}}\end{bmatrix}\\&=\frac{1}{2}\begin{bmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{bmatrix}.\end{aligned} $$ 

For an arbitrary  $ \theta $, the linear polarizer,  $ \frac{\lambda}{4} $ plate then can be easily worked out by (8-24), starting from the horizontal matrix.

(For those familiar with linear algebra, you see right away what I did here is similarity transformation of matrix; this is called method 0 in my supplementary to find the matrix representation of a physical operator; there are other equivalent methods and examples are provided in the supplements)

For the optical elements, its operation on the polarization state of light is represented by a matrix,  $ \hat{o} $, then if knowing the input and  $ \hat{o} $, getting output polarization state will be straightforward.

 $$ \hat{o}\ \vec{E}=\hat{o}\begin{bmatrix}\mathbf{A}\\ \mathbf{B}\end{bmatrix}=\begin{bmatrix}\mathbf{A}^{\prime}\\ \mathbf{B}^{\prime}\end{bmatrix} $$ 

For multiple elements:

 $$ \hat{o}_{\mathrm{~n~}}\cdots\hat{o}_{\mathrm{~1~}}\vec{\mathrm{E}}=\quad\hat{o}_{\mathrm{~n~}}\cdots\hat{o}_{\mathrm{~1~}}\begin{bmatrix}\mathrm{A}\\ \mathrm{B}\end{bmatrix}=\begin{bmatrix}\mathrm{A}^{\prime}\\ \mathrm{B}^{\prime}\end{bmatrix} $$ 

Note: the order of matrix is important. The operation is not commute, i.e.

 $ \hat{o}_{1}\hat{o}_{2}\neq\hat{o}_{2}\hat{o}_{1} $

Example: circular polarizer by P1 (45°) + λ/4 plate.

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_536_924_769.jpg" alt="Image" width="58%" /></div>


The input polarization is  $ \begin{bmatrix} A \\ B \end{bmatrix} $, then the output:

 $$ \begin{bmatrix}\mathbf{A}^{\prime}\\\mathbf{B}^{\prime}\end{bmatrix}=\hat{Q}_{V-fast}\hat{L}_{45^{\circ}}\begin{bmatrix}\mathbf{A}\\\mathbf{B}\end{bmatrix}=\mathbf{e}^{\mathrm{i}\pi/4}\begin{bmatrix}1&0\\0&-\mathrm{i}\end{bmatrix}\frac{1}{2}\begin{bmatrix}1&1\\1&1\end{bmatrix}\begin{bmatrix}\mathbf{A}\\\mathbf{B}\end{bmatrix}\propto\begin{bmatrix}1&0\\0&-\mathrm{i}\end{bmatrix}\frac{1}{2}\begin{bmatrix}\mathbf{A}+\mathbf{B}\\\mathbf{A}+\mathbf{B}\end{bmatrix}\propto\begin{bmatrix}1\\-\mathrm{i}\end{bmatrix} $$ 

the output is right circular polarized light.

Certainly for this simple case, direct analysis of o, e component will give the same result and is probably more simple, but as optical elements increases, the matrix method will display its power (very similar to the Ray tracing in Geometric optics).

## 8 -5-4-2 Eigenvectors and Eigenvalues of Jones Matrix

(a) Definition of eigenvector, eigenvalue.

For a matrix  $ \hat{o} $, its Eigenvectors satisfy:

 $$ \hat{o}\;\vec{\mathrm{~A~}}=\varepsilon\vec{\mathrm{~A~}},\quad(8-26) $$ 

 $ \varepsilon $ is a scalar number, which is called the eigenvalue of the matrix.

The above relation shows that the eigenvectors of a matrix (or operation) will not change after interact with the matrix, except for a constant scalar.

* Physically, a state (Be the polarization state of light, or energetic state in atoms/molecules .....) is usually represented as a vector (spanned in some coordinate, x-y for polarized light, multidimensional Hilbert space for quantum states in quantum mechanics). An operation on the state (such as the polarized light passes a wave plate; or measuring energy of some molecular states .....) is generally represented by an “Operator”, and it is in form of matrix.

The eigenstate (or eigenvector) of an operator (or matrix) is a special state that won't be affected by the operation, only modified by a constant—— its eigenvalue.

(b) Eigenvectors of Jones Matrix (a 2-d matrix)

 $$ \hat{o}=\begin{bmatrix}{{{a}}}&{{{c}}} \\{{{b}}}&{{{d}}}\end{bmatrix}\qquad\vec{A}=\begin{bmatrix}{{{A}}} \\{{{B}}}\end{bmatrix} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_552_1193_720_1357.jpg" alt="Image" width="14%" /></div>


If  $ \vec{A} $ is eigenvector of  $ \hat{o} $, then:

 $$ \hat{o}\ \vec{A}=\begin{bmatrix}{{{a}}}&{{{c}}} \\{{{b}}}&{{{d}}}\end{bmatrix}\begin{bmatrix}{{{A}}} \\{{{B}}}\end{bmatrix}=\varepsilon\begin{bmatrix}{{{A}}} \\{{{B}}}\end{bmatrix} $$ 

We need to find out the form of  $ \vec{A} $, and  $ \varepsilon $, given  $ \hat{o} $

Rearrange the above:

 $$ \begin{bmatrix}\mathbf{a}-\boldsymbol{\varepsilon}&\mathbf{b}\\ \mathbf{c}&\mathbf{d}-\boldsymbol{\varepsilon}\end{bmatrix}\begin{bmatrix}\mathbf{A}\\ \mathbf{B}\end{bmatrix}=0 $$ 

In order to have non-trivial solution of A, B (A=0, B=0 is the trivial one) requires:

The determinant  $ \begin{vmatrix} a - \varepsilon & b \\ c & d - \varepsilon \end{vmatrix} = 0 $

Secular equation

Or  $ (a - \varepsilon)(d - \varepsilon) - bc = 0. $

Solving this will give two  $ \varepsilon_{1} $,  $ \varepsilon_{2} $, the eigenvalues in this 2-dimensional case. Then the A, B's corresponding to certain  $ \varepsilon $ can then be determined by:

 $$ \begin{cases}(a-\varepsilon)A+bB=0\\ cA+(d-\varepsilon)B=0\end{cases} $$ 

Most times we only interested in the normalized vectors, so there is also a condition for normalization of  $ \begin{bmatrix} A \\ B \end{bmatrix} $, i.e.

 $$  AA^{*}+BB^{*}=1 $$ 

Using fast axis horizontal  $ \lambda/4 $ plate as example:

 $$ \hat{o}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{\mathrm{i}}}}\end{bmatrix}\qquad(neglect\mathrm{e}^{\mathrm{i}\pi/4},won^{\prime}t affect results) $$ 

Then (8-27) becomes  $ (1-\varepsilon)(i-\varepsilon)=0 $

 $$ \varepsilon_{1}=1\quad,\quad\varepsilon_{2}=1 $$ 

(Here is extremely simple, since the eigenvalue is just the diagonal

elements for an already diagonalized matrix)

 $$  For\ \varepsilon_{1}=1,(8-28)\implies\begin{cases}(1-1)A=0\\ (i-1)B=0\end{cases}\implies\begin{cases}A\neq0\\ B=0\end{cases}\implies\begin{cases}A=1(or e^{i\varphi})\\ B=0\end{cases} $$ 

by the normalization condition.

 $$ \varepsilon_{2}=\mathrm{i},\begin{cases}(1-\mathrm{i})\mathrm{A}=0\\\mathrm{(i}-\mathrm{i})\mathrm{B}=0\end{cases}\longrightarrow\begin{cases}\mathrm{A}=0\\\mathrm{B}=1\end{cases} $$ 

 $$ \therefore\quad\varepsilon_{1}=1,eigenvector is\begin{bmatrix}1\\ 0\end{bmatrix}\quad\xrightarrow{\lambda/4}\begin{bmatrix}1\\ 0\end{bmatrix} $$ 

 $$ \varepsilon_{2}=\mathrm{i},\mathrm{eigenvector}\mathrm{is}\begin{bmatrix}0\\ 1\end{bmatrix}\xrightarrow{\lambda/4}\begin{bmatrix}0\\ 1\end{bmatrix}=\mathrm{e}^{\mathrm{i}\pi/2}\begin{bmatrix}0\\ 1\end{bmatrix} $$ 

(the common phase factor is neglected above)

The results certainly make sense, since we already know that for a  $ \lambda/4 $ plate, if the incoming light is linear polarized, and if the polarization is parallel with either o, e axis of the plate, the output will be same linear polarized light; and there will be a phase difference between the o, e light.

For the simple device or operation of a  $ \lambda/4 $ plate etc., it is easy to see its eigenvectors and eigenvalues. However for more complicated systems, this will not be the case. Our above derivation solving the eigenvalues and eigenvectors through secular equation applies for the complicated situations too. The method plays an important role in quantum mechanics, where solving for eigenvectors and eigenvalues of an “operator” is one of the central problems in Q.M.

After knowing the eigenvector, the operation by the “operator” on any arbitrary state can be solved if we decompose the arbitrary state into components of eigenvectors. You see that is why we always decompose light into o-e components in studying wave plates, o-e are the eigenvectors for the wave plate.

## 8 -6 Optical activity (Circular Birefringence)

## 8 -6-1 Definition

Optical activity: rotation of a linear polarized light after passing a media.

(Fig 5-2, Zhao’s, Pg. 216, Fig 8.53, Hecht’s)

<div style="text-align: center;"><img src="imgs/img_in_image_box_199_883_817_1104.jpg" alt="Image" width="51%" /></div>


For certain crystal or liquid,  $ P_{out} $ is right-hand rotated——dextrorotatory

<div style="text-align: center;"><img src="imgs/img_in_image_box_222_1173_518_1316.jpg" alt="Image" width="24%" /></div>


P_{out} is left-handed rotated——levorotatory

<div style="text-align: center;">i.e.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_287_1387_412_1544.jpg" alt="Image" width="10%" /></div>


## 8 -6-2 Optical Activity in Crystal

For a crystal with length d, rotated angle  $ \psi $ :

 $ \psi = \alpha d \quad (8-30) $

 $ \alpha $ : rotatory power.

The  $ \alpha $ of quartz (SiO $ _{2} $ crystal) is given in Table VII-4, Pg. 216, Zhao's. Clearly  $ \alpha $ is dependent on wavelength  $ \lambda_{0} $, this is called rotatory dispersion.

The rotation of linear polarized light depends on the crystalline of the material. For SiO₂, one crystalline D, gives rise to dextrorotatory; the other crystalline L, gives rise to levorotatory. The D,L crystalline is mirror image of each other and has same value of rotatory power, but different sign. Here α > 0 for levorotatory; α < 0 for dextrorotatory. (This sign convention in crystal is different than that used in liquid, as we shall see. This is just a man-made artifact)

In the linear birefringence we discussed earlier, we see that o, e linear polarized light travel at different speed in crystal, and the o, e lights are eigenvectors of the linear birefringent crystals, i.e. if the input is o light or e light, the output is also o or e light.

For the optical active crystals, this is clearly not the case, such as in  $ \mathrm{SiO}_{2} $, the input light is linearly polarized and propagate along the optical axis of the  $ \mathrm{SiO}_{2} $, but the output is not the original input, but rotated by an angle. So the o, e light is not eigenvectors in this case.

Optical activity as we shall see is not caused by linear birefringence, but by circular birefringence, a process similar to the linear birefringence.

## 8 -6-3 Circular Birefringence

In an optical active media, the left and right circular polarized lights are eigenvectors, and they travel with different speed.

 $$ \mathbf{k}_{\mathrm{R}}=\mathbf{n}_{\mathrm{R}}\boldsymbol{\omega}/\mathbf{c}=\frac{2\pi}{\lambda_{0}}\mathbf{n}_{\mathrm{R}} $$ 

 $$ \mathbf{k}_{\mathrm{L}}=\mathbf{n}_{\mathrm{L}}\boldsymbol{\omega}/\mathbf{c}=\frac{2\pi}{\lambda_{0}}\mathbf{n}_{\mathrm{L}} $$ 

So the right and left circular polarized light in the optical active media can be expressed as:

<div style="text-align: center;"><img src="imgs/img_in_image_box_171_831_759_987.jpg" alt="Image" width="49%" /></div>


For a linear polarized light  $ \begin{bmatrix} 1 \\ 0 \end{bmatrix} $  $ \vec{x} $ polarized:

 $$ \begin{bmatrix}1\\ 0\end{bmatrix}=\frac{1}{2}\begin{bmatrix}1\\ -\mathrm{i}\end{bmatrix}+\frac{1}{2}\begin{bmatrix}1\\ \mathrm{i}\end{bmatrix} $$ 

After passing distance l in the optical active media, the complex amplitude of light becomes (neglect the same  $ \omega $ part)

 $$ \frac{1}{2}\begin{bmatrix}1\\ -\mathrm{i}\end{bmatrix}\mathrm{e}^{\mathrm{i}\mathrm{k}_{\mathrm{R}}\mathrm{l}}+\frac{1}{2}\begin{bmatrix}1\\ \mathrm{i}\end{bmatrix}\mathrm{e}^{\mathrm{i}\mathrm{k}_{\mathrm{L}}\mathrm{l}}=\frac{1}{2}\mathrm{e}^{\mathrm{i}\frac{\mathrm{k}_{\mathrm{R}}+\mathrm{k}_{\mathrm{L}}}{2}\mathrm{l}}\begin{cases}\begin{bmatrix}1\\ \mathrm{e}^{\mathrm{i}\frac{\mathrm{k}_{\mathrm{R}}-\mathrm{k}_{\mathrm{L}}}{2}\mathrm{l}}+\begin{bmatrix}1\\ \mathrm{i}\end{bmatrix}\mathrm{e}^{-\mathrm{i}\frac{\mathrm{k}_{\mathrm{R}}-\mathrm{k}_{\mathrm{L}}}{2}\mathrm{l}}\end{bmatrix}\end{cases} $$ 

let  $ \varphi = \frac{1}{2}(k_{\mathrm{R}} + k_{\mathrm{L}})l $

 $$ \psi=\frac{1}{2}(\mathrm{k}_{\mathrm{R}}-\mathrm{k}_{\mathrm{L}})\mathrm{l} $$ 

The above relation becomes:

 $$ \mathbf{e}^{\mathrm{i}\varphi}\left[\frac{1}{2}\begin{bmatrix}1\\ -\mathrm{i}\end{bmatrix}\mathbf{e}^{\mathrm{i}\psi}+\frac{1}{2}\begin{bmatrix}1\\ \mathrm{i}\end{bmatrix}\mathbf{e}^{-\mathrm{i}\psi}\right]=\mathbf{e}^{\mathrm{i}\varphi}\left[\begin{aligned}&\frac{1}{2}(\mathbf{e}^{\mathrm{i}\psi}+\mathbf{e}^{-\mathrm{i}\psi})\\ &-\frac{1}{2}\mathrm{i}(\mathbf{e}^{\mathrm{i}\psi}-\mathbf{e}^{-\mathrm{i}\psi})\end{aligned}\right]=\mathbf{e}^{\mathrm{i}\psi}\left[\begin{aligned}&\cos\psi\\ &\sin\psi\end{aligned}\right] $$ 

(8-33) is a Jones vector for linear polarized light, however compare with the original  $ \begin{bmatrix} 1 \\ 0 \end{bmatrix} $,  $ \vec{x} $ polarized light.  $ \begin{bmatrix} \cos \psi \\ \sin \psi \end{bmatrix} $ is rotated by angle  $ \psi $ with respect to the  $ \vec{x} $ axis. (Here also  $ \psi > 0 \rightarrow $ levorotatory;  $ \psi < 0 $ right rotatory as we defined.)

 $$ \psi<0\colon\qquad\overbrace{\psi}^{\longrightarrow\mathrm{x}}\qquad\qquad\psi>0\colon\qquad\qquad\overbrace{\psi}^{\longrightarrow_{\mathrm{x}}} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_792_691_913_768.jpg" alt="Image" width="10%" /></div>


 $$ \psi=\frac{1}{2}(\mathrm{k}_{\mathrm{R}}-\mathrm{k}_{\mathrm{L}})\mathrm{l}=\frac{\pi}{\lambda_{0}}(\mathrm{n}_{\mathrm{R}}-\mathrm{n}_{\mathrm{L}})\mathrm{l} $$ 

Compare with (8-30), it is clear that the rotatory power

 $$ \alpha=(n_{R}-n_{L})\pi/\lambda_{0} $$ 

 $ \alpha > 0, \ n_R > n_L $, it is levorotatory (left hand)

 $ \alpha < 0, \ n_R < n_L $, it is dextrorotatory (right hand)

From the derivation above, the cause of rotation of the incoming linear polarized light, is a result of difference in  $ n_{R} $ and  $ n_{L} $, so it is caused by circular birefringence.

As we mentioned earlier, different crystalline give rise to levorotatory and dextrorotatory, with same power. This means the  $ n_{R} $,  $ n_{L} $ in the two crystalline are simply flipped, i.e.:

Levo-crystal (left handed crystal line)

Symbol:  $ n_{R}^{1} $

Right circular light.

<div style="text-align: center;"><img src="imgs/img_in_image_box_336_254_419_375.jpg" alt="Image" width="6%" /></div>


And we have relation:  $ \parallel \parallel $

 $ n_{R}^{d} < n_{L}^{d} $

The right, left circular polarized light as eigenvectors (eigenstates) of the circular birefrigent crystals is neatly demonstrated by the Fresnel composite prisms. (Fig 8.52, Hecht's, Fig 5.6, Zhao's, Pg. 220).

<div style="text-align: center;"><img src="imgs/img_in_image_box_261_759_700_993.jpg" alt="Image" width="36%" /></div>


Here if the income is linear polarized light as shown in the figure the output are left and right circular polarized light; If the income is circular polarized, then the output is also the same circular polarized light.

In a crystal, such as quartz (SiO₂) which can have both linear birefringence and circular birefringence, the propagation of light inside it is complicated, the eigenstates depend on the direction of light propagation. As shown in Fig 5-7, Zhao’s, Pg221.

## In Quartz:

Direction of light propagation          Eigenstates

|| OA                                      circular R, L    circular birefringence

⊥ OA                                      o, e linear     linear birefringence

other direction                    right/left elliptical    elliptical birefringence

## 8 -6-4 Optical activity in solution

Not only crystal, but also many organic solutions display optical activity. This can be used to measure the concentration of solution.

 $ \psi = [\alpha]\text{Nl} \quad (8-35) $

[α]: relative rotatory power. In units: degree/dm·cg/cm³,

N: concentration. In unit: g/cm $ ^{3} $

l: length. In unit: dm.

Here,  $ [\alpha] > 0 $ is defined as representing dextrorotatory, in contrary to what we have in crystal.

The optical activity in solution is caused by chiral molecules, i.e. the molecules have isomers that are “hand” like.

These isomers have structures that are mirror image of each other.

For example:

<div style="text-align: center;">(d)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_326_1321_700_1453.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">(1)</div>


___ isomers ___

One of the isomers will be dextro-, and the other will be levo-, with same value of rotatory power but different sign. Such chiral molecules play important roles in chemistry and biology. There are many unsolved problems in this area, such as the relation between optical activity and molecular structure; the molecular structure and its chemical, biological functions etc. For example. Some medicine has to be d-isomer to be effective, while its l-isomer is completely medical useless.

## 8 -6-5 Induced Circular Birefringence——Faraday effect

The setup is given in Fig 5-9, Zhao’s, Pg223. Fig 8-63, Hecht’s.

<div style="text-align: center;"><img src="imgs/img_in_image_box_264_762_750_993.jpg" alt="Image" width="40%" /></div>


 $ \psi = \text{VBl} \quad (8-36) $

V: Verdet constant, l is the length of material.

 $ \psi $ is >0 for levorotatory (This is the convention used in crystal).

Note: V>0, means if the light propagate along  $ \bar{B} $, it is left rotatory, if light propagates antiparallel with  $ \bar{B} $, it is dextrorotatory. Such change of handedness with respect to the light propagation direction is characteristic of the Faraday effect.

This means for the reflected beam, its polarization would have angle

of 2 $ \psi $ with respect to the original incoming polarization! This is quite different from natural optical active material, where the rotation of polarization is unaffected by the propagation direction of light, i.e. if light passing from left or right to a L-SiO $ _{2} $( or equivalently rotate crystal 180 degree) the result will be levorotatory. This is because the handedness cannot be changed by rotation; think about your hand, the right hand cannot overlap with left hand just by rotation. The reason for change of handedness of Faraday effect will be discussed below.

Faraday effect is useful in constructing the optical isolator to block the reflected beams:

<div style="text-align: center;"><img src="imgs/img_in_image_box_296_845_883_1107.jpg" alt="Image" width="49%" /></div>


The output of single pass is rotated by  $ 45^{\circ} $. The reflected would be rotated by another 45 and then orthogonal to the linear polarizer and won't pass.

The reason that the change of handedness of the media towards different light propagation can be explained qualitatively by the simple picture:

The effect of  $ \bar{B} $ field is to align the magnetic dipoles of the media along one direction:

<div style="text-align: center;"><img src="imgs/img_in_image_box_312_263_614_577.jpg" alt="Image" width="25%" /></div>


The small magnetic dipoles of media B' can be thought as created by circulating electrons or charges.

The circulating electrons may interact differently with right or left circular light:  $ \longrightarrow $ circular birefringence.

Assume for light travel along  $ \vec{B} $, right circular light interact with magnetic dipole  $ \left(\begin{array}{c} \vec{e} \\ \vec{e} \end{array}\right) $ (clockwise) and have larger  $ n_R > n_L $, so it is levo-rotatory,  $ n_R^1 > n_L^1 $. However for light propagate antiparallel with  $ \vec{B} $, the right circular light in this case, interacts with (viewing against direction of light propagation)  $ \left(\begin{array}{c} \vec{e} \\ \vec{e} \end{array}\right) $ (counterclockwise), this is exactly the interaction between left circular light with the clockwise dipole in the parallel propagation, so for the antiparallel (with respect to  $ \vec{B} $),  $ n_R' = n_L' $,  $ n_L' = n_R^1 $ clearly now the media is dextrorotatory, since  $ n_R' < n_L' $. The media changed handedness for different propagation.

This is the difference between Faraday effect and natural optical active media.

9-1 Absorption of Light—Beer’s Law (Lambert Law)

<div style="text-align: center;"><img src="imgs/img_in_image_box_260_395_777_636.jpg" alt="Image" width="43%" /></div>


I is the irradiance in unit of: power/Area (W/m $ ^{2} $).

The change of irradiance due to absorption is given by:

 $$ \mathrm{\frac{dI}{I}}=-{\alpha}\mathrm{d}l $$ 

 $$ \therefore\quad\ln\frac{I}{I_{0}}=-\alpha l $$ 

 $$ \mathrm{I}=\mathrm{I}_{0}\mathrm{e}^{-\alpha\mathrm{l}} $$ 

(9-1) (Lambert law)

 $ \alpha $ is a number depending on the material and transition; it is called absorption coefficient; l is the length of absorbing media.

In solution,  $ \alpha $ can be written as:

 $$ \alpha=AC $$ 

Then (9-1) becomes

 $$  I=I_{0}e^{-ACl} $$ 

 $$ \begin{array}{r l}{(9-3)}&{{}(\mathrm{B e e r^{\prime}s~l a w})}\end{array} $$ 

A: molar absorption coefficient (L·mol⁻¹·dm⁻¹, (L is liter) or

 $ dm^2 \cdot mol^{-1} $

C: molar concentration (mole/Liter)

l: length (dm)

Sometimes it is also convenient to change.

Cl=mole/volume·length=mole/Area=S ↔—surface concentration S in unit of (mole/dm²)

(9-3) becomes  $ I = I_{0} e^{-AS} $ (9-4)

If the absorption is weak, i.e.  $ \alpha l $ (or  $ ACl\cdots $) is small,  $ e^{-\alpha l} \approx (1 - \alpha l) $.

Then (9-1), (9-3) becomes:

 $$ \Delta\mathrm{I}=-\alpha\mathrm{I I}_{0}=-\mathrm{A C I I}_{0}=-\mathrm{A S I}_{0} $$ 

 $ \Delta I = I - I_{0} $ is the light being absorbed.

So by measuring  $ \Delta I $, we can evaluate A, the absorption coefficient. Note Beer's law is correct for I is small, far away from saturation, to avoid nonlinear optical effect; and also when C is small, to avoid molecular congregation and other inter-molecular interaction.

From quantum mechanics, the atom/molecule absorbs light if there is an energy gap between levels (states) in resonant with light. I.e.

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_1236_638_1501.jpg" alt="Image" width="34%" /></div>


 $$ \Delta\mathrm{E}=\mathrm{E}_{\mathrm{S}_{1}}-\mathrm{E}_{\mathrm{S}_{0}}=\hbar\omega_{12}\qquad(9-6) $$ 

In atomic cases, the energetic states are electronic states (distribution of electrons in atom). For example the Double line of Na around 580 nm are:

<div style="text-align: center;"><img src="imgs/img_in_image_box_226_400_1045_681.jpg" alt="Image" width="68%" /></div>


In molecular cases, the energetic states not only have electronic structures, but also have vibrational, rotational structures due to the motion of nuclei.

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_887_1059_1299.jpg" alt="Image" width="70%" /></div>


\[\mathrm{\Delta E_{elec} \sim \Delta P = \frac{10000000}{100000000000} \times 10

 $$ \Delta E_{vib}\sim\mathrm{o r d e r~o f~}10^{2}-10^{3}\mathrm{c m}^{-1}\mathrm{~\textsuperscript{~}~}\mathrm{I R} $$ 

 $ \Delta E_{\text{rot}} \sim \text{order of a few cm}^{-1} $ —— Microwave

The absorption coefficient  $ \alpha $(or A) corresponds to the transition probability between energetic levels in atom/molecules.

After the atom/molecule absorbs light, there are many ways to dissipate the energy.

<div style="text-align: center;"><img src="imgs/img_in_image_box_223_404_948_695.jpg" alt="Image" width="60%" /></div>


Only part of the absorbed energy are emitted by atom/molecules, give rise to optical radiation, a common form of radiation is fluorescence, and fluorescence quantum yield Q is a measure of the percentage of energy emitted by atom/molecules as fluorescence:

 $$ \mathrm{Q}_{\mathrm{fluor}}=\frac{\#of photon emitted as fluorescence}{\#of photon absorbed} $$ 

In what follows, we shall treat the absorption of light classically. The quantum treatment is left for other courses (quantum mechanics, spectroscopy etc.).

## 9 -2 Complex index of refraction

 $$ \widetilde{\mathrm{E}}=\mathrm{E}_{0}\mathrm{e}^{\mathrm{i}(\mathrm{k}\mathrm{x}-\omega\mathrm{t})}=\mathrm{E}_{0}\mathrm{e}^{\mathrm{i}\omega(\frac{\mathrm{n}\mathrm{x}}{\mathrm{c}}-\mathrm{t})} $$ 

For wave propagates in a media without loss of energy, n is a real number, the amplitude of wave does not change during propagation.

In case of absorption, the process can be treated by introducing an imaginary part in the index of refraction. I.e.

 $$ \mathbf{\widetilde{n}}=\mathbf{n}(1+\mathbf{i}\mathbf{K})\quad(9-6) $$ 

n, k are real numbers.

Then  $ \widetilde{\mathbf{E}}=\mathbf{E}_{0}\mathbf{e}^{-\frac{\mathbf{n}\mathbf{K}\omega}{\mathbf{c}}\mathbf{x}}\mathbf{e}^{-\mathbf{i}(\omega\mathbf{t}-\mathbf{n}\mathbf{x}/\mathbf{c})} $

This is clearly a decaying wave in media, and the K is the decaying coefficient, with

 $$ \mathrm{I}\propto\widetilde{\mathrm{E}}\widetilde{\mathrm{E}}^{*}=\left|\mathrm{E}_{0}^{2}\right|\mathrm{e}^{-\frac{2\mathrm{n}\mathrm{K}\omega}{\mathrm{c}}\mathrm{x}} $$ 

Compare with Lambert or Beer's law

 $$ \longrightarrow\quad a=\frac{2nK\omega}{c}=\frac{4\pi nK}{\lambda} $$ 

If we have means to evaluate  $ \tilde{n} $, the complex index of refraction we shall have expression for both n, K, the dispersion and absorption.

## 9 -3 Classical E-M theory on dispersion and absorption

From E-M theory:

 $$ \begin{array}{c} \widetilde{\mathbf{n}}=\sqrt{\varepsilon} \\ \uparrow \end{array} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_220_1106_837_1427.jpg" alt="Image" width="51%" /></div>


 $$ \mathrm{P}=\chi\varepsilon_{0}\mathrm{E} $$ 

polarizability

So that knowing  $ \chi $, we shall know  $ \tilde{n} $.

For a media consists of N atoms, each atom has Z electrons. We shall treat the media as composed of electric dipoles, each dipole is  $ -\bar{e}\bar{r} $, and there are total of NZ of such dipoles. (This is a simplification) This NZ dipoles, under the external field, will align along the direction of the field, so the total polarizability of the media P would be:

 $$ \mathrm{P}=-\mathrm{NZer}=\Sigma\mathrm{dipoles}\qquad(9-9) $$ 

(If we use the dipole definition given earlier in this note, see Pg. 23 of this note, dipole=q_{e}r, q_{e} is the electron charge -e; same expression as above, just replace -e with q_{e}. The summation of NZ dipole is actually summation of vectors, but since these vectors is along the same direction of the external field, so it reduces to the above expression).

For a dipole under the oscillating external field, the r will also oscillate. The solution for r; the dipole displacement, is just the solution for a forced oscillator (the dipole) driven by the external field (the light field) with damping (limited lifetime with energy dissipation).

Such problem we have already solved earlier in the course (see Note Pg. 25-26).

Basically under the external driving field, the motion of an electric dipole is given by:

<div style="text-align: center;"><img src="imgs/img_in_image_box_221_1342_639_1507.jpg" alt="Image" width="35%" /></div>


The solution of the equation is in form of:

 $$ \mathbf{r}=\frac{\mathbf{e}\mathbf{E}_{0}}{\mathbf{m}}\frac{1}{\omega^{2}-\omega_{0}^{2}+\mathbf{i}\omega\gamma}\mathbf{e}^{-\mathbf{i}\omega t} $$ 

It is the forced oscillation of dipole has same frequency as the external driving field, but with a phase lag, a result we should already be familiar with.

Under condition of resonance, i.e.  $ \omega = \omega_0 $ ( $ \omega_0 = \sqrt{\text{k/m}} $ is the freq. of free dipole), the amplitude of dipole oscillation is the maximum, and the energy will be absorbed more efficiently by the dipoles from the field, this give rise to the phenomenon of absorption of light from classical E-M theory. As  $ \omega \neq \omega_0 $ the absorption would be much weaker.

Putting (9-10) into (9-9), so that:

 $$ \begin{aligned}&\mathrm{P}=-\mathrm{NZer}=-\frac{\mathrm{Nze}^{2}}{\mathrm{m}}\frac{\mathrm{E}}{\omega^{2}-\omega_{0}^{2}+\mathrm{i}\omega\gamma},\quad\widetilde{\mathrm{E}}=\mathrm{E}_{0}\mathrm{e}^{-\mathrm{i}\omega t}\\ &\\&=\chi\varepsilon_{0}\widetilde{\mathrm{E}}\\ &\\&\therefore\chi=\mathrm{P}\bigg/\varepsilon_{0}\widetilde{\mathrm{E}}=-\frac{\mathrm{Nze}^{2}}{\varepsilon_{0}\mathrm{m}}\frac{1}{\omega^{2}-\omega_{0}^{2}+\mathrm{i}\omega\gamma}\\ &\\&\varepsilon=1+\chi=1-\frac{\mathrm{Nze}^{2}}{\varepsilon_{0}\mathrm{m}}\frac{1}{\omega^{2}-\omega_{0}^{2}+\mathrm{i}\omega\gamma}\quad(9-11)\\ &\\&\varepsilon=\widetilde{\mathrm{n}}^{2}=\mathrm{n}^{2}(1+\mathrm{i}\mathrm{K})^{2}\quad(9-12)\\ \end{aligned} $$ 

Compare the two relation of 9-11, 9-12, equal the real and imaginary

part: (neglect  $ l-\mathrm{K}^{2} $ term)

 $$ \begin{cases}\mathrm{n}^{2}=1-\frac{\mathrm{NZe}^{2}}{\varepsilon_{0}\mathrm{m}}\frac{\omega^{2}-\omega_{0}^{2}}{\left(\omega^{2}-\omega_{0}^{2}\right)^{2}+\left(\omega\gamma\right)^{2}}\\2\mathrm{n}^{2}\mathrm{K}=\frac{\mathrm{NZe}^{2}}{\varepsilon_{0}\mathrm{m}}\frac{\omega\gamma}{\left(\omega^{2}-\omega_{0}^{2}\right)^{2}+\left(\omega\gamma\right)^{2}}\end{cases} $$ 

The relation (9-13) shows the change of index of refraction n and K with  $ \omega $. So this gives the relation of dispersion, i.e.  $ \mathrm{n}(\omega) $ and absorption coefficient  $ \mathrm{K}(\omega) $. (recall  $ \mathrm{a} = \frac{2\mathrm{n}\mathrm{K}\omega}{\mathrm{c}} $, the absorption coefficient a).

The result is plotted in Fig 2-6 in Zhao's, Pg. 240.

The above treatment assumes that the dipoles only oscillate with one resonant frequency  $ \omega_{0} $. In real situation, there are multiple resonant frequencies,  $ \omega_{10} $,  $ \omega_{20} $…. The treatment for many dipoles with different resonant freq. would be analogy to the one we give before for single  $ \omega_{0} $, and the results are presented in the Zhao’s book. Pg. 241-242.

With the classical E-M theory, we have been able to explain some aspect of dispersion and absorption of light. The dispersion theoretical calculation agree well with the experimental results, and the result in (9-13) predicts the correct line shape in absorption, and relates the a (absorption coefficient) with atomic/molecular resonance.

However, it is unable to explain why there are only certain values of  $ \omega_{0} $ for a specific atom/molecule. This has to be explained by quantum theory.

## Chapter 10 Quantum property of light

In the following sections, we shall discuss some of the experiments that lead to the birth of quantum theory. Light plays the central role in all these experiments. It is these experiments that reveal the quantum properties of light. This chapter acts as an introduction of the historical background for the development of quantum theory $ ^{12} $, and the formal treatment will be introduced in next chapter.

## 10 -1 Photon——Light Quanta

The concept of photon, or “photo-particle” was introduced due to the failure of classical theory in their treatment of some experimental observations (The term “photon” was coined by Lewis in 1926, but the idea was already exploited by Einstein in his explanation for photo-electric effect).

Below, I shall first list the properties of photon and discuss the detailed story in the following sections.

\[\begin{aligned}&Photon\begin{cases}&Energy\ E=\hbar\omega=h\nu\quad

Angular Momentum  $ L = \hbar $

## 10 -2 Blackbody Radiation

### (Zhao's, Pg. 258-271)

A heated object would emit out light or more generally radiate E-M wave. The radiance (optical energy)  $ r(\nu,r,t) $, that is the energy emitted by a unit area of the surface per unit time at certain frequency  $ \nu $ of the heated object, could be measured. Now let's take a look of classical E-M theory treatment of the radiation.  $ [r(\nu,r,t) $ is called radiation power's spectrum density]

(1) First we need to relate the radiance  $ r(\nu, r, t) $ from an object with the energy term of the light field.

This could be established as follows:

<div style="text-align: center;"><img src="imgs/img_in_image_box_274_947_642_1293.jpg" alt="Image" width="30%" /></div>


The object may irradiate and absorbs energy from the field. By the time of equilibrium at temperature T, then the amount of radiation emitted and absorbed by the object must equal, i.e.

 $$ \mathbf{r}_{\mathrm{T}}(\nu,\mathbf{r},\mathbf{t})=\alpha(\nu)\mathbf{e}_{\mathrm{T}}(\nu,\mathbf{r},\mathbf{t})\quad(10-2) $$ 

where  $ e(v,r,t) $ is the illumination per unit area per unit time around

v of the field on the surface of the object. [or can be called spectrum

density of illumination power]

At the thermal equilibrium, the radiation from the object and the E-M field will be uniform (independent of position r) stationary (independent of time t) and isotropic (independent of direction). So (10-2) reduces to

 $$ \mathbf{r}_{\mathrm{T}}(\nu)=\alpha(\nu)\mathbf{e}_{\mathrm{T}}(\nu)\qquad(10-3) $$ 

where  $ \alpha $ is the absorption coefficient, i.e. only part of the illumination on the surface may be absorbed by the object. The  $ e(\nu) $, the spectrum density illumination on a surface by the field can be expressed in energy terms of the field.

For a E-M field, let $f(\nu,\hat{S},r,t)$ be its energy distribution function. The physical meaning of $f(\nu,\hat{S},r,t)$ is the energy of the field with in a unit volume around $r$, at time $t$, around frequency $\nu$ and along direction of $\hat{S}$. (In unit of energy/volume·Hz·stericangle)

For an uniform, stationary and isotropic, f(\nu,\hat{S},r,t) reduces to f(\nu). The illumination on a surface S will be the  $ \underline{\text{energy flux}} $ (energy flow across the surface S from all directions, half of the steric angle since we do not consider back illumination here) through the surface and can be calculated as:

(energy flux: energy flow across a surface per unit time)

<div style="text-align: center;"><img src="imgs/img_in_image_box_228_233_968_450.jpg" alt="Image" width="62%" /></div>


 $$ \Delta\psi(\nu,\mathrm{r},\mathrm{t})=\iint\limits_{(2\pi)}\mathrm{cf}(\nu,\hat{\mathrm{S}},\mathrm{r},\mathrm{t})\hat{\mathrm{S}}\cdot\Delta\mathrm{S}\mathrm{d}\Omega=\pi\mathrm{cf}(\nu,\mathrm{r},\mathrm{t})\Delta\mathrm{S}\quad(\mathrm{for~isotropic~f}) $$ 

spectrum of energy flux density across surface S

 $$ \begin{aligned}\therefore\quad\mathrm{e}(\nu,\mathrm{r},\mathrm{t})=\pi\mathrm{cf}(\nu,\mathrm{r},\mathrm{t})\\ \uparrow\end{aligned} $$ 

illumination (energy flux per unit area of the surface)

Also because the energy per unit volume of certain v for an isotropic field is given by (Taken an analogy that u is the number of bullets per volume; and f is the number of bullets flying along certain direction per unit time):

 $$ \mathrm{u}(\nu,\mathrm{r},\mathrm{t})=\iint\mathrm{fd}\Omega=4\pi\mathrm{f} $$ 

 $$ \therefore\mathrm{e}(\nu,\mathrm{r},\mathrm{t})=\frac{\mathrm{c}}{4}\mathrm{u}(\nu,\mathrm{r},\mathrm{t}) $$ 

energetic spectrum density of the field

From (10-4), the relation (10-3) would be reduced to

 $$ \frac{\mathbf{r}_{\mathrm{T}}(\nu)}{\alpha(\nu)}=\frac{\mathbf{c}}{4}\mathbf{u}_{\mathrm{T}}(\nu) $$ 

We take the field to be isotropic uniform and stationary.

(10-5) tells us that for any object, no matter what the material are, its spectrum density of radiation power/absorption coefficient is a

value that is a property of the field, independent of the material.

For an object with  $ \alpha(\nu)=1 $ for all  $ \nu $, then

 $$ \mathrm{r}_{\mathrm{T}}(\nu)=\frac{\mathbf{c}}{4}\mathrm{u}_{\mathrm{T}}(\nu) $$ 

 $$ (10-6) $$ 

Such object is called blackbody, since  $ \alpha(\nu)=1 $ means it absorbs all the light illuminated on it. For the radiation of a blackbody,  $ r_{\mathrm{T}}(\nu) $ which can be experimentally determined, it can also be theoretical evaluated from  $ u_{\mathrm{T}}(\nu) $, the field’s spectrum density of energy density. We shall see that the classical E-M theory’s evaluation of  $ u_{\mathrm{T}}(\nu) $ differs from the experimental observation of  $ r_{\mathrm{T}}(\nu) $.

(2) Let's first take a look of the experimental measurement of  $ \mathrm{r}_{\mathrm{T}}(\nu) $ a blackbody.

The experimental setup and results are shown as (Zhao's fig. 1.6):

<div style="text-align: center;"><img src="imgs/img_in_image_box_267_963_1007_1151.jpg" alt="Image" width="62%" /></div>


An ideal blackbody can be approximated by a cavity with a small opening.

(3)Empirical Formula for blackbody radiation (based on experimental measurement of radiation):

(a) Stefan-Boltzmann:

 $$ \mathrm{R}_{\mathrm{T}}=\int\mathrm{r}_{\mathrm{T}}(\nu)\mathrm{d}\nu=\sigma\mathrm{T}^{4}\stackrel{\uparrow}{\mathrm{const.}} $$ 

(b)Wien’s Displacement law:  $ \lambda_{\mathrm{m}} \mathrm{T} = \mathrm{b} \quad (10-7) $

 $$ \sigma=5.67033\times10^{-8}W/m^{2}\cdot K^{4},\quad b=0.288cm\cdot K $$ 

(4)Classical Theory: Electro-Magnetic Theory + Statistical Theory

——Rayleigh-Jeans equation

We need to evaluate the  $ u_{T}(\nu) $, the spectrum density of energy density of the field in cavity that approximates the black body:

Consider a cubic cell with length of l.

The waves inside the cubic cavity have forms of (or as linear combinations):

 $$ \mathbf{e}^{\mathbf{i}(\mathbf{k}\mathbf{r}-\omega\mathbf{t})}=\mathbf{e}^{\mathbf{i}(\mathbf{k}_{x}\mathbf{x}+\mathbf{k}_{y}\mathbf{y}+\mathbf{k}_{z}\mathbf{z})}\mathbf{e}^{-\mathbf{i}\omega\mathbf{t}}\qquad(\mathrm{n e g l e c t~t h e~a m p l i t u d e}) $$ 

The enclosed cavity put limit on the possible values of  $ k_{i} $, this is introduced by either solving wave equation  $ \nabla^{2}E=\frac{1}{c^{2}}\frac{\partial^{2}E}{\partial t^{2}} $ in the cavity and the restriction is a direct result of boundary condition. Or it can be viewed more intuitively by the standing wave picture, i.e. the stationary waves inside the cavity have to be a standing wave that satisfies the relation:

 $ kl = m\pi \quad (m=1,2,3\cdots) $ in one-dimension

This can be easily understood from interference point of view. The above relation is simply:

 $$ 2l=m\lambda $$ 

Under this condition, the initial and reflected waves inside the cavity

can interfere constructively. Otherwise would result in destructive interference.

<div style="text-align: center;"><img src="imgs/img_in_image_box_215_333_431_511.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_488_336_709_515.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_763_325_965_509.jpg" alt="Image" width="16%" /></div>


So in three dimension cubic cavity with  $ l_{x}=l_{y}=l_{z}=1 $ we have:

 $$ \mathbf{k}_{\mathrm{x}}\mathbf{l}=\mathbf{m}_{\mathrm{x}}\pi,\mathbf{k}_{\mathrm{y}}\mathbf{l}=\mathbf{m}_{\mathrm{y}}\pi,\mathbf{k}_{\mathrm{z}}\mathbf{l}=\mathbf{m}_{\mathrm{z}}\pi $$ 

For each set of possible  $ (m_{x}, m_{y}, m_{z}) $ is called a mode of the cavity.

 $$ \mathrm{k}^{2}=\left(\frac{2\pi}{\lambda}\right)^{2}=\frac{\omega^{2}}{\mathrm{c}^{2}}=\pi^{2}\frac{\left(\mathrm{m}_{\mathrm{x}}^{2}+\mathrm{m}_{\mathrm{y}}^{2}+\mathrm{m}_{\mathrm{z}}^{2}\right)}{1^{2}} $$ 

It is easy to see that as  $ \omega $ increases, there are more possible sets of  $ (m_{x}, m_{y}, m_{z}) $ that will satisfy (10-8), or there are more modes corresponding to  $ \omega $ (or  $ \lambda $) rearrange (10-9) to:

 $$ \frac{4\pi^{2}\nu^{2}\mathrm{l}^{2}}{\mathrm{c}^{2}}=(\mathrm{m}_{\mathrm{x}}^{2}+\mathrm{m}_{\mathrm{y}}^{2}+\mathrm{m}_{\mathrm{z}}^{2})\pi^{2} $$ 

It is a spherical surface with radius of  $ \frac{2\nu}{c} $ in a space spanned by

<div style="text-align: center;"><img src="imgs/img_in_image_box_178_1181_743_1590.jpg" alt="Image" width="47%" /></div>


Each mode  $ (m_x, m_y, m_z) $ corresponds to a point here (such as those represented at the vertices of cubic cells), at large  $ l (\gg \lambda) $, the modes in the x-y, y-z, x-z planes and along x, y, z axis can be neglected. The total numbers of possible modes corresponds to  $ \leq \nu $ then would be the volume of this octant of a sphere with radius  $ \left(\frac{2\nu}{c}\right) $:

 $$ \mathrm{N}(\nu)=2\times\frac{4}{3}\pi\bigg(\frac{2\nu}{\mathrm{c}}\bigg)^{3}/8=\frac{8\pi}{3\mathrm{c}^{3}}\nu^{3}\mathrm{l}^{3} $$ 

This 2 is introduced due to two possible polarization

 $ N(\nu) $ is the total number of modes of the E-field that are  $ \leq\nu $.

 $$ \therefore\text{Number of mode/Volume=n(v)=\frac{8\pi}{3c^{3}}v^{3}} $$ 

 $$ \mathrm{d n}(\nu)=\frac{8\pi}{\mathrm{c}^{3}}\nu^{2}\mathrm{d}\nu $$ 

 $$ \therefore\mathrm{~s~c~t~e~r~u~m~d~e~n~s~i~t~y~o~f~m~o~d~e~s:~}\mathrm{~g~}(\nu)=\frac{d n(\nu)}{d\nu}=\frac{8\pi}{\mathrm{~c~}^{3}}\nu^{2} $$ 

This is the possible modes within small frequency interval around  $ \upsilon $ (the number of points within spheric thin shell in the figure). Then the energy spectrum density inside a cubic cavity (Actually inside any cavity) would be:

 $$ \mathrm{u}_{\mathrm{T}}(\nu)=\mathrm{g}(\nu)\overline{\varepsilon}(\nu,\mathrm{T})=\frac{8\pi\nu^{2}}{\mathrm{c}^{3}}\overline{\varepsilon}(\nu,\mathrm{T}) $$ 

where  $ \bar{\varepsilon}(\nu,T) $ is the average energy of the mode at freq.  $ \nu $. From statistics:

 $$ \bar{\varepsilon}(\nu,\mathrm{T})=\int\varepsilon\mathrm{P}(\varepsilon)\mathrm{d}\varepsilon=\frac{\int_{0}^{\infty}\varepsilon\mathrm{e}^{-\varepsilon/\mathrm{kT}}\mathrm{d}\varepsilon}{\int_{0}^{\infty}\mathrm{e}^{-\varepsilon/\mathrm{kT}}\mathrm{d}\varepsilon}=\mathrm{kT} $$ 

Classical equal-partition of energy

From classical point of view, an oscillator with frequencyν, its energy value(ε) can be taken continuously from0—∞, and then:

 $$ \mathrm{u_{T}(\nu)=\frac{8\pi\nu^{2}}{\mathrm{c}^{3}}\mathrm{kT}} $$ 

Rayleigh-Jeans relation

It is absurd in a sense that at high  $ \nu $ region, the spectrum density goes to infinity, and so will be the radiation too, this is of course contradict the experimental result of  $ r_{T}(v) $ and it is called UV-catastrophe.

A brief recount of what I showed above (in case the complicated derivation confused you):

 $$ \mathrm{r}_{\mathrm{T}}(\nu)=\frac{\mathrm{c}}{4}\mathrm{u}_{\mathrm{T}}(\nu) $$ 

where  $ \mathbf{r}_{\mathrm{T}}(\nu) $ is the radiation energy emitted by a unit area surface per unit time at freq.  $ \nu $.

u_{T}(v) is the energy of the E-M field per unit volume, at freq. v.

r_{T}(v) is experimentally measurable, and in accordance with empirically

determined Stefan-Boltzmann and Wien's Displacement relations.

 $ u_T(v) $ can be calculated from E-M field theory. I have shown that for a cubic cavity, the cavity modes (\# of possible E-M waves) per unit volume, at freq.  $ v $ is given by:

(spectrum density of modes)  $ \mathrm{g}(v)=\frac{8\pi}{\mathrm{c}^{3}}v^{2} $

 $$ \begin{array}{r l r}{S o}&{{}\mathrm{u}_{\mathrm{T}}(\nu)=\mathrm{g}(\nu)\bar{\varepsilon}_{\mathrm{T}}}&{{}(10-12)}\end{array} $$ 

 $ \bar{\varepsilon}_{\mathrm{T}} $ is the average energy per mode.

For a classical wave, the energy  $ \varepsilon $ is proportional to the  $ |\mathrm{E}_0|^2 $, where  $ |\mathrm{E}_0| $, is the amplitude, and could range from  $ 0-\infty $. At certain T, the probability distribution obeys Boltzmann distribution.

 $$ \mathrm{P}(\varepsilon)=\mathrm{e}^{-\varepsilon/\mathrm{kT}} $$ 

The probability of a mode with energy  $ \varepsilon $.

 $$ \begin{array}{r l r}{T h e n}&{{}\overline{{\varepsilon}}_{\mathrm{T}}=\frac{\displaystyle\int_{0}^{\infty}\varepsilon\mathbf{e}^{-\varepsilon/\mathrm{k T}}}{\displaystyle\int_{0}^{\infty}\mathbf{e}^{-\varepsilon/\mathrm{k T}}}=\mathrm{k T}}&{{}\quad(10-13)}\end{array} $$ 

 $$ \mathrm{S O}\quad\mathrm{u_{T}}(\nu)=\mathrm{g}(\nu)\overline{{\varepsilon}}_{\mathrm{T}}=\frac{8\pi}{\mathrm{c}^{3}}\nu^{2}\mathrm{k T}\qquad(10-14) $$ 

 $$ \mathrm{r_{T}}(\nu)=\frac{2\pi}{\mathrm{c}^{2}}\nu^{2}\mathrm{kT}\quad(10-15) $$ 

(10-15) is the result from classical E-M theory, and is called Rayleigh-Jeans law. Compare with experimental black-body radiation, it clearly violates the experimental observation at large  $ \nu $ (small  $ \lambda $) region.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_227_1238_640_1511.jpg" alt="Image" width="34%" /></div>


In fact it predicts, the radiation will go to infinity at large  $ \nu $ (small  $ \lambda $) which is clearly absurd. This is called Ultraviolet Disaster. Something is wrong with the classical E-M theory.

(5) Planck’s Quantization of the field.

Due to the failure of classical theory in explaining the black body radiation, Max Planck made his famous revolutionary hypothesis at the beginning of 20 $ ^{th} $ century. (Though at the time, he did not realize how revolutionary it would become). The hypothesis is that the energy of an oscillator at freq.  $ \nu $ cannot be taken continuously from 0 —  $ \infty $, but has to be integers of  $ \hbar\nu $, where  $ \hbar $ is a constant named after Planck later, i.e.

 $$ \varepsilon=\mathrm{m h}\nu,\mathrm{m}=0,1,2\cdots $$ 

With his modification, (10-13) becomes:

 $$ \overline{\varepsilon}_{\mathrm{T}}(\nu)=\frac{\sum_{\mathrm{m}}\mathrm{m h}\nu\mathrm{e}^{-\mathrm{m h}\nu/\mathrm{k T}}}{\sum_{\mathrm{m}}\mathrm{e}^{-\mathrm{m h}\nu/\mathrm{k T}}}=\frac{\mathrm{h}\nu}{\mathrm{e}^{\mathrm{h}\nu/\mathrm{k T}}-1} $$ 

 $$ \mathrm{u}_{\mathrm{T}}(\nu)=\frac{8\pi\nu^{3}\mathrm{h}}{\mathrm{c}^{3}}\frac{1}{\mathrm{e}^{\mathrm{h}\nu/\mathrm{kT}}-1} $$ 

The proof of (10-16) can be worked out as:

 $$ \begin{array}{l}{\frac{\displaystyle\sum_{m=0}^{\infty}m h v e^{-m h\nu\beta/_{k T}}}{\displaystyle\sum_{m=0}^{\infty}e^{-m h\nu\beta/_{k T}}}=\frac{\beta=1/_{k T}\displaystyle\sum_{m=0}^{\infty}m h v e^{-m h\nu\beta}}{\displaystyle\sum_{m=0}^{\infty}e^{-m h\nu\beta}}=\frac{d}{d\beta}[\ln(\displaystyle\sum_{m=0}^{\infty}e^{-m h\nu\beta})]}\\ {\displaystyle\sum_{m=0}^{\infty}e^{-m h\nu\beta}=1-e^{-h\nu\beta}}\end{array} $$ 

At smallν, (10-17) reduces to (10-14) Rayleigh-Jeans law; and at high ν, (10-17) reduces to Wien’s law and gives the displacement law. Both

Empirical relations of Stefan-Boltzmann and Wien’s displacement can be derived from (10-17) and the Planck constant h, can be evaluated by comparing Stefan-Boltzmann constant  $ \sigma $ and Wien’s constant b, in (10-6), (10-7).

hν, the unit of energy for oscillators at freq. ν, is called the quantum of energy, or quanta.

Since the oscillator with freq.  $ \nu $, cannot have a continuous energy distribution as in classical mechanics, but has to take discrete values of integers of  $ \hbar\nu!! $, this is not anything analogy in classical theory.

Since h is an extremely small value,  $ h = 6.63 \times 10^{-34} \, \text{J} \cdot \text{s} $, so for small  $ \nu $, the quanta  $ \hbar \nu $ is a very small number and can be treated as continuous variable. However, in optical freq. region,  $ (\nu \sim 10^{14} - 10^{15} \, \text{Hz}) $, the discreteness in energy is more significant.

## 10 -3 Photon-Electric effect

The setup and observations are summarized in Zhao’s book, (fig 2-2, Pg. 277). The observations cannot be explained by the classical theory.

<div style="text-align: center;"><img src="imgs/img_in_image_box_198_162_555_599.jpg" alt="Image" width="30%" /></div>


Observations

(1) Threshold freq.  $ \nu_{0}, \nu > \nu_{0} $

there will be photo current

(2) Stop voltage $V_{0}$, $V_{0}$ is dependent of $\nu$, larger $V_{0}$ ($V_{0}$ is a measure of electron's kinetic energy $\frac{1}{2}mv_{e}^{2}$) The above 2 results only depend on $\nu$ of light, but not I, the intensity.

(3) At  $ \nu > \nu_{0} $, the photo-electron current is proportional to I.

Einstein’s explanation by concept of photon.



(4) The generation of photo-electron is instantaneous. The interaction between photon and electron is fast clearly  $ A = h\nu_{0} $



<div style="text-align: center;"><img src="imgs/img_in_image_box_568_778_969_1041.jpg" alt="Image" width="33%" /></div>


the threshold frequency

 $$ \mathrm{h}(\nu-\nu_{0})=\frac{1}{2}\mathrm{m_{e}v_{e}^{2}}=\mathrm{eV_{0}} $$ 

The above explanation is assuming that each electron interacts with a

single photon, which is reasonable since the probability of an electron interacts with multi-photon is extremely small.

## 10 -4 Compton Effect and Momentum of Photon

## (a) Momentum of photon

Previously we give the relation of photo-pressure created by illuminating an absorbing surface (normal incidence):

 $$ \mathrm{P}=\frac{\mathrm{I}}{\mathrm{c}}\qquad(10-19)\quad(\mathrm{see~Pg.~20~of~this~note}) $$ 

(pressure)

 $$ =\frac{\mathrm{Nh}\nu}{\mathrm{c}}=\mathrm{N}\left(\frac{\mathrm{h}\nu}{\mathrm{c}}\right) $$ 

N: is the photon flux, i.e. # of photon pass through a unit area, per unit time.

For the absorbing surface, the pressure is due to the change of momentum of the photon,  $ \Delta p = p $ for absorbing surface, p is momentum of individual photon. P=Np, compare with above, clearly:

 $$ \mathrm{p}=\frac{\mathrm{h}\nu}{\mathrm{c}}=\frac{\mathrm{h}}{\lambda}\qquad(10-21) $$ 

The result is in accordance with that derived from relativity:

 $$ \mathrm{P=E/c=\frac{h\nu}{c}=\frac{h}{\lambda}\quad same\ result.} $$ 

(b) Compton effect

An experimental proof that photon behaves as particle and possess momentum given by (10-21).

The experiment setup is depicted in Fig 2-5, Pg. 282, Zhao's, as well as the results (Fig 2-6, 2-7).

The observed change of wavelength of scattered light can be relatively simply explained in the framework that treating light as a photon, by using conservation of energy and momentum:

 $$ \left\{\begin{aligned}\mathbf{h}\boldsymbol{v}_{0}&=\mathbf{h}\boldsymbol{v}+\frac{1}{2}\mathbf{m}_{\mathrm{e}}\mathbf{v}^{2}\\ \vec{\mathbf{p}}_{0}&=\vec{\mathbf{p}}+\mathbf{m}_{\mathrm{e}}\vec{\mathbf{v}}\end{aligned}\right. $$ 

(Of course if you took my special relativity course, I used special relativity formula to derive the same results below)

<div style="text-align: center;"><img src="imgs/img_in_image_box_299_870_763_1149.jpg" alt="Image" width="38%" /></div>


Then, it is not hard to derive the  $ \nu $ (or  $ \lambda $) and  $ \Delta\nu $ (or  $ \Delta\lambda $), the frequency change of scattered light:

 $$ \Delta\lambda=\lambda-\lambda_{0}=\frac{2\mathrm{h}}{\mathrm{m_{e}c}}\sin^{2}\theta/2=2\lambda_{\mathrm{c}}\sin^{2}\theta/2 $$ 

$\lambda_{\mathrm{c}}$ is the Compton wave length $=\frac{\mathrm{h}}{\mathrm{m}_{\mathrm{c}}} = 0.0241^{\mathrm{A}}$. The Compton

effect only shifts the wavelength of scattered light by a very small

amount, for light in the visible or UV region ( $ \lambda_0 \sim 1000 - 10000 \AA $),

such shift is negligible; it becomes significant for X-ray, the light with

small  $ \lambda_0 $.

## 10 -5 Angular Momentum of Photon (Spin)

If we illuminate an absorbing surface with circular polarized light, we will create a Torque on the surface. Classical theory that the torque per unit area is:

 $$ \mathrm{T}=\frac{\mathrm{I}}{\omega} $$ 

I: irradiance of light (Energy absorbed by the absorbing surface per unit area per unit time)

ω : angular freq. of light.

The detailed treatment is similar to the photo-pressure on the absorbing surface and is omitted here.

In view from picture of photons, this indicates

 $$ \mathrm{T}=\frac{\mathrm{N}\hbar\omega}{\omega}=\mathrm{N}\hbar $$ 

 $$ (10-25) $$ 

The torque is created by the change of angular momentum of photons, since the photons are absorbed by the surface,  $ \Delta L = L $, L is the angular momentum of photon.

Compare with (10-25)  $ \rightarrow $ L =  $ \hbar $ (10-26)

The angular momentum of photon is also named “spin” of photon. We shall see that not only photon, but also other particles such as electron and nuclei that there is spin associating with them.

The left-circular polarized light has spin of  $ \hbar $, which is parallel with  $ \vec{k} $, the wave vector,

The right-circular polarized light has spin of  $ -\hbar $, which is anti-parallel with  $ \vec{k} $.

Other polarized states can be treated as mixture of these two.

## 10 -5 de Broglie's Matter wave

(This part and below will be discussed in detail in quantum part of the course, see chapter 11)

Relations (10-21) and (10-26) are peculiar from classical point of view. (10-21) relates momentum p, a parameter associated with particle with wavelength  $ \lambda $, a parameter associated with wave. (Here, wave, particles are all termed in the classical framework). (10-26) is no less stranger, it relates the angular momentum with photon and polarization of light. How can a particle have polarization? Even the fact that photon possesses angular momentum is puzzling, for a classical hard body (mass point), it does not possess angular momentum. Even if you propose that a photon is a classical particle with mass distribution over finite space, and

the particle is rotating. (Such picture is wrong!) It is still hard to explain why its angular momentum is always  $ \hbar $, not continuous for different rotating speed. Leave along why such rotation relates to polarization.
So, the photon, or “photo-particle” is clearly not a classical particle as we are familiar with from our daily life experience. It is also not a classical wave.
(Here a classical particle, its properties, such as energy, location etc. by classical mechanics; A classical wave, its properties are delocalized all over the space and time, and its evolution is governed by classical E-M theory)
For photon, it is something that does not exist in the classical framework. It contains characteristics of both classical particle and waves. This is termed as Wave-Particle Duality. Under certain circumstances we only observe its wave character, while under others we observe its particle character. (it is not that light is sometimes wave, sometimes particle)
Such wave-particle duality is not only limited to light (or photon), it is common for all physical existence, the relation (10-21) for photon was generalized by de Broglie in 1923, and he proposed that for all matters,  $ p = h / \lambda $ holds. de Broglie wave or matter wave is attributed to matters which are treated classically as particles, such as electron and atom.

De Broglie wave was experimentally confirmed by Davidson and

Germer in 1927 by electron diffraction (Diffraction is phenomenon related to classical wave, and electron is classically being treated as particle).

De Broglie wave is also supported by the single electron (photon) Young's experiment. This single electron or single photon experiment raises some acute questions and also reveal the nature of matter wave.

<div style="text-align: center;"><img src="imgs/img_in_image_box_318_527_776_837.jpg" alt="Image" width="38%" /></div>


When both  $ S_{1} $,  $ S_{2} $ are open the interference (Diffraction) pattern on screen  $ I \neq I_{1} + I_{2} $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_1115_680_1346.jpg" alt="Image" width="36%" /></div>


What happens if the photon or electron flow is extremely weak, average speaking, only one photon or electron passes through the double

slit device every time. Then after long time, accumulates many such singe photon or electron events, what is the diffraction pattern? Strikingly it is not  $ I_{1} + I_{2} $, it is I, still shows the interference pattern.

<div style="text-align: center;"><img src="imgs/img_in_image_box_292_452_792_783.jpg" alt="Image" width="42%" /></div>


Even if you let photon or electron to arrive at the double slits one at a time, you still observe the interference pattern (The distribution of photon) as in traditional Young's experiment, if you wait to accumulate large number of photons or electrons over some period of time.

For each single electron or photon, it is recorded on the detection screen as a dot (not a wave pattern), the large number of such “dots” shows a distribution of interference pattern.

This is completely in contradiction to the classical view of particle or wave. If it is a classical particle, it will pass one of the slits without knowing the other slit, and there should be no interference, the intensity distribution on screen would be simply  $ I_{1} + I_{2} $ ( $ I_{1} $,  $ I_{2} $ are intensity

distribution with either  $ S_{1} $ or  $ S_{2} $ open). If each photon or electron is a classical wave, how can it only be recorded as a localized dot rather than some delocalized form by the detector?! So the matter wave is neither a classical particle nor wave.

This puzzle can be explained by introducing the quantum mechanical “wave” function  $ \psi $:

For each single photon or electron, it can be described by a “wave” function  $ \psi $. (“wave” in quotation work means it is different from that in classical sense). It is the interference of this “wave” function  $ \psi $ by the two slits which generates the interference pattern. I.e. the interference is generated by single electron or photon, not between different electrons or photons!!

The physical meaning of this “wave” function is different from a classical wave.  $ \psi $ represents a probability wave at Born pointed out.  $ \psi\psi^* $ or  $ |\psi|^2 $ is the probability (or more rigorously, the probability density). For a wave function given by  $ \psi(\mathbf{r},t) $,  $ |\psi(\mathbf{r},t)|^2 $ dV is the probability of finding the “particle” at time t, within spatial volume dV.

In the double slit experiment, let  $ \psi_1 $,  $ \psi_2 $ be the “wave” functions for the photon pass through slit  $ S_1 $,  $ S_2 $, and reach at a point on screen, since we do not know which slit photon may pass, it has equal probability to pass  $ S_1 $ or  $ S_2 $, so the final “wave” function  $ \psi = \psi_1 + \psi_2 $, and  $ |\psi|^2 = |\psi_1 + \psi_2|^2 $ which will contain the  $ \psi_1\psi_2^* $,  $ \psi_1\psi_2 $ cross terms and give

rise to interference.

A single such “particle” certainly does not reveal  $ |\psi|^{2} $, the probability distribution, since when you detect it, you always record the “particle” as whole. (It is in this sense, it becomes as a particle). However, a large number of such “particles” with same  $ \psi $ would reveal the probability distribution! That’s why interference pattern shows up after many recordings.

In summary:

a) Electrons or photons are not classical particles or waves.

b) The interference is not due to the interaction among different particles, but by the wave function  $ \psi $ of the single particle itself.

c) The physical meaning of  $ \psi(\mathrm{r}, \mathrm{t}) $ is different from classical wave, which is energy delocalized over space and time,  $ \psi $ here is a probability wave!  $ |\psi(\mathrm{r}, \mathrm{t})|^2 \mathrm{d}V $ is the probability of finding the particle in  $ \mathrm{d}V $ around  $ \mathrm{r} $ at time  $ \mathrm{t} $.

d) As you will learn in quantum mechanics, the evolution of  $ \psi $ is governed by Schrödinger Equation.

The reason that for macroscopic particle behaves like a classical particle, and lacks any wave character, such as interference, can be understood from de Broglie relation  $ p = h / \lambda $.

For a 1 gram (1g) particle, moving at 1cm/s, it is de Broglie wavelength  $ \lambda \div 10^{-26} $ cm, which is much smaller than dimension used in

<div style="text-align: center;"><img src="imgs/img_in_image_box_433_1566_508_1637.jpg" alt="Image" width="6%" /></div>


experiments and resolution of any existing instrument. This is why it lacks wave-like behavior such as diffraction, which requires the obstacle on the order of $\lambda$; and interference. (Recall in Young’s double slit expt. $\Delta x\Delta\theta=\lambda$, $\Delta x$ is the spacing of interference maxima or minima on screen; $\Delta\theta=\frac{a}{d}$ , angle spanned by slits. $\therefore \Delta x$ would be on the order of $\lambda$, and is extremely small in this example. Any practical measurement would only produce an average of the intensity distribution over space, and the interference would smear out.

In summary of what have been discussed and refer to the quantum properties of light as we listed earlier (P 321 of this note)

Black body Radiation →Quantization of Energy

Photo-Electric effect  $ \rightarrow $ Photon, light behaves as particle with quantized energy

Compton Effect ——→Momentum of photos

Photo Torque  $ \longrightarrow $ Angular momentum of photon

Electron diffraction de Broglie matter wave. Wave-particle duality.

And interference  $ \longrightarrow $ The system is described by a probability wave  $ \psi $

## 10 -6 Uncertainty Principle

This sets the ultimate accuracy that we can determine for a physical

observable. The principle itself, however, is a direct result from Fourier Transform.

As we have elaborated previous in discussing properties of Fourier Transform, we proved that for the two variables related by Fourier Transform, we have:

 $$ \mathrm{g}(\mathrm{u})=\mathrm{\quad ~}[\mathrm{h}(\mathrm{v})] $$ 

Then  $ \Delta u\Delta v \approx 1 $

For a wave function in forms of  $ e^{-i(\omega t - kx)} $, this means

 $$ \Delta\omega\Delta t\approx1\qquad\mathrm{a n d}\qquad\Delta k\Delta x\approx1 $$ 

 $$ \Delta\mathrm{E}\Delta\mathrm{t}\approx\hbar $$ 

 $$ \Delta\mathrm{p}\Delta\mathrm{x}\approx\hbar\qquad\begin{pmatrix}\mathrm{E}=\hbar\omega\\ \mathrm{p}=\hbar\mathrm{k}\end{pmatrix} $$ 

A more strict derivation from quantum mechanics will give the Heisenberg Uncertainty relation: $\Delta p\Delta x \geq \frac{\hbar}{2}$, but since we care for the order of magnitude most of time, the difference is not important.

This limit is set by the nature and not by our abilities of detection. Trivial as it may appear (we have known it for a long time in optics), its physical implication is far more profound. It basically overthrow in concept of trajectory in classical mechanics.

Introduction to Quantum Mechanics

## Chapter 11 Introduction to Quantum Mechanics $ ^{13} $

In the previous chapter, we have discussed quantum properties of light.

The experimental results discussed in the last chapter (Blackbody radiation; Photoelectric effect; Compton’s effect etc.), showed that the classical treatment of light as E-M wave (which we had spent much of this course to discuss) is at least incomplete if not totally wrong (It is not totally wrong; It just does not work in all situations, so incomplete is the correct word). $ ^{14} $ The classical E-M theory works fine when we deal with statistical behaviors of many photons; but failed to explain the experimental results where the behavior of individual photon is important. We have to resort to the idea cultured by Einstein and coinage by Lewis, the concept of “photon”---a strange ‘particle’ which also contains property of wave, a particle-wave duality. (Even the photon is particle alike, it certainly cannot be explained in the frame work of classical mechanics dealing with classical particles, e.g.  $ E = h\nu $;  $ p = h/\lambda = \hbar k $;  $ L_z = \hbar $) So now the question is: Is this particle-wave duality only holds for light? The common logical thinking would be: probably not! Other classical waves may demonstrate particle-like behavior (such as sound wave

consists of ‘phonon’) and vice-versa. That is to say the classical particles may demonstrate wave-like behavior.

This is what I am going to discuss in detail in the following sessions first, and new concept of physics shall be introduced. Then a formal statement of quantum postulates shall be presented; followed by examples to illustrate these fundamental postulates. The detailed calculation especially those involved solving Schrodinger's equation is not the focus for this introductory course, which will be left for the course on quantum mechanics (Q.M) $ ^{15} $

## 11 -1 Young's Double Slits Experiment Revisited

I shall present a thorough discussion on these experimental results with the focus to show that all the explanations based on the classical theory (both wave and particle) fail to provide a satisfactory result.

New concept---particle-wave duality has to be accepted as a general rule not limited to light only; and new relation-Uncertainty Relation, though bizarre at first look has to be accepted; and the description of this new phenomena requires new physical interpretation of the wave function (Max Born’s probability amplitude and probability wave) and new

mechanics which we call quantum mechanics.

1) First take a look at the experiment with macroscopic object (which we know that the classical mechanics describe it very well)

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_362_757_649.jpg" alt="Image" width="41%" /></div>


Feynman fig. 1-1, experiment with bullets passing double slits (holes, windows, you name it), the bullets pass the holes and reach the target screen. We can count the number of bullets that hit within a certain range around a place and the probability distribution can be derived from this count.

<div style="text-align: center;"><img src="imgs/img_in_image_box_264_1005_784_1201.jpg" alt="Image" width="43%" /></div>


The probability of a bullet hitting around X1 is P(x₁)dx, where P(x₁)=n₁/N (N is the total number of bullets that are fired). With a single hole, say only hole1 is open, let’s say the probability distribution in this case is P(x)=P₁; same goes to the hole2 and P₂. Now with both holes open, what would you expect the probability

distribution? Should it be  $ P=P_{1}+P_{2} $? Indeed this is what you observed when both holes open for bullets,  $ P_{12}=P_{1}+P_{2} $, just the summation of probabilities of single holes.

This is not surprising in the sense of classical mechanics. The motion of the bullet through whole 1 (or 2) would be same no matter the other hole is open or closed. The effect of the other hole on the bullet is null (i.e. the force exerted by the other hole on the bullet can be safely neglected). If we do not consider the interaction between the bullets (such as collision between them before and after the holes, which we can always manage the experiment in a way that such collision is negligible, like firing bullets one at a time and repeat it many times, N times, N is large, this would give same results as firing many bullets at same time), then the results of both holes open  $ P_{12} $ would be just  $ P_{1} + P_{2} $. Second experiment is with classical waves

<div style="text-align: center;"><img src="imgs/img_in_image_box_269_1035_438_1281.jpg" alt="Image" width="14%" /></div>


<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_428_1038_557_1280.jpg" alt="Image" width="10%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_569_1034_640_1302.jpg" alt="Image" width="5%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_654_1034_769_1287.jpg" alt="Image" width="9%" /></div>


<div style="text-align: center;">(c)</div>


<div style="text-align: center;">Feynman fig.1-2</div>


We are quite familiar with this result by now. This is the classical Young’s experiment with waves, will show double slits diffraction pattern we already discussed in optics.  $ P_{12} \neq P_{1} + P_{2} $, there will be up

and downs in the pattern which we call interference fringe. This interference phenomenon is used in the classical theory to distinguish between wave and particle.

3) Third experiment with electrons (a microscopic object treated as particle in classical theory)

The results is shown in fig. 1-3(Feynman)

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_530_735_789.jpg" alt="Image" width="42%" /></div>


<div style="text-align: center;">(a)</div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;">(c)</div>


The observed distribution of electrons distribution shows interference fringe, though each individual electron hitting the target as a particle $ ^{16} $ (each electron hitting the screen only generate a sparkle at a localized place). The surprise (or peculiarity) of the observation is summarized in the last sentence, but allow me to fully illustrate it below:

a) The probability distribution clearly shows an interference feature like a classical wave, though in classical theory, the electron is treated as a particle. (point charge with certain mass  $ \sim10^{-30} $ kg;

radius  $ <10^{-15} $ m)

b) The electron indeed shows particle behavior whenever it is detected, it only gives a particle-like signal, and i.e. the energy is localized as shown by the small dots on the detection screen.

So both particle and wave characters are displayed by the electron, and how we explain this within the framework of classical theory (either by wave or particle theory)? It turns out none is capable to give a satisfactory explanation! I shall try to convince you this in the following, Using classical theory to explain double slits experiment:

a) Single electron is particle, large number of them behave as wave.

This is a sound argument and partially true that the behavior of large number of particles do follow classical wave theory (this is the basis that we treat the collective behavior of many photons---light in E-M theory).

However, this description meets difficulty in the SINGLE ‘particle’ case. Remember that we can do the experiment one electron at a time, just like the bullet case. If the electron is indeed a classical particle like a bullet, supported by the localized energy recorded on the detector, then following the same argument as bullet’s experiment, for electrons  $ P_{12}=P_{1}+P_{2} $.

You may argue by proposing that maybe electron can split into two ‘half electron’ and each half may pass different slit. The rebuttal for

this idea is that electron is a fundamental particle, the reason that it is called fundamental is not just nomenclature, but based on the experimental observation, that never a half-charge particle be detected. Indeed if we place two electron detectors (D1 and D2) behind each holes respectively, carry out the experiment with single electrons. Every time, either D1 or D2 record a signal but never both.

Basically this shows that the experimental results contradict the assumption that single electron behaves as a classical particle.

## b) Electron as a superposition of classical wave

Treating the electron as a wave packet we discussed in the optics resulting from superposition of waves with different frequencies or wavelengths. This explanation also meets difficulty. For adding waves together, we know there are a relation the width (localization) of the wave packet  $ \Delta x $, and the distribution width of wavelength  $ \Delta k $, i.e.  $ \Delta x\Delta k \cong 2\pi $

For an electron as small as  $ 10^{-15} $ m, this means  $ \Delta k $ has to be huge. It contains wide range of wavelengths of such classical waves. This wide distribution in wavelength would inevitably give rise to dispersion.

As discussed in the Young's experiment of light (temporal coherence), we know that different frequency components would

form different interference patterns and will smear out the interference fringe. In the language of coherent length, interference can only be observed (non-zero contrast) within the region where  $ \Delta r \leq L_{c} $ (The path difference has to be less than coherent length).  $ L_{c} $, the coherent length, is related to the spectral distribution. In the case of wave packet as small as  $ 10^{-15} $m, the coherent length would be also this small. This means there would be no interference observed since  $ 10^{-15} $m is far below the spatial resolution of any available instruments.
So the electron interference pattern observed contradicts treating electron as classical wave or a superposition of them.
:) Electron is half time particle, half time wave
Besides this sounds ridiculous (this is not a scientific argument), it cannot explain the results (this is the argument).
If indeed the case, then let's for every electron reaching the detecting screen (assuming detecting efficiency is 100% for simplicity), then 50 of the electrons would show localized energy form as little 'dots', while the other 50 would show non-localized energy over the entire detection screen as wave. This is not what is observed in the experiment, 100 electron reached detection screen, 100 small 'dots' (localized energy) were recorded.
Besides, if 50% are particle, 50% are wave, the pattern observed

would be a combination of bullets experiment in case (a) and wave experiment in case (b), something like  $ \underline{\text{A}} $ . The contrast would decrease but this is not true.

You may construct other proposals like the above based on classical picture and theory of particle or wave, but inevitably failed to account for the experimental observation. The Young's experiment is indeed the most simple but also most important driving force in the development of quantum theory

From the above arguments, we have to accept that there is a limitation of the classical theory and classical distinction between particle and wave. This picture is at least incomplete if not totally wrong (It is not, depending on what you observe and the system under study).

New physical picture and /or concepts are needed as well as new theory for the microscopic objects.

New physical picture-----Particle-Wave Duality

New theory-----Quantum Mechanics

For the particle wave duality, we have to admit that the classical particle and wave properties exist simultaneously in the matter. Which aspect shows up depends on the situation (such as size, the momentum etc.), as well as on our measurement (whether we measure individual energy or probability distribution)

The matter itself of course exists in a certain form which does not care

whether we call it particle or wave. The reason we group it into either particles or waves in classical theory is due to the past experiments or daily life experience. Different theory explains different party. As the new experimental observation indicates such distinction is no longer valid under certain circumstance, we have to abandon the old 'picture' and adopt the new ones. This reflects our understanding to the true nature of the matter is getting deeper and better. The new theory and new picture will provide a self-consistent explanation for both aspects of the particle-wave duality.

So in summary, our current understanding for the nature of the matter is this: It is neither particle nor wave in the classical sense; it can show properties of either wave or particle. This new form of understanding is called MATTER WAVE developed by French physicist (and a prince) de-Broglie, which is summarized in his famous formula:  $ P = \frac{h}{\lambda} $ for all matters (not limited to photon as discussed in the last chapter).

Example: Some typical wavelength of matter wave for different matters.

For macroscopic object, such as bullet:

Mass=10^{-3}kg, Velocity=1000m/s, then  $ \lambda = h / P \div 10^{-34} m $

The wavelength is way too small to observe, so you never notice its wave property.

For electrons out of electron gun in double slits experiment:

Mass=10^{-30}kg, V=10^{4}m/s, then  $ \lambda = h / P \div 10^{-8} m = 10 nm $

It really like a short wavelength light and can show interference (the wave property) under certain lab conditions.

Another useful way to estimate wavelength for electron knowing the accelerating voltage $ ^{17} $:

 $$ E_{k i n e t i c}=U e V=U\times1.6\times10^{-19}J o u l e,P=\sqrt{2m E}\quad(Non-relativity) $$ 

 $$ \lambda=\frac{h}{P}=\frac{h}{\sqrt{2mE}}=\frac{12.3A}{\sqrt{U}}\quad(for electron) $$ 

(Note: A common error is like this: use the correct energy formula  $ E = h\nu $; then use the WRONG formula:  $ \lambda = \frac{C}{\nu} $, here the phase velocity of electron is NOT same as light. Actually we can calculate the phase velocity of electron  $ C_e $: If you follow  $ E = h\nu $ and  $ \lambda = \frac{C_e}{\nu} $ (notice it is  $ C_e $ not C), then  $ C_e \equiv \lambda\nu = \frac{h}{P} \frac{E}{h} = \frac{E}{P} = \frac{P^2 / 2m}{P} = \frac{P}{2m} = \frac{V}{2} $, the phase velocity of free moving electron is half of the kinetic speed which is the group velocity. This of course can be proved from quantum mechanics, solving Schrodinger equation for free electron, find phase velocity of the wave function of the electron, and its phase velocity from the wave function, as well as group velocity from dispersion relation  $ V_{group} = \frac{d\omega}{dk} \ldots $

For macroscopic object like the bullet,  $ \lambda = h / P \equiv 10^{-34} \, m $, due to its extreme short wavelength, it is impossible to observe its wave property. Here is the detailed argument:

<div style="text-align: center;"><img src="imgs/img_in_image_box_184_152_378_293.jpg" alt="Image" width="16%" /></div>


In this Young’s setup, we derived relations of adjacent maxima of the interference pattern, basically, it goes as:

Between the adjacent maxima:  $ \Delta r = r_1 - r_2 = \lambda $; also  $ \Delta r \approx a \sin \theta \approx a \theta $

The spacing between the adjacent maxima:  $ \Delta x \approx D\theta = \frac{D}{a}\lambda $

So the spacing between the interference fringes is on the order of wavelength. For extreme short wavelength, it is impossible to resolve this interference. The result is the convolution between the interference and instrument’s spatial response (which at best on the order of  $ 10^{-9} $m), so the observed is an average of those fast varying up-and-downs, which will smear out the interference. (Feynman fig.1-5)

## 11 -2 Physical Meaning of the Matter Wave---Probability Wave

(This is actually one of the fundamental postulates of the Q.M, which cannot be proved or derived, but tested correct by experiments. I shall come back to this again when we start the fundamental postulates of Q.M)

The natural question would be what this matter wave with particle-wave duality. How do we describe it in math? If so, what is the physical meaning of this mathematical description and do we have a

## self-consistent explanation?

In the classical wave theory, we know that the general solution of the wave equation is in the forms of  $ Ae^{i\phi(r,t)} $, where the amplitude A is related to energy (its module squared  $ |A|^2 $),  $ \phi(r,t) $ is the phase factor.

For the matter wave, it obeys not the classical wave equation but the Schrodinger equation. The solutions would also have similar math forms with amplitude and phase  $ Ae^{i\phi(r,t)} $. Then what is the physical meaning of A here? Is it related to the energy of the matter wave? The answer is NO! The A is related to probability as implied in the Young’s double slits experiment. Then it is the probability of what? It is the probability of finding the ‘particle’ (I have to borrow this simpler term from the classical theory instead of create some new name ‘wavicle’; though I hope you understand what I mean is the matter wave with duality) at certain location and certain time---This is the Born’s probability wave.

In summary, the matter wave is expressed by a wave function  $ \psi(r,t) $, it obeys Schrodinger equation and can generally be solved from it. Knowing the  $ \psi(r,t) $, all the other physical properties can be derived from it (these are the contents of other fundamental postulates of Q.M). This wave function representing the matter wave is a probability wave, whose amplitude relates to the probability of finding ‘particle’ in space-time.

(1) For discrete spectrum

(a) Wave Function Notation

Let's suppose that the particle can only exist at some discrete locations (the following figure shows a case with 3 discrete places), and the wave function's value (also discrete of course) is given in the figure.

\[\begin{array}{c} \psi(x)\\ \quad \

 $ \psi(x_i) $ is the probability amplitude at  $ x_i $

 $ |\psi(x_i)|^2 $ is the probability. (Do notice their difference and relation, in analogy to the field and energy. This is the fundamental postulate in Q.M.) $ ^{18} $

The total probability of finding the particle in the entire space is:

 $$ P_{total}=\int\psi^{*}(r,t)\psi(r,t)dr^{3}=\sum_{i}\psi^{*}(x_{i})\psi(x_{i})=1 $$ 

The wave function satisfies the above is called proper wave function. This restriction is called normalized condition which comes naturally from the probability description. If  $ \int \psi^{*}(r,t) \psi(r,t) dr^3 \neq 1 $, then wave function is not properly normalized. There is no trouble to find the proper one by:  $ \frac{\psi}{\sqrt{\int \psi^* \psi dr^3}} $, the wave function is modified by a common factor.

(b) Dirac Notation $ ^{19} $

Here we use a vector to represent the wave function. It is a vector spanned in some orthonormal basis in Hilbert space. In the example above (particle only appears at 3 discrete locations), the space is constructed by three orthonormal unit vectors.  $ |x_{1}>,|x_{2}>,|x_{3}> $, they satisfy:

Orthonormal Condition:  $ <x_i \mid x_j \geq \delta_{ij} = \begin{cases} 1 & i=j \\ 0 & i \neq j \end{cases} $ 20

Completeness (Closure) Condition:  $ \sum_i |x_i| < x_i| = I $

I is the identity matrix. The completeness means that the basis is complete; it spans the whole space, any state can be expressed as a combination of the basis. For the example above, any state describing the particle appearance at 3 discrete locations can be expressed as:

 $ |\psi \geq \psi_1 | x_1 > +\psi_2 | x_2 > +\psi_3 | x_3 > (\psi_i \text{’s are the expansion coefficients, it is the probability amplitude of finding particle at } x_i, \text{ it is indeed the } \psi(x_i) \text{ in the wave function notation}) $

$$\psi(x_i) \equiv \psi_i = <x_i \mid \psi > \quad \text{(this result can be seen from the}\

orthonormal conditions in 11-2; or use the closure relation:}\

\mid \psi \geq I \mid \psi \geq \sum_i |x_i \rangle \langle x_i | \psi \rangle\ )$$

In |x₁> basis, the matrix form (representation) of the state is:

 $ |\psi \rangle = \begin{bmatrix} \psi_1 \\ \psi_2 \\ \psi_3 \end{bmatrix} $ and its complex conjugate  $ <\psi | = \begin{bmatrix} \psi_1^* & \psi_2^* & \psi_3^* \end{bmatrix} $

The total probability is given by the module of the vector:

 $$ <\psi\mid\psi>=\left[\psi_{1}^{*}\quad\psi_{2}^{*}\quad\psi_{3}^{*}\right]\begin{bmatrix}\psi_{1}\\ \psi_{2}\\ \psi_{3}\end{bmatrix}=\sum_{i}\psi_{i}^{*}\psi_{i}\quad\text{same as}(11-1). $$ 

(2) For continuous spectrum

(what happened if x becomes a continuous variable)

The wave function  $ \psi(x,t) $ in this case is a continuous function rather than the discrete values above.

<div style="text-align: center;"><img src="imgs/img_in_image_box_216_517_517_702.jpg" alt="Image" width="25%" /></div>


This can be treated as a natural extension from the discrete case, as number of variable becomes large, $n\to\infty$, the spacing between them $\frac{1}{n}\to0$, just like transition from summation to integral. The probability of finding the particle in a small region around certain location, say $x^{\prime}$ is defined to be:

 $$ d\rho(x^{\prime})=\mid\psi(x^{\prime})\mid^{2}d x^{\prime} $$ 

| ∀(x') | 2 = ∀(x')* ∀(x') is called probability density at x'.

Total probability then is:

 $$ P_{total}=\sum d\rho(x^{\prime})=\sum\psi(x^{\prime})^{*}\psi(x^{\prime})dx^{\prime}\xrightarrow{dx^{\prime}\to0}\int\psi(x)^{*}\psi(x)dx $$ 

If it is =1, then the wave function is a proper wave function; if not, then just renormalize it.

In the Dirac Notation, we also treat it as limiting case from the discrete.

The above wave function is:  $ |\psi> $ the state vector now is expanded on

an infinite dimensional Hilbert space, spanned by unit vector  $ |x\rangle $, the expression of the expansion can be worked from the probability definition as following:

The total probability is:

$\psi\mid\psi

 $$ \int\left|x><x\right|dx=I $$ 

This is the complete relation for continuous situation, analogy to the relation 11-2 in the discrete case. Then we can work out the expansion expression of state vector:

 $$ \left|\psi>=I\right|\psi>=\int\left|x><x\right|\psi>d x=\int<x\left|\psi>\right|x>d x=\int\psi(x)\left|x>d x\right. $$ 

We could also find the orthonormal condition of the basis, this will be a little different from the discrete relation (11-2):

 $$ \psi(x)=<x\mid\psi>=<x\mid I\mid\psi>=\int<x\mid x^{\prime}><x^{\prime}\mid\psi>dx^{\prime}=\int\psi(x^{\prime})<x\mid x^{\prime}>dx^{\prime} $$ 

Recall the relation:  $  f(x) = \int f(x') \delta(x - x') dx'  $, this gives:

 $$ <x\mid x^{\prime}>=\delta(x-x^{\prime}) $$ 

Thus we have worked out the most important relations in the continuous basis, they are summarized as:

The orthonormal and complete relations of the basis (continuous):

 $$ <x\mid x^{\prime}>=\delta(x-x^{\prime}) $$ 

 $$ \int\left|x><x\right|dx=I $$ 

The expansion of state vector:

 $$ \left|\psi\right\rangle=\int\psi(x)\left|x\right\rangle d x $$ 

You may try this as an exercise, evaluate the probability from (11-6):

 $$ \begin{aligned}&|\psi>=\int<x|\psi>|x>dx=\int\psi(x)|x>dx;<\psi|=\int<x'|<x'|\psi>dx'=\int<x'|\psi(x)^{*}dx\\ &<\psi|\psi>=\iint\psi(x)\psi(x)^{*}<x'|x>dxdx^{\prime}=\iint\psi(x)\psi(x)^{*}\delta(x-x^{\prime})dxdx^{\prime}=\int\psi\psi^{*}dx\\ \end{aligned} $$ 

same as the relation at the beginning of last page.

The vector representation of the state is equivalent to the wave function which you may feel more comfortable at the beginning, since our previous descriptions in classical theory are mostly in function forms. Dirac's notation is just one mathematical 'trick', but a very powerful one. Though it does not provide any new physical laws (how could a math trick do that), it is an elegant way to present quantum mechanics. It does help us to understand the physical picture, ease the calculation in some cases, etc. So most modern textbooks on Q.M are using this notation, and that is why we will use it too mostly in this course.

Now, let's solve the electron's double slit experiment using the state vector:

<div style="text-align: center;"><img src="imgs/img_in_image_box_206_164_714_411.jpg" alt="Image" width="42%" /></div>


<div style="text-align: center;">(0)</div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;">(c)</div>


As shown in the Feynman’s fig.3-1, the electron’s initial state is  $ |s\rangle $ (electron out of the gun), and its final state is  $ |x\rangle $ (electron hits a location on detection screen). The probability amplitude of electron starting with  $ |s\rangle $ and ending in  $ |x\rangle $, is simply  $ \langle x|s\rangle $, this is the value we need to evaluate. If we expand the  $ |s\rangle $ into components of  $ |x\rangle $ (i.e.  $ |x\rangle $ as basis, find expression or projection of  $ |s\rangle $ on this basis),  $ \langle x|s\rangle $ is just the expansion (projection) coefficient. In case of double slits here, the initial state will be expanded onto the basis of  $ |1\rangle $ and  $ |2\rangle $ first.  $ |1\rangle,|2\rangle $ are electrons passing through hole 1 and 2 on the wall, respectively.

 $ \langle x|s\rangle=\langle x|(1\rangle\langle1|+|2\rangle\langle2|)|s\rangle=\langle x|1\rangle\langle1|\langle s\rangle+\langle x|2\rangle\langle2|\langle s\rangle $

We use the completeness relation  $ \sum |i><i|=I $. Here the electrons can only pass hole 1 or 2, and the electrons hitting other locations on the wall outside of holes are blocked and will not affect experimental results. (The rigorous statement is we only investigate a subspace of all the possible locations for electron to reach the wall, i.e. electrons pass holes; and within this subspace,  $ |1\rangle $,  $ |2\rangle $ are complete basis)

Another conventional way of reasoning (though a bit lengthy, it does explain the process in more detail) is as following:

At hole1 and 2, the initial state becomes a combination of  $ |1\rangle $ and  $ |2\rangle $:

 $$ \left|s\right|\Longrightarrow\left<1\right|s\left|\left.s\right>\right|1\left>+\left<2\right|s\right|\left.s\right>\left|2\right> $$ 

Then both  $ |1> $ and  $ |2> $ are expanded (projected) onto final states  $ |x> $

i.e.  $ |1 \geq \int <x' |1> |x' > dx' $;  $ |2 \geq \int <x' |2> |x' > dx' $^{22}

So the state of the system at the detection screen becomes:

 $$ \begin{aligned}&|s\gg\Longrightarrow\int(<1\mid s><x^{\prime}|\;1>+<2\mid s><x^{\prime}|\;2>)|\;x^{\prime}>dx^{\prime}=\int(\phi_{1}+\phi_{2})\mid x^{\prime}>dx^{\prime}\\ &where\;\phi_{i}=<i\mid s><x^{\prime}|\;i>\\ \end{aligned} $$ 

The probability amplitude at x is <x|s> and can be easily evaluated from the above relation. <x|s>=φ₁+φ₂ (where x’ will be replaced by x)²³. The probability would be P(x)=|<x|s>|²=|φ₁+φ₂|²=|φ₁|²+|φ₂|²+2Re(φ₁φ₂), thus there will be cross terms that give rise to interference.

## 11 -3 Uncertainty Principle

In the classical wave, we learned that there will be a limitation between the distributions of the variables. (see the Fourier Transform part), such as the relation between  $ \Delta k\Delta x $, and  $ \Delta\omega\Delta t $. This is the general results of superposition of waves and Fourier Transform. So for all kinds of waves including the matter wave here, as long as the wave forms is taking shape of  $ Ae^{i\phi} $ and the phase part is expressed in terms of  $ kx $ and  $ \omega t $,

would generate similar results in relations of  $ \Delta k\Delta x $, and  $ \Delta\omega\Delta t $.

So a natural extension from classical wave to the matter wave is:

 $$ \begin{pmatrix}\Delta k\Delta x\doteq2\pi\\\Delta\omega\Delta t\doteq2\pi\end{pmatrix}\xrightarrow[p=\hbar k]{E=\hbar\omega}\begin{pmatrix}\Delta p\Delta x\doteq h\\\Delta E\Delta t\doteq h\end{pmatrix} $$ 

(For all waves) (matter wave)

A more rigorous derivation from the fundamental postulates of Q.M will generate the accurate form for the uncertainty relation:

 $$ \Delta p_{x}\Delta x\geq\frac{\hbar}{2};\ \Delta E\Delta t\geq\frac{\hbar}{2} $$ 

I shall discuss the uncertainty principle by first showing a couple variations of the double slits experiment ('which way' experiments). These are experiments showing that if we tend to observe the particle behavior by deciding the trajectory of the particle, we will not observe the wave behavior, the interference pattern will disappear(this is also called Bohr's complementary principle, that is we can only observe either particle or wave behavior, but hardly both). This will act to illustrate the importance of uncertainty principle, i.e. we have to use this principle to explain the observation. Next I will show you the uncertainty principle sets up criteria for the application of quantum mechanics, i.e. when shall we apply Q.M to which system. $ ^{24} $

(1) Experiments illustrating the uncertainty principle

A. 'Which-Way' experiment I (Feynman fig. 1-4)

<div style="text-align: center;"><img src="imgs/img_in_image_box_287_217_743_447.jpg" alt="Image" width="38%" /></div>


The experiment is to use light scattering with electron to determine which hole the electron will pass, and at the same time measure the electron distribution on a screen. As the experimental results demonstrate, if we can determine the path of the electron by knowing which hole the electron passes, the interference pattern disappears and the total probability with both holes open  $ P_{12}=P_{1}+P_{2} $.

The question is why. Feynman gives a detailed discussion in the book and basically: The measurement of the position of the electron (which hole it passes) by light scattering inevitable introduce an interaction between photons and electrons. It is this interaction perturbs the state of the electron. The more accurate measurement of the position requires larger interaction (use shorter wavelength of light for better spatial resolution, thus larger momentum exchange between electrons and photons) and thus larger perturbation to the original state of electron. This will destroy the interference.

The interaction is the momentum exchange, which is determined by the momentum of the photon  $ p = h / \lambda $. So to make the perturbation small so that interference pattern still exists, longer wavelength of light should be used. However, if long wavelength of light is used, it will limit the ability of position determination, since spatial resolution is limited by wavelength. This is to say to maintain the interference pattern, the longer the wavelength of light the better; However to determine the electron to pass which hole accurately, the wavelength of light needs to be short. This creates a contradictory condition and cannot be satisfied simultaneously.

Of course, underlying this contradictory is the uncertainty principle between momentum and position. In order to determine the position of electron within certain precision  $ \Delta x $, we create uncertainty in the associated momentum. Here the uncertainty in the momentum  $ \Delta p $ of the electron is caused by the interaction with photon of wavelength of  $ \lambda $. Form the wave point of view, the interference pattern depends on the stability of the phase of the wave function contribution of hole 1 and 2, which is in the forms of  $ e^{i(k,r-\omega_{t})} $. If there are random phase between them, then no interference.

Applying the quantum relation  $ p = \hbar k $ and  $ E = \hbar \omega $, the propagation of the probability wave in free space would be in forms of  $ e^{i\left(\frac{p}{\hbar}r - \frac{E}{\hbar}t\right)} $

So the uncertainty in the momentum introduced by measuring position means a random phase factor in the phase between the contributions from hole 1 and 2. This random phase difference is $e^{i\frac{\Delta p}{\hbar}r}$ at certain space and time. Following the argument in the derivation of double slit in section 11-2, the result would be :

 $$ \left|<x\mid s>\right|^{2}=\left|\phi_{1}e^{\frac{\Delta p}{h}r}+\phi_{2}\right|^{2}=\left|\phi_{1}\right|^{2}+\left|\phi_{2}\right|^{2}+2\mathrm{Re}(\phi_{1}e^{\frac{\Delta p}{h}r}\phi_{2}^{*}) $$ 

Since the  $ \Delta p $ is random, so the interference will disappear unless  $ \frac{\Delta p}{\hbar}r << \pi $. But this would mean  $ \Delta x > \frac{\hbar}{2\Delta p} >> \frac{r}{2\pi} $. Since  $ r >> a $ (the paraxial condition, r is the path length from holes to screen and a is the spacing between the slit), then  $ \Delta x > a $, impossible to determine which hole the electron shall pass. So if you observe the interference, it is impossible to tell which hole the electron passes; if you determine which hole the electron passes, no interference will be observed, this is what the so called Bohr’s complementary principle originally addressed to, now I hope you see the underlying physics is uncertainty principle.

### B. 'Which-Way' Experiment II

This example was one challenge raised by Einstein to Bohr trying to defy the uncertainty relation. But the Bohr’s complementary principle and uncertainty relation holds in the end. We shall discuss this interesting example below.

<div style="text-align: center;"><img src="imgs/img_in_image_box_290_203_687_487.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">As Feynman fig.1-6 shows, if we construct a gedanken experiment (thought experiment) that can determine the passage of electrons through holes by measuring the momentum change of the wall on an ideal roller.</div>


The electron detector on the final backstop is placed at center. For simplicity let's assume the incoming electrons all have their momentum at  $ \theta = 0 $ (the normal angle to the wall). So if the electron finally reach detector through hole 1, it will 'kick' the wall upward; and if it is through hole 2, the wall will move downward.

<div style="text-align: center;"><img src="imgs/img_in_image_box_263_1090_754_1324.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;">As my drawing shows, the electron through hole 1 will have momentum change of the order of  $ \Delta p_x = -p \sin \frac{\theta}{2} $, and thus roller</div>


plate wall will have recoil momentum  $ p\sin\frac{\theta}{2} $. Similar argument for the hole 2 case, the recoil momentum of the wall there will be  $ -p\sin\frac{\theta}{2} $. It may seem at the beginning that we have a way to know the passage of the electron without introducing any further perturbation, such as light scattering in the previous example (the electron would pass the two holes anyway). Then can we observe the interference knowing the ‘which-way’? The answer is negative due to the uncertainty principle and the reason is the following: In order to tell which hole the electron will pass, the measurement of the momentum of the roller plate has to be accurate enough. How accurate? It has to have resolution better than the momentum difference between the cases that electron passes hole 1 and 2. i.e. Resolution of momentum measurement of the plate < recoil momentum difference for hole 1 and 2. In math:

 $$ \Delta p_{x-plate}<|p_{1-recoil}-p_{2-recoil}|=2p\sin\frac{\theta}{2}\approx p\theta\doteq p\frac{a}{D} $$ 

However, the uncertainty principle requires that the measurement of momentum with this accuracy means the loss of accuracy of the position of the plate. (i.e. the location of hole 1 and hole 2 will not be exact). The uncertainty of the holes position:

 $$ \Delta x_{plate}\Delta p_{x-plate}\geq h\rightarrow\Delta x_{plate}>\frac{h}{p}\frac{D}{a}=\lambda\frac{D}{a} $$ 

But this shift of the plate will cause the shift of the interference pattern on the detection screen by exactly same amount of  $ \Delta x $. We also know from the previous work that the spacing between the adjacent peaks (or valleys) of the interference fringe is  $ \lambda \frac{D}{a} $, same as  $ \Delta x $. So the shift of the  $ \Delta x $ is pretty large, will make the interference fringe smear out. (the shift in position of the plate makes the peak and valley overlap in the interference fringe and thus the drop of contrast)

In this case, the uncertainty principle also makes the determination of the passage and the observation of interference pattern simultaneously impossible.

I hope through the thorough discussion of the double slit experiment and ‘which-way’ experiment, I convince you the new nature of the matter---matter wave with particle-wave duality. The description of the state of the matter is by a wave function or state vector. This is a probability wave. The uncertainty relation is the result of this wave nature. The probability wave and uncertainty principle are both fundamental in Q.M. Though in current formulation, the probability wave is one fundamental postulate of Q.M.; the uncertainty relation can be derived from other postulates (This is shown close to the end of the notes). This is just the way of

formulation of the theory. It does not make uncertainty principle less important. Indeed if the uncertainty principle fails (you can construct which-way experiment and observe the interference), then the fundamental postulates will be on a shaky ground. This formulation is so called Copenhagen interpretation of Q.M. (After Niles Bohr. The director of theoretical physics institute at Copenhagen, Denmark, supported by people collaborated with him, including Born, Pauli, Heisenberg, Dirac, etc.)

Einstein and Schrodinger on the other hand, never fully convinced of this probability nature. The famous saying of Einstein: 'God does not throw dice' summarize it. This comes from their different views of what science can do and reality of nature is. For Bohr: 'It is wrong to think the task of physics is to find out how nature is'. 'Physics concerns what we can say about nature'. He believed that science has but two goals, 'to extend the range of our experience and to reduce it to order' $ ^{25} $ However, Einstein once said: 'What we call science has the sole purpose of determining what nature is'. To Einstein, what nature is should be independent of our observation. The reason you have probability and uncertainty is because we do not have complete knowledge and there may be some 'hidden variables' that are unknown to us which would give back

deterministic mechanics and certainty once we know them.

Then whose view is correct? In 1960's, John Bell put this scientific and philosophical debate into a testable math relation, the Bell inequality. And the experiments followed showed that the Bohr's is right.

The uncertainty relations (11-8) (You may find other forms like it in further study in Q.M. Basically a relation between non-commute physical observables, i.e. these are physical properties that cannot be determined simultaneously) is the intrinsic limit imposed by the nature. It is not due to our instrumental resolution. Even you have an ideal infinite resolved instrument, you cannot surpass this limit in determining a pair of non-commute observables, such as position x and its associated momentum  $ p_{x} $.

The reason of this is because for the microscopic system under study, its state is vulnerable to the perturbation. The measurement (or observation) involves interaction between the detection and the physical state of the system. (such as in observing the position of electron, we have to use light scattered from it, so light-electron interaction is involved) The interaction though small for the macroscopic object (light scattered from a bullet will have negligible effect on the state of the bullet), it is non-negligible in microscopic world. Thus the measurement of one property would

have an interaction that perturbs state of the system, makes the state change (so called ‘collapse’) and renders the determination of other properties less accurate.

(2) Uncertainty principle sets up a criteria for the application of Q.M.

Like in special relativity, c the speed of light or better  $ \beta = v / c $ is used to judge when we apply special relativity. The uncertainty relation (11-8) also provides criteria for the application of Q.M. What we need to do is to estimate the uncertainties and compare it with Planck constant, if it is much larger than h, the classical mechanics would work. This is best illustrated by examples.

A bullet with  $ m=10^{-3}kg, v=10^{3}m/s \rightarrow p=1kgm/s $ This bullet's motion in space (in 1-d for simplicity) is on the order of  $ x=10^{-3}m $. Then  $ xp=10^{-3} \gg h\sim10^{-34} $. So for this macroscopic object, within any practical accuracy (say  $ \Delta x/x\sim10^{-6}, \Delta p/p\sim10^{-6} $, which is basically the limit of our observation), the  $ \Delta x\Delta p $ is still much larger than the h. So the limit imposed by the uncertainty relation is negligible for macroscopic object. In this case, the x and p can be determined accurate enough for any practical application, the classical mechanics and trajectory picture is applicable.

Example of microscopic object

Electron moving inside atom

 $ m_e \doteq 10^{-30} \, kg, \, x \approx 10^{-10} \, m $ (electron is restricted or has probability of detecting it within this range to the nuclei)

 $ v_e \approx 10^5 \, \text{m/s} $ (This can be estimated by the resonance frequency of electron inside the atom, which is measured by absorption or emission of light, its frequency is about  $ 10^{-15} \, \text{Hz} $.)

Then $p=mv\approx10^{-25}$, and $xp\approx10^{-35}$ and this is comparable to the $h$. In this case, it would be impossible to determine both $x$ and $p$ with sufficient accuracy. Since if we require $\Delta x/x\ll1$; and $\Delta x\Delta p>h>xp$ here, so $\Delta p/p\gg1$. This means the momentum cannot be determined with any accuracy. So it is meaningless to talk about trajectory in this case, classical theory cannot describe the system and quantum mechanics has to be applied.

Another example using uncertainty principle: explanation of the stability of atom.

Previously we discussed that classical theory cannot explain the stable structure of atoms with electron and nuclei. The classical theory predicts the minimum energy is when the distance between the electron and nuclei is zero.

i.e.  $ E = E_{kinetic} + U_{potential} $

 $$ mv^{2}/r=e^{2}/r^{2}\rightarrow E_{kinetic}=\frac{1}{2}\frac{e^{2}}{r},\ U_{potential}=-\frac{e^{2}}{r} $$ 

So  $ E = -\frac{1}{2} \frac{e^{2}}{r} $ has its minimum at r=0.

The electron will collapse into the nuclei eventually in classical theory. However now we know that there is uncertainty principle which is important for the electron motion in atom. As it is more restricted to the nuclei (i.e. the probability distribution of the wave function for electron is more close to nuclei), this means smaller  $ \Delta x $ will indicate large  $ \Delta p $. This would have created large kinetic energy that will keep the electron from falling to nuclei.

So if the electron’s distribution is within a certain distance from the nuclei, its average is  $ r_{0} $.

 $$ \begin{aligned}&Then\ E_{kinetic}=<\frac{p^{2}}{2m}>_{average}\doteq\frac{(\Delta p)^{2}}{2m}\geq\frac{h^{2}}{2mr_{0}^{2}}\text{}^{26},\quad U_{potential}=-\frac{e^{2}}{r_{0}}\\ &E=\frac{h^{2}}{2mr_{0}^{2}}-\frac{e^{2}}{r_{0}}\\ \end{aligned} $$ 

This energy will have a minimum value  $ r_{0}=a_{0}=\frac{h^{2}}{m_{e}e^{2}} $ and the minimum energy is  $ E_{\min}=-\frac{m_{e}e^{4}}{2h^{2}} $. (if you use  $ \hbar $ instead of h in the evaluation, the result is exactly the Bohr’s radius of electron in Hydrogen atom and the energy is the 1S energy of the electron. This coincidence is purely accidental. The uncertainty principle is useful for qualitative analysis, but you should not expect it to give you exact

quantitative answer) The point here is that without resort to the formal treatment of Q.M., you may appreciate that it can solve the puzzles which the classical theory fails.

## 11 -4 Fundamental Postulates of Quantum Mechanics

This part of discussion is a formal treatment of Q.M. Such postulation method is adopted in most of the standard textbook. $ ^{27} $ These postulates are summarized over years of experimental observations and theoretical modeling, some of which we discussed in the previous sections. These postulates form the foundation of quantum mechanics. Such approach is also common in all branches of physics, such as Newton’s laws of motion (or Least action of Lagrange; Hamiltonian) in classical mechanics; three laws in thermodynamics; Maxwell equations in electro-magnetic theory, etc. The postulation approach bears advantage of theoretical clarity, but lacks the historical development that leads to it, so we spend first part of this chapter discussing some of that. Now it is time for the crown jewel. The formalism of the quantum theory and its mathematical description has to include all the ‘strange’ features that we have discussed. Such as

existence of ‘quanta’---the discrete energy and momentum changes during interaction, whose values cannot be further divided into smaller quantity (This is also called indivisibility); the particle-wave duality of all matter; and the probability interpretation of the wave function. $ ^{28} $

(1) The fundamental questions addressed by the postulates.

In analogy to classical mechanics, the following basic questions need to be answered:

(i) How the physical state of a system at a certain time is described mathematically in quantum mechanics?

(ii) Given a state, what are the results of measurement of various physical properties? (such as position, momentum, energy, angular momentum...)

(iii) How is the state evolving with time? i.e. what is the state at time t if the state at  $ t_{0} $ is known.

We know the answers in classical mechanics, the first two are kinematics, and the last is dynamic problem. In summary of classical mechanics:

(i) The system at certain time is described by a set of coordinates  $  q_i(t_0)  $; and their canonical conjugate momentum  $  p_i(t_0) = \frac{\partial L}{\partial q_i}  $

(ii) Knowing the state of the system, the properties are completely

determined,  $ E = H = \frac{p^{2}}{2m} + U(q) $ for energy;  $ L = q \times p $ for angular momentum, etc. can all be calculated. This determination in measurement means that we can predict results with complete certainty.

(iii) The time evolution of the system is given by Hamilton equations:  $ \frac{\partial H}{\partial q_i} = -p_i $ and  $ \frac{\partial H}{\partial p_i} = q_i $

## (2) Quantum Mechanic Postulates

These postulates are basically addressing to the above questions, i.e. state description; measurement and time evolution of the state, and in accordance with the quantum features (the indivisibility, duality and probability). So you may guess three postulates. I present it in a similar form as in Shankar’s with 4 postulates (there are 2 about measurement, since measurement inevitably perturbs the state in Q.M., and treatment is very different from that of classical theory). Of course how we group the postulates is not important. It is the contents that matter.

I. Postulate 1: the description of the physical state of a system

At a fixed time t, the state of a physical system is described by a

state vector  $ |\psi(t)\rangle $ (Dirac's ket) belongs to a Hilbert space.

This sounds abstract. But we have already discussed relation

between the Dirac’s vector notation and wave function. Both descriptions are equivalent. However, the state vector is more generalized; while the wave function is just one representation of  $ |\psi> $ in the spatial coordinate system,  $ \psi(x,t)=<x|\psi(t)> $. Certainly the  $ |\psi> $ can be expressed in other basis which is extremely useful. How we choose or construct the basis will be concern of the next postulate.

Note: This vector description already implies the superposition principle: i.e. a state vector can be written (also called decomposed) as a superposition (also called combination or expansion) of different components (a basis). And a linear combination of vectors is also a vector in the same space.

The ket  $ |\psi> $ in certain basis will be represented as a column vector. i.e.  $ |\psi\rangle=\psi_{1}|1\rangle+\psi_{2}|2\rangle+\psi_{3}|3\rangle+\ldots $ where  $ |1\rangle $,  $ |2\rangle $,  $ |3\rangle $ are basis vectors,  $ \psi_{i} $ is a complex number that is the expansion coefficient. In the language of liner algebra, this is

represented as:  $ |\psi\rangle=\begin{bmatrix}\psi_{1}\\ \psi_{2}\\ \psi_{3}\\ \cdot\\ \cdot\end{bmatrix} $ and its complex conjugate is given

by:  $ <\psi\mid\equiv(|{\psi}\rangle)^{*}=\left[\psi_{1}^{*}\quad\psi_{2}^{*}\quad\psi_{3}^{*}\quad\bullet\bullet\right] $

II. Postulate 2: physical quantity and operator

For every physical measurable quantity A, it can be described

by an operator A in Hilbert space. This operator is linear and

Hermite. Such operator is also called observable.

In the language of matrix, the operator is represented by a nxn matrix in a space with dimension of n.

Comments: properties of an observable.

(1)Linear:  $ A(a \mid \varphi_1 > +b \mid \varphi_2 >) = aA \mid \varphi_1 > +bA \mid \varphi_2 > $

(2) Hermite:  $ A^{\dagger} = A $ (11-10)

 $ A^{\dagger} $ is the transposed and complex conjugate of the original A in matrix form.

(3) Eigenvalues and eigenvectors:

 $$ A\mid u_{n}>=\lambda_{n}\mid u_{n}> $$ 

Where  $ \lambda_{n} $ is the eigenvalue, a complex number in general;

 $ |u_{n}> $ is the associated eigenvector.

For Hermite operator satisfying (11-10), there is one important property: The eigenvalues are real and eigenvectors associated with different eigenvalues are orthogonal.

Proof: From the definition of eigenvalues and eigenvectors and property of Hermite and complex conjugate, I can write:

 $$ \begin{aligned}&A\left|u_{i}\right.\right\rangle=\lambda_{i}\left|u_{i}\right.\left.\left(1\right)\quad<u_{i}\mid A^{\dagger}=<u_{i}\mid A=\lambda_{i}^{*}<u_{i}\mid\left(2\right)\right.\\&A\left|u_{j}\right.\left.\right\rangle=\lambda_{j}\left|u_{j}\right.\left.\left(3\right)\quad<u_{j}\mid A^{\dagger}=<u_{j}\mid A=\lambda_{j}^{*}<u_{j}\mid\left(4\right)\right.\\ \end{aligned} $$ 

Let the  $ <u_{i}| $ times the (1) from left, and  $ |u_{i}> \text{times}(2) $

from right, we have:

 $$ <u_{i}\mid A\mid u_{i}>=\lambda_{i}<u_{i}\mid u_{i}>and<u_{i}\mid A\mid u_{i}>=\lambda_{i}^{*}<u_{i}\mid u_{i}> $$ 

So  $ \lambda_i < u_i \mid u_i \geq \lambda_i^* < u_i \mid u_i > \rightarrow \lambda_i = \lambda_i^* $ for none zero vectors

This proves that the eigenvalues are real.

Let the  $ \langle u_{j} \mid \text{times the (1) from left and } |u_{i} \rangle \text{ times (2)} $

from right, we have:

 $$ \begin{aligned}&<u_{_{j}}\mid A\mid u_{_{i}}>=\lambda_{_{i}}<u_{_{j}}\mid u_{_{i}}>\\&<u_{_{j}}\mid A\mid u_{_{i}}>=\lambda_{_{j}}^{*}<u_{_{j}}\mid u_{_{i}}>=\lambda_{_{j}}<u_{_{j}}\mid u_{_{i}}>\\&(\lambda_{_{i}}-\lambda_{_{j}})<u_{_{j}}\mid u_{_{i}}>=0\\&<u_{_{j}}\mid u_{_{i}}>=0\text{for}\lambda_{_{i}}\neq\lambda_{_{j}}\\ \end{aligned} $$ 

(4) The eigenvectors of an observable forms an orthogonal and complete basis for the space.

As already presented in formula  $ (11-2) $ and  $ (11-5) $,

For discrete spectrum ( $ \lambda_{i} $ is discrete):

Orthonormal condition:  $ <u_j |u_i \rangle = \delta_{ij} $

 $$ \sum_{i}|u_{i}><u_{i}|=I $$ 

For continuous spectrum (λ 's is continuous):

Orthonormal condition:  $ <u_\alpha |u_\alpha' \rangle = \delta(\alpha - \alpha') $

Completeness:

 $$ \int\left|u_{\alpha}><u_{\alpha}\right|d\alpha=I $$ 

The orthogonal condition is already proved for Hermite operator, and normalization condition can always be achieved by renormalization procedure to make the module of the vector equals 1. The completeness, however, is a condition of the observable, i.e. it is part of the definition of an

observable. $ ^{29} $

The orthonormal and completeness relation are extremely useful, here are some examples illustrating their use.

Example 1: Projector operator  $ |u_i><u_i|^30 $

This is called projector because it acts on a state vector to get the coefficient and the  $ |u_{i}\rangle $. i.e.

 $ |\psi\rangle=\sum_{j}c_{j}|u_{j}\rangle $ (any vector expanded as combination of

basis)

 $ c_j = <u_j | \psi > $ (the expansion coefficient can be calculated from the orthonormal conditions)

Now apply the projector to the state:

 $$ \left|u_{i}><u_{i}\right|\psi>=|u_{i}>(<u_{i}|\psi>)=c_{i}|u_{i}> $$ 

The projector ‘picks out’ the  $ |u_{i}> $ components out of the original state vector. The completeness condition can be viewed from this projector point of view, that if we know all the projections of the vector along all the basis direction, we know the complete information about the vector.

Example2: Use the completeness relation to find the expression of a vector on a basis:

 $$ \left|\psi>=I\right|\psi>=\sum_{i}\left|u_{i}><u_{i}\right|\psi>=\sum_{i}<u_{i}\left|\psi>\right|u_{i}>=\sum_{i}c_{i}\left|u_{i}>\right| $$ 

The module squared of the state vector (related to the total probability):

 $$ \begin{aligned}&<\psi\mid\psi>=<\psi\mid I\mid\psi>=<\psi\mid\sum_{i}\mid u_{i}><u_{i}\mid\psi>\\ &=\sum_{i}<\psi\mid u_{i}><u_{i}\mid\psi>=\sum_{i}c_{i}^{*}c_{i}\\ \end{aligned} $$ 

If this equals 1, the state is a proper physical state; if not then renormalize it by:

 $ |\psi' \geq \frac{|\psi >}{\sqrt{<\psi |\psi >}}} $,  $ |\psi' > $ is a proper physical state that is normalized.

Example 3: The expression for an operator on a basis  $ |u_i|^{31} $:

 $$ A=IAI=\sum_{i}|u_{i}><u_{i}|A\sum_{j}|u_{j}><u_{j}|=\sum_{i,j}<u_{i}|A|u_{j}>|u_{i}><u_{j}| $$ 

So the operator is expressed as combinations of  $ |u_i><u_j| $ (this is not a projector, but similar, it is also what is called rank one matrix) with coefficient  $ <u_i|A|u_j> $.

This is much clearer if we write out the explicit matrix expression of A on basis of  $ u_i $'s. Let's consider one term in the summation, say  $ i=2 $,  $ j=1 $. The matrix forms are:

 $$ \begin{aligned}&\left|u_{2}\right.\rangle\left.=\begin{bmatrix}0\\ 1\\ 0\\ 0\\ \cdot\\ \cdot\end{bmatrix},\quad<u_{1}\right|=\left[1\ 0\ 0\ \cdot\ \cdot\right]\\ \end{aligned} $$ 

 $ |u_2><u_1|=\begin{pmatrix}0&0&0\\1&\ddots&0\\0&0&0\end{pmatrix} $ a rank one matrix only has none zero

at row2 column 1 (position 21)

So the term  $ \langle u_2 \mid A \mid u_1 \rangle \mid u_2 \rangle \ll u_1 $ in the summation in matrix:

 $$ <u_{2}\mid A\mid u_{1}>|u_{2}><u_{1}|=\begin{pmatrix}{{{0}}}&{{{0}}}&{{{0}}} \\{{{A_{21}}}}&{{{\ddots}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{pmatrix},while<u_{2}\mid A\mid u_{1}>=A_{21} $$ 

Take all terms in the summation, you will get the complete matrix form of A on basis  $ |u_i> $, with matrix element  $ A_{ij} = <u_i | A | u_j> $ (11-11)

(I derived this in the supplemental material on matrix with another method, here is just using the completeness relation)

In the above discussion, the  $ |u_{i}\rangle $ is any complete basis, not necessarily the eigenstates of the A. If the  $ |u_{i}\rangle $ are the eigenstates, then the above relations would be simpler:

 $$ A=\sum_{i,j}|<u_{i}\mid A\mid u_{j}>|u_{i}><u_{j}|=\sum_{i}\lambda_{i}\mid u_{i}><u_{i}\mid $$ 

Notes: in 11-12,  $ |u_i\rangle $'s are the eigenstates of the A. The

operators A can be written as a combination of projectors formed by its eigenstates.

The Identity in the completeness relation is very useful, you will find it inserted in many places, to work out the vector's or operator's expression on certain basis.

III. Postulate 3: Measurement of physical quantity (only for non-degenerate here for simplicity $ ^{32} $)

This is a long postulate, it contains three parts:

(i) Possible Results: The only possible result of a measurement of a physical quantity A is one of the eigenvalues of the corresponding operator A.

(ii) If the $A$ is measured on a system at a normalized state $|\psi>\$, then the probability $P(\lambda_{n})$ of obtaining the eigenvalue $\lambda_{n}$ of $A$ is:

 $$ P(\lambda_{n})=|<u_{n}\mid\psi>|^{2}=<\psi\mid u_{n}><u_{n}\mid\psi> $$ 

Where  $ |u_n> $ is the corresponding eigenvector.

Notes: This means that if the initial state is one of the eigenvector, say  $ |u_{n}\rangle $, then the measurement result is deterministic, always getting the corresponding eigenvalue. If the initial state of the system is not an eigenvector of the measurement, the results would be probabilistic: i.e. for each

measurement, we cannot predict the exact result; but we know the probability of getting a certain eigenvalue by (11-13) after many such measurements.

Another way of stating the same thing is to use the probability nature of the wave function or state vector and superposition principle:

 $ |\psi\rangle=\sum_{n}c_{n}|u_{n}\rangle $ (the state vector is decomposed into components on the basis of eigenvectors, as a superposition of the basis vectors)

The expansion coefficient  $ c_n = <u_n | \psi > $ (because the eigenvectors are orthonormal)

Since the state is a superposition of the eigenvectors, the measurement would result in all possible eigenvalues. The probability of finding state  $ |\psi> $ at state  $ |u_{n}\rangle $, thus the measurement of A would give  $ \lambda_{n} $ would be given by the coefficient (this is the meaning of probability wave we discussed earlier):  $ P(\lambda_{n})=c_{n}^{*}c_{n}=|\langle u_{n}|\psi\rangle|^{2} $

(iii) Collapse of the initial state: If we perform a measurement of physical quantity A, on a system at state  $ \left|\psi\right> $ (before the measurement), and we get the result  $ \lambda_{n} $. Then the state immediately after the measurement changes into the eigenstate  $ \left|u_{n}\right> $ associated with  $ \lambda_{n} $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_335_182_759_378.jpg" alt="Image" width="35%" /></div>


Comments: the measurement due to the inevitable perturbation to the system, causes the ‘sudden death’ or collapse of the original state, and project the original state into the eigenstate corresponding to the measurement result. This is also sometimes called reduction of the original state (by measurement), and the physical reasoning is still a mystery.

Another way to put it:

 $$ \left|\psi\right>{\xrightarrow[\lambda_{n}]{}\;e^{i\theta}\left|u_{n}\right>} $$ 

Notes: $e^{i\theta}$ is to stress the possible phase change during the measurement. $|u_n>\text{or }e^{i\theta}|u_n>\text{(or more generally any state}|\psi>\text{and a common phase factor attached to it }$

$e^{i\theta}|\psi>\text{represent the same physical state. The state can be written in either way, the arbitrary common phase would have no effect in the measurement. The measurement results would be same in both cases: if you introduce common phase factors to}|\psi>,|u_n>\text{or both, they would not affect}$

the probability of measurement given by (11-13), since in  $ \langle\psi|u_{n}\rangle\langle u_{n}|\psi\rangle $, the phase factors would cancel because of the complex conjugate.

Another way to look at this is that: suppose we chose  $ |u_n> $ as our basis, and we have for a given state  $ |\psi> $

 $$ \left|\psi\right>=\sum_{n}<u_{_{n}}\left|\psi>\right|u_{_{n}}>=\sum_{n}c_{_{n}}\left|u_{_{n}}\right> $$ 

Now suppose we use an equivalent basis  $ |u_n'> $, and

 $ |u_n' \geq e^{i\theta_n} |u_n> $. The expression of  $ |\psi> $ would be

equivalent to that of  $ |u_n> $ basis, here is how:

 $$ \left|\psi\right>=\sum_{n}<u_{n}^{^{\prime}}\left|\psi>\right|u_{n}^{^{\prime}}>=\sum_{n}<u_{n}\left|\psi>e^{-i\theta_{n}}e^{i\theta_{n}}\right|u_{n}>=\sum_{n}c_{n}\left|u_{n}\right> $$ 

As discussed above, the common phase factor does not alter the physical state (this is quite similar in classical wave theory, the initial phase of a wave is always arbitrary). However, the relative phases between the components are important! Relative phase means the phase between the expansion coefficient  $ c_{n} $, where  $ c_{n} $ is generally a complex number.  $ c_{n}=e^{i\delta_{n}}|c_{n}| $, and

 $ |\psi\rangle=\sum_{n}e^{i\delta_{n}}|c_{n}||u_{n}> $ the relative phase between  $ \delta_{n} $ will generally be always there (since you can only factor out one common phase, so it is the phase difference that matters), and this relative phase difference is important. Different relative phase  $ \delta_{n} $ (though  $ |c_{n}| $ may be same) would

represent different physical state. This is not a new idea,

consider a familiar case in polarization of light:

 $$ \frac{\sqrt{2}}{2}\begin{bmatrix}1\\ 1\end{bmatrix}=\frac{\sqrt{2}}{2}\left|H>+\frac{\sqrt{2}}{2}\right|V> $$ 

 $$ \frac{\sqrt{2}}{2}\begin{bmatrix}1\\ i\end{bmatrix}=\frac{\sqrt{2}}{2}\left|H>+\frac{\sqrt{2}}{2}i\right|V> $$ 

They are clearly two different polarization states, one is +45 linear polarized, the other is left circular polarized.

The postulate 3 is a long and profound one. I would also mention one important result of this postulate: The ‘average value’ of measurement of physical quantity A (the observable in postulate 2) on a given state  $ |\psi> $ (This value is also often called ‘expectation value’):

 $$ <A>_{\psi}=<\psi\mid A\mid\psi> $$ 

Clearly if the state is one of the eigenstate of A associated with eigenvalue $\lambda_{n}$, then from the postulate you will always get $\lambda_{n}$ in measurement and this $\lambda_{n}$ is the ‘mean’ value or expectation value (there is actually no need of average in this case):

 $$ <A>_{u_{n}}=<u_{n}\mid A\mid u_{n}>=\lambda_{n}<u_{n}\mid u_{n}>=\lambda_{n} $$ 

However, if the initial state is not one of the eigenstates, but a combination of them, i.e.  $ |\psi| = \sum_{n} c_{n} |u_{n}| $, the measurement would give different values with corresponding probability given by (11-13). We can ask for the average value of the

measurement, and this is the expectation value in (11-15):

 $$ \begin{aligned}&<\psi\mid A\mid\psi>=<\psi\mid IAI\mid\psi>\\=&<\psi|\sum_{n}|u_{n}><u_{n}\mid A|\sum_{n^{\prime}}|u_{n^{\prime}}><u_{n^{\prime}}|\psi>\\=&\sum_{n,n^{\prime}}<\psi\mid u_{n}><u_{n}\mid A\mid u_{n^{\prime}}><u_{n^{\prime}}|\psi>\\=&\sum_{n,n^{\prime}}c_{n}^{*}\lambda_{n^{\prime}}<u_{n}\mid u_{n^{\prime}}>c_{n^{\prime}}\\=&\sum_{n}c_{n}^{*}c_{n}\lambda_{n}\qquad use postulate3\rightarrow\\=&\sum_{n}P(\lambda_{n})\lambda_{n}\quad from definition of average value\rightarrow\\=&<A>_{\psi}\end{aligned} $$ 

This proves that indeed the expression in 11-15 does give the average value. In fact, we can also view the probability expression 11-13 from this expectation point of view:

 $$ P(\lambda_{n})=|<u_{n}\mid\psi>|^{2}=<\psi\mid u_{n}><u_{n}\mid\psi>=<\psi\mid\hat{P}_{n}\mid\psi>=<\hat{P}_{n}>_{\psi} $$ 

Where  $ \hat{P}_{n} $ is the projector operator  $ |u_{n}><u_{n}| $.

### IV. Postulate 4: Time evolution of the state

The time evolution is governed by the Schrodinger equation:

 $$ i\hbar\frac{\partial}{\partial t}\mid\psi>=H\mid\psi> $$ 

It is also expressed by some as:  $ i\hbar\frac{d}{dt}|\psi>=H|\psi>(11-16-2) $

Where H is the Hamiltonian, it is the operator associated with the total energy of the system.

Above is the general “vector” expression of the S-equation, and later quite often, it is expressed in the space representation, i.e. express the state vector and operator in the eigenstates of position observable:

 $$ i\hbar\frac{\partial}{\partial t}\psi(r,t)=[\frac{-\hbar^{2}}{2m}\Delta+V(\hat{R})]\psi(r,t) $$ 

The  $ \Delta = \nabla^2 = \frac{\partial^2}{\partial x^2} + \frac{\partial^2}{\partial y^2} + \frac{\partial^2}{\partial z^2} $，is related to momentum

opbservable, the detail from 11-16-1 to 11-16-3 will be given

later, here I just throw out this space representation.

Comment: You may be alarmed by  $ \frac{d}{dt} $ and  $ \frac{\partial}{\partial t} $ in the derivative in the S-equation, they mean differently in math, and can we write the equation either way?

The answer is YES, then how can total derivative and partial be

same? I will argue as following: the time change rate of a state

(any change)  $ \left|\psi(t)\right. $ to  $ \left|\psi(t+dt)\right. $ should be expressed as

 $ \frac{d}{dt} $, while the  $ \frac{\partial}{\partial t} $ will be same in quantum and convienient, the

key reason is that in quantum due to uncertainty relation, there

is no trajectory. Below is the detail.

Let me use the space representation to illustrate: The wave function  $ \psi(r,t) $ contains variable r (position), it is a different meaning than the r in the function of classical mechanics, say

$$f(r,t)\text{. In classical mechanics, the }r\text{ can depend on }t\text{, we have$$

$$

\begin{aligned}

\frac{df}{dt} &= \frac{\partial f}{\partial r} \frac{dr}{dt} + \frac{\partial f}{\partial t} \quad \text{is different} \\

\end{aligned}

$$

$$

\begin{aligned}

\frac{d}{dt} &= \frac{\partial f}{\partial r} \frac{dr}{dt} + \frac{\partial f}{\partial t} \quad \text{is different} \\

\end{aligned}

$$

$$

\begin{aligned}

\frac{d}{dt} &= \frac{\partial f}{\partial r} \frac{dr}{dt} + \frac{\partial f}{\partial t} \quad \text{is different} \\

\end{aligned}

$$

However, in quantum the $r$ in the $\psi(r,t)$ is different, we don't have trajectory! The $r$ here is the eigenvalues of the position operator! In Schrodinger picture (meaning time change is attributed to the state $|\psi(t)\rangle$, $R$ (position operator) is independent of time, and so will be its eigenvalues and eigenvectors. You see that Shrodinger picture is like choose the fixed coordinate where the bases doesnot change, the vector itself changes with time. Because $r$ is the eigenvalue, it is like a time-independent parameter in wave function, that is why $\frac{d}{dt}$ is same as $\frac{\partial}{\partial t}$ in S-equation. $\frac{\partial}{\partial t}\psi(r,t)$ is convenient to remind you this $r$ independence on time.

More generally:  $ |\psi(t) \geq \sum_{n} c_{n}(t) |n > , |n> \text{is an eigenvector of} $

some observable and n is a parameter labeling the expansion coefficient, in the S-picture, the base  $ |n> $ doesnot change with time, then:

 $$ \frac{d}{dt}\mid\psi(t)>={\sum_{n}\frac{dc_{_{n}}(t)}{dt}}\mid n> $$ 

In case of continuous base such as position case,

 $ c_n(t) \to c(n,t) $, expansion coefficients  $ c $ is a function of both  $ n,t $,  $ n $ is a continuous parameter independent of time (you see the wave function  $ \psi(r,t) $ fits in). Then  $ \frac{d}{dt} $ and  $ \frac{\partial}{\partial t} $ have same meaning.

The Schrodinger equation cannot be derived. It is the great guess by Schrodinger trying to find the wave equation that can give the solution of the electron’s motion of Hydrogen atom. No experimental results in non-relativistic regime violate it (we here only consider the non-relativistic cases. In the special-relativity case, there will be modification to the Schrodinger’s equation by Dirac. This will not be discussed here), so we just accept it as laws of nature at present.

Some important relations can be derived from the S-equation and will be discussed below. Since the Hamiltonian (H) governs the time evolution of the states, we will see it plays a central role in the quantum mechanics (actually it also plays the similar role in classical mechanics, the Hamilton formalism). The relations (such relations will be expressed as commutation relation defined below) between other physical observables (such as momentum, position, angular momentum etc) with H will determine whether these observables are “good” (exactly meaning discussed below), and the eigenstates of the H also

have special property we call “stationary”, meaning the time evolution of these eigenstates of H is simple.

## (1) Ehrenfest Theorem

I shall first like to discuss the Ehrenfest Theorem, which is the preliminary for discussion on section (2) below, and it also shows the link between the quantum mechanics and classical mechanics. $ ^{33} $ Let's consider the time evolution of the expectation value of a physical observable A:

$$\frac{d<A>_{\psi}}{dt}=\frac{d<\psi\mid A\mid\psi>}{dt}=\frac{d<\psi\mid}{dt}A\mid\psi>+\langle\psi\mid A\mid\frac{d\mid\psi\rangle}{dt}+\langle\psi\mid$$

Here according to the Schrodinger’s picture, the observable

would not explicitly depend on time, so$$\frac{\partial A}{\partial t}=0.\textsuperscript{34}$$ This is to say

that the coordinate system spanned by the eigenvectors of the

observable is time-independent; it is the physical state that

changes with time. Another picture is called Heisenberg picture

treats the observable change with time and the physical state is

not. Both Schrodinger and Heisenberg pictures are equivalent. It

is analogous to the description of the motion of a particle in a

coordinate system in classical mechanics. You can either fix the coordinate system, and the particle is moving in this fixed coordinate system; or you can treat the particle is not moving, but the coordinate system is. The Schrodinger equation in 11-16 is of course based on Schrodinger's picture) The time dependence of the state is given by Schrodinger equation 11-16. So we have $ ^{35} $:

 $$ \begin{aligned}\frac{d<A>_{\psi}}{dt}&=-\frac{1}{i\hbar}<\psi\mid HA\mid\psi>+\frac{1}{i\hbar}<\psi\mid AH\mid\psi>\\&=\frac{1}{i\hbar}<\psi\mid AH-HA\mid\psi>\end{aligned} $$ 

The relation between the operators AH-HA is very important and often shows up in Q.M. So we give it a name for this:

 $$ [A,H]\equiv A H-H A $$ 

This is called commutator of the two operators. Thus the time evolution of the expectation value is then:

 $$ \frac{d<A>_{\psi}}{dt}=\frac{1}{i\hbar}<[A,H]>_{\psi} $$ 

11-18 is called Ehrenfest Theorem. It states that the time evolution of the expectation value of a physical observable A is related to the expectation value of the commutator between A and H, the Hamiltonian.

This relation looks similar to its classical counterpart. For a

physical quantity A is classical mechanics, it is changing with time as:

 $$ \frac{dA}{dt}=\{A,H\} $$ 

Where  $ \{A,H\} $ is the Poisson bracket. In Q.M, it is replaced by the commutator. In the homework, you will calculate the commutator of [x, H] (between position operator and Hamiltonian) and [p, H] (between momentum operator and H). Then you will see that 11-18 will be reduced to the form:

 $$ \frac{d<x>_{\psi}}{dt}=<\frac{p}{m}>_{\psi}\quad and\quad\frac{d<p>_{\psi}}{dt}=-<\frac{\partial V(x)}{\partial x}>_{\psi} $$ 

V is the potential energy term, and the above relation is just definition of momentum and Newton's force law. The result also comes from the Hamilton-Jacobi equation in classical mechanics. So Ehrenfest theorem shows that the expectation value (or the average of results of many measurements) follows the classical theory, and the classical theory is a ‘special-case’ of the quantum mechanics.

## (2) Good Quantum Number and Stationary State

As stated above, the Hamiltonian operator plays important role in quantum mechanics (It is in fact in both classical and quantum), it is the operator representing the physical

observable---the energy of the system and it dominates the time evolution of the state (Schrodinger equation in QM and Hamilton equations in CM). In this section we discuss two general results which have close relation to the Hamiltonian operator in QM. I will give the results here and discuss them in the sections below. “Good quantum number” is referring to the eigenvalues of a physical observable, whose operator is commute with H; it is related to the constant of motion (conservative quantity) in classical mechanics. “Stationary state” is referring to the physical state prepared into an eigenstate of the Hamiltonian H, i.e. the energy eigenstate, the system at this state possesses certain energy value.

## (2-a) Good quantum number

If an operator Q commutes with H, [Q,H]=0, and the Q itself does not depend on time explicitly, then the eigenvalues of Q, {q_i}'s are called good quantum number.

We have seen from the Ehrenfest theorem, how the expectation value of any physical observable changes with time. Let the operator representing the physical observable be Q, then from 11-18:

 $$ \frac{\partial<Q>_{\psi}}{\partial t}=\frac{1}{i\hbar}<[Q,H]>_{\psi} $$ 

<Q>≡<γ | Q | γ > for any arbitrary state | γ>

Since  $ [Q,H]=0 $, then the expectation value of Q over any arbitrary state is independent over time, i.e.  $ <Q>= $ constant. It is a

conserved quantity, corresponding to the concept of constant of

motion in classical mechanics.

What is more, not only the expectation value of Q but all its higher moments,  $ \langle Q^{n}\rangle $, are independent of time, because  $ [Q^{n},H]=0 $ too. So the probability distribution of the measurement of the physical observable represented by Q won’t change with time. $ ^{36} $ This means if you carry out measurement on Q (physical properties represented by this operator) for any physical state (you may not start with an eigenstate of Q), you will get its eigenvalues  $ \{q_{i}\} $, and the probability distribution of this measurement won’t change with time. This is the meaning for “good quantum number” in an arbitrary state of the system.

For example (this example can be fully understood after we discuss spin and Stern_Gerlach experiment), electrons are in an uniform magnetic field along Z-direction, only has  $ B_{z} $. The interaction energy due to spin with magnetic field is proportional to  $ S_{Z}B_{z} $, so is the Hamiltonian here, thus  $ [S_{z}, H]=0 $. If you start with some arbitrary state, the measurement results won't depend on when you measure it. Suppose your starting state is  $ |+X\rangle $ by a

 $ SG_x $ setup, you will always get 50% of  $ +1/2 $ and 50%  $ -1/2 $ in the  $ S_z $ measurement no matter when you measure it. Though at later time, your starting  $ |X+> $ state will evolve into other state, such as  $ |Y+> $,  $ |Y-> $ ...(the time evolution of course can be calculated from the Schrodinger equation, the result for this simple case is  $ |X+> $ will presses around the  $ B_z $ field which I had not proved yet). This would be in contrast to observables not commute with  $ H $, say  $ S_x $. Its measurement ( $ S_x $) results would depend on time (initially only  $ +1/2 $, then later you will get both  $ -1/2 $ and  $ +1/2 $, at certain time you may only get  $ -1/2 $...).

Let’s look at the good quantum number from another point of view: If you start with a special state of the system, the eigenstate of Q, say  $ |q_{1},t=0> $ (the system can be initially prepared or projected into this state by measurement), of course you will get  $ q_{1} $ in the initial measurement for certainty, i.e.  $ \langle Q\rangle_{|q_{1},t=0\rangle}=q_{1} $; and  $ \langle Q^{2}\rangle_{|q_{1},t=0\rangle}=(q_{1})^{2} $, so variation=0 at time t=0. This is the meaning of the eigenstate, you will always get the associated eigenvalue. Let the system evolving with time and you carry out measurement of Q again later. Our above argument states that all the expectation values of all moments of Q will be independent of time for  $ [Q,H]=0 $, so you will get  $ q_{1} $ for certainty again at later time. The  $ q_{i} $ is conserved in this case and is good in this sense. This also implies that if the system is initially put

into an eigenstate of Q, it will be staying in the same eigenstate all the time! Because whenever you measure Q, you always get  $ q_{1} $ at later time. This property is exactly what we shall discuss in the stationary state.

Above property for commutable observables is quite general and discussed in the supplement and complete set of commutable observables(C.S.C.O), here I only summarize it without proof (see the supplement at the end of quantum notes for detail) for the commuting observables, they share common eigenstates. In this case, since  $ [Q,H]=0 $, Q and H would have same eigenstates, i.e. the eigenstate of Q would also be eigenstate of energy. The eigenstate of energy evolves with time with a unique property: it stays at the same eigenstate with only a phase change that is what we shall see right away.

## (2-b) Stationary State

These are the physical states of a system if they are initially prepared to be the eigenstates of Hamiltonian operator H, i.e.

 $$ \mathrm{H}|\mathrm{E}_{\mathrm{i}}>=\mathrm{E}_{\mathrm{i}}|\mathrm{E}_{\mathrm{i}}>\quad(11-19) $$ 

The  $ |E_i> $ are eigenstates of H with eigenvalue (the energy here)  $ E_i $.

Here I need to stress a point about the notation to avoid possible

confusion.  $ |E_i> $ is the eigenstate of H, if H is independent of time, then

its eigenstate will be independent of time too. These eigenstates will

form a basis on which other state vectors can be expanded.  $ |E_{i}\rangle $ is also called basis ket in this sense, it is not changing with time provided the operator does not depend on time explicitly (as in most cases in Schrodinger picture).

The physical state (physical ket) can be written as a combination of these basis kets (that is because as discussed in postulate 2, the eigenstates of observable forms a complete set of basis), and the physical state can change with time, the time change is reflected in the projection (expansion) coefficients, i.e.

 $$ |\psi(t)>=\sum_{i}c_{i}(t)\mid E_{i}>=\sum_{i}<E_{i}\mid\psi(t)>|E_{i}> $$ 

Using the Schrodinger equation, the time varying coefficients can be

evaluated:

 $$ i\hbar\frac{d\mid\psi(t)>}{d t}=H\mid\psi(t)> $$ 

 $$ i\hbar\sum_{n}\frac{d c_{_{n}}(t)}{d t}\mid E_{_{n}}>=\sum_{n}c_{_{n}}(t)E_{_{n}}\mid E_{_{n}}> $$ 

Take  $ \langle E_j \mid $ product from left, and apply  $ \langle E_j \mid E_n \rangle = \delta_{jn} $

 $$ i\hbar\frac{d c_{_{j}}(t)}{d t}=E_{_{j}}c_{_{j}}(t) $$ 

 $$ \frac{d c_{_{j}}(t)}{d t}=-i\frac{E_{_{j}}}{\hbar}c_{_{j}}(t) $$ 

 $$ c_{j}(t)=e^{-i\frac{E_{j}}{\hbar}t}c_{j0} $$ 

c j 0 = < E j | ψ (0) > is a constant, the coefficient at time 0 (11-21)

So (11-20) can be written as:

 $$ |\psi(t)>=\sum_{n}c_{n}(t)\mid E_{n}>=\sum_{n}c_{n0}e^{-i\frac{E_{n}}{\hbar}t}\mid E_{n}> $$ 

This relation shows us a strikingly important fact and very useful method: To study the time evolution of any state of the system, what we need to know is its initial (t=0) expansion in basis of the eigenstates of H, i.e. to know the  $ |E_n\rangle $ and those  $ c_{n0} $'s; then we know how it will change over time!

Specifically, if we prepare our initial state at t=0 into one of the eigenstate, say:

 $$ |\psi(t=0)>=|E_{j}> $$ 

i.e.  $ c_{j0}=1 $ and the rest are zeros. Then at later time t:

 $$ |\psi(t)>=e^{-i\frac{E_{j}}{\hbar}t}|E_{j}>\equiv|E_{j},t> $$ 

This means at later time, the system will be still an eigenstate of H with same energy as the initial one, only with a phase factor changing with time. Such state (the physical state prepared into the eigenstate of the energy) is called stationary state for reasons given below.

For the system in such state, all the measurement would give same probability distribution. i.e.:

 $$ P(\alpha)=|\alpha\mid E_{j},t>|^{2}=|\alpha\mid E_{j}>|^{2} $$ 

The probability of measurement of some physical observable would

be independent of time! This can also be considered from the point of

view in the last section. There we evaluate the expectation value of the

'good' physical observables that commute with H over an arbitrary state. Here we evaluate the expectation value of any observable A (good or bad, that is commuting with H or not, still assume that A will not depend on time itself) over a 'good' state---stationary state.

 $$ \frac{d<A>_{\left|E_{j},t\right>}}{dt}=<E_{j},t\left|\left[A,H\right]\right|E_{j},t>=<A>E_{j}-E_{j}<A>=0 $$ 

Higher orders of moments of A in the stationary state will also be

independent of time. i.e.  $ \frac{d < A^{n} > |E_{j}, t>}{dt} = 0 $ too. This means probability distribution of the measurement will be same all the time. This is why the state is called stationary, the big reason is the simple time evolution for such state given in relation 11-23.

Equation 11-19 (the equation for energy eigenstate) is also called time independent Schrodinger equation, it needs to be solved to get energy eigenstates and energy values of the system. The eigenstates and energy eigenvalues are important to determine the time evolution of any state of the system, indicated by 11-22, and the systems prepared into the eigenstate becomes a stationary state with simple time evolution in 11-23 and has advantage in measurement prediction. So solving 11-19 is one of the basic problems in quantum mechanics.

Thus concludes our discussions on the postulates of Q.M. This discussion

of the 4 fundamental postulates may appear abstract at the beginning. The study of quantum mechanics is to understand the meaning of these postulates by applying them to solve and explain various problems, which would be a major part in the course of quantum mechanics.

The general procedures $ ^{37} $ to tackle the problems in Q.M. is actually not too strange to us (we have used similar method in treating problems in optics)

(1)For a certain measurement or observation, construct the corresponding operator (the so called observable). It may simple in some cases, but may not in general.

(2) Find the eigenvalues and eigenstates of the observable (only simple in some special cases, such as two-level system in a 2-dimensional space)

(3) Use the superposition principle to describe the physical state of the system on a basis formed by the eigenstates of the observable. i.e.

 $ |\psi\rangle = \sum_{i} c_i |u_i\rangle = \sum_{i} <u_i | \psi\rangle |u_i\rangle $

(4)Use postulate 3 to predict the measurement result and use time-dependent Schrodinger equation to determine the time evolution of the state, especially with the help of (11-22)

### 11.5 Some Examples to Illustrate the Postulates

Here I do not intend to use the postulates, especially the Schrodinger equation, to solve the problems in some typical systems, such as particle inside a potential well; time-evolution of the two-level system, harmonic oscillator and angular momentum, etc. These are the topics covered in a standard Q.M. course.

I shall start with a simple example of polarization of light (we already know well in the classical sense), treat it using the language of Q.M. This is a simple but important example, illustrating most of the postulates (except the Schrodinger equation). Then as time allowed, I shall discuss the examples (experimental results and their explanations) used by Feynman in his Chapter3 and 4. Then I will discuss the Stern-Gerlach experiment of a spin1/2 particle, the electron.

### Example1. Light passing linear polarizer

For a linear polarized light, here for simplicity let's say it is +45 degree

linear.

<div style="text-align: center;"><img src="imgs/img_in_image_box_297_1255_483_1405.jpg" alt="Image" width="15%" /></div>


a linear polarizer with transmission axis horizontal and assume this

polarizer is ideal with perfect extinction ratio, i.e.  $ T_V/T_H = 0 $

<div style="text-align: center;"><img src="imgs/img_in_image_box_223_152_873_399.jpg" alt="Image" width="54%" /></div>


So this H polarizer will let  $ |H> $ pass 100% and block the  $ |V> $ light 100%.

A detector will be placed after the polarizer to measure the light. We learned from the classical theory, if the  $ I_{0} $ is the intensity of the input  $ |+45> $, the  $ D_{1} $ will record  $ 1/2 I_{0} $.

The reason is (I just repeat the what we already discussed in the Malus' law) for the input of  $ I_0 $, the field has amplitude  $ \sqrt{I_0} $ and the input state of  $ |+45\rangle $ is:  $ \frac{\sqrt{2}}{2}\sqrt{I_0}\left[1\right]=\frac{\sqrt{2}}{2}\sqrt{I_0}\left|H\right>+\frac{\sqrt{2}}{2}\sqrt{I_0}\left|V\right> $

The amplitude  $ \frac{\sqrt{2}}{2}\sqrt{I_0} $ here is related with energy in classical theory. Since only the  $ |H> $ component will pass the polarizer, and its energy is the amplitude squared, so  $ I_{D1}=(\frac{\sqrt{2}}{2}\sqrt{I_0})^2=\frac{1}{2}I_0 $

What happened if we carry out the experiment with single photon? (assume we have good single photon source and single photon detector, which are available nowadays) For every photon fired from the source (which could be known to us), what is the response of the detector  $ D_{1} $? The classical argument above suggests for every photon fired, the detector will register a ‘click’, i.e. generates a signal (imagine it is hooked

to a loud speaker to create sound). The volume of the sound will be less, half compared with firing the photon directly into the detector. This prediction is wrong.

The experimental results are well known. The photon is a fundamental particle and cannot be further separated. The experimental observations are as following:

(1)For every photon fired from the source,  $ D_{1} $ may record the photon and give a click; or  $ D_{1} $ is completely silent (no photon detected). For recorded photon, the volume of the sound of click is same.

(2)For a specific measurement, can the observer beforehand predict whether the  $ D_{1} $ is silent or click? One cannot. Whether the  $ D_{1} $ silent or click is probabilistic for each measurement, we have no way to predict the exact response of it.

(3)However, if we repeat this single photon  $ \left|+45\right> $ polarization many times, say N times (N is large). We can predict the probability of ‘clicks’ by  $ D_{1} $ in these N trials. It is 1/2, and the number of times the detector has clicks is N/2.

(4)Imagine we insert a second linear polarizer after the first and its transmission axis is also horizontal. Then $D_{1}$ will record same hits as the first case with single polarizer. If we rotate the second polarizer 90 degree making its transmission axis vertical, then $D_{1}$ will be completely silent.

With the postulates of Q.M., the above observations can be explained nicely (you may try it yourself).

The standard procedure (listed at the end of last section) is to expand the input state in terms of eigenstates of the measurement (the observable). The eigenstates (or eigenvectors, the two terms are interchangeable) in this case are simple. For the linear polarizer H (horizontal pass), its eigenstates are simply |H> and |V> linear polarized light, with eigenvalues 1 and 0 respectively, i.e.

 $ H|H \geq 1|H > 1 \text{ means } 100\% \text{ pass} $

 $ H|V \geq 0|V > 0 \text{ means } 100\% \text{ block} $

The matrix form of the H operator in  $ |H\rangle $,  $ |V\rangle $ basis is  $ H = |H\rangle < H | = \begin{pmatrix} 1 & 0 \\ 0 & 0 \end{pmatrix} $

This is basically the postulate 2, the  $ |H\rangle,|V\rangle $ forms a orthonormal and complete basis for representation of polarization of light. The expansion of the input on this basis is already given in Jones vector form as we discussed in the polarization.

Then from postulate 3, for any input, the measurement result is either 1 (that is the detector will register a click) or 0 (the detector is silent)---observation (1).

For input photon of +45 linear polarized:

 $$ \left|+45\right\rangle=\frac{\sqrt{2}}{2}\left|H\right\rangle+\frac{\sqrt{2}}{2}\left|V\right\rangle $$ 

Is expanded (as superposition) on the basis of the eigenstates of H, the |H>

and  $ |V> $. This  $ |+45> $ state is not an eigenstates of the H, so the measurement results are probabilistic. i.e. for each photon reaches the polarizer, you have no idea whether it will collapse into  $ |H> $ or  $ |V> $, thus is transmitted or blocked. You can only predict after many trials, the probability of getting 1's or 0's (the probability of the input being collapsed or projected into the  $ |H> $ or  $ |V> $ states). This probability is given by the probability amplitude that is the expansion (projection) coefficient:

 $$ \begin{aligned}&P(|H>)=|<H|+45>|^{2}=\frac{1}{2}\\ &P(|V>)=|<V|+45>|^{2}=\frac{1}{2}\\ \end{aligned} $$ 

Though you cannot predict measurement results for each trial (either 1 or 0), you can calculate the average value of each measurement after many trials. This is the expectation value of the measurement:

 $$ <H>_{|+45>}=<+45\mid H\mid+45>=\frac{1}{2}(<H\mid+<V\mid)H(\mid H>+|V>)=\frac{1}{2}<H\mid H>=\frac{1}{2} $$ 

For N trials, the average number of recording is N/2. (Note the 1/2 here does not mean 1/2 photon, it is an average value of each measurement after many trials, 1/2 is the result of half time recording one photon and half time none). This explains the observations (2) and (3).

After the photon passing through the first polarizer, the postulate 3 tells us that it has been projected from the  $ |+45> $ input to a new state  $ |H> $ and thus can pass the second polarizer completely if  $ H_{2} \| H_{1}  $; or completely

blocked if V2 ⊥ H1. This explains the observation (4).

A digression from the discussion of the postulates (not required for this course): Pure state and Mixed state.

What happens if we carry out the above experiment with natural light instead of  $ |+45\rangle $. The experimental results would be exactly same. We learned from the study of polarization of light, natural light (essentially unpolarized light) is different from the linear polarized light, the difference lies not in the magnitude of the amplitude (expansion coefficient) but in the phase (the expansion coefficients are generally complex numbers). Indeed for the natural light, the probability finding it in  $ |H> $ (gives 1 in the above measurement) or  $ |V> $ state is also 1/2. The above experiment gives same results as in  $ |+45\rangle $. This is because the phase information is lost in the measurement!

For the natural light, expanded on the basis of  $ |H> $,  $ |V> $ would take a form like:  $ |\psi_{\text{natural}}| \geq \frac{\sqrt{2}}{2} |H\rangle + \frac{\sqrt{2}}{2} e^{i\delta} |V\rangle $, where  $ \delta $ is a random number. As we stated earlier, the relative phase ( $ \delta $ here) between the coefficients is important while a common phase is not. The measurement probability for natural light is :

 $$ \begin{aligned}P(|V>)=&|<V\mid\psi>|^{2}=<\psi\mid V><V\mid\psi>\\=&\frac{\sqrt{2}}{2}e^{-i\delta}<V\mid V>\frac{\sqrt{2}}{2}e^{i\delta}<V\mid V>=\\ \end{aligned}\frac{1}{2} $$ 

So for the natural and +45 linear light, the measurement carried out on

|H>,|V> basis would give same results, though the inputs are different. To tell them apart would be easier, just rotate the linear polarizer, and results would be different. (same as discussion of light in E-M theory. Large number of photons, its statistical behavior such as the average, E-M theory would give same results as quantum)

The phase difference between the coefficients has profound impact in many applications. So I shall address the issue here in a bit more detail. In quantum mechanics, the state similar to the natural light is called “Mixed State”; while the linear polarized light is an example of the “Pure State”. Here the essence in the difference between the “pure” and “mixed” is the RELATIVE PHASE relations in the expansion coefficients. If the relative phase among components is fixed, then it is a “pure” state; if it is random, then the state is a “mixed” state. (so think of the natural and linear polarized light when you come across the mixed and pure state in later studies)

In order to get rid of the troublesome random phase factor  $ \delta $ in the  $ e^{i\delta} $ of the mixed state, Q.M. applies a method called Density Operator (or Density Matrix if the operator is expressed in certain basis). In this method, a density operator (math form similar to the observable, it is a nxn matrix rather than a nx1 column vector) is used to represent the physical state.

The density operator representation of the natural light is:

 $$ \rho_{n a t u r a l}=\frac{1}{2}\left|H><H\right|+\frac{1}{2}\left|V><V\right| $$ 

And for +45 linear polarized light, its density operator form is:

 $$ \rho_{+45}=\mid+45\rangle\langle+45\mid=\frac{\sqrt{2}}{2}(\mid H\rangle+\mid V\rangle)\frac{\sqrt{2}}{2}(\langle H\mid+\langle V\mid) $$ 

If you write out above form or the explicit matrix form in  $ |H\rangle, |V\rangle $ basis, you will see the difference between the natural and +45 light. There will be cross terms (or off-diagonal term in matrix) for the pure states, indicating the possible interference. If we use density operator to represent the state (a modification of postulate 1), the prediction of measurement needs to be modified accordingly. The details will be skipped here. The discussion here is mainly used to introduce the important concepts of pure and mixed state, the important facts are the phase relations among the components and it is going to be closely related to coherence and interference. For interested students, a brief but a clearer introduction of density operator is given. Chap.3, complements  $ E_{III} $ in Cohen-Tannoudji's Quantum Mechanics.

## Example 2: Young's double slits experiment with electron scattering photon

(Feynman’s 3-2)

The detailed description of the setup is in the book. It is a variation of

detecting electron’s distribution over double slits setup. But this time a photon source is placed after the slits. The photons can be scattered due to interaction with the electrons and the scattered photons can be detected by the detector1 or 2 as in the figure. The measurement is the distribution of those electrons that scatter the photons to detector D1 and D2. (i.e. we record correlated events that when D1 receives a photon, we record where the electron hits the screen; OR D2 receives a photon, and electron hits the screen. We do not look at the electron’s distribution if photons go into other directions) Then what is the results of the observation and how we explain it with postulates in Q.M.?

<div style="text-align: center;"><img src="imgs/img_in_image_box_253_770_696_1094.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;">(Fig.3-3, Feynman)</div>


From the discussed standard procedure, we need to expand the initial physical state into components of the eigenstates of the measured observable. So, we need to address:

(1)What is the expression for the initial physical state? It is a state vector (postulate 1) alright, but in this case, it is a state vector involving two particles, an electron and a photon. I will use symbol  $ |S>|\gamma_{l}> $ (actually the better symbol may be  $ |S,\gamma_{l}> $) to specify a state of

electron is in  $ |S> $ state and photon is  $ |\gamma_{l}>^{38} $. The detailed expression of  $ |S> $ or  $ |\gamma_{l}>^{39} $ is not main concern here and will not affect our reasoning and conclusion.

## (2) We need to find the eigenstates of the measurement

In the measurement, we measure the electron’s distribution on the detection screen, this is a position measurement and the eigenstate of this is  $ |X> $ (this means the electron will hit position X on screen). The photon will be scattered into all angles, so detection of photon is an angle detection (similar to position), and I will use  $ |\gamma_{\theta}> $ to represent the state that a photon flying in direction  $ \theta $.

The meaning of this is: if the electron and photon are in a state like

| X > |  $ \gamma_\theta\rangle $, it is a state that electron will hit X on detection screen and photon will go into direction  $ \theta $ and may be detected by photon detector there. If D is the observable for this measurement, then:

 $$ D\mid X>\mid\gamma_{\theta}>=X\theta\mid X>\mid\gamma_{\theta}> $$ 

(D can be thought as measurement of photon and electron, i.e.  $ D = D_{e}D_{l} $)

So  $ |X| > |\gamma_\theta> $ are the eigenstates of the observable and will be the basis to expand the initial state into.

The position and angle distribution for electron and photon are obviously continuous, and infinite dimensional. In the following discussion, I will use a discrete case to analyze the problem to simplify the writing (i.e. the electrons would only hit some locations on screen and photons fly into some angles. This would make no need for the integral in the expansion and Dirac deltas in the orthonormal conditions as in the continuous case). This is equivalent to ‘digitize’ the experimental result, i.e. group the electron screen into small areas and photon scattering angle into small cones. $ ^{40} $ This would simplify the math a little bit and lose no taste in physics.

(3)With the initial state and basis ready, we need to expand the initial state onto basis formed by the eigenstates.

This will be done in steps to account for every physical process in the

experiment.

First, the electron will pass the double slit wall before interacting with photons. In this step, the electron state will change, being projected into  $ |1\rangle $ and  $ |2\rangle $,  $ |1\rangle $,  $ |2\rangle $ represent states that electrons passing through hole 1 and 2. The photon state is not affected yet.

i.e. At the double slit, the initial state is expanded as:

 $$ |S>|\gamma_{l}>=...+<1|S>|1>|\gamma_{l}>+<2|S>|2>|\gamma_{l}>+... $$ 

In the above relation the ... means that the initial electron state  $ |S\rangle $ has probabilities hitting other places on the wall besides hole 1 and 2  $ (|1\rangle<1|+2\rangle<2|\neq I) $. But since those will not affect the result so I do not write them out.

Second, after passing hole 1 and 2, electron will interact with photon and scatter the photon into other directions and the electron state will also change accordingly due to the conservation of momentum. The above relation will further be expanded as:

 $$ \begin{aligned}\left|S>\right|\gamma_{_{l}}>&=...+<1\left|S>\right|1>\left|\gamma_{_{l}}>+<2\left|S>\right|2>\right|\gamma_{_{l}}>+...\\&=...+<1\left|S>a\right|\psi_{_{e}}>\left|\gamma_{\theta_{1}}>+<1\left|S>b\right|\psi_{_{e}}^{^{\prime}}>\right|\gamma_{\theta_{2}}>\\&\quad+<2\left|S>b\right|\psi_{_{e}}>\left|\gamma_{\theta_{1}}>+<2\left|S>a\right|\psi_{_{e}}^{^{\prime}}>\right|\gamma_{\theta_{2}}>+...\\ \end{aligned} $$ 

The  $ |\psi_e > |\gamma_\theta_1 > $ means the photon after scattering will fly towards direction of D1 detector and will be recorded by D1, and electrons state will change into a state that will keep the total momentum conserved; similar meaning for  $ |\psi_e' > |\gamma_\theta_2 > $. The  $ a $,  $ b $ are probability amplitude (expansion coefficient) of this process from the  $ |1>|\gamma_l> $

state.

The physical meaning of one term in the above relation, such as  $ <1|S>a|\psi_e>|\gamma_{\theta_i}> $ is this: From the initial state, the electron will has certain probability (amplitude) pass through hole 1 ( given by  $ <1|S> $), then has probability (amplitude) to scatter the photon from its original state into flying towards D1 and the electron state changed correspondingly (this probability amplitude is a). Similar arguments apply for the other terms.

Because of the symmetry of the setup, D1,D2 and hole 1 and hole 2 are symmetric with the central line. The probability (amplitude) for electron through hole1 and scatter the photon into D1 (or D2), would be same as the electron through hole 2 and scatter the photon into D2 (or D1), that's why you only have a, b in the above relation instead of four.

The ... in the relation means that electron can scatter the photon into other directions other than D1,D2, or even no scattering at all. That part of expansion is not written out explicitly because they are not related to the measurement (we only record the electron distribution when either D1 or D2 record a photon) and contribute nothing to the result.

Finally, Expand the electron state from  $ |\psi_e>, |\psi_e'> $ into basis of  $ |X_i> $ and only write out the relevant parts:

 $$ \begin{aligned}\left|S>\right|\gamma_{_{l}}>=...+<1\left|S>\right|1>|\gamma_{_{l}}>+<2\left|S>\right|2>|\gamma_{_{l}}>+...\\=&...+<1\left|S>a\right|\psi_{_{e}}>|\gamma_{_{\theta_{1}}}>+<1\left|S>b\right|\psi_{_{e}}^{^{\prime}}>|\gamma_{_{\theta_{2}}}>\\&+<2\left|S>b\right|\psi_{_{e}}>|\gamma_{_{\theta_{1}}}>+<2\left|S>a\right|\psi_{_{e}}^{^{\prime}}>|\gamma_{_{\theta_{2}}}>+...\\=&...+<1|S>a<X\left|\psi_{_{e}}>|X>\right|\gamma_{_{\theta_{1}}}>+<1\left|S>b<X\right|\psi_{_{e}}^{^{\prime}}>|X>|\gamma_{_{\theta_{2}}}>\\&+<2\left|S>b<X\right|\psi_{_{e}}>|X>|\gamma_{_{\theta_{1}}}>+<2\left|S>a<X\right|\psi_{_{e}}^{^{\prime}}>|X>|\gamma_{_{\theta_{2}}}>+...\\=&...+A\left|X>\right|\gamma_{_{\theta_{1}}}>+B\left|X>\right|\gamma_{_{\theta_{2}}}>+C\left|X>\right|\gamma_{_{\theta_{1}}}>+D\left|X>\right|\gamma_{_{\theta_{2}}}>+...\\=&...+(A+C)\left|X>\right|\gamma_{_{\theta_{1}}}>+(B+D)\left|X>\right|\gamma_{_{\theta_{2}}}>+...\\\end{aligned} $$ 

Now we have expanded the initial state into basis of the eigenstates of the observable, then the probabilities in the measurement can be derived from this with postulate 3.

(1) Only detect photon at D1 (i.e. no D2) and measure electron at X (the only projection here is  $ |X| > |\gamma_{\theta_1}| $). Then the probability of this detection result is:

 $$ P_{(X,\theta_{1})}=|\langle\gamma_{\theta_{1}}|<\boldsymbol{X}|\boldsymbol{S}>\mid\gamma_{l}>\mid^{2}=<\gamma_{l}|<\boldsymbol{S}|\hat{\boldsymbol{P}}_{X,\theta_{1}}|\boldsymbol{S}>\mid\gamma_{l}> $$ 

 $$ \hat{P}_{X,\theta_{1}}\equiv\left|X>\right|\gamma_{\theta_{1}}><\gamma_{\theta_{1}}\left|<X\right|\text{a projection operator} $$ 

Use the orthonormal conditions of the eigenstates:

 $$ <\gamma_{\theta_{j}}\mid\gamma_{\theta_{i}}>=\delta_{ij};<X_{j}\mid X_{i}>=\delta_{ij}^{41} $$ 

 $ P_{(X,\theta_1)} = |A + C|^2 $ equivalent to that in Feynman's. It is the probability amplitude summation and then squared.

If say $b=0$ (i.e. the electron passing hole2 will not scatter the photon to D1), then $C=0$. The result would be only $|A|^{2}$. This is

when the photon detected by D1 only comes from electron passing hole1, thus you only collect the electrons passing through hole1. The result will not have interference but a single hole diffraction. (Feynman, fig.3-4 (a))

<div style="text-align: center;"><img src="imgs/img_in_image_box_281_425_572_681.jpg" alt="Image" width="24%" /></div>


In case of $b=a$, or $C=A$. Then the interference pattern is observed.

(fig.3-4(b)) Here electrons passing hole 1 and 2 have equal probability scattering the photon into detector D1, so recording photons reveals nothing about which way the electron path is. (You do still have electron-photon interaction, this is reflected in the expansion that after the scattering, the electron state changes from |1>,|2> into |\psi_e>. The electron passing 1 or 2 will subject to the same perturbation and thus the phase perturbation cancels)

Similar results for the electron hitting X, and photon goes to D2:

$P_{(X,\theta_e)} = |\langle \gamma_\theta, | \langle X | S \rangle | \gamma_l \rangle^2 = |B + D|^2$

(2) What happens if both D1 and D2 are placed.

You recorded the electrons whenever either D1 or D2 register a photon count. As state above, this is a single electron experiment,

and each electron will only scatter one photon into one direction (the direction may not be even along D1 or D2, but those events are not recorded). So we are asking for the probability of event A (photon hits D1, electron hits X) OR event B (photon hits D2, electron hits X), while events A, B are mutually exclusive (i.e. If A happens, B will not). Indeed we have these exclusive events here, since if electron scatters a photon to D1, then D2 will detect noting, and vice versa. So the probability of either D1 or D2 records photon and electron at X is:

 $$ P_{(X,\theta_{1};or\;X,\theta_{2})}=P_{(X,\theta_{1})}+P_{(X,\theta_{2})}=\left|A+C\right|^{2}+\left|B+D\right|^{2} $$ 

This summation of probability does not come from quantum theory. It is the result of the probability of OR events (so called distinguishable events in Feynman's). In quantum, for individual event, you always sum the probability and then squared to get probability. We can get same results by:

 $$ \begin{aligned}P_{(X,\theta_{1}or X,\theta_{2})}=&\left|\begin{matrix}\boldsymbol{e}lectron at X\\\boldsymbol{P}hoton at\theta_{1}or\theta_{2}\end{matrix}\right|S>|\gamma_{l}>|^{2}\\=&<\gamma_{l}|<S\left|\begin{matrix}\left|\gamma_{\theta_{1}}>\right|X><X|\left<\gamma_{\theta_{1}}\right|\\+\\\left|\gamma_{\theta_{2}}>\right|X><X|\left<\gamma_{\theta_{2}}\right|\end{matrix}\right|S>|\gamma_{l}>\\=&\left|A+C\right|^{2}+\left|B+D\right|^{2}\end{aligned} $$ 

In Feynman’s book, he stated this result as a principle. That is if the final two events are distinguishable, their amplitude squared (the probability) should be added. You now see why it is, it is coming

from the postulates of Q.M and probability theory (i.e. probability

of OR events)

Actually the fact we detect photons at D1 or D2 is just to let us

select a part of electrons for observation. If the scattered photons

can only go into  $ \theta_{1} $ or  $ \theta_{2} $ two directions (of course an

idealization), then whether we detect the photon or not will not

affect the electron pattern, since it is the interaction between the

electron and photon that determines the interference pattern, the

interaction is always there independent of the detection of photon.

 $$ |X>|\gamma_{\theta_{1}}><\gamma_{\theta_{1}}|<X|+|X>|\gamma_{\theta_{2}}><\gamma_{\theta_{2}}|<X| $$ 

 $$ \begin{aligned}=\mid X>(\mid\gamma_{\theta_{1}}><\gamma_{\theta_{1}}\mid+\mid\gamma_{\theta_{2}}><\gamma_{\theta_{2}})\mid)<X\mid=\mid X>I<X\mid=\mid X><X\mid\end{aligned} $$ 

Here we assume only two directions for photon, so

 $ |\gamma_{\theta_{1}}><\gamma_{\theta_{1}}|+|\gamma_{\theta_{2}}><\gamma_{\theta_{2}}|=I $

In the more realistic model, where photon can take many directions (a continuous distribution in fact), we still ‘digitize’ them into many discrete directions for simplicity.

If we do not detect the photon and only measure the electron's distribution after its interaction with the photon, this is equivalent to place many 'virtual' photo-detectors at all possible angles, and record the electron distribution whenever one of the 'virtual' photo-detectors register a count. Here we arrange the experimental condition so that whenever an electron passes the light zone, one and only one photon will be deflected. We neglect other processes

between photon-electron interactions, such as no interaction at all (no photon deflected); an electron can scatter multiple photons during the passage, etc.

The expansion of the initial state will be:

 $$ |S>|\gamma_{l}>\rightarrow\sum_{i}(a_{i1}+a_{i2})|\gamma_{\theta_{i}}>|X> $$ 

$a_{i1}$ is the probability amplitude of electron through hole 1 scattering the photon into direction $\theta_{i}$; $a_{i2}$ is the probability amplitude of electron through hole 2 scattering the photon into direction $\theta_{i}$.

The detection of electron corresponds to projection along all  $ |\gamma_{\theta_i}>|X> $ states, i.e.

 $$ \hat{P}_{X,all\theta}=\mid X><X\mid=\mid X>(\sum_{i}\mid\gamma_{\theta_{i}}><\gamma_{\theta_{i}}\mid)<X\mid $$ 

And the resulting probability of electron at X no matter where the photon goes is:

 $$ P_{X,all\theta}=<\gamma_{l}\left|<S\mid\hat{P}_{X,all\theta}\mid S>\right|\gamma_{l}>=\sum_{i}\left|a_{i1}+a_{i2}\right|^{2} $$ 

This is a long example. Once you understand this, there will be no difficulty for you to understand Feynman's example in his chap.3, such as neutron scattering by a crystal in section 3-3. (Please read it yourself)

## Example3: Stern-Gerlach Experiment and Electron Spin

## (1) Magnetic Dipole and Motion in Magnetic Field (Classical)

Here is the review of what you probabl $ \underline{\text{u know about the motion of}} $ magnetic dipole in a B field. The key is to show the relation between angular momentum and magnetic dipole.

<div style="text-align: center;"><img src="imgs/img_in_image_box_212_355_349_430.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_617_335_704_481.jpg" alt="Image" width="7%" /></div>


We know that the current loop will generate the magnetic dipole and its formular is:

 $$ \vec{\mu}=I\hat{A}\hat{n} $$ 

Where I is current (the arrow in the figure shows the current direction, while electrons motion would be reversed), A is area of the loop and n is normal direction of the area (as illustrated by figure left above). In the case of electron motion around nuclei, it also possesses a current and thus a magnetic dipole, imaging electron moves in a circular loop with radius r: Its current will be:

 $ I = -e \frac{v}{2\pi r} $, (minus sign of course due to negative charge for electron)

Then the m-dipole will be:

 $$ \vec{\mu}=-\frac{e v}{2\pi r}\pi r^{2}\hat{n}=-\frac{e}{2m_{e}}m_{e}v r\hat{n}=-\frac{e}{2m_{e}}\vec{L} $$ 

L is the angular momentum of the motion.

So we see that the m-dipole is proportional to the angular momentum, the proportion constant is called gyromagnetic coefficient, usually shortened as gyro, it is defined as:

 $ g_L = -\frac{e}{2m_e} $, then:

 $$ \vec{\mu}=g_{L}\vec{L} $$ 

Noticed due to the negative charge, the dipole direction and L direction is antiparallel for electron.

When such dipole is placed in a magnetic field B (as illustrated in the figure right above), it will experience a torque, which is:

 $$ \vec{\tau}=\vec{\mu}\times\vec{B} $$ 

Then the angular momentum change can be calculated with the formula:

 $$ \frac{d\vec{L}}{d t}=\vec{\tau}=\vec{\mu}\times\vec{B}\quad\mathrm{o r~i n s e r t~(11-25):} $$ 

 $$ \frac{d\vec{\mu}}{d t}=\vec{\mu}\times g\vec{B} $$ 

Recall what we learned in classical mechanics for any vector, if:

 $$ \frac{d\vec{A}}{dt}=\vec{\omega}\times\vec{A} $$ 

The vector A is pressing with a agular frequency.

So the (11-26) shows us the m-dipole presseses around B with certain frequency, rewrite it as:

 $$ \frac{d\vec{\mu}}{d t}=\vec{\mu}\times g\vec{B}=-g\vec{B}\times\vec{\mu}=\vec{\omega}\times\vec{\mu} $$ 

 $$ \vec{\omega}=-g\vec{B}=\frac{e}{2m_{e}}\vec{B} $$ 

This shows the in the figure right above, the m-dipole will presses around B with this frequency, and this frequency is called Larmour frequency.

Above is purely classical treatment, our next question is how the quantum treat magnetic dipole interaction with B field, i.e. what is the observable related to the dipole?, what is the interaction energy of m-dipole with B field? And also what is the quantum treatment of the field?

Below is a brief discussion on the above questions:

First the field here will be treated as parameter, just the quantity as in classical field theory, the quantization of the field in QED will not be introduced here. This is of course an approximation, but works in cases where interaction between atoms/molecules with many photons. The magnetics dipole is related to the angular momentum, and we apply the quantization rules (as discussed in supplement a) to make it (the observable or operator) as:

 $$ \mu=g_{L}L $$ 

Here the form is same as (11-25) but here the meanings are different, the L is the angular momentum operator in quantum mechanics. The detailed quantum treatment of angular momentum (how to express L's operator and find its eigenvalue and eigenstate) will not be treated here. The key point is only to show the relation between the magnetic dipole is related to angular momentum observable.

Besides the angular momentum related to the orbital motion of electron (or any particle), there is another angular momentum which does not has classical analogy, it is called spin! Uhlenbeck and Goudsmit were the

first to propose the spin in order to explain the extra spectra lines in atomic spectroscopy (we now know these are called fine structures due to the spin-orbit coupling), and Dirac's relativistic equation contains them. The existence of unclassical spin have been again and again proved with experimental observation and I shall discuss the famous Stern-Gerlach experiment below. It not only shows the existence of spin, and spin of electron actually provides a very nice and simple system (so called two-level system) to works with and offers a excellent example to illustrate the postualtes we discussed, so now let's take a look.

## (2) Electron Spin and Stern-Gerlach Experiment

<div style="text-align: center;"><img src="imgs/img_in_image_box_250_812_913_1369.jpg" alt="Image" width="55%" /></div>


## FIGURE 1

<div style="text-align: center;">Schematic drawing of the Stern-Gerlach experiment. In figure a is shown the trajectory of a silver atom emitted from the high-temperature furnace E. This atom is deflected by the gradient of the magnetic field created by the electromagnet A and then condenses at N on plate P.</div>


<div style="text-align: center;">Figure b shows a cross section in the xOz plane of the electromagnet A; the lines of force of the magnetic field are shown in dashed lines. Bz has been assumed to be positive and  $ \partial B_z/\partial z $, negative. Consequently, the trajectory of figure a corresponds to a negative component  $ M_z $ of the magnetic moment, that is, to a positive component of  $ S_z $ ( $ \gamma $ is negative for a silver atom).</div>


The above figure (taken from Cohen-Tannoudji's book, vol.1 p388) shows a typical setup of Stern-Gerlach experiment. The electrons $ ^{42} $ will pass a non-uniform magnetic field (here in the figure, the B field has large gradient along the Z direction, which is arbitrarily chosen in the lab, interact with the magnetic field and then detected by the electron detectors at the screen P.

The interaction between the electron and the magnetic field is given by (Below is basically classical argument, and quantum will kick in by introducing spin as angular momentum and its eigenvalues determined by quantum mechanics):

 $$ W=-\mu\bullet B $$ 

Where W is the interaction energy,  $ \mu $ is the magnetic moment of the electron and B is the magnetic field. We have seen the  $ \mu $ is related to the angular momentum of the particle, but now the angular momentum is not orbital (we purposely set electron does not have L, see footnote above), it is the spin instead:

 $$ \vec{\mu}=g_{s}\vec{S} $$ 

 $$ (11-30)^{43} $$ 

where  $ \vec{S} $ is the spin and  $ g_{s} $ is a constant called gyromagnetic ratio for

spin, it is not same as g_{L}, but very closely twice of it, i.e.

 $ g_{s} \approx 2g_{L} $

The reason for this difference is relativistic in origin, it is related to the Thomas precession. Here we need to just accept this difference and this relation was first introduced by Ulrenbeck and Goudsmit purely from experimental result.

Thus the force experienced by the electron with certain angular momentum in the B field is:

 $$ F=\nabla(\mu\bullet B)=\nabla(\mu_{z}B_{z})=\mu_{z}\nabla B_{z} $$ 

The reason that I only consider the gradient of  $ \mu_{z}B_{z} $ and neglect the x, y components is two folds:  $ B_{z} $ is the largest in the apparatus shown in the above figure; and due to the precession of the electron motion in the B field (a rotation along the Z direction) would make the average contribution of the  $ \mu_{x}, \mu_{y} $ to zero.

So the force exerted on the electron is proportional to the z-component of angular momentum. Electrons with different  $ \mu_{z} $ (or  $ S_{z} $) will experience different force while travelling through the B field, and will split and hit different locations on the detection screen. So by measuring the electron's distribution, you can learn the electron's angular momentum along the z-direction (projection of the total angular momentum along one direction, you can of course measure the x, y components just by rotating the B field and the results would be same as the z case because of the space is

isotropic). For the electrons (or atoms) coming out of the furnace, its

angular momentum’s direction is random in space, so the projection along

z-direction would be continuously, i.e.  $ S_{z} = S \cos \theta, (0 \leq \theta \leq \pi) $ from the

classical picture. So the distribution on the detection screen would also be

continuous. The results of Stern-Gerlach (SG) experiment are totally

surprising. The electrons are concentrated in two spots with equal

probability on the screen. (see figure below)

<div style="text-align: center;"><img src="imgs/img_in_image_box_226_593_389_955.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;">FIGURE 3</div>


<div style="text-align: center;">Spots observed on the plate $P$ in the Stern-Gerlach experiment. The magnetic moments $\mathbf{M}$ of the atoms emitted from the furnace $E$ are distributed randomly in all directions of space, so classical mechanics predicts that a measurement of $\mathbf{M}_{z}$ can yield with equal probability all values included between $+|\mathbf{M}|$ and $-|\mathbf{M}|$. One should therefore observe only one spot (dashed lines in the figure). In reality, the result of the experiment is completely different: two spots, centered at $N_{1}$ and $N_{2}$, are observed. This means that a measurement of $\mathbf{M}_{z}$ can yield only two possible results (quantization of the measurement result).</div>


The SG’s result demonstrated not only the electron has spin but more, it also shows what we call the quantization of the projection of angular moment along certain direction. In the microscopic world, quantum theory will show not only the angular momentum is quantized, but also its directional projection!⁴⁴ To understand the quantization of angular momentum and its directional components, you have to study the quantum mechanical treatment on angular momentum which is not my

intention here. So I will simply give out the Q.M result of angular momentum of electron below.

For the electrons, its angular momentum has two parts (any fundamental particles do). For the bound electrons inside an atom, it has orbital angular momentum due to motion around the nuclei. Besides this, it also has an intrinsic angular momentum which is called spin. For the free electrons or electrons-in-atom residing in ‘orbit’ with zero total angular momentum, only detectable angular momentum is due to spin completely (as in the SG case). The spin of the electron has no classical analogy (no way to calculate the electron spin with classical model), though sometimes a classical picture helps to ‘visualize’ spin (earth revolves around sun which has orbit angular momentum, it also spins around north-south pole which gives self-rotation angular momentum). What is the cause of fundamental particle’s spin? Is it due to some internal structures that we do not know yet? I just cannot answer. What quantum mechanics can answer is spin is angular momentum. For the electron, the quantum number for spin is 1/2 (quantization of angular momentum), which means the size of the spin is  $ \sqrt{\frac{1}{2}(\frac{1}{2}+1)\hbar} $, its component along any direction can only take possible value 1/2  $ \hbar $ and -1/2  $ \hbar $ (quantization of direction projection), i.e. For electron spin:

 $$ \begin{aligned}&\left|S\right|=\sqrt{\frac{1}{2}(\frac{1}{2}+1)\hbar}\\ &S_{z}=\frac{1}{2}\hbar or-\frac{1}{2}\hbar\\ \end{aligned} $$ 

More generally, the quantum mechanics shows for angular momentum represented by j:

 $$ \begin{aligned}&|j|=\sqrt{j(j+1)}\hbar\\&j_{z}=m_{z}\hbar\\ \end{aligned} $$ 

Where j is called angular momentum quantum number, it can only take intergers (1, 2, 3...) or half intergers (1/2, 3/2...); the  $ m_{z} $ is the direction quantization number; also called magnetic quantum number, since it plays roles when interaction with B field as we shall see. The  $ m_{z} $ is restricted within a given j,  $ m_{z} $ can only take j, j-1,...-j, total of 2j+1 value. If you accept this quantum result, you see (11-32) for spin 1/2 (angular momentum quantum number is 1/2) certainly fits in. The relation (11-33) can be rigorously derived from quantum mechanics and here I just throw out these to you.

Since the SG essentially measures the z-component of the electron spin. It has only two possible values (eigenvalues of the observable) and the two corresponding eigenstates (Postulate 3 of QM). Electron’s spin is also called spin-1/2 system. It belongs to a general class of two-level systems whose treatment is the simplest in Q.M (only in a generalized 2-Dimensional space). The focus here is to show you the Q.M treatment for such two-level system, illustrating the postulates and mathematical

manipulation.

First let me summarize what the observations of SG type experiments tell us:

1) Electron is only located at two places. The two and only two possible value means the observable correspond to the measurement of the  $ S_{z} $ only has two eigenvalues, and two distinct eigenstates associated with them. (electrons hitting above or below)

2) I shall use Dirac’s notation  $ |+Z> $ and  $ |-Z> $ to represent the two eigenstates of the Sz measurement that correspond to the  $ 1/2\hbar $ and  $ -1/2\hbar $. In math, it is just:  $ S_z\left|+z\right|=\frac{1}{2}\hbar\left|+z\right| $,  $ S_z\left|-z\right|=-\frac{1}{2}\hbar\left|-z\right| $. The  $ |+z\rangle $ and  $ |-z\rangle $ are chosen to be orthonormal, i.e.  $ <+z|+z\rangle=1 $ and  $ <-z|+z\rangle=0 $. They also form a complete basis in a 2-D space, i.e. closure relation  $ |+z\rangle\langle+z|+|-z\rangle\langle-z|=\mathrm{I} $ (the identity).

3) What happened for the x or y components of the spin? The results would be same if we use  $ |+x\rangle $,  $ |-x\rangle $ or  $ |+y\rangle $,  $ |-y\rangle $ as basis for the Sx or Sy measurement respectively. (this is expected from isotropic symmetry of the problem)

4) Now let's consider a series of SG experiment by let electrons passing a series of B field aligned at different angles. First consider the case as two B field all along the z direction:

<div style="text-align: center;"><img src="imgs/img_in_image_box_238_169_631_277.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">FIGURE 7</div>


<div style="text-align: center;">The first apparatus (a "source" composed of the furnace  $ E_1 $ and the slit  $ F_1 $, plus a "polarizer" formed by the magnet  $ A_1 $ and the pierced plate  $ P_1 $) prepares the atoms in the state  $ |+\rangle $. The second one (an "analyzer" composed of the magnet  $ A_2 $ and the plate  $ P_2 $) measures the component  $ S_2 $. The result obtained is certain  $ (+\hbar/2) $.</div>


In this case, the first  $ B_1 $ prepare the electron into  $ |+z> $ state (postulate

III, measurement cause the collapse of the input state into the

eigenstates). If we let the electron at the  $ |+z> $ state pass  $ B_2 $ (also along

the z), of course we will always get  $ +1/2 $ in the final measurement.

(This is really analogical to the light passing a series of polarizers).

5) Same figure above, now let's put the second B field to another direction, say along the x (or y) direction. The results would show that the  $ |+z> $ state out of the first SG apparatus, after passing the B2, it will hit two positions with equal probability along the x (or y) direction. This shows that the  $ |+z> $ state is not an eigenstate for the  $ S_x $ (or  $ S_y $) measurement. (There is no common state which is eigenstate for both  $ S_z $ and  $ S_x $; another saying of the same is that the  $ S_z $ and  $ S_x $ are not compatible and their operators are not commute). The  $ S_z $ measurement on a  $ |+z> $ state is:

 $ S_{x} \mid +z \rightarrow 50\% $ probability collaps to  $ |+x> $ and  $ 50\% $ into  $ |-x> $ (same for y or any pair combination of x-y-z)

So for the measurement of spin-1/2 along certain direction, it can be treated in a 2-D space spanned by the eigenstates of the spin-operators.

 $ |+z>, |-z> $ is a suitable basis, so does  $ |+x>, |-x> $ pair and etc. You can imagine many other basis formed by eigenstates of spins measured along different directions. (This is really like the cases in the polarization state of light)

The question now is from the above experimental results, how we construct a description in math? All the operators (S_z, S_x or S_y) and states (|+z>, |-z>, |+x>...) are abstract Dirac notations. The appearance of their mathematical expressions depends on the choice of basis.

I shall work out in the following by using the ‘stupid’ method (no math tricks) to show you the detailed forms (in matrix) of the expressions of the operator and basis. Knowing this would enable you to work out the quantum predictions given any input state. (This is very much like the polarization state of light. Knowing the basis and matrix forms of optical elements, given the input, you can work out the polarization state of the output)

I will first choose a basis.  $ |+z> $ and  $ |-z> $. They form an orthonormal basis set in this 2-D space. Then I will work out the expressions of  $ S_z $,  $ S_x $,  $ S_y $ and their eigenstates on this basis.

1. The simple case for  $ S_z $ and  $ |+z\rangle $,  $ |-z\rangle $:

The matrix forms for them are obvious.

 $$ \left|+z\right\rangle=\begin{bmatrix}1\\ 0\end{bmatrix},\left|-z\right\rangle=\begin{bmatrix}0\\ 1\end{bmatrix} $$ 

 $$ S_{z}=\frac{\hbar}{2}\binom{1\ 0}{0\ -1} $$ 

If you do not understand how I get  $ S_{z} $ expression. Try the systematic method I discussed in the class to get expression of operators in certain basis:

 $$ S_{z}\mid+z>=\frac{\hbar}{2}\mid+z>=\frac{\hbar}{2}\begin{bmatrix}1\\ 0\end{bmatrix}\quad\leftarrow first column in 2x2S_{z} matrix $$ 

a.

 $$ S_{z}\mid-z>=-{\frac{\hbar}{2}}\mid-z>={\frac{\hbar}{2}}{\left[\begin{array}{l}0\\ -1\end{array}\right]}\leftarrow\mathrm{s e c o n d~c o l u m n~i n~}2\mathrm{x}2\mathrm{~S}_{z}\mathrm{~m a t r i x} $$ 

b.  $ <+z|S_z|+z>=\hbar/2 $  $ \leftarrow $ gives the  $ S_{11} $ matrix element ...

c.  $  S_z = \frac{\hbar}{2} | +z \rangle + z \langle +z | +(-\frac{\hbar}{2}) | -z \rangle \langle -z |  $ the rest is simple matrix multiplication.

2. How about the  $ S_x $ and  $ |+x\rangle $,  $ |-x\rangle $ expression in basis of  $ |+z\rangle $ and  $ |-z\rangle $?

In  $ |+x\rangle $,  $ |-x\rangle $ basis, the answer would be simple, same as above

actually. However, in  $ |+z\rangle $,  $ |-z\rangle $ basis, their forms are not obvious (at

least to me). The problem is basically a transform of basis! As we

discussed in the polarization case, the key is to find the relation

between the basis, i.e. the expression of  $ |+x\rangle $,  $ |-x\rangle $ in terms of  $ |+z\rangle $ and

 $ |-z\rangle $, then everything else would be straightforward. We need to find:

 $$ \begin{aligned}&|+x>=c_{++}\mid+z>+c_{+-}\mid-z>\\&|-x>=c_{-+}\mid+z>+c_{--}\mid-z>\end{aligned} $$ 

The 4 coefficients need to be determined. Since each c is a complex number in general, so there are actually 8 unknowns in total.  $ c_{++} = |c_{++}| e^{i\theta_{+}} \ldots $ both the module and the phase need to be determined. However, we know that for a given state, there is an arbitrary total

phase factor which would have no physical significance, this would reduce the 8 unknowns to 6.

 $$ \left|+x\right\rangle=\left|c_{++}\right|e^{i\theta_{++}}\left|+z\right\rangle+\left|c_{+-}\right|e^{i\theta_{+-}}\left|-z\right\rangle=e^{i\theta_{++}}\left(\left|c_{++}\right|\left|+z\right\rangle+\left|c_{+-}\right|e^{i(\theta_{+-}-\theta_{++})}\left|-z\right\rangle\right) $$ 

We can neglect the common phase factor  $ e^{i\theta_{+}} $ (by set the phase angle 0), and let  $ \theta_{+} \equiv \theta_{+} - \theta_{++} $; similar to the  $ |-x> $ case. So 6 unknowns of which 4 are modules and 2 are phase angles.

We shall use orthonormal conditions of the  $ |+x\rangle, |-x\rangle $ (similar for  $ y $'s) and the experimental results of the SG experiment (the one list in 5 above) to determine them.

 $$ \begin{aligned}&<+x\mid+x>=\mid c_{++}\mid^{2}+\mid c_{+-}\mid^{2}=1\\&<-x\mid-x>=\mid c_{-+}\mid^{2}+\mid c_{--}\mid^{2}=1\\&<-x\mid+x>=\mid c_{++}\mid\mid c_{-+}\mid+\mid c_{+-}\mid\mid c_{--}\mid e^{i(\theta_{+}-\theta_{-})}=0\\ \end{aligned} $$ 

From the observation 5 above, we learned that if the input state is  $ |+x\rangle $ (or  $ |-x\rangle $), put it through  $ S_z $ measurement, there will be 1/2 probability ends in  $ |+z\rangle $ and 1/2 probability ends in  $ |-z\rangle $, this means (postulate 3):

 $$ \left|<+z\right|+x>\left|^{2}\right|=|c_{++}|^{2}=\frac{1}{2},\quad\left|c_{++}\right|=\frac{\sqrt{2}}{2} $$ 

Similarly  $ |c_{+}|=|c_{-}|=|c_{-}|=\frac{\sqrt{2}}{2} $ too. Put this in the orthogonal

relation above:

 $$ \begin{aligned}&<-x\mid+x>=\mid c_{++}\mid\mid c_{-+}\mid+\mid c_{+-}\mid\mid c_{--}\mid e^{i(\theta_{+}-\theta_{-})}=0\\&\frac{1}{2}+\frac{1}{2}e^{i(\theta_{+}-\theta_{-})}=0\\&then\theta_{+}-\theta_{-}=\pi\\ \end{aligned} $$ 

Put all these into expressions for  $ |+x\rangle, |-x\rangle $

 $$ \left|+x\right\rangle=\frac{\sqrt{2}}{2}\left|+z\right\rangle+\frac{\sqrt{2}}{2}e^{i\theta_{+}}\left|-z\right\rangle $$ 

 $$ \left|-x\right|=\frac{\sqrt{2}}{2}\left|+z\right|-\frac{\sqrt{2}}{2}e^{i\theta_{+}}\left|-z\right> $$ 

Only one phase angle is undetermined now.

All the above argument would be applied equally well to the  $ |+y\rangle, |-y\rangle $ cases with  $ c' $ and  $ \theta' $ as coefficients, and we shall have the expression for  $ |+y\rangle, |-y\rangle $:

 $$ \left|+y\right\rangle=\frac{\sqrt{2}}{2}\left|+z\right\rangle+\frac{\sqrt{2}}{2}e^{i\theta_{+}^{-}}\left|-z\right\rangle $$ 

 $$ \left|-y\right\rangle=\frac{\sqrt{2}}{2}\left|+z\right\rangle-\frac{\sqrt{2}}{2}e^{i\theta_{+}^{^{\prime}}}\left|-z\right\rangle $$ 

There is one more experiment result we have not used, the relation between the x and y's. If the input state is  $ |+x> $ (or  $ |-x> $), passing through a  $ S_y $ measurement, you would get same results as the  $ S_z $ case. i.e.

 $$ \begin{aligned}&|<+y\mid+x>|^{2}=\mid\frac{1}{2}+\frac{1}{2}e^{i(\theta_{+}-\theta_{+}^{\prime})}\mid^{2}=\frac{1}{2}+\frac{1}{2}\cos(\theta_{+}-\theta_{+}^{\prime})=\frac{1}{2}\\ &so\theta_{+}-\theta_{+}^{\prime}=-\frac{\pi}{2}\\ \end{aligned} $$ 

(other relations between x and y would give same result) Still only one angle is not determined ( $ \theta_{+} $). Why there is this ‘free’ variable? Well, think the experiment setup. With the Z direction fixed, there are obvious many ways to choose X-Y directions. The X-Y can be rotated around the Z direction. So it is this arbitrary choice of X (with X fixed, then the Y will be fixed too) will give rise to the free variable. I shall

choose the X direction which would make  $ \theta_{+}=0 $. In such convention,

the final expression for  $ |+x\rangle $,  $ |-x\rangle $,  $ |+y\rangle $,  $ |-y\rangle $ are:

 $$ \begin{aligned}&|+x\geq\frac{\sqrt{2}}{2}|+z>+\frac{\sqrt{2}}{2}|-z>\\&|-x\geq\frac{\sqrt{2}}{2}|+z>-\frac{\sqrt{2}}{2}|-z>\\&|+y\geq\frac{\sqrt{2}}{2}|+z>+\frac{\sqrt{2}}{2}i|-z>\\&|-y\geq\frac{\sqrt{2}}{2}|+z>-\frac{\sqrt{2}}{2}i|-z>\end{aligned} $$ 

(so  $ |+z\rangle $,  $ |-z\rangle $ is like H-V basis;  $ |+x\rangle $,  $ |-x\rangle $ is like 45—(-45) basis;  $ |+y\rangle $,  $ |-y\rangle $ is like circular basis in polarization)

3. With the knowledge of basis vectors, determination of  $ S_x $,  $ S_y $ in the  $ |+z\rangle $,  $ |-z\rangle $ basis would be easy. (I listed 3 ways to find matrix form above, you may use either)

 $ S_x = \frac{\hbar}{2} \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix} $; and  $ S_y = \frac{\hbar}{2} \begin{pmatrix} 0 & -i \\ i & 0 \end{pmatrix} $

So knowing the input state  $ |\varphi \geq a| + z > +b| - z > $, the measurement results of  $ S_{z}, S_{x} $ and  $ S_{y} $ can be easily predicted using the postulate 3 of Q.M. (the probability of detected eigenvalues)

Actually the  $ S_{x}, S_{y}, S_{z} $ and the identity matrix I would form a complete basis for any measurement in 2-D space. (The matrix has 4 elements, so it is a 4-dimensional space, and the 4 matrix above form a basis)

<div style="text-align: center;"><img src="imgs/img_in_image_box_249_153_443_380.jpg" alt="Image" width="16%" /></div>


For example, if the magnetic field is along the u direction as shown above, the measurement would correspond to  $ S_{u} $. The matrix expression for it under certain basis for  $ S_{u} $ can be easily worked out with  $ S_{x} $,  $ S_{y} $ and  $ S_{z} $.

 $$ S_{u}=\sin\theta\cos\varphi(S_{x})+\sin\theta\sin\varphi(S_{y})e+\cos\theta(S_{z})=\frac{\hbar}{2}\left(\begin{aligned}&\cos\theta&\sin\theta\mathrm{e}^{-i\varphi}\\&\sin\theta e^{i\varphi}&-\cos\theta\end{aligned}\right) $$ 

With this you can work out the results of a given state subjected to the  $ S_{u} $ measurement $ ^{45} $.

Example4: Expression of state vector in position and momentum representation and particle in free space.

This is the example that will illustrate what we had talked about the postulates of QM. I will use the postulates to solve quantitatively a simple system: Particle in free space. (This is a typical example in standard QM course. I tried to avoid spoiling your fun when you take the

QM course, but I cannot help showing you this though you probably will learn it again next semester because not only this will act as concrete an example for the postulates, but also showing you what we have learned previously about waves will be useful in QM)

I shall talk about following subjects in this example:

(1) Position (x) representation of state vector---wave function  $ \psi(x) $

(2)Momentum operator and momentum (p) representation of state vector

(3)Particle in free space

The first 2 topics are about how we describe the state of our system; the last is a simple case of state evolution. (A review on my supplementary on matrix representation of vector and Dirac notation would be helpful)

## (1) Position (x) representation

The state vector  $ |\psi\rangle $ will be expressed as combination (projection) of eigenstates of position  $ |x\rangle $, i.e. if the particle is in  $ |x\rangle $ we know its position is x. If I use  $ \hat{X} $ as symbol for position observable:

 $$ \hat{X}\mid x>=x\mid x> $$ 

The  $ |x> $ form a complete orthonormal basis:

 $ \begin{array}{l} <x^{\prime} | x \> = \delta(x - x^{\prime}) \quad (11-39) $ (orthonormal condition for continuous basis)

 $$ \int\left|x><x\right|dx=I $$ 

(11-40) (completeness of basis)

For any state |ψ > to be expressed in this |x> basis:

 $$ \left|\psi\right\rangle=I\left|\psi\right\rangle=\int\left|x^{\prime}\right\rangle\left\langle x^{\prime}\right|\psi\left\langle d x^{\prime}\right\rangle=\int\left\langle x^{\prime}\right|\psi\left\langle\right|x^{\prime}\left\langle d x^{\prime}\right| $$ 

The expansion coefficient is a function of x for this continuous basis:

 $$ <x\mid\psi>=\psi(x) $$ 

 $ \psi(x) $ is usually called wave function and we see that it is expression of state vector onto x basis.

The probability density of finding particle at x is (according to postulate 3):

 $$ \left|<x\mid\psi>|^{2}=|\psi(x)|^{2}=<\psi\mid x><x\mid\psi>={\psi}^{*}(x)\psi(x)\right. $$ 

The proper state  $ |\psi> $ need to be normalized:

 $$ <\psi\mid\psi>=<\psi\mid I\mid\psi>=\int<\psi\mid x><x\mid\psi>dx=\int\psi^{*}\psi dx=1 $$ 

Dot product between state vectors is:

 $$ <\varphi\mid\psi>=\int\varphi^{*}(x)\psi(x)dx $$ 

If we act  $ \hat{X} $ on  $ |\psi> $, the state may change (unless the  $ |\psi> $ is one of eigenstates  $ |x> $):

 $$ \hat{X}\mid\psi>=\mid\psi^{\prime}> $$ 

This is not much helpful just a math expression of what I stated above.

The point is the output  $ |\psi'\rangle $ and input  $ |\psi\rangle $ are related:

 $$ \begin{aligned}&|\psi^{\prime}>={\hat{X}}\mid\psi>=\int{\hat{X}}\mid x><x\mid\psi>d x=\int x\psi(x)\mid x>d x\\ &\psi^{\prime}(x)=<x\mid\psi^{\prime}>=\int x^{\prime}\psi(x^{\prime})<x\mid x^{\prime}>d x^{\prime}=\int x^{\prime}\psi(x^{\prime})\delta(x-x^{\prime})d x^{\prime}=x\psi(x)\\ \end{aligned} $$ 

In short I have shown that:

 $$ <x\mid\hat{X}\mid\psi>=x\psi(x) $$ 

This is the expression of position operator acting on any state in x basis.

If the state is not eigenstate of position operator, then measurement of position will not give a definite value (position), with probability amplitude  $ \psi(x) $, the average of the position measurement is given by the expectation value of  $ \hat{X} $, and we can use what we learned above to give an practical formula for the calculation of this expectation value with wave function (calculate the value in the basis of  $ |x\rangle $)

 $$ <X>=<\psi\mid\hat{X}\mid\psi>=\int<\psi\mid x><x\mid\hat{X}\mid\psi>dx=\int\psi^{*}x\psi dx $$ 

The reason we go through this lengthy math is to show you that we can translate the abstract vector representation into familiar functional form for calculation.

In summary, for an arbitrary state vector  $ |\psi\rangle $, knowing its expression in basis  $ |x\rangle $ is knowing the wave function  $ \psi(x)=\langle x|\psi\rangle $. The wave function is just the probability amplitude of finding x from postulate 3. The actions of X operator and expectation values can all be expressed in the  $ |x\rangle $ basis, and the expressions are particularly simple. There is no surprise since we are using eigenbasis of the X operator.

However we may further ask what happened if we are handling not only the position operator but other operators corresponding to other physical interaction and measurement? It is going to be interesting and important that we can work out other operators using |x> basis. This would allow us by knowing the  $ \psi(x) $, we can predict the measurement result of other operation (such as energy, momentum etc.) and compute the average

value (expectation value) etc.

Indeed we can do that as I will show you next with momentum operator, but first a general discussion may help. For a physical observable represented by operator A, is eigenvalues and eigenvectors are $a$ and $|a>.$ The measurement of A given the state $|\psi>\$ will have probability amplitude: $|a|\psi>, since we know the wave function $\psi(x)$, we’d like to evaluate the probability amplitude of A in $|x>\$ basis:

 $$ <a\mid\psi>=\int<a\mid x><x\mid\psi>dx=\int<a\mid x>\psi(x)dx=\int<x\mid a>^{*}\psi(x)dx=\int a^{*}\psi dx $$ 

$a^{*}$ is the conjugate of wave function of eigenvector $|a>.$ The above expression can also be seen as an expression for the matrix product, $I$ mean $|a|$ is a row vector with $a^{*}$ as its element (coefficients) while $| \psi >$ is a column vector with $\psi(x)$ as its elements.

So we see that the key is the  $ <a|x> $, the relation between basis vectors, which is no surprise at all from our discussion on polarization of light and spin 1/2 particles in Stern-Gerlach experiment. To work with operator A, the natural choice of basis would be its eigenbasis (eigenvector as base vectors and indeed most of time we shall choose such basis), but since I'd like to show how to work in  $ |x> $ basis, I need to do base transformation, and the key to base transformation is the relation between the base vectors.

Above shows that knowing  $ <a|x> $, we can compute probability amplitude of getting value a in measurement. The expression of A acting

on  $ |\psi> $ in  $ |x> $ basis can also be determined:

 $$ <x\mid\hat{A}\mid\psi>=\int<x\mid\hat{A}\mid x^{\prime}><x^{\prime}\mid\psi>dx^{\prime} $$ 

(above can also be seen as matrix product, similar to  $ d_i = \sum_{j} A_{ij} c_j $)

<x| $ \widehat{A} $|x' > is the matrix element in the |x> basis (similar to the A_{ij} in the discrete basis, but here we have a continuous basis), it can be evaluated knowing the <a|x>:

 $$ <x\mid\widehat{A}\mid x^{\prime}>=\sum_{i,j}<x\mid a_{i}><a_{i}\mid\widehat{A}\mid a_{j}><a_{j}\mid x^{\prime}> $$ 

The matrix form of A in its eigenbasis is diagonal with eigenvalues along diagonal, and relations  $ \langle a | x \rangle $ would certainly allow us to get A's matrix form in  $ |x\rangle $ basis (of course above relation is just the similarity transform of matrices)

(2) Momentum operator and momentum (p) representation

The momentum operator and its eigenstate can be expressed as:

 $$ \hat{p}\mid p>=p\mid p>\quad(11-47) $$ 

This is just a restatement of definition of eigenstate. The important (and interesting) point is what this representation related to that of position? If we know the position representation, can we find out the momentum representation and vice versa? If not the QM would be hopelessly complicated and almost useless, since we need to express the abstract state vector onto some basis, and if no relations between basis, then knowing the expression in one basis cannot allow us to

know its expression in other basis and things would be complicated. However as we have seen in the Stern-Gerlach and spin 1/2 case, we do have relations between basis: there knowing expression in  $ |z> $ would allow us to write out the expression in  $ |x> $ or  $ |y> $ basis (The key is the relation between base vectors). I will show you that we have a similar case here too, knowing the x representation, we can find out the momentum representation of any state vector

To do above and as discussed for the general case in the last section, the key is relation between  $ \langle x|p\rangle $. However my treatment here followed a historical approach by first showing the position expression of momentum operator  $ \hat{p} $, and then form there to find out what is the form of  $ \langle x|p\rangle $. This approach has the advantage that using correspondence principle to show that the operator we defined as momentum do correspond to the canonical momentum in classical physics. So first a very important relation of the positions expression of momentum operator (we do keep in mind that staring from here, we need to find  $ \langle x|p\rangle $ and then the transform between  $ |x\rangle $,  $ |p\rangle $ representation would be clear and it will turn out to be Fourier transform)

 $$ <x\mid\hat{p}\mid\psi>=-i\hbar\frac{d}{d x}(<x\mid\psi>)=-i\hbar\frac{d\psi(x)}{d x} $$ 

I do not pretend that the above relation is obvious, it isn't at all! It tells you that the action of some operator on any state, when expressed in

the position basis, the effect is equivalent to a space differentiation and  $ -ih $ as some sort of proportional constant. You may treat the above as one definition of some crazy operator, but the point here is why I say that operator is momentum? The argument may be a bit long (I adopt the argument as in Dirac's which I think is more rigorous, you may refer to other books such as that in Griffiths for simpler version) but worth trying.

(a) The operator defined above is Hermite:

I need to prove $\hat{P} = \hat{P}^\dagger$, or equivalently: $<\varphi|\hat{P}|\psi>=<\psi|\hat{P}|\varphi>$, since $<\psi|\hat{P}|\varphi>^{*}=<\varphi|\hat{P}^\dagger|\psi>$, if above relation holds for any $|\psi>|\varphi>$, then the operator is Hermitian.

 $$ \begin{align*}<\varphi\mid\hat{P}\mid\psi>=&\int<\varphi\mid x><x\mid\hat{P}\mid\psi>dx=\int\varphi^{*}(x)(-i\hbar)\frac{d\psi(x)}{dx}dx\\=&-i\hbar\psi\varphi^{*}\big|_{-\infty}^{+\infty}+i\hbar\int\psi\frac{d\varphi^{*}}{dx}dx\end{align*} $$ 

From the physical argument that any realistic physical state cannot last forever, that means the wave functions go to zero at infinity, so that the first term would be zero. Then:

 $$ <\varphi\mid\hat{P}\mid\psi>=i\hbar\int\psi\frac{d\varphi^{*}}{d x}d x=[\int\psi^{*}(-i\hbar)\frac{d\varphi}{d x}d x]^{*}=<\psi\mid\hat{P}\mid\varphi>^{*} $$ 

So indeed the operator defined above is a Hermitian.

(b)Commutation rules between  $ \hat{X}.\hat{P} $

 $$ [\hat{X},\hat{P}]=\hat{X}\hat{P}-\hat{P}\hat{X} $$ 

Let's see its action on any wave function (let this commutator act

on any state and see what the expression in the  $ |x> $ basis):

 $$ \begin{aligned}<x|\hat{X}\hat{P}-\hat{P}\hat{X}|\psi>=&<x|\hat{X}\hat{P}|\psi>-<x|\hat{P}\hat{X}|\psi>\\=&<x|\hat{P}|\psi>-<x|\hat{P}|\psi^{\prime}>\quad|\psi^{\prime}>=\hat{X}|\psi>\\=&-i\hbar x\frac{d\psi}{d x}+i\hbar\frac{d<x|\hat{X}|\psi>}{d x}=-i\hbar x\frac{d\psi}{d x}+i\hbar\frac{d}{d x}(x\psi)\\=&i\hbar\psi=i\hbar<x|\psi>\end{aligned} $$ 

Since the above relation holds for arbitrary  $ |\psi> $, this means:

 $$ [\hat{X},\hat{P}]=\hat{X}\hat{P}-\hat{P}\hat{X}=i\hbar $$ 

This seemingly simple relation plays a very important role in the development of quantum theory. We have proved Ehrenfest theorem, and in the homework you have proved that: giving the above commutation relation, we can prove that the expectation values will obey Hamilton's equation of classical mechanics, i.e.

 $$ \frac{d<\hat{X}>}{dt}=\frac{<\hat{P}>}{m};\frac{d<\hat{P}>}{dt}=-\frac{dU(\hat{X})}{dx}>\mathrm{if}[\hat{X},\hat{P}]=\hat{X}\hat{P}-\hat{P}\hat{X}=i\hbar $$ 

This justifies the operator defined as above in relation (11-48) to be called momentum operator. $ ^{46} $

(c) Eigenstate of  $ \hat{P} $ and its expression in  $ |x> $ basis:  $ <x|p> $

Finally we come to the key to the transformation between  $ |x> $ and

 $ |p> $ basis, we can find the expression of  $ <x|p> $ from the above definition of momentum operator in  $ |x> $ basis:

 $$ \begin{aligned}&\hat{P}\mid p>=p\mid p>\stackrel{|x>basis}{\rightarrow}<x\mid\hat{P}\mid p>=p<x\mid p>\\&-i\hbar\frac{d<x\mid p>}{dx}=p<x\mid p>\end{aligned} $$ 

Let  $  p(x) = \langle x \mid p \rangle  $ (wave function of momentum)

 $$ -i\hbar\frac{dp(x)}{dx}=pp(x) $$ 

 $$ p(x)=e^{i\frac{p}{\hbar}x} $$ 

The wave function  $ \langle x|p\rangle $ is in a standard from of harmonic oscillation! Using our convention, we can define wave vector (in 1-D just a number):

 $$ \frac{p}{\hbar}=k=\frac{2\pi}{\lambda}\rightarrow p=\frac{h}{\lambda} $$ 

This is the de-Broglie relation.

## (d) Proper wave function of p(x)

The wave function  $ p(x) $ we get is not properly normalized. The  $ |p\rangle $s just like  $ |x\rangle $s form a continuous basis, and in analogy to the  $ |x\rangle $ basis, we would like to have orthonormal condition:

 $$ <p^{\prime}|p>=\delta(p-p^{\prime}) $$ 

We can use the above p(x) to calculate the  $ \langle p' | p \rangle $ to see what we get:

 $$ <p^{\prime}|p>=\int<p^{\prime}|x><x|p>d x=\int e^{\frac{i\frac{(p-p^{\prime})}{\hbar}x}{}}d x $$ 

Recall what we learned from Fourier transform, the delta function can be expressed as:

 $$ \begin{aligned}&\delta(x)=\frac{1}{2\pi}\int e^{i K x}d K\\ &\\ &Let\ x/\hbar=K,d x=\hbar d K\\ &\\ &<p^{\prime}|p>=\hbar\int e^{i(p-p^{\prime})K}d K=2\pi\hbar\delta(p-p^{\prime})\\ \end{aligned} $$ 

So the properly normalized  $ \langle x|p\rangle $ should be:

 $$ p(x)=<x\mid p>=\frac{e^{\frac{i\frac{p}{\hbar}x}{\hbar}}}{\sqrt{2\pi\hbar}}=\frac{e^{\frac{i\frac{p}{\hbar}x}{\hbar}}}{\sqrt{h}} $$ 

## Comments:

The meaning of  $ \langle x|p\rangle $ from the postulate is that given the state with definite momentum p, the probability amplitude find position at x. This probability is just  $ |\langle x|p\rangle|^{2}=1/h $. It is same for all x, i.e. you have equal probability of finding particle at any position! This is agreeable with the uncertainty relation, since in  $ |p\rangle $ the uncertainty of p is zero. However, the total probability of particle at  $ |p\rangle $ in the position space will explode (diverge), which is a headache for the quantum formalism, and a defect in the theory. But this is not a serious one because the state  $ |p\rangle $ (and  $ |x\rangle $) are idealization and not realizable in physics.

(e) Transformation between x and p spaces

 $$ p(x)=<x\mid p>=\frac{e^{^{i\frac{p}{\hbar}x}}}{\sqrt{2\pi\hbar}}=\frac{e^{^{i\frac{p}{\hbar}x}}}{\sqrt{h}} $$ 

From this, I know the  $ \langle p|x\rangle $ (the expression of base  $ |x\rangle $ in p space)

which is the complex conjugate of  $ \langle x | p\rangle $:

 $$ x(p)=<p\mid x>=(<x\mid p>)^{*}=\frac{e^{-i\frac{p}{\hbar}x}}{\sqrt{2\pi\hbar}} $$ 

This is if the particle has definite location x, the probability of finding momentum p world be same for all p.

For any state  $ |\psi> $, its expression in x space and p space are:

Expression in x space:  $ <x|\psi \geq \psi(x) $

Expression in p space:  $ <p|\psi\rangle=\varphi(p) $

The two expressions are related, and knowing one will enable us to get the other:

 $$ \begin{aligned}&\psi(x)=<x\mid\psi>=<\langle x\mid p><p\mid\psi>dp=\frac{1}{\sqrt{2\pi\hbar}}\int\varphi(p)e^{\frac{i\frac{p}{h}x}{\hbar}}dp\\ &\\ &\varphi(p)=<p\mid\psi>=<\langle p\mid x><x\mid\psi>dx=\frac{1}{\sqrt{2\pi\hbar}}\int\psi(x)e^{-\frac{p}{\hbar}x}dx\\ \end{aligned} $$ 

The two are indeed related by the Fourier transform as advertised, except by a difference of constant factor. We can then make some ‘cosmetic’ by substitute:

 $$ k=\frac{p}{\hbar},d p=\hbar d k,\varphi(p)=g(k)/\sqrt{\hbar},then: $$ 

 $$ \begin{aligned}&\psi(x)=\frac{1}{\sqrt{2\pi}}\int g(k)e^{ikx}dk\\ &g(k)=\frac{1}{\sqrt{2\pi}}\int\psi(x)e^{-ikx}dx\\ \end{aligned} $$ 

This is exactly the definition of Fourier Transform.

(3) Particle in free space and time evolution of its wave function

A particle in free space is that it has no interaction, the potential energy is thus 0. The energy is only due to kinetic energy (the rest mass energy can be taken as a constant and set the 0 point for energy measurement). The Hamiltonian operator in this case is (see the discussion on supplement (a) for more details):

 $$ \hat{H}=\frac{\hat{p}^{2}}{2m}=\frac{\hat{p}\hat{p}}{2m} $$ 

The eigenstate of momentum  $ |p> $ is the also the eigenstate of energy:

 $$ \hat{H}\mid p>=\frac{\hat{p}}{2m}p\mid p>=\frac{p^{2}}{2m}\mid p>=E_{p}\mid p> $$ 

 $ |p> $ is the eigenstate of  $ \hat{H} $ with eigenvalue (energy)  $ E_p=\frac{p^2}{2m} $. A result agree with classical theory for particle free of potential $ ^{47} $.

Once we know the eigenstate of $H$, we can predict the time evolution of any state$^{48}$. In particular, say at time 0, the initial state is $|p\rangle$, then at time t, the state will be:

 $$ |p,t>=e^{^{-i\frac{E_{p}}{\hbar}t}}|p> $$ 

In X-representation, the above is:

 $$ \varphi(p,t)=<x\mid p,t>=e^{-i\frac{E_{p}}{\hbar}t}<x\mid p>=\frac{1}{\sqrt{2\pi\hbar}}e^{i(\frac{p}{\hbar}x-\frac{E_{p}}{\hbar}t)}=\frac{1}{\sqrt{2\pi\hbar}}e^{i(k x-\omega t)} $$ 

It is our familiar plane wave, expressing the wave function of a particle with definite momentum in free space at any time.

 $$ k=\frac{p}{\hbar},\omega=\frac{E_{p}}{\hbar}=\frac{p^{2}}{2m\hbar}=\frac{\hbar k^{2}}{2m} $$ 

The phase velocity of the wave is:

 $$ \nu_{_{p}}=\frac{\omega}{k}=\frac{\hbar k}{2m}=\frac{p}{2m} $$ 

The group velocity is:

 $$ \nu_{g}=\frac{d\omega}{d k}=\frac{\hbar k}{m}=\frac{p}{m} $$ 

It is the group velocity that corresponds to the velocity of classical particle, which in a certain analogy, should not be surprise, since we see that in wave theory, it is the group velocity corresponds to the energy propagation of the wave packet.

The above plane wave is the ideal unrealizable case of for particle with definite momentum p (in analogy to monochromatic light wave), any real wave packet representing the particle will be a superposition of such plane waves. Say at time 0, the state of the system is a combination of different states of  $ |p> $ (i.e. express the state as combination of eigenstates of energy):

 $$ \left|\psi,t=0\right>=\int<p\left|\psi>\right|p>d p=\int\varphi(p)\left|p>d p\right. $$ 

Then at later time, the state of the system is:

 $$ |\psi,t>=\int\varphi(p)e^{-i\frac{E_{p}}{\hbar}t}\mid p> $$ 

In the X representation, it is:

 $$ \psi(x,t)=<x\mid\psi,t>=\frac{1}{\sqrt{2\pi\hbar}}\int\varphi(p)e^{i(\frac{p}{\hbar}x-\frac{E_{p}}{\hbar}t)}dp=\frac{1}{\sqrt{2\pi}}\int g(k)e^{i(kx-\omega t)}dk $$ 

(11-62)

 $ g(k) = \varphi(p)\sqrt{\hbar} $ and it is the Fourier Transform of wave function at time 0  $ \psi(x,0) $.

So if we know the wave function at certain time (that time can be set as 0), then we can find its Fourier transform g(k), adding the time evolution phase  $ e^{-i\omega t} $, using the above relation to get the wave function at later time. This strategy is better illustrated with an explicit example: The propagation of a Gaussian wave packet.

Example: The initial wave function is a Gaussian:

 $$ \psi(x,0)=e^{-\frac{x^{2}}{\sigma^{2}}}e^{i k_{0}x} $$ 

(a) The state given is not proper due to the normalization is not 1, so first I need to make it proper by:

 $$ \int\psi^{*}\psi dx=\int e^{-\frac{2x^{2}}{\sigma^{2}}}dx $$ 

Use the integration table (or calculate it with complex variable):

 $$ \int e^{-\alpha^{2}(\xi+\beta)^{2}}d\xi=\frac{\sqrt{\pi}}{\alpha} $$ 

In the normalization integral,  $ \alpha^{2} = \frac{2}{\sigma^{2}} $

 $$ \int\psi^{*}\psi dx=\int e^{\frac{2x^{2}}{\sigma^{2}}}dx=\sigma\sqrt{\pi}\bigg/\sqrt{2}=(\frac{\sigma^{2}\pi}{2})^{\frac{1}{2}} $$ 

Then the proper normalized initial wave function is:

 $$ \psi(x,0)=\left(\frac{2}{\pi\sigma^{2}}\right)^{\frac{1}{4}}e^{-\frac{x^{2}}{\sigma^{2}}}e^{-i k_{0}x} $$ 

(b) Finding its Fourier Transform:

The Fourier transform can be directly found by definition:

 $$ g(k)=\frac{1}{\sqrt{2\pi}}\int\psi(x,0)e^{-ikx}dx $$ 

You will need formula for calculation, but I will take the known Gauss transform:

 $$ f(x)=e^{-\frac{x^{2}}{\sigma^{2}}}\xrightarrow{FT}g(K)=\frac{\sigma}{\sqrt{2}}e^{-\frac{K^{2}\sigma^{2}}{4}} $$ 

For our given initial wave function, its FT then is(use above formula and phase shift property of FT):

 $$ g(k)=\left(\frac{2}{\pi\sigma^{2}}\right)^{\frac{1}{4}}\frac{\sigma}{\sqrt{2}}e^{-\frac{(k-k_{0})^{2}\sigma^{2}}{4}}=(2\pi)^{\frac{1}{4}}\sigma^{\frac{1}{2}}e^{-\frac{(k-k_{0})^{2}\sigma^{2}}{4}} $$ 

The FT of a Gaussian is another Gaussian.

Comments: Width of distribution of Gauss packet meets the lower limit in Uncertainty relation. The width of Gaussian is defined as:

For  $ f(x)=e^{-\frac{x^2}{\sigma^2}} $,  $ \Delta x \equiv \sigma/\sqrt{2} $ (This is defined from standard deviation of distribution.  $ (\Delta x)^2 = \langle x - \langle x \rangle \rangle^2 = \langle x^2 \rangle - \langle x \rangle^2 $)

For the given wave function, the probability (the square of the wave function) is:

 $$ |\psi(x,0)|^{2}\propto e^{-2\frac{x^{2}}{a^{2}}}\rightarrow\Delta x=\sigma/2 $$ 

 $$ |g(k)|^{2}\propto e^{-\frac{(k-k_{0})^{2}\sigma^{2}}{2}}\rightarrow\Delta k=1/\sigma $$ 

 $$ \Delta x\Delta k=\frac{1}{2}\stackrel{49}{\quad} $$ 

 $$ p=\hbar k\rightarrow\Delta x\Delta p=\hbar/2 $$ 

So for Gauss wave function, the uncertainty meets the lower limit.

(c) The time evolution of the wave function

Now we can evaluate the  $ \psi(x,t) $ from its initial form, using relation (11-51) above:

 $$ \psi(x,t)=\frac{1}{\sqrt{2\pi}}\int g(k)e^{i(kx-\omega t)}dk,\quad\omega=\frac{\hbar k^{2}}{2m} $$ 

Throw in the g(k), and calculate the monster integral:

 $$ \begin{aligned}\psi(x,t)=&\frac{1}{\sqrt{2\pi}}(2\pi)^{-\frac{1}{4}}\sigma^{\frac{1}{2}}\int e^{-\frac{\sigma^{2}}{4}(k-k_{0})^{2}}e^{i(kx-\frac{\hbar k^{2}}{2m}t)}d k\\=&(\frac{2\sigma^{2}}{\pi})^{\frac{1}{4}}\frac{e^{i(k_{0}x+\varphi_{0})}\equiv}{(\sigma^{4}+4\hbar^{2}t^{2}\bigg/m^{2})^{\frac{1}{4}}}\exp[-\frac{(x-\frac{\hbar k_{0}}{m}t)^{2}}{\sigma^{2}+i2\hbar t}]\\ \end{aligned} $$ 

 $$ |\psi(x,t)|^{2}=\sqrt{\frac{2\sigma^{2}}{\pi}}\frac{1}{\sigma^{2}(1+4\hbar^{2}t^{2}/\sigma^{4}m^{2})^{\frac{1}{2}}}\exp[-\frac{2\sigma^{2}(x-\frac{\hbar k_{0}t}{m})^{2}}{\sigma^{4}+4\hbar^{2}t^{2}/m^{2}}] $$ 

Let’s focus only on the time dependent part in this monster.

i. The amplitude of the wave function or its square drops as time increases. The total probability is still normalized

(which I will skip the proof by integration), this means the wave packet will get broadened, which is indeed reflected in the exponential term.

ii. The center of the wave packet (also its maximum) travels at group velocity corresponds to the classical particle's velocity.

 $$ x-\left.\hbar k_{0}t\right|_{m}=0\quad(the center changes with time) $$ 

 $$ x\left/t=\hbar k_{0}\right/m=p\bigg/m $$ 

The width of the wave packet spreads:

 $$ \Delta x=\frac{\sigma}{2}\sqrt{1+\frac{4\hbar^{2}t^{2}}{\sigma^{4}m^{2}}} $$ 

The spreads rate is in accordance of the drop of the amplitude as expected.

We have discussed the most important postulates in Q.M, and worked out some examples to illustrate them. Now let me add some extra comments as summary.

Let's consider the single particle here for simplicity. In classical mechanics, the single particle is described by set of variables in real 3-D space, i.e.  $ q_{1}, q_{2}, q_{3} $ and their canonical conjugate momentum  $ p_{1}, p_{2}, \ldots, p_{n} $, and  $ p_{3} $, total of 6 variables. Knowing the environment (such as force or potential) and the initial conditions of the particle, the

particles property and its time evolution are completely determined.

In microscopic world, due to wave-particle duality and Uncertainty

Relations, the above classical description is no longer valid. The

results of measurements will be probabilistic in the general cases. i.e.

given a particle, we measure its physical property, we find that we will

get some values ( $ \lambda_{i} $) with some probability, expressed in terms of

probability amplitude ( $ a_{i} $),  $ |a_{i}|^{2} $ is the probability to get  $ \lambda_{i} $ in the

measurement. (of course, we have to prepare many particles in the

same state, and repeat measurements on these )

From these measurements we have a description of the physical system (the state of the particle under study in this case). This is a very reasonable and sound way to describe a system. So we shall characterize the state of a system by giving probability amplitude to the possible outcomes of measurement. i.e.

 $$ |\psi>=(a_{1}(\lambda_{1}),a_{2}(\lambda_{2}),a_{3}(\lambda_{3}).....) $$ 

Where  $ |\psi> $ is just a symbol to represent the physical state;  $ a_{i}(\lambda_{i}) $ is the probability amplitude to get the physical measurement result  $ \lambda_{i} $ has to be real number because it is a measured value,  $ a_{i}(\lambda_{i}) $ is generally a complex number because only requirement is that its square to be real. $ ^{50} $

To express these ideas in concrete math forms, this is realized by the postulate 1, 2, and 3. The forms of  $ |\psi\rangle=(a_{1}(\lambda_{1}),a_{2}(\lambda_{2}),a_{3}(\lambda_{3}).....) $ can be rewritten in a vector form (postulate 1):

 $$ \left|\psi\right>=a_{1}\left|\lambda_{1}\right>+a_{2}\left|\lambda_{2}\right>+a_{3}\left|\lambda_{3}\right>+\ldots $$ 

 $ |\lambda_{i}> $ is the eigenvector associated with eigenvalue  $ \lambda_{i} $ of the

observable. The observable is in form of Hermitian operator (postulate

2)would guarantee the real eigenvalue and orthogonality and

completeness of the eigenvectors (orthogonal comes from the fact that

the property of the system should be single valued, i.e. if the particle at

position  $ x_{1} $, it cannot appear at  $ x_{2} $ at the same time. Completeness

comes from that fact that we have to list ALL the possible

measurement outcomes). Postulate 3 would allow us to predict the

outcomes (in terms of probability, from the expansion coefficients-the

probability amplitude). This is the physical reasoning behind those

abstract postulates.

This quantum description may seem far less satisfactory than the classical one. There a particle is specified by only 6 variables and if you state it in a vector sense, the state vector in classical mechanics is in a phase space of dimension=6. In quantum, the state vector will be generally in a space with many dimensions or infinite dimension,

even for the simplest case for a particle in free space (no external force or potential), its dimension to describe the position or momentum would be infinite (even we ‘digitize’ the results to make them discrete instead of continuous, they are still infinite numbers of them). This complexity is indeed imposed in quantum by the uncertainty principle and we have to bear with it.

Not only the dimension of the space is big in quantum, there are also many different bases in quantum corresponding to different physical properties under measurement (i.e. position, momentum, energy…). This means there are different ways to express the physical state  $ |\psi\rangle $ depending on which physical property in concern thus which basis is in use. The vector may be invariant in different bases (this is the blessing of the vector so that physical relations expressed by them would be independent of base), but its expression will be different in different bases (to work out problem, often you need explicit expressions of vectors with certain base). Here are two more examples to illustrate this point:

(1) The expression of photon state in terms of polarization or spin

For a photon if we only interested in its polarization state $ ^{51} $. Of

course if we know its  $ |H\rangle $,  $ |V\rangle $ components (the expansion

coefficients---the probability amplitude, complex numbers in

general):

 $ |\psi \rangle = c_1 | H \rangle + c_2 | V \rangle $ or Jones Vector  $ \begin{bmatrix} c_1 \\ c_2 \end{bmatrix} $

This is a specific expression of state  $ \left| \psi \right\rangle $ in the  $ \left| H \right\rangle, \left| V \right\rangle $ base.

What’s its expression if we are interested in the spin state of the

photon? This time the base is  $ \left|+1\right\rangle $,  $ \left|-1\right\rangle $, corresponding to the

photon spin  $ +1\hbar $ and  $ -1\hbar $ along k, the direction of photon

propagation. IN this case, the  $ \left|+1\right\rangle $ and  $ \left|-1\right\rangle $ are related to the

polarization state $ ^{52} $:

 $$ |+1>=\left|L>,|-1>=\right|R> $$ 

 $$ \left|\psi\right>=c_{1}^{^{\prime}}\left|L\right>+c_{2}^{^{\prime}}\left|R\right> $$ 

The expression would be quite different in this base. However, with the simple relation between  $ \langle H|L\rangle,\langle H|R\rangle,\langle V|L\rangle,\langle V|R\rangle $ (the 4 elements in a transform matrix), you can find out the relation between  $ c_1 $,  $ c_2 $ and  $ c_1' $,  $ c_2' $.

(2) State of particle inside an infinite potential.

<div style="text-align: center;"><img src="imgs/img_in_image_box_252_1187_531_1405.jpg" alt="Image" width="23%" /></div>


You worked this out in a homework, the energy of the particle can

have is in forms of  $ E=m^{2}E_{0} $, where m is an integer number determined by the standing wave condition  $ 2L=m\lambda $ ( $ m=1,2,3\ldots $)

The eigenstate of the energy (energy observable, represented by H, the Hamiltonian operator) forms a complete basis set. The initial state's expression in terms of the expansion of this basis set is:

 $$ |\psi>=\sum_{i}c_{i}\mid E_{i}> $$ 

Knowing the coefficients  $ c_{i} $, the results of energy measurement can be predicted (the probability of course).

Now you may ask the expression of the state in terms of position. The expression of the state in the base formed by position eigenstates  $ |x\rangle $ would be different:

 $$ <x\left|\psi>=\sum_{n}c_{_{n}}<x\right|E_{_{n}}>=\sum_{n}c_{_{n}}\sin(k_{_{n}}x)=\sum_{n}c_{_{n}}(\sin\frac{n\pi}{L}x)\quad(0\leq x\leq L) $$ 

So the state expressed in terms of |x> would be:

 $$ \left|\psi\right\rangle=\int\left|x\right\rangle\left\langle x\right|\psi\left\langle d x\right\rangle=\int[\sum_{n}c_{n}(\sin\frac{n\pi}{L}x)]\left|x\right\rangle d x $$ 

Both expressions represent the same initial state. Their expression can be quite different. In this case, it is also impossible to find a common basis set which are eigenstates for both the energy and position measurement, as in the polarization and spin case for photon. This is due to the uncertainty relation, the position and momentum (the energy in this case directly related to  $ p^{2} $) cannot be determined simultaneously.

I hope the examples show the point, that the specification of the state vector (the explicit expression in certain basis) depends on physical property under study (the basis vectors are the eigenstates of the observables). So instead of asking is there a ultimate base in quantum so that I can express the state in one definite form $ ^{53} $ and calculate the answer from there, it is more appropriate to ask what is the suitable basis for a specific problem, i.e. the natural choice would be the eigenstate of the physical observable under study.

Another point is that though we may have many bases (along with these, different expressions for the physical state in these bases), the expressions of the quantum state in these bases are related. This change of basis (called transformation) had been discussed for the spin 1/2 electron and photon polarization in detail. The vectors representation in different bases that span the same space are related by a Unitary transformation, the key is the relations among the base vectors. This point has been discussed in the supplementary material on matrices.

In general, the quantum problems will be in three classes:

(1) Find the expression of the state and predict the experimental results. This is the basic description of physical system and measurement dealt in postulates 1, 2, 3, illustrated in examples in this notes.

(2) The transformation of bases. Knowing the expression of the state, the observable in one basis, find out their expressions under a different basis span the same space. This is given in examples of polarization and spin 1/2(Also in examples you probably already worked many times before, such as transformation between the Cartesian coordinate and polar coordinate system, or between rotate Cartesian coordinate systems). Another important example will be between the |x> basis and |p> basis in quantum which is not covered here. In this kind of problem, the key is to find out the relation between the base vectors, then everything else would follow mechanically in math.

(3) The time evolution of the physical state. This is of course solving the Schrodinger equation. (The state evolution in a two-level system; the particle moving in some simple potential, such as infinite or finite wells, harmonic potential and coulomb potential of single electron-nuclei, etc. These are a few cases that you can find analytical solutions) I do not have time to show you all this but you will have plenty of practice in quantum mechanics next semester.

This concludes the introductory course on quantum mechanics. Before I leave, I should mention that there are also some important topics which are omitted and not required in this introductory course. The supplements (a),(b) ,(c) and below will cover these topics just for the completeness of

the theory.

## Supplement (A): Quantization Rules

(a) The relation between the observables and its correspondence to the physical relation in classical theory.

I only discussed some simple observables and their operators, such as position, spin. What about other physical quantities and how to express their operators if we already know some operator forms. The most important one would be what is the form of energy operator (Hamiltonian) in terms of other operators such as momentum and position?

From the correspondence principle as in Ehrenfest theorem, that the quantum expectation value would follow the classical theory, we have a method to construct the quantum observables (the operator). The classical energy is in forms of:

$$H = \frac{p^{2}}{2m} + V(x)\ \text{(here, H, p, x are just numbers)}$$

Express this in the expectation values in quantum:

 $$ \begin{aligned}<\varphi|\hat{H}|\varphi>=&<\varphi|\frac{\hat{P}\hat{P}}{2m}|\varphi>+<\varphi|V(\hat{x})|\varphi>\\ =<&\varphi|\frac{\hat{P}\hat{P}}{2m}+V(\hat{x})|\varphi>\end{aligned} $$ 

Here  $ \hat{H},\hat{P},\hat{x} $ are operators, and  $ V(\hat{x}) $ is a function of operators whose meaning is clearer in Taylor expansion. Since the state  $ |\varphi> $ is

arbitrary, the above relation suggests the relation between the energy

operator and that of position and momentum are:

 $$ \hat{H}=\frac{\hat{P}\hat{P}}{2m}+V(\hat{x}) $$ 

In fact the simple rule is to replace the variables (the measurable quantities) in classical relation of physical properties with operator, you will get the quantum operator. Since in classical mechanics, the x, p describes the state of system, and all physical properties can be expressed as function of (x,p), thus we can construct the operator form from the classical relations. Of course this only applies to the observable that has classical correspondence. For the spin, we have to construct the operator based on experimental results as what I did in Stern-Gerlach example.

There is a pitfall in this method because of the uncertainty relation.

For example, we could define a quantity which is  $ D = xp_x $ in classical theory. Then what is the corresponding operator for D in quantum theory?⁵⁴ Is  $ \hat{D} = \hat{x}\hat{p}_x $ or  $ \hat{D} = \hat{p}_x\hat{x} $ ? Because  $ x $,  $ p_x $ are not commutable, i.e.  $ [\hat{x}, \hat{p}_x] = \hat{x}\hat{p}_x - \hat{p}_x\hat{x} = i\hbar \neq 0 $. So the two expressions are really different. Each expression is not even a Hermitian as required by the quantum theory. (You check it yourself). It turns out the correct form would be so called symmetrised product (a Hermitian):

\hat{D}=\frac{1}{2}(\hat{x}\hat{p}_{x}+\hat{p}_{x}\hat{x})\equiv\frac{1}{2}\{\hat{x},\hat{p}_{x}\} to represent this physical quantity in quantum. $ ^{55} $ The {A,B} is called anti-commutator, it is not Poisson Bracket in classical mechanics.

## Supplement (B): Uncertainty

(b) Uncertainty relations between observables derived from the postulate.

We first need to define the expression for the uncertainty, the variation of the measurements of some observable A. If the measurements result in many values, $a_{i}$'s, then the variation is :

$(\Delta a)^{2} = <(a_{i} - <a_{i}>)^{2} >$, here <...> means average. From the above discussion, we could use an operator to represent this variation (the variation is a physical measurable quantity). The variation operator for observable A would be (just replace the numbers with operator A):

 $$ \begin{aligned}&<\left(\Delta A\right)^{2}>=<\left(A-<A>\right)^{2}>=<A^{2}-2A<A>+<A>^{2}>\\&\quad\quad\quad\quad=<A^{2}>-<A>^{2}\\&Thus\Delta A=A-<A>\\ \end{aligned} $$ 

A is the operator and <A> is the expectation value evaluated over some state. Since A is Hermitian,  $ \Delta A $ defined above is also a Hermitian as required by physical measurement.

It can be proved that for any two observables, the uncertainty between them obeys:

 $$ <(\Delta A)^{2}><(\Delta B)^{2}>\;\geq\;\frac{1}{4}|<[A,B]>|^{2} $$ 

This states that the uncertainty has a lower bound which is given by the module of the expectation value of the commutator between A,B. [A,B]=AB-BA. To prove 11-73, we shall need some Lemmas. $ ^{56} $

Lemma 1. The Schwarz Inequality

 $$ <\alpha\mid\alpha><\beta\mid\beta>\geq\mid<\alpha\mid\beta>\vert^{2} $$ 

The above relation is obvious for any real vectors in 3-D space, the module of the direct product is obvious less than the product of individual lengths. They are related by a cosine, only equal when the two vectors parallel. For any arbitrary vectors in the Hilbert space:

 $$ \begin{aligned}&||\alpha>+\lambda|\beta>|^{2}\geq0\text{for all}\lambda\\&(<\alpha|+\lambda^{*}<\beta|)(|\alpha>+\lambda|\beta>)=<\beta|\beta>\lambda^{2}+2\mathrm{Re}(\lambda<\alpha|\beta>)+<\alpha|\alpha>\geq0\\ \end{aligned} $$ 

This is equivalent for a parabolic function larger than 0, i.e.

 $ ax^2 + bx + c \geq 0 $ for all  $ x $, and the condition is:  $ b^2 \leq 4ac $. This will give the inequality in 11-74.

Lemma 2. The expectation value for a Hermitian operator is real.

Proof.  $ A = A^{\dagger} $

 $$ \left(<\varphi\mid A\mid\varphi>\right)^{*}=<\varphi\mid A^{\dagger}\mid\varphi>=<\varphi\mid A\mid\varphi> $$ 

Lemma3. The expectation value for an anti-Hermitian  $ (A^{+}=-A) $ is purely imaginary.

The proof for this is obvious, similar to lemma 2.

Equipped with these 3 lemmas, we can prove relation 11-73.

Take  $ |\alpha| = \Delta A |\varphi| > $

 $ |\beta| = \Delta B |\varphi| > |\varphi| \text{ is just some arbitrary ket} $

From Lemmal, the Schwarz Inequality, we have:

 $$ <\left(\Delta A\right)^{2}><\left(\Delta B\right)^{2}>\ \geq\ |\<\Delta A\Delta B>\|^{2} $$ 

 $$ \Delta A\Delta B=\frac{1}{2}[\Delta A,\Delta B]+\frac{1}{2}\{\Delta A,\Delta B\} $$ 

The  $ \{A,B\} $ is the notation for anti-commutator, it is defined as

 $ \{A,B\}=AB+BA $ for any A,B including the variation operators above.

Please prove yourself that the commutator is always anti-Hermitian

and anti-commutator is always Hermitian. Then using Lemma 2 and

3:

 $$ \begin{aligned}&<\Delta A\Delta B>=\frac{1}{2}<[\Delta A,\Delta B]>+\frac{1}{2}<\{\Delta A,\Delta B\}>\\ &\\ &|\lt\Delta A\Delta B\rangle|^{2}=\frac{1}{4}|<[\Delta A,\Delta B]>|^{2}+\frac{1}{4}|<\{\Delta A,\Delta B\}>|^{2}\geq\frac{1}{4}|<[\Delta A,\Delta B]>|^{2}\\ \end{aligned} $$ 

This proves the relation 11-73. This means that if two physical quantities can be determined simultaneously, i.e. with zero variation, the two operators representing the physical quantity has to be commute, [A,B]=0; otherwise, there will be uncertainty relations governed by the expectation value of the commutator <[A,B]>. If you put in the commutation relations between X,P, [X,P]=ih, you will get our familiar uncertainty relation:

 $$ (\Delta X)^{2}(\Delta P)^{2}\geq\frac{\hbar^{2}}{4}\rightarrow\Delta X\Delta P\geq\frac{\hbar}{2} $$ 

58

 $ \Delta X $ is defined as  $ \sqrt{<(\Delta X)^2>} $ etc.

##### Supplement (C): C.S.C.O

(c) Commutable Observables, Common Eigenstates and Complete Set of Commutable Observables (C.S.C.O)

From the discussion in (b), we see that if two physical observables are not commute, then they cannot be determined simultaneously. You probably guessed (though it does not count as proof) that if the observables are commutable, then they can be determined simultaneously.

This is the first part I shall show you indeed the case. I shall try to prove that for commutable observables, you can construct eigenvectors that are common to them. That is:

If for two observables, their operators are A, B and they commute, i.e.

[A,B]=0 or AB=BA, then it is possible to find a vector so that:

 $$ A\mid\phi_{i}>=a_{i}\mid\phi_{i}> $$ 

 $$ B\mid\phi_{i}>=b_{i}\mid\phi_{i}> $$ 

 $ |\phi_i> $ is the common eigenvector for both A and B (with different eigenvalues of course, since A,B represent different physical property, say one is energy, the other is total angular momentum). If you

measure property A,B on a state  $ |\phi_{i}> $, you get values  $ a_{i} $,  $ b_{i} $. These common eigenvectors will form a orthonormal basis for the sate space.

In summary, this theorem states:

For two commutable observables, it is possible to construct an

orthonormal basis of the state space by the eigenstates that are

common to both observables.

The necessary condition is also true, i.e. if there is such basis by the common eigenstates, then [A, B]=0. This is easy to prove, since

 $$ \left(A B-B A\right)\mid\phi_{i}>=(\boldsymbol{a}_{i}\boldsymbol{b}_{i}-\boldsymbol{b}_{i}\boldsymbol{a}_{i})\mid\phi_{i}>=0 $$ 

For any arbitrary state which can be written as linear combination of

the eigenstates, the above relation would also be true. (prove it

yourself), then AB-BA=0

To prove the sufficient condition, i.e. the theorem in italic above would require more work. It is extremely simple if the eigenspace for A,B are not degenerate, i.e. all eigenvalues are different, and each eigenvalue is associated with an eigenstate. Let's first consider this case.

Suppose  $ |\phi_i\rangle $ is an eigenstate of A with eigenvalue  $ a_i $, then  $ B|\phi_i\rangle $ is also the eigenstate of A with same eigenvalue.

Proof:  $ A(B \mid \phi_i >) = BA \mid \phi_i >= a_i(B \mid \phi_i >) $

From the definition of eigenvalues and eigenstates, this proves the above statement. Since the eigenvalues are non-degenerate, so the

eigenstates of the same eigenvalue could only be different by a common factor, let's call this common factor  $ b_{i} $, i.e.

 $$ B\mid\phi_{i}>=b_{i}\mid\phi_{i}> $$ 

This proves that  $ |\phi_i > \text{is also an eigenstates for } B \text{ with eigenvalue } b_i $.

So  $ |\phi_i > \text{ would be the orthonormal basis we are looking for.} $

In case of degeneracy, the above relation  $ B|\phi_{i}>=b_{i}|\phi_{i}> \text{ may not be true. But we still can still find the common eigenstates and form a orthonormal basis. For simplicity of discussion, let me just take a simple case for example, but can be easily extended to more general situation:} $

Still the  $ |\phi_i> $ would be eigenstates of A, but in this case A has degenerate eigenvalues. Assume for one eigenvalue number  $ a_i $, it is doubly degenerate, i.e. there are two eigenvalues taking the number  $ a_i $. There will be two eigenvectors associated with this eigenvalue number  $ a_i $:

 $$ A\mid\phi_{i}^{1}>=a_{i}\mid\phi_{i}^{1}> $$ 

 $$ A\mid\phi_{i}^{2}>=a_{i}\mid\phi_{i}^{2}> $$ 

 $ |\phi_i^1 > \text{and} |\phi_i^2 > \text{are independent and orthogonal vectors.}^59 $

Important lemma: any combination of  $ |\phi_i^j> $ would also be

eigenvectors of A with eigenvalue of  $ a_i $. The  $ |\phi_i^j> $ spans a subspace in

the eigenspace of A.

 $$ \mathrm{Proof}:|\varphi>=\sum_{j}c_{j}|\phi_{i}^{j}> $$ 

 $$ A\mid\varphi>=\sum_{j}c_{j}A\mid\phi_{i}^{j}>=\sum_{j}c_{j}a_{i}\mid\phi_{i}^{j}>=a_{i}\sum_{j}c_{j}\mid\phi_{i}^{j}>=a_{_{i}}\mid\varphi> $$ 

For a commutable observable B, we see that:

 $$ A(B\mid\phi_{i}^{j}>)=BA\mid\phi_{i}^{j}>=a_{i}(B\mid\phi_{i}^{j}>) $$ 

So  $ B|\phi_{i}^{j}> $ is within the subspace which is generally:

 $$ B\mid\phi_{i}^{1}>=c_{1}\mid\phi_{i}^{1}>+c_{2}\mid\phi_{i}^{2}> $$ 

 $$ B\mid\phi_{i}^{2}>=c_{1}^{^{\prime}}\mid\phi_{i}^{1}>-c_{2}^{^{\prime}}\mid\phi_{i}^{2}> $$ 

This means  $ |\phi_i^J > \text{may not be eigenstates of } B $. We can also see this from another point of view. The matrix of B within the subspace of  $ |\phi_i^J > \text{in this two dimensional case is just} $:

 $ B_{in-subspace-spanned\ by-|\phi_i^j>}=\begin{pmatrix}c_1&c_1'\\c_2&c_2'\end{pmatrix} $ which is not diagonal.

However, for the Hermitian B, we could take a certain linear

combinations of  $ |\phi_{i}^{j}> $, to reform a basis in this subspace so that B is

diagonal, and these new basis (a linear combination of  $ |\phi_{i}^{j}> $) would

be eigenvectors of B. The diagonalization of the above  $ 2x2 $ is trivial,

let's say the combination of:

 $$ |\boldsymbol{\varphi}_{i}^{1}>=d_{1}|\boldsymbol{\phi}_{i}^{1}>+d_{2}|\boldsymbol{\phi}_{i}^{2}> $$ 

 $$ |\varphi_{i}^{2}>=d_{1}^{^{\prime}}|\phi_{i}^{1}>+d_{2}^{^{\prime}}|\phi_{i}^{2}> $$ 

Under this basis for the subspace of A, the B would also be diagonal.

i.e.  $  B_{in-subspace-spanned\ by-|\varphi_i^j>} = \begin{pmatrix} b_1 & 0 \\ 0 & b_2 \end{pmatrix}  $, so  $  |\varphi_i^j>  $ would be

eigenvectors for B with eigenvalues of b_j. Because  $  |\varphi_i^j>  $ is just a

linear combination of  $ |\phi_{i}^{j}> $, from the above lemma, it is also the eigenvector for A with eigenvalue  $ a_{i} $. Thus we constructed a basis consisting of the common vectors for both A and B.

Since  $ |\varphi_{i}^{j}> $ is a common eigenvector for A,B, so we usually choose the notation:

 $$ |\varphi_{i}^{j}>=|a_{i}b_{j}> $$ 

Now we could talk about the Complete set of Commutable Observables (the C.S.C.O). For the simple non-degenerate case, measuring the eigenvalue would specify a unique state. However this generally is impossible in case of degeneracy. Let's say measurement of A gives a value of $a_{i}$, the state is not unique if $a_{i}$ is degenerate, it could be a linear combination within that subspace. This introduced the ambiguity in our description of physical state from measurement.$^{60}$ But such ambiguity in the state description due to degeneracy of one observable can be removed if we have a commutable observable B with A. The measurement of A cannot specify a state uniquely, but measurement of A and B will, i.e. for any pair of $(a_{i},b_{i})$, there is a unique eigenstate associated with it. What happens if there are even degeneracy for A and B. In the above example, this would be the case that $b_{1}=b_{2}$. Then we could introduce

another operator C which is commute with A and with B, so that

 $ |a_{i},b_{j},c_{k}> $ would uniquely specify a state, which is common

eigenstate for A,B and C. A typical example is how we describe the

electronic state in hydrogen atom and alike ions, there we use  $ |n,l,m> $

to specify the state, related to the energy, orbit anaular momentum and

its directional component (projection). This process can go on till

we remove any degeneracy, and we will get the C.S.C.O. Such

C.S.C.O would have following properties:

(i) All observables A, B, C ... commute by pair.

(ii) Specifying the eigenvalues (from the measurement) would

uniquely determine a common eigenstate. $ ^{61} $

## Chapter 12 Simple Systems

In this chapter, we shall apply the quantum mechanics on some simple systems. We have worked some examples to illustrate the working mechanism of quantum mechanics last chapter, but most cases I focused on the postulates of quantum and did not solve Schrodinger equation, except in the example where I have solved the case of particle in free space (V=0). In this chapter, we shall start from solving the Schrodinger equation for 1-dimension, working in detail on some simple potential (V) forms: the square potential wells; the step type and square type potential barrier and harmonic oscillator. Finally I shall give you the result of Hydrogen atom, the solution of S-equation in a central potential field.

Such systems are simple because they are the rare cases that due to their simpler potential forms, the differential equation has exact and analytic solutions. So these problems serve perfect roles further showing the power of principles of quantum mechanics, they are also important models for more advanced topics. $ ^{62} $

## 12 -1 Schrodinger Equation in Space Representation and General Property of Wave Function Solution

First, let me list the results of last chapter. We have learned the general form of S-equation is:

 $$ i\hbar\frac{\partial\left|\psi\right.>}{\partial t}=\hat{H}\left|\psi\right.> $$ 

H is the Hamilton operator, corresponding to the energy of the system:

 $$ \hat{H}=\frac{\hat{P}^{2}}{2m}+V(\hat{R}) $$ 

Where P and V(R) are operators of momentum and position, and the semicircle “hat” on top remind you they are operators. For the rest of these chapters, I shall use capital letter to represent the operator and I hope in most cases this won’t cause confusion. In 1-d case, we have discussed these operators, their representation in space are:

 $$ \begin{aligned}&<x\mid X\mid\psi>=x\psi(x,t)\quad\psi(x,t)=<x\mid\psi>\\ &\\ <x\mid P\mid\psi>=-i\hbar\frac{d}{dx}\psi(x,t)\quad&(12-4)\\ \end{aligned} $$ 

The  $ \psi(x,t) $ is the space representation of state vector, and it is called wave function. We see that in 1-d space, the effect of position operator is just times eigenvalue x to the wave function; the effect of momentum operator is space derivative of the wave function. In higher dimension, the wave function will depend on  $ (r, t) $, and the momentum operator would be  $ -i\hbar\nabla\psi(r,t) $.

Now we can express the general form of S-equation in space representation, let us time bra  $ \langle x| $ from left to  $ (12-1) $, and because  $ |x\rangle $ is eigenstate of time independent operator X,  $ |x\rangle $ is independent of time, so:

 $$ \begin{aligned}&i\hbar\frac{\partial<x\mid\psi>}{\partial t}=<x\mid H\mid\psi>\\&i\hbar\frac{\partial\psi(x,t)}{\partial t}=\frac{1}{2m}<x\mid P^{2}\mid\psi>+<x\mid V(X)\mid\psi>\\ \end{aligned} $$ 

Now apply the relation in (12-3) and (12-4), we have (an exercise for you to prove it, involves Taylor expansion of functions of operator)

 $$ i\hbar\frac{\partial\psi(x,t)}{\partial t}=[-\frac{\hbar^{2}}{2m}\frac{d^{2}}{d x^{2}}+V(x)]\psi(x,t) $$ 

This is the Schrodinger equation in 1-d space. In 3-d, it becomes:

 $$ i\hbar\frac{\partial\psi(x,t)}{\partial t}=[-\frac{\hbar^{2}}{2m}\Delta+V(r)]\psi(x,t)\quad\Delta\equiv\nabla^{2}=\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}} $$ 

We have discussed in last chapter, usually to study the time evolution, we have a nice strategy. We do not need to solve the time-dependent S-equation above. Instead, we solve the time-independent S-equation to find out the eigenstates (stationary states) first, these states have very simple time evolution behavior; then we expand the initial wave function (wave function at t=0) in terms of stationary states, then the time evolution will be determined. So we need to work out the time independent S-equation, its space representation is:

 $$ [-\frac{\hbar^{2}}{2m}\frac{d^{2}}{d x^{2}}+V(x)]\psi_{_{E}}(x)=E\psi_{_{E}}(x) $$ 

The E at the foot of the wave function is to remind you they are special wave functions (though I may drop it to save typing), the eigenstates of the energy, and they are independent of time (if H does not explicitly contain time). This is the most important equation in this chapter.

Before we throw in the particular forms of potential and start cranking the math, it is helpful to discuss the general property of wave functions that are solutions to the equation. The solutions of the partial differential equation (1n 1-d, partial becomes ordinary), not only the equation is important, the boundary/initial condition is also crucial.

(1) The wave function solutions to equation (12-6) need to be single valued, continuous, and its first derivative over x is also continuous unless the potential V becomes infinite.

Comment: Single value is the requirement of the physics. The continuity condition is actually enforced by the equation, its second derivative over x, and if there are any discontinuity of the wave function or its first derivative, there will be singularity (infinity) in equation. However, there is one particular case which happens in our simple idealized potential: infinite potential, where V becomes infinite. In this infinite V, we see that the continuity of first derivative of wave function cannot be satisfied $ ^{63} $.

This requirement on solutions of wave function will be very useful, they essentially establish the boundary condition: wherever, there is a sudden change of potential (the boundary), the continuity of wave function and its first derivative at the boundary set the limit (or condition) on the possible solutions, and we shall see these boundary condition will limit the possible energy (not all values are allowed), i.e. the quantization of energy. When the potential change is infinite, then we do not have continuity on first derivative of wave function.

So in summary, the wave function goes “smoothly” through boundary of finite height; but will have a “kink” at the boundary with infinite height.

(2)The solutions of physical realizable wave function should be normalizable, i.e.

 $$ <\psi\mid\psi>=\int\psi^{*}(x)\psi(x)d x\quad\mathrm{s h o u l d~b e~f i n i t e}^{64}. $$ 

Comment: This is true for many solutions, for example the bound state (I mean the energy is less than the maximum of potential, thus the particle is “bound” by the potential and its wave function only extends over limited space, dies away when x goes big), this sometimes expressed as requirement that  $ \psi(\infty)=0 $. This is a rather

physical requirement, since we don't have anything real can extend to

infinity. However, we do see unphysical solutions contradict this, the

idealized plane wave of particle in free space (analogy to

monochromatic light with single frequency). Those idealized solutions

are unrealizable in real world, they are useful because they are simple

and we can construct realistic wave packet out of these idealized plane

wave. In conclusion, I stress that for the bound state, the wave

functions are normalizable; while for the free particle-like states

(those extends all over space, unbound by the potential, also they are

called scattering states), we accept the plane wave type solution

though they are unnormalizable.

(3) If the potential possess space symmetry, i.e.  $ V(x)=V(-x) $ is an even function of space, then the solution wave function should be even or odd functions.

Comment: This is not as general as the previous two, only applies to even potential. The proof of this is as following:

If the  $ \psi(x) $ is a solution of 12-6, and if the  $ V(x)=V(-x) $, you make parameter change  $ x'=-x $, and you see right away that the  $ \psi(x')=\psi(-x) $ is also the solution to the same equation. Since the S-equation (12-6) is linear, so that combination of  $ \psi(x)+\psi(-x) $ (an even function) or  $ \psi(x)-\psi(-x) $ (an odd function) are also solutions. In 1-D problem, we can prove that the eigenstates

corresponding to certain energy is non-degenerate, i.e. only one state corresponds to every energy value (refer to problem 2.45 Griffiths). This means all the eigenstates corresponding to certain energy have to be linear dependent, meaning at most differ by a constant (a phase factor), since we proved that the even/odd functions are solutions, they will be the only possible solutions for even potential $ ^{65} $.

With above general discussions in mind, we can now proceed to solve the S-equation (12-6) by given certain types of potential forms. I shall start from the easiest infinite square potential well, illustrate the quantization of energy by boundary condition imposed (just like quantization on wave vector of standing wave in optics). Then I shall discuss step-like square potential barrier, we shall see reflection and transmission that differs from classical mechanics on particles (but quite analogous to wave behavior in optical Fresnel equation on reflection and transmission), we shall also observe evanescent wave behavior and tunneling effect if the barrier has limited width. Then we shall treat finite square potential well and harmonic potential. The treatment is systematic, combing the solution of (12-6) ODE and imposing proper boundary conditions.

## 12 -2 Infinite Square Potential Well

 $$ \begin{aligned}&\begin{vmatrix} \\{{{I}}} \\{{{\begin{vmatrix}}}} \\{{{II}}} \\{{{III}}} \\{{{V=0}}} \\\end{vmatrix}\\ &x=0\quad\quad x=a\\ \end{vmatrix}\\ \end{aligned} $$ 

The potential is given as:

 $$ V(x)=\begin{cases}0&0\leq x\leq a\\\infty&x>a,x<0\end{cases} $$ 

It is a squared well type and unrealistic due to infinity and discontinuity (the steep boundary) but simple to solve, and I divide the region in I, II and III. The strategy is to find solutions in these regions respectively and find those that meet the boundary conditions.

The region I and III are outside the well  $ (x<0, x>a) $. Because of the infiniteness of V in these two regions, the solution of S-equation with infinite V in region I and II could only be zero. This of course has very clear physical meaning, that due to the infinite potential barrier, the particle cannot escape the well at all (we do not have particle with infinite energy).

Let’s focus on rigation II inside the well, the S-equation is in forms of:

 $$ -\frac{\hbar^{2}}{2m}\frac{d^{2}\psi(x)}{d x^{2}}+0=E\psi(x) $$ 

Both energy eigenvalue E (we know it is >0 here, since total energy has to be larger than minimum of the potential) and wave function form need

to be determined.

Let's define:  $  k = \sqrt{2mE} / \hbar  $, the ODE becomes:

 $$ \frac{d^{2}\psi(x)}{d x^{2}}+k^{2}\psi(x)=0 $$ 

It has solution in the general form of:

 $$ \psi(x)=Ae^{ikx}+Be^{-ikx}=C\sin kx+D\cos kx $$ 

Above two expressions are equivalent (we had talked about this a while ago on solving the ODE for harmonic oscillator in classical mechanics) and you may choose either form, however a practical trick is the sine, cosine form will be easier to apply the boundary condition for the bound state.

Now we will use boundary (between region I and II, II and III) conditions at x=0 and x=a to determine the wave form and E value. We only have continuity of wave function here due to infinite potential jump.

At x=0, the boundary condition requires:

 $$ \psi_{_{II}}(0)=C\sin0+D\cos0=\psi_{_{I}}(0)=0\ ,then D=0 $$ 

The wave function will be in form of:

 $$ \psi_{II}(x)=C\sin kx $$ 

At x=a, we have:

 $ C \sin ka = 0 $

This requires:

 $$ ka=n\pi\rightarrow E=\frac{\hbar^{2}\pi^{2}}{2ma^{2}}n^{2}\quad n=1,2,3\ldots $$ 

The energy is thus quantized. This is actually not surprise from wave point of view, we see the relation like (12-8) in standing wave bounded by total reflective cavity! You see (12-8) is exactly same as the standing wave condition, due to exactly same wave form and boundary condition. The wave functions corresponding to energies are:

 $$ \psi_{_{n}}(x)=C\sin(\frac{n\pi}{a}x) $$ 

Using the normalization,  $ \int_{0}^{a}\psi^{*}\psi dx = 1 $ we get:

 $ \psi_{n}(x) = C\sin(\frac{n\pi}{a}x) = \sqrt{\frac{2}{a}}\sin(\frac{n\pi}{a}x) $ (12-9)

These wave functions are same (except the normalization factor) as standing waves in a total reflective cavity. The first couple functions were shown before, as following: (Griffiths, fig. 2.2)

<div style="text-align: center;"><img src="imgs/img_in_chart_box_185_962_430_1088.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_471_963_714_1089.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_754_964_997_1089.jpg" alt="Image" width="20%" /></div>


Comments: The following are just applications of the general principles we discussed before to this particular case.

(1) The states are actually either even or odd functions. The potential form we have above is not even symmetry, but we can shift the coordinate to make it even. From the general discussion before, the wave functions for even potential should be even or odd. Indeed if we shift the coordinate to make explicit symmetry, i.e.  $ V(x)=0 $, if  $ -a/2<x,+a/2 $,

you may solve this problem from beginning (do this as an exercise), or

use the results we obtained above, the functions in this case is just

shifted sines:

 $$ \psi_{_{n}}(x)=\sqrt{2/a}\sin(\frac{n\pi}{a}(x+\frac{a}{2}))=\begin{cases}\sqrt{2/a}\cos(\frac{n\pi}{a}x)&n\text{odd}\\\sqrt{2/a}\sin(\frac{n\pi}{a}x)&n\text{even}\end{cases} $$ 

(2) These wave functions (stationary states, the eigen-functions of energy) do form orthonormal basis. The orthogonal condition is obvious due to sinusoidal functions. The completeness is usually an assumption, but here in this case, it is from completeness of Fourier expansion.

(3)Other measurement probability can be calculated knowing the wave functions. For example, the expectation value of X and P are:

 $$ \begin{aligned}&<X>_{\psi_{n}}=<\psi_{n}\mid X\mid\psi_{n}>=<\psi_{n}\mid x><x\mid X\mid\psi_{n}>dx=\int\psi_{n}^{*}x\psi_{n}dx\\ &\\&<P>_{\psi_{n}}=\int<\psi_{n}\mid x><x\mid P\mid\psi_{n}>dx=-i\hbar\int\psi_{n}^{*}\frac{d\psi_{n}}{dx}dx\quad(12\\ \end{aligned} $$ 

They are zero for the stationary states due to odd even symmetry. For the  $ \langle X^{2}\rangle $ and  $ \langle P^{2}\rangle $, you may carry out the calculation, and verify the uncertainty relation is indeed satisfied, the  $ (\Delta x)^{2} \equiv \langle X^{2} \rangle - \langle X \rangle^{2} $, the root mean squared deviation. (Griffith's problem 2.4)

(4) Time evolution of an arbitrary initial state.

If at t=0, we have a state that is not one of the eigenstates, as we have discussed in last chapter, the general strategy is: Expand the state on basis of stationary states,

 $$ \begin{aligned}&\psi(x,t=0)=\sum_{n}c_{n}\psi_{n}(x)\\&c_{n}=\int\psi_{n}^{*}\psi(x,t=0)dx\\ \end{aligned} $$ 

Then the time evolution is:

 $$ \psi(x,t)=\sum_{n}c_{n}e^{-i\omega_{n}t}\psi_{n}(x)\quad\omega_{n}=\frac{E_{n}}{\hbar} $$ 

The expectation values of various physical properties then can be calculated.

## 12 -3 Potential Step and Barrier

It may seem natural to discuss the finite square well next, but it turns out it is easier to discuss simple potential step first. For the infinite well above, all the physical possible states are “bound states”, meaning restricted by the potential. For potential with finite height, we will encounter states with higher energy (E>V_{max}) which are extended all over space, these are unbound states (also called scattering states). We have seen this in case of free space (V=0 everywhere), and the potential barrier here is another example, where we will see reflection and transmission (corresponding to probability of particle bounced back or shoot through the barrier). We shall define the probability current associated with wave function (analogous to energy flux Poynting vector associated with EM wave), and use it to calculate the reflection and transmission coefficients (analogous to Fresnel equations in optics). We shall see wave behavior which is strange in classical particle sense, the evanescent wave and

tunneling effect.

The simplest potential to illustrate above is a square potential step, and that is what we first discuss in this section, then we shall discuss finite square potential barrier.

The general strategy is same as that in infinite potential well, I shall repeat again here:

(1)We divide the regions given the potential form, since within each region, the S-equation (time independent) have simple solutions due to the simple potential form in that region.

(2) Apply the boundary (separate regions) conditions (continuity of wave function and its first space derivative when applies) to find the suitable general solutions, i.e. use boundary conditions to determine the unknown parameters (usually within a common normalization factor)

## 12 -3-1 Potential Step

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_1133_651_1317.jpg" alt="Image" width="34%" /></div>


The potential is shown above, its form is:

 $$ V(x)=V_{0}\theta(x)=\begin{cases}V_{0}&x>0\\ 0&x<0\end{cases}\quad\theta(x)is step function $$ 

First, let's talk about classical picture: It is like a car rolling up a very

steep uphill. If the initial energy is larger than the potential  $ V_{0} $, the car will roll up the hill (or we say 100% pass it); if the E is less, then the car will roll back (or we say 100% reflected). We will see results of quantum will be quite different due to the wave nature.

It is helpful we divide the energy E in two cases:

(a)  $ E \geq V_0 $

(b)  $ 0 < E \leq V_0 $ Here we shall see evanescent wave in x > 0 region.

Of course you may choose not to make such division at the beginning, but will come to same consideration in the due process.

## (a) When  $ E \geq V_{0} $

In region I (x ≤ 0), we have

 $$ \frac{d^{2}\psi(x)}{d x^{2}}+k_{1}^{2}\psi(x)=0\quad k_{1}=\sqrt{2m E}\Big/\hbar $$ 

In region II, we have

 $$ \frac{d^{2}\psi(x)}{d x^{2}}+k_{2}^{2}\psi(x)=0\quad k_{2}=\sqrt{2m(E-V_{0})}\bigg/\hbar $$ 

The general solutions of (12-14), (12-15) are obvious:

 $$ \begin{aligned}&\psi_{I}(x)=Ae^{ik_{1}x}+Be^{-ik_{1}x}\\ &\\ &\psi_{II}(x)=Ce^{ik_{2}x}+De^{-ik_{2}x}\\ \end{aligned} $$ 

These are the stationary state with energy E, their time evolution are simple, just attach  $ e^{-i\omega t} $,  $ \omega = E/\hbar $.

We have finished step (1) in our general strategy. Let's pause a while to see what these general solutions tell us, the two terms in each

solution corresponding to a plane wave (once we plugging the time factor in) travelling towards left and right.

Now let's carry out step (2), applying boundary requirement (the continuity of  $ 1^{st} $ derivative applies here in finite potential case):

 $$ \begin{aligned}&A+B=C+D\\&k_{1}(A-B)=k_{2}(C-D)\\ \end{aligned} $$ 

The two relations cannot determine the relative ratio between them (need at least 3 independent relations for that), I shall rewrite above in matrix form, so that you see what kind of relations they provide:

 $$ \begin{pmatrix}{{{1}}}&{{{1}}} \\{{{k_{1}}}}&{{{-k_{1}}}}\end{pmatrix}\begin{bmatrix}{{{A}}} \\{{{B}}}\end{bmatrix}=\begin{pmatrix}{{{1}}}&{{{1}}} \\{{{k_{2}}}}&{{{-k_{2}}}}\end{bmatrix}\begin{bmatrix}{{{C}}} \\{{{D}}}\end{bmatrix}\quad(I just express above in matrix) $$ 

This can be used to get:

 $$ \begin{bmatrix}C\\ D\end{bmatrix}=M\begin{bmatrix}A\\ B\end{bmatrix} $$ 

M is called M matrix or transfer matrix, just one useful way to express the relation between coefficients. Another variation which is more often used is S matrix, defined as:

 $$ \begin{bmatrix}\boldsymbol{B}\\ \boldsymbol{C}\end{bmatrix}=\boldsymbol{S}\begin{bmatrix}\boldsymbol{A}\\ \boldsymbol{D}\end{bmatrix} $$ 

It is called S matrix or scattering matrix, because above shows if we have two incoming waves from left and right initially (represented by the A, D part), the component of outgoing wave (represented by B, C) can be known from S matrix. The M and S matrix here are (verify mine yourself please, by working out the relation between the

elements of S and M matrix first):

 $$ M=\left[\begin{array}{cc}\frac{k_{1}+k_{2}}{2k_{2}}&\frac{k_{2}-k_{1}}{2k_{2}}\\\frac{k_{2}-k_{1}}{2k_{2}}&\frac{k_{1}+k_{2}}{2k_{2}}\end{array}\right] $$ 

 $$ S=\begin{bmatrix}\frac{k_{1}-k_{2}}{k_{1}+k_{2}}&\frac{2k_{2}}{k_{1}+k_{2}}\\ \frac{2k_{1}}{k_{1}+k_{2}}&\frac{k_{2}-k_{1}}{k_{1}+k_{2}}\end{bmatrix} $$ 

Of course the S and M matrix are related, you can easily derive their relation (Griffiths problem 2.53). The boundary conditions fixed the S (or M) matrix, their expressions explicitly given above; and to know the relation between various components, we need to know clearly the initial condition.

Let's assume we only have waves travelling towards right at the beginning, there will be no waves in region II travelling towards left then, so that this put limit D=0, and now we can find ratios between components, directly read from (12-19) and (12-21) with D=0:

 $$ \frac{B}{A}=\frac{k_{1}-k_{2}}{k_{1}+k_{2}};\frac{C}{A}=\frac{2k_{1}}{k_{1}+k_{2}} $$ 

Of course for this simple problem, you can directly derive this relation without bothering the M or S matrix, the point here is of course introducing a systematic matrix way treating the boundary conditions. I do not pursue the normalization to get A here, because such scattering state cannot be normalized. Also the boundary conditions

here for the scattering state do not fix the energy (we do not have quantization of k), which is kind of expected if we recall the standing wave case in optics, the one end cavity does not put restriction on k at all.

You may also expect the relation (12-22) is related to the reflection and transmission coefficients. That is very good guess (look it and compare the Fresnel equation for normal illuminations in 1-D, you see the similarity between k and n, the index refraction in optics, I shall argue their relation later), but first I shall digress to discuss the probability current and define clearly what are reflection and transmission here.

## Digression: Probability Current in Quantum

We have learned current associated with local conservation of certain physical property in classical physics. The familiar one is the local conservation of charge, the total charge of a closed system is conserved (global conservation), also the local change of charge will associate to an electrical current (local conservation), i.e.

 $$ \frac{\partial\rho(r,t)}{\partial t}+\nabla\cdot\vec{j}(r,t)=0 $$ 

This tells us the local change of charge has to equal to the negative

divergence of current density, thus the decrease of charge locally will

equal to the flow of current out of the enclosed surface (Gauss

theorem).

In quantum mechanics, we have the total probability  $ \langle \psi \rangle $ is conserved (always 1 for normalized  $ \mid \psi \rangle $), and we will see that for the wave function satisfying S-equation, we can define a probability current, so that the local conservation is also satisfied, here is how (I only use 1-D for derivation and extend result to 3-D):

 $$ i\hbar\frac{\partial\psi}{\partial t}=(-\frac{\hbar^{2}}{2m}\frac{d^{2}}{d x^{2}}+V)\psi $$ 

The local probability density is clearly:

 $$ \rho(x,t)=\psi^{*}\psi $$ 

And

 $$ \frac{\partial\rho(x,t)}{\partial t}=\psi^{*}\frac{\partial\psi}{\partial t}+\psi\frac{\partial\psi^{*}}{\partial t} $$ 

To get something similar to 12-23, this suggest we multiply  $ \psi^* $ to the S-equation, and  $ \psi $ to the conjugate of S-equation and subtract them (since i changes sign in conjugation), resulting:

 $$ \frac{\partial\rho}{\partial t}+\frac{\hbar}{2m i}[\psi^{*}\frac{d^{2}}{d x^{2}}\psi-\psi\frac{d^{2}}{d x^{2}}\psi^{*}]=0 $$ 

In the l-D case, the divergence is simple d/dx, the second part of the above can be written as:

 $$ \frac{\hbar}{2mi}[\psi^{*}\frac{d^{2}}{dx^{2}}\psi-\psi\frac{d^{2}}{dx^{2}}\psi^{*}]=\frac{\hbar}{2mi}\frac{d}{dx}[\psi^{*}\frac{d\psi}{dx}-\psi\frac{d\psi^{*}}{dx}] $$ 

We have then:

 $$ j(x,t)\equiv\frac{\hbar}{2mi}[\psi^{*}\frac{d\psi}{dx}-\psi\frac{d\psi^{*}}{dx}]=\frac{1}{m}\mathrm{Re}[\psi^{*}\frac{\hbar}{i}\frac{d\psi}{dx}] $$ 

This is the probability current in 1-D case. In 3-D, it is:

 $$ \vec{j}(r,t)=\frac{\hbar}{2m i}[\psi^{*}\nabla\psi-\psi\nabla\psi^{*}]=\frac{1}{m}\mathrm{R e}[\psi^{*}\frac{\hbar}{i}\nabla\psi] $$ 

The reason to write it as last part is to show this current is related to probability amplitude (the wave function) and momentum, which is indeed what a current is about (density times velocity).

With the above definition of probability current (12-24), we can calculate it for a plane wave type function, for if

 $$ \begin{aligned}&\psi(x,t)=A e^{i(kx-\omega t)}\\ &\\ &j(x,t)=\mid A\mid^{2}\frac{\hbar k}{m}\\ \end{aligned} $$ 

Where  $ |A|^{2} $ is the probability density and  $ \frac{\hbar k}{m} $ is related to velocity. This is analogous to the intensity (Poynting vector) in EM wave, the energy flow is related to amplitude square and velocity (there expressed as index of refraction and c)

For the wave function given in (12-16) and (12-17), (12-16) corresponds to an initial plane wave with amplitude A and a reflected wave with amplitude B, and (12-17) a plane wave transmitted with amplitude C (D=0) so:

 $$ j_{i n i}=\frac{\hbar k_{1}}{m}\left|\begin{array}{l l}A\end{array}\right|^{2}\quad j_{r e f}=\frac{\hbar k_{1}}{m}\left|\begin{array}{l}B\end{array}\right|^{2}\quad j_{t r a n s}=\frac{\hbar k_{2}}{m}\left|\begin{array}{l}C\end{array}\right|^{2} $$ 

Now we can define the reflection and transmission as ratio between the reflected and transmitted current versus the initial, thus:

 $$ R=\frac{j_{r e f}}{j_{i n i}}=|\frac{B}{A}|^{2}\quad T=\frac{j_{t r a n}}{j_{i n i}}=\frac{k_{2}}{k_{1}}|\frac{C}{A}|^{2} $$ 

Note the transmission ratio T has extra ratio of k besides probability density, since the two waves have different momentum in the two regions (Analogous to the R, T in optics). We see that by knowing the S matrix, we learned ratio of the amplitude and thus the R and T, put the (12-22) into (12-28), we have for the step potential, and E>V₀:

 $$ R=\left(\frac{k_{1}-k_{2}}{k_{1}+k_{2}}\right)^{2}\quad T=\frac{4k_{1}k_{2}}{\left(k_{1}+k_{2}\right)^{2}} $$ 

As this relation shows, even in the E>V₀ case, there is reflection and the transmission ratio is less than 1. It is the result of wave behavior of the ‘particle’ (duality). Of course it is clearly T+R=1.

(b) $ 0 \leq E \leq V_{0} $

In region I, same form of wave function as above; in the region 2, with  $ k_2' = \sqrt{2m(V_0 - E)} / \hbar $, the equation is:

 $$ \frac{d^{2}\psi_{_{II}}}{d x^{^{2}}}-k_{_{2}}^{\prime2}\psi_{_{II}}=0 $$ 

The general form of solution becomes:

 $$ \begin{aligned}&\psi_{I}(x)=Ae^{ik_{1}x}+Be^{-ik_{1}x}\\&\psi_{II}(x)=Ce^{k^{\prime}_{2}x}+De^{-k^{\prime}_{2}x}\\ \end{aligned} $$ 

The C has to be zero, otherwise the wave function will explode in

region II, and so the physical meaningful solution in region II is:

 $$ \psi_{_{II}}(x)=De^{-k^{\prime}_{2}x} $$ 

Now applying the boundary conditions:

 $$ A+B=D $$ 

 $$ i k_{1}(A-B)=-k_{2}^{\prime}D $$ 

We do not need M or S matrix method for this simple case, we have:

 $$ \frac{B}{A}=\frac{k_{1}-ik_{2}^{\prime}}{k_{1}+ik_{2}^{\prime}}\quad\frac{D}{A}=\frac{2k_{1}}{k_{1}+ik_{2}^{\prime}} $$ 

The reflected current is same as case (a); for the transmitted current, it is zero here, because the exponential dependence on x is real in region II, the two conjugate parts in (12-24) are same and cancel. Thus:

 $$ R=\mid\frac{k_{1}-ik_{2}^{\prime}}{k_{1}+ik^{\prime}}\mid^{2}=1\quad T=0 $$ 

So there will be total reflection with no transmission. However, just analogous to the total internal reflection in optics, the probability wave in the classical forbidden region II is not zero, but decays exponentially (12-31), it is an evanescent wave. The particle can penetrate into the forbidden region, and then bounced back, and thus the reflected wave will have some extra phase difference comparing to the initial one. In our infinite wide potential step, such evanescent wave dies quickly with increasing x. We will expect if the potential barrier becomes narrow; the particle with less energy than the barrier may penetrate into the barrier, and leak to the other side. That is the tunneling effect we shall see next in finite potential barrier.

As a conclusion remark on this section, let me further illustrate analogy here and that in optics. I hope I have convinced you there is great similarity between them. This is not a surprise but as expected, since both are waves described by the same mathematical wave functions (but different physical interpretation).

The time-independent S equation is in forms of:

 $$ \frac{d^{2}\psi}{d x^{2}}+\frac{2m(E-V)}{\hbar^{2}}\psi=0 $$ 

The wave equation in 1-D from Maxwell equations of EM wave in a media with index n is:

 $$ \frac{\partial U^{2}}{\partial x^{2}}-\frac{n^{2}}{c^{2}}\frac{\partial^{2}U}{\partial t^{2}}=0 $$ 

Taking the U in a standard plane wave form with time dependence of  $ e^{-i\omega t} $, we have:

 $$ \frac{\partial U^{2}}{\partial x^{2}}+\frac{n^{2}\omega^{2}}{c^{2}}U=0 $$ 

The two differential equations will be same, if we make substitution:

 $$ \begin{aligned}&k^{2}\equiv\frac{2m(E-V)}{\hbar^{2}}=\frac{n^{2}\omega^{2}}{c^{2}}\\ &or\ n=\frac{kc}{\omega}\\ \end{aligned} $$ 

The two equations will be same, and k is what we called wave vector before. The boundary conditions here is continuity of wave and its  $ 1^{st} $ derivative; while in optics, it is continuity of the electro and magnetic field, but this continuity can be demonstrated for the 1-D plane wave

same as continuity of E field and its  $ 1^{st} $ derivative (please do this yourself as an exercise). Since the equation and boundary conditions are essentially same, no surprise we get same result: with relation (12-34), the R and T derived here were same as those in Fresnel equations in optics.

## 12 -3-2 Potential Barrier

In this section, we consider the square V barrier with width a:

<div style="text-align: center;"><img src="imgs/img_in_image_box_276_649_648_819.jpg" alt="Image" width="31%" /></div>


 $$ V(x)=\begin{cases}V_{0}&0<x<a\\0&everywhere else\end{cases} $$ 

 $$ (a)\mathrm{E}\geqq\mathrm{V}_{0} $$ 

We consider solutions in 3 regions and join those using boundary conditions.

The stationary wave functions in I, II, III are:

 $$ \begin{aligned}&\psi_{_{I}}=Ae^{ik_{1}x}+Be^{-ik_{1}x}\quad k_{_{1}}=\sqrt{2mE}\bigg/\hbar\\&\psi_{_{II}}=Ce^{ik_{2}x}+De^{-ik_{2}x}\quad k_{_{2}}=\sqrt{2m(E-V_{_{0}})}\bigg/\hbar\\&\psi_{_{III}}=Fe^{ik_{1}x}+Ge^{-ik_{1}x}\\ \end{aligned} $$ 

Their time evolution form will just attach the  $ e^{-t-\frac{t}{h}} $. The boundary at x=0 and x=a will give us:

 $$ \begin{aligned}&A+B=C+D\\&k_{1}(A-B)=k_{2}(C-D)\quad(12-36)\\&Ce^{ik_{2}a}+De^{-ik_{2}a}=Fe^{ik_{1}a}+Ge^{-ik_{1}a}\\&k_{2}(Ce^{ik_{2}a}-De^{-ik_{2}a})=k_{1}(Fe^{ik_{1}a}-Ge^{-ik_{1}a})\\ \end{aligned} $$ 

The strategy is to eliminate the C and D, to get relation between A, B, F, G, which are related to the reflection and transmission. It is quite nasty calculation, the systematic way is to use matrix form of (12-36) and (12-37), from (12-36), we can get

 $$ \begin{aligned}&\begin{bmatrix}C\\ D\end{bmatrix}=\begin{bmatrix}matrix}matrix\\ matrix1\end{bmatrix}\begin{bmatrix}A\\ B\end{bmatrix},then using(12-37)to get:\\ &\begin{bmatrix}F\\ G\end{bmatrix}=\begin{bmatrix}matrix}matrix\\ matrix2\end{bmatrix}\begin{bmatrix}C\\ D\end{bmatrix}=M\begin{bmatrix}A\\ B\end{bmatrix}\\ \end{aligned} $$ 

The transfer matrix M can be calculated this way, and we can relate F, G with A, B. If we set the initial condition so that only have waves travelling towards right, then G=0. We can get ratio between B/A and F/A which are related to reflection and transmission. However, the calculation even using matrix is lengthy and tedious, I skipped steps, only give the result (please test it yourself as a challenge for your computation ability):

 $$ \begin{aligned}\frac{F}{A}=&4k_{1}k_{2}e^{-ik_{1}a}[(k_{1}+k_{2})^{2}e^{-ik_{2}a}-(k_{1}-k_{2})^{2}e^{ik_{2}a}]^{-1}\\=&4k_{1}k_{2}e^{-ik_{1}a}[4k_{1}k_{2}\cos(k_{2}a)-2i(k_{1}^{2}+k_{2}^{2})\sin(k_{2}a)]^{-1}\end{aligned} $$ 

I shall not write the B/A, since F/A will allow us to get T and using T+R=1 to get R.

Using the probability current expression (12-27) for plane waves in

region I and III (with G=0), we have:

 $$ T=\frac{k_{1}}{k_{1}}\vert\frac{F}{A}\vert^{2}=\frac{4k_{1}^{2}k_{2}^{2}}{4k_{1}^{2}k_{2}^{2}+(k_{1}^{2}-k_{2}^{2})^{2}\sin^{2}(k_{2}a)}=\left[1+\frac{1}{4}(\frac{k_{1}^{2}-k_{2}^{2}}{k_{1}k_{2}})^{2}\sin^{2}(k_{2}a)\right]^{-1} $$ 

This form is quite like the Airy function in Fabry_Perot case and different from classical particle prediction where T=1 when E>V₀.

Using T+R=1, we get (an honest calculation should get B/A from M matrix and then the R form, and indeed the R+T=1 satisfied):

 $$ \begin{aligned}&R=\frac{(k_{1}^{2}-k_{2}^{2})^{2}\sin^{2}(k_{2}a)}{4k_{1}^{2}k_{2}^{2}+(k_{1}^{2}-k_{2}^{2})^{2}\sin^{2}(k_{2}a)}\quad(12-40)\\ &Since\quad(\frac{k_{1}^{2}-k_{2}^{2}}{k_{1}k_{2}})^{2}=\frac{V_{0}^{2}}{E(E-V_{0})}=\frac{1}{\varepsilon(\varepsilon-1)}\quad\varepsilon=\frac{E}{V_{0}}\\ \end{aligned} $$ 

The above T, R can be expressed as:

 $$ T=[1+\frac{1}{4\varepsilon(\varepsilon-1)}\sin^{2}(k_{2}a)]^{-1} $$ 

 $$ R=\frac{\sin^{2}(k_{2}a)}{4\varepsilon(\varepsilon-1)+\sin^{2}(k_{2}a)} $$ 

The transmission is maximum (T=1) whenever:

 $$ k_{2}a=m\pi,m=1,2,3\ldots $$ 

The relation is called resonance condition and the scattering satisfying it is called resonance scattering. This is not very surprise if we recall the F-P case, where we have  $ 2kl = 2m\pi $ (same as 12-42), then all the transmitted wave due to multireflection will be in phase, another way of saying is the incoming light is in resonance with the cavity mode (standing wave), and thus the output is maximum.

(b) $ 0 \leq E \leq V_{0} $

We expect difference in region II where the wave function will be with real exponent. The wave forms in region I and III will be exactly same as case (a). In region II, the wave function is in forms of:

 $$ \psi_{_{II}}=C e^{k_{2}^{\prime}x}+D e^{-k_{2}^{\prime}x}\quad k_{2}^{\prime}=\sqrt{2m(V_{_{0}}-E)}\bigg/\hbar $$ 

Because the x is limited between 0 and a, so both parts (C and D) are acceptable.

The boundary conditions are:

 $$ \begin{aligned}&A+B=C+D\\&ik_{1}(A-B)=k_{2}^{\prime}(C-D)\quad(12-44)\\&Ce^{k_{2}^{\prime}a}+De^{-k_{2}^{\prime}a}=Fe^{ik_{1}a}+Ge^{ik_{1}a}\\&k_{2}^{\prime}(Ce^{k_{2}^{\prime}a}-De^{-k_{2}^{\prime}a})=ik_{1}(Fe^{ik_{1}a}-Ge^{ik_{1}a})\\ \end{aligned} $$ 

You may carry out honest computation to get M matrix relating A, B and F, G, but actually there is an easier way. We see that boundary conditions will be exactly same as (12-36) and (12-37) in case (a), if replacing  $ k_{2}^{\prime}=ik_{2} $. This suggests that we can replace the  $ k_{2} $ in (12-38) (or in the M matrix elements) with  $ -ik_{2}^{\prime} $:

 $$ \frac{F}{A}=e^{-ik_{1}a}[\cosh(k_{2}^{\prime}a)+\frac{i(k_{2}^{\prime2}-k_{1}^{2})}{2k_{1}k_{2}^{\prime}}\sinh(k_{2}^{\prime}a)]^{-1}\qquad67 $$ 

 $$ \begin{aligned}T=&\mid\frac{F}{A}\mid^{2}=[\cosh^{2}(k_{2}^{\prime}a)+\frac{(k_{2}^{\prime2}-k_{1}^{2})^{2}}{4k_{1}^{2}k_{2}^{\prime2}}\sinh^{2}(k_{2}^{\prime}a)]^{-1}\\=&[1+\frac{(k_{2}^{\prime2}+k_{1}^{2})^{2}}{4k_{1}^{2}k_{2}^{\prime2}}\sinh^{2}(k_{2}^{\prime}a)]^{-1}\\ Since&\frac{(k_{2}^{\prime2}+k_{1}^{2})^{2}}{4k_{1}k_{2}^{\prime2}}=\frac{V_{0}^{2}}{E(V_{0}-E)}=\frac{1}{\varepsilon(1-\varepsilon)},\varepsilon\equiv\frac{E}{V_{0}},\\T=&[1+\frac{1}{4\varepsilon(1-\varepsilon)}\sinh^{2}(k_{2}^{\prime}a)]^{-1}\quad(12-47)\end{aligned} $$ 

This shows the transmission of particle even when its energy is less than the potential barrier, an impossible in classical mechanics. This leak out of the high potential barrier is called tunneling, and had been demonstrated in numerous cases, such as the flip of molecular configuration (such as NH₃ configuration inversion); the alpha decay in some nuclei, etc. The most important technology applying this effect is electron scanning tunneling microscope (STM) invented by IBM researchers.⁶⁸

We take a closer look on relation (12-47) and show that only in certain microscopic cases, the T is not practically zero. The magnitude of T depends on energy ratio  $ \varepsilon $, and especially on the size of barrier a. The  $ k'_{2} $ is on the order of de Broglie wave vector which means a should be less than the order of de Broglie wave length to have larger T. If the  $ k'_{2}a > 1 $, we shall see the T has exponential decay, dies quickly as a gets large:

 $$ \sinh(k_{2}^{\prime}a)\stackrel{k_{2}^{\prime}a>1}{\approx}e^{k_{2}^{\prime}a}\bigg/2 $$ 

And T can be approximated by  $ (1/(1+\text{big}) \sim 1/\text{big}) $:

 $$ T\approx16\varepsilon(1-\varepsilon)e^{-2k_{2}^{\prime}a} $$ 

It is usually defined a threshold for width of barrier:

 $$ a_{_{0}}=\frac{1}{k_{_{2}}^{\prime}}=\frac{\hbar}{\sqrt{2m(V_{_{0}}-E)}} $$ 

When  $ a < a_{0} $, the particle has considerable T and thus non-negligible tunneling effect. We see such threshold is extremely small for any macroscopic particle and that is we do not see tunneling in classical mechanics. For electron, the (12-49) becomes:

 $$ a_{_{0(e)}}\approx\frac{1.96\stackrel{\circ}{A}}{\sqrt{V_{_{0}}-E}}\;~e n e r g y~i n~e V $$ 

It is on the order of  $ \AA $, which is the scale of atom/molecule; for the heavier particle such as neutron, the width need to be  $ \sqrt[1]{\sqrt{1800}} $ smaller.

## 12 -4 Finite Square Potential Well

Let’s consider a potential well with width 2a and finite depth  $ V_{0} $:

 $$ \begin{aligned}&\overline{\quad}\quad\quad\quad\quad I\quad&\quad&\quad&\quad\quad\quad I I I\quad&\quad&V=0\\&\quad&\quad&\quad&\quad&\quad\quad\quad-V_{0}\quad&\quad&\quad\\&\quad&x=-a\quad&\quad&x=a\quad&\quad&\quad\end{aligned} $$ 

Without solving equations, we can guess the result using the results we had learned on other forms of potentials so far. (1) When  $ -V_{0} < E < 0 $, we expect to have bound state in region II and evanescent in region I and III. The bound state will be similar to that in infinite well, but due to finite depth, can leak into the forbidden region. (2) When E>0, we shall have unbound state (scattering state), and we will have reflection and transmission at the boundary separate regions. (3) Here I make the potential even, so we shall expect the wave functions be even or odd.

## (a) Bound state when  $ -V_{0}<E<0 $

The wave function in region I and III are:

 $$ \psi_{_{I}}=A e^{k_{1}x}\quad x\leq-a,\;k_{_{1}}=\sqrt{2m(-E)}\bigg/\hbar\quad(the other half will explode and $$ 

thus discarded)

 $$ \psi_{III}=Ge^{-k_{1}x}\quad x\geq a $$ 

In region II, we have:

 $$ \psi_{_{II}}=C\sin(k_{2}x)+D\cos(k_{2}x)\quad k_{2}=\sqrt{2m(V_{_{0}}+E)}\bigg/\hbar\quad-a<x<a $$ 

Now we can throw in the boundary conditions and proceed as before.

We could also exploit the requirement on the odd and evenness of the wave function here to simplify a bit.

For the even solution:

 $$ \psi_{_{I}}=A e^{k_{1}x},\psi_{_{II}}=D\cos(k_{2}x),\psi_{_{III}}=A e^{-k_{1}x} $$ 

We could only consider the boundary condition at one end, say x=a,

and the other end will satisfy automatically:

 $$ \begin{aligned}&D\cos(k_{2}a)=Ae^{-k_{1}a}\\&k_{2}D\sin(k_{2}a)=k_{1}Ae^{-k_{1}a}\\ \end{aligned} $$ 

Here we have 3 independent variable (A, D, and E energy, both k related to E) and 2 relations. Thus the condition set a limit on the possible energy (quantization), and once we know the possible energy, we could know the relation between A, D. Let's focus on the possible energies here. Divide the two relations in (12-52), we have:

 $$ k_{2}\tan(k_{2}a)=k_{1} $$ 

This is a transcendent equation and cannot be solved analytically. I shall first do some “cosmetics”:

Let:

 $$ \begin{aligned}&z\equiv k_{2}a\\ &since\ k_{1}^{2}+k_{2}^{2}=\frac{2mV_{0}}{\hbar^{2}}\\ &then\ k_{1}\bigg/k_{2}=\sqrt{\frac{2mV_{0}}{\hbar^{2}k_{2}^{2}}-1}=\sqrt{\frac{2ma^{2}V_{0}}{\hbar^{2}k_{2}^{2}a^{2}}-1}=\sqrt{\frac{z_{0}^{2}}{z^{2}}-1}\\ &z_{0}\equiv\frac{a\sqrt{2mV_{0}}}{\hbar}\qquad(12-55)\\ \end{aligned} $$ 

 $ z_{0} $ is known provides with  $ V_{0} $ and width

Equation (12-53) has the new form:

 $$ \tan(z)=\sqrt{\frac{z_{0}^{2}}{z^{2}}-1}\quad even states\qquad(12-56) $$ 

Above are for the even states, and for the odd states, we can get (prove it as exercise):

 $$ -\cot(z)=\sqrt{\frac{z_{0}^{2}}{z^{2}}-1}\quad odd states\qquad(12-57) $$ 

The equations can be used to determine z, and thus  $ k_{2} $ then the energy E for the even and odd states respectively. To determine the z satisfying either (12-56) or (12-57), we have to resort to graphical method, plot the  $ \tan(z) $ (or  $ -\cot $) and  $ \sqrt{\frac{z_{0}^{2}}{z^{2}}-1} $ curves and find their intersection.

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_589_831_859.jpg" alt="Image" width="48%" /></div>


This method is shown qualitatively above. Some general features are quite obvious from the graph:

(1) The allowed energies are quantized (z can only take certain values at the intersection), and its value will be less than the case of infinite well. There the  $ k(2a)=m\pi $ (since here the well’s width is 2a) gives us the allowed energy. Here for the finite well, the intersection happens below it, so the energy above the potential bottom will be less than the infinite  $ V_{0} $ case.

(2)  $ Z_{0} $ sets the limit on the number of bound states.  $ Z_{0} $ itself is set by the  $ V_{0} $ and a, the depth and width of the potential well. From the

graph, easy to see that the when the  $ \sqrt{\frac{z_{0}^{2}}{z^{2}}}-1 $ curve reaches 0 when  $ z=z_{0} $, so if  $ z_{0}\geq\frac{n}{2}\pi, n=0,1,2\ldots $, we have  $ n+1 $ intersections and these many bound states. For example, if  $ z_{0}<\frac{\pi}{2} $ (a narrow and shallow well), we can only have one intersection with the  $ \tan(z) $ curve, and there will be only one even bound state (the ground state). As  $ V_{0} $ approaches infinity, so will be the  $ z_{0} $, and the intersection z approaches the  $ \frac{n}{2}\pi $ ( $ n=1,2\ldots $) lines, which is the solution for the infinite well.

Once we find out the solutions for energies, we can use (12-52) to get the wave function (up to a normalization factor).

## (b) Scattering states when E>0

This problem is actually already been solved in the potential barrier case (the E>V₀ there), here the only differences are in the region II,  $ k_2 = \sqrt{2m(E + V_0)} / \hbar $ is defined slightly different than before, and the width is 2a. We plug all these into relation (12-39):

 $$ T=[1+\frac{1}{4}(\frac{k_{1}^{2}-k_{2}^{2}}{k_{1}k_{2}})^{2}\sin^{2}(k_{2}2a)]^{-1}=[1+\frac{1}{4\varepsilon(1+\varepsilon)}\sin^{2}(k_{2}2a)]^{-1} $$ 

 $ \varepsilon \equiv \frac{E}{V_0} $. We have a very similar expression and same resonance condition  $ k_2(2a) = m\pi $ for the maximum T.

This concludes our discussion on the simplest potential forms, we see that we can solve the S-equation quite easily and applying boundary conditions to get energy and/or relative coefficients. There are also some other simple and typical potential forms, one particular is the delta type potential which is covered in detail in Griffiths' book (section 2.5). There due to the infiniteness in the delta function, the  $ 1^{st} $ derivative of wave function is not continuous at the boundary. However, using the property of delta function, there is a simple relation on the change of  $ 1^{st} $ derivatives. Please read on the delta potential yourself.

Such square or delta type potential are usually what we used at the beginning to understand the qualitative behavior on the more sophisticated potential forms. For most sophisticated potentials whose exact solution may not be solved analytically and we have to apply approximation methods, such as the perturbation or WKB method. In the following section, we shall talk two more kinds of problems which are more complex than the square type, but still simple enough to have exact solutions. These are harmonic potentials, and single electron in central field potential (Hydrogen atom).

### 12.5 Harmonic Oscillator

The potential in space representation is in form of:

 $$ V(x)=\frac{1}{2}kx^{2} $$ 

We have seen the importance of harmonic oscillator in classical physics. It also has many important applications in quantum, such as molecular vibration; the quantum field theory (where the field will be treated as a collection of harmonic-like operators) etc.

We can solve this problem by the formalism we have used by now in this chapter, i.e. directly solve the differential equation and apply the boundary condition. This is called analytic method and I shall discuss in somewhat detail here. This is a quite straightforward (knowing the potential and attack the equation directly) method but with messy mathematics. However, similar method will be used in solving the solution for hydrogen atom, so it is worth going through all this mess.

There is another quite different but clean and elegant way of solving this problem, by using operator property (first used by Dirac), constructing the so called creator and annihilator. This is called algebra or operator method, and will be used not only in harmonic oscillator, but also in angular momentum. Such method will not be discussed in detail here and its treatment will be left for later quantum course $ ^{69} $. This unfortunately means we may not be able to use some powerful tools and methods in dealing with problems on harmonic oscillator.

The focus in this section is to show the energy spectrum of the oscillator

and its wave function form. The strategy of the analytic method is same as before: writing out the differential equation, guess the general form of the wave function, and using boundary condition to see what kind of requirement it puts on solution. Here since the potential changes continuously all over space and up to infinity, states with all energy will be bounded and the boundary condition is that the states should be normalizable.

You should be able to guess the general shape of the wave function from what we had discussed on the infinite square potential. The wave function will be something similar, but can leak out of the potential here. For the lowest states, they are somethings like:

<div style="text-align: center;"><img src="imgs/img_in_image_box_191_911_469_1126.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_486_865_711_958.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_729_847_953_936.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_486_983_710_1131.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_731_1014_954_1118.jpg" alt="Image" width="18%" /></div>


Of course the details have to be solved rigorously as following:

(1) The S-equation and general solution form

 $$ (-\frac{\hbar^{2}}{2m}\frac{d^{2}}{dx^{2}}+\frac{1}{2}kx^{2})\psi=E\psi $$ 

Let's make some cosmetic to make equation looks better:

 $$ \omega^{2}\equiv\frac{k}{m},\xi\equiv\sqrt{\frac{m\omega}{\hbar}}x,K\equiv\frac{2E}{\hbar\omega} $$ 

We basically rescale the position and energy above, and (12-60) becomes:

 $$ \frac{d^{2}}{d\xi^{2}}\psi+(K-\xi^{2})\psi=0 $$ 

Let’s first take a look on the asymptote behavior of the equation, when  $ x(or \xi) \to \pm \infty $, where we can neglect the K term and the equation is in forms of:  $ \frac{d^2}{d\xi^2}\psi - \xi^2\psi = 0 $

It is not hard to guess the asymptote solution will be in the general form of:  $ \psi(\xi) = A e^{-\frac{\xi^2}{2}} + B e^{\frac{\xi^2}{2}} $, we can reject the B part on the ground that it explodes for large x and won’t be normalizable, thus the asymptotic solution has to be in forms of:  $ \psi(\xi) \to e^{-\frac{\xi^2}{2}} $. For very large x, the exponential term will dominate; for any  $ \xi $, the A is not a constant here; otherwise it won’t solve the equation. So we use the polynomial method, guess the solution may be in form of:

 $$ \psi(\xi)=h(\xi)e^{-\frac{\xi^{2}}{2}} $$ 

The h( $ \xi $) is a polynomial whose coefficients need to be determined, and we hope in the due process we can also get possible K (or E) values.

The general form of  $ h(\xi) $ part is:

 $$ h(\xi)=a_{0}+a_{1}\xi+a_{2}\xi^{2}+\ldots=\sum_{j=0}^{\infty}a_{j}\xi^{j} $$ 

(2) The recursion formula for the polynomial

We can actually do better in the guess on the form of polynomial, using the even symmetry of the potential form. The solution then has to be either even or odd functions, meaning the polynomial contain either even or odd power, i.e. the solution should be:

 $$ \begin{aligned}&h_{even}(\xi)=a_{0}+a_{2}\xi^{2}+a_{4}\xi^{4}+\ldots\\&h_{odd}(\xi)=a_{1}\xi+a_{3}\xi^{3}+a_{5}\xi^{5}+\ldots\\ \end{aligned} $$ 

In the derivation on relations of the coefficients, I shall combine the above two in one form:

 $$ h(\xi)=\xi^{p}(a_{0}+a_{2}\xi^{2}+\ldots)=\xi^{p}\sum_{m=0}^{\infty}a_{2m}\xi^{2m} $$ 

Here, the power p in the  $ \xi^{p} $ can be either 0 or 1 corresponding to the even or odd series $ ^{70} $.

Throw the form of wave function (12-63) into equation (12-62), we get equation on $h(\xi)$ polynomial after cancel the exponential part:

 $$ \frac{d^{2}h}{d\xi^{2}}-2\xi\frac{dh}{d\xi}+(K-1)h=0 $$ 

Throw in the form of h (12-65) in, this will give us relations between the coefficients (recursion formula):

 $$ \sum_{m}(2m+p)(2m+p-1)a_{2m}\xi^{2m+p-2}-\sum_{m}[2(2m+p)+K\textcircled{m}1]a_{2m}\xi^{2m+p}=0 $$ 

Group the coefficients for the same power, say  $ \xi^{2m+p} $, and for the series equals zero (variables are linear independent), the coefficient has to be zero. In the grouping the index m in the first half has to be  $ m+1 $ to have same  $ \xi $ power as the second half, then:

 $$ \begin{aligned}&(2m+2+p)(2m+p+1)a_{2m+2}-[2(2m+p)+K\underset{ 伱 }{=}a_{2m}=0\\ &\\ &a_{2m+2}=\frac{2(2m+p)+1-K}{(2m+p+2)(2m+p+1)}a_{2m}\quad(12-67)\\ \end{aligned} $$ 

This is the recursion formula $ ^{71} $. For the p=0 (even series), if we know the K (energy) and the first coefficient  $ a_{0} $, the rest can be known. For the p=1 case, if we know the K and first coefficient  $ a_{0} $ (same as  $ a_{1} $), the rest can be known.

(3) Boundary condition and truncation of the polynomial, quantization of energy

Now since we have the recursion formula, though we do not know

exact form of the polynomial (need K and initial coefficients for that),

we can study the asymptote behavior (I mean when the x (or  $ \xi $) is

large, what this polynomial approaches) and combined with

exponential part  $ e^{-\frac{\xi^{2}}{2}} $ to see whether it is normalizable.

For the large  $ \xi $, the higher powers (large m) will dominate. The

recursion formula (12-67) then can be approximated when m is large:

 $ \frac{a_{2m+2}}{a_{2m}} \rightarrow \frac{1}{m} $, or the ratio between adjacent terms in power series is

$$\frac{\xi^{2}}{m}.$$ From this, you see that if the $h(\xi)$ has infinite terms, it will

approach an exponential at large $\xi$, because:

e^{\xi^2} = \sum_{m=0}^{\infty} \frac{1}{m!} \xi^{2m}, the ratio between adjacent terms is also  $ \frac{\xi^2}{m} $. So the asymptote behavior of  $ h(\xi) $ will be proportional to  $ e^{\xi^2} $. (The reason for proportion is that we only compare the ratio above. For the odd series, p=1 case, the series actually proportional to  $ \xi e^{\xi^2} $) But such asymptote behavior is physically unacceptable, because this means the wave function which is  $ h(\xi)e^{-\frac{\xi^2}{2}} $, at large  $ \xi $, will be like  $ \frac{\xi^2}{e^2} $, renders the wave function normalization impossible.

The above argument is based on the $h(\xi)$ has infinite terms, and higher order terms dominate at large $\xi$; so the way out of the unnormalizable dilemma requires the series only has limited terms, i.e. the series truncates at certain $m$, and higher order terms are all zero. I use $m_0$ to label this largest $m$ of nonzero term, meaning the largest power in the series is $a_{2m_0}\xi^{2m_0}$, with nonzero $a_{2m_0}$. The next higher term $a_{2m_0+2}\xi^{2m_0+2}$ is zero only if the $a_{2m_0+2}=0$, and the rest of higher terms will also be zero from the recursion formula. Using the recursion formula (12-67), we see that $a_{2m_0+2}=0$, $a_{2m_0}\neq 0$ means:

 $$ \frac{2(2m_{0}+p)+1-K}{(2m_{0}+p+2)(2m_{0}+p+1)}=0\quad or $$ 

 $$ K=2(2m_{0}+p)+1 $$ 

Let  $ n \equiv 2m_{0} + p $ (12-69)

Since  $ m_{0} $ is an integer 0, 1, 2... (Depend on number of nonzero terms in the series), p=0 or 1, so n is an integer whose value can be 0, 1, 2, 3... Put in relation between K and E in (12-61):

 $$ E_{n}=(n+\frac{1}{2})\hbar\omega\ n=0,1,2\ldots $$ 

This is the allowed energy values which can give physical meaningful wave function. Clearly it is quantized. The boundary condition once again put a limit on the possible energy values, this time it is just a bit more complicated.

The energy spectrum is quite unique for the oscillator, it is equally spaced with interval  $ \hbar\omega $. The lowest energy state has energy  $ \frac{1}{2}\hbar\omega $. As in the infinite potential it is not zero and also demonstrates the uncertainty relation.

(4) Determine the wave functions associated with  $ E_{n} $

I have mentioned following the recursion formula that once we know the K (E_n) and certain a, we can find all other coefficients with recursion formula. Given an arbitrary n (and thus E_n), it fixed largest m_0 and p (even or odd series), clearly if n is even, p=0, the wave function will be even; if n is odd, p=1, the function is odd. But how do we get at least one a_{2m}? Well the recursion formula will allow us writing the coefficients in terms of the lowest a, i.e. the ratio between

the coefficients are fixed by the recursion, and then we can use the normalization condition to determine the overall factor. In the following it is helpful to rewrite the recursion (12-67) as (same as Griffiths):

 $$ a_{_{j+2}}=\frac{-2(n-j)}{(j+1)(j+2)}a_{_{j}}\begin{cases}n odd\rightarrow odd j\\ n even\rightarrow even j\end{cases}(12-71) $$ 

In the formula above, I use  $ j = 2m + p $,  $ K = 2n + 1 $,  $ n = j_0 = 2m_0 + p $ which gives the highest nonzero term, and re-label the odd series index as 1, 3, 5...

Let's start from the lowest energy which only contains one coefficient to see how this works:

For the lowest energy n=0, then  $ m_0=0 $, p=0. This is an even function, and the only nonzero term in  $ h(\xi) $ (the highest is  $ a_{2m_0}\xi^{2m_0} $) is  $ a_0 $:

 $ \psi_0 = a_0e^{\frac{\xi^2}{2}} $, and normalization  $ \int\psi_0^*\psi_0dx = 1 $ gives:

 $$ \psi_{0}=(\frac{m\omega}{\pi\hbar})^{\frac{1}{4}}e^{-\frac{\xi^{2}}{2}} $$ 

This is the wave function corresponding to lowest energy. For the next higher energy in the even series, i.e. n=2, m₀=1, p=0. The polynomial part of wave function corresponding to E₂ is h₂(ξ) = a₀ + a₂ξ²,

Using the recursion formula (12-71): a₂ = -2a₀; the normalization will fixed the overall factor.

For the other higher even n number, you repeat the above to find all the nonzero terms in the h(ξ).

For the odd wave functions associated with odd n, the lowest (the second in the complete energy spectrum) is n=1, with  $ E_1 = \frac{3}{2} \hbar \omega $, this is  $ m_0 = 0 $, p=1, the odd series.  $ h_1(\xi) = a_0' \xi = a_1 \xi $ (I change the label back to 1, 3,... in the odd series)

The wave function is  $ \psi_{1}=a_{1}\xi e^{-\frac{\xi^{2}}{2}} $, after normalization:

 $$ \psi_{1}=\sqrt{2}(\frac{m\omega}{\pi\hbar})^{\frac{1}{4}}\xi e^{-\frac{\xi^{2}}{2}} $$ 

For the n=3 (m₀=1, p=1, K=7), it contains  $ a_1\xi + a_3\xi^3 $, using (12-71):

 $ a_3 = -\frac{2}{3}a_1 $. The overall factor will be set by normalization.

So you see how to get wave functions knowing the energy. For the general formula with $E_n$ (n=0, 1, 2...), it had been worked out. The $h(\xi)$ is related to Hermite Polynomial up to a normalization factor. Hermite Polynomial is related to the so called special functions you will encounter in quantum and the details on this will be left for the math book$^{72}$. The conventional Hermite Polynomial $H(x)$ is given by (Griffiths table2.1):

 $$ H_{0}=1, $$ 

 $$ H_{1}=2x, $$ 

 $$ H_{2}=4x^{2}-2, $$ 

 $$ H_{3}=8x^{3}-12x, $$ 

 $$ H_{4}=16x^{4}-48x^{2}+12, $$ 

 $$ H_{5}=32x^{5}-160x^{3}+120x. $$ 

The convention is to set the coefficient of the highest order term (say 5

in H_{5}) in the series equals to 2^{n}, then you can use the recursion formula (12-67) or (12-71) to coefficients of lower terms. With such convention on H(x) and normalization condition we have the wave function associated with E_{n}:

 $$ \psi_{_{n}}=\left(\frac{m\omega}{\pi\hbar}\right)^{\frac{1}{4}}\frac{1}{\sqrt{2^{^{n}}n!}}H_{_{n}}(\xi)e^{-\frac{\xi^{^{2}}}{2}} $$ 

(You may throw in (12-61) if you want to express it as function of x)

The form of the several lowest states had been plotted in the figure shown at the beginning of the section, though the functional form is quite different from that in square well, the similarity in shape is clear. For the state with large energy (large n), it looks like:

<div style="text-align: center;"><img src="imgs/img_in_chart_box_253_843_773_1020.jpg" alt="Image" width="43%" /></div>


The probability amplitude is actually higher close to the classical turning point. For the oscillator with large energy, the quantization is less obvious, the energy can be treated almost as continuous, and it approaches the classical limit. In classical mechanics, at the turning point, the particle has lowest velocity and spend more time there, so you are more likely (large probability) to find particle there.

This concludes our discussion on harmonic oscillator in quantum. I tried to solve the equation directly and find out energy quantization (12-70)

and wave functions (12-74). If you are happy with the process, great; if not at least you know the results.

I must confess the math is not pretty here. Even provided with wavefucntions as (12-74), it is still a nightmare to calculate other physical parameters, such as  $ \langle x^2 \rangle $ or  $ \langle p^2 \rangle $ (the  $ \langle x \rangle = 0, \langle p \rangle = 0 $ is easy by using odd even symmetry). The operator method will be more clean and beautiful, and also provides easier ways in estimate terms (so-called matrix element) in the energy eigenbasis, such as  $ \langle x^2 \rangle $ or  $ \langle p^2 \rangle $.

## 12 -6 Hydrogen Atom

This is the only atomic element which has a single electron and thus simplest Hamiltonian and has rigorous analytic solution in quantum. It also serves as a model and starting point in calculation for other multi-electron atoms. It is still the more complicated calculation so far and in this section, I shall list out the major procedures in solving the S-equation for hydrogen atom, with some math details neglected $ ^{73} $.

## (1) The S-equation for H atom

The total Hamiltonian with Coulomb potential between nucleus and electron is in form of (in space representation):

 $$ H_{total}=-\frac{\hbar^{2}}{2}(\frac{1}{M}\Delta+\frac{1}{m}\Delta)+V(r) $$ 

 $$ V(r)=-\frac{e^{2}}{4\pi\varepsilon_{0}r}\ r=\mid r_{e}-R_{n}\mid $$ 

The total Hamiltonian includes both kinetic energy of nucleus and electron. We have learned the way to simplify such problems by using center of mass frame, the Hamiltonian will decompose into the free-particle motion of the total mass, and relative motion of reduced mass. We know how to solve the free particle and here we shall only concentrate on the relative motion, whose Hamiltonian is:

 $$ H=-\frac{\hbar^{2}}{2}\frac{1}{m}\Delta+V(r)\Delta\equiv\nabla^{2} $$ 

The m should be the reduced mass  $ \left(m_{e}M_{n}/m_{e}+M_{n}\right) $, but very close to  $ m_{e} $.

(2) Spherical symmetry of the potential and separation of variables of the S equation

Since the potential V(r) (r>0) only depends on distance, not on direction. It has what is called spherical symmetry. This implies the (12-76) should be worked in spherical coordinate and we need the explicit form of it.

 $$ \begin{aligned}\Delta=&\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}}\quad(Cartesian)\\=&\frac{1}{r^{2}}\frac{\partial}{\partial r}(r^{2}\frac{\partial}{\partial r})+\frac{1}{r^{2}\sin\theta}\frac{\partial}{\partial\theta}(\sin\theta\frac{\partial}{\partial\theta})+\frac{1}{r^{2}\sin^{2}\theta}\frac{\partial^{2}}{\partial\phi^{2}}\end{aligned} $$ 

The relations can be derived directly from the relation between

Cartesian and Spherical coordinate  $ (x = r \sin \theta \cos \phi, y = r \sin \theta \sin \phi, $

and $z=r\cos\theta$ and reverse relations), please confirm (12-77) as an exercise$^{74}$. Of course, the stationary wave function is expressed in term of: $\psi(r,\theta,\phi)$.

We shall exploit separation of variables in solving the:

 $$ -\frac{\hbar^{2}}{2m}[\frac{1}{r^{2}}\frac{\partial}{\partial r}(r^{2}\frac{\partial}{\partial r})+\frac{1}{r^{2}\sin\theta}\frac{\partial}{\partial\theta}(\sin\theta\frac{\partial}{\partial\theta})+\frac{1}{r^{2}\sin^{2}\theta}\frac{\partial^{2}}{\partial\phi^{2}}]\psi+V(r)\psi=E\psi $$ 

First if the wave function can be separated as product of radial and angular part, i.e.:

 $$ \psi(r,\theta,\phi)=R(r)Y(\theta,\phi) $$ 

Insert this into (12-77), we will get (after some rearrangement):

 $$ \frac{1}{R}\frac{d}{d r}(r^{2}\frac{d R}{d r})-\frac{2m r^{2}}{\hbar^{2}}[V(r)-E]=-\frac{1}{Y}[\frac{1}{\sin\theta}\frac{\partial}{\partial\theta}(\sin\theta\frac{\partial Y}{\partial\theta})+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}Y}{\partial\phi^{2}}] $$ 

The left and right part depends on r and angles separately, and for the equation to be valid for any variables, the two ends has to equal to some constants, and we shall write the constant in forms of  $ l(l+1)^{75} $:

 $$ \frac{1}{R}\frac{d}{d r}(r^{2}\frac{d R}{d r})-\frac{2m r^{2}}{\hbar^{2}}[V(r)-E]=l(l+1) $$ 

 $$ \frac{1}{Y}[\frac{1}{\sin\theta}\frac{\partial}{\partial\theta}(\sin\theta\frac{\partial Y}{\partial\theta})+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}Y}{\partial\phi^{2}}]=-l(l+1) $$ 

These are the two differential equations need to be solved. I shall only give the result mostly in the following for the solutions for these

equations. First let's talk about solutions of (12-80) called angular part (this is also because the solution is the eigenfunction for the angular momentum).

(3) Angular part solution and quantum number L and m

(12-80) still have two variables $(\theta,\phi)$; we need further separation of variables by guessing:

 $$ Y(\theta,\phi)=\Theta(\theta)\Phi(\phi) $$ 

After insertion, (12-80) becomes:

 $$ \frac{1}{\Theta}[\sin\theta\frac{d}{d\theta}(\sin\theta\frac{d\Theta}{d\theta})]+l(l+1)\sin^{2}\theta=-\frac{1}{\Phi}\frac{d^{2}\Phi}{d\phi^{2}} $$ 

Since the two sides depend on different variables, each has to be equal to some constant, and let's designate it as  $ m^{2} $ (m is some complex number like l, still undetermined). Then the  $ \Phi(\phi) $'s general form can be solved easily:

 $$ -\frac{1}{\Phi}\frac{d^{2}\Phi}{d\phi^{2}}=m^{2}\rightarrow\frac{d^{2}\Phi}{d\phi^{2}}+m^{2}\Phi=0 $$ 

Thus the general form of  $ \Phi(\phi) $ is:

 $$ \Phi(\phi)=e^{i m\phi} $$ 

(the -m can be absorbed by allow m both negative and positive, and coefficient in front will be fixed by normalization)

Next we shall use boundary condition to determine m by requiring

after  $ 2\pi $ change of  $ \phi $, the wave function be back to itself:

 $$ \Phi(\phi+2\pi)=\Phi(\phi)\qquad(12-84)^{76} $$ 

Then  $ e^{im2\pi}=1 $, meaning:

 $$ m=0,\pm1,\pm2\ldots $$ 

For the  $ \theta $ part:

 $$ \frac{1}{\Theta}[\sin\theta\frac{d}{d\theta}(\sin\theta\frac{d\Theta}{d\theta})]+l(l+1)\sin^{2}\theta=m^{2} $$ 

Both function and quantum number $l$ need to be determined. In the following only the solutions are provided with details neglected. The (12-80) (as well as the 12-82 and 12-86 which come out of 12-80) is actually the eigenvalue problem for orbital angular momentum, and the treatment with “ladder” operator (constructing creator $L_{+}$ and annihilator $L_{-}$, analogous to the operator method in harmonic oscillator) is best to deal with the eigenvalue and eigen function problem in angular momentum. There the restriction on the quantum number $l$, $m$ can be derived more clearly; the wave functions can be worked out by using the property of the creator or annihilator with simpler differential equations. Since we have not talked about formal definition of angular momentum in quantum, this treatment is thus out of the hand at present. Most textbooks have the details on the topic, such as Shankar’s Chap. 12, or Cohen-Tannoudji et al’s Chap. 6. For

the students who want to learn more beyond this course, please refer to these references.

The solution to  $ (12-86) $ is:

 $$ \Theta(\theta)=A P_{l}^{m}(\cos\theta) $$ 

A is a factor can be determined by normalization.  $ P_{l}^{m}(x) $ is so-called associated Legendre function, which can be calculated from the Legendre polynomial:

 $$ P_{l}^{m}(x)\equiv(1-x^{2})^{\frac{|m|}{2}}(\frac{d}{d x})^{|m|}P_{l}(x) $$ 

 $ P_{1}(x) $ is the Legendre polynomial, which can be worked out by the generating formula:

 $$ P_{l}(x)\equiv\frac{1}{2^{l}l!}(\frac{d}{dx})^{l}(x^{2}-1)^{l} $$ 

These solutions put a restriction on the possible l and m:

The Legendre polynomial is meaningful only if $l$ is non-negative integer; from (12-89) the highest order of $x$ is $x^l$, to have non-zero $P_l^m(x)$ from (12-89), the $|m|\leq l$. Thus the restriction on the $l$ and $m$: $l=0,1,2,\ldots$ (12-90)

 $$ m=-l,-l+1....l-1,l $$ 

For any given value $l$, there are $2l+1$ possible m. In the angular momentum theory, the $l$ corresponds to the magnitude of angular momentum, i.e. $|L|=\sqrt{l(l+1)}\hbar$; $m$ corresponds to the directional component of angular momentum, say the $z$ component: $L_z=m\hbar$.

Some lower order of the polynomial and associated function are listed

in the table (taken from Griffiths):

Legendre Polynomial:  $ P_{L} $

<div style="text-align: center;"><img src="imgs/img_in_image_box_263_323_617_593.jpg" alt="Image" width="29%" /></div>


 $$ \mathbf{P}_{2}=\frac{1}{2}(3x^{2}-1) $$ 

 $$ \mathrm{P}_{3}=\frac{1}{2}(5x^{3}-3x) $$ 

 $$ \mathrm{P}_{4}=\frac{1}{8}\left(35x^{4}-30x^{2}+3\right) $$ 

 $$ \mathrm{P}_{5}=\frac{1}{8}(63x^{5}-70x^{3}+15x) $$ 

<div style="text-align: center;">a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_640_285_1098_644.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">b)</div>


The associated Legendre function  $ P_{l}^{m}(\cos\theta) $:


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{0}^{0}=1  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{2}^{0}=\frac{1}{2}(3\cos^{2}\theta-1)  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{1}^{1}=\sin\theta  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{3}^{3}=15\sin\theta(1-\cos^{2}\theta)  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{1}^{0}=\cos\theta  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{3}^{2}=15\sin^{2}\theta\cos\theta  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{2}^{2}=3\sin^{2}\theta  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{3}^{1}=\frac{3}{2}\sin\theta(5\cos^{2}\theta-1)  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{2}^{1}=3\sin\theta\cos\theta  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{3}^{0}=\frac{1}{2}(5\cos^{3}\theta-3\cos\theta)  $</td></tr></table>

<div style="text-align: center;">a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_676_807_989_1123.jpg" alt="Image" width="26%" /></div>


<div style="text-align: center;">b)</div>


With solution in  $ \Phi(\phi) $ (12-83) and  $ \Theta(\theta) $ (12-87), we have the total angular solution  $ Y(\theta,\phi) $ in (12-81). Since its function form will depend on quantum number l and m, it is expressed as  $ Y_{l}^{m}(\theta,\phi) $. It needs to be normalized over angular part of space, i.e.:

 $$ \int\limits_{\theta=0}^{\pi}\int\limits_{\phi=0}^{2\pi}Y_{l}^{m*}Y_{l}^{m}\sin\theta d\theta d\phi=1 $$ 

The normalization factor A can be determined, the results are listed in

the table for some normalized  $ Y_{l}^{m}(\theta,\phi) $

 $$ \mathbf{Y}_{0}^{0}=\left(\frac{1}{4\pi}\right)^{1/2} $$ 

 $$ \mathrm{Y}_{2}^{\pm2}=\left(\frac{15}{32\pi}\right)^{1/2}\sin^{2}\theta\mathrm{e}^{\pm2\mathrm{i}\phi} $$ 

 $$ \mathbf{Y}_{1}^{0}=\left(\frac{3}{4\pi}\right)^{1/2}\cos\theta $$ 

 $$ \Upsilon_{3}^{0}=\left(\frac{7}{16\pi}\right)^{1/2}\left(5\cos^{3}\theta-3\cos\theta\right) $$ 

 $$ \mathbf{Y}_{1}^{\pm1}=\mp\left(\frac{3}{8\pi}\right)^{1/2}\sin\theta\mathbf{e}^{\pm\mathrm{i}\phi} $$ 

 $$ \mathbf{Y}_{3}^{\ast1}=\mp\left(\frac{21}{64\pi}\right)^{1/2}\sin\theta(5\cos^{2}\theta-1)\mathbf{e}^{\ast\mathrm{i}\phi} $$ 

 $$ \mathbf{Y}_{2}^{0}=\left(\frac{5}{16\pi}\right)^{1/2}\left(3\cos^{2}\theta-1\right) $$ 

 $$ \mathbf{Y}_{3}^{\pm2}=\left(\frac{105}{32\pi}\right)^{1/2}\sin^{2}\theta\cos\theta\mathbf{e}^{\pm2\mathrm{i}\phi} $$ 

 $$ \mathbf{Y}_{2}^{\pm1}=\mp\left(\frac{15}{8\pi}\right)^{1/2}\sin\theta\cos\theta\mathbf{e}^{\pm i\phi} $$ 

 $$ \mathrm{Y}_{3}^{\pm3}=\mp\left(\frac{35}{64\pi}\right)^{1/2}\sin^{3}\theta\mathrm{e}^{\pm3\mathrm{i}\phi} $$ 

 $ Y_{l}^{m}(\theta,\phi) $ is called spherical harmonics, it is the eigenfunction for the orbital angular momentum, and it is probably one of the most important functions in quantum mechanics. For more on the properties (such as parity property) on the spherical harmonics, please refer to special functions in math books or Cohen-Tannoudji's book complement  $ A_{VI} $ for details (we do not need much of them in this course, but they play important roles in later advanced topics, such as transition probability and selection rules in spectroscopy, i.e. tell you what kind of change of energy state in atom/molecule is allowed through the interaction with light).

The general formula for the spherical harmonics is:

 $$ Y_{l}^{m}(\theta,\phi)=\varepsilon\sqrt{\frac{(2l+1)}{4\pi}\frac{(l-|m|)!}{(l+|m|)!}}e^{i m\phi}P_{l}^{m}(\cos\theta) \varepsilon=(-1)^{m}\quad m\stackrel{\equiv}{\leq}0;\qquad\varepsilon=1\quad m<0 $$ 

These functions form an orthonormal basis over the angular space

(you may prove this hack way or as in angular momentum theory, since these functions are eigenfunctions for a Hermitian operator L, they must be orthogonal), meaning:

 $$ \int\limits_{\theta=0}^{\pi}\int\limits_{\phi=0}^{2\pi}Y_{l^{\prime}}^{m^{\prime}*}Y_{l}^{m}\sin\theta d\theta d\phi=\delta_{l l^{\prime}}\delta_{m m^{\prime}} $$ 

I’d better make a quick summary on this lengthy section on the angular solution. The most important facts for this course is through the solution of angular part (12-80), we can put restrictions on the quantum number l and m (12-90); and the wave functions on angular part can also be determined (12-83), (12-87) and (12-91).

## (4) Radial solution and quantum number n

We still need to solve the radial equation (12-79) to have a complete solution for electron in hydrogen atom. I shall list out crucial steps below and left some details out. You can find step by step derivation in Griffiths.

(a) Reformulate (12-79) into better form

Let's define a function:

 $$ u(r)\equiv rR(r) $$ 

In terms of u(r), the (12-79) becomes:

 $$ -\frac{\hbar^{2}}{2m}\frac{d^{2}u}{d r^{2}}+\left[V(r)+\frac{l(l+1)\hbar^{2}}{2m r^{2}}\right]u=E u $$ 

This equation is exactly a particle moving in a 1-D potential, the

effective potential is:

 $$ V_{eff}=V+\frac{l(l+1)\hbar^{2}}{2mr^{2}} $$ 

This probably reminds you of the central field problem we learned in classical mechanics. There we encounter same effective potential in forms of  $ V + \frac{L^2}{2\mu r^2} $, where  $ \mu $ is the reduced mass and L is angular momentum. In quantum, the magnitude of angular momentum is  $ \sqrt{l(l+1)}\hbar $, so 12-95 is really analogous to the classical case. Solving the equation with Coulomb potential has similar procedures as solving the harmonic potential: Guess the general solution form by investigating the asymptotic behavior of solution; find the recursion formula for the polynomial, that will give us solution form; the polynomial has to be truncated to keep the solution normalizable, that will give us the quantization on energy.

(b) Asymptotic behavior of the solution and recursion formula for polynomial

Now we throw in the form of Coulomb potential:

 $$ V(r)=-\frac{e^{2}}{4\pi\varepsilon_{0}r}\mathrm{~a n d~d e f i n e:} $$ 

 $$ k\equiv\frac{\sqrt{-2mE}}{\hbar} $$ 

We expect the energy is less than zero for the bound state. (12-94)

becomes:

 $$ \frac{d^{2}u}{k^{2}dr^{2}}=[1-\frac{me^{2}}{2\pi\varepsilon_{0}\hbar^{2}k}\frac{1}{kr}+\frac{l(l+1)}{\left(kr\right)^{2}}]u $$ 

With substitution:

 $$ \rho\equiv k r,\rho_{0}\equiv\frac{m e^{2}}{2\pi\varepsilon_{0}\hbar^{2}k} $$ 

We have:

 $$ \frac{d^{2}u}{d\rho^{2}}=[1-\frac{\rho_{0}}{\rho}+\frac{l(l+1)\hbar^{2}}{\rho^{2}}]u $$ 

At the limit of the r, one end is infinity where both potential terms

vanish except constant 1; the other end is r=0, where the centrifugal

term dominates. We can get the asymptotic behavior of the solution

close to these two limits by neglecting the appropriate terms:

 $$ u\xrightarrow{\rho\rightarrow\infty}A e^{-\rho}+B e^{\rho}\quad\quad u\xrightarrow{\rho\rightarrow0}C\rho^{l+1}+D\rho^{-l} $$ 

The normalizable solution requires B and D to be zero. (It should be kept in mind that it is  $ R(r)=u(r)/r $ required to be normalizable, that kills D even for the  $ l=0 $ case) Thus the suitable guess for the general solution would be:

 $$ u(r)=v(\rho)\rho^{l+1}e^{-\rho} $$ 

 $ v(\rho) $ is a polynomial whose coefficients to be determined:

 $$ \nu(\rho)=c_{0}+c_{1}\rho+...=\sum_{j=0}^{\infty}c_{j}\rho^{j} $$ 

Here the potential is not symmetric in r, so I do not have even or odd series.

Put form (12-99) into (12-98) we get:

 $$ \rho\frac{d^{2}v}{d\rho^{2}}+2(l+1-\rho)\frac{d v}{d\rho}+[\rho_{0}-2(l+1)]v=0 $$ 

Put in the polynomial form, group the coefficients for the same power of  $ \rho $ together and from linear independence of  $ \rho^{0}, \rho^{1}, \rho^{2} $…, the coefficients has to be zero, we finally reach the recursion formula:

 $$ c_{_{j+1}}=c_{_{j}}[\frac{2(j+l+1)-\rho_{_{0}}}{(j+1)(j+2l+2)}] $$ 

 $$ (12-101) $$ 

So knowing one term, say  $ c_{0} $ (which can be determined by normalization), the rest will be known from the recursion provided with the energy (that determines the  $ \rho_{0} $).

## (c) Polynomial truncation and quantization of energy

We can show if the polynomial has unlimited terms and obeys the recursion formula (12-101), the asymptotic (at large r or  $ \rho $ where high power terms dominate) behavior of such polynomial would approach exponential form of:

 $$ v(\rho)\stackrel{\rho\to\infty}{\rightarrow}e^{2\rho}\qquad(Prove it yourself or read the book) $$ 

This will make the complete solution (12-99) approaches  $ e^{\rho} $ at large  $ \rho $, and the solution is physically unacceptable.

To wiggle out this dilemma, the polynomial has to be truncated at certain order with the highest order nonzero term to be  $ c_{j_0}\rho^{j_0} $, the  $ j_0 $ is the index for this highest nonzero term.  $ c_{j > j_0} = 0 $ when:

 $$ 2(j_{0}+l+1)=\rho_{0} $$ 

Let's define another quantum number n:

 $$ n\equiv j_{0}+l+1\qquad(12-102) $$ 

Then:

 $$ \rho_{_{0}}=2n\qquad(12-103) $$ 

The n can only take positive integers 1, 2, 3..., since both  $ j_{0} $ and l are non-negative integers. We then have energy relation:

 $$ \begin{aligned}&\rho_{_{0}}^{^{2}}\equiv\frac{m_{_{e}}^{^{2}}e^{^{4}}}{(2\pi\varepsilon_{_{0}}\hbar^{^{2}})^{^{2}}k^{^{2}}}=-\frac{m_{_{e}}e^{^{4}}}{8\pi^{^{2}}\varepsilon_{_{0}}^{^{2}}\hbar^{^{2}}E}\\ &E=-\frac{1}{n^{^{2}}}[\frac{m_{_{e}}}{2\hbar^{^{2}}}(\frac{e^{^{2}}}{4\pi\varepsilon_{_{0}}})^{^{2}}]=\frac{E_{_{1}}}{n^{^{2}}}\\ &E_{_{1}}=-\frac{m_{_{e}}}{2\hbar^{^{2}}}(\frac{e^{^{2}}}{4\pi\varepsilon_{_{0}}})^{^{2}}=-13.6eV\\ \end{aligned} $$ 

This is the ground state energy of electron in hydrogen. The higher energy levels corresponds to larger n. We thus have the formula for the complete energy spectrum of electron in hydrogen.

 $$ \begin{aligned}&k=\frac{m_{e}e^{2}}{2\pi\varepsilon_{0}\hbar^{2}\rho_{0}}=\frac{1}{n}(\frac{m_{e}e^{2}}{4\pi\varepsilon_{0}\hbar^{2}})=\frac{1}{a_{0}n}\\&a_{0}=\frac{m_{e}e^{2}\equiv}{4\pi\varepsilon_{0}\hbar^{2}}=0.529^{\circ}\quad(12-107)\\ \end{aligned} $$ 

This is the Bohr radius (the radius of the orbital for the ground state electron) in Bohr's model. Of course there is no orbital in quantum; the $a_{0}$ is actually where the electron has the largest radial probability density (problem 4.14 in Griffiths). To prove this we have to know the wave function.

Digression: Atomic Units

In atomic physics, it is more convenient to use atomic unit by rescale

the length, mass, charge etc. It is quite straightforward from above

relations; the form can be greatly simplified if we define new units as:

 $ m_{e}=1 $ au (mass)

 $$ \frac{e}{\sqrt{4\pi\varepsilon_{0}}}=1\ a u\ (charge) $$ 

 $$ a_{_{0}}=1au(length) $$ 

Then  $ \hbar = 1 $ in atomic unit (it is the unit for angular momentum).

To find au for time or speed, we use the fact the following combination would be a dimensionless constant:

 $$ \alpha\equiv\frac{\hbar}{a_{0}m_{e}c}\approx\frac{1}{137} $$ 

The $\alpha$ is called fine structure constant. It appears quite often in atomic physics. Then $\alpha c$ is the au for velocity. In terms of au, the energy (12-105) will be $E_{1}=-\frac{1}{2}	au$. The au for energy is called Hartree, and 1 Hartree=27.2 eV.

(d) Quantum numbers and Wave functions corresponding to them

After determining the energy form, we know the  $ \rho_{0} $ in the recursion formula (12-101) and the radial wave function can be determined, where the  $ c_{0} $ can be fixed by normalization condition:

 $$ \int\limits_{0}^{\infty}R^{*}(r)R(r)r^{2}dr=1 $$ 

Because the angular part wave function is already normalized in forms

of spherical harmonics, then the complete wave function  $ \psi(r,\theta,\phi)=R_{nl}(r)Y_{l}^{m}(\theta,\phi) $ will be normalized over space. Note, since the form of  $ \mathrm{R}(\mathrm{r}) $ will clearly depend on the quantum number n and l, it is natural to use symbol  $ R_{nl}(r) $. You see that the total wave function will depend on the quantum numbers n, l, m.

We have seen the restrictions between $l$ and $m$ in (12-90); the definition on $n$ in (12-102) put extra restriction between $n$, $l$. Since the $j_0$ is non-negative integer, the biggest $l$ for a given $n$, could be $n-1$.

Thus the complete restriction among n, l, m are:

 $ n=1,2,3\ldots $

 $ l=n-1,n-2,\ldots,0 $ (n possible value for given n) (12-110)

 $ m=l,l-1,\ldots,-l $  $ (2l+1\text{ possible value for given }l) $

The wave functions will be determined by these quantum numbers (as we shall explicitly demonstrate below). The n is called principal quantum number, because it determines the energy; the l is called orbital (short for orbital angular momentum) quantum number, because it fixes the magnitude of orbital angular momentum; m is called magnetic quantum number, it fixes the directional component of angular momentum, and will cause energy shift when interacting with external magnetic field (Zeeman effect).

The wave functions corresponding to these quantum numbers are expressed as (in Dirac’s notation and space wave function):

 $$ |n,l,m>\quad\xrightarrow{in space representation}\quad\psi_{nlm}(r,\theta,\phi) $$ 

Let’s work out the explicit function form given the quantum numbers.

For instance if n=1, we could only have $j_{0}=0$, meaning only has one

constant term in polynomial: $v_{n-1}(\rho)=c_{0}$ ; and $l=0$, meaning

restriction on angular quantum number, the angular function could

only be (since if $l=0$, m=0 too) $Y_{l}^{m}=Y_{0}^{0}$

 $$ R_{10}(r)=\frac{u(\rho)}{r}=\frac{u(\left.\frac{r}{a_{0}}\right.)}{r}=\frac{c_{0}\rho^{1}e^{-\rho}}{r}=c_{0}\frac{1}{a_{0}}e^{-r/a_{0}} $$ 

After normalization  $ c_0 = \frac{2}{\sqrt{a_0}} $, and  $ Y_0^0 = \sqrt{\frac{1}{4\pi}} $, then complete wave function for the ground state electron in hydrogen is:

 $$ \psi_{100}=\frac{1}{\sqrt{\pi a_{0}^{3}}}e^{-r/a_{0}} $$ 

Now let's consider the case for n=2. The energy is:

 $$ E_{2}=-\frac{E_{1}}{4} $$ 

There are 4 wave functions associated with this energy with different l or m. The possible combinations are:

 $ l=0,m=0; l=1,m=0,\pm1 $ total 4 of them.

For the case of  $ |n,1,m| \geq |2,0,0\rangle $, from (12-102) we see  $ j_0 = 1 $, meaning the polynomial has up to the order of  $ \rho^1 $, i.e.  $ v_{20}(\rho) = c_0 + c_1\rho $,

Using recursion formula  $ (\rho_{0}=2n=4\text{ here}) $:  $ c_{1}=-c_{0} $,  $ \rho=\frac{r}{2a_{0}} $

 $$ R_{20}(r)=\frac{c_{0}}{r}(1-\frac{r}{2a_{0}})\frac{r}{2a_{0}}e^{-\frac{r}{2a_{0}}}=\frac{c_{0}}{2a_{0}}(1-\frac{r}{2a_{0}})e^{-\frac{r}{2a_{0}}} $$ 

 $$ (c_{0}=\sqrt{\frac{2}{a}}\mathrm{~from~normalization~for~R_{20}}) $$ 

The complete wave function for state  $ |2,0,0> $ would be:  $ \psi_{200}=R_{20}Y_{0}^{0} $.

For the case of  $ |2,1,0> $:

 $ J_{0}=0 $, so only  $ c_{0} $ term in polynomial, and :

 $$ R_{21}(r)=\frac{c_{0}}{r}\big(\frac{r}{2a_{0}}\big)^{2}e^{-\frac{r}{2a_{0}}}=\frac{c_{0}}{4a_{0}^{2}}re^{-\frac{r}{2a_{0}}}\quad(c_{0}=\sqrt{\frac{2}{3a_{0}}}\quad for R_{21}) $$ 

The complete wave function would be:  $ \psi_{210} = R_{21}Y_1^0 $; for the  $ [2,1,1>2,1,-1> $ case, just replace it with proper spherical harmonics.

For the simple examples given above, we can find wave functions term by term with recursion. The radial function  $ R_{nl} $ has a general formula, using the so called associated Largurre function:

 $$ R_{n l}=\sqrt{(\frac{2}{n a_{0}})^{3}\frac{(n-l-1)!}{2n[(n+l)!]^{3}}}(\frac{2r}{n a_{0}})^{l}e^{-\frac{r}{n a_{0}}}[L_{n-l-1}^{2l+1}(\frac{2r}{n a_{0}})] $$ 

The L in the monster formula is associated Laguerre function:

 $$ L_{q-p}^{p}(x)\equiv(-1)^{p}(\frac{d}{d x})^{p}L_{q}(x) $$ 

 $ L_{q}(x) $ is the Laguerre polynomial defined as:

 $$ L_{q}(x)\equiv e^{x}(\frac{d}{dx})^{q}(e^{-x}x^{q}) $$ 

You can find the first couple polynomials and associated functions

tabled in Griffiths' book, and the first couple radial function  $ R_{nl} $ are:

 $$ \begin{aligned}&R_{10}=2a^{-3/2}\exp\left(-r/a\right)\\ &\frac{R_{20}=\frac{1}{\sqrt{2}}a^{-3/2}\left(1-\frac{1}{2}\frac{r}{a}\right)\exp\left(-r/2a\right)}{R_{21}=\frac{1}{\sqrt{24}}a^{-3/2}\frac{r}{a}\exp\left(-r/2a\right)}\\ &\frac{R_{30}=\frac{2}{\sqrt{27}}a^{-3/2}\left(1-\frac{2}{3}\frac{r}{a}+\frac{2}{27}\left(\frac{r}{a}\right)^{2}\right)\exp\left(-r/3a\right)}{R_{31}=\frac{8}{27\sqrt{6}}a^{-3/2}\left(1-\frac{1}{6}\frac{r}{a}\right)\left(\frac{r}{a}\right)\exp\left(-r/3a\right)}\\ &\frac{R_{32}=\frac{4}{81\sqrt{30}}a^{-3/2}\left(\frac{r}{a}\right)^{2}\exp\left(-r/3a\right)}{R_{40}=\frac{1}{4}a^{-3/2}\left(1-\frac{3}{4}\frac{r}{a}+\frac{1}{8}\left(\frac{r}{a}\right)^{2}-\frac{1}{192}\left(\frac{r}{a}\right)^{3}\right)\exp\left(-r/4a\right)}\\ &\frac{R_{41}=\frac{\sqrt{5}}{16\sqrt{3}}a^{-3/2}\left(1-\frac{1}{4}\frac{r}{a}+\frac{1}{80}\left(\frac{r}{a}\right)^{2}\right)\frac{r}{a}\exp\left(-r/4a\right)}{R_{42}=\frac{1}{64\sqrt{5}}a^{-3/2}\left(1-\frac{1}{12}\frac{r}{a}\right)\left(\frac{r}{a}\right)^{2}\exp\left(-r/4a\right)}\\ &\frac{R_{43}=\frac{1}{768\sqrt{35}}a^{-3/2}\left(\frac{r}{a}\right)^{3}\exp\left(-r/4a\right)}{}\\ \end{aligned} $$ 

To graphically displaying the wave functions, chemists usually call them electron cloud, we plot the  $ |\psi|^2 $ versus coordinates, with the brightness proportional to the value of probability density  $ |\psi|^2 $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_231_165_1022_703.jpg" alt="Image" width="66%" /></div>


<div style="text-align: center;"> $ (3,1,0) $</div>


<div style="text-align: center;"> $ (4, 1, 0) $</div>


<div style="text-align: center;"> $ (4,0,0) $</div>


<div style="text-align: center;"> $ (4,2,0) $</div>


<div style="text-align: center;"> $ (4,3,0) $</div>


<div style="text-align: center;">I probably should mention that there is another often used label for quantum number for historical reason. People use letters s,p,d,f....to represent $l=0,1,2,3\ldots$ (fortunately we do not encounter too high angular momentum and do not run out of letters), so in this terminology, $|211>\mathrm{is}$ called $2p_{1},|430>\mathrm{is}$ $4f_{0}$. Chemists also likes to use linear combinations of states with same $n$, $l$ but different $m$ (since these states have same energy, combination of them is also eigenstates of the energy), to have $p$ orbitals along $x,y,z$ direction, such as $2p_{x},2p_{y}$ (both are linear combination of $2p_{1},2p_{-1})^{77}$, and $2p_{z}$ (which is $2p_{0}$); the combination of different $m$ states with $l=2$ will result in so called $d_{z^{2}},d_{x^{2}-y^{2}},d_{xz},d_{yz},d_{xy}$ orbitals. There are also other linear combinations used by chemists in explaining the bonding of</div>


molecules, these are called hybrid orbitals, such as  $ sp^{3} $,  $ sp^{2} $, sp hybrids etc.

One more thing need to be mentioned: degeneracy

We have seen that the energy in hydrogen only depends on principal quantum number n. For a given n, in the n>1 case, there are many distinct (linear independent) states correspond to the same energy, 4 for the n=2 case. The situation that many distinct states correspond to same energy is called degeneracy, meaning specify energy only cannot fix the state. For example with n=2 energy, any linear combination of the 4 states can be eigenstates with same energy. That is why we need extra quantum numbers l and m to specify the state, those quantum numbers correspond to orbital angular momentum and its directional component. $ ^{78} $ The number of degeneracy (numbers of distinct states correspond to same energy) can be calculated for hydrogen:

 $$ g_{n}=\sum_{l=0}^{n-1}(2l+1)=n^{2} $$ 

The reason that different orbital angular momentum l has same energy is “accidental” in the hydrogen case, for the potential with 1/r form $ ^{79} $. For other potential form, or inclusion of electron repulsion in multielectron atoms, or including the relativistic effect (the spin-orbit

coupling), the energy degeneracy on l will be removed. The energy

degeneracy on m is related to the isotropic space and thus more

persistent, only by applying external field (say a magnetic field along

z direction) will remove the degeneracy (by saying remove of

degeneracy, I mean the energy will depend on that quantum number).

We finally finished calculation for electron in hydrogen atom, the simplest atomic structure in physics and chemistry, and unfortunately the only possible rigorous solution we can get (besides other hydrogen-like ions which only has one electron, but Z charged nucleus). In going to multielectron atoms (Helium and beyond), there will be extra term in Hamiltonian due to mutual repulsion among electrons, which make the rigorous analytic solution impossible, approximation method (variation or perturbation) has to be used.

Now back to the summary of hydrogen atom, the most important parts for this course are: we have computed energy and wave functions by solving the S-equation, and in the due process quantum numbers n, l, m appear. These numbers let us fix the energy and the wave functions, so the state can be specified $ ^{80} $ as  $ |n,l,m\rangle $. The relations between these numbers (12-110) were also derived.

(5) Including the spin for electron

In the above calculation, since there is no term involving the spin in the Hamiltonian (12-75), what we computed is the space wave function of electron as if the electron is spinless. But we know the electron has spin with $S=1/2$, $S_{z}=\pm\frac{1}{2}$. So we need to include this in the state vector (or wave function) to completely specify the electron. The spin has no classical analogy; they live in a space spanned by the base vectors:

 $$ \alpha_{+}\equiv|+>=\mid S=\frac{1}{2},S_{z}=\frac{1}{2}>\alpha_{-}\equiv|->=\mid S=\frac{1}{2},S_{z}=-\frac{1}{2}> $$ 

We have used the basis to represent the spin in the previous treatment of Stern-Gerlach experiment. The arbitrary spin state would be linear combinations of these base vectors. That is how we represent the spin, and we cannot write it in function of  $ (x,y,z) $. This means the spin space is independent of the usual 3-D space, and to include spin degree of freedom, our space representing the state vector need to be expanded to include both. The complete space is what is called tensor product of the two spaces and I discussed it briefly in footnote 38. But we also keep in mind the two part of space do not mix, an action by an operator in the 3-D space only act on the 3-D part of wave function, and leave the spin part unchanged (just like d/dx only act on x, leave y,z untouched, in fact x,y,z, in fact the 3-D space is the tensor product of 1-D space  $ x \otimes y \otimes z $). The most important things to

remember for the tensor product of space is very intuitive (I use 2-D X, Y space to illustrate, and ‘digitize’ X into N₁ points (N₁ dimension) and Y into N₂ points) and I shall summarize below (what you had known for a long time in language of functions, but now expressed in terms of vector in linear algebra):

(1) The dimension of space is  $ N_1N_2 $, base vector  $ |x_i, y_j \geq \mid x_i \rangle \otimes \mid y_j \rangle $, sometimes we even neglect the  $ \otimes $ symbol.

(2) State vector which is a tensor product, its wave function will be just

product of the two wave functions in each space:

Let:  $ <x_i \mid \Phi(x) \geq \phi(x_i), <y_j \mid \Theta(y) \geq \theta(y_j) $, then the tensor product state vector:  $ |\Psi \geq |\Phi \otimes |\Theta\rangle $, or write it out explicitly with base vectors:  $ |\Psi \geq \sum_{i,j} \phi(x_i) \theta(y_j) |x_i \rangle |y_i\rangle $, so the wave

function is:

 $$ <x_{i},y_{j}\mid\Psi>=\psi(x_{i},y_{j})=\phi(x_{i})\theta(y_{j}) $$ 

Please note the above is true if the state vector in the complete space (X, Y here) is a tensor product. $ ^{81} $

(3) The operator act in one space would only affect the corresponding component of the state vector:

 $$ \hat{R}(x)\left|\Psi\right\rangle=\left(\hat{R}(x)\left|\Phi\right\rangle\right\rangle\otimes\left|\Theta\right\rangle\qquad\left(S u c h~a s\quad\frac{\partial}{\partial x}\right) $$ 

 $$ \begin{aligned}&\hat{R}(x)\otimes\hat{P}(y)\mid\Psi>=\left(\hat{R}(x)\mid\Phi>\right)\otimes\left(\hat{P}(y)\mid\Theta>\right)\\ &\\ &\frac{\partial^{2}}{\partial x\partial y}act on\phi(x)\theta(y))\\ \end{aligned} $$ 

With the above knowledge, I can now talk about the electron state in hydrogen with inclusion of spin. We have seen that the  $ |n,l,m> $ completely specify the eigenstate of Hamiltonian in 3-D space, and these  $ |n,l,m> $ do form a complete and orthogonal basis in 3-D (eigenstates of Hermitian operator); and spin is spanned by the  $ |S,S_{z}> $, so the tensor product of them will form a complete and orthogonal basis for the tensor product space of 3-D and spin. These basis vectors are expressed as:

 $$ |n,l,m,S,S_{z}>{\equiv}|n,l,m>\otimes|S,S_{z}>\qquad(12-I I8) $$ 

If expressed in wave function:

 $$ <x,y,z,\alpha\mid n,l,m,S,S_{z}>=\psi_{n l m}\alpha_{i} $$ 

The  $ \alpha $ above is just abstract parameter symbolizes the spin degree of freedom, and the  $ \alpha_{i} $ is just  $ \alpha_{\pm} $ in (12-117) depend on the value of  $ S_{z} $, they are just column vectors  $ \begin{bmatrix} 1 \\ 0 \end{bmatrix}, \begin{bmatrix} 0 \\ 1 \end{bmatrix} $ if  $ \alpha_{\pm} $ are the base vectors in spin space.

For any arbitrary state, it can be expressed as combination of base vectors. More specifically, for any arbitrary tensor product state:

 $$ \begin{aligned}&|\psi,\chi_{s}>=\mid\psi>\otimes\mid\chi_{s}>=\sum c\mid n,l,m,S,S_{z}>\\&c=<n,l,m\mid\psi><\alpha_{\pm}\mid\chi_{s}>=(\int\psi_{n l m}^{*}\psi d^{3}r)<\alpha_{\pm}\mid\chi_{s}>\\ \end{aligned} $$ 

For example, if a state is in form of  $ f(r,\theta,\phi)\mid S_x=\frac{1}{2}>, \text{ you can} $ (neglect the difficulty in the computing integral) find the component straightforwardly, then its time evolution will be known.

The state vector  $ \left|n,l,m,S,S_{z}>\text{including the spin is also an eigenstates of Hamiltonian (energy). It is because the Hamiltonian here contains no spin part, it is an operator only acts in 3-D, then the spin “function” (It is not exactly a function, but physicists are sloppy in terminology, more strictly, this spin vectors are called spinor) would cancel in the S-equation, so the wave function in (12-119) is indeed an eigenfunction of energy. $ ^{82} $

Since the spin state does not affect energy here, it obviously doubles the degeneracy number from  $ n^{2} $ in (12-116) to  $ 2n^{2} $. That is to say for a given energy (given n in hydrogen), there are  $ 2n^{2} $ distinct states associated to it. Specify the energy alone cannot fix the state, with the spin included, we need also orbital angular momentum (l and m) and spin angular momentum (S,S₂) to uniquely fix the state. Energy, orbital and spin angular momentum thus form a CSCO in the complete space. It may occur to you since the Hamiltonian does not include spin, why bother to consider it. Indeed, in our computation at first, we do not need spin at all. However, the Hamiltonian here is only an approximate one. It is called zeroth order since it contributes most of

the energy. There are other “perturbation” terms, terms that arises from interactions besides Coulomb, such as spin-orbit coupling (electron “sees” the nucleus moving, and a moving charge will produce magnetic field, which can interact with magnetic moment of electron which is proportional to spin), and coupling between spin of nucleus to the electron. These will bring extra terms in Hamiltonian due to extra interaction energy, but they are orders of magnitude smaller than the dominant Coulomb interaction, that is why they will be treated as perturbation, and the details will not be discussed here $ ^{83} $. The spin-orbit coupling will cause the “fine structure” in the energy level of electron in hydrogen, where different states with different l and S will be different in energy (The famous  $ 21\,cm^{-1} $ microwave emission is transition from 2p to 2s states, due to the spin-orbit coupling that splits the energy of the 2s, 2p states in hydrogen). The nucleus spin can further split the energy levels, and this is called “hyperfine structure”.

## Chapter 13 Identical Particles and Permutation Symmetry

So far we have discussed mostly on the system containing only one particle, for example the single electron in the potential well in last chapter, the spin of single electron in Stern-Gerlach. The only case we involve multiple particles is the double slit experiment example with electron-photon scattering, but there the particles are “distinguishable” meaning “not identical” (we shall give more detail on the meaning of distinguishable and identical below). In this chapter, we shall discuss on system involving multi-particles (mostly I shall talk about particle number N=2 system to illustrate the principle which can be extended to N>2 case). Let’s first take a look on the distinguishable particles case.

## 13 -1 Non-identical and Identical Particles

I shall use collision between particles as an example for this discussion.

The example is discussed in Feynman's 3.4 and 4.1; it acts as a prelude

where the Q.M. treatment for identical particles is introduced. Things will

be a little different from our previous discussion where we consider single

particle cases. Here many-body is involved and we shall see how Q.M.

works for this non-identical system. The important class of identical

particles, such as Bosons and Fermions will be introduced in next section.

Let's first take a look of the experimental setup before starting a formal

quantum treatment.

<div style="text-align: center;"><img src="imgs/img_in_image_box_219_231_753_464.jpg" alt="Image" width="44%" /></div>


<div style="text-align: center;">(fig.3-7, Feynman)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_213_510_801_760.jpg" alt="Image" width="49%" /></div>


<div style="text-align: center;">Fig. 3–8. The scattering of electrons on electrons. If the incoming electrons have parallel spins, the processes (a) and (b) are indistinguishable.</div>


<div style="text-align: center;">(fig.3-8)</div>


The setups are shown in the above figures (fig. 3-7 and 3-8 in Fynman’s) for the collision between the non-identical and identical particles respectively. The setup is easy to understand. The particles collide and then scatter to different angles. If one of the particles being scattered into angle  $ \theta_{1} $ and can be picked up by detector D1. From the conservation of momentum, the other particle will be scattered into the angle  $ \pi - \theta_{1} $ (this is of course in the reference frame of the center of mass, i.e. a coordinate system moving with the center of mass of the two particles) and be detected by detector D2.

The classical theory would give the results same for both non-identical and identical cases, only a difference in the probability of the particle

being scattered into certain angles due to difference of particles involved.

(i.e. the cross section for alpha-oxygen and electron-electron collision

will be different) But quantum mechanics would give drastic difference

between the non-identical and identical cases!

(1) Simple one: Collision between non-identical particles

Here non-identical means there are differences in some intrinsic properties (such as mass, charge, spin, etc.) between the particles, so that these particles can be distinguished.

For example, in the experiment shown in fig.3-7, the scattering between an  $ \alpha $ particle ( $ He_{4}^{2+} $) and a ion of oxygen ( $ O_{6}^{2+} $). These two particles are different and in principle can be distinguished. Let's imagine we have such device, for instance, our detector is a chemical reaction device. When the  $ He_{4}^{2+} $ particle strikes the detector, it will trigger a chemical reaction that would generate a red light (a photon with low frequency); while if the  $ O_{6}^{2+} $ strikes the detector, it would trigger a different reaction and give out green light (a photon with high frequency). So by detecting the light, we know that a particle strikes the detector; and by knowing the color of light, we would also know the kind of the particle. So these  $ He_{4}^{2+} $,  $ O_{6}^{2+} $ are in principle distinguishable, they are non-identical.

In this kind of experiment, you probably already guessed that the probability for any detector, say D1, to pick up a signal (either from

 $ He_{4}^{2+} $ or  $ O_{6}^{2+} $ ) would be a summation of individual probability. If so, a good guess.

It is easy to argue from the experimental detection. Let’s say you carry out the experiments N times, each time one  $ He_{4}^{2+} $ and one  $ O_{6}^{2+} $ are fired. The detector D1 may pick up a signal or not for each case. But if you do this N time, there will be N1 times that D1 will pick up  $ He_{4}^{2+} $ (the number of times the D1 generates red photon); and N2 time D1 recorded  $ O_{6}^{2+} $. (note: these two events are exclusive, i.e. if D1 picks up  $ He_{4}^{2+} $, it cannot record  $ O_{6}^{2+} $ because of the conservation of momentum. The  $ O_{6}^{2+} $ will fly toward D2 and vice versa) So the total probability for these two exclusive events, i.e. D1 will register a hit (no matter from which particle) is:

 $$ P(D1)=\frac{N_{1}+N_{2}}{N}=P(D1^{He})+P(D1^{O}) $$ 

Where the probability of D1 detecting He2+ is:

 $$ P(D1^{He})=\frac{N_{1}}{N}=|f(\pi-\theta_{1})|^{2} $$ 

And the probability of D1 detecting  $ O_{6}^{2+} $ is:

 $$ P(D1^{o})=\frac{N_{2}}{N}=\mid f(\theta_{1})\mid^{2} $$ 

The  $ f(\pi - \theta_1) $ and  $ f(\theta_1) $ are the probability amplitudes associated with each process.

The reason that the probability of either event is just the sum of the probability of individual events is because these events are

distinguishable and exclusive for non-identicals.

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_207_699_447.jpg" alt="Image" width="38%" /></div>


According to Feynman’s arguments and our discussion in Example 2 (chapter 11), the probability of different distinguishable events is the sum of the probability of individual event. This is really in analogy of the ‘which-way’ experiment in interference. There if the individual paths can be determined, then just sum of probability and no interference.

Enough for the semi-quantitative argument, I shall proceed to prove it from the postulates in Q.M.

<div style="text-align: center;"><img src="imgs/img_in_image_box_251_966_556_1150.jpg" alt="Image" width="25%" /></div>


For a particle A coming from left and B from right, where  $ A \neq B $, the initial state of the system can be described as a state vector (Dirac's

Ket):

 $$ |\psi_{_{AB}}>_{i}=|A,L;B,R>=|A,L>\otimes|B,R> $$ 

This abstract math representation means an initial state (the subscript I stands for) where particle A from right and particle B from left and the

Of course, in a specific spatial representation  $ \langle r|A,L\rangle $ will be a wave packet with group velocity  $ V_A $ from left to right;  $ \langle r|B,R\rangle $ will be a wave packet with group velocity  $ V_B $ from right to left. The  $ |A,L;B,R\rangle $ will be a tensor product of  $ |A,L\rangle $ and  $ |B,R\rangle $. The more general way to express the Ket for these two particles would be  $ |A,\varepsilon_A;B,\varepsilon_B\rangle $, with  $ \varepsilon_A,\varepsilon_B $ (such as position, spin state etc.) to specify the state that A and B are. The key is that this tensor product expression of state (13-1) uniquely specifies the state for the non-identical particles.

The two particles will approach each other and collide. The state after collision is related to the initial state by:

 $$ \left|\psi_{_{AB}}>={\hat{O}}\right|\psi_{_{AB}}>_{i} $$ 

The $O$ stands for the operator representing the interaction between particles during the collision (it may involve time evolution propagator, such details is not needed for our purpose), and $|\psi_{AB}>$ is the product state.

To get the probability of D1 detecting either A or B, the product state

 $ |\psi_{AB}> $ needs to be expanded onto basis by eigenstates of the

detection:  $ |A,\theta_{A};B,\theta_{B}> $. This means after collision, particle A will go

into direction  $ \theta_{A} $ and B into  $ \theta_{B} $. In our center of mass frame,

 $ \theta_{B}=\pi-\theta_{A} $ due to conservation of momentum.

 $$ |\psi_{_{AB}}>=\sum...+f(\theta)\left|A,\theta;B,\pi-\theta>+f(\pi-\theta)\right|A,\pi-\theta;B,\theta>+... $$ 

... in the equation means the particles may be scattered into other

directions. Since those won't be detected, so they are omitted here.

(Though the angular distribution would be continuous, I shall use discrete simplification here too) Let's call:

 $$ |\varphi_{\theta}>=|A,\theta;B,\pi-\theta>;|\varphi_{\pi-\theta}>=|A,\pi-\theta;B,\theta> $$ 

Then:  $ \langle \varphi_{\theta_i} \mid \varphi_{\theta_j} \rangle = \delta_{ij} $

 $$ \begin{array}{l} And\quad f(\theta)=<\varphi_{\theta}\mid\psi_{AB}>,f(\pi-\theta)=<\varphi_{\pi-\theta}\mid\psi_{AB}>\\\end{array} $$ 

The probability for D1 detects either A or B is:

 $$ \begin{aligned}P(D_{1})=&<\psi_{_{AB}}\begin{vmatrix}|\varphi_{\theta}><\varphi_{\theta}|\\ +\\ \|\varphi_{\pi-\theta}><\varphi_{\pi-\theta}\|\end{vmatrix}\psi_{_{AB}}>\\ =&\left\langle f(\theta)^{*}<\varphi_{\theta}|+\\ &f(\pi-\theta)^{*}<\varphi_{\pi-\theta}|\end{vmatrix}\begin{vmatrix}|\varphi_{\theta}><\varphi_{\theta}|\\ +\\ \|\varphi_{\pi-\theta}><\varphi_{\pi-\theta}\|\end{vmatrix}\left\lvert f(\theta)|\varphi_{\theta}>+\right.\\ =&\left|f(\theta)\right|^{2}+|f(\pi-\theta)|^{2}\end{aligned} $$ 

 $ |\varphi_\theta><\varphi_\theta| $ is the detection of A by D1, and  $ |\varphi_{\pi-\theta}><\varphi_{\pi-\theta}| $ is the detection of B by D1. The probability result is exactly same as Feynman’s 3-14.

(2) A more complex case: scattering between identical particles

First define what identical particles are. They have the same intrinsic properties (such as mass, spin, charge, etc.) and cannot be distinguished in any experiment.

In classical mechanics, of course there are these particles with same intrinsic properties. However, even these particles can be distinguished, because they may follow different paths (trajectory). Imagine a pool of

same white billiard ball, they all look alike, still you can follow the trajectories and thus label them. In this sense, all particles in classical mechanics are distinguishable.

Things are drastically changed in quantum mechanics. The uncertainty principle rules out the concept of trajectory. You cannot follow the paths of individual particles any more (using the billiard ball example as above, imagine we let the balls roll but with lights off. After a while, we turn on the light again, you really cannot tell which starting ball ends where). In quantum mechanics, for identical particles, there is no way to tell them apart. This indistinguishable character is indeed the results of uncertainty relation and thus a true quantum character.

Considering the collision experiment, this time with identical particles, such as a pair of  $ \alpha $ particles ( $ He_{4}^{2+} $, spin=0) or a pair of electrons with same spin ( $ e, S = \frac{1}{2} \hbar $). Notes: if the electrons have different spins, say one +1/2, the other -1/2, and the spin state will not flip during the process, then they are distinguishable in principle and thus not identical. Imaging the +1/2 electron can trigger a transition  $ \Delta m = 1 $ in some atoms (electron changes from +1/2 to -1/2 in this case) and the atom may emit out light left-circular polarized; While the -1/2 electron may trigger right-circular light emission. So we can tell them apart. In the identical particle case (as in fig. 3-8), the detector still records

the  $ \alpha $ (or e) particles, but we do not know the particle is originally from left or right. i.e.:

These two events (the D1 records particle coming from left or particle from right) become indistinguishable $ ^{84} $. Then what is probability in this case for D1 registering a hit? Is it in a form of summation of probability as in non-identical case? Or is it in a form of (summation of probability amplitude) $ ^{2} $ as in interference? From the previous experience, you may make a sensible guess that it will be in a form of (summation of probability amplitude) $ ^{2} $, from the rules stated in Feynman’s lecture at the end of section 3-2; or using the analogy of ‘which-way’ experiment in the interference (here you really have no idea which way the particle originates when the D1 record a hit). So the previous discussion helps you developing a quantum instinct, which enables you to make a reasonable guess.



<div style="text-align: center;"><img src="imgs/img_in_image_box_220_272_752_502.jpg" alt="Image" width="44%" /></div>


Even it is in the form of (summation of probability amplitude)$^2$, then is

it $|f(\theta)+f(\pi-\theta)|^2$ or $|f(\theta)-f(\pi-\theta)|^2$ or other combinations

such as $|\alpha f(\theta)+\beta f(\pi-\theta)|^2$?

## 13-2 Exchange Deneneracy and Permutation Symmetry Requirement in Identical Particles

In the example of collision among identical particles, the key is how we describe the state, is it a simple tensor product of two particles? The answer is NO, because they are identical, there is an ambiguity called exchange degeneracy. In the last example, since we cannot tell during the interaction between 1, 2 particles (here I use 1 and 2 instead of A,B for the label of identical particles), which comes from left or right, the following states:

 $$ \left|1,L;2,R>,\ \left|2,L;1,R>,\ a\ \left|1,L;2,R>+b\ \left|2,L;1,R>\right.\right.\right.\right. $$ 

may all be suitable for the description of the state, this ambiguity in state description has to be removed, since our physical measurement result does depend on the specific form of state (recall that though the overall phase factor will be equivalent for state description; the relative relation between the coefficients is important).

For the final product state in the collision, we have similar problem on state description:

 $$ \left|1,\theta;2,\pi-\theta>,\right|2,\theta;1,\pi-\theta>,c\left|1,\theta;2,\pi-\theta>+d\right|2,\theta;1,\pi-\theta> $$ 

These seem are all possible descriptions of the final states, there is ambiguity (exchange degeneracy) here too.

To remove such ambiguity and make the theories prediction to be consistent with experimental results, we introduce the permutation symmetry for the identical-particle system and this puts a very clear requirement on the possible forms of state vectors. That is what we shall discuss below.

The goal is to find the correct unique form that describes state vector (the Physical Ket) of the physical systems consists of multiple identical particles. There will be some modification to our postulate 1 in chapter 11. There is certain requirement imposed on the physical ket, by the physical meaning of “identical”.

For a physical system consisting many identical particles, when one write out the math form of the ket, it may necessary to choose a label for the particles, such 1, 2,3...j...; this choice of labeling on the particles is just for clear math representation and is really arbitrary. The physical results or predictions (the results from experiment) should not depend on this labeling: i.e. if we switch the labeling (a permutation), since the particles are all identical, then the physical state with the permutated labeling should represent the same physical state.

To restate the above more explicitly in math expression, I shall choose  $ |\psi_{1,2,3...j..k..} > $ to represent the state of many identical particles with a choice of labeling. Assume we exchange the label between j and k, so the state representation becomes  $ |\psi_{1,2,3...k..j..}>. $ i.e.

 $$ \hat{P}_{j k}\mid\psi_{1,2,3..j..k..}>=\mid\psi_{1,2,3..k..j..}> $$ 

 $ \hat{P}_{jk} $ is a permutation operator that does exactly as describe above,

exchange the labeling. Both vectors before and after the permutation

should represent the same physical state due to the identical property (this

is actually a postulate and a quite intuitive one). i.e.:

 $$ \hat{P}_{j k}\mid\psi_{1,2,3..j..k..}>=|\psi_{1,2,3..k..j..}>={\varepsilon}\mid\psi_{1,2,3..j..k..}>\quad{\varepsilon}\quad{\mathrm{i s~a~c o n s t a n t.}} $$ 

From the definition, it is obvious that:

 $ \hat{P}_{jk}\hat{P}_{jk}\equiv(\hat{P}_{jk})^2=I $, the identity matrix.

 $$ (\hat{P}_{j k})^{2}\mid\psi_{1,2,3..j..k..}>=\varepsilon^{2}\mid\psi_{1,2,3..j..k..}>=\mid\psi_{1,2,3..j..k..}> $$ 

So  $ \varepsilon^{2}=1 $, and  $ \varepsilon=1 $ or  $ -1^{85} $.

So for every physical state describing the system of many identical particles, they should satisfy either:

 $$ \hat{P}_{j k}\mid\psi_{1,2,3..j..k..}>=|\psi_{1,2,3..j..k..}> $$ 

Or

 $$ \hat{P}_{j k}\mid\psi_{1,2,3..j..k..}>=-\mid\psi_{1,2,3..j..k..}> $$ 

 $ |\psi_{1,2,3...j...k...}> $ is the eigenstate for permutation operator.It has clear

symmetry upon permutation. The one associated with eigenvalue 1

(13-4) is called symmetric state, and it describes the state of Boson particle.

The one associated with eigenvalue -1(13-5) is called anti-symmetric, and

describes the state of Fermion. These symmetric or anti-symmetric with

respect to permutation put a restriction on the proper mathematical

description of the system of identical particles.

The above is summarized as a postulate modifying the postulate 1:

The state vector describing the identical particle system has to be either symmetric (for Bosons) or anti-symmetric (for Fermions) with respect to permutation.

Which particles are Bosons and which are Fermions then? The answer is their spin quantum numbers (though I cannot prove it here). For a particle whose spin is an integer (integers of $\hbar$, such as $0\hbar,1\hbar\ldots$), it is a Boson. If the spin is half integer ($\frac{1}{2}\hbar,\frac{3}{2}\hbar\ldots$), it is a Fermion.$^{86}$ For the fundamental particles, the spin is just the spin of the particle (electron, proton, neutron with spin of $\frac{1}{2}\hbar$ are Fermions; photon with spin of $\hbar$ is a Boson). For composite particles (nuclei or atoms made of fundamental particles), the spin is the total spin (summation of spin numbers of the particle it consists). Spin equals integer there means even number of the composing fermions (such as the $\alpha$ particle with 2 protons (one $+1/2$, one $-1/2$), 2 neutrons (one $+1/2$, one $-1/2$) and 0 electron, $S=0$); while spin equals half-integer means odd number of fermions.

This permutation symmetry requirement is better be illustrated by

examples:

For a two-Boson particle system (such as collision between two  $ \alpha $ particles), we used symbol containing combinations of  $ |1, L; 2, R> $ type to represent one particle coming from left and one from right. The permutation symmetry will remove the exchange degeneracy on state description. Please note:

 $$ |2,L;1,R>\neq|1,L;2,R>\stackrel{87}{} $$ 

But we can construct easily a mathematical representation that satisfies the (13-4) by:

 $$ |\psi_{1,2}>_{b o s o n}=\frac{\sqrt{2}}{2}(|1,L;2,R>+|2,L;1,R>) $$ 

This state is obvious symmetric with respect to permutation and it removes the exchange degeneracy, i.e. fixes the relationship of the coefficients.  $ \frac{\sqrt{2}}{2} $ is just the normalization factor. More generally, for a system of two Bosons, one at state with some property (or properties)  $ \varepsilon_{1} $, the other with property  $ \varepsilon_{2} $, the proper form of the physical state is:

 $$ |\psi_{_{1,2}}>_{b o s o n}=\frac{\sqrt{2}}{2}(|1,\varepsilon_{_{1}};2,\varepsilon_{_{2}}>+|2,\varepsilon_{_{1}};1,\varepsilon_{_{2}}>)^{88} $$ 

Since within |2,  $ \varepsilon_1 $;1,  $ \varepsilon_2 $ >, where you put particles with associated property is arbitrary, i.e. |2,  $ \varepsilon_1 $;1,  $ \varepsilon_2 $ >=|1,  $ \varepsilon_2 $;2,  $ \varepsilon_1 $ > So, I will also write (13-6) in terms of:

 $$ |\psi_{1,2}>_{b o s o n}=\frac{\sqrt{2}}{2}(|1,\varepsilon_{1};2,\varepsilon_{2}>+|1,\varepsilon_{2};2,\varepsilon_{1}>) $$ 

Obviously with the form of 13-6 (or 13-6'), it satisfies the symmetry requirement for Boson (13-4), i.e.  $ \hat{P}_{12} \mid \psi_{12} \geq \mid \psi_{12} \rangle $ for these two-particle systems. For many Boson particles, say N, then:

 $$ |\psi_{1,2,\ldots N}>_{b o s o n}=\frac{1}{\sqrt{N!}}\sum_{\substack{p e r m u t a t i o n o f N t e r m s}}^{\perp}\mathcal{E}_{1};2,\mathcal{E}_{2}...;N,\mathcal{E}_{N}> $$ 

For the two-Fermions case (such as two electron), similar argument with respect to the symmetry requirement by 13-5 would lead us to the proper description of the physical state:

 $$ \begin{aligned}|\psi_{1,2}>_{fermion}=&\frac{\sqrt{2}}{2}(|1,\varepsilon_{1};2,\varepsilon_{2}>-|2,\varepsilon_{1};1,\varepsilon_{2}>)\\=&\frac{\sqrt{2}}{2}(|1,\varepsilon_{1};2,\varepsilon_{2}>-|1,\varepsilon_{2};2,\varepsilon_{1}>)\end{aligned} $$ 

(13-8) satisfies (13-5). For the case of many fermions, the expression of the state would be in a form given by Slater Determinant :

If we have total of n fermions, and we have n normalized states specified by some quantum number  $ \varepsilon_{i} $ occupied by the fermions, the total state that

is antisymmetric with respect to permutation is given by:

 $$ |\psi>_{f e r}=\frac{1}{\sqrt{n!}}\left|\begin{matrix}|1,\varepsilon_{1}>&|1,\varepsilon_{2}>&\ldots|1,\varepsilon_{n}>\\ |2,\varepsilon_{1}>&|2,\varepsilon_{2}>&\ldots|2,\varepsilon_{n}>\\ \end{matrix}\right|\\ \left|\begin{matrix}\\ |n,\varepsilon_{1}>&|n,\varepsilon_{2}>&\ldots|n,\varepsilon_{n}>\\ \end{matrix}\right.\\ \end{matrix}\right. $$ 

Often, we express the vector in the wave function form, such as electrons in the hydrogen-like orbitals (include the spin), in this case:

|1,  $ \varepsilon_1 $  $ \rightarrow $  $ \phi_1\chi_1(1) $, where  $ \phi $ is the spatial orbital,  $ \chi $ is the spin function, and (1) means for the electron labeled with 1, the Slater determinant:

 $$ \psi_{f e r}=\frac{1}{\sqrt{n!}}\left|\begin{matrix}\phi_{1}\chi_{1}(1)&\phi_{2}\chi_{2}(1)...&\phi_{n}\chi_{n}(1)\\ \phi_{1}\chi_{1}(2)&\phi_{2}\chi_{2}(2)...&\phi_{n}\chi_{n}(2)\\ &\\ &\phi_{1}\chi_{1}(n)&\phi_{2}\chi_{2}(n)...&\phi_{n}\chi_{n}(n)\end{matrix}\right| $$ 

Comment on Slater determinant:

(1) The form of the matrix is easy to remember, for the  $ a_{ij} $ element: i is the particle label; j is the wave function label. There are n! terms in the determinant, each is a tensor product of single-particle type functions (just multiplications); the  $ \frac{1}{\sqrt{n!}} $ is for normalization.

(2) Using the determinant property, it is easy to see that if we exchange labels of two fermions (permutation), it is equivalent to exchange two rows of the determinant, the result is clearly antisymmetric (-1). You can also use the transposed matrix to represent the state for fermion.

(3) The two antisymmetric states represented by two different

determinants will be orthogonal. Here the difference means there are different orthogonal single-particle wave functions in the matrix, say one determinant contains  $ \phi_{1}\alpha $, in the other  $ \phi_{1}\alpha $ is replaced by  $ \phi_{1}\beta $,  $ \alpha,\beta $ are orthogonal; then the two determinants will be orthogonal too. (Please prove it yourself)

## (4) Pauli Exclusion Principle:

No two fermions can occupy the same state.

This famous result is a direct consequence of the anti-symmetric requirement on the total state or wave function. If the two fermions occupy the same state, for instance, they both have  $ \psi_{100}\alpha $ i.e. both electrons are in 1s orbital with spin up. Then there will be two identical columns in the determinant, and the total wave function will be zero.

## 13 -3 Examples

Here I shall give some relatively simple examples to illustrate what we had learned above on identical particles. First, I shall talk about wave functions for a multi-electron atom (use Helium mostly as example). There are still quite a lot knowledges missing here, such as how we calculate the wave functions (the so called Hartree-Fock method), how we determine the good quantum numbers (the addition of angular

momentum). All these important topics will not be covered here, and I only focus on the permutation symmetry requirement. The next example will be the qualitative treatment on scattering result between identical particles, described in the opening example in this chapter. We shall see the permutation symmetry gives different interference terms for bosons and fermions.

## 13 -3-1 Muti-electron Atom

The Pauli Exclusion Principle is useful to construct the electron configurations in multi-electron atoms. Since electrons are fermions and there are only 2 spin states “up” and “down”, so it is impossible to put all electrons to one spatial orbital. Every spatial orbital at most can have two electrons (if it contains 2, then one has to be up the other down). That is why you see the electronic configuration people used often. For example, the ground state of He: 1s² (2 electron in the 1s type spatial orbital), the next excited state is: 1s2s; ground state of Li: 1s²2s....

However the configuration does not tell you the details of the total wave function, and that is what I shall discuss in some detail in this example, to see what the wave function forms for a given configuration are. This is actually a quite complicated matter for many electron cases, so I shall only limit to the Helium and discuss its ground state and the first excited state.

## (1) Ground state helium

The electron configuration is  $ 1s^{2} $, meaning one electron in the 1s orbital with spin up and the other in the same 1s with spin down. Here I should mention that the 1s orbital here is different from the  $ \psi_{100} $ in hydrogen. It has to be calculated with the Hamiltonian in helium which contains electron repulsion term (try to write the Hamiltonian for the He yourself). Solving that with approximation method will give us the 1s, 2s... orbitals. These are single electron wave functions bears some resemblance to the hydrogen, and we call it hydrogen-like orbitals. The total wave functions have to be antisymmetric, and there is only one determinant form for this configuration:

 $$ |\varepsilon_{1}>\rightarrow\phi_{1s}\alpha,\quad|\varepsilon_{2}>\rightarrow\phi_{1s}\beta $$ 

 $$  I use\quad\alpha\rightarrow|+>=|S=\frac{1}{2},S_{z}=\frac{1}{2}>,\\ \beta\rightarrow|->=|S=\frac{1}{2},S_{z}=-\frac{1}{2}>(\text{instead} $$ 

of α_ used before to save some type).

The total wave function in Slater determinant is:

 $$ \begin{aligned}\psi_{ground}=&\frac{1}{\sqrt{2}}\left|\phi_{1s}(1)\alpha(1)\quad\phi_{1s}(1)\beta(1)\right|\\=&\frac{1}{\sqrt{2}}[\phi_{1s}(1)\alpha(1)\phi_{1s}(2)\beta(2)-\phi_{1s}(1)\beta(1)\phi_{1s}(2)\alpha(2)]\end{aligned} $$ 

Rearrange above:

 $$ \psi_{ground}=\phi_{1s}(1)\phi_{1s}(2)\frac{1}{\sqrt{2}}[\alpha(1)\beta(2)-\beta(1)\alpha(2)] $$ 

The reason for the form of  $ (13-11) $ will be clear once you learned the

addition of angular momentum.Since we have not formally discussed

angular momentum in quantum, leave alone their additions. I shall

only give the result without proof on this addition of angular

momentum issue.

Each electron has orbital angular momentum and spin, with wave

functions associated to them. Now we have two electrons, it turns out

the good quantum number (the one from the operators commuting

with Hamiltonian) comes from the total orbital angular momentum:

 $ \widehat{L} = \widehat{l}_{1} + \widehat{l}_{2} $ and total spin:  $ \widehat{S} = \widehat{S}_{1} + \widehat{S}_{2} $ (we neglect spin-orbit coupling).

Knowing the eigenfuctions of the individual angular momentum, we

can find out the eigenfunction of the total angular momentum (it is

essentially a base transformation and the matrix elements related to

them are Clebsch-Gordan coefficients) $ ^{89} $.

The  $ \phi_{ls}(1)\phi_{ls}(2) $ is the eigenfunction with total orbital angular momentum  $ L=0 $ (M=0 too then); and  $ \frac{1}{\sqrt{2}}[\alpha(1)\beta(2)-\beta(1)\alpha(2)] $ is the eigenfunction with total spin  $ S=0 $ ( $ S_{z}=0 $ too). The atomic symbol for such state is:

 $ ^{2S+1}L $ (and historically people use S for L=0,P for L=1, D for L=2...)

The 2S+1 is called multiplets, and if 2S+1=1, it is called siglet; if it is

3, triplets... So for the ground state Helium, the wave function is

(13-11) and the symbol is:  $ ^{1}S $

## (2) Excited state of helium

The lowest configuration in energy will be 1s2s, i.e. one electron is excited from 1s to 2s. How do we know the wave function form for this excited configuration? You see right away there are a few states correspond to the configuration once we consider the possible spins of electron. There are total of 4 possible combinations, thus 4possible determinants for the 4 states:  $ \left|\phi_{1s}\alpha\phi_{2s}\alpha\right| $,  $ \left|\phi_{1s}\alpha\phi_{2s}\beta\right| $,  $ \left|\phi_{1s}\beta\phi_{2s}\alpha\right| $ and  $ \left|\phi_{1s}\beta\phi_{2s}\beta\right| $. Each term is a determinant, for example:

 $$ \begin{aligned}&D_{1}\equiv\left|\phi_{1s}\alpha\phi_{2s}\alpha\right|=\frac{1}{\sqrt{2}}\left|\phi_{1s}(1)\alpha(1)\quad\phi_{2s}(1)\alpha(1)\right|\\ &\quad=\frac{1}{\sqrt{2}}[\phi_{1s}(1)\alpha(1)\phi_{2s}(2)\alpha(2)-\phi_{2s}(1)\alpha(1)\phi_{1s}(2)\alpha(2)]\\ &\quad=\frac{1}{\sqrt{2}}[\phi_{1s}(1)\phi_{2s}(2)-\phi_{2s}(1)\phi_{1s}(2)]\alpha(1)\alpha(2)\\ \end{aligned} $$ 

The rest D₂, D₃, D₄ correspond to |φ₁s αφ₂s β |, |φ₁s βφ₂s α | and |φ₁s βφ₂s β | will be left for you to write out.

These are the states satisfying the anti-symmetric requirement, however they are not the usual form used to express the excited state for 1s2s configuration. We can linearly combine those D terms to form functions which are eigenfunctions for the total L and S angular momentum (this is called angular momentum adapted). Unfortunately, the addition of angular momentum theory usually starts with unsymmetrized tensor product of wave functions to express the eigenfunction of total L and S, and that needs to be symmetry adapted.

Here is how:

The addition of two s orbitals (l=0) could only give total L=0 (M=0); the addition of two spin=1/2 will be a bit complicated, it can give total spin S=1, and thus  $ S_{z}=1,0,-1 $; it can also give a total S=0 ( $ S_{z}=0 $). The results of eigenfunction of L and S given as combination of eigenfunction of individual angular momentum are (all the paragraph and (13-13 to 13-15) are given without proof):

Orbital part: L = 0 (M = 0) → φ1s (1) φ2s (2)

Spin Part:

 $$ S=1\begin{cases}S_{z}=1\rightarrow\alpha(1)\alpha(2)\\S_{z}=0\rightarrow\frac{1}{\sqrt{2}}[\alpha(1)\beta(2)+\alpha(2)\beta(1)]\\S_{z}=-1\rightarrow\beta(1)\beta(2)\end{cases} $$ 

 $$ S=0\rightarrow\frac{1}{\sqrt{2}}[\alpha(1)\beta(2)-\alpha(2)\beta(1)] $$ 

The complete state with certain L, M, S,  $ S_{z} $ will be tensor product of

above so far. For example:

 $$ |L=0,M=0,S=1,S_{z}=1\geq\phi_{1s}(1)\phi_{2s}(2)\alpha(1)\alpha(2) $$ 

However, we have to be aware that the permutation symmetry have not been considered yet above, and the wave function (13-16) though it is an eigenfunction with unique angular momentum, obviously does not fit the antisymmetry requirement. There is extra exchange degeneracy, the  $ \phi_{1s}(2)\phi_{2s}(1) $ is also the eigenfunction of L=0. We can find out the symmetry adapted wave functions from above results

(13-13 to 13-16). This can be done in two ways.

First method: we notice the spin part (13-14) for S=1 are symmetric with permutation, so that if the total wave function need to be antisymmetric, the orbital part has to be antisymmetric, and it can be antisymmetrize to:  $ \frac{1}{\sqrt{2}}[\phi_{1s}(1)\phi_{2s}(2) - \phi_{1s}(2)\phi_{2s}(1)] $. Thus, the correct forms (symmetry adapted eigenfunctions of angular momentum for 2 electrons)  $ |L,M,S,S_z> $ are (these are the states for atomic symbol  $ ^3S $):

 $$ \begin{aligned}&|0,0,1,1>=\frac{1}{\sqrt{2}}[\phi_{1s}(1)\phi_{2s}(2)-\phi_{1s}(2)\phi_{2s}(1)]\alpha(1)\alpha(2)\\&|0,0,1,-1>=\frac{1}{\sqrt{2}}[\phi_{1s}(1)\phi_{2s}(2)-\phi_{1s}(2)\phi_{2s}(1)]\beta(1)\beta(2)\\&|0,0,1,0>=\frac{1}{2}[\phi_{1s}(1)\phi_{2s}(2)-\phi_{1s}(2)\phi_{2s}(1)][\alpha(1)\beta(2)+\alpha(2)\beta(1)]\\ \end{aligned} $$ 

For the S=0 state, the spin part is antisymmetric, then the orbital part has to be symmetric (this is the state for atomic symbol  $ 2^{1}S $, since the ground state is also a  $ ^{1}S $, that is why this one has 2 in front of it):

 $$ |0,0,0,0>=\frac{1}{\sqrt{2}}\phi_{1s}(1)\phi_{2s}(2)[\alpha(1)\beta(2)-\alpha(2)\beta(1)] $$ 

Second method: we can start from (13-16) which does not have particular symmetric property, but we can project out the antisymmetric part $ ^{90} $:

 $$ |\psi>=\sum_{i}<D_{i}|\psi>|D_{i}> $$ 

|D_{i}> are determinant forms in (13-12), its antisymmetric but may not be eigenfunctions of total angular momentum. |D_{i}> are orthogonal so that we can find out antisymmetric form as (13-19). For example, the state with form of (13-16) will only have |D_{1}>component:

<D_{1}|\phi_{1s}(1)\phi_{2s}(2)\alpha(1)\alpha(2)>={\frac{1}{\sqrt{2}}}, the rest of the coefficients in (13-19) will be zero. So the |0,0,1,1> state only contains the |D_{1}> and with renormalization within the antisymmetric subspace, we have:

 $$ |0,0,1,1>=\mid D_{1}> $$ 

It will be same as first relation in (13-17) with (13-12) for  $ |D_1\rangle $.

For the  $ |0,0,1,0\rangle $, we can start from direct product combining (13-13)

and (13-14):

 $ |0,0,1,0 \rightarrow \phi_{1s}(1)\phi_{2s}(2)\frac{1}{\sqrt{2}}[\alpha(1)\beta(2) + \alpha(2)\beta(1)] $ which is not symmetry adapted, but can find out the  $ |D> $ component and with proper normalization, the result is:

 $$ |0,0,1,0>=\frac{1}{\sqrt{2}}(|D_{2}>+|D_{3}>) $$ 

Similarly

 $$ \begin{aligned}&|0,0,1,-1>=\mid D_{4}>\\&|0,0,0,0>=\frac{1}{\sqrt{2}}(\mid D_{2}>-\mid D_{3}>)\end{aligned} $$ 

These will be same as given in (13-17) and (13-18) if you plug in the specific form of the D's.

These wave functions are symmetry adapted and with certain angular

momentum for the excited helium configuration 1s2s. Such wave

functions will play important roles in the accurate calculation of

energy state in multi-electron atoms.

## 13 -3-2 Collisions between Identical Particles

After we have equipped with this knowledge for many body system of identical particles, the results of experiment shown in fig.3-8 at the beginning of this chapter can be fully derived from using quantum postulates.

(1)Interference term in collisions among identical particles

For the two Boson particles ( $ \alpha $ particles for instance), the initial state is:

 $$ |\psi_{1,2}>_{iboson}=\frac{\sqrt{2}}{2}(|1,L;2,R>+|2,L;1,R>) $$ 

(This state is quite different from that of non-identical case, which is

 $$ |A,L;B,R>\mathrm{o n l y}) $$ 

The product state after collision is:

 $ \psi_{1,2} >_{boson} = \hat{O} \mid \psi_{1,2} >_{ibonson} $, where  $ \hat{O} $ is the interaction operator during collision.

Expand this product state into components of in terms of  $ |1,\theta;2,\pi-\theta> $ (please refer to the part of non-identical case for the meaning of notations used below):

 $$ \begin{aligned}&|\psi_{1,2}>_{b o s o n}=\hat{O}\left|\psi_{1,2}\right>_{i}=\frac{\sqrt{2}}{2}\hat{O}(|1,L;2,R>+|2,L;1,R>)\\ &=\frac{\sqrt{2}}{2}\sum...+(f(\theta)\left|1,\theta;2,\pi-\theta>+f(\pi-\theta)\right|1,\pi-\theta;2,\theta>)+\\ &\quad(f(\pi-\theta)\left|1,\theta;2,\pi-\theta\right)+f(\theta)\left|1,\pi-\theta;2,\theta>\right)+...\\ &=\frac{\sqrt{2}}{2}\sum...[f(\theta)+f(\pi-\theta)]\left|\varphi_{\theta}>+[f(\theta)+f(\pi-\theta)]\right|\varphi_{\pi-\theta}>+...\\ \end{aligned} $$ 

The eigenstate of the detection is also the state representing this

two-identical particle case, so that it would also satisfy the permutation

symmetry. The state is one particle goes to direction  $ \theta $ and the other goes

to direction  $ \pi - \theta $. The proper expression for this eigenstate is:

 $$ |\theta;\pi-\theta>_{b o s o n}=\frac{\sqrt{2}}{2}(|1,\theta;2,\pi-\theta>+|1,\pi-\theta;2,\theta>)=\frac{\sqrt{2}}{2}(|\varphi_{\theta}>+|\varphi_{\pi-\theta}>) $$ 

Then the probability of the detection from that of postulate 3 is:

 $$ P(D_{1})_{b o s o n}=|\langle\theta;\pi-\theta|\psi_{12}>|^{2}=|f(\theta)+f(\pi-\theta)|^{2} $$ 

If you did not expand the initial state in terms of  $ |1, \theta; 2, \pi - \theta> $ above, you could also work out the results directly from:

 $$ \begin{aligned}&<\theta;\pi-\theta\left|\psi_{12}\right>=\frac{\sqrt{2}}{2}(<1,\theta;2,\pi-\theta|+<1,\pi-\theta;2,\theta|)\frac{\sqrt{2}}{2}\hat{O}(|1,L;2R>+|1,R;2L>)\\ &=\frac{1}{2}(<1,\theta;2,\pi-\theta\left|\hat{O}\right|1,L;2R>+<1,\theta;2,\pi-\theta\left|\hat{O}\right|1,R;2L>+\\ &\quad<1,\pi-\theta;2,\theta\left|\hat{O}\right|1,L;2R>+<1,\pi-\theta;2,\theta\left|\hat{O}\right|1,R;2L>)\\ &=\frac{1}{2}(f(\theta)+f(\pi-\theta)+f(\pi-\theta)+f(\theta))\\ &=f(\theta)+f(\pi-\theta)\\ \end{aligned} $$ 

Same result as above. Here  $ f(\theta) = <1, \theta; 2, \pi - \theta \mid \hat{O} | 1, L; 2R> $, the probability amplitude for one particle from the left to end into detector

D1 (so the other particle from right would end in D2 direction) and similar meanings for other <|> terms. This is exactly the meaning of  $ f(\theta) $ defined before.

Similar calculation for the two identical fermions such as electrons, the results is (try it yourself with the antisymmetric states):

 $$ |f(\theta)-f(\pi-\theta)|^{2} $$ 

Feynman's summary that if the events or processes (or other names) are distinguishable, then it is the summation of probability (i.e. no interference); if the events are indistinguishable, it is the square of the summation of amplitudes that gives the probability. This is a useful summary, you may treat it as a principle as stated in his book. But what I have shown here and in example 2 in chapter 11, Feynman's summary is the results of postulates of Q.M., which are the principles underlying his statement.

Let me discuss this example a little further. Considering the collision between two electrons (fermions) but this time with different spin states, say the electron from the left with spin 1/2 (I shall use the conventional symbol  $ \uparrow $ for this), the other electron from the right side with spin -1/2( $ \downarrow $). Then what is the result for detector D1 register the electron? The D1 here does not recognize the spin state, it just record the particle no matter what is its spin state. (this is shown in Feynman's fig.3-9):

<div style="text-align: center;"><img src="imgs/img_in_image_box_216_170_843_432.jpg" alt="Image" width="52%" /></div>


<div style="text-align: center;">Fig. 3–9. The scattering of electrons with antiparallel spins.</div>


According to the argument in the book, there are two processes in the measurement: one electron with spin up (↑) from the left will be scattered along direction θ and the other (↓) will be along π-θ, (a) in the figure. The other is electron (↑) from the left will be scattered along direction π-and the other will be along θ, (b) in the figure. Since these two processes are distinguishable, so it will be summation of probability directly and give  $ |f(\theta)|^{2} + |f(\pi - \theta)|^{2} $. One may ask why this result even though the detector cannot tell the spin apart, for D1 the electrons with spin up or spin down would make no difference. Feynman's argument is in principle we could tell these apart (by measuring the spins like Stern-Gerlach of course), so these are really not indistinguishable processes. But one may further question that how come that “we could tell the difference” has anything to do with an experiment results that we do not measure that difference (in this example, the spin states. Here we only prepare the initial spin state into up or down, say using S-G setup, but we do not measure it anymore afterwards). The above argument seems suggesting that human's will could affect the results? How can that

be true?

This puzzle will disappear if we work out this problem from the postulates

of Q.M. directly rather than from Feynman's principle. Here is how it is

solved from this:

First the description of the initial state: Here is what we know. The electron from the left always is in spin up state; the electron from right always with spin down. So the state property in this case would be ↑L; ↓R. Put this in a state description for 1 electron in the ↑L state, the other in ↓R would be:

 $$ |1,\uparrow,L;2,\downarrow,R>91 $$ 

However, we learned that the labeling for identical particles are arbitrary and exchange them has to satisfy the permutation symmetry. For the fermions, the proper state for these two particle system would be:

 $$ \begin{aligned}|\psi_{12}>_{i}=&\frac{\sqrt{2}}{2}(|1,\uparrow,L;2,\downarrow,R>-|2,\uparrow,L;1,\downarrow,R>)\\=&\frac{\sqrt{2}}{2}(|1,\uparrow,L;2,\downarrow,R>-|1,\downarrow,R;2,\uparrow,L>)^{92}\end{aligned} $$ 

After collision the product state will be:

 $$ |\psi_{12}>={\hat{O}}|\psi_{12}>_{i} $$ 

Secondly what is the eigenstate of the detection? We know that there are two exclusive events here in the detection: one is as in fig.3-9 (a), the spin up ends in D1, and spin down in D2; the other would be spin up ends in D2, spin down in D1 as in fig. 3-9 (b). Let's consider the eigenstates for the case (a): one electron with spin up being scattered into direction  $ \theta $, while the other with spin down into  $ \pi-\theta $. The proper description for this eigenstate would be:

 $$ \begin{aligned}|\uparrow,\theta;\downarrow,\pi-\theta>=\frac{\sqrt{2}}{2}(|1,\uparrow,\theta;2,\downarrow,\pi-\theta>-|1,\downarrow,\pi-\theta;2,\uparrow,\theta>)\end{aligned} $$ 

Now we could calculate the probability of detection in case (a):

 $$ P(\uparrow D1,\downarrow D2)=|\langle\uparrow,\theta;\downarrow,\pi-\theta\mid\psi_{12}\rangle|^{2} $$ 

We can put above expressions for the states to evaluate the Bracket:

 $$ \begin{aligned}<\uparrow,\theta;\downarrow,\pi-\theta\mid\psi_{12}>=&\frac{1}{2}(<1,\uparrow,\theta;2,\downarrow,\pi-\theta|-<1,\downarrow,\pi-\theta;2,\uparrow,\theta|)\\&\hat{\mathrm{O}}(|1,\uparrow,L;2,\downarrow,R>-|1,\downarrow,R;2,\uparrow,L>)\\\end{aligned} $$ 

There will be total of four terms in forms of BraKet, I will evaluate each term below:

 $$ <1,\uparrow,\theta;2,\downarrow,\pi-\theta\mid\hat{O}\mid1,\uparrow,L;2,\downarrow,R>=<1,\theta;2,\pi-\theta\mid\hat{O}\mid1,L;2,R>=f(\theta) $$ 

Here use the orthonormal conditions of the spin states for each particle and the result of this term will give the  $ f(\theta) $ same meaning as before. Of course I assume here that the interaction during the collision (the O operator) do not change the spin state (that is why I can take the spin state out of operator and dot product them). Indeed if the spin state can be switched during the collision, then you cannot tell the spin up ends at

the detector comes from right or left! Then we would expect some interference.

 $$ <1,\downarrow,\pi-\theta;2,\uparrow,\theta\mid\hat{O}\mid1,\uparrow,L;2,\downarrow,R>=0 $$ 

Because of for particle 1 or 2,  $ \langle\uparrow\downarrow\rangle=0^{93} $

Similarly:

 $$ <1,\uparrow,\theta;2,\downarrow,\pi-\theta|\hat{O}|1,\downarrow,R;2,\uparrow,L>=0 $$ 

 $$ <1,\downarrow,\pi-\theta;2,\uparrow,\theta\mid\hat{O}\mid1,\downarrow,R;2,\uparrow,L>=f(\theta) $$ 

So:

 $$ P(\uparrow D1,\downarrow D2)=|\langle\uparrow,\theta;\downarrow,\pi-\theta\mid\psi_{12}>|^{2}=|\frac{1}{2}(f(\theta)+f(\theta))|^{2}=|f(\theta)|^{2} $$ 

For the case (b), you should be able to find out that:

 $$ P(\downarrow D1,\uparrow D2)=|\prec\downarrow,\theta;\uparrow,\pi-\theta\mid\psi_{12}>|^{2}=|f(\pi-\theta)|^{2} $$ 

The probability for detector D1 to detect either spin up or down would be the summation of the two probabilities calculated above, since these two events are exclusive.

You may now ask what happened if both electrons are spin up? Well this is actually already solved before without explicitly involving the spin states. Here if we include the spin states, I will only outline the procedure without detailed calculation.

First the description of the initial state would be:

 $$ \begin{aligned}|\psi_{12}>=&\frac{\sqrt{2}}{2}\hat{O}(|1,\uparrow,L;2,\uparrow,R>-|2,\uparrow,L;1,\uparrow,R>)\\=&\frac{\sqrt{2}}{2}\hat{O}(|1,\uparrow,L;2,\uparrow,R>-|1,\uparrow,R;2,\uparrow,L>)\\\end{aligned} $$ 

Second the eigenstate for detection is:

 $$ \begin{aligned}|\uparrow,\theta;\uparrow,\pi-\theta>=\frac{\sqrt{2}}{2}(|1,\uparrow,\theta;2,\uparrow,\pi-\theta>-|1,\uparrow,\pi-\theta;2,\uparrow,\theta>)\end{aligned} $$ 

Here case (a) and (b) becomes indistinguishable and the eigenstate is given as above. Then you carry out the calculation for the detection, you will find that the probability for D1 detecting an electron would be:  $ |f(\theta) - f(\pi - \theta)|^2 $.

In summary, all the above discussions showed that for identical particles and indistinguishable processes, the probability is squared of summation of amplitudes. For Bosons, it has the form of  $ \left|f(\theta)+f(\pi-\theta)\right|^{2} $, and  $ \left|f(\theta)-f(\pi-\theta)\right|^{2} $ for fermions. Interference comes directly from this form. (Recall the previous discussion of interference of light in classical theory, where math form is exactly same). Here the numbers  $ f(\theta) $ and  $ f(\pi-\theta) $ are generally complex numbers, so the results really depend on their relative phases. In one special case, where

$$f(\theta)=f(\pi-\theta)\quad(\theta=90^{\circ}),\text{then the probability for detecting Bosons}$$

along this direction would be $4f^{2}$; and that for fermions would be 0; while

for non-identical particles, this value is $2f^{2}$.

(2) ‘Antisocial’ electrons and ‘social’bosons

The symmetry and anti-symmetry with respect to the permutation for

bosons and fermions have profound effect in physics. The most important is Pauli exclusion principles for fermions we had mentioned. It states that no two fermions can occupy the same quantum state. So the fermions are really ‘anti-social’ in this sense.

For bosons, there is no such restrictions and they are indeed very ‘social’ in the sense that they have larger probability to go into the same state. As discussed in Feynman’s book, chapter 4 (4.2, 4.3 and 4.4) and this is the reason for the phenomenon called stimulated emission of photon (or as somebody also calls it induced emission which is more lively). The book has a detailed discussion and it based on the derivation I elaborated above for the identical particles, so I only give a brief summary here without lengthy explanation.

States with two or many (N) Bosons (section 4-2,4-3 in Feynman)

Equipped with the quantum description of identical particles, I hope you would have little difficulty to understand this part. In the book, Feynman used fig. 4-3, 4-4 to explain that bosons intends to be ‘induced’, i.e. they like to end into the same quantum state. The probability for the boson to go into a state is enhanced if there are already bosons in that state.

<div style="text-align: center;"><img src="imgs/img_in_image_box_214_174_477_471.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;">Fig. 4–3. A double scattering into nearby final states.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_542_193_818_476.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;">Fig. 4–4. The scattering of n particles into nearby final states.</div>


This is really a natural conclusion from the  $ |f(\theta)+f(\pi-\theta)|^2 $ results in boson scattering. We see there that due to interference, along certain direction which corresponds to the final state of the particle, the probability of bosons being scattered into that direction is enhanced. The book contains a detailed arguments in two boson case. It shows that  $ P_2 $, the probability for two bosons ending in the same final state, is twice as big as that for two non-identical particles. Following the derivation given in the example 4 here, we can derive this probability (the case in fig. 4-3):

Initial state for two photon, one along path a and the other along b:

 $$ |\psi_{12}>=\frac{\sqrt{2}}{2}(|1,a;2,b>+|1,b;2,a>) $$ 

The final state after scattering is: 94

 $$ |1,\theta;2,\theta> $$ 

Then the probability for the initial photons ending into the final state:

 $$ P_{2b o s o n}=|<1,\theta;2\theta\mid\psi_{12}>|^{2}=\frac{1}{2}\mid a b+b a\mid^{2}=2\mid a\mid^{2}\mid b\mid^{2} $$ 

Here:

 $$ \begin{aligned}&<1,\theta;2,\theta\mid1,a;2,b>=<1,\theta\mid1,a><2,\theta\mid2,b>=ab\\&<1,\theta;2,\theta\mid1,b;2,a>=<1,\theta\mid1,b><2,\theta\mid2,a>=ba\\ \end{aligned} $$ 

If the detector has a small area of  $ \Delta s $, then the probability for single particle taking the a (or b) path to be scattered into final state is  $ |a|^2 \Delta s $ (or  $ |b|^2 \Delta s $ for b), the probability amplitude would be  $ a(\Delta s)^{1/2} $ and  $ b(\Delta s)^{1/2} $ respectively for the two paths. The above results would be adjusted:

 $$ P_{_{2boson}}=\frac{1}{2}\left|ab\Delta s+ba\Delta s\right|^{2}=2\left|a\right|^{2}\left|b\right|^{2}\left(\Delta s\right)^{2} $$ 

The |a|2|b|2(Δs)² is just the probability for two non-identical particles

being scattered into the detector. So this shows:

P(2boson → same state) = 2P(2 non−identical → same state)

(for fermions this probability would be zero)

Another way to put the above results is this: If there is already a boson in

certain final state (here in this example, it is the final direction, let's say

photon along path b has already been scattered into this direction,

 $ |b|^2\Delta s=1 $, another boson will be more likely to go into the same state.

Comparing to the probability of single particle, the probability is

increased by 2.

As the number of bosons increases, this tendency is even more obvious.

For the n bosons all scattered into the same state is given by (4-20) in

Feynman's, it is easy to derive:

 $$ |\psi_{n-b o s o n s}>=\frac{1}{\sqrt{n!}}\sum_{\substack{p e r m u t a t i o n\\ o f\ n\ t e r m s}}|1,a;2,b;3,c;...> $$ 

 $$ P_{n-boson}=|<1,\theta;2,\theta;3,\theta...|\psi_{n-boson}>|^{2}=n!|a|^{2}|b|^{2}|c|^{2}...(\Delta s)^{n} $$ 

The probability for n non-identical particles to end into one state is:

 $$ P_{n}(non-identical)=|a|^{2}|b|^{2}|c|^{2}\ldots(\Delta s)^{n} $$ 

 $$ So\quad P_{n}(bosons)=n!P_{n}(non-identical) $$ 

Also, let's imaging that we add another boson to the n-bosons, and what

is the probability of this extra boson to end into the final state with n

bosons already there. For the extra boson, if it is alone (along come

initial path  $ \omega $, its probability into final direction is:

 $$ \left|<1,\theta\right|1,path\ \omega>|^{2}\Delta s=\left|\omega\right|^{2}\Delta s $$ 

To have n+1 bosons into same state, from 11-34 the probability is:

 $$ P_{n+1}(bosons)=(n+1)\mid\omega\mid^{2}\Delta s P_{n}(bosons) $$ 

This last relation means that if there are already n bosons in the final

state (given by Pn), then for another boson to end up in the same state is

enhanced by a factor of  $ n+1 $, comparing to the single boson case

 $$ (|\omega|^{2}\Delta s). $$ 

An interesting application of this is discussed in Feynman's 4-4, the absorption and emission of light.

## Chapter 14 Application of Quantum Theory to Molecule and Solid State

In this chapter, I shall apply what we have learned to the more

complicated system, namely molecules and solid state. Of course I have

to confess there are quite a few basic topics needed for a somewhat

detailed discussion on these; such as angular momentum, approximation

methods etc. which I have not covered. Also as in multi-electron atom

case, we do not have rigorous analytic solutions for most cases. However,

from what we had learned, I can show you why the molecule bond

together; why there is so called energy band structure in solid. These are

the main focus in this chapter. I shall explain in detail in the molecular

case, using the simplest molecular ion  $ H_{2}^{+} $ as example; while for the

solid state, the Griffiths' section 5.3 gives a nice discussion, and hence I

shall leave you to read that for the solid part.

## 14 -1 Molecular Obital and Bonding in  $ H_{2}^{+} $

When you come across molecule in chemistry (high school or college), people usually say that the reason we have a stable molecule is due to mutual balance between attraction (lowing the energy) between electron-nuclei and repulsion (raise) between nucleus-nucleus and electron-electron. The resulting is there are energetically stable states (so

called bonding molecular orbitals), meaning the energy of the molecule is lower than that of the separated atoms composing the molecule. Chemists also like to use very intuitive picture showing the ‘bonds’ between atoms in molecule, claiming the more overlap between the ‘electron cloud’ (the atomic orbitals) the stronger the bond (the lower the energy). The above of course are true; but you have to wonder how these conclusions come from and it is the purpose of this section to use quantum theory to explain these. And for this purpose, I chose the simplest molecular ion  $ H_{2}^{+} $. It is simple because it contains one electron (so I do not need to worry about exchange degeneracy in identical particles) and we know the hydrogen atomic orbitals (states), but it is also sufficient to show us the basics in molecular bonding, i.e. how the energy is lowered in molecule; how the molecular orbital (state) is constructed with atomic orbitals; why the overlap of atomic orbitals forms bond.

## (1) Born-Oppenheimer approximation

The Hamiltonian for the  $ H_{2}^{+} $ is:

 $$ H=-\frac{\hbar^{2}}{2m}\Delta+\frac{1}{4\pi\varepsilon_{0}}(-\frac{e^{2}}{r_{1}}-\frac{e^{2}}{r_{2}}+\frac{e^{2}}{R}) $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_373_1270_721_1409.jpg" alt="Image" width="29%" /></div>


The r's and R are shown in the figure, N₁ and N₂ are the two nuclei.

Both r's and R can change in reality, however when consider the

electron’s motion, we shall treat the nuclei as fixed in space due to their slow motions. Thus R will be treated as a parameter rather than a variable in the calculation for electron. This ‘decoupling’ between the motion of electron and nuclei is the essential idea of

Born-Oppenheimer approximation. After calculate the electronic energy for a given R, it can be repeated for various R to get energy values E(R).

## (2) Two-Level system treatment

I shall first simplify the problem to a 2-level system, which is easy to solve as we shall see. Though this is a quite approximation, it illustrates many important aspects in forming molecules from atoms. When the R is large, the system is reduced to a hydrogen atom and a proton; the lowest energy for the electron will be in the 1s orbital of hydrogen. If the electron is close to N₁, the r₂ and R terms in H can be neglected at limit of large R, and the eigenstate for energy is just:

 $$ |\phi_{1}>\rightarrow<r|\phi_{1}>=\phi_{100}(r_{1}) $$ 

If the electron is close to N_{2}, the state is:

 $$ |\phi_{2}>\rightarrow<r|\phi_{2}>\Rightarrow\phi_{100}(r_{2}) $$ 

Above are eigenfunctions of the H only in the case of large R.

These two states (the localized atomic orbital) will act as zero order

state as R gets smaller and the extra terms in H cannot be neglected.

Since only two states involved, it is a typical two-level system. The

reason I only consider the above two-zero order states, neglecting other possible states (such 2s,2p...states in hydrogen), is because these two will have the largest contribution to the lowest energy state (ground state) in molecule; the contribution to molecular ground state by the high energy atomic state will be small (neglected here in my 2-level treatment). $ ^{95} $

So if I choose the basis as  $ |\phi_1>, |\phi_2> $, the H will not be diagonal when all the terms included. The following is a standard treatment for 2-level system, an easy one by diagonalizing a  $ 2 \times 2 $ matrix:

The Hamiltonian matrix in the basis of zero order states is:

 $$ \boldsymbol{H}=\begin{bmatrix}H_{11}&H_{12}\\ H_{21}&H_{22}\end{bmatrix} $$ 

 $$ H_{ii}=<\phi_{i}\mid H\mid\phi_{i}> $$ 

 $$ H_{ij}=<\phi_{i}\mid H\mid\phi_{j}>=H_{ji}^{*} $$ 

When the bases are orthogonal, i.e.  $ \langle \phi_i \mid \phi_j \rangle = \delta_{ij} $ (a note here: the  $ |\phi_1\rangle $,  $ |\phi_2\rangle $ localized atomic orbitals are actually not orthogonal, I shall treat them as orthogonal here as in the standard 2-level problem; I shall consider the effect of non-orthogonal in next section where the overlap integral will arise)

Let the eigenstate of H to be:

 $$ \left|\psi\right\rangle=\boldsymbol{c}_{1}\left|\phi_{1}\right\rangle+\boldsymbol{c}_{2}\left|\phi_{2}\right\rangle=\begin{bmatrix}\boldsymbol{c}_{1}\\ \boldsymbol{c}_{2}\end{bmatrix} $$ 

Note: the writing of it as column form needs the fact of orthogonal basis.

Then, the eigenvalue and eigenvector solution is a standard problem we had encountered several times:

 $$ \begin{aligned}&H\mid\psi>=E\mid\psi>\\&\begin{bmatrix}H_{11}-E&H_{12}\\H_{21}&H_{22}-E\end{bmatrix}\begin{bmatrix}c_{1}\\c_{2}\end{bmatrix}=0\\ \end{aligned} $$ 

The secular equation is:

 $$ (H_{11}-E)(H_{22}-E)-H_{12}H_{12}^{*}=0 $$ 

The solutions are:

 $$ \begin{aligned}&E_{+}=\frac{1}{2}(H_{11}+H_{22})+\frac{1}{2}\sqrt{(H_{11}-H_{22})^{2}+4\left|H_{12}\right|^{2}}\\ &E_{-}=\frac{1}{2}(H_{11}+H_{22})-\frac{1}{2}\sqrt{(H_{11}-H_{22})^{2}+4\left|H_{12}\right|^{2}}\\ \end{aligned} $$ 

Above is the general solution for 2-levelsystem with orthogonal basis.

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_982_945_1180.jpg" alt="Image" width="60%" /></div>


 $$ \begin{array}{ccc} \underline{{E_{+}}} \\ \hline H_{11} & & \underline{{E_{-}}} \end{array} \quad \begin{array}{ccc} & \underline{{}} \\ & H_{22} \\ \hline \end{array} $$ 

In our special case of  $ H_2^+ $, with  $ |\phi_1>,|\phi_2> $ in forms of (14-2) and (14-3), it is easy to see that  $ H_{11}=H_{22} $ (in the integral of  $ H_{22} $, if we switch label  $ r_1,r_2 $, the result will be exactly  $ H_{11} $; of course this is true because we have two same nuclei; it won’t hold for heteroatomic molecules). The energy splitting for the general case, and special

case  $ (H_{11}=H_{22}) $ are shown in the figure above.

Clearly from (14-9), we have energy splitting due to the interactions between electron with all nuclei (the extra terms in H). In our case when  $ H_{11}=H_{22} $, the splitting comes from the off-diagonal term. The lower energy will be more stable, and the wave function associated to it is called “bonding” orbital; the higher energy state is not stable, it likes to dissociate into atoms, and the wave function associated to it is thus called “anti-bonding”. Now let’s solve the wave function forms for the bonding and anti-bonding (We have already solved a similar problem in homework for the eigenstates of spin matrix). It is straightforward to get:

 $$ \begin{aligned}&|\psi_{+}>=\cos\frac{\theta}{2}e^{-i\frac{\varphi}{2}}|\phi_{1}>+\sin\frac{\theta}{2}e^{i\frac{\varphi}{2}}|\phi_{2}>\\&|\psi_{-}>=-\sin\frac{\theta}{2}e^{-i\frac{\varphi}{2}}|\phi_{1}>+\cos\frac{\theta}{2}e^{i\frac{\varphi}{2}}|\phi_{2}>\\ \end{aligned} $$ 

The  $ \theta,\varphi $ are:

 $$ \begin{aligned}&\tan\theta=\frac{2\left|H_{21}\right|}{H_{11}-H_{22}}\quad0\leq\theta\leq\pi\\&H_{21}=\left|H_{21}\right|e^{i\varphi}\\ \end{aligned} $$ 

Above are general formulas for any 2-level system.

For our  $ H_{2}^{+} $,  $ H_{11}=H_{22} $, thus  $ \theta=\frac{\pi}{2} $; we do not know the form of  $ H_{21} $ yet, but it can be shown for the attractive system (in the formation of molecule, we expect the attractive will win over the repulsion), it is a negative number (this will be shown in the next section when we

study the form of  $ H_{12} $ or  $ H_{21} $), thus  $ \varphi = \pi $. With these, the wave functions with higher and lower energies are:

 $$ \begin{aligned}&|\psi_{+}>=\frac{\sqrt{2}}{2}(|\phi_{1}>-|\phi_{2}>)\\&|\psi_{-}>=\frac{\sqrt{2}}{2}(|\phi_{1}>+|\phi_{2}>)\\ \end{aligned} $$ 

These are the eigenstates of the molecular Hamiltonian (14-1), and they are called molecular orbital. They are linear combinations of atomic orbitals, so this method is called LCAO-MO (linear combination of atomic orbitals to form molecular orbital). Graphically, I can draw the bonding  $ |\psi_{-}\rangle $ and the anti-bonding  $ |\psi_{+}\rangle $:

<div style="text-align: center;"><img src="imgs/img_in_image_box_222_771_519_959.jpg" alt="Image" width="24%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_641_800_965_1002.jpg" alt="Image" width="27%" /></div>


From the graph, we can interpret the calculation result as: for the electron in bonding orbital, it has considerable probability in space between the nuclei, i.e. there is considerable constructive overlap between the atomic orbitals. The electron will experience attractive force from both nuclei and also it shields the repulsion between the nuclei more effectively in such orbital. Thus it has lower energy and stable. That is the reason behind the qualitative description at the beginning of this section.

This concludes my discussion on the formation of molecule using the simplest 2-level system. The splitting of energy is a general result due to the existence of off-diagonal Hamiltonian elements. Next we shall investigate this more quantitatively, taken the non-orthogonality of atomic orbital basis into consideration.

Before doing that, I should mention, there are other ways to see the splitting of energy. For example, we can approximate the attraction of two nuclei with electron as 2 delta function potential (of course, this is not exactly Coloumb, so a crude approximation to ease computation) separated by distance R. The repulsion between nuclei is just a constant term shift the energy by a fixed  $ \frac{e^{2}}{4\pi\varepsilon_{0}R} $ for a given R. Then the electron with double-delta potential can be solved exactly in 1-D, as the problem 2.27 in Griffiths. Please do that and you will see the similar results (splitting of energy comparing to the energy of single delta potential; and the forms of wave fucntions with high and low energy).

## (3) Detailed LCAO-MO treatment

In this section, we follow the idea introduced above: Using the atomic orbitals as zeroth order state and linear combine them to form molecular orbitals that diagonalize the Hamiltonian, i.e. the stationary state for molecule.

In the crude approximation, we only use the |φ1>,|φ2> in (14-2) and

(14-3), the two localized Is orbital, as the basis. The molecular orbital would be in form of:

 $$ \left|{{\psi}}\right>=c_{1}\left|{{\phi_{1}}}\right>+c_{2}\left|{{\phi_{2}}}\right>\qquad(14-13) $$ 

The two linear independent (LI) base vectors will form two LI molecular orbitals, corresponding to the lowest bonding and antibonding orbitals. One obvious defect is that we only include two base vectors, while we should include more (such as 2s, 2p, 3s, 3p, 3d...) if we need accurate results. As I mentioned in last section, the two 1s will make the most important contribution and also are sufficient to illustrate the basic character in chemical bond, so I shall use the two base vectors only (this makes it a 2-level system).

In the usual treatment in 2-level system, the zeroth order states are usually chosen orthonormal, which is what I used in last section. However, a look on the  $ |\phi_1>,|\phi_2> $ will reveal that their dot product  $ <\phi_1|\phi_2>\neq0 $. The  $ |\phi_1>,|\phi_2> $ here are two real functions centered at two nuclei drop exponentially, and the dot product:

 $$ <\phi_{1}\mid\phi_{2}>=\int\phi_{100}(r_{1})\phi_{100}(r_{2})d r^{3}\qquad(14-14) $$ 

It is the overlap of the two 1s orbitals centered at  $ N_{1} $,  $ N_{2} $ with R

distance between them. Only when the R is large, the overlap is close

to zero. This integral is thus called overlap integral; it can be

computed by using elliptical coordinate, and only the results given

here: $ ^{96} $

 $$ S\equiv<\phi_{1}\mid\phi_{2}>=e^{-\rho}[1+\rho+\frac{1}{3}\rho^{2}] $$ 

Here all the lengths are rescaled using Bohr radius (i.e. in atomic units)

 $$ \rho\equiv\frac{R}{a_{0}},\rho_{1}\equiv\frac{r_{1}}{a_{0}},\rho_{2}\equiv\frac{r_{2}}{a_{0}}\qquad(14-16) $$ 

Because the non-zero overlap integral, the secular equation for energy eigenvalue will be different from (14-8) above, here is how we derive it:

 $$ H\mid\psi>=E\mid\psi> $$ 

 $$ H(c_{1}\mid\phi_{1}>+c_{2}\mid\phi_{2}>)=E(c_{1}\mid\phi_{1}>+c_{2}\mid\phi_{2}>) $$ 

Dot product above with bra  $ <\phi_{1}|,\langle\phi_{2}| $ respectively:

 $$ \begin{aligned}&H_{11}c_{1}+H_{12}c_{2}=Ec_{1}+ESc_{2}\quad&(14-17)\\&H_{21}c_{1}+H_{22}c_{2}=ESc_{1}+Ec_{2}\end{aligned} $$ 

In matrix form, it is:

 $$ \begin{bmatrix}H_{11}-E&H_{12}-ES\\ H_{21}-ES&H_{22}-E\end{bmatrix}\begin{bmatrix}c_{1}\\ c_{2}\end{bmatrix}=0\qquad(14-18) $$ 

Of course when $S=0$ (orthogonal), the (14-18) is reduced to (14-8).

Now we can solve it, express $E$ in terms of $H$ elements and overlap

integral $S$. The solution is actually quite simple, if we take the fact

that $H_{11}=H_{22}$ (for our symmetric diatomic molecule), $H_{12}=H_{21}$ (the

$\phi_{100}$ is a real function, and so will be the integral will $H$, that means

the H12 should be real, from Hermitian property, we have H12=H21),

this means from secular equation, we have:

 $$ \left(H_{11}-E\right)^{2}=\left(H_{12}-E S\right)^{2}\rightarrow H_{11}-E=\pm(H_{12}-E S) $$ 

So, the two energies are:

 $$ E_{1}=\frac{H_{11}+H_{12}}{1+S};\quad E_{2}=\frac{H_{11}-H_{12}}{1-S}\qquad(14-19) $$ 

Here we do not know which energy is higher (in last section, I assume  $ H_{12} $ is negative, and thus  $ E_{1} $ is the  $ E_{-} $, I shall prove this later). First we can calculate the eigenstates for these two energies, I only do it for  $ E_{1} $, the other is similar. Put the  $ E_{1} $ back to (14-18), easy to find:

 $$ c_{1}=c_{2} $$ 

So the state will be in form of:

 $$ |\psi_{1}>=c_{1}(|\phi_{1}>+|\phi_{2}>) $$ 

The normalization can fix the c:

 $$ 1=<{\psi_{1}}\mid{\psi_{1}}>=c_{1}^{2}(2+2S)\rightarrow c_{1}=\frac{1}{\sqrt{2(1+S)}} $$ 

 $$ |\psi_{1}>=\frac{1}{\sqrt{2(1+S)}}(|\phi_{1}>+|\phi_{2}>)\qquad(14-20) $$ 

Similarly:

 $$ |\psi_{_{2}}>=\frac{1}{\sqrt{2(1-S)}}(|\phi_{_{1}}>-|\phi_{_{2}}>) $$ 

Now what I need to do is to investigate the H element form to see which energy is higher:

I shall do this in atomic unit: (a reminder:  $ m_e = 1, a_0 = 1 $,  $ \frac{e}{\sqrt{4\pi \varepsilon_0}} = 1 $,  $ \hbar = 1 $,  $ E_{1s(\text{hydrogen})} = \frac{1}{2} $)

Hamiltonian (14-1) in atomic units will be:

 $$ H(in\ a u)=-\frac{1}{2}\Delta-\frac{1}{\rho_{1}}-\frac{1}{\rho_{2}}+\frac{1}{\rho}\qquad(14-22) $$ 

Note:  $ H_1 \equiv -\frac{1}{2} \Delta - \frac{1}{\rho_1}, H_2 \equiv -\frac{1}{2} \Delta - \frac{1}{\rho_2} $ are just  $ H $ for hydrogen atoms with  $ |\phi_1>, |\phi_2> $ are eigenstates respectively.

The Matrix element for H in (14-22) in basis of  $ \left|\phi_{1}>, \left|\phi_{2}\right>\right. $ are:

 $$ \begin{aligned}&H_{11}=<\phi_{1}\mid H\mid\phi_{1}>=<\phi_{1}\mid H_{1}\mid\phi_{1}>-<\phi_{1}\mid\frac{1}{\rho_{2}}\mid\phi_{1}>+<\phi_{1}\mid\frac{1}{\rho}\mid\phi_{1}>\\ &<\phi_{1}\mid H_{1}\mid\phi_{1}>=-\frac{1}{2}\quad(forls energy in hydrogen)\\ &C\equiv<\phi_{1}\mid\frac{1}{\rho_{2}}\mid\phi_{1}>={\int\frac{\mid\phi_{100}(\rho_{1})\mid^{2}}{\rho_{2}}dr^{3}}\quad(14-23)\\ \end{aligned} $$ 

This is the Coulomb attraction between the nucleus at N₂ to the electron at r₁. (You will have similar term in H₂₂, but r₁, r₂ are switched) This is why this integral is called Coulomb integral.

 $$ <\phi_{1}\mid\frac{1}{\rho}\mid\phi_{1}>=\frac{1}{\rho}<\phi_{1}\mid\phi_{1}>=\frac{1}{\rho} $$ 

This is the result of Born-Oppenheimer approximation, the R (and ρ)

here is some fixed parameter. The the H is:

 $$ H_{11}=-\frac{1}{2}-C+\frac{1}{\rho}\qquad(14-24) $$ 

For the H12:

 $$ \begin{aligned}&H_{12}=<\phi_{1}\mid H_{2}\mid\phi_{2}>-<\phi_{1}\mid\frac{1}{\rho_{1}}\mid\phi_{2}>+<\phi_{1}\mid\frac{1}{\rho}\mid\phi_{2}>\\ &<\phi_{1}\mid H_{2}\mid\phi_{2}>=-\frac{1}{2}<\phi_{1}\mid\phi_{2}>=-\frac{1}{2}S\\ &A\equiv<\phi_{1}\mid\frac{1}{\rho_{1}}\mid\phi_{2}>={\int}\phi_{1}^{*}(\rho_{1})\frac{1}{\rho_{1}}\phi_{2}(\rho_{2})d r^{3}\quad(14-25)\\ \end{aligned} $$ 

This term has no classical interpretation as the Coulomb integral. In the atomic basis used here, this tells you that the electron can “exchange” from one orbital close to  $ N_{1} $ to orbital close to  $ N_{2} $. This is the effect of “resonance” in two-level system. The two zero order states are not stationary any more (otherwise the H will be diagonal). That is why this term is called resonance integral (or exchange integral, though the name is also used for a similar integral form in multi-electron atoms). Please also note both the C and A terms are some positive numbers since all the integrands are positive.

 $$ <\phi_{1}|\frac{1}{\rho}|\phi_{2}>=\frac{1}{\rho}S $$ 

Thus:

 $$ H_{12}=-\frac{S}{2}-A+\frac{S}{\rho}\qquad(14-26) $$ 

You see from above, in the last section, I neglect S (treat atomic orbitals orthogonal, S=0), the  $ H_{12}=-A $ a negative number.

Now put (14-24) and (14-26) into energy (14-19):

 $$ E_{1}=\frac{H_{11}+H_{12}}{1+S}=-\frac{1}{2}+\frac{1}{\rho}-\frac{C+A}{1+S} $$ 

 $$ E_{2}=\frac{H_{11}-H_{12}}{1-S}=-\frac{1}{2}+\frac{1}{\rho}+\frac{A-C}{1-S} $$ 

The first term is just the energy of electron in single hydrogen 1s

orbital; the second is repulsion of nuclei. The  $ E_{1} $ has bigger negative

term and thus be the lower energy state (also refer to figure below),

and the orbital in (14-20) is the bonding molecular orbital. This

agrees to our initial more crude treatment in section (2). The integrals

for  $ H_{2}^{+} $actually can be computed rigorously, the result is a function of

R (or  $ \rho $), the result is shown graphically below (there

 $$ \Delta E\equiv E-E(R=\infty)=E+\frac{1}{2}); $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_245_791_652_1051.jpg" alt="Image" width="34%" /></div>


The graph is only qualitative correct, It drops too fast and the anti-bonding energy curve actually does not have a shallow well. This is because we only include two atomic orbitals in basis. More elaborate LCAO-MO method will include more hydrogen-like orbitals (such s and p to make hybrid orbitals which is better because it includes the polarity of electron due to the appearance of the proton in H₂⁺); modification by introducing the adjustable parameters to

atomic orbitals (this is better because it takes the “shielding” effect of electrons into consideration), etc. To accurately calculate the energy states of more and more complex molecules is still a challenge to theoretical chemists and computational physicists.

### 14.2 Free Electron Gas and Kronig-Penney Model for Solids

The Griffiths book contains a nice discussion on these simplified but quite basic models. Since I have no add-on, please refer to the section 5.3 in his book. They are good examples showing how to apply the simple quantum models we had learned to a more complex system.

Just note that in the free-electron gas model, it is just a 3-D infinite potential well, and the method of counting the number of “modes” (possible LI states) is what we had used in black-body radiation. While in Kronig-Penney model, it may be more realistic to use a periodic finite potential well; the delta potential however is much simpler in computation and also reveals to band structure.

## References for Quantum Part:

(the order reflects how close related to our course)

1. D. Griffiths. Introduction to Quantum Mechanics Chap.1-5

2. Feynman et al. Feynman lectures on Physics Vol. III, Chap. 1-8

3. R. Shankar. Principles of Quantum Mechanics. Chap 1-7

4. C. Cohen-Tannoudji et al. Quantum Mechanics. Vol. one, Chap 1-7; Vol. two, Chap. 10, 14

5. JJ. Sakura. Modern Quantum Mechanics. Chap1,2

6. D.F. Lawden. The Mathematical Principles of Quantum Mechanics.

Chap. 1-4

7. S. Thornton and A. Rex. Modern physics—for Scientists and Engineers. (3 $ ^{rd} $ edition, international student edition) Chap 1-6.

8. 杨福家 原子物理学（第四版）高教出版社

9. P.A. Dirac. Principles of Quantum Mechanics

10. D. Bohm. Quantum Theory. (1951) Chap1-10

11. L. Pauling and E.B. Wilson Introduction to Quantum Mechanics

12. L.I. Schiff. Quantum Mechanics

13. N. Zettili. Quantum Mechanics Concepts and Applications

14. I.N. Levine. Quantum Chemistry (6th edition)

## Math Supplement on Matrix Representation of Vector

In the class, I introduce the matrix representation for ‘vectors’ $ ^{97} $ and Dirac notation. Since this method is very important in modern physics (you would not understand the talking of modern physics if unfamiliar with this language), here I give a little more detailed discussion on this subject. (though still very simplified in a sense that I neglect many strict math proof and do not have too many examples to illustrate)You are encouraged to read more on this in other quantum textbooks. (Such as Shankar’s ‘principle of quantum mechanics’ chap.1, or Cohen-Tannoudji’s ‘quantum mechanics’ chap.2; If you are really needing math background in linear algebra oriented to physicists or engineers, I recommend Gilbert Strang’s ‘Introduction to Linear Algebra’, or watch him teaching the Linear Algebra from I-tunes-U on internet, MIT course 18.06)

I only assume you are still fresh with linear algebra (at least much more fresh than mine). For those of you that are familiar with linear algebra (LA), you can treat the below as a summary of the useful LA that is

applied everywhere in QM.

For a vector in physics, though it usually visualized as an ‘arrow’ pointing in space, it is essentially the superposition principle, i.e. the physical entity can be decomposed into components (usually we decompose it into orthogonal components), knowing how big each component are (that is knowing the expansion coefficient along each component) and knowing the basis that it is expanded onto is equivalent of knowing the vector itself. (The two knowledge: basis set and corresponding coefficients are complete knowledge for a vector $ ^{98} $) Such expansion coefficients of course can be arranged into numerical arrays (an ordered list of the coefficients and the basis units) so that matrix naturally comes into play to represent them. In the following discussion I still use polarization of light as example so limits it to 2-D, but as usual the discussion is general and can be extended to higher dimensions easily.

## (1) Orthogonal basis:

The Jones representation of polarization of the electrical field depends on the basis chosen (the vector itself is basis independent, but the detailed

representation does require basis and thus would be different in different basis). For a 2-D space (the field is transverse and in a 2-D plane perpendicular to the wave vector), the basis clearly has dimension of 2, i.e. you will need two independent vectors to form a basis to span the whole space (any vector in the space can be expressed as linear combination of the basis vectors, this is the completeness of the basis set).

There will be infinite ways to choose the basis even for a 2-D space, you just need two independent vectors (the two vectors would not even be orthogonal, but orthogonal vectors do satisfy independence requirement and offer many convenient features, so we shall study orthogonal basis most of the time). The  $ |H\rangle $,  $ |V\rangle $ basis (the Cartesian basis) is clearly a choice; the  $ |+45\rangle $ and  $ |-45\rangle $ linear polarization (a rotated Cartesian) is another, as well as  $ |R\rangle $,  $ |L\rangle $ for circular basis....., you can construct other basis by two independent vectors. (To test independence, we shall refer to the linear algebra, construct a matrix A formed by these vectors, i.e. each base vector is one column in the matrix A; the nxn A in space  $ R^n $ (real number space) or  $ C^n $ (complex number) has to be invertible for independent column vectors. You can test these by determinant or elimination of A). You may try this on the circular and elliptical basis in the note. (They are obviously independent due to orthogonality, but what the heck, test them yourself)

P.S. The above question may seem trivial but quite fundamental, it is the

heart in linear algebra. You may want to review linear algebra for details.

The best linear algebra textbook (for physicist and engineer) in my personal opinion is the book by Prof. Gilbert Strang at MIT. (He has two similar books on introductory linear algebra, one is: 'Introduction to linear algebra' which I have a pdf file; the other is 'Linear algebra and its applications' which I have a hard copy and you could also buy from Amazon with RMB200+. If you cannot find sources and indeed in need, I would be happy to help)

In 2-D, two orthogonal vectors form a complete basis, i.e. any other vector can be written as a superposition of them. Let  $ |1> $ and  $ |2> $ to represent the unit vector of this base (I will give you a detailed discussion of this in section 3), the orthonormal condition between them is defined by direct product between these two:

 $$ \begin{aligned}\left\langle i\right|j\rangle=\delta_{ij}=&1(if i=j)\\=&0(if i\neq j),\quad i,j=1or2\end{aligned} $$ 

And  $ \sum_{i=1,2}|i\rangle\langle i|=1 $ (1 here is identity matrix) is meaning the completeness of the basis.  $ |i> $ is the Dirac’s notation (bookkeeping) for a vector,  $ <i| $ is the notation for the vector’s conjugate (complex conjugate if in complex space), the  $ <i|j> $ is notation for the scalar (dot) product, i.e.  $ \vec{i}\cdot\vec{j} $ in conventional vector case, and  $ i^T j $ (real space),  $ i^\dagger j $ in linear algebra. More details on this notation are below.

(2)Dirac’s notation and its matrix form

Any vectors expanded on this basis will have component along  $ |1> $ or  $ |2> $,

let's say a and b are the coefficients:

Then  $ |E\rangle = a|1\rangle + b|2\rangle $ (the usual way represent a vector in 2-D Cartesian coordinate is an example:  $ \vec{E} = a\vec{i} + b\vec{j} $).

We could use a ordered array of a,b to represent the vector too (ordered means we already arrange the basis, such as 1st entry of the column matrix is the coefficient of expansion along |1>, 2nd is along |2>, etc)

Then: in matrix form

 $$ \left|\boldsymbol{E}\right\rangle=\begin{bmatrix}a\\ b\end{bmatrix}=a\begin{bmatrix}1\\ 0\end{bmatrix}+b\begin{bmatrix}0\\ 1\end{bmatrix} $$ 

where  $ \begin{bmatrix} 1 \\ 0 \end{bmatrix} $ and  $ \begin{bmatrix} 0 \\ 1 \end{bmatrix} $ are the matrix representation of base vector  $ |1> $ and  $ |2> $, and the complex-conjugate of the vector  $ |1> $,  $ |2> $, the  $ <1| $,  $ <2| $ are represented by  $ [1\ 0] $ and  $ [0\ 1] $, the row matrix form (Here, 0,1 are real so complex conjugates are same)

Here using a column matrix  $ (n \times 1 \text{ matrix}) $ to represent vector is a traditional but an artificial choice, and the following calculation are according to this choice. (if you choose a row matrix to represent the vector, then the physics is still same, but the calculation will be different) Using the orthonormal property of the base vectors, the expansion coefficient a, b can be calculated or just written as:

 $ a=\langle1|E\rangle,b=\langle2|E\rangle $, the dot product between the base vectors and the vector

itself (we will define dot product in the following session)

(3)Matrix representation of complex conjugate of the vector and dot product in Dirac notation

For a  $ \vec{E} = a\vec{i} + b\vec{j} $ in its usual representation, the conjugate in complex space is:  $ \vec{E}^* = a^* \vec{i} + b^* \vec{j}' $, and dot product between them is  $ \vec{E}^* \cdot \vec{E} = a^* a + b^* b $. Then in matrix form, how we represent the complex conjugate of  $ |E\rangle $? is  $ (\left|E\right\rangle)^* = \begin{bmatrix} a^* \\ b^* \end{bmatrix} $? Well if we represent its conjugate in this form, we would have trouble to conduct the dot product (try it in the current form and you will find trouble using matrix product rules to evaluate the dot product), you may argue we can construct rules of calculation to proceed, but why not using the powerful arsenal already existing in linear algebra?

To use the existing rules of linear algebra, the calculation of dot product is extremely straightforward IF we represent the complex conjugate by a row vector (1 x n matrix), which turns out to be the transposed and complex conjugate matrix of original vector’s matrix representation. (In language of linear algebra, the physical vectors live in Column space and its complex conjugate in Row space) So  $ (\left|E\right\rangle)^{*}=\left[a^{*}b^{*}\right] $, and Paul Dirac invented using  $ \langle E\rangle $ (He called the  $ \left|E\right\rangle $ ‘ket’ vector and  $ \langle E\rangle $, the conjugate of the ‘ket’, is called ‘bra’ vector, then the dot product will be in forms of a  $ \mathbf{Bracket} $ to represent this complex conjugate of the original  $ \left|E\right\rangle $. Then the dot product between the two vectors is :

 $$ \left\langle E\Big|E\right\rangle=\left[a^{*}b^{*}\right]\begin{bmatrix}a\\ b\end{bmatrix}=a^{*}a+b^{*}b $$ 

(the last directly follows from matrix product rules of linear algebra), the dot product results in a scalar value which is exactly same as dot product of the ‘old’ representation which you may be more familiar or comfortable with.

A note here, because matrix product are sensitive to the order of matrix, so direct product can only be represented by the “Braket”  $ \langle E|E\rangle $ (the order is important, where  $ |E\rangle\langle E| $ represents a total different physical meaning, it is a ‘projector’ I shall show you right away that it is an operator in 2 x 2 matrix form (in 2-D), not a scalar number as dot product); where in old representation,  $ \vec{E} \cdot \vec{E} = \vec{E} \cdot \vec{E}^* $, the order does not matter.

Recall that in linear algebra, the inner product (another name for scalar or dot product) is represented as  $ E^{T}E $, and the projector as  $ EE^{T} $, for vectors in real space; for the vectors in complex space, the transposed matrix would be replaced by the adjoint matrix  $ E^{+} $, which is the transposed and complex conjugated matrix of the original one. Dirac notation just uses another bookkeeping to express these linear algebra relations: ‘Ket’ vector in matrix representation would be column vector, ‘Bra’ would be transposed and complex conjugated.

(4)The matrix representation of an Operator (physical operation that

## alters the vector)

In physics and engineering, we encounter many problems involving linear transformation. i.e. the output state would be a linear combination of the input states. Examples you have in this course are: Ray tracing method in geometric optics (the output light ray and input light ray are linearly related); the Fresnel equation upon reflection or transmission through an interface; and the polarization state change by optical elements(polarizer, waveplates etc) You will encounter more examples in quantum mechanics.

In this kind of problem, the input and output states are represented as ordered column ‘vectors’, and the linear operation (the operator) would be represented by a Matrix. The form of the matrix would depend on the details of physical interaction, as well as the basis we choose to represent it. However there are general methods to find the matrix representation of the operation.

The basis would determine the representation of the given vectors, i.e. knowing the basis set and vector, you can determine the expansion coefficients onto the basis, so you know the expression of the vector on this basis. Example: in 2-D Cartesian basis,  $ |H \rangle = \begin{bmatrix} 1 \\ 0 \end{bmatrix} $,  $ |V \rangle = \begin{bmatrix} 0 \\ 1 \end{bmatrix} $, any vectors would be in forms of  $ \begin{bmatrix} x \\ y \end{bmatrix} = x |H \rangle + y |V \rangle $, a linear combination of the basis vectors.

The question is to find the matrix representation for a certain operation in this basis. We use T to represent the operation, how can you find the matrix form of T given a basis? The idea is simple. Since any vectors in such space would be a linear combination of the basis vectors, so if we know the result of an operation on the basis vectors, we would know its effect on any input vectors! (because the operation is also linear) This is expressed in math as:

 $$ T\begin{bmatrix}x\\ y\end{bmatrix}=xT\mid H>+yT\mid V> $$ 

If we know the operation of  $ |H> $ and  $ |V> $, we know the operation for any input vector. The determination of  $ T|H> $ and  $ T|V> $ would require detailed knowledge of the physical interaction involved, this is where physics kicked in.

As an example of this method (I shall call this method 1 to get the expression of T), let’s assume an operation changes a 2-D vector into another vector also in 2-D, (the T in this case is a 2X2 matrix) and through physical analysis, we also know the T|H> and T|V>, then T is determined:  $ T = \begin{bmatrix} a_{11} & a_{12} \\ a_{21} & a_{22} \end{bmatrix} $, the four elements need to be determined.

But we know the T|H> and T|V>, which is:

 $$ \begin{aligned}&T\mid H>=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}1\\ 0\end{bmatrix}=\begin{bmatrix}a_{11}\\ a_{21}\end{bmatrix}\\ &T\mid V>=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}0\\ 1\end{bmatrix}=\begin{bmatrix}a_{12}\\ a_{22}\end{bmatrix}\\ \end{aligned} $$ 

So if you know the T|H>, you know the first column of matrix T; and T|V>

gives you the second column. The determination of matrix T is completed if you know the T's action on each basis vector. This also make the choice of basis becomes crucial to determine the T. A nice choice of basis would make T's representation simple (the simplest is diagonal), and that's where eigenstates of the operation becomes important.

The above is a general discussion, even though I chose a 2-D to 2-D transform as example for simplicity (and we only use this type for this course), but it can be extended to n-D to m-D transformation (T in this case would be in what form? And how you find its form? Please think this yourself, though I will not put it in test)

Another example: (I shall call this method 2 to find out T)

If the input vector has a,b components along |1>, |2>, let's imagine a physical operation alters it linearly so that the output would have different components a' and b'. (we see many examples of this type already in analytical ray tracing, light reflection and transmission and change of polarization state of light)

 $$ a^{\prime}=o_{11}a+o_{12}b $$ 

 $$ b^{\prime}=o_{21}a+o_{22}b $$ 

Then in matrix form the above process is summarized as:  $ |E'\rangle = \hat{O}|E\rangle $,  $ \hat{O} $ is called the operator which is the physical operation or measurement,  $ |E\rangle $ and  $ |E'\rangle $ are the input and the output state of the system (such as a polarization state passing through a polarizer or waveplate), in the basis of  $ |1\rangle $ and  $ |2\rangle $, the above is:

 $$ \begin{bmatrix}a^{\prime}\\ b^{\prime}\end{bmatrix}=\begin{pmatrix}o_{11}&o_{12}\\ o_{21}&o_{22}\end{pmatrix}\begin{bmatrix}a\\ b\end{bmatrix} $$ 

The matrix elements of ☑ can be found out by:

 $$ o_{ij}=\left\langle i\left|\hat{O}\right|j\right\rangle $$ 

i,j are the base vectors. This can be easily seen as following:

 $$ \begin{aligned}&a^{\prime}=\left\langle1\right|E^{\prime}\rangle=\left\langle1\right|\hat{O}\left|E\right\rangle=\left\langle1\right|\hat{O}\left\{1\right\}\left\langle1\right|+\left|2\right\rangle\left\langle2\right|\}\left|E\right\rangle\\ &=\left\langle1\right|\hat{O}\left|1\right\rangle a+\left\langle1\right|\hat{O}\left|2\right\rangle b\\ \end{aligned} $$ 

(here I used completeness of base 1,2, i.e. inserting  $ \sum_{i=1,2}|i\rangle\langle i|=1 $ into the equation, this is of course just express the  $ |E> $ in terms of its components along  $ |1> $ and  $ |2> $ )

Compare with the beginning relation of this section, clearly  $ o_{ij} = \langle i | \hat{O} | j \rangle $.

(I only prove half but the rest is same).

The physical meaning of this  $ o_{ij}=\langle i|\hat{O}|j\rangle $, is of course direct from definition, that an operation acts on the base vector, this may change the base vector into some other vectors, the resulting vectors components along basis gives the corresponding matrix elements of the operation, so that in short, the matrix form of a operator in some basis is determined by its action on the basis vectors. (This is not a surprising but an expected behavior, since every vector can be expanded into a complete basis, then if the operators action on the basis vector is known, its action on any vectors in the space can be analyzed, I repeated here of what I discussed earlier as in method 1. Indeed this method2 are essentially same as method 1). For example the quarter wave plate with fast axis horizontal,

the Q_H (Q for quarter-wave, H for fast axis along H direction), in the |H>, |V> basis:

 $ \hat{Q}_H \left| H \right\rangle = e^{i\varphi_H} \left| H \right\rangle; \hat{Q}_H \left| V \right\rangle = e^{i\varphi_V} \left| V \right\rangle, \varphi_H - \varphi_V = -\frac{\pi}{2}, \text{then the matrix form of } Q_H \text{ is then:} $

 $$ \left(Q_{11}=\left\langle H\left|\hat{Q}_{H}\right|H\right\rangle,\mathbf{e t c}\right) $$ 

 $$ \hat{Q}_{H}=\begin{pmatrix}{{{e^{i\varphi_{H}}}}}&{{{0}}} \\{{{0}}}&{{{e^{i\varphi_{V}}}}}\end{pmatrix}=e^{i\varphi_{H}}\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{i}}}\end{pmatrix} $$ 

There are still other methods to get the expression of operator in certain basis, but I have to introduce an important operation first:

## Projector

Though here I used the polarization of light as example, but the discussion is general and can be extended to the vector state in Q.M and higher dimensional space (polarization is 2-D)

For a Jones vector representation of polarization, let's say |E> to represent this vector, to write out the vector explicitly, in the Jones vector form, of course we need basis (orthonormal vectors form basis, in 2-D, a basis consist 2 vectors, orthogonal and normalized to 1, so called orthonormal), the one easy to imagine is the H-V basis consists of horizontally and vertically polarized light as basis vector, in such basis:

 $$ \left|\boldsymbol{E}\right\rangle=\begin{bmatrix}h\\ v\end{bmatrix}=h\begin{bmatrix}1\\ 0\end{bmatrix}+v\begin{bmatrix}0\\ 1\end{bmatrix}=h\left|\boldsymbol{H}\right\rangle+v\left|\boldsymbol{V}\right\rangle $$ 

 $ \begin{bmatrix} h \\ v \end{bmatrix} $ then is the Jones vector of the polarization  $ |E> $ in H-V basis

Of course in other basis (such as that formed by other othonormal base vectors like Right and Left circular polarization), the Jones vector would take different value than h, v.

More general, let  $ \left|Ea\right\rangle $,  $ \left|Eb\right\rangle $ be a pair othonormal base vectors, then

 $$ \left|E\right\rangle=a\left|E_{a}\right\rangle+b\left|E_{b}\right\rangle $$ 

Using orthonormal relation between  $ \left|Ea\right\rangle,\left|Eb\right\rangle $

 $$ a=\left\langle E_{a}\left|E\right.\right\rangle,\quad b=\left\langle E_{b}\left|E\right.\right\rangle $$ 

(<Ea| is the conjugate vector of |Ea> in a complex space, in matrix form it

is the transposed and conjugate of the original |Ea>)

Then we rewrite above equation of expansion of  $ |E> $:

 $$ \left|E\right\rangle=\left\langle E_{a}\left|E\right\rangle\right|E_{a}\rangle+\left\langle E_{b}\left|E\right\rangle\right|E_{b}\rangle $$ 

This is nothing new of course, just restated that the  $ \left|E\right> $ has two components whose amplitude is given by a and b or rewrite a, b in direct product form, the physical meaning of the coefficient a,b is that they tell you how big each components are, or how often (the probability amplitude)you may find  $ \left|E\right> $ in  $ \left|Ea\right> $ or  $ \left|Eb\right> $.

Now let's rearrange the above relation:

 $$ \begin{aligned}\left|E\right>=&\left\langle E_{a}\left|E\right\rangle\right|E_{a}\rangle+\left\langle E_{b}\left|E\right\rangle\right|E_{b}\rangle\\ =&\left|E_{a}\right\rangle\left\langle E_{a}\left|E\right\rangle+\left|E_{b}\right\rangle\left\langle E_{b}\left|E\right\rangle\right.\\=&\left(\sum_{i=a,b}\left|E_{i}\right\rangle\left\langle E_{i}\right|\right)\left|E\right\rangle\end{aligned} $$ 

(nothing new in second step, just rearrange terms,  $ \langle E_a | E \rangle $ is just a number; the third step is because all these product are matrix operations, and in matrix operation though the order is important, it also obeys

association rules)

Clearly  $ \sum_{i=a,b}|E_i\rangle\langle E_i| $ should be 1 (the identity matrix)  $ \begin{bmatrix}1&0\\ 0&1\end{bmatrix} $.

 $ |E_i\rangle\langle E_i| $ is an operator, it is called projector, what it does is to ‘project’ any vector to show its component of  $ |E_i\rangle $, like  $ |E_a\rangle\langle E_a| $ acts on  $ |E> $. it produce  $ a|E_a\rangle $. In matrix form (in 2-D), this projector is 2X2 matrix. For example, in the H-V basis,  $ |H\rangle\langle H| $ is the projector gives the H components of any vector

 $$ \left|\boldsymbol{H}\right\rangle=\begin{bmatrix}{{{1}}} \\{{{0}}}\end{bmatrix},\quad\left\langle\boldsymbol{H}\right|=\left[\begin{matrix}{{{1}}}&{{{0}}}\end{matrix}\right],\quad\left|\boldsymbol{H}\right\rangle\left\langle\boldsymbol{H}\right|=\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{pmatrix} $$ 

If you act this  $ |H\rangle\langle H| $ on any vector state  $ |E\rangle=\begin{bmatrix}h\\ v\end{bmatrix} $, then it will project the H component (horizontal linear polarized)out:

 $$ \left|H\right\rangle\left\langle H\right|\left|E\right\rangle=\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{pmatrix}\begin{bmatrix}{{{h}}} \\{{{v}}}\end{bmatrix}=\begin{bmatrix}{{{h}}} \\{{{0}}}\end{bmatrix}=h\left|H\right\rangle $$ 

This is what a projector does. (Please also refer to linear algebra to see how projector there is represented, you should be able to see that it is the same as discussed here)

 $$ \sum_{i=a,b}\left|E_{i}\right\rangle\left\langle E_{i}\right|={\bf1} $$ 

this means if the basis is complete, then knowing all of each component (also called “projection”) is equivalent of knowing the complete vector, this is the condition to test whether a basis is complete, but in 2-D space, it is obvious 2 orthogonal vectors would satisfy it. The 1 identity matrix can be inserted into the equation and will not affect the relation (similar to

multiply 1 to a number) and is a very useful ‘trick’ to apply, as the below shows.

Now we can have a  $ 3^{rd} $ method to find out the matrix representation of an operator:

For an operator O, in a basis spanned by unit vectors  $ |i> $ (inserting identity matrix before and after O):

 $$ \hat{O}=\sum_{i}\left|i><i\right|\hat{O}\sum_{j}\left|j><j\right|=\sum_{i,j}<i\left|\hat{O}\right|j>\left|i><j\right|=\sum_{i j}o_{i j}\left|i><j\right| $$ 

|i><j|is not exactly an projector, it is called dyad and what it does is shown below explicitly for |2><1| (this part is also in the quantum note ):

 $$ \begin{aligned}|2>=&\begin{bmatrix}{{{0}}} \\{{{1}}} \\{{{0}}} \\{{{0}}} \\{{{\cdot}}} \\{{{\cdot}}}\end{bmatrix},\quad<1|=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{\cdot}}} \\\end{bmatrix}\qquad|2><1|=\begin{pmatrix}{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{\ddots}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\\end{pmatrix}\end{aligned} $$ 

It is just a rank one matrix with 1 at position 21, and the rest are zeroes.

So the  $ o_{ij} \mid i < j $ is just another way to say the matrix element at ith

row, jth column is  $ o_{ij} $ and the whole matrix is a summation of these

kinds of terms. Relation (9) is just same as method 2 to get matrix

elements. But now consider we use the eigenvectors of the  $ \hat{O} $ as basis,

the eigenvalues are  $ \lambda_{i} $ and associated eigenvector is  $ |\phi_{i}\rangle $:

 $$ \hat{O}\mid\phi_{i}>=\lambda_{i}\mid\phi_{i}> $$ 

With the eigenvector as basis, the O will be diagonal, with eigenvalues

along the diagonal, i.e.:

 $$ <\phi_{i}\mid\hat{O}\mid\phi_{j}>=\lambda_{i}\delta_{ij} $$ 

Under this eigenvector basis, the O can be expressed as:

 $$ \hat{O}=\sum_{i}\lambda_{i}\mid\phi_{i}><\phi_{i}\mid $$ 

It is a summation of projectors with eigenvalues in front of it. Though (12) is proved using eigenvector as basis, it can be used to find the expression of O in other basis, just throw in the expression of eigenvectors in that particular basis. This is true because relation like (12) is a tensor relation which should hold independent of choice of basis.

All these methods are best illustrated by examples. In the polarization part, I derived the matrix form for a +45 linear polarizer. Here I shall show the details using various methods:

In the optics notes I used transform between basis to find out the +45 linear polarizer in |H>,|V> basis, that is basically similarity transform in linear algebra, and I shall call it method 0.

## a) Method 0: Similarity Transform

The  $ |H\rangle $,  $ |V\rangle $ linear polarized light will be termed as  $ |1\rangle $,  $ |2\rangle $; The  $ |+45\rangle $,  $ |-45\rangle $ linear polarized light will be termed as basis  $ |1\rangle $,  $ |2\rangle $.

The +45 polarizer’s matrix form in the 1’, 2’ basis is clear, it allows a complete pass of |1’>, and completely block |2’> (that is the property of the +45 linear polarizer), so the matrix form of +45 polarizer in basis|1’>,|2’> is:

 $$ \hat{L}_{+45(|1^{\prime}>,|2^{\prime}>)}=\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{pmatrix} $$ 

The question is to find its expression under  $ |1\rangle, |2\rangle $ basis. That is similarity transform in LA.

 $$ \begin{array}{l}\left|1^{\prime}>=<1\left|1^{\prime}>\right|1>+<2\left|1^{\prime}>\right|2>\right.\\\left|2^{\prime}>=<1\left|2^{\prime}>\right|1>+<2\left|2^{\prime}>\right|2>\right.\left.\left|2>=<1^{\prime}\right|2>|1^{\prime}>+<2^{\prime}|2>|2^{\prime}>\right.\end{array} $$ 

Above are the transformation between basis (i.e. express the  $ |1'\rangle $ as combination of  $ |1\rangle $,  $ |2\rangle $ etc.)

For a vector being expressed in either basis:

 $$ \left|r>=x\right|1>+y\left|2>=x^{\prime}\right|1^{\prime}>+y^{\prime}\left|2^{\prime}>\right. $$ 

The relation between x,y (the coordinate of vector in basis 1-2) and x',y' (the coordinate of vector in basis 1'-2') can be found out through basis transform relations:

 $$ \begin{aligned}x\mid1>+y\mid2>=x(<1^{\prime}\mid1>|1^{\prime}>+<2^{\prime}|\mid1>|2^{\prime}>)+y(<1^{\prime}\mid2>|1^{\prime}>+<2^{\prime}|\mid2>|2^{\prime}>)\\=&(x<1^{\prime}|\mid1>+y<1^{\prime}|\mid2>)|\mid1^{\prime}>+(x<2^{\prime}|\mid1>+y<2^{\prime}|\mid2>)|\mid2^{\prime}>\end{aligned} $$ 

the above should be equal to  $ x'|1' > +y'|2'> $, this gives the transform relation between the expression (coordinates) of a vector in different basis:

 $$ \begin{bmatrix}x^{\prime}\\ y^{\prime}\end{bmatrix}=\begin{bmatrix}<1^{\prime}|1>&<1^{\prime}|2>\\ <2^{\prime}|1>&<2^{\prime}|2>\end{bmatrix}\begin{bmatrix}x\\ y\end{bmatrix}=\hat{S}\begin{bmatrix}x\\ y\end{bmatrix}\quad and $$ 

 $$ \begin{bmatrix}x\\ y\end{bmatrix}=\hat{S}^{-1}\begin{bmatrix}x^{\prime}\\ y^{\prime}\end{bmatrix} $$ 

§ is called transform matrix from 1−2→1′−2′basis. (noticed the coordinate x′−y′ transform differently as the basis vector |1′>,|2′>, that is called contra-variance) It is just dot product between basis vectors,

and columns are just base vector  $ |i> $ expressed in the  $ |i’> $ basis. If the  $ |1> $,  $ |2> $ and  $ |1’> $,  $ |2’> $ are orthogonal basis (it is obvious here for linear polarized light), then we have important conclusion from linear algebra: The inverse of matrix of S is extremely easy to get.

 $ \hat{S}^{-1} = \hat{S}^{T} $ (Inverse=Transpose in real number space) (13)

 $ \hat{S}^{-1} = \hat{S}^{+} $ (Inverse=Transposed and complex conjugate in complex space) (14)

(13) and (14) are called Orthogonal transformation and Unitary Transformation respectively. They represent a very important (and probably most used) transformation in physics since we always choose orthogonal basis whenever possible.

Suppose an operator O change  $ (x_1, y_1) $ to  $ (x_2, y_2) $ in  $ |1->|2> $ basis:

 $ \begin{bmatrix} x_2 \\ y_2 \end{bmatrix} = \hat{O}_{1-2} \begin{bmatrix} x_1 \\ y_1 \end{bmatrix} $, then we switch the basis to  $ |1’->|2’> $:

 $$ \hat{S}^{-1}\begin{bmatrix}x_{2}^{^{\prime}}\\ y_{2}^{^{\prime}}\end{bmatrix}=\hat{O}_{1-2}\hat{S}^{-1}\begin{bmatrix}x_{1}^{^{\prime}}\\ y_{1}^{^{\prime}}\end{bmatrix} $$ 

 $$ \begin{bmatrix}x_{2}^{^{\prime}}\\ y_{2}^{^{\prime}}\end{bmatrix}=\hat{S}\hat{O}_{1-2}\hat{S}^{-1}\begin{bmatrix}x_{1}^{^{\prime}}\\ y_{1}^{^{\prime}}\end{bmatrix} $$ 

Thus the matrix represent the operator in the |1’>-|2’> basis should be:

 $$ \hat{O}_{1^{\prime}-2^{\prime}}=\hat{S}\hat{O}_{1-2}\hat{S}^{-1} $$ 

 $$ \hat{O}_{1-2}=\hat{S}^{-1}\hat{O}_{1^{\prime}-2^{\prime}}\hat{S} $$ 

Above I basically give a derivation on similarity transform between matrices. Now back to our particular problem:

 $$ \hat{S}=\begin{bmatrix}{{{<1^{\prime}|1>}}}&{{{<1^{\prime}|2>}}} \\{{{<2^{\prime}|1>}}}&{{{<2^{\prime}|2>}}}\end{bmatrix}=\frac{\sqrt{2}}{2}\begin{pmatrix}{{{1}}}&{{{1}}} \\{{{-1}}}&{{{1}}}\end{pmatrix},\quad\hat{S}^{-1}=\hat{S}^{T}=\frac{\sqrt{2}}{2}\begin{pmatrix}{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}\end{pmatrix} $$ 

 $$ \hat{L}_{+45(|1>,|2>)}=\hat{S}^{-1}\hat{L}_{+45(|1^{\prime}\rangle,|2^{\prime}\rangle)}\hat{S}=\frac{1}{2}\binom{1\quad-1}{1\quad1}\binom{1\quad0}{0\quad0}\binom{1\quad1}{-1\quad1}=\frac{1}{2}\binom{1\quad1}{1\quad1} $$ 

That is quite a long derivation for this simple problem. Of course the point is to show you the similarity transform.

b) Method 1: Apply the +45 linear polarizer on the |1> and |2> base vectors

If the +45 polarizer act on the  $ |1> $ (The H linear polarized light), the output will be a +45 linear polarized light with  $ \frac{\sqrt{2}}{2} $ amplitude:

 $$ \hat{L}_{+45}\mid1>=\frac{\sqrt{2}}{2}\mid+45>=\frac{1}{2}(\mid1>+\mid2>)=\frac{1}{2}\begin{bmatrix}1\\ 1\end{bmatrix} $$ 

As I proved before, this will give us the first column of the matrix  $ L_{+45} $.

Similarly:

 $$ \hat{L}_{+45}\mid2>=\frac{\sqrt{2}}{2}\mid+45>=\frac{1}{2}(\mid1>+\mid2>)=\frac{1}{2}\begin{bmatrix}1\\ 1\end{bmatrix} $$ 

So the matrix form of L in  $ |1>-|2> $ basis is:

 $$ \hat{L}_{+45(|1>,|2>)}=\frac{1}{2}\binom{1\quad1}{1\quad1} $$ 

c) Method 2: direct calculate the matrix element

 $$ l_{11}=<1\mid L_{+45}\mid1>=\frac{\sqrt{2}}{2}<1\mid+45>=\frac{1}{2};l_{12}=<1\mid L_{+45}\mid2>=\frac{\sqrt{2}}{2}<1\mid+45>=\frac{1}{2} $$ 

For other elements, the calculation is similar. It is about same amount work as method 1.

d) Method 3: Projector

The +45 linear polarizer, its eigenvector is  $ |+45> $ linear polarized light with eigenvalue 1; another eigenvector is  $ |-45> $ and the eigenvalue is 0.

 $$ \begin{aligned}&\hat{L}_{+45}=1\mid+45><+45\mid+0\mid-45><-45\mid=\mid+45><+45\mid\\ &\mid+45>=\frac{\sqrt{2}}{2}(|1>+|2>)=\frac{\sqrt{2}}{2}\begin{bmatrix}{{{1}}} \\{{{1}}}\end{bmatrix},<+45\mid=\frac{\sqrt{2}}{2}\begin{bmatrix}{{{1}}}&{{{1}}} \\\end{bmatrix}\\ &\mid+45><+45\mid=\frac{1}{2}\begin{bmatrix}{{{1}}} \\{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\\end{bmatrix}=\frac{1}{2}\begin{pmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{pmatrix}\\ \end{aligned} $$ 

To solve this simple problem with 4 different methods is indeed like shooting a bug with cannon, but this kind of systematic treatment will be important in quantum mechanics.

In the homework, you may be asked to calculate the matrix form of a right circular polarizer under  $ |H\rangle,|V\rangle $ basis. Please try all the methods above as a practice for yourself. I will list the solution below, but you may choose to do that yourself first before reading my answer (or skip completely my answer below, since nothing new there)

Answers to the matrix form of Right-Circular Polarizer in  $ |H\rangle, |V\rangle $ basis:

The notations and base vectors relations:

R is the symbol for operator that acts as right-circular polarizer. What it does is let right-circular light pass completely and block the left-circular polarized light. i.e. the right circular polarized is an eigenvector to R with eigenvalue 1; left circular light is another eigenvector with eigenvalue 0. Let  $ |H> = |I>| $,  $ |V> = |2> $;  $ (\vert H\rangle, \vert V\rangle $ are linear polarized light)

 $ |R>=|1',|L>=|2';(|R>,|L>\text{ are circular polarized light, and they} $

form another orthonormal basis)

 $$ \left|1^{\prime}\right\rangle=\frac{\sqrt{2}}{2}\begin{bmatrix}1\\ -i\end{bmatrix}=\frac{\sqrt{2}}{2}\left(\left|1>-i\right|2\right) $$ 

 $$ \left|2^{\prime}\right\rangle=\frac{\sqrt{2}}{2}\begin{bmatrix}1\\ i\end{bmatrix}=\frac{\sqrt{2}}{2}(\left|1\right\rangle+i\left|2\right\rangle) $$ 

From these coefficients we can get  $ \hat{S}^{-1} = \hat{S}^{+} $ (whose elements are <I | I '>, etc. i.e, the |I '> expression gives the first column in  $ \hat{S}^{-1} = \hat{S}^{+} $)

 $$ \hat{S}^{-1}=\hat{S}^{+}=\frac{\sqrt{2}}{2}\begin{pmatrix}{{{1}}}&{{{1}}} \\{{{-i}}}&{{{i}}}\end{pmatrix},\hat{S}=\frac{\sqrt{2}}{2}\begin{pmatrix}{{{1}}}&{{{i}}} \\{{{1}}}&{{{-i}}}\end{pmatrix} $$ 

Of course, same result can be obtained by expressing  $ |1\rangle $,  $ |2\rangle $ in terms of  $ |1'\rangle $,  $ |2'\rangle $ and find out S first like what I did before.

## a) Method 0:

The matrix form for R under  $ |1\rangle, |2\rangle $ basis is simple:

 $$ \widehat{R}_{|1^{\prime}>,|2^{\prime}>}=\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{pmatrix} $$ 

In the  $ |1\rangle, |2\rangle $ basis, It is:

 $$ \widehat{R}_{|1>,|2>}=\widehat{S}^{-1}\widehat{R}_{|1>,|2>},\widehat{S}=\frac{1}{2}\binom{1\quad1}{-i\quad i}\binom{1\quad0}{0\quad0}\binom{1\quad i}{1\quad-i}=\frac{1}{2}\binom{1\quad i}{-i\quad1} $$ 

b) Method 1:

 $$ |I>=<I^{\prime}|I>|I^{\prime}>+<2^{\prime}|I>|2^{\prime}>=\frac{\sqrt{2}}{2}(|1^{\prime}>+|2^{\prime}>) $$ 

 $$ |2>=<1^{\prime}|2>|1^{\prime}>+<2^{\prime}|2>|2^{\prime}>=\frac{\sqrt{2}}{2}i(|1^{\prime}>-|2^{\prime}>) $$ 

(be careful when take conjugate of  $ |2'\rangle $ to get  $ <2' $|, need to complex

conjugate:  $ <2'| = -\frac{\sqrt{2}}{2}i(<1|-<2|) $. Of course the above can also be directly read from matrix S)

The reason I express  $ |1\rangle $,  $ |2\rangle $ in terms of  $ |1'\rangle $,  $ |2'\rangle $ is because the action of operator  $ R $ on  $ |1'\rangle $,  $ |2'\rangle $ are obvious (they are eigenstates of  $ R $), i.e.  $ \widehat{R} |1'\rangle = |1'\rangle $;  $ \widehat{R} |2'\rangle = 0 |2'\rangle = 0 $. To write the  $ R $ in  $ |1\rangle $,  $ |2\rangle $ basis, we act  $ R $ on  $ |1\rangle $ first to get the first column of the matrix (need to be expressed in  $ |1\rangle $,  $ |2\rangle $ basis):

 $ \hat{R} \mid 1 \geq \frac{\sqrt{2}}{2} \mid 1' \geq \frac{1}{2} \left[1 - i\right] $, this is the first column of  $ R $ in  $ |1>, |2> $ basis.

 $ \hat{R} \mid 2 \geq \frac{\sqrt{2}}{2} i \mid 1' \geq \frac{1}{2} i \begin{bmatrix} 1 \\ -i \end{bmatrix} = \frac{1}{2} \begin{bmatrix} i \\ 1 \end{bmatrix} \quad 2^{nd} \text{ column.} $

c) Method 2:

 $$ R_{11}=<1\mid R\mid1>=\frac{1}{2}(<1^{\prime}|+<2^{\prime}|)R(\mid1^{\prime}>+\mid2^{\prime}>)=\frac{1}{2} $$ 

 $$ R_{12}=<1\mid R\mid2>=\frac{1}{2}(<1^{\prime}|+<2^{\prime}|)R(i\mid1^{\prime}>-i\mid2^{\prime}>)=\frac{1}{2}i $$ 

 $$ R_{_{21}}=<2\mid R\mid1>=\frac{1}{2}(-i)(<1^{\prime}|-<2^{\prime}|)R(\mid1^{\prime}>+\mid2^{\prime}>)=-\frac{1}{2}i $$ 

 $$ R_{22}=<2\mid R\mid2>=\frac{1}{2}(-i)(<1^{\prime}|-<2^{\prime}|)R(i\mid1^{\prime}>-i\mid2^{\prime}>)=\frac{1}{2} $$ 

d) Method 3:

 $$ \hat{R}=1\left|1^{\prime}><1^{\prime}\right|+0\left|2^{\prime}><2^{\prime}\right|=\left|1^{\prime}><1^{\prime}\right|=\frac{1}{2}\begin{bmatrix}{{{1}}} \\{{{-i}}}\end{bmatrix}\left[1\quad i\right]=\frac{1}{2}\begin{pmatrix}{{{1}}}&{{{i}}} \\{{{-i}}}&{{{1}}}\end{pmatrix} $$ 

(5)The matrix form of the operator acts in the complex conjugate (the ‘bra’) space

The above section is about the matrix representation for a physical operation in the ‘ket’ space, , i.e. a representation of the following facts:

 $$ \begin{aligned}&a^{\prime}=o_{11}a+o_{12}b\\&b^{\prime}=o_{21}a+o_{22}b\\ \end{aligned} $$ 

For the complex conjugate of the vector, we would have relation of the following between them (just take complex conjugate on both sides):

 $$ \begin{aligned}&a^{\prime}^{*}=o_{11}^{*}a^{*}+o_{12}^{*}b^{*}\\&b^{\prime}^{*}=o_{21}^{*}a^{*}+o_{22}^{*}b^{*}\\ \end{aligned} $$ 

This is how the conjugate is going to change under physical operation. We also know that in the ‘bra’ space, row matrix is used to represent vectors, i.e:

 $$ \left\langle E^{\prime}\right|=(a^{\prime^{*}}b^{\prime^{*}});\left\langle E\right|=(a^{*}b^{*}) $$ 

Then the above relation of the physical operation can be expressed into matrix form of:

 $$ (a^{\prime\ast}b^{\prime\ast})=(a^{\ast}b^{\ast})\begin{pmatrix}o_{11}^{\ast}&o_{21}^{\ast}\\ o_{12}^{\ast}&o_{22}^{\ast}\end{pmatrix} $$ 

In Dirac notation, this could be written as:

 $ \langle E' \rangle = \langle E | (\hat{O})^* $, where  $ (\hat{O})^* $ is the operator in the ‘bra’ space, its matrix form is given above, which is exactly the complex and transposed matrix of the operator in ‘ket’ space  $ \hat{O} $. The matrix symbol for the transposed and complex of a matrix is  $ \hat{O}^\dagger $, so the above Dirac notation is written as:

 $ \langle E' \rangle = \langle E | \hat{O}^\dagger \qquad (17) $

In the LA language, above is just take complex conjugate on both sides and use the fact that  $ (AB)^{\dagger} = B^{\dagger}A^{\dagger} $.

(6) We have discussed about the basics of matrix representation of vectors and Dirac notation, here are some often used representations in Q.M (many of them I already used or proved above)

(in the following discussion, I will use i,j,k to represent base vectors; Greek letter to represent other state vectors, and capital A, B's to represent operators)

(a) The complex conjugate of any combination.

In (3) and (5), we discussed complex conjugate of the state vector and operator, i.e.  $ |\langle\rangle \leftrightarrow \langle| $ for state vector;  $ A \leftrightarrow A^\dagger $ for operator, use matrix and linear algebra, not hard to prove the following:

For any combination of numbers, kets, bras, and operators, its complex conjugate is conjugate any numbers; replace kets with bras and vice versa, replace operator with its conjugate(the daggers); For the kets (bra) and operator cases, their order needs to be reversed too. (This is important since order in matrix is vital). This is illustrated by examples below:

 $$ \left(\left\langle\chi\left|\psi\right.\right\rangle\right)^{*}=\left\langle\psi\left|\chi\right.\right\rangle $$ 

 $$ (18)\left(\operatorname{k e t}{\leftrightarrow}\operatorname{b r a},\mathrm{a n d~o r d e r~c h a n g e}\right) $$ 

 $ |\psi\rangle = a|\phi\rangle = a_1|\varphi_1\rangle + a_2\langle\varphi_2|\varphi_3\rangle|\varphi_4\rangle + a_3AB|\varphi_5\rangle $, then what is the complex conjugate of this vector? (you should try it yourself first before looking into my answer which I hope mine is correct)

 $$ \left(\left|\psi\right\rangle\right)^{*}=\left\langle\psi\right|=a^{*}\left\langle\phi\right|=a_{1}^{*}\left\langle\varphi_{1}\right|+a_{2}^{*}\left\langle\varphi_{4}\right|\left\langle\varphi_{3}\right|\varphi_{2}\rangle+a_{3}^{*}\left\langle\varphi_{5}\right|B^{\dagger}A^{\dagger} $$ 

(the last comes from linear algebra that  $ (AB)^{\dagger}=B^{\dagger}A^{\dagger} $)

(b) Some often used Dirac notations in Q.M

For a given basis (orthonormal and complete), satisfying conditions listed in part (1), for any state vector expanded on this basis with corresponding expansion (projection) coefficient  $ c_{i} $.

 $ |\psi\rangle = \sum_{i=1}^{n} c_i |i\rangle $, another vector  $ |\chi\rangle = \sum_{i=1}^{n} d_i |i\rangle $, A is an operator:

 $$ \left\langle i\left|\psi\right.\right\rangle=c_{i} $$ 

This is the projection coefficient(probability amplitude) along basis vector  $ |i> $ (Example, the H,V component for a circular polarized light)

 $ |\langle i|\psi\rangle|^{2}=\langle\psi|i\rangle\langle i|\psi\rangle=c_{i}^{*}c_{i} $ (20)

This is the probability (density for continuous) you will find state  $ |\psi\rangle $ in  $ |\mathrm{i}\rangle $. (Griffith would not like my terminology here, but what I mean is exactly like his)

 $ \langle \chi |\psi \rangle $ this is the probability amplitude of find  $ \chi $ component in  $ \psi $. (i.e. For a elliptical polarized light, how much left circular component it has, the basis is chosen as H-V)

In the given basis, it can be written as:  $ \langle \chi | \psi \rangle = \sum_{i=1}^{n} \langle \chi | i \rangle \langle i | \psi \rangle = \sum d_i^* c_i $ (this is exactly expressions for dot product between two vectors)

$A|\psi\rangle=|\psi'\rangle$, this is to say a physical operation changes the initial state into another state, the new state’s expansion in the basis can be calculated as following:

 $$ c_{i}^{\prime}=\left\langle i\left|\psi^{\prime}\right\rangle=\left\langle i\left|A\right|\psi\right\rangle=\left\langle i\left|A(\sum\left|j\right\rangle\left\langle j\right|)\right|\psi\right\rangle=\sum_{j=1}^{n}\left\langle i\left|A\right|j\right\rangle\left\langle j\right|\psi\right\rangle=\sum_{j=1}^{n}A_{i j}c_{j} $$ 

(A_{ij} is just the matrix element of the operator in the given basis, above is just the matrix product formula)

 $ \langle\chi|A|\psi\rangle $, this is to find the component of  $ \chi $ for the given input state  $ \psi $ after physical operation  $ A $ (i.e. a elliptical polarized light passes through a quarter-wave plate, and then how much circular polarized light it has) From the above discussion, you should be able to write out explicit expression but I will provide the answer anyway:

 $$ \begin{aligned}&\langle\chi\big|A|\psi\rangle=\langle\chi\big|\sum_{i}\big|i\rangle\langle i\big|A\sum_{j}\big|j\rangle\langle j\big|\big|\psi\rangle\\ &=\sum_{i j}\big\langle\chi\big|i\rangle\big\langle i\big|A\big|j\rangle\big\langle j\big|\psi\rangle=\sum_{i j}d_{i}^{*}A_{i j}c_{j}\\ \end{aligned} $$ 

One special case of this is if  $ |i\rangle $'s are eigenstates of  $ A $, then  $ A_{ij}=0 $ (for  $ i\neq j $),  $ A_{ii}=\lambda_i $ (the eigenvalues of  $ A $), then  $ \langle\psi|A|\psi\rangle=\sum_i(c_i^*c_i)\lambda_i $ (21)

which is the mean value (the expectation value) of measurement A performed on state  $ |\psi\rangle $.

Above listed are some often-used Dirac notations and their expressions in a certain basis are explicitly worked out. Now consider the case like this, what if we change the basis from basis |i> to another orthonormal basis say |k>(such as by rotation or maybe even change from spatial space to

momentum space, etc), then knowing the expression in one basis and knowing the transform between the basis themselves would enable us to write the form of above expressions in the new transformed basis, here is how :

 $ \langle k|\psi\rangle $ this is the projection component in the new basis. It is:

 $ \langle k | \psi \rangle = \sum_i \langle k | i \rangle \langle i | \psi \rangle $, so knowing the relation between  $ k,i $ (the basis vectors of the two space), and  $ c_i $ (the expression of the vector in one basis), the calculation is straightforward.(You may try this from H-V basis to R-L circular basis for polarization)

 $ \langle k | A | v \rangle $, this is the matrix element of operator in the new basis

 $ \langle k | A | v \rangle = \sum_{i,j} \langle k | i \rangle \langle i | A | j \rangle \langle j | v \rangle $, again knowing the operator under one basis,

you can find its form in the transformed basis. (again try H-V and R-L for

one optical element, say quarter wave plate or circular polarizer)

In the matrix form above relation is:

 $$ A_{k}=S A_{i}S^{\dagger}=S A_{i}S^{-1} $$ 

 $ A_k $,  $ A_i $ are the matrix form for operator  $ A $ in  $ k $ basis and  $ i $ basis.  $ S $ is a transform matrix, whose component is in form of  $ <k|i> $, if  $ k $,  $ i $'s are orthonormal basis, the  $ S $ is a orthogonal matrix, and  $ S^\dagger S = 1 $ or  $ S^\dagger = S^{-1} $ (also called a Unitary matrix in case of normalized  $ k, i $'s). This is just a quick statement on the similarity transform in  $ LA $.

(I only listed some important Dirac notation that come into my mind at

present, and might be used in the class, you are welcome to add more in this format☺)

