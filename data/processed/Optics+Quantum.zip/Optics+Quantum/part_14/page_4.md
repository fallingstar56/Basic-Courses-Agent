momentum space, etc), then knowing the expression in one basis and knowing the transform between the basis themselves would enable us to write the form of above expressions in the new transformed basis, here is how :

 $ \langle k|\psi\rangle $ this is the projection component in the new basis. It is:

 $ \langle k | \psi \rangle = \sum_i \langle k | i \rangle \langle i | \psi \rangle $, so knowing the relation between  $ k,i $ (the basis vectors of the two space), and  $ c_i $ (the expression of the vector in one basis), the calculation is straightforward.(You may try this from H-V basis to R-L circular basis for polarization)

 $ \langle k | A | v \rangle $, this is the matrix element of operator in the new basis

 $ \langle k | A | v \rangle = \sum_{i,j} \langle k | i \rangle \langle i | A | j \rangle \langle j | v \rangle $, again knowing the operator under one basis,

you can find its form in the transformed basis. (again try H-V and R-L for

one optical element, say quarter wave plate or circular polarizer)

In the matrix form above relation is:

 $$ A_{k}=S A_{i}S^{\dagger}=S A_{i}S^{-1} $$ 

 $ A_k $,  $ A_i $ are the matrix form for operator  $ A $ in  $ k $ basis and  $ i $ basis.  $ S $ is a transform matrix, whose component is in form of  $ <k|i> $, if  $ k $,  $ i $'s are orthonormal basis, the  $ S $ is a orthogonal matrix, and  $ S^\dagger S = 1 $ or  $ S^\dagger = S^{-1} $ (also called a Unitary matrix in case of normalized  $ k, i $'s). This is just a quick statement on the similarity transform in  $ LA $.

(I only listed some important Dirac notation that come into my mind at