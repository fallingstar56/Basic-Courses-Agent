The above section is about the matrix representation for a physical operation in the ‘ket’ space, , i.e. a representation of the following facts:

 $$ \begin{aligned}&a^{\prime}=o_{11}a+o_{12}b\\&b^{\prime}=o_{21}a+o_{22}b\\ \end{aligned} $$ 

For the complex conjugate of the vector, we would have relation of the following between them (just take complex conjugate on both sides):

 $$ \begin{aligned}&a^{\prime}^{*}=o_{11}^{*}a^{*}+o_{12}^{*}b^{*}\\&b^{\prime}^{*}=o_{21}^{*}a^{*}+o_{22}^{*}b^{*}\\ \end{aligned} $$ 

This is how the conjugate is going to change under physical operation. We also know that in the ‘bra’ space, row matrix is used to represent vectors, i.e:

 $$ \left\langle E^{\prime}\right|=(a^{\prime^{*}}b^{\prime^{*}});\left\langle E\right|=(a^{*}b^{*}) $$ 

Then the above relation of the physical operation can be expressed into matrix form of:

 $$ (a^{\prime\ast}b^{\prime\ast})=(a^{\ast}b^{\ast})\begin{pmatrix}o_{11}^{\ast}&o_{21}^{\ast}\\ o_{12}^{\ast}&o_{22}^{\ast}\end{pmatrix} $$ 

In Dirac notation, this could be written as:

 $ \langle E' \rangle = \langle E | (\hat{O})^* $, where  $ (\hat{O})^* $ is the operator in the ‘bra’ space, its matrix form is given above, which is exactly the complex and transposed matrix of the operator in ‘ket’ space  $ \hat{O} $. The matrix symbol for the transposed and complex of a matrix is  $ \hat{O}^\dagger $, so the above Dirac notation is written as:

 $ \langle E' \rangle = \langle E | \hat{O}^\dagger \qquad (17) $

In the LA language, above is just take complex conjugate on both sides and use the fact that  $ (AB)^{\dagger} = B^{\dagger}A^{\dagger} $.