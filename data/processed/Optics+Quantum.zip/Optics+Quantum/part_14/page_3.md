 $$ c_{i}^{\prime}=\left\langle i\left|\psi^{\prime}\right\rangle=\left\langle i\left|A\right|\psi\right\rangle=\left\langle i\left|A(\sum\left|j\right\rangle\left\langle j\right|)\right|\psi\right\rangle=\sum_{j=1}^{n}\left\langle i\left|A\right|j\right\rangle\left\langle j\right|\psi\right\rangle=\sum_{j=1}^{n}A_{i j}c_{j} $$ 

(A_{ij} is just the matrix element of the operator in the given basis, above is just the matrix product formula)

 $ \langle\chi|A|\psi\rangle $, this is to find the component of  $ \chi $ for the given input state  $ \psi $ after physical operation  $ A $ (i.e. a elliptical polarized light passes through a quarter-wave plate, and then how much circular polarized light it has) From the above discussion, you should be able to write out explicit expression but I will provide the answer anyway:

 $$ \begin{aligned}&\langle\chi\big|A|\psi\rangle=\langle\chi\big|\sum_{i}\big|i\rangle\langle i\big|A\sum_{j}\big|j\rangle\langle j\big|\big|\psi\rangle\\ &=\sum_{i j}\big\langle\chi\big|i\rangle\big\langle i\big|A\big|j\rangle\big\langle j\big|\psi\rangle=\sum_{i j}d_{i}^{*}A_{i j}c_{j}\\ \end{aligned} $$ 

One special case of this is if  $ |i\rangle $'s are eigenstates of  $ A $, then  $ A_{ij}=0 $ (for  $ i\neq j $),  $ A_{ii}=\lambda_i $ (the eigenvalues of  $ A $), then  $ \langle\psi|A|\psi\rangle=\sum_i(c_i^*c_i)\lambda_i $ (21)

which is the mean value (the expectation value) of measurement A performed on state  $ |\psi\rangle $.

Above listed are some often-used Dirac notations and their expressions in a certain basis are explicitly worked out. Now consider the case like this, what if we change the basis from basis |i> to another orthonormal basis say |k>(such as by rotation or maybe even change from spatial space to