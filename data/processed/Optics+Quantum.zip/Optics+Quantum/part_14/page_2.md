(b) Some often used Dirac notations in Q.M

For a given basis (orthonormal and complete), satisfying conditions listed in part (1), for any state vector expanded on this basis with corresponding expansion (projection) coefficient  $ c_{i} $.

 $ |\psi\rangle = \sum_{i=1}^{n} c_i |i\rangle $, another vector  $ |\chi\rangle = \sum_{i=1}^{n} d_i |i\rangle $, A is an operator:

 $$ \left\langle i\left|\psi\right.\right\rangle=c_{i} $$ 

This is the projection coefficient(probability amplitude) along basis vector  $ |i> $ (Example, the H,V component for a circular polarized light)

 $ |\langle i|\psi\rangle|^{2}=\langle\psi|i\rangle\langle i|\psi\rangle=c_{i}^{*}c_{i} $ (20)

This is the probability (density for continuous) you will find state  $ |\psi\rangle $ in  $ |\mathrm{i}\rangle $. (Griffith would not like my terminology here, but what I mean is exactly like his)

 $ \langle \chi |\psi \rangle $ this is the probability amplitude of find  $ \chi $ component in  $ \psi $. (i.e. For a elliptical polarized light, how much left circular component it has, the basis is chosen as H-V)

In the given basis, it can be written as:  $ \langle \chi | \psi \rangle = \sum_{i=1}^{n} \langle \chi | i \rangle \langle i | \psi \rangle = \sum d_i^* c_i $ (this is exactly expressions for dot product between two vectors)

$A|\psi\rangle=|\psi'\rangle$, this is to say a physical operation changes the initial state into another state, the new state’s expansion in the basis can be calculated as following: