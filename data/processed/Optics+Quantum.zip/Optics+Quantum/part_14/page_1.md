(6) We have discussed about the basics of matrix representation of vectors and Dirac notation, here are some often used representations in Q.M (many of them I already used or proved above)

(in the following discussion, I will use i,j,k to represent base vectors; Greek letter to represent other state vectors, and capital A, B's to represent operators)

(a) The complex conjugate of any combination.

In (3) and (5), we discussed complex conjugate of the state vector and operator, i.e.  $ |\langle\rangle \leftrightarrow \langle| $ for state vector;  $ A \leftrightarrow A^\dagger $ for operator, use matrix and linear algebra, not hard to prove the following:

For any combination of numbers, kets, bras, and operators, its complex conjugate is conjugate any numbers; replace kets with bras and vice versa, replace operator with its conjugate(the daggers); For the kets (bra) and operator cases, their order needs to be reversed too. (This is important since order in matrix is vital). This is illustrated by examples below:

 $$ \left(\left\langle\chi\left|\psi\right.\right\rangle\right)^{*}=\left\langle\psi\left|\chi\right.\right\rangle $$ 

 $$ (18)\left(\operatorname{k e t}{\leftrightarrow}\operatorname{b r a},\mathrm{a n d~o r d e r~c h a n g e}\right) $$ 

 $ |\psi\rangle = a|\phi\rangle = a_1|\varphi_1\rangle + a_2\langle\varphi_2|\varphi_3\rangle|\varphi_4\rangle + a_3AB|\varphi_5\rangle $, then what is the complex conjugate of this vector? (you should try it yourself first before looking into my answer which I hope mine is correct)

 $$ \left(\left|\psi\right\rangle\right)^{*}=\left\langle\psi\right|=a^{*}\left\langle\phi\right|=a_{1}^{*}\left\langle\varphi_{1}\right|+a_{2}^{*}\left\langle\varphi_{4}\right|\left\langle\varphi_{3}\right|\varphi_{2}\rangle+a_{3}^{*}\left\langle\varphi_{5}\right|B^{\dagger}A^{\dagger} $$ 

(the last comes from linear algebra that  $ (AB)^{\dagger}=B^{\dagger}A^{\dagger} $)