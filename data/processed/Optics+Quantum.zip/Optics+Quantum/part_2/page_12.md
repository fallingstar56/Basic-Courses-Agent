 $ S_{i_1} < 0 $, means  $ i_1 $ is at the same side as  $ O $, i.e. it is a virtual image,

 $ \frac{n'}{n} S_{o_1} $ to the left of 1.

For surface 2,  $ i_{1} $ becomes a real object (The incident light towards surface 2 are diverging)

The distance between surface 2 and  $ i_{1} $ is  $ S_{o_{2}} = d_{o} - S_{i_{1}} = d_{o} + \frac{n'}{n} S_{o_{1}} $

(Notice this is n' the incident light to 2 is from n' side)

 $$ \frac{n^{\prime}}{S_{o_{2}}}+\frac{n}{S_{i_{2}}}=0 $$ 

 $$ S_{_{i_{2}}}=-\frac{n}{n^{\prime}}S_{_{o_{2}}}=-S_{_{o_{1}}}-\frac{n}{n^{\prime}}d_{_{0}} $$ 

i is also a virtual image (S i < 0 ), to the left of 2, with distance

 $$ S_{o_{1}}+\frac{n}{n^{\prime}}d_{0} $$ 

 $$ \therefore\Delta S=\left|S_{_{i_{2}}}\right|-\left(S_{_{o_{1}}}+d\right)=-\frac{n^{\prime}-n}{n}d $$ 

Summary on Image Formation by a Spherical Refracting Surface

Generally a spherical surface is not an ideal optical element for image formation. However, under Paraxial Approximation, it is close to ideal.

Relation between image-object conjugate is given by: