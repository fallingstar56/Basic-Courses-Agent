Convex  $ (N_{1}>N_{0}) $

<div style="text-align: center;"><img src="imgs/img_in_image_box_186_202_766_1465.jpg" alt="Image" width="48%" /></div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>c</td><td style='text-align: center; word-wrap: break-word;'>f_{i}</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f_{i}</td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

Based on the above argument, it is easy to see that two special