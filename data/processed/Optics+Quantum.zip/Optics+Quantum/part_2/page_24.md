
<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>where</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

## 4 -8 Thin lens combination

For a combination of thin lenses of two or more, it is same as the way we have worked for the multiple spherical surfaces cases, where we can work one lens at a time.

For the special use, where the separation between lenses d = 0, it is easy to prove that:

 $$ \begin{aligned}&\frac{1}{S_{o}}+\frac{1}{S_{i}}=\frac{1}{f_{1}}+\frac{1}{f_{2}}+...\\ &\\ &\left(n_{i}=n_{o}\right)\\ &\\ &\therefore\frac{1}{f}=\frac{1}{f_{1}}+\frac{1}{f_{2}}+...\\ &\\ &D\equiv\frac{1}{f}\\ &\\ &D=D_{1}+D_{2}+...\\ \end{aligned} $$ 

D: dioptric power, in unit of Diopter  $ \left(\frac{1}{m}\right) $

* The close contact combination of thin lenses is equivalent to a single thin lens, with effective focal length given by (4-17)

For combination of thin lenses with nonzero separation will be equivalent