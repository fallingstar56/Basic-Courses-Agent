 $$ n_{i_{1}}(\alpha_{i_{1}}+\alpha_{1})=n_{t_{1}}(\alpha_{t_{1}}+\alpha_{1}) $$ 

 $$ \begin{aligned}&\alpha_{_{1}}\approx\frac{y_{_{1}}}{R}\\ &\\ &\therefore n_{_{t_{i}}}\alpha_{_{t_{i}}}=n_{_{i}}\alpha_{_{i_{i}}}-(\frac{n_{_{t_{i}}}-n_{_{i_{i}}}}{R_{_{1}}})y_{_{1}}=n_{_{i_{i}}}\alpha_{_{i_{i}}}-D_{_{1}}y_{_{1}};D_{_{1}}\equiv\frac{n_{_{t_{i}}}-n_{_{i_{i}}}}{R_{_{1}}}\\ &\\ &Or for refraction\begin{cases}n_{_{t_{i}}}\alpha_{_{t_{i}}}=n_{_{i_{i}}}\alpha_{_{i_{i}}}-D_{_{1}}y_{_{1}}\\ \quad y_{_{t_{i}}}=y_{_{i_{i}}}}\end{cases}(4-27)\\ \end{aligned} $$ 

Similarly for the propagation in the same media, we have:

Transfer $ \left\{\begin{array}{l}\alpha_{i_{2}}=\alpha_{t_{1}}\\y_{i_{2}}=y_{t_{1}}+d_{21}\alpha_{t_{1}}\end{array}\right. $  $ d_{21} $ is the thickness of lens

① Definition of Refraction Matrix

 $$ \begin{bmatrix}n_{t_{1}}\alpha_{t_{1}}\\ y_{t_{1}}\end{bmatrix}=\begin{bmatrix}1&-D_{1}\\ 0&1\end{bmatrix}\begin{bmatrix}n_{i_{1}}\alpha_{i_{1}}\\ y_{i_{1}}\end{bmatrix} $$ 

 $ R_{1} $ refraction matrix:  $ \begin{bmatrix} 1 & -D_{1} \\ 0 & 1 \end{bmatrix} $

② Transfer matrix

 $$ \begin{bmatrix}{{{n_{i_{2}}\alpha_{i_{2}}}}} \\{{{y_{i_{2}}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{\frac{d_{21}}{n_{t_{1}}}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{n_{t_{1}}\alpha_{t_{1}}}}} \\{{{y_{t_{1}}}}}\end{bmatrix} $$ 

 $ \Gamma_{21} $ Transfer Matrix:  $ \begin{bmatrix} 1 & 0 \\ \frac{d_{21}}{n_{t_1}} & 1 \end{bmatrix} $

③ For a lens system, the initial ray  $ \tau_{i} $ will be refracted by the front