 $$ \frac{f_{0}}{S_{0}}+\frac{f_{i}}{S_{i}}=1 $$ 

Under paraxial condition, that each point on the axis  $ S_{0} $, will form an image at  $ S_{i} $ on the axis based on (4-6)

 $ ^{*} $Sign convention for spherical refraction and thin lenses (Light entering the lens from Left side)


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$ S_{0}, f_{0} $</td><td style='text-align: center; word-wrap: break-word;'>+ left of vertex A</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_{i}, f_{i} $</td><td style='text-align: center; word-wrap: break-word;'>+ right of A</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>R</td><td style='text-align: center; word-wrap: break-word;'>+ c is right of A</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ y_{0}, y_{i} $</td><td style='text-align: center; word-wrap: break-word;'>+ above the optical axis</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ x_{o} $</td><td style='text-align: center; word-wrap: break-word;'>+ left of  $ f_{0} $ (x is used in Newton formular)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ x_{i} $</td><td style='text-align: center; word-wrap: break-word;'>+ right of  $ f_{i} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ \mu $</td><td style='text-align: center; word-wrap: break-word;'>+ optical axis to ray is counter clock wise.</td></tr></table>

Choose the convention and stick to it, then from the computation to determine the positions of the image relative to the optical elements. This is the basics of geometric optics.

Example: