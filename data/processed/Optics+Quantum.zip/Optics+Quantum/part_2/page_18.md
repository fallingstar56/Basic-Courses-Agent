 $$ S_{o_{2}}=d_{12}-S_{i} $$ 

 $$ S_{o_{3}}=d_{23}-S_{i_{2}} $$ 

Lagrange-Helmholtz relation:

Though there is no simple relation between the position of object and image for multiple surfaces. The energy conservation generates a simple relation between angular and linear size of the conjugate object-image.

①. First, need to define signs for angle spanned by the object and image.

<div style="text-align: center;"><img src="imgs/img_in_image_box_314_818_456_869.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_317_884_454_936.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_646_825_786_878.jpg" alt="Image" width="11%" /></div>


 $$ \frac{u_{1}}{u_{2}} $$ 

 $$ M>0 $$ 

 $$ u^{\prime}<0 $$ 

optical axis  $ \rightarrow $ ray

counter clockwise

Optical axis → ray

clockwise

Then it is easy to prove L-H relation. At small  $ \mu_{o}, \mu_{i} $

 $$ \underline{\mu_{o}}=-\frac{S_{i}}{\dot{\underline{\mu}}}=\underline{y_{i} n_{i}} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_479_1254_668_1343.jpg" alt="Image" width="15%" /></div>


 $$ \mu_{_{i}}\qquad S_{_{o}}\quad y_{_{o}}n_{_{o}} $$ 

 $$ \because\frac{y_{i}}{y_{o}}=-\frac{S_{i}n_{o}}{S_{o}n_{i}} $$ 