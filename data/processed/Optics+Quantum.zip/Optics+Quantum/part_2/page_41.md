4-33 will become  $ a_{12} = -\frac{1}{f} $.

Similarly  $ \overline{V_{1}H_{1}}=\frac{n_{i_{1}}(1-a_{11})}{-a_{12}} $

If plug in the expression for  $ a_{11}, a_{12}, a_{22}, a_{21} $, then the relations (4-32)-(4.34) will be exactly as the equation of the locations for focal points and primary planes of thick lens given earlier without proof (4-20), (4-21).

### ④. Object —— Image conjugate points

 $ \tau_{obj} $ is the origin of a ray from a point of object

 $ \tau_{image} $ is the destination point of the conjugate ray on the image?

 $$ \tau_{image}=\Gamma_{I2}A_{21}\Gamma_{10}\tau_{obj} $$ 

⑤. General form of A for the multi-lenses system.

 $$ A=\ldots\Gamma_{43}R_{3}\Gamma_{32}R_{2}\Gamma_{21}R_{1} $$ 

As the example of Hecht’s Book (pg. 251, Hecht, Fig 6.10), the 4 lenses-7 surface system, by writing explicitly each $R_{i}$, $\Gamma_{ij}$ and by production of the matrices, fairly straight-forward to generate the final matrix $A_{\Gamma1}$, which is equivalent to a thick lens; and from its matrix element, the cardinal points of the equivalent lens can be easily calculated.

Such evaluation is more easily solved by computer program. There is

commercial available software for ray tracing, such as “Optical Labs”