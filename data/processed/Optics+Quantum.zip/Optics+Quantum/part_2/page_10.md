<div style="text-align: center;"><img src="imgs/img_in_image_box_230_151_557_273.jpg" alt="Image" width="27%" /></div>


 $$ f_{i}=\frac{n_{i}r}{n_{i}-n_{o}}\quad>0 $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_199_341_509_479.jpg" alt="Image" width="26%" /></div>


 $$ f_{i}=\frac{n_{i}r}{n_{i}-n_{o}}<0 $$ 

The calculation based on the above sign convention is straightforward in this simple case. What I want to demonstrate is that they agree with the geometric method (draw directly from Snell’s law). Also noticed that the converging or diverging of the convex and concave surface depend on relative value between  $ n_{i}, n_{0} $ if  $ n_{i} < n_{o} $, the above situations are reversed.

Example for a refracted surface:

<div style="text-align: center;"><img src="imgs/img_in_image_box_238_1018_905_1259.jpg" alt="Image" width="56%" /></div>


<div style="text-align: center;">Where is the image of o after inserting a glass slide with thickness  $ d_{o} $, or where is the new position the eye thinks the light originated?</div>


(1) Geometric solution