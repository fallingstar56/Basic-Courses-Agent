<div style="text-align: center;"><img src="imgs/img_in_image_box_198_172_830_387.jpg" alt="Image" width="53%" /></div>


For rays in the same plane as the optical axis, thus the problem is basically in 2-dimensional space, the location of each point on the ray (thus the trajectory) can be determined by specifying two independent variables, such as (x,y) Cartesian coordinate. Then the general form of propagation of light would be:

 $$ \begin{bmatrix}x^{\prime}\\ y^{\prime}\end{bmatrix}=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}x_{0}\\ y_{0}\end{bmatrix} $$ 

With the matrix known, we can determine the transformation of the original light ray  $ \begin{bmatrix} x_0 \\ y_0 \end{bmatrix} $, and we shall see that the rectilinear propagation of light, and refraction at interfaces can call be represented in matrix form.

There are obviously other ways to specify the variables (Fig.6.7 Hecht's). The variables for a point on a ray are specified by variables:

y: distance from optical axis; and

 $ \alpha $ : the angle between ray and optical axis.