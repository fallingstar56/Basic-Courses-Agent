## 4 -10 Graphical Method of Image Formation

By using the definition of focal points, optical center, or other cardinal points, we can determine the light rays passing through these cardinal points, and thus the image formed after the optical elements. The graphical method is just geometric drawings by a pair of special rays (the rays passing the cardinal points) out of an objective point and finds its intersection after the lens to get the image point.

(a) Spherical Surface

<div style="text-align: center;"><img src="imgs/img_in_image_box_184_803_990_1140.jpg" alt="Image" width="67%" /></div>


For the on-axis point B