<div style="text-align: center;"><img src="imgs/img_in_image_box_203_162_993_468.jpg" alt="Image" width="66%" /></div>


By using the fact that A parallel beam (but not collinear with optical axis) will be focused to point on the focal plane.

You should be able to work for the concave cases.

b) Thin lens

<div style="text-align: center;"><img src="imgs/img_in_image_box_239_794_672_1110.jpg" alt="Image" width="36%" /></div>


For the on axis points, similar to what been discussed for the spherical surface