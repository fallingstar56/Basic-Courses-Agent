surface and its objective distance is provided by (4-10). This derivation and the previous example on the image formation by the glass slide follows a simple logic and important procedure of working the problems of image formation through multiple optical elements (here optical elements are refractive surfaces; later can be lens, mirrors etc.). The procedure is just working the problem of image formation one element at a time. The image of the first element will act as object to the second and it proceeds like this. Knowing the arrangement of the elements, the (4-10) provides means to calculate objective distance.

Now back to the thin lens case, we need a relation between  $  S_o(=S_{o_1})  $ and  $  S_i(=S_{i_2})  $

 $$ \begin{aligned}&S_{i_{1}}=-\frac{f_{i_{1}}S_{o_{1}}}{f_{o_{1}}-S_{o_{1}}}\quad&S_{i_{2}}=-\frac{f_{i_{2}}S_{o_{2}}}{f_{o_{2}}-S_{o_{2}}}\\ &\\ &S_{o_{2}}=d-S_{i_{1}}=d+\frac{f_{i_{1}}S_{o_{1}}}{f_{o_{1}}-S_{o_{1}}}\\ &\\ &\therefore S_{i_{2}}=\frac{-f_{i_{2}}}{f_{o_{2}}-S_{o_{2}}}(d+\frac{f_{i_{1}}S_{o_{1}}}{f_{o_{1}}-S_{o_{1}}})\\ \end{aligned} $$ 

It is hard to find a simple relation between $S_{i}$, and $S_{o_{1}}$, as $d \neq 0$.

As for the thin lens whose  $ d \rightarrow 0 $ :

 $$ S_{i_{2}}=\frac{-f_{i_{2}}f_{i_{1}}S_{o_{1}}}{(f_{o_{2}}-S_{o_{2}})(f_{o_{1}}-S_{o_{1}})} $$ 