Their location with respect to the surface is given sign convention and summarized in the notes above and also in table 5.1 Hecht's:


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="2">$  \dot{s}.1  $ Sign Convention for Spherical  $ \mathbf{s} $.acting Surfaces and Thin Lenses $ ^{*} $ (Light Entering from the Left)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  s_{o}, f_{o}  $</td><td style='text-align: center; word-wrap: break-word;'>+ left of  $  V  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  x_{o}  $</td><td style='text-align: center; word-wrap: break-word;'>+ left of  $  F_{o}  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  s_{i}, f_{i}  $</td><td style='text-align: center; word-wrap: break-word;'>+ right of  $  V  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  x_{i}  $</td><td style='text-align: center; word-wrap: break-word;'>+ right of  $  F_{i}  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  R  $</td><td style='text-align: center; word-wrap: break-word;'>+ if  $  C  $ is right of  $  V  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  y_{o}, y_{i}  $</td><td style='text-align: center; word-wrap: break-word;'>+ above optical axis</td></tr></table>

## 4 -5 Finite Imagery and Transverse Magnification

This is the question of image formation for points off the optical axis:

<div style="text-align: center;"><img src="imgs/img_in_image_box_208_916_823_1156.jpg" alt="Image" width="51%" /></div>


Due to the spherical symmetry,  $ P - P' $  $ S - S' $ are also object-Image conjugate.

If the $\phi$ is very small (paraxial condition), then Curve $PQS$ and its conjugate image $\widehat{P'Q'S'}$ will be close to a plane perpendicular ($\perp$) to the optical axis. Equivalently this requires: