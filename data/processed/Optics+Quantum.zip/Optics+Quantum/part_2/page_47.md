etc. , the point I want to illustrate is that by such image formation with the optical element to the left, we have systematic method to determine the AS.

Entrance Pupil: The image of the aperture stop form by it with the optical element preceding it (to the left of it with our conventional setup).

Knowing the entrance pupil (determined by the method illustrated by the example above), (4-36) is used to estimate the percentage of energy passed system.

There is also a symmetrical pupil for exit:

Exit Pupil: The image formed by the AS by the optical elements after it (to the right of it).

The light that passes through the entrance pupil will pass through the aperture stop and then leave the system through the exit pupil.

## (3) F number

This is related to the brightness of the image. The size of the image is proportional to square of the linear magnification:

Image Area  $ \propto M_{T}^{2} = \frac{f^{2}}{x_{o}^{2}} $

In many cases where S_o >> f , so will be the x_o = S_o - f , and the area of