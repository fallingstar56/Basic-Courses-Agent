every single point of the image, while keeping the proportion (one to one correspondence without distortion).

<div style="text-align: center;"><img src="imgs/img_in_image_box_267_292_952_471.jpg" alt="Image" width="57%" /></div>


In sections below, we are going to study what are these devices, why they work and what are their limitations.

## 4 -1 Jargons in geometric optic

——Focal points, concave, convex, real, virtual images, objects, object-Image conjugates

Take examples that we are already familiar with,

a) convex lens

 $$ 0\quad\text{or}\quad\downarrow $$ 

light passes through a convex lens will be more converged

<div style="text-align: center;"><img src="imgs/img_in_image_box_286_1158_1047_1416.jpg" alt="Image" width="63%" /></div>


Optical axis: The line passes the center of the lens and