## Nodal points

If  $ n_{o}=n_{i} $, the nodal points overlap with primary points

(2) Cardinal points in terms of basic parameters  $ (n_{i}, n_{o}, n_{L}, R, d) $

 $$  If n_{_{o}}=n_{_{i}}\approx1,f_{_{o}}=f_{_{i}}=f $$ 

(a)

 $$ \frac{1}{f}=\left(n_{_{L}}-1\right)\left[\frac{1}{R_{_{1}}}-\frac{1}{R_{_{2}}}+\frac{(n_{_{L}}-1)d_{_{L}}}{n_{_{L}}R_{_{1}}R_{_{2}}}\right] $$ 

 $ f_{o} $ : is measured from  $ H_{1} $ It is + to the left of  $ H_{1} $

f: is measured from H2. It is + to the Right of H2.

(b)

 $$ \overline{V_{_{1}}H_{_{1}}}=h_{_{1}}=\frac{-f(n_{_{L}}-1)d_{_{L}}}{R_{_{2}}n_{_{L}}} $$ 

 $$ \overline{V_{_{2}}H_{_{2}}}=h_{_{2}}=\frac{-f(n_{_{L}}-1)d_{_{L}}}{R_{_{1}}n_{_{L}}} $$ 

 $ h_{1}, h_{2}: +\mathrm{if} \quad H_{j} \mathrm{is} \mathrm{to} \mathrm{the} \mathrm{right} \mathrm{of} \quad V_{j} \quad (\mathrm{note} \mathrm{this} \mathrm{definition} \mathrm{is} \mathrm{different}  $

in Zhao's book)

For the thin lens,  $ (d_{L} \rightarrow 0) $ (4-19) is reduced to lens-Maker formula,  $ H_{1} $,  $ H_{2} $ collapse into one point and overlap with the optical center. These formula will be proved later using matrix method.

(3) Object – Image Relation