<div style="text-align: center;">C)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_381_143_794_580.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;">D)</div>


1) Real, Virtual Object:

In case (C), (D), object AB are real objects for $L_{1}$. Real means for the optical elements (such as $L_{1}$), the incoming lights from the object are diverging.

In case (C), if we insert a second lens into the system  $ (L_{2}) $, at the axial location as shown,  $ A'B' $ (the real image of AB through  $ L_{1} $) now becomes a virtual object for  $ L_{2} $, the incoming light to the  $ L_{2} $ (another saying is that  $ L_{2} $ sees the incoming light) are converging.

In case (D),  $ A'B' $ (the virtual image of AB through  $ L_{1} $) is a real object for  $ L_{2} $.

2) Real, Virtual Image

A'B' is a real image in case (c) formed by  $ L_{1} $, the lights that form the image are converging. The real image can be projected on a real screen.