Ω is the steric angle spanned by the aperture. The aperture stop is the one that has the smallest steric angle and thus limiting the light passage.

However, determining the AS is not straightforward, as the example shown above, just by looking at the setup we cannot tell which one will be the AS. You have to draw the rays corresponding to the limiting case for each optical element to find the AS. Still referring to the above example, the angle spanned by the first lens  $ L_{1} $ is easy to evaluate, but angles spanned by others may not. Clearly we need more systematic and error proof way for this, and for this purpose we introduce the concept of “pupil”.

## (2) Entrance Pupil and Exit Pupil

Starting with a simpler example with less optical element:

<div style="text-align: center;"><img src="imgs/img_in_image_box_249_1036_768_1157.jpg" alt="Image" width="43%" /></div>


For the 2 lens with one iris setup, we need to determine first which the aperture stop is. This is done by image formation. As always, we use the configuration that light comes from left. Taking the image of each optical element with respect to the lens (or multiple lens system) to the left of it, such images are called pupils. In the simpler example, the iris