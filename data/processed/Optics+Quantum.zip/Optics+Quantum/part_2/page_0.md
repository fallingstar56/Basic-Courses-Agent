Example: Change the wave front and Image formation:

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_289_1000_460.jpg" alt="Image" width="67%" /></div>


In experiments in physics, there are numerous occasions that we need to detect the light emitting or scattered from an object, not even considering that our own eyes are a pair of complicated lens (or camera) system. The most common set up would be:

<div style="text-align: center;"><img src="imgs/img_in_image_box_187_810_1003_1096.jpg" alt="Image" width="68%" /></div>


molecules, cells,

Stars



eyes, photo multiplier,

CCD, camera film ...

(a) Intensity—— such as molecular spectroscopy

We need to measure or record

(b) Image

For purpose (a), we need to collect as much light as possible.

For purpose (b), we need a device to convert every point of the object into