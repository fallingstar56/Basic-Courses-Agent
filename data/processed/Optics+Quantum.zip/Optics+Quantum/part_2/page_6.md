under what condition that the spherical ones can be treated as ideal.

Ideal optical Element:

(1) All light rays from one point source can be transformed into another point. 1↔1 relation between image and object, so to the lines and planes.

(2) The optical element can cover wide range of objective distance, not only for a specific pair of object —— image points.

(3) No distortion, i.e. keep the original shape of the object, a constant magnification value in image plane.

## 4 -3 Refraction at a Single Spherical Surface

(Fig 5.6 Hecht’s or Fig 5.1 Zhao’s)

<div style="text-align: center;"><img src="imgs/img_in_image_box_196_999_991_1345.jpg" alt="Image" width="66%" /></div>


We need to find relation between $S_{o}, S_{i}$. If it is independent of $\phi$ (or $h, i_{1}$, $i_{2}, \ldots$) then all rays coming from $Q$ can be converged into $Q', i.e. Q, Q'$