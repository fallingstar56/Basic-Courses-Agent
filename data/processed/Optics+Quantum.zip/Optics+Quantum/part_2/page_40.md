have their formula.

<div style="text-align: center;"><img src="imgs/img_in_image_box_216_254_795_565.jpg" alt="Image" width="48%" /></div>


The initial input ray is just  $ \begin{bmatrix} 0 \\ y_{i_1} \end{bmatrix} $

 $$ \begin{aligned}&\begin{bmatrix}n_{t_{2}}\alpha_{t_{2}}\\ y_{t_{2}}\end{bmatrix}=A\begin{bmatrix}0\\ y_{i_{1}}\end{bmatrix}=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}0\\ y_{i_{1}}\end{bmatrix}\\ &\\ &\Rightarrow n_{t_{2}}\alpha_{t_{2}}=a_{12}y_{i_{1}}.\\ \end{aligned} $$ 

 $$ \begin{aligned}&y_{t_{2}}=a_{22}y_{i_{1}}.\\ &\\ &\overline{V_{2}H_{2}}=\frac{\Delta y}{\alpha_{t_{2}}}=\frac{y_{i_{1}}-y_{t_{2}}}{\alpha_{t_{2}}}=\frac{(1-a_{22})}{\frac{a_{12}}{n_{t_{2}}}}=\frac{n_{t_{2}}(a_{22}-1)}{-a_{12}}\\ &\\ &\overline{V_{2}f_{i}}=\frac{-y_{t_{2}}}{\alpha_{t_{2}}}=\frac{-n_{t_{2}}a_{22}}{a_{12}}\\ &\\ &f_{i}\equiv\overline{H_{2}f_{i}}=\frac{-n_{t_{2}}a_{22}}{a_{12}}+\frac{n_{t_{2}}(a_{22}-1)}{a_{12}}=\frac{-n_{t_{2}}}{a_{12}}\\ &\\ &Or\quad a_{12}=\frac{-n_{t_{2}}}{f}\quad(4-33)\\ \end{aligned} $$ 

A lot of times, the other side of the lens is just air and thus  $ n_{t}, \approx 1 $, and