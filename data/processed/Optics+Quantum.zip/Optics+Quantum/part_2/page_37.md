<div style="text-align: center;"><img src="imgs/img_in_image_box_194_165_481_291.jpg" alt="Image" width="24%" /></div>


y: + if above O.A

 $ \alpha:+ $ if O.A to ray is counter-clockwise (or ray has positive slope)

Under Paraxial approx., using Snell’s Law: (refer to Fig 6.7)

<div style="text-align: center;"><img src="imgs/img_in_image_box_229_625_991_973.jpg" alt="Image" width="64%" /></div>


We first investigate the transform brought by the spherical surface refraction. (The point on the surface at the incident beam side is  $ \begin{bmatrix} \alpha_{i_1} \\ y_{i_1} \end{bmatrix} $, its counterpart on the transmitted side would be  $ \begin{bmatrix} \alpha_{i_1} \\ y_{i_1} \end{bmatrix} $. It is the relation between  $ \begin{bmatrix} \alpha_{i_1} \\ y_{i_1} \end{bmatrix} \leftrightarrow \begin{bmatrix} \alpha_{i_1} \\ y_{i_1} \end{bmatrix} $ that we want. The subscript meaning:  $ i_1 $ incident at surface 1;  $ t_1 $ transmitted at surface 1...)

 $$ n_{i_{1}}\theta_{i_{1}}=n_{t_{1}}\theta_{t_{1}} $$ 