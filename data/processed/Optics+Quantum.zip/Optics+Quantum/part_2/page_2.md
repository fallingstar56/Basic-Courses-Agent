perpendicular to it.

$f_{o}$ : a special point on the optical axis; lights from $f_{o}$ after optical elements will be parallel beams. Or $f_{o}$ has image at $\infty$ (infinity).

$f_{i}$: another special point on optical axis; beams parallel to the optical axis after pass optical element will focus to $f_{i}$. Or object at $\infty$ will have its image at $f_{i}$.

 $$ \mathbb{Z}\quad\text{or}\quad\mathbb{Z} $$ 

b) concave lens:

Light passes through a concave lens will be more diverged. The  $ f_{o} $ is a virtual object on the optical axis whose image is at infinity;  $ f_{i} $ is the virtual image whose corresponding object is at infinity.

<div style="text-align: center;"><img src="imgs/img_in_image_box_379_921_843_1246.jpg" alt="Image" width="38%" /></div>
