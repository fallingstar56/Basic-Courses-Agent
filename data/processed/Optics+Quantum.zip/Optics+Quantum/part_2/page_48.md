image will be approximately proportional to  $ f^{2} $

The energy flow through the system as we had seen previously will be proportional to the square of the diameter of the lens or the aperture stop:  $ E_{r} \propto D^{2} $. So the energy flow density or energy per unit time per unit area on the image will be proportional to  $ \frac{D^{2}}{f^{2}} $

The f number of the lens system is defined as:

 $$ f^{\#}\equiv\frac{f}{D} $$ 

The reason defined as 4-37 as reciprocal of the energy flow density is in photography, this f number is used to determine the exposure time. The larger the f number (the smaller the energy flow rate) means longer the exposure time to get a bright picture.

## (4) Field Stop

Previously we focus on the axial point sources and concern how much energy will pass the optical system. Here we shall consider off-axis point and estimate how much energy will pass through system for these off axis point, this relates to the problem of field of view for the imaging system.

For a single lens system, the lens itself will be the aperture stop, the entrance and exit pupil as well. The light from off axis points can be