are conjugate. The position of the image is most generally in a functional form:  $ S_i = F(S_0, n_i, n_0, r, \phi, i_1, i_2, \ldots) $. Of course, not all the variables are independent, they are related by Snell's law, triangular relations etc.

Neglect the detail derivation (refer to Hecht's 5.2.2), we get:

 $$ \frac{S_{0}^{2}}{n_{0}^{2}(S_{0}+r)^{2}}-\frac{S_{i}^{2}}{n_{i}^{2}(S_{i}-r)^{2}}=-4r\sin^{2}\frac{\phi}{2}\left[\frac{1}{n_{0}^{2}(S_{0}+r)}+\frac{1}{n_{i}^{2}(S_{i}-r)}\right] $$ 

Generally,  $ S_0 $ and  $ S_i $ are dependent on  $ \phi $ (that is where the ray hit the surface), so rays from  $ S_0 $ of different angle generally interact the axis at different distance, except for a special pair  $ S_0 $,  $ S_i $ where  $ \left\{\begin{array}{l} S_0^2 \\ n_0^2(S_0 + r)^2 - \frac{S_i^2}{n_i^2(S_i - r)^2} = 0 \\ \frac{1}{n_0^2(S_0 + r)} + \frac{1}{n_i^2(S_i - r)} = 0 \end{array}\right. $

Such $S_{0}, S_{i}$ defines the location of Stigmatic Points for the spherical surface (these special pair can achieve so called broad beam image formation. i.e. all light from the object at O are converged to the image point I).

So (4-1) shows that the spherical surface is not an ideal optical element except for a special pair of points.

## 4 -4 Paraxial Approximation

Under paraxial condition for points on the axis, i.e.