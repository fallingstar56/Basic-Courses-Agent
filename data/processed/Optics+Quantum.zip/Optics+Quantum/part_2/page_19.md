 $$ n_{o}y_{o}\mu_{o}=n_{i}y_{i}\mu_{i}=n_{i_{2}}y_{i_{2}}\mu_{i_{2}}\cdots\cdots $$ 

We can use L-H relation to easily determine the angular  $ \left(\mu\right) $ and linear size  $ (y) $ between conjugates.

<div style="text-align: center;"><img src="imgs/img_in_image_box_223_377_762_524.jpg" alt="Image" width="45%" /></div>


No matter how complex it is, can use L-H relation to get φi or yi.

## 4 -7 Thin Lens

<div style="text-align: center;"><img src="imgs/img_in_image_box_205_853_989_1159.jpg" alt="Image" width="65%" /></div>


This is equivalent to an object – Image formation through 2 interfaces.

 $$ \frac{f_{o_{1}}}{S_{o_{1}}}+\frac{f_{i_{1}}}{S_{i_{1}}}=1\qquad\quad\frac{f_{o_{2}}}{S_{o_{2}}}+\frac{f_{i_{2}}}{S_{i_{2}}}=1 $$ 

 $$ S_{o_{2}}=d-S_{i_{1}} $$ 

The image through the first surface will act as object to the second