 $$ \overline{O_{2}H_{2}}=-\frac{n_{t_{2}}(Q_{22}-1)}{a_{12}}=\frac{-fd}{f_{1}} $$ 

Same as (4-24)

## 4 -12 Apertures

(Hecht's 5.3)

Up to now, we have focused on the image formation for an optical system, i.e. given the information of the object, finding the location and magnification of its image etc. There is another important topic: Intensity. How much energy will be collected by the optical system? Each lens itself is an aperture only allowing a portion of light passing through it. People also purposely insert apertures (called iris) in the system in order to limit the size of the incoming light beam, so that the paraxial approximation will hold and this will reduce so called aberration and forming better quality picture. These apertures (the lens and the iris) will limit the amount of energy passing and this is what we shall study in this section.

## (1) The Aperture Stop (for axial point sources)

Aperture stops (AS) is the aperture that determines the energy flow through the system. It is the limiting apertures in the system so that if the light from an axial point can pass through AS, it will pass the system.