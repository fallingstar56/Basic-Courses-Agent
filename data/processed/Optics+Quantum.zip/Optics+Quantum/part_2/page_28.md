 $$ \frac{1}{S_{_{o}}}+\frac{1}{S_{_{i}}}=\frac{1}{f}\quad for\quad n_{_{o}}=n_{_{i}} $$ 

 $$ \mathrm{Or}\quad x_{0}x_{i}=f^{2} $$ 

 $$ M_{_{T}}=\frac{y_{_{i}}}{y_{_{o}}}=\frac{-x_{_{i}}}{f}=\frac{-f}{x_{_{o}}}=\frac{-S_{_{i}}}{S_{_{o}}} $$ 

Where  $ S_{0} $ is measured from  $ H_{1} $, + if to the left of  $ H_{1} $

S_{i} is measured from H_{2}, + if to the right of H_{2}.

These formula can most easily be proved by geometric method.

The physical meaning of the primary planes:

 $$  From(4-21):f=\frac{S_{o}S_{i}}{S_{i}+S_{o}} $$ 

If  $ S_{0} $ is on the  $ H_{1} $ plane, i.e.  $ S_{0}=0 $, then  $ S_{i}=0 $ too for non-zero focal length.

This means the image point is on the back principal plane H2.

∴ H1 and H2 are conjugate planes with magnification M:

 $$ M_{_{T}}=-\frac{x_{_{i}}}{f}=\frac{-f}{x_{_{o}}}=1\quad where\quad\begin{aligned}x_{_{o}}&=-f\\ x_{_{i}}&=-f\end{aligned} $$ 

(4) Combination of lenses