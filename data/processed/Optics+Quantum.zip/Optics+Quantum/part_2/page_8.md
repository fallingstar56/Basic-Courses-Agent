 $$ h^{2}\ll S_{0}^{2},\quad S_{i}^{2},\quad r^{2}\quad or\quad\mu^{2},\mu^{\prime}^{2},\phi^{2}\ll1 $$ 

Then

 $$ \sin^{2}\frac{\phi}{2}\approx\left(\frac{\phi}{2}\right)^{2}\approx0\qquad\qquad\mathrm{in}(4-1) $$ 

 $$ \therefore\frac{S_{0}^{2}}{n_{0}^{2}(S_{0}+r)^{2}}-\frac{S_{i}^{2}}{\left(S_{i}-r\right)^{2}n_{i}^{2}}=0 $$ 

 $$ \frac{S_{0}}{n_{0}(S_{0}+r)}=\frac{S_{i}}{\left(S_{i}-r\right)n_{i}} $$ 

 $$ n_{_{0}}+\frac{n_{_{0}}r}{S_{_{0}}}=n_{_{i}}-\frac{n_{_{i}}r}{S_{_{i}}} $$ 

 $$ \therefore\frac{n_{i}}{S_{i}}+\frac{n_{0}}{S_{0}}=\frac{n_{i}-n_{0}}{r} $$ 

 $ f_{i} $

For image focal point,  $ f_i: S_0 \to \infty $,  $ S_i \to f_i $

 $$ \frac{n_{i}}{f_{i}}=\frac{n_{i}-n_{0}}{r} $$ 

 $$ f_{i}=\frac{n_{i}r}{n_{i}-n_{0}} $$ 

Similarly for object focal point:  $ S_{i} \to \infty $,  $ S_{0} \to f_{0} $

 $$ f_{0}=\frac{n_{0}r}{n_{i}-n_{0}} $$ 

(4-3) object-image relation can be rewritten in the more familiar formula

(Gauss's formula):