 $$ \begin{aligned}&\begin{bmatrix}x_{1}\\ x_{2}\end{bmatrix}=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}y_{1}\\ y_{2}\end{bmatrix}\\ &\xrightarrow{vector}2*2 matrix\\ \end{aligned} $$ 

Column vector

(or 1X2 matrix)

(Transform Matrix)

 $$ \begin{aligned}If\begin{cases}y_{1}=b_{11}Z_{1}+b_{12}Z_{2}\\y_{2}=b_{21}Z_{1}+b_{22}Z_{2}\end{cases}\quad or\quad\begin{bmatrix}y_{1}\\y_{2}\end{bmatrix}=\begin{bmatrix}b_{11}&b_{12}\\b_{21}&b_{22}\end{bmatrix}\begin{bmatrix}Z_{1}\\Z_{2}\end{bmatrix}\end{aligned} $$ 

Then:

 $$ \begin{bmatrix}x_{1}\\ x_{2}\end{bmatrix}=\hat{A}\hat{B}\begin{bmatrix}Z_{1}\\ Z_{2}\end{bmatrix}=\hat{C}\begin{bmatrix}Z_{1}\\ Z_{2}\end{bmatrix} $$ 

(AB: Matrices product)

Where

 $$ C\equiv\begin{bmatrix}C_{11}&C_{12}\\ C_{21}&C_{22}\end{bmatrix}\quad C_{ij}=\sum_{k}a_{ik}b_{kj} $$ 

 $$ \left(C_{11}=a_{11}b_{11}+a_{12}b_{21};C_{12}\ldots\ldots\right) $$ 

Noticed that generally  $ AB \neq BA $ (matrix product is not commutative)

(b) Ray Tracing

Purpose: Finding the trajectory of light rays propagating through space.

We already know the basics of light propagation:

1) It travels rectilinearly in the same homogeneous isotropic media.

2) It changes direction upon interface between two media.