<div style="text-align: center;"><img src="imgs/img_in_image_box_192_192_793_469.jpg" alt="Image" width="50%" /></div>


 $$ \overline{N_{1}N_{2}}=\overline{H_{1}H_{2}}=d $$ 

## 4 -11 Analytical Ray Tracing and Matrix Method

As we have demonstrated earlier, two spherical surfaces  $ \rightarrow $ lens (Thin or Thick). Multiple lenses combination is equivalent to a single thick lens. As the number of refraction surfaces (or optical elements) increases, the analysis either by graphical method or algebra to get the equivalent lens, or work surfaces (or element) one by one becomes complicated and tedious.

Here we discuss a new approach to the problem, still under paraxial approximation for simplicity.

(a) Introduction of Matrix

 $$ \left\{\begin{aligned}x_{1}&=a_{11}y_{1}+a_{12}y_{2}\\ x_{2}&=a_{21}y_{1}+a_{22}y_{2}\end{aligned}\right. $$ 