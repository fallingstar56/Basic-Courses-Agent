“Optical Ray” etc.

## ⑤ Thin Lens Matrix

Knowing the matrix representation  $ A_{21} $ (4-31) for thick lens, it is a simple matter to get the representation in thin lens case, where  $ \Gamma_{21} $ is 1, unit matrix  $ \begin{bmatrix} 1 & 0 \\ 0 & 1 \end{bmatrix} $, and d = 0

Then for thin lens  $ A_{21}=R_{2}R_{1}=\begin{bmatrix}1&-D_{1}-D_{2}\\ 0&1\end{bmatrix} $ (4-35)

And  $ \frac{1}{f}=D_{1}+D_{2} $, the same as lens-maker formula derived earlier.

For the thin lens combination:

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_854_653_1002.jpg" alt="Image" width="33%" /></div>


 $$ \boldsymbol{A}=\begin{bmatrix}{{{1}}}&{{{-D_{2}}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{d}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{-D_{1}}}} \\{{{0}}}&{{{1}}}\end{bmatrix}=\begin{bmatrix}{{{1-\frac{d}{f_{2}}}}}&{{{-\frac{1}{f_{1}}-\frac{1}{f_{2}}+\frac{d}{f_{1}f_{2}}}}} \\{{{d}}}&{{{\frac{-d}{f_{1}}+1}}}\end{bmatrix} $$ 

 $$ D_{1}=f_{1}^{-1}\quad D_{2}=f_{2}^{-1} $$ 

 $$ \frac{1}{f}=-a_{12}=\frac{1}{f_{1}}+\frac{1}{f_{2}}-\frac{d}{f_{1}f_{2}} $$ 

Same as (4-23) of the Note

 $$ \overline{O_{1}H_{1}}=\frac{fd}{f_{2}}=\frac{n_{i}(1-a_{11})}{-a_{12}} $$ 