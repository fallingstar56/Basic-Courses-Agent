<div style="text-align: center;"><img src="imgs/img_in_image_box_221_178_748_399.jpg" alt="Image" width="44%" /></div>


<div style="text-align: center;">You need to work for the negative lens (concave) for yourself.</div>


c) Thick lens

<div style="text-align: center;"><img src="imgs/img_in_image_box_197_612_813_864.jpg" alt="Image" width="51%" /></div>


Here we used fact that the $H_{1}, H_{2}$ are a pair of object – Image conjugate plane, with transverse Magnification $\nu=1$. (See proof on pg.124 of the note)

It is also easy to see that if  $ f_o = f_i $ (Means  $ n_i = n_o $ for the thick lens) The Nodal points are simply the intersections of optical axis with the primary plane, the beam 3, 3' are parallel each other. If  $ n_i \neq n_o $ (or  $ f_o \neq f_i $), the Nodal points will not be on the primary planes: (see figure below)