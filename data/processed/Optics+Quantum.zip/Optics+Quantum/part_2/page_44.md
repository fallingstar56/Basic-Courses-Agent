This is better illustrated by examples:

<div style="text-align: center;"><img src="imgs/img_in_image_box_276_247_768_427.jpg" alt="Image" width="41%" /></div>


In the above optical system with 3 lenses and one iris, the iris (a small hole inserted to limit the size of light beam) is the aperture stop, i.e. the light passing though it will pass through other lens and thus the whole system. We cannot say this to other lens, i.e. the light passing  $ L_{1} $ may not pass the whole system, because it may be blocked by other lens or the iris.

Each aperture (in the figure above, the apertures are  $ L_{1} $,  $ L_{2} $,  $ L_{3} $ and iris) only admit certain amount of light by limiting the steric angle of the energy flow:

<div style="text-align: center;"><img src="imgs/img_in_image_box_255_1056_670_1258.jpg" alt="Image" width="34%" /></div>


The potion of energy flow through the aperture is proportional to the steric angle spanned by it:

 $$ E_{_{T}}/E_{_{0}}=\frac{\pi(R\sin\theta)^{2}}{4\pi R^{2}}\approx\frac{\theta^{2}}{4}=\frac{\Omega}{4\pi} $$ 