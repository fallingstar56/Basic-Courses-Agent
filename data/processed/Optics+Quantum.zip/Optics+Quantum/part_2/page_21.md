 $$ \frac{f_{i_{2}}f_{i_{1}}}{S_{i_{2}}}+\frac{f_{o_{2}}f_{o_{1}}}{S_{o_{1}}}=f_{o_{2}}+f_{i_{1}} $$ 

Focal point:

 $$ \begin{aligned}&S_{o}\rightarrow\infty,S_{i}\rightarrow f_{i}\rightarrow f_{i}=\frac{f_{i_{1}}f_{i_{2}}}{f_{o_{2}}+f_{i_{1}}}\\ &\\ &S_{o}\rightarrow f_{o},S_{i}\rightarrow\infty_{i}\rightarrow f_{o}=\frac{f_{o_{1}}f_{o_{2}}}{f_{o_{2}}+f_{i_{1}}}\\ &\\ &\frac{f_{o}}{S_{o}}+\frac{f_{i}}{S_{i}}=1\\ \end{aligned} $$ 

This is similar to that of a single spherical Interface, but with different expression for f.

 $$ f_{o}=\frac{n_{o}}{\frac{n_{L}-n_{o}}{r_{1}}+\frac{n_{i}-n_{L}}{r_{2}}} $$ 

 $$ \frac{f_{o}}{f_{i}}=\frac{n_{o}}{n_{i}} $$ 

when  $ n_{0}=n_{i}\approx1 $ :

 $$ f_{o}=f_{i}=\frac{1}{(n_{L}-1)(\frac{1}{r_{1}}-\frac{1}{r_{2}})} $$ 

In a non-air media (say immerse the lens into water), the formula becomes:

 $$ f_{o}=f_{i}=\frac{n}{(n_{L}-n)(\frac{1}{r_{1}}-\frac{1}{r_{2}})} $$ 