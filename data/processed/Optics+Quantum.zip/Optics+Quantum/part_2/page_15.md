 $$ y_{o}^{2},y_{i}^{2}<<S_{o}^{2},S_{i}^{2},r^{2} $$ 

The transverse magnification is:

<div style="text-align: center;"><img src="imgs/img_in_image_box_206_327_714_494.jpg" alt="Image" width="42%" /></div>


 $$ y_{o}=S_{o}\tan i\approx S_{o}i $$ 

 $$ y_{i}=-S_{i}\tan i^{\prime}\approx-S_{i}i^{\prime} $$ 

 $$ \therefore\frac{y_{i}}{y_{o}}=-\frac{S_{i}}{S_{o}}\frac{i^{\prime}}{i}=-\frac{S_{i}}{S_{o}}\frac{n_{o}}{n_{i}} $$ 

 $$ V\equiv\frac{y_{i}}{y_{o}}=-\frac{n_{o}S_{i}}{n_{i}S_{o}} $$ 

 $$ |\nu|>1\qquad\mathrm{m a g n i f i e d~I m a g e}\qquad|\nu|<1\qquad\mathrm{m i n i m i z e d~I m a g e} $$ 

 $$ \nu>0\quad\mathrm{E r e c t e d~I m a g e}\qquad\nu<0\quad\mathrm{I n v e r t e d~I m a g e} $$ 

The  $ S_o $,  $ S_i $ obeys relation of  $ \frac{f_o}{S_o} + \frac{f_i}{S_i} = 1 $ or  $ S_o $,  $ S_i $ can be determined geometrically.

Focal Plane of spherical Refracted Surface: It is simply a plane passing through the focal points and perpendicular to the optical axis under paraxial condition. The light ray out such plane is represented in the figures below for concave (diverging) and convex (converging) surfaces.