We shall see that knowing the basic parameters will allow us to determine the location of the cardinal points; then we can calculate the relation between object —— Image conjugates. This is the basic problem in thick lens image formation.

## (1) Definition of the Cardinal points

Focal points: same as spherical interfaces or thin lens  $ (S_o \to \infty, S_i \to f_i $,

 $ S_i \to \infty, S_o \to f_o $)

Principal plane and points (H1, H2): (Fig 6.1, 6.2, Hecht's)

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_729_554_931.jpg" alt="Image" width="27%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_602_761_1035_960.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;">The principal plane (the dotted curves in the figure, under paraxial condition, it is approximately a plane) is defined by collection of intersection points of rays (extended shown in dotted lines) from the focal point and its output. The principal points are the intersection of such planes with the optical axis (defined by the vertex of the two surfaces). The effective focal length in the thick lens case will be measured between the focal points and principal points (see below).</div>
