Both rays A and B are parallel with each other A//B

 $$ OO^{\prime}=PP^{\prime}=\frac{AB}{\tan i_{1}} $$ 

 $$ AB=AC-BC=d_{_{0}}\tan i_{_{i}}-d_{_{0}}\tan i_{_{2}} $$ 

If  $ i_{1} $ is very small (paraxial approximation)

 $$ AB\approx d_{0}(i_{1}-i_{2})=\frac{n^{\prime}-n}{n^{\prime}}d_{0}i_{1}\quad n i_{1}=n^{\prime}i_{2} $$ 

 $$ \therefore OO^{\prime}=\frac{n^{\prime}-n}{n^{\prime}}d_{0} $$ 

∴ O' moves to  $ \frac{n' - n}{n'}d_{0} $ closer to the eye.

(2) By image formation formula:

The two flat surfaces of the Slide are spherical surfaces with  $ R \to \infty $

For surface 1, object O from n (refraction index) toward side n'

through 1.

The distance between O and surface l is  $ S_{o} $

(>0 according to our convention)

 $$ \frac{n}{S_{_{o_{1}}}}+\frac{n^{\prime}}{S_{_{i_{1}}}}=0(\frac{n^{\prime}-n}{r\rightarrow\infty}) $$ 

 $$ \therefore S_{_{i_{1}}}=-\frac{n^{\prime}}{n}S_{_{o_{1}}} $$ 

 $ i_{1} $ is the image formed by O through surface 1.