A'B' in case (D) is a virtual image by  $ L_{1} $, the lights “forming” it are diverging.

If the objective points and image points have a 1 to 1 relation (i.e. each objective point corresponds to one and the only one image point), it means all the light from the object after passing through the optical element (lens here) will converge to its image point (for the real image case; or diverge to virtual image point). The corresponding objective and image points are called conjugate points.

In (C), (D):

 $$ A\xleftarrow{L_{1}}\rightarrow A^{\prime} $$ 

 $$ B\xleftarrow{L_{1}}\boldsymbol{B}^{\prime} $$ 

They are conjugate points by

## 4 -2 Fermat's Principle

→The OPL for all light rays between conjugate points are equal.

It is fairly easy to prove for real object and real image ease. The light rays connecting the object point O and image point I through the optical element have to be stationary. The OPL of these different rays cannot be