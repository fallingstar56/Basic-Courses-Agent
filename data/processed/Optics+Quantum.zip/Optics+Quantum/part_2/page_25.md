to a single thick lens.

# 4-9 Thick Lenses and Lens System

(Hecht's 6.1)

<div style="text-align: center;"><img src="imgs/img_in_image_box_208_525_654_784.jpg" alt="Image" width="37%" /></div>


Basic Parameters for a lens:

 $$ n_{L},\quad n_{L},\quad d_{l},\quad R_{2},\quad R_{1}, $$ 

(Radius)

(Thickness)

(index of Refraction)



## Cardinal Points for a lens:

(a) Thin lens: optical center,  $ f_{o}, f_{i} $

(b) Thick lens:

Principal points:  $ H_{1}, H_{2} $

Focal points:  $ f_{o}, f_{i} $

Nodal points:  $ N_{1}, N_{2} $