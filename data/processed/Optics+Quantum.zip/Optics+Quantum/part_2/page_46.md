and the lens 2 will form image with respect to Lens 1 only. In the earlier example, the iris and lens 3 has to form image with respect to the lens system by lens 1 and lens 2. Once such images (pupils) are determined, it is easy to find out the AS:

<div style="text-align: center;"><img src="imgs/img_in_image_box_254_414_911_686.jpg" alt="Image" width="55%" /></div>


<div style="text-align: center;"> $ L_{2}^{\prime}, A^{\prime} $ are the images of lens and iris A formed by lens 1. The corresponding conjugate of the limiting points are also shown in the figure, such as  $ D_{1}, D_{1}^{\prime} $, etc. Using the property of the object-image conjugate, i.e. the light from the objective point will pass through its image conjugate and vice versa. It is easy to draw the limiting rays for an on axis source S with the help of the pupils (image  $ L_{2}^{\prime}, A^{\prime} $ in this case); such rays are shown as colored arrows in the figure above. Now it is obvious that the blue one (corresponding the iris) span the smallest angle and thus limiting the energy flow, and iris is the aperture stop here.</div>


You can imagine cases where  $ L_{2} $ or even  $ L_{1} $ are the aperture stop for a different arrangement. The detailed determination always depends on the relative position, size, focal lengths and where the point source S is