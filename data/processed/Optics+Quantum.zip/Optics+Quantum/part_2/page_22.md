Whether a lens (with fixed  $ r_{1}, r_{2}, n_{L} $) is converging ( $ f > 0 $) or diverging ( $ f < 0 $) depends on the value of  $ n_{L} $ and  $ n_{media} $.

Summary of formula for the thin lens:

Gaussian Formula:  $ \frac{f_{o}}{S_{o}}+\frac{f_{i}}{S_{i}}=1 $

Newton Formula:

 $$ x_{o}x_{i}=f_{o}f_{i} $$ 

(Its proof can be done easily with geometric method)

 $$ S_{o}=x_{o}+f_{o} $$ 

 $$ S_{i}=x_{i}+f_{i} $$ 

Transverse Magnification:

 $$ \nu=-\frac{n_{o}S_{i}}{n_{i}S_{o}}=-\frac{f_{o}}{x_{o}}=-\frac{x_{i}}{f_{i}} $$ 

<div style="text-align: center;">Meanings associated with the signs of thin lens and spherical surfaces.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="2">Quantity</td><td colspan="2">Sign</td></tr><tr><td style='text-align: center; word-wrap: break-word;'></td><td colspan="2">+</td><td style='text-align: center; word-wrap: break-word;'>-</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_{o} $</td><td colspan="2">Real object</td><td style='text-align: center; word-wrap: break-word;'>Virtual</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ S_{i} $</td><td colspan="2">Real Image</td><td style='text-align: center; word-wrap: break-word;'>Virtual</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f</td><td colspan="2">Converging lens</td><td style='text-align: center; word-wrap: break-word;'>Diverging</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ y_{o} $</td><td colspan="2">Erect object</td><td style='text-align: center; word-wrap: break-word;'>Inverted</td></tr></table>