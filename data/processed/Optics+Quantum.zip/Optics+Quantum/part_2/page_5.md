maximum or minimum, have to be a constant. For virtual object or image, their OPL have to be counted as negative (try proving this as an exercise, hint: set up using extra lens to make virtual image as object again and forming real image with second lens), and the refractive index n in OPL=nl, has to be taken corresponding to the objective or image side respectively.

So if any interface can satisfy the constant OPL between points Q and  $ Q' $, they will be a pair of Object – Image conjugate with respect to that interface. Such interface can be derived by requiring:

(Hecht's 5.2.1, Zhao's 4.4)

<div style="text-align: center;"><img src="imgs/img_in_image_box_223_832_568_978.jpg" alt="Image" width="28%" /></div>


$$\left.\frac{\overline{QM}}{\overline{QM}}+\overline{MQ^{\prime}}=const\right\rangle\text{contour of point M for real or virtual image(object)}$$

The contour of M, satisfying the above equation is generally an aspheric curve (or surface, such as elliptical, hyperbolic...). These aspheric optical elements are more difficult to manufacture in great precision than spherical ones.

Since spherical optical elements are widely used and easier to make, we are going to study in detail of such optical lenses or mirrors, to see