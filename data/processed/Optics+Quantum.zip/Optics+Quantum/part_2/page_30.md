The sign for  $ \overline{H_{11}H_{1}} $,  $ \overline{H_{22}H_{2}} $ are: + if to the right of  $ H_{11} $,  $ H_{22} $ respectively.

Noticed that the definition for sign of $H_{1}$ is different from Zhao's Book, that is why there is a sign change for $\overline{H_{11}H_{1}}$ between the two books.

The object – Image Relation for the combined lens system is equivalent to the single lens system whose cardinal points are given by (4-23), (4-24)

However in real computation, the strategy is still working one lens at a time, applying the image of the first lens as object to the second lens and so on.

Example: (Zhao's Book P80)

<div style="text-align: center;"><img src="imgs/img_in_image_box_247_987_860_1194.jpg" alt="Image" width="51%" /></div>


 $$ f=\frac{1}{f_{1}}+\frac{1}{f_{2}}-\frac{d}{f_{1}f_{2}}=\frac{3}{2}a $$ 

 $$ to the right of O_{1} $$ 

 $$ \overline{H_{22}H_{2}}=\overline{O_{2}H_{2}}=\frac{-fd}{f_{1}}=-a\qquad\text{to the left of}\ O_{2} $$ 