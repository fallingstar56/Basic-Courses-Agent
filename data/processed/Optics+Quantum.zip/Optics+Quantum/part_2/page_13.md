 $$ \frac{n_{_{i}}}{S_{_{i}}}+\frac{n_{_{o}}}{S_{_{o}}}=\frac{n_{_{i}}-n_{_{o}}}{r} $$ 

 $$ \mathrm{Or}\frac{f_{o}}{S_{o}}+\frac{f_{i}}{S_{i}}=1 $$ 

Where  $ f_{o}=\frac{n_{o}r}{n_{i}-n_{o}}\quad f_{i}=\frac{n_{i}r}{n_{i}-n_{o}} $

* Important Note:

a) The definition of +,- sign for  $ s_{o}, s_{i}, f_{i}, f_{o}, r $ (the sign convention)

b) Their correspondence to the real, virtual object (or Image, focal point);

c) And their location with respect to the spherical surface.

<div style="text-align: center;"><img src="imgs/img_in_image_box_237_783_508_972.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_194_983_556_1223.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_617_817_984_1253.jpg" alt="Image" width="30%" /></div>


The above conclusion is easily verified by Snell's law (on diverging or converging behavior of light) and the formula of  $ f_{o}, f_{i} $ given earlier.

The real object (image)  $ \leftrightarrow+(S_{o},S_{i}) $

Virtual object (image)  $ \leftrightarrow-(S_{o},S_{i}) $