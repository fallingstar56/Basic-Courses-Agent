<div style="text-align: center;"><img src="imgs/img_in_image_box_179_182_989_466.jpg" alt="Image" width="68%" /></div>


Basic problem: Knowing the cardinal points of individual lens and their configurations (the order and the separation etc.), calculate the equivalent cardinal points of the whole system $f,H_{1},H_{2}$ (or $\overline{H_{11}H_{1}}$, $\overline{H_{22}H_{2}}$):

 $$ M_{_{T}}=(\frac{-S_{_{i_{1}}}}{S_{_{o_{1}}}})(\frac{-S_{_{i_{2}}}}{S_{_{o_{2}}}})=-\frac{S_{_{i}}}{S_{_{o}}} $$ 

 $$ F o r S_{o_{1}},S_{i_{1}},S_{i_{2}},S_{o_{2}}:\frac{1}{S_{o_{n}}}+\frac{1}{S_{i_{n}}}=\frac{1}{f_{n}} $$ 

 $$ S_{o_{2}}=d_{12}-S_{i} $$ 

 $$ As\quad S_{o_{1}}\rightarrow\infty,S_{o}\rightarrow S_{o_{1}};S_{i_{1}}\rightarrow f_{1},S_{i}\rightarrow S_{i_{2}}\rightarrow f $$ 

 $$ S_{o_{2}}=d_{12}-S_{i_{1}}=d_{12}-f_{1} $$ 

 $$ \begin{aligned}&\therefore-f=\frac{f_{1}S_{i_{2}}}{S_{o_{2}}}=\frac{f_{1}}{S_{o_{2}}}(\frac{S_{o_{2}}f_{2}}{S_{o_{2}}-f_{2}})\\ &\\&=\frac{f_{1}f_{2}}{S_{o_{2}}-f_{2}}=\frac{f_{1}f_{2}}{d_{12}-f_{1}-f_{2}}\\ \end{aligned} $$ 

 $$ \overline{H_{11}H_{1}}=\frac{fd}{f_{2}}\quad\overline{H_{22}H_{2}}=\frac{-fd}{f_{1}} $$ 