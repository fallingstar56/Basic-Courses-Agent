objective, image planes are objective (image) focal plane. The points on the objective focal plane will form image at  $ \infty $ (or the light form this point source will be collimated after the interface, with its direction determined by the line connecting the point and the center of sphere).

The optical center, defined as the rays passing it will not change direction at the interface. For spherical surface, it is clearly the center of sphere.

## 4 -6 Multiple Surfaces and Lagrange - Helmholtz Relation

(Zhao’s Book, 5.4 p53)

We have worked an example of image formation by two surfaces. For the case of multiple surfaces separated with some distance, the general way is:

① treat each surface from left to right in turn (Assume light is from the left);

② use sign convention as we defined earlier;

③clarify which is object and with is image, usually the image of the previous surface will behave as object for the next surface;

④ identify the refraction index n for object and image.

Fig5-4. with the sign convention, easy to see: