collected by the lens and the its field of view is only limited by the paraxial requirement and slow decrease of steric angle spanned by the lens as the point moves further away from axis thus the decrease of energy collected.

For the multiple lens system, the limitation of field of view can arise from an extra factor, so called field stop. This is better illustrated by an example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_293_611_871_985.jpg" alt="Image" width="48%" /></div>


<div style="text-align: center;">In the example of two-lens setup, the second lens AB is the aperture stop and its entrance pupil is the image by lens 1 A'B' as shown in the figure. For the off axis point O' and O", we shall focus on their chief ray, the chief ray is defined as lines connect the off axis points and the center of the entrance pupil (the colored lines in the figure). This chief ray is approximately the direction of energy of input light to the system, it passes through the center of entrance pupil and it may pass through the exit pupil to have an output. If it passes the exit pupil, then</div>
