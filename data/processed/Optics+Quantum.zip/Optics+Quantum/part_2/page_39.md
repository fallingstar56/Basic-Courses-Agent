surface, propagate inside the lens (transfer from surface 1 to surface 2), then refracted again by the back surface. The whole process (the output ray) can be represented by:

 $$ \tau_{_{t_{2}}}=R_{2}\Gamma_{_{21}}R_{_{1}}\tau_{_{i}} $$ 

The process is reading backward on the right hand side above. Then matrix representing the lens would be.

 $$ A_{21}=R_{2}\Gamma_{21}R_{1} $$ 

Put (4-28), (4-29) into it:

 $$ \begin{aligned}&A_{21}=\begin{bmatrix}{{{a_{11}}}}&{{{a_{12}}}} \\{{{a_{21}}}}&{{{a_{22}}}}\end{bmatrix}=\begin{bmatrix}{{{1}}}&{{{-D_{2}}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{0}}} \\{{{\frac{d_{21}}{n_{t_{1}}}}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{-D_{1}}}} \\{{{0}}}&{{{1}}}\end{bmatrix}\\ &=\begin{bmatrix}{{{1-\frac{D_{2}d_{21}}{n_{t_{1}}}}}}&{{{-D_{1}-D_{2}+\frac{D_{2}D_{1}d_{21}}{n_{t_{1}}}}}} \\{{{\frac{d_{21}}{n_{t_{1}}}}}}&{{{1-\frac{D_{1}d_{21}}{n_{t_{1}}}}}}\end{bmatrix}&(4-31\\ \end{aligned} $$ 

The matrix $A_{21}$ for a lens is fixed(and so will be the light rays passing through it) once we know all the basic parameters $(R_{1}, R_{2}, d_{21}, n_{i}, n_{0}, n_{i})$ and from the matrix elements, we should be able to derive the location of the cardinal points.

Here I give a proof of (4-20), (4-21) earlier in this note, give out focal point; and primary plane's position, using the figure below. The initial ray is a light parallel with the optical axis and it will pass the focal point on image side. Using the definition of focal point and principal point, we can