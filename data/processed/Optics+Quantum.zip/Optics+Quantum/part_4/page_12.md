If  $ I_{1}=I_{2} $, then the  $ \gamma $ of interference pattern shows:

 $ \left\{\begin{array}{ll}\gamma=1 & \text{complete\_coherent\_source} \\ 0<\gamma<1 & \text{partial\_coherent} \\ \gamma=0 & \text{incoherent}\end{array}\right. $

5-6-1 Extended Monochromatic Source and Spatial Coherence

<div style="text-align: center;"><img src="imgs/img_in_image_box_178_505_547_908.jpg" alt="Image" width="31%" /></div>


 $ \Delta x_{a,b}(spacing\ bet\ max\ in\ pattern\ a\ or\ b)=\frac{D}{d}\lambda $

 $$ I_{_{a}}=I_{_{0}}(1+\cos2\pi f x) $$ 

where  $ f = \frac{1}{\Delta x} $

 $ I_{0}=I_{1}+I_{2} $

intensity on screen by s1,s2

For the off-axis source  $ O_{b} $, if s is small, the interference pattern originating from it would be similar to that of  $ O_{a} $, with same cosine variation, but different center, or basically a shifted fringe, with same spatial frequency(refer to the figure above):

 $$ I_{b}=I_{0}\Big[1+\cos2\pi f(X-X_{0})\Big] $$ 

For Ob, X0 (the position of 0th order maximum, marked by B in the figure)