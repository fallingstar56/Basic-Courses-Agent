Thus, for  $ \Delta L_{12} $ (The OPL difference between two points from the source)

<div style="text-align: center;"><img src="imgs/img_in_image_box_193_210_358_322.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_394_232_607_322.jpg" alt="Image" width="17%" /></div>


If  $ \Delta L_{12} > L_{0} $, the wave trains through path 1 and 2 to reach point P will be likely from different wave trains with random phase relation(average speaking) and thus 1 and 2 are not coherent

 $$ \triangle L_{12}=(r_{1}+R_{1})-(r_{2}+R_{2})>L_{0} $$ 

There will be no interference at P, or 1,2 are incoherent for point P.

Clearly this  $ L_0 = c\tau_0 $ should relate to the maximum OPL difference  $ \Delta L_m = \lambda^2 / \Delta \lambda $ we derived in (5-47).

For a wave train with duration  $ \tau $, it is not a single frequency wave. As we discussed at very beginning of this course and in superposition of waves with different frequencies, the wave train is a result of superposition of many harmonic waves with certain frequency distribution.

 $ f(t) $: wave train



<div style="text-align: center;"><img src="imgs/img_in_image_box_180_1102_397_1171.jpg" alt="Image" width="18%" /></div>


 $$ f(t)\propto\int_{-\infty}^{+\infty}g(\omega)e^{-i\omega t}d\omega $$ 

 $ g(\omega) $: frequency distribution

This is not strange to us by now, since in our earlier discussion on the wave packet, we have demonstrated that a square frequency distribution