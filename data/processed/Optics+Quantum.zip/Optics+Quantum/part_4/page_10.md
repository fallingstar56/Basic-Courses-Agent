length bandwidth:

 $$ \delta\lambda=\frac{\lambda}{m\phi} $$ 

The resolving power is defined as:

 $$ R\equiv\frac{\lambda}{\delta\lambda}=m\wp $$ 

## 5 -6 Coherent Theory

(Hecht, Chap 12 Zhao’s chap3 §1 §4 pg272-281; pg315-328)

We have discussed the “ideal” case for various interference devices.

The “ideal” is referring to:

(1) Point Source

(2) Monochromatic light (Single frequency)

Such conditions as we already mentioned and shall further discuss, lead to complete coherence.

Now we are starting to investigate the more realistic situations, involving

① Extended source → Spatial coherence

② Non-monochromatic light → Temporal coherence

For a conventional extended sources (“conventional” is in contrast to coherent sources as laser)