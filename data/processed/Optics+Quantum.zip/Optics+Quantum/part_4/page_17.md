For  $ \Delta L > \Delta L_m, \gamma \to 0 $ then there will be no interference. This  $ \Delta L_m $ is clearly caused by the non-monochromatic source.

## Coherent time and Coherent length:

To understand the  $ \Delta L_{m} $, (or equivalently the non-zero width in  $ \omega $ or v distribution), we have to look into the microscopic point of view of light emitting by the conventional source.

In short, we can state that the non-zero frequency bandwidth  $ \Delta\omega $ is caused by the limited lifetime of the excited states in atones/molecules. For a conventional light source, the excited atoms/molecules emit light when it transits from an excited state to the ground state. However, the excited state has limited lifetime  $ \tau $. This is the time that the electrons in molecules exist at the excited state, the classical picture is the time that a dipole stays excited and doing oscillation. For the excited dipoles lasting for a lifetime instead of forever, the light emitted will be in forms of wave train (or wave packet) with duration of  $ \tau $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_230_1212_567_1513.jpg" alt="Image" width="28%" /></div>
