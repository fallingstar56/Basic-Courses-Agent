 $$ \delta=4\pi n h/\lambda\qquad d\delta=-\frac{4\pi n h}{\lambda^{2}}d\lambda_{m} $$ 

 $$  At FWHM,\ d\delta=\varepsilon=\frac{4}{\sqrt{F}}\rightarrow d\lambda_{m}=\frac{-\lambda^{2}\varepsilon}{4\pi nh}=\frac{-2\lambda^{2}}{\pi m\lambda\sqrt{F}}=\frac{-\lambda}{\wp m} $$ 

 $$ d\upsilon_{m}=-\frac{c}{\lambda^{2}}d\lambda_{m}=\frac{c}{\wp m\lambda} $$ 

I used  $ \upsilon = \frac{c}{\lambda} \rightarrow d\upsilon = -\frac{c}{\lambda^2} d\lambda $ to get frequency interval from wavelength interval.

 $$ \mathrm{Then}\frac{Free\_{S}pectral\_{R}ange}{FWHM}=\frac{(5-37)}{(5-38)}=\wp\quad(\mathrm{using}\ 2nh=m\lambda_{m}) $$ 

There is no surprise here, recall the definition of  $ \phi $ in phase space,

the above procedure is same but carried now in frequency domain.

## (3) F-P interferometer or spectrometer

In this case, the h is not fixed but scanning, i.e. changes in a range, moving forward backward periodically. This is achieved by mounting one of the mirrors on a piezo driven by some voltage.

<div style="text-align: center;"><img src="imgs/img_in_image_box_247_1123_976_1347.jpg" alt="Image" width="61%" /></div>


If the light from source S is monochromatic, then there are only for certain values of h that the light can pass the F-P and be detected.