6. Fabry-Perot Interferometer.

(1) The most important two parameters are:

h: thickness     R: reflectance     or  $ F=\frac{4R}{(1-R)^{2}} $ (and the Finesse defined below)

(2) Transmission Intensity and its FWHM

 $$ I_{t}=I_{0}/(1+F\sin^{2}\delta/2)\qquad\delta=2k n h\cos i $$ 

 $$  It\quad has\quad maximum\quad at:\quad2nh\cos i=m\lambda\quad\varepsilon(FWHM)=\frac{4}{\sqrt{F}} $$ 

 $$ \wp=\frac{2\pi}{\varepsilon}=\frac{\pi}{2}\sqrt{F} $$ 

(3) Etalon: (h is fixed)

Function as wavelength selector  $ \lambda_{m}=\frac{2nh}{m}(i=0) $ or  $ v_{m}=\frac{mc}{2nh} $

Free spectral Range:  $ \Delta v = \frac{c}{2nh} $  $ dv_{m} = \frac{c}{\varphi m\lambda} = \frac{c}{\varphi 2nh} = \frac{\Delta v}{\varphi} $

∴ h determines the wavelength; Finesse  $ \phi $ determines the FWHM

(4) Spectrometer: (h is scanning)

 $ 2nh = m\lambda $ h determines the order m for a  $ \lambda $.

 $$ \delta\lambda=\frac{\lambda}{m\wp}\quad(\delta\nu=\frac{c}{\wp m\lambda})\quad R=\frac{\lambda}{\delta\lambda}=m\wp $$ 

7. Coherence

(1) Spatial Coherence:

Caused by extended incoherent sources.  $ b\Delta\theta=\lambda $

(2) Coherent time and length.

Caused by the limited temporal duration of the wave train, or