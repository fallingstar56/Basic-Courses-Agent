O1 ● (1) Each point emits light incoherently i.e. no

O2 ● fixed phase relationship between light from

O3 ● O1,O2.....

(2) The light emitted by each point is not monochromatic, i.e. there is a frequency distribution.

Generally, such extended sources will lead to a decrease in the contrast in interference pattern. This gives rise to what we shall study: a Partial Coherence (a reduced coherence).

As we already learned from interference of two sources:

 $$ \begin{aligned}&I=I_{1}+I_{2}+2\sqrt{I_{1}I_{2}}\cos\delta=(I_{1}+I_{2})(1+\gamma\cos\delta)\\ &\gamma=\frac{I_{\max}-I_{\min}}{I_{\max}+I_{\min}}\\ \end{aligned} $$ 

As we mentioned before, that even for a complete coherent source,  $ \gamma $ depends on  $ I_{1} $ and  $ I_{2} $, it could be small if  $ I_{1} \ll I_{2} $

<div style="text-align: center;"><img src="imgs/img_in_image_box_186_960_496_1132.jpg" alt="Image" width="26%" /></div>


 $$ \left.\begin{array}{r l}{\gamma=1}&{{~I_{1}=I_{2}~}}\\ {\gamma\rightarrow0}&{{~I_{1}<<I_{2}~}}\end{array}\right\}{f o r\_{c}oherent\_{s}ources} $$ 

To avoid confusion, or to separate the reduction of  $ \gamma $ by intensity difference of the complete coherent sources, with the reduction of  $ \gamma $ due to partial coherent sources, we shall assume  $ I_{1}=I_{2} $ in our following discussion, so that the decrease of  $ \gamma $ from 1 will be completely caused by the lack of coherence of the sources.