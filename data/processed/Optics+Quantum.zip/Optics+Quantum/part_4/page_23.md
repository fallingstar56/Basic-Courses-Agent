 $$ \begin{aligned}&I(p)=<E_{p}\cdot E_{p}>=<(E_{1p}+E_{2p})\cdot(E_{1p}+E_{2p})^{*}>\\ &=<\left|E_{1}(t-t_{1})\right|^{2}+\left|E_{2}(t-t_{2})\right|^{2}+2\operatorname{Re}(E_{1}(t-t_{1})E_{2}(t-t_{2})^{*}>\\ &=<\left|E_{1}(t-t_{1})\right|^{2}>+<\left|E_{2}(t-t_{2})\right|^{2}>+<2\operatorname{Re}(E_{1}(t-t_{1})E_{2}(t-t_{2})^{*}>\\ &=I_{1}+I_{2}+2\operatorname{Re}<E_{1}(t^{\prime})E_{2}(t^{\prime}+\tau)^{*}>\\ &=I_{1}+I_{2}+2\operatorname{Re}<E_{1}(t)E_{2}(t+\tau)^{*}>\quad(5-52)\\ \end{aligned} $$ 

where  $ t' = t - t_{1} $;  $ \tau = t_{1} - t_{2} $

Define:

 $$ \tau_{_{12}}(\tau)=<E_{_{1}}(t)E_{_{2}}(t+\tau)^{*}>_{_{T}}=\frac{1}{T}\int_{_{0}}^{T}E_{_{1}}(t)E_{_{2}}(t+\tau)^{*}dt $$ 

This is the Correlation Function between sources that carries information on interference. Because the interference term from (5-52) is:  $ 2\operatorname{Re}\tau_{12}(\tau) $,  $ \tau_{12}(\tau) $ is defined as above.

Comment: I need the sources are statistically stationary for the above derivation, i.e. the time averaged value is independent of the starting time chosen by the observer, that is why I changed t' to t in the last relation of 5-52. The correlation function is a function of time delay  $ \tau $ only.

Auto correlation  $ \tau_{ii} $ is one special case of the definition (5-53), it is a measurement of coherent time of the single source.

 $$  Clearly\quad\tau_{11}(0)=I_{1},\tau_{22}(0)=I_{2} $$ 

Define Normalized correlation function:

 $$ \gamma_{12}(\tau)=\frac{\tau_{12}(\tau)}{\sqrt{\tau_{11}(0)\tau_{22}(0)}}=\frac{\tau_{12}(\tau)}{\sqrt{I_{1}I_{2}}} $$ 