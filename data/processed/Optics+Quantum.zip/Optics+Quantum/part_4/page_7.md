interference pattern would be like that of equal-inclination---concentric rings. Different freq. light corresponds to rings at different angles. Here we are considering the case that the incident angle is fixed, say i=0, normal incidence, and let the incoming light have a broad frequency distribution.

We shall see that the etalon acts as a freq. selector (filter), only certain frequencies can pass etalon.

<div style="text-align: center;"><img src="imgs/img_in_image_box_329_613_732_718.jpg" alt="Image" width="33%" /></div>


The transmitted peaks (i=0) occur at  $ \delta_{m}=2m\pi $

 $$ \mathrm{Or}\quad\lambda_{_{m}}=\frac{2nh}{m}\quad\mathrm{or}\quad\upsilon_{_{m}}=\frac{c}{\lambda_{_{m}}}=\frac{mc}{2nh} $$ 

So the output would be a group of equally spaced lines in frequency domain, with free spectral range defined as:

 $$ \Delta v=v_{_{m+1}}-v_{_{m}}=\frac{c}{2nh} $$ 

Which is the spacing between peaks corresponds to adjacent order of interference.

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_1245_737_1443.jpg" alt="Image" width="42%" /></div>


<div style="text-align: center;">Evaluate dv, the FWHM of line in v domain:</div>
