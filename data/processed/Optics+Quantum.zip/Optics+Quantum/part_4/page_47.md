For an arbitrary phase difference between the center of the aperture and the edge, represented by A on the vibrational curve, with phase difference by  $ \beta $; then  $ |U(P)|=|OA| $ and can be easily evaluated by treating (approximately) the spiral as a circle with radius  $ A_0 $ (As long as we can treat  $ f(\theta, \theta_0) $ as constant)

Example:  $ r - r_{0} = \frac{1}{3}\lambda $

What is |U(P)| for

<div style="text-align: center;"><img src="imgs/img_in_image_box_613_466_866_590.jpg" alt="Image" width="21%" /></div>


Fresnel diffraction?

<div style="text-align: center;"><img src="imgs/img_in_image_box_195_705_597_941.jpg" alt="Image" width="33%" /></div>


 $$ \Delta phase=k\Delta r=\frac{2\pi}{\lambda}\frac{1}{3}\lambda=\frac{2}{3}\pi $$ 

 $$ |U(p)|=A=2A_{0}\sin(\frac{1}{3}\pi) $$ 

6-3-3 Circular Obstacle

S

<div style="text-align: center;"><img src="imgs/img_in_image_box_395_1296_448_1401.jpg" alt="Image" width="4%" /></div>
