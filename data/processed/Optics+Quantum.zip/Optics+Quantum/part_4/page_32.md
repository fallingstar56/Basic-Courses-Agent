equivalently by the frequency distribution of the source.

Temporal duration and frequency distribution are related by Fourier Transform.

 $$ \mathrm{Coherent~time}\quad\tau_{0}\triangle v\doteq1\quad\mathrm{coherent~length}\quad L_{0}=C\tau_{0}/n=\frac{\lambda^{2}}{\left|\Delta\lambda\right|} $$ 

(3) Degree of coherence and Correlation function

 $$ \gamma=\frac{I_{\max}-I_{\min}}{I_{\max}+I_{\min}}=\frac{2\sqrt{I_{1}I_{2}}}{I_{1}+I_{2}}\left|\gamma_{12}(\tau)\right| $$ 

$$\gamma_{12}(\tau)=\frac{\tau_{12}(\tau)}{\sqrt{I_{1}I_{2}}}=\frac{<E_{1}(t)E_{2}^{*}(t+\tau)>}{\sqrt{I_{1}I_{2}}}\quad\mathrm{E1~E2~are~the~fields~at~the~sources.}$$

$$\left\{\begin{array}{ll}\gamma_{12}(\tau)=1 & \text{compelete\_coherent}\\ 0<\gamma_{12}(\tau)<1 & \text{partial\_coherent}\\ \gamma_{12}(\tau)=0 & \text{incoherent}\end{array}\right.$$

For normalized auto-correlation function:

 $$ \gamma_{_{ss}}\equiv\frac{<E_{_{s}}(t)E_{_{s}}^{*}(t+\tau)>}{I_{_{s}}},\quad I_{_{s}}=<|E_{_{s}}|^{2}> $$ 