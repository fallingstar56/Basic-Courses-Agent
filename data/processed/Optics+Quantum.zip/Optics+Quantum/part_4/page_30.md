amplitude) is independent of position of p; paraxial and Farfield condition:

 $ \phi_{j}(p) $ is in form of a plane wave.

## 4 Two beam Interference

Point source:  $ \delta = k\Delta L $  $ \Delta L $ is difference in OPL

 $ \Delta L = m\lambda $ bright fringe  $ \Delta L = (m + 1/2)\lambda $ dark fringe (Reversed if exist  $ \lambda/2 $ diff. in reflection)

This applies to Young’s Experiment, amplitude splitting devices, such as Equal thickness and Equal inclination fringes for thin film.

(1) Young’s Experiment:  $ \Delta L = \frac{dx'}{D} $ (And other wavefront splitting devices)

(2)Thin film:  $ \Delta L = 2nh\cos i $ (Amplitude splitting) Equal Thickness: I fixed usually i=0

(Thin film wedge; Newton Ring)  $ \Delta L = 2nh = m\lambda $  $ \Delta h = \lambda / 2n $

Equal Inclination: h is fixed

Rings  $ \Delta L = 2nh\cos i = m\lambda $

Be familiar with the change of fringe patterns with change of

parameters.

5. Michelson Interferometer.

(1) Realization of various interference patterns

(2) Precision measurement of physical quantities: distance, refraction index, wavelength .....