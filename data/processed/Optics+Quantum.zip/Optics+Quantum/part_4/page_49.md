<div style="text-align: center;"><img src="imgs/img_in_image_box_356_172_481_227.jpg" alt="Image" width="10%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_290_251_433_380.jpg" alt="Image" width="12%" /></div>


 $$ r-r_{0}=\Delta L $$ 

 $$ U(P)=\mid\overline{AO_{s}}\mid $$ 

The position of A is determined by  $ \Delta L $ which in turn is determined by the size of obstacle and position of P.

## 6 -3-4 Cabinet Principle

This is a more general result in diffraction and not limited to the Fresnel diffraction, it is originated from HFP.

From HFP:  $ U_{\Sigma_0}(P) = C \iint_{\Sigma_0} U_0(Q) e^{ikr} / r dr \Sigma $

Let  $ \Sigma_{0}=\Sigma_{a}+\Sigma_{b} $

Then:  $ U_{\Sigma_{a}}(P)+U_{\Sigma_{b}}(P)=U_{\Sigma_{0}}(P) $

 $ \Sigma_{a}, \Sigma_{b}, \Sigma_{0} $ are transparent parts of screen to add up, for example:

 $$ \begin{array}{r c l}{{}}&{{}}&{{}}\\ \hline{{}}&{{}}&{{}}\\ \hline{{}}&{{}}&{{}}\\ \hline{{}}&{{}}&{{}}\end{array}+\begin{array}{r c l}{{}}&{{}}&{{}}\\ {{}}&{{}}&{{}}\\ {{}}&{{}}&{{}}\end{array}=\text{open space} $$ 

For the illustration above, where  $ \Sigma_{0} $ is free space, then  $ \Sigma_{a} $,  $ \Sigma_{b} $ are said to be “complementary” to each other, this means the transparent region on one exactly matches the opaque region on the other and vice