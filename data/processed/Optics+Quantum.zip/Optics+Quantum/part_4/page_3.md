 $$ \tilde{U}_{_{T}}=\sum_{i}U_{_{i^{\prime}}}=A t t^{\prime}(1+r^{2}e^{i\delta}+r^{4}e^{2i\delta}\cdots\cdots)=\frac{A t t^{\prime}}{1-r^{2}e^{i\delta}} $$ 

 $$ I_{_{T}}=\tilde{U}_{_{T}}U_{_{T}}^{*}=\frac{A^{2}(t t^{\prime})^{2}}{(1-r^{2}e^{i\delta})(1-r^{2}e^{-i\delta})}=\frac{I_{_{0}}(1-r^{2})^{2}}{1+r^{4}-2r^{2}\cos\delta}=I_{_{0}}\left[\frac{1}{1+\frac{4R\sin^{2}\delta/2}{(1-R)^{2}}}\right] $$ 

 $$ R\equiv r^{2} $$ 

Define coefficient of Finesse:  $  F \equiv \frac{4R}{(1 - R)^2}  $ (5-31)

 $$ I_{_{T}}=I_{_{0}}\left/\left(1+F\sin^{2}\delta\right.\right/2) $$ 

 $$ I_{_{R}}=I_{_{0}}-I_{_{T}}=I_{_{0}}\left/\left(1+\frac{1}{F\sin^{2}\frac{\delta_{_{2}}}{}}\right)\right. $$ 

As R<<1, F≈4R and  $ I_{T}=I_{0}\left[1-2R(1-\cos\delta)\right] $,  $ I_{R}=2I_{0}R(1-\cos\delta) $,

exactly the intensity distribution for a double beam Interference

 $ (I=I_{0}(1+\gamma\cos\delta)) $ which is a limiting case.

From（5-30） and (5-32), it is easy to see that:

For $I_T$, it's maximum at $\sin\delta/2=0$, or $\delta=2m\pi$, or $\Delta L=2n h\cos i=m\lambda_0$. This is when all the transmitted waves are exactly in phase, and constructively superposed together.

For the  $ I_R $, the same condition  $ \sin \delta/2 = 0 \rightarrow I_R = 0 $ This is when all the reflected waves are all in phase, except  $ \text{ONE---} $ the first reflected beam. (This arises from the half-wavelength difference between reflected beam by top and bottom surface, as expressed by stokes relation  $ r = -r' $ also refers to Fig9.38, Hecht). The reflected beam is out of phase with