 $$ \begin{aligned}&\tilde{U}_{_{j}}(P)=\frac{2C_{_{j}}}{ik}e^{ikb}(-1)^{^{j}}\quad(6-7)\\ &=A_{_{j}}(-1)^{^{j}}\\ &\tilde{U}(P)=\sum_{j=1}^{N}\tilde{U}_{_{j}}(P)=\sum_{j=1}^{N}(-1)^{^{j}}A_{_{j}}\\ \end{aligned} $$ 

The neighboring  $ \lambda/2 $ cancels each other in the contribution to field point P.

Absolute Amplitude of P Contribution of  $ 1^{st} $,  $ 2^{nd} $ ...  $ \lambda/2 $-plate.

 $$ \begin{aligned}|U(P)|=&\frac{\left|A_{1}\right|}{2}+(\frac{\left|A_{1}\right|}{2}-\left|A_{2}\right|+\frac{\left|A_{3}\right|}{2})+(\frac{\left|A_{3}\right|}{2}-\left|A_{4}\right|+\frac{\left|A_{5}\right|}{2})+\frac{\left|A_{5}\right|}{2}\ldots\pm\frac{\left|A_{m}\right|}{2}\\ \approx&\frac{\left|A_{1}\right|}{2}\pm\frac{\left|A_{m}\right|}{2}\quad(6-9)\end{aligned} $$ 

The terms enclosed in the bracket ( ) is close to zero due to the cancellation between adjacent zones. The signs in the final expression are + if m is an odd number, - if m is even.

The expression of  $ |A_{j}| $ can be seen from (6-6), (6-7)

 $$ A_{j}=\frac{2\lambda}{i}Kf(\theta,\theta_{0})\frac{A_{0}e^{ik(R+b)}}{R+b} $$ 

It is depending on $f(\theta,\theta_0)$, the rest can be treated as constant for the current setup. For the adjacent $\lambda/2$ plate, $f(\theta,\theta_0)$ is almost a constant (the change of $\theta$ is negligible), $f(\theta,\theta_0)$ slowly decreases as the order of $\lambda/2$-plate increases. $f(\theta,\theta_0) \searrow$ as $j \nearrow$. It reaches 0 as $j$ approaches the other pole of the spherical surface.

Based on the above arguments, we conclude:

(1) In the case of free propagation (Aperture is infinitely large), (6-8)