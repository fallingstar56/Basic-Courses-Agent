 $$ \tau_{_{S S}}=<E_{_{S}}(t)E_{_{S}}^{*}(t+\tau)> $$ 

We consider auto correlation function of S since only one source here.

$$E(t)=E_{0}e^{-i\omega t}e^{i\varphi_{0}(t)}\quad\text{and}\quad\varphi_{0}(t)\quad\text{is the initial phase. If the source is the ideal monochromatic, the light wave will be simple harmonic and the calculation is simple (try this yourself). Here let's work out a realistic case where the source emit light in wave trains, for each wave train its initial phase }\varphi_{0}\quad\text{takes certain value, random for different wave-trains.}$$

The point source S has the characteristic of emitting light as we discussed earlier; i.e. it emits a series of wave-trains with distribution in temporal duration, the average time is  $ \tau_{0} $, the temporal distribution  $ \tau' $ is given by (5-48):  $ \rho(\tau') = \frac{1}{\tau_{0}} e^{-\frac{\tau'}{\tau_{0}}} $,  $ \tau_{0} $ is the average of  $ \tau' $ s.

 $$ \begin{array}{l}\leftrightarrow\sim\sim\sim\sim\sim\sim\\\leftarrow\tau_{1}^{^{\prime}}\rightarrow\leftarrow\tau_{2}^{^{\prime}}\rightarrow\leftarrow\sim\sim\sim\sim\sim\\\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\rightarrow\end{array} $$ 

 $$ \begin{aligned}&\gamma_{12}(\tau)=\gamma_{ss}(\tau)=\frac{<E_{s}(t)E_{s}^{*}(t+\tau)>}{\left|E_{s}\right|^{2}}\\ &=<e^{i\omega\tau}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>\\ &=e^{i\omega\tau}<e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>\\ \end{aligned} $$ 

e iωτ is interference due to variation in OPL (equivalent to kΔL)

Let’s focus on evaluation of  $ <e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}> $, assume we have N wave-trains, total time would be  $ T=\sum_{i=1}^{N}\tau_{i}^{\prime}\approx N\tau_{0} $, then: