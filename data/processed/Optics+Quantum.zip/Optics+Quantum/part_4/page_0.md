Then  $ \Delta d = N \left( \frac{\lambda_{0}}{2} \right) $ (5-28)

 $ \Delta d $ is the optical path length difference. It can be either real change of the mirror's position, or it can be variation of index of refraction. Thus, the Michelson-Interferometer offers an accurate method to measure the n, index of refraction of some transparent materials, and it can be used in other related ways, such as monitoring the gas density by the change of n.

Example: Wavelength meters ---determination of the wavelength. A commercial wave meter, such as those made by Burleigh Inc. is essentially a Michelson-Interferometer.

 $$ \begin{array}{r l}{\mathrm{A s}}&{{}\Delta d=N(\frac{\lambda_{0}}{2})}\end{array} $$ 

It seems if we change  $ \Delta d $ by a precise amount and count N correctly, we shall be able to get  $ \lambda_{0} $. However, the very precise control of  $ \Delta d $ is not easy (Though now days, step-motor with nm precision becomes available but very expensive).

The measurement of  $ \lambda_{0} $ by a wavelength meter is achieved with the help of another stable light source, a He-Ne laser is stabilized at a fixed temperature, whose wavelength  $ \lambda^{r_{0}} $ is known. The light of reference He-Ne and unknown wavelength light are fed into a Michelson-Interferometer, each will generate an interference pattern of its own. Scan a mirror, say M, by  $ \Delta d $, there would be fringes