## Chapter 6 Diffraction

The topics will be covered in this chapter are:

1. What's Diffraction(Zhao's, chap2 §5.1 Hecht's 10.1)

2. Huygens Fresnel Principle (Kirchhoff equation) (Zhao’s chap2 §5.2, pg186; Hecht, 10.4)

3. Fresnel Diffraction (Zhao's chap2 §6, pg194-206; Hecht, 10.3.1-10.3.5)

4. Fraunhoffer Diffraction (Zhao's chap2 §7, pg209-230; Hecht, 10.2.1)

5. Grating (Zhao's chap4, Hecht's, 10.2.2-10.2.7)

## 6 -1 What's Diffraction

## 6 -1-1 Definition

In Young’s Experiment, we used points to represent the two coherent sources. However in any reality, the sources themselves (aperture or slit in the experiments) have limited sizes, then an instant question is: what is the field distribution after such opening :

<div style="text-align: center;"><img src="imgs/img_in_image_box_238_1311_942_1443.jpg" alt="Image" width="59%" /></div>


From geometric optics, if p is in the region spanned by angle d/R, then its