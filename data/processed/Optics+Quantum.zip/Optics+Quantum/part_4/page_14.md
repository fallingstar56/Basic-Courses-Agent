<div style="text-align: center;"><img src="imgs/img_in_chart_box_188_151_562_374.jpg" alt="Image" width="31%" /></div>


The function of  $ \gamma $ is not strange to us. We have come across to similar functions dealing with wave packet, group velocity, where superposition of waves with a frequency distribution→wave packet. The math in both cases are same, essentially a Fourier Transform of square function. Clearly, as

 $$ \mu=\frac{\pi b d}{R\lambda}=\pi{~o r~}b=\frac{R\lambda}{d}\qquad(5-45)\qquad then\gamma=0 $$ 

Though as  $ \mu > \pi, \gamma $ is non-zero (there is still some up-downs beyond  $ \pi $) but will be negligible. Then if the source length  $ b > \frac{R\lambda}{d} $. the contrast of the interference pattern  $ \gamma \to 0 $, i.e. the secondary wave sources  $ S_1, S_2 $ will be incoherent.

Relation (5-45) can be rearranged to:  $ d = \frac{R}{b} \lambda $ (5-46)

This is for a fixed extended source b, at distance R from it, if the two secondary sources are separated by  $ d > \frac{R}{b}\lambda $, they are incoherent (i.e. you cannot put double slit there and expect to see interference):