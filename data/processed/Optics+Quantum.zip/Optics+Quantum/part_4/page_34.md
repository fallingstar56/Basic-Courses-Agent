 $  \text{Ip}^\infty | \text{Ep}|^2 = |\text{Es}/(\text{R} + \text{r})|^2  $. If  $  p  $ is outside the angle  $  d/R  $, then  $  \text{Ip} = 0  $. Is this true?

This is not always true as clearly demonstrated in the experiment shown in Figure below:

<div style="text-align: center;"><img src="imgs/img_in_image_box_215_348_985_668.jpg" alt="Image" width="64%" /></div>


From the experimental observation, it is easy to conclude that

(1) The distribution of energy on an observing plane I(p) is generally an interference pattern. The energy distribution has highs and lows.

(2) Light does not propagate in a rectilinear form, its distribution "spread out" along the direction wherever it meets restriction.

(3) The more restriction, the light seems spread out more.

This gives the definition of diffraction.

Diffraction (literally or phenomenally): Deviation of light from a rectilinear propagation

Diffraction $ ^{7} $ (physical): interference of waves.(a continuous coherence sources)