of $g(\omega)$, the superposition gives rise to a wave packet in forms of $\frac{\sin \mu}{\mu}$ (or $\sin c(\mu)$), with a spread of $\Delta T'$ and $\Delta t \Delta \omega = 2\pi$ or $\Delta t \Delta \upsilon = 1$.

(In the previous discussion $T'=\frac{x}{v_{g}}-t$, for fixed space coordinate: $\Delta T'=\Delta t=\tau$ for a wave train)

Thus  $ \tau\Delta\upsilon=1 $ (5-50)

Comment: In the previous discussion of superposition waves with different frequencies, is a square function $g(\omega)$, $f(t)$ is in form of $\frac{\sin \mu}{\mu}$; here the $f(t)$ is inform of square function, then $g(\omega)$ would be in forms of $\frac{\sin \mu}{\mu}$. So $\Delta T_{\Delta U} \approx 1$ still holds. Generally the exact form of $f(t)$ will depend on $g(\omega)$, and vice versa, but relation (5-50) generally holds for the uncertainties in the conjugate variables for which we shall see it is a general property of Fourier Transform.

For a wave train with average duration  $ \tau_{0} $ as emitted by atoms/molecules:

 $$ \tau_{0}\triangle v=1 $$ 

 $$ \triangle v=-\frac{\triangle\lambda}{\lambda^{2}}C $$ 

 $$ \tau_{_{0}}=\frac{\lambda^{2}}{\left|\triangle\lambda\right|c} $$ 

 $$ \therefore\quad L_{0}=\frac{\lambda^{2}}{\left|\triangle\lambda\right|} $$ 

Compare with (5-47), $L_{0}$ the coherent length and $\Delta L_{m}$ maximal OPL difference are clearly the same. This helps us understanding that