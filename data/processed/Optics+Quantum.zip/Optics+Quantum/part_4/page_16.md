O is a point source with frequency distribution (for simplicity, it is a distribution with square function). For each frequency component, it has equal intensity, i.e.  $ i_{0}(k) = I_{0} / \Delta k $

 $ i_{0} $ is the intensity density (per unit wavelength interval or frequency interval),  $ I_{1} $,  $ I_{2} $ is the intensity by  $ S_{1} $,  $ S_{2} $ to a point on observing screen. The interference pattern on the observing screen caused by component with wave vector k is:

 $$ i_{k}(\Delta L)=(I_{1}+I_{2})(1+\cos k\Delta L) $$ 

The total intensity from all frequency (or wavelength) components will be a superposition of such i(k)s, since we neglect the coherence between sources with different frequency. The summation would be exactly same as we treated earlier in spatial coherence cases,

 $$ \begin{aligned}I(\triangle L)&=\int_{0}^{\infty}i(k)dk\\&=\int_{k_{0}-\frac{\triangle k}{2}}^{k_{0}+\frac{\triangle k}{2}}I_{\frac{0}{\triangle k}}(1+\cos k\triangle L)dk\\&=I_{0}[1+\frac{\sin\frac{\triangle k\triangle l}{2}}{\frac{\triangle k\triangle l}{2}}\cos(k\triangle L)]\end{aligned} $$ 

 $$ \gamma=\left|\frac{\sin\mu}{\mu}\right|\qquad\qquad\mu=\frac{\triangle k\triangle L}{2} $$ 

 $$ \begin{aligned}&\gamma=0\quad when\quad\frac{\triangle k\triangle L}{2}=\pi\\&\Delta L_{m}=\frac{2\pi}{\Delta k}=\frac{1}{\Delta(\frac{1}{\lambda})}=\frac{\lambda^{2}}{\left|\Delta\lambda\right|}\\ \end{aligned} $$ 

 $ \Delta L_{m} $ is the maximum difference in OPL.