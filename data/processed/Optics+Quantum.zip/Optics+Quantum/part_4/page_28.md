The model leads to the  $ \gamma_{12}(t) $ in (5-56) here takes the distribution of time

 $ \tau' $ in a more realistic form of  $ \frac{1}{\tau_0}e^{-\frac{\tau'}{\tau_0}} $

<div style="text-align: center;"><img src="imgs/img_in_image_box_654_217_920_386.jpg" alt="Image" width="22%" /></div>


whose

frequency spectrum g(w)[which is the reverse Fourier Transform of

 $ \rho(\tau) $ ] is in a form of Lorentian:

 $$ g\left(w\right)\propto\frac{1}{\omega^{2}-\omega_{0}^{2}+a\omega} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_266_592_471_762.jpg" alt="Image" width="17%" /></div>
