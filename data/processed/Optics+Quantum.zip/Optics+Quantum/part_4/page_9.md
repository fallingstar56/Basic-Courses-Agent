<div style="text-align: center;"><img src="imgs/img_in_image_box_282_151_834_601.jpg" alt="Image" width="46%" /></div>


The FWHM of the output line can be derived:

 $$ d\delta=\frac{4\pi n}{\lambda}dh=\varepsilon=\frac{4}{\sqrt{F}}\quad d h=\frac{\lambda}{2n\wp} $$ 

Now, let's consider the light from source S has various frequency components. As the F-P scanning, different frequency components will pass F-P at different h.

<div style="text-align: center;"><img src="imgs/img_in_image_box_245_955_754_1287.jpg" alt="Image" width="42%" /></div>


 $$ h_{_{m}}=\frac{m\lambda}{2n},h_{_{m}}^{\prime}=\frac{m\lambda^{\prime}}{2n}\qquad\delta\lambda=\lambda^{\prime}-\lambda=\frac{2n\delta h_{_{m}}}{m} $$ 

The $\lambda,\lambda'$ can be resolved if the $\delta h$ caused by $\delta\lambda$ equals or larger ($\geq$) than the FWHM of the single line, this is the Rayleigh criteria.

Replace  $ dh_{m} $ for  $ \delta h_{m} $, We have the minimum resolvable wave