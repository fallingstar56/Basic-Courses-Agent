For the spherical surface, the obliquity factor is:

 $$ \cos\theta_{0}=1,f(\theta,\theta_{0})=\frac{1}{2}(1+\cos\theta)(6-5) $$ 

Next we evaluate the small area element (a belt shown by dashed lines in the figure)  $ d\Sigma $ :

 $$ =2\pi R^{2}\sin\alpha d\alpha $$ 

 $$ \because\cos\alpha=R^{2}+(R+b)^{2}-r^{2}/2R(R+b) $$ 

 $$ \sin\alpha d\alpha=\frac{r}{R(R+b)}dr $$ 

 $$ \therefore d\Sigma=\frac{2\pi Rr}{R+b}dr $$ 

Put all above into (6-3), it becomes:

 $$ \begin{aligned}d\tilde{U}_{_{j(P)}}=\tilde{U}_{_{j0}}Kf(\theta,\theta_{_{0}})\frac{2\pi R}{R+b}e^{ikr}dr\\=C_{_{j}}e^{ikr}dr\end{aligned} $$ 

 $$ \begin{aligned}&\tilde{U}_{j}(P)=\int_{r_{j-1}}^{r_{j}}dU_{j}(P)\\ &=C_{j}\int_{r_{j-1}}^{r_{j}}e^{ikr}dr\\ &=\frac{C_{j}}{ik}e^{ikr}\begin{vmatrix}r_{j}\\ r_{j-1}\end{vmatrix}\\ &r_{j}=b+\frac{j}{2}\lambda,j=1,2,\ldots\\ &e^{ikr}\begin{vmatrix}r_{j}\\ r_{j-1}\end{vmatrix}=e^{ikb}[(-1)^{j}-(-1)^{j-1}]\\ &=2e^{ikb}(-1)^{j}\\ \end{aligned} $$ 

(neglect $f(\theta,\theta_{0})$'s dependence on the $\lambda/2$-plate, treat it as a constant within the $\lambda/2$-plate)