(Here P is a point on-axis defined by S and center of  $ \Sigma $)

## 6 -3-1 Method of Half-Wavelength ( $ \lambda/2 $) Plate

Direct application of (6-2) on this problem for the general setup would result in a nasty integral, the r has to be expressed as function of x,y of the surface area. We shall use an approximation method to evaluate such integral and this is the method of half-wavelength plate. Divide the opening aperture into orbital zone. The OPL from the edge of each neighboring zones to the field point P differs by  $ \lambda/2 $.

 $ \tilde{U}(P)=\sum_{j=1}^{n}\tilde{U}_{j}(P) $ (Integral over area reduces to summation of zones)

 $ \tilde{U}_{j}(p) $ is the contribution to P by the jth  $ \lambda/2 $ plate (zone).

 $$ r_{j}=r_{j-1}+\frac{\lambda}{2} $$ 

To evaluate  $ \tilde{U}_{j}(P) $, we need to first evaluate  $ d(\tilde{U}_{j}(P)) $, the contribution to P by a very small zone on the jth  $ \lambda/2 $ plate.

According to the HFP and Kirchhoff equation:

 $$ d\tilde{U}_{j}(P)=K f(\theta,\theta_{0})\tilde{U}_{j0}\frac{e^{i k r}}{r}d\Sigma $$ 

First the field at the diffraction screen is:

 $$ \tilde{U}_{_{j0}}=\frac{A_{_{0}}}{R}e^{ikR} $$ 