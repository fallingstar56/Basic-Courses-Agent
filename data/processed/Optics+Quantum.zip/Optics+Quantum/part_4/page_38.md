pattern for the off axis points in Fresnel-diffraction case.

## 6 -2 Huygens-Fresnel Principle (HFP) and Kirchhoff equation

As we stated earlier that the HFP is basically the Huygens principle combined with superposition of the waves (The waves coming from the secondary wavelets).

It is Kirchhoff who derived a correct mathematical representation for the HFP, which we only give out as a result $ ^{8} $. For the more detailed derivation of the Kirchhoff theory, please refer to Hecht’s 10.4

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_774_1015_1233.jpg" alt="Image" width="65%" /></div>


 $$ U(p)=\oint\limits_{a r e a}^{o p e n}d U(p)=K\oint\limits_{(\Sigma_{0})}^{}\frac{e^{i k r}}{r}\tilde{U}_{0}(Q)d\Sigma $$ 