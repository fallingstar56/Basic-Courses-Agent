determines the number of beams taking part in interference, thus affecting the energy distribution in phase space; the h determines the condition of constructive interference, thus the peaks' position in the phase space.

(1) Full Width at Half Maxima (FWHW) in phase space

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_407_727_661.jpg" alt="Image" width="40%" /></div>


As derived in the Zhao’s Book, pg337 or Hecht’s 9.6.1, pg423:

 $$ \varepsilon=\frac{2(1-R)}{\sqrt{R}}=4\bigg/\sqrt{F} $$ 

Define finesse  $ \varphi $

 $$ \wp\equiv\frac{\Delta\delta}{\varepsilon}=\frac{2\pi}{\varepsilon}=\pi\sqrt{F}\Big/2 $$ 

φ is the ratio between spacing of peaks and the width of individual peak, it is closely related to the resolution of the instrument. The larger φ means narrower ε or large Δδ, the peaks are well resolved in phase space. However, these are in terms of δ, the phase, we need to translate it in measurable parameters, such as h, λ, angle i... These are related with δ by (5-30),  $ \delta = \frac{4\pi nh\cos i}{\lambda_0} $

(2) Etalon

The h is fixed for an etalon, for single freq. light input, the transmitted