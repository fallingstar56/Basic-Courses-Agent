## 6 -3-2 Phasor Treatment and Vibrational Spirals (curves)

What happened if the opening does not contain an integer of  $ \lambda/2 $-plates?

For the on-axis point P, such problem can be solved by the phasor method.

<div style="text-align: center;"><img src="imgs/img_in_image_box_226_594_732_739.jpg" alt="Image" width="42%" /></div>


 $ r - r_{0} = m\left(\frac{\lambda}{2}\right) $, m is a real number, not necessarily an integer as in  $ \lambda/2 $-plates case.

We still start from HFP:  $  U(P) = \frac{K}{r_{0}} \iint_{\Sigma} \tilde{U}_{0} f(\theta, \theta_{0}) e^{ikr} d\Sigma  $

Now we divide the wave front at aperture  $ \Sigma $ into many small zones  $ d\Sigma $, each small zone contributes to P with amplitude and phase  $ dA(P)e^{i\delta} $;

 $$ d A(P)=\frac{K}{r_{0}}f(\theta,\theta_{0})\tilde{U}_{0}d\Sigma,\delta=k\Delta r $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_234_1237_514_1561.jpg" alt="Image" width="23%" /></div>


And integral U(P) can be estimated

then by phasor method.