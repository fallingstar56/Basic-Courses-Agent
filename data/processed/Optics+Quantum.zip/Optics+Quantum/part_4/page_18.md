The excited molecules/atoms radiate such wave-trains, with duration of the lifetime of the excited states. Also the lifetime  $ \tau $ is not a constant, it has certain distribution.

 $$ \begin{array}{c} \leftarrow\tau_{1}\rightarrow\leftarrow\tau_{2}\rightarrow\cdots\cdots\cdots\cdots\rightarrow\\ \cdots\cdots\cdots\cdots\cdots\cdots  \quad \leftarrow\tau_{3}\rightarrow\cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \\ \rightarrow\cdots\cdots\cdots\cdots\cdots  \quad \cdots\cdots\cdots\cdots\cdots  \end{array} $$ 

In the figure,  $ \tau $ the lifetime or the duration of wave train; the frequency  $ \omega $ is given by  $ \Delta E = \hbar \omega $. Different wave train has its duration and very important its own initial phase, where initial phases between different wave trains are unrelated (incoherent). The distribution of the excited state lifetime  $ \tau $ is :

(equivalently, the probability of finding the atom at the excited state at time  $ \tau $)

 $$ \rho(\tau)=\frac{1}{\tau_{_{0}}}e^{-\frac{\tau}{\tau_{_{0}}}} $$ 

 $$ \mathrm{When}\quad<\tau>=\frac{\int\tau\rho(\tau)d\tau}{\int\rho(\tau)d\tau}=\tau_{0} $$ 

∴  $ \tau_{0} $ is the average of lifetime of the excited state, or the average duration of the wave-trains temporal duration. The average space duration, or the OPL duration is then:

 $$ L_{0}=c\tau_{0} $$ 

 $ \tau_{0} $: coherent time,  $ L_{0} $: coherent length.