The simplest model to treat diffraction is Huygens-Fresnel Principle (H-F-P): On the unobstructed wave front, every point serves as a source of spherical secondary wavelets (same  $ \omega $). The complex amplitude of the optical field at any point beyond is a superposition of all the wavelets. It is basically Huygens Principle + Superposition of waves. Simple picture of H-F-P in determining E(p) through a hole:

a) For  $ \overline{AB}<\lambda/2 $. Then  $ \Delta L $ of difference in OPL between any two paths,  $ \Delta L<\overline{AB}<\lambda/2 $ All secondary waves add at P constructively  $ \overline{AB} $ behaves as a point source.

b) As  $ \overline{AB} $ increases, the interference at P from all the secondary wavelets can either constructive or destructive-diffraction, meaning intensity there may be high or low.

c) As  $ \overline{AB} \gg \lambda $ such interference would cause light APPEAR to travel in linear form and we get geometric optics prediction. (We shall see that the diffraction arising from the boundary is much smaller comparing to the light in the geometric allowed zone, which is the  $ 0^{th} $ order diffraction)

<div style="text-align: center;"><img src="imgs/img_in_image_box_211_1250_534_1474.jpg" alt="Image" width="27%" /></div>


Simple as its physical picture appear to be, solving the field at p