From  $ \lambda/2 $ plate method:

<div style="text-align: center;"><img src="imgs/img_in_image_box_228_226_738_501.jpg" alt="Image" width="42%" /></div>


The obstacle

blocks $l\ \lambda/2$ plates, so the contribution to field point $P$ is from $(l+1)^{\mathrm{th}}\ \lambda/2$ plate to $(l+\mathrm{m})^{\mathrm{th}}$:

 $$ \begin{aligned}&|U_{P}|=|A_{l+1}|-|A_{l+2}|\ldots\\ &=\frac{|A_{l+1}|}{2}\pm\frac{|A_{l+m}|}{2}\\ &=\frac{|A_{l+1}|}{2}\\ \end{aligned} $$ 

 $ A_{l+m}=0 $ since it is the plate with  $ f(\theta,\theta_{0})=\frac{1}{2}(1+\cos\theta)=\frac{1}{2}(1-1)=0 $

Thus the point P is always bright, with irradiance as if the obstacle does not exist, similar to that of free propagation. This is another counter intuitive result, but confirmed by the experiment, very important in the demonstration of wave characters of light.

In terms of vibrational curves, the field at point P over an obstacle is: