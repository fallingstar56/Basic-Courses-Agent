In the figure left I showed the contribution of first  $ \lambda/2 $ plate by dividing the integral into many (N) phasors. The deviation from a perfect circle is due to the decrease of  $ f(\theta,\theta_{0}) $

As  $ N \rightarrow \infty $, the arrow form a continuous curve(very close to a circle).

As the increase of aperture(or as P moves closer), the phasor diagram will be:

<div style="text-align: center;"><img src="imgs/img_in_image_box_271_529_712_888.jpg" alt="Image" width="37%" /></div>


(The spiral in the above figure is overly exaggerated, for the many lower order half-wavelength zones, it is very close to a circle)

 $$ A_{0}\approx\frac{\left|OZ_{1}\right|}{2}=\frac{\left|A_{1}\right|}{2} $$ 

 $ A_{0} $ is the field at free propagation.

Two  $ \lambda/2 $-zone-plates in aperture:  $ |U(P)|=|OZ_{2}| $

Three λ/2-plates in aperture:  $ |U(P)| = |\overrightarrow{OZ_3}| $

The figure above over exaggerates the deviation from circle. Because the

slow decrease of the obliquity factor, the  $ Z_{2}, Z_{4} $ should be very close to O

and  $ Z_{1}, Z_{3} $ is about  $ A_{0} $ away from O.