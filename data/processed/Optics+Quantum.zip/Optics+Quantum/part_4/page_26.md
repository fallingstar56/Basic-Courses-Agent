 $$ \begin{aligned}&<e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>_{T}\\&=\frac{1}{N\tau_{_{0}}}\int\limits_{_{0}}^{^{N\tau_{_{0}}}}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}dt\\&=\frac{1}{N\tau_{_{0}}}\int\limits_{_{0}}^{\tau_{_{1}}}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)}dt+\int\limits_{\tau_{_{1}}}^{\tau_{_{1}}^{^{\prime}}+\tau_{_{2}}^{^{\prime}}}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)}dt+\cdots\cdots\\ \end{aligned} $$ 

If  $ \tau < \tau_{1}^{\prime} $, then the first integral is:

 $$ \int\limits_{0}^{\tau_{1}^{\prime}}e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)}d t=\int\limits_{0}^{\tau_{1}^{\prime}-\tau}e^{i0}d t+\int\limits_{\tau_{1}^{\prime}-\tau}^{\tau_{1}^{\prime}}e^{i\Delta_{1}}d t=\tau_{1}^{\prime}-\tau+\tau e^{i\Delta_{1}} $$ 

$\Delta_1$ is the initial phase difference between $1^\mathrm{st}$ and $2^\mathrm{nd}$ wave train and it is a random number of which we know nothing about its value. However this term will average to zero in the process of summation, so we can drop such $\tau e^{i\Delta_j}$ term in final results after summation of all the wave trains.

If $\tau > \tau_1^\prime$, $\int_0^{\tau_1^\prime} e^{i[\varphi_0(t) - \varphi_0(t+\tau)} dt = \tau_1^\prime e^{i\Delta_1}$, this time only has the random number part, and it will be similarly averaged out in the summation process. Thus, only those long wave trains with $\tau < \tau_j^\prime$ survives, contribute to the average by $\tau_j' - \tau$:

 $$ <e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>=\frac{1}{N\tau_{0}}\sum_{\tau_{j}^{^{\prime}}>\tau}(\tau_{j}^{^{\prime}}-\tau) $$ 

Let’s say the number of trains with length  $ \tau_j' $ is  $ n_j $, then  $ \frac{n_j}{N} = \rho(\tau') d\tau' $:

 $$ \begin{aligned}&<e^{i[\varphi_{0}(t)-\varphi_{0}(t+\tau)]}>={\frac{1}{N\tau_{0}}}\sum_{\tau_{j}^{\prime}>\tau}(\tau_{j}^{\prime}-\tau)={\frac{1}{\tau_{0}}}\int\limits_{\tau}^{\infty}\rho(\tau^{\prime})(\tau^{\prime}-\tau)d\tau^{\prime}\\ &=\frac{1}{\tau_{0}}\int\limits_{\tau}^{\infty}\frac{1}{\tau_{0}}e^{-\frac{\tau^{\prime}}{\tau_{0}}}(\tau^{\prime}-\tau)d\tau^{\prime}\\ &=e^{-\frac{\tau}{\tau_{0}}}\\ \end{aligned} $$ 