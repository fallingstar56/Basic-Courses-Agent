people. A slight change of the environment (breeze of wind, beautiful

lady passing by...) will cause significant disturbance and may destroy

constructiveness, so the constructive condition for multi-party is more

sensitive to the parameters.

## 5 -5-1 Fabry-Perot Interferometer

Here is a device applying the multi-beam interference discussed above. The Fabry_Perot (FP) interferometer is essentially a pair of flat (very flat indeed) plate, parallel with each other with spacing h. If the spacing h is fixed, it is called “etalon”, and is widely used in lasers as wavelength narrowing device. If h is scanned over a range, it is called Fabry-Perot interferometer or spectrometer.

<div style="text-align: center;"><img src="imgs/img_in_image_box_238_956_553_1156.jpg" alt="Image" width="26%" /></div>


The flatness of the plate is on the order of  $ \frac{\lambda}{100} $ (to let more beams into interference, the random up-down on the surface can destroy the interference by introducing random OPL)

The most important parameters for F-P is its  $ F $ (or equivalently R) and h, the Finesse coefficient and spacing. As we already see that the F