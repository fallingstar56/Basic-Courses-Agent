 $ K = -\frac{i}{\lambda} $ (we shall give a proof on this later)

 $$ F(\theta,\theta_{0})=\frac{1}{2}(\cos\theta_{0}+\cos\theta) $$ 

Here I shall use U(p) as symbol for the field, instead of E(p) because we treat the field as a scalar field, this works when the vector feature of the field can be neglected (such as cases where the polarization all along same direction). Most part in (6-2) is quite intuitive: The field at P would depend on the area of the opening and the surface integral is over the open portion of the diffraction screen; It also depends on the field at the opening and its propagation like a spherical source dictated by Huygens principle; the  $ F(\theta_{0},\theta) $ is called obliquity factor whose origin is not intuitive (like that of HFP) but can be derived with the Kirchhoff scalar theory. (6-2) is going to be the starting point for us to deal with diffraction.

## 6 -3 Fresnel Diffraction through an open aperture

<div style="text-align: center;"><img src="imgs/img_in_image_box_170_1211_693_1513.jpg" alt="Image" width="43%" /></div>


A point source S

A screen  $ \Sigma $ with aperture

What is the field at P,

U(P)?