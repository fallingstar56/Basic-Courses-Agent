<div style="text-align: center;"><img src="imgs/img_in_image_box_210_155_769_472.jpg" alt="Image" width="46%" /></div>


<div style="text-align: center;">Then (1) The field Amplitude of the secondary wavelets on  $ \sum $ is constant. (2) The OPL used in the calculation (we shall explain this in detail later) only depends linearly on the two aperture variables  $ d, \theta $, such linearity is the mathematical criterion for the Fraunhoffer diffraction.</div>


Applying the far-field criterion (in the optical  $ \lambda $ region, far field includes the paraxial)

 $ R \gg \frac{d^{2}}{\lambda} $ d the size of the  $ \sum $ (6-1)

R is the smaller distance between S and P to  $ \sum $

As we shall see Fraunhoffer diffraction has many important applications and is also instrumental in the Fourier transform optics. Other arrangement does not satisfy (6-1) is called Fresnel diffraction. Fraunhoffer diffraction is only a special case for it. However, the treatment is more involving for the Fresnel type diffraction. We shall give a brief introduction for the Fresnel diffraction first, the goal is to illustrate: how to use H-F-P, and we only concerns the P on the central axis in this case. We are not going to treat the detailed distribution of the interference