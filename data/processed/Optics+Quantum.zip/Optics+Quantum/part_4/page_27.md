The integration is evaluated by method of integration by part and details are skipped here. The result of this phase evaluation combined with other term will give us the expression for the normalized auto-correlation:

 $$ \begin{aligned}&\gamma_{_{ss}}(\tau)=e^{-\frac{\tau}{\tau_{_{0}}}}e^{i\omega\tau}\quad(5-56)\\ &I(P)=I_{_{1}}+I_{_{2}}+2\sqrt{I_{_{1}}I_{_{2}}}\operatorname{Re}(\gamma_{_{ss}}(\tau))=I_{_{1}}+I_{_{2}}+2\sqrt{I_{_{1}}I_{_{2}}}e^{-\frac{\tau}{\tau_{_{0}}}}\cos\omega\tau\\ \end{aligned} $$ 

The  $ \cos\omega\tau=\cos k\Delta L $ (recall  $ \Delta L=c\tau $) is the variation of intensity due to OPL difference.  $ e^{-\frac{\tau}{\tau_0}} $ is the reduction of coherence due to limited coherent time. As  $ \tau $ (or the  $ \Delta L $ for point P) increases,  $ |\gamma(\tau)| $decrease exponentially according to (5-56).

We can see that at  $ \tau = \tau_{0} $, the coherent time,  $ \gamma = e^{-1} $. This appears a little different from our previous discussion in the temporal coherence, where at  $ \tau = \tau_{0} $,  $ \gamma = 0 $. The difference is because the models involved in the derivations are a little different. In the derivation in temporal coherence and leads to relation (5-47), the frequency distribution is a square function.

i.e.  $  g(w)  $ is  $ \boxed{\leftarrow\triangle w} $, the resultant distribution in  $ \tau $ is given by the Fourier Transform of  $  g(w)  $ and is in form of  $  \frac{\sin \mu}{\mu}  $,

<div style="text-align: center;"><img src="imgs/img_in_image_box_225_1125_457_1197.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_177_1316_833_1507.jpg" alt="Image" width="55%" /></div>
