the rest of the reflection, and cancel with others. This is the answer for the question raised at the beginning of this section. It is possible under ideal situation $ ^{6} $ that light 100% pass and at meantime no reflection.

As R (or r, or F) increase, there are more beams taken part in the interference. The interference fringe  $ (I_{T}, or, I_{R} $ vs.  $ \delta $, the phase difference) sharpens, or in other words, the energy tends to concentrate in smaller phase space as interfering beams increase:

<div style="text-align: center;"><img src="imgs/img_in_chart_box_222_602_847_982.jpg" alt="Image" width="52%" /></div>


This is a general character of interference by multiple sources. You may try to use phasor method to see this point (say 10000 phasor, with a small difference in phase angle (say  $ \frac{2\pi}{10000} $)  $ \underline{\text{between adjacent pair}} $, these ten-thousand components will add up to zero). One analogy with daily life experience is working with peoples: It is relatively easy to make two people to do the same thing, say push something in one direction at same time (constructive); it is much harder to do the same with thousands of