Let  $ \frac{d}{R} = \Delta \theta_0 \rightarrow b \Delta \theta_0 = \lambda $

<div style="text-align: center;">(5-47)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_612_157_774_267.jpg" alt="Image" width="13%" /></div>


So if the  $ \Delta\theta $ is the angle spanned by  $ S_{1} $,  $ S_{2} $ with the center of source with extension b. The spatial coherent condition for  $ S_{1}, S_{2} $ is:  $ \Delta\theta < \Delta\theta_{0} $

This explains why using sunlight directly to illuminate the two slit in Young’s Experiment fails to observe interference pattern; it also explains the decrease of  $ \gamma $ in equal thickness fringes using extended sources (P306, Zhao’s). An example of application is Michelson stellar interferometer. (P280, Zhao’s; 12.4.1 in Hecht)

Once again: Spatial coherence is caused by the size of incoherent source.

5-6-2 Effect of Non-Monochromatic Light---Temporal Coherence

<div style="text-align: center;"><img src="imgs/img_in_image_box_178_1018_737_1499.jpg" alt="Image" width="46%" /></div>
