## Summary on Interference

1 Principle of superposition

 $$ \begin{array}{r l r l r l}&{\stackrel{!}{\mathcal{Z}}}&{\stackrel{\bullet}{\bullet}}&&{\mathcal{E}_{1},\mathcal{E}_{2},\cdots}&{\qquad\vec{E}=\displaystyle\sum_{j}\vec{E}_{j}(p)}\\ &{\stackrel{\Im}{\bullet}}&&{\stackrel{\bullet}{\mathcal{P}}}&&{}\\ &{\stackrel{\cdot}{\cdot}}&&{}&&{}\end{array} $$ 

 $$ \vec{E}_{j}(p)=\vec{E}_{o j}e^{i\phi_{j}(p)}e^{-i\omega t} $$ 

 $$ \vec{E}(p)=\vec{E}_{o}e^{i\phi_{j}(p)}e^{-i\omega t} $$ 

2 Interference and Coherence

 $$ \begin{aligned}I(p)=&\left|\vec{E}\right|^{2}\\=&\sum_{j=1}^{N}E_{o j}^{2}+\sum_{j=1}^{N}\sum_{i=1}^{N}\vec{E}_{o j}\cdot\vec{E}_{o i}<\cos[\phi_{j}(p)-\phi_{j}(p)]>\\&\text{Interference term}\end{aligned} $$ 

Interference Term  $ \neq 0 \rightarrow $ coherent conditions:

(1)  $ \vec{E}_{j} $ all have same  $ \omega $

(2)  $ \vec{E}_{j} $ have parallel component with each other

(3) Stationary  $ \delta = \phi_{j}(p) - \phi_{i}(p) $

Two beam Interference  $ I(p)=I_{1}(p)+I_{2}(p)+2\sqrt{I_{1}(p)I_{2}(p)}\cos\delta $

3. Wave front distribution

To know:  $ I_{1}(p), I_{2}(p), \delta = \phi_{1}(p) - \phi_{2}(p) $

We need  $ E_{j}(p)=E_{oj}(p)e^{i\phi_{j}(p)} $

paraxial condition:  $ E_{oj}(p) $ (the

