<div style="text-align: center;"><img src="imgs/img_in_image_box_253_148_588_407.jpg" alt="Image" width="28%" /></div>


 $$ n_{1}=n_{2} $$ 

With  $ n_{1}=n_{2} $, and we have Stokes Relation.

 $$ r=-r^{\prime},r^{2}+tt^{\prime}=1 $$ 

 $$ \begin{aligned}&Reflection\begin{cases}\\ &A_{1}=A r\\&A_{2}=A tr^{\prime}t^{\prime}\\&A_{3}=A tr^{\prime3}t^{\prime}\\&\vdots\\ &\end{cases}\quad&Transmitted\quad&\begin{cases}\\ &A_{1}^{\prime}=A t t^{\prime}\\&A_{2}^{\prime}=A tr^{\prime}r^{\prime}t^{\prime}=A t t^{\prime}r^{\prime2}\\&A_{3}^{\prime}=A t t^{\prime}r^{\prime4}\\ &\end{cases}\\ \end{aligned} $$ 

The amplitude distribution for Reflected and Transmitted light are given above.

The Optical path length difference between adjacent beams:

 $$ \Delta L=2n h\cos i, $$ 

 $$ \delta=k_{0}\Delta L=\frac{4\pi nh\cos i}{\lambda_{0}} $$ 

The complex amplitude of wave is: (neglect the common factor, such as  $ e^{-i\omega t} $)

 $$ R\left\{\begin{aligned}\tilde{U}_{1}=-A r^{\prime}\\ \tilde{U}_{2}=A t t^{\prime}r^{\prime}e^{i\delta}\\ \tilde{U}_{3}=A t t^{\prime}r^{\prime}e^{2i\delta}\end{aligned}\right.\qquad T\left\{\begin{aligned}\tilde{U}_{1}^{\prime}=A t t^{\prime}\\ \tilde{U}_{2}^{\prime}=A t t^{\prime}r^{\prime2}e^{i\delta}\\ \tilde{U}_{3}^{\prime}=A t t^{\prime}r^{\prime4}e^{i2\delta}\end{aligned}\right. $$ 

We shall treat the Transmission first and the intensity of Reflection can be derived from conservation of energy.

 $$ I_{R}+I_{T}=I_{0} $$ 