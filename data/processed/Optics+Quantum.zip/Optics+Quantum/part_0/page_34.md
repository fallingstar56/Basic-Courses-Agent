Considering the case that the light propagates from left-to-right; the observer is moving with velocity u against light (from right-to-left). (Here I only consider the motion of observer along the direction of light propagation; I shall neglect the effect of so called transverse motion, i.e. the motion perpendicular with respect to the light propagation, because the transverse effect is usually much smaller)

First I will define two reference frames, S is the frame in which the light source is stationary, and the observer is moving with  $ -u $ (observer is at the right-side of the light source and moving toward the light source). The S' system is in which the observer is stationary and the light source is moving with velocity u. The Lorentz Transformation between the two frames is:

 $$ x^{^{\prime}}=\frac{x+ut}{\sqrt{1-\frac{u^{2}}{c^{2}}}}\quad and\quad t^{^{\prime}}=\frac{t+\frac{ux}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}} $$ 

 $$ \Delta x^{^{\prime}}=\frac{\Delta x+u\Delta t}{\sqrt{1-\frac{u^{2}}{c^{2}}}}\quad and\quad\Delta t^{^{\prime}}=\frac{\Delta t+\frac{u\Delta x}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}} $$ 

 $$ x=\frac{x^{^{\prime}}-ut^{^{\prime}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}}\quad and\quad t=\frac{t^{^{\prime}}-\frac{ux^{^{\prime}}}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}} $$ 

 $$ \Delta x=\frac{\Delta x^{^{\prime}}-u\Delta t^{^{\prime}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}}\quad and\quad\Delta t=\frac{\Delta t^{^{\prime}}-\frac{u\Delta x^{^{\prime}}}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}} $$ 

Where  $ (x, t) $,  $ (x', t') $ are spatial-temporal coordinates for the same event in two frames, and the  $ (\Delta x, \Delta t) $,  $ (\Delta x', \Delta t') $ are the difference between the two events observed in the two frames.

Next we shall define the two events relevant to the problem (in all problems involving relativity, defining the relevant events are always important). Considering two adjacent equal phase wavefronts from the light source, wavefront 1 and wavefront 2 (the phase difference between them is of course  $ 2\pi $): Event 1 is when the wavefront 1 passes the observer; Event 2 is when the wavefront 2 passes the observer. The time period experienced by the observer  $ \Delta t' $ is what we are interested, its reciprocal will be the frequency experienced by the observer with relative motion to the light source. To calculate  $ \Delta t' $, I will first calculate  $ \Delta t $ and then use L-transform.

In the frame S, event 1 happens at (x1, t1), now the wavefront 1 passes the observer at (x1, t1), at this moment the wavefront 2 is at distance cT from x1, where T