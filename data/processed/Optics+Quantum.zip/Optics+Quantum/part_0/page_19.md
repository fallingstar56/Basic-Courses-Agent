 $$ \Delta\varphi(p,t)>0\quad\longrightarrow\longrightarrow\quad\mathrm{L a g s~i n~p h a s e} $$ 

 $$ \Delta\varphi(p,t)<0\quad\overrightarrow{\quad}\quad\mathrm{~L~e~a~d~s~i~n~p~h~a~s~} $$ 

Thus, the complex representation is

(1) Equivalent to the cosine representation, as long as we bear in mind the physical wave correspond to the real part of the complex.

(2) The complex will simplify the calculation.

Comments on the Equivalence of Euler expression and sinusoidal expression for waves:

The complex expression of waves (Euler formula) is very useful; it simplifies many calculations comparing with the sinusoidal expressions of waves. I stated above that as long as you are aware that the real part of the complex expression corresponds to the physical wave, you can use the complex during the calculation, and if necessary (a lot of times it is not necessary) you take the real part of the complex result to express the physical wave. This statement needs a little bit polish in a sense that it depends on the calculation:

If the required calculation would not mix the real and imaginary parts, such as adding, subtracting and differentiating waves, you can use the complex expression with confidence. It generates same results as the sinusoidal expression. (By taking the real part of the complex)

However, if the calculation mixes the real and imaginary parts, such as multiply, generally two expressions will give different results, and you need to stick to the sinusoidal expressions (Not many calculations in this course belong to this class). Example: two waves at a fixed spatial point with same frequency, we calculate their product at that point over time:  $ E_1 = A_1 \cos(\omega t + \delta_1) $;  $ E_2 = A_2 \cos(\omega t + \delta_2) $. The corresponding complex expressions are:  $ \tilde{E}_1 = A_1 e^{i(\omega t + \delta_1)} $ and  $ \tilde{E}_2 = A_2 e^{i(\omega t + \delta_2)} $. Then (* means complex conjugate):

 $$ E_{1}E_{2}=E_{1}E_{2}^{*}=A_{1}A_{2}\cos(\omega t+\delta_{1})\cos(\omega t+\delta_{2})=\frac{1}{2}A_{1}A_{2}[\cos(\delta_{1}-\delta_{2})+\cos(2\omega t+\delta_{1}+\delta_{2})] $$ 

 $$ \tilde{E}_{1}\tilde{E}_{2}=A_{1}A_{2}e^{i(2\omega t+\delta_{1}+\delta_{2})}\xrightarrow{r e a l}\neq E_{1}E_{2} $$ 