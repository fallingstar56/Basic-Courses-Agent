7-1-2 Non-periodic functions – Fourier Transform (Fourier Integral) ..... 293  
7-1-3. Dirac Delta Function  $ \delta(x) $ ..... 304  
7-1-4 Properties of Fourier Transform ..... 307  
7-2 Fraunhoffer Diffraction from Fourier Optics' point of view ..... 315  
7-2-1 Fraunhoffer Diffraction ..... 316  
7-2-2 Abbe imaging principle and image processing by spatial Filtering ..... 323  
Chapter 8 Polarization and Propagation of Light in Crystal ..... 337  
8-1 Polarization Type of Light ..... 337  
8-2 Polarizer ..... 344  
8-3 Jones Vector for Polarized Light and Jones Matrix ..... 349  
8-3-1 Jones Vector ..... 349  
8-3-2 Jones matrix for operation on polarized light ..... 351  
8-4 Propagation of light in Crystal-Birefringence ..... 352  
8-4-1 Phenomena of Birefringence (Double refraction) ..... 352  
8-4-2 Microscopic explanation of Birefringence ..... 355  
8-5 Crystal Optical Elements ..... 364  
8-5-1 Birefrigent polarizers ..... 364  
8-5-2 Wave plate—phase retarder ..... 364  
8-5-4 Jones Matrix for polarizer and wave plate ..... 372  
8-6 Optical activity (Circular Birefringence) ..... 380  
8-6-1 Definition ..... 380  
8-6-2 Optical Activity in Crystal ..... 381  
8-6-3 Circular Birefringence ..... 382  
8-6-4 Optical activity in solution ..... 385  
8-6-5 Induced Circular Birefringence—Faraday effect ..... 386  
Chapter 9 Absorption, Dispersion and Scattering of light ..... 389  
9-1 Absorption of Light—Beer's Law (Lambert Law) ..... 389  
9-2 Complex index of refraction ..... 392  
9-3 Classical E-M theory on dispersion and absorption ..... 393  
Chapter 10 Quantum property of light ..... 397  
10-1 Photon—Light Quanta ..... 397  
10-2 Blackbody Radiation ..... 398  
10-3 Photon-Electric effect ..... 408  
10-4 Compton Effect and Momentum of Photon ..... 410  
10-5 Angular Momentum of Photon (Spin) ..... 412  
10-5 de Broglie's Matter wave ..... 413  
10-6 Uncertainty Principle ..... 419  
Chapter 11 Introduction to Quantum Mechanics ..... 422  
11-1 Young's Double Slits Experiment Revisited ..... 423  
11-2 Physical Meaning of the Matter Wave---Probability Wave ..... 433  
11-3 Uncertainty Principle ..... 441  
11-4 Fundamental Postulates of Quantum Mechanics ..... 454  
(1) Ehrenfest Theorem ..... 472