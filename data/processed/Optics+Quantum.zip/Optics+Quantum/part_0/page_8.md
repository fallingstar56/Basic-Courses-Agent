 $$ \nabla^{2}\equiv\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}} $$ 

Laplacian operator

If a function  $ \psi(r,t) $ is a solution of the wave equation, and its second partial derivative vs. space and time is non-trivial, then  $ \psi(r,t) $ represents a wave.

A special example (as well as a common case in the course):

Wave propagates with a constant shape and phase velocity.

 $ \psi(x,t) = f(x \mp vt) $ (Fig. 2.3, 2.4, pg13. Hecht)

<div style="text-align: center;"><img src="imgs/img_in_chart_box_270_736_627_1082.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_271_1097_644_1418.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">If you put this back to (1-1), it certainly satisfy the wave equation.</div>
