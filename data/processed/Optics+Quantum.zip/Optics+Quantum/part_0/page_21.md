vector representation of any complex number.

 $$ \psi(p,t)=A(p)e^{i\varphi(p)}e^{-i\omega t} $$ 

phasors :

<div style="text-align: center;"><img src="imgs/img_in_image_box_451_330_689_469.jpg" alt="Image" width="20%" /></div>


与 if +iwt

 $$ 2it-i w t $$ 

This is very useful in summation of multiple waves with same frequency:

 $$ A(p)e^{i\varphi(p)}e^{-i\omega t}=(\sum_{j}A_{j}(p)e^{i\varphi_{j}(p)})e^{-i\omega t} $$ 

The geometrical expression is provided in the figure below

<div style="text-align: center;"><img src="imgs/img_in_image_box_392_784_760_1024.jpg" alt="Image" width="30%" /></div>


Example: Adding two waves.

I shall use this example to illustrate describing waves with sinusoidal functions, complex formula and phasor method, showing they are indeed equivalent.

The problem is a simple but important one: adding two waves with same frequency but with a phase difference. The two 1-D waves are:

 $$ \psi_{1}=A\cos(kx-\omega t) $$ 