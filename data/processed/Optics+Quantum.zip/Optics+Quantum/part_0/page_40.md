For the detailed treatment of  $ n^{\prime} $'s dependence on  $ \omega $, will leave for later class.

## 2 -3 Transverse Wave

Let's first assume the E, H are in forms of plane wave. (A plane wave form certainly satisfy the Maxwell equations)

 $$ E(\vec{r},t)=A_{0}e^{i(\vec{k}\bullet\vec{r}-\omega t)} $$ 

Then  $ \nabla E = i\vec{k}E $

 $$ \frac{\partial E}{\partial t}=-i\omega E $$ 

The operators  $ \nabla $, and  $ \frac{\partial}{\partial t} $ act on plane waves as if:

$$\frac{\partial}{\partial t}\rightarrow-i\omega,\text{ which means the operator act on plane wave just like}\text{ multiply it with}-i\omega.$$

 $ \nabla \rightarrow i\vec{k} $, which means the operator act on plane wave just like multiply it with  $ i\vec{k} $.

From Maxwell Equation (2-3)

 $$ \nabla\times\vec{E}=-\mu\frac{\partial\vec{H}}{\partial t} $$ 

Then:  $ i\vec{k} \times \vec{E} = \mu i\omega\vec{H} $