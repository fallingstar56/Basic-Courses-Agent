The force due to electric field will drive the particle on the surface into forced oscillator parallel to the surface (Recall the  $ \vec{E}, \vec{B} $ are parallel to the surface in the normal illumination case here).  $ \vec{v} $ is the speed of such oscillation of the charged particle, and  $ \vec{v} \times \vec{B} $ will be a force in the direction of  $ \vec{k} $, the direction of wave propagation, it is this force responsible for the radiant pressure and momentum change of the field.

(Note: if $\vec{v}$, $\vec{B}$ are random, $\vec{v} \times \vec{B}$ can be either in direction of $\vec{k}$ or $-\vec{k}$; the reason that radiant pressure (or force) is in the direction of $\vec{k}$ is because: $\vec{v}$ is the speed of a forced oscillation driven by $\vec{E}$, it is partially in phase with $\vec{E}$, we are going to prove that the phase lag between $\vec{v}$ and $\vec{E}$ is between $-\frac{\pi}{2} - \frac{\pi}{2}$. So $\vec{v}$ is somewhat in the direction of $\vec{E}$, and $\vec{E} \times \vec{B} \to \vec{k}$)

(3) Application of radiant pressure:

a. Optical cooling :

 $ \xrightarrow{\text{photon}} \quad \leftarrow \quad O $

 $ \xrightarrow{\text{atom/molecule}} $

Absorption of photon will slow down the atom/molecule.

b. Laser separation of isotopes.