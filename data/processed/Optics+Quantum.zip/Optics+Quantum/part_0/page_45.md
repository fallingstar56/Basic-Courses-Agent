 $$ E\cdot j=E\cdot(\nabla\times H-\frac{\partial D}{\partial t})=E\cdot\nabla\times H-E\cdot\frac{\partial D}{\partial t} $$ 

 $$ \because\nabla\cdot(E\times H)=H\cdot\nabla\times E-E\cdot\nabla\times H\quad(general product rule of \nabla) $$ 

 $$ \therefore E\cdot j=-\nabla\cdot(E\times H)+H\cdot\nabla\times E-E\cdot\frac{\partial D}{\partial t}=-\nabla\cdot(E\times H)-H\cdot\frac{\partial B}{\partial t}-E\cdot\frac{\partial D}{\partial t} $$ 

 $$ H\cdot\frac{\partial B}{\partial t}=\mu H\cdot\frac{\partial H}{\partial t}=\frac{1}{2}\mu\frac{\partial(H\cdot H)}{\partial t}=\frac{1}{2}\frac{\partial(H\cdot B)}{\partial t} $$ 

 $$ similarly\quad E\cdot\frac{\partial D}{\partial t}=\frac{1}{2}\frac{\partial(D\cdot E)}{\partial t} $$ 

 $$ E\cdot j=-\nabla\cdot(E\times H)-\frac{1}{2}\frac{\partial(D\cdot E)}{\partial t}-\frac{1}{2}\frac{\partial(H\cdot B)}{\partial t} $$ 

 $$ \frac{dW}{dt}=\iiint\limits_{V}E\cdot jdV=-\iint\limits_{S}E\times H\cdot dS-\frac{d}{dt}(\iiint\limits_{V}(\frac{1}{2}D\cdot E+\frac{1}{2}H\cdot B)dV) $$ 

The last equation carries a clear physical meaning. The left-hand states that the work done by the field, the right-hand states the E-M energy changes in the field. The equation states the work done by the field equals to the energy decrease of the field, no surprise there! Take a closer look of the energy change of the field, the last term is clearly the change of energy of the field stored inside the volume (I hope this is obvious to you, if not, recall that the energy density of the electric and magnetic field are 1/2D.E and 1/2H.B respectively). The first term on the right-hand side is the energy flow out of the surface bounded the volume, with an energy flow density (the flux density) ExH, which is called Poynting vector. The physical meaning of it is the energy flow across a perpendicular surface with unit area per unit time. This is the energy flow carried by a traveling electro-magnetic wave!

## 2 -5 Momentum of E-M Field

<div style="text-align: center;"><img src="imgs/img_in_image_box_291_1152_520_1308.jpg" alt="Image" width="19%" /></div>


Light is incident or a surface. The surface will absorb the light. Light will generate a pressure (radiant pressure) on the surface, or equivalently transform momentum to the surface.