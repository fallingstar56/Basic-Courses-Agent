difference between this wave and the $E_0 = A_0 \cos(kz - \omega t)$ is $\delta$. The figure above only shows the E(z,t), (for comparison, you can add the $E_0$ yourself on the picture). It is clear from the picture that $E(z,t) = A \cos(kz - \omega t + \delta)$. Lags in phase comparing with $E_0 = A_0 \cos(kz - \omega t)$. The delay (choose a same phase point, let's choose the maxim point of the sinusoidal wave in the figure) in the $z$ coordinate is $kz' - \omega t + \delta = 0 = kz - \omega t$ (for same $t$), $\Delta z = z' - z = -\delta / k$. (The $\delta$ value will be set between $- \pi < \delta < \pi$, this can be satisfied always by adding $n2\pi$ to the phase part, $n = \pm 1, \pm 2...$)



<div style="text-align: center;"><img src="imgs/img_in_image_box_222_219_545_339.jpg" alt="Image" width="27%" /></div>


Conclusion: If the wave expressed in forms of  $ \cos(kz - \omega t + \delta) $ or  $ e^{i(kz - \omega t + \delta)} $, the positive phase difference  $ \delta(\delta > 0) $ value means lags in phase and negative phase difference  $ \delta(\delta < 0) $ value means leads in phase.

(2)For a wave propagates along the -z direction, If we express it in forms of  $ E(z,t) = A\cos(kz + \omega t - \delta) $:

<div style="text-align: center;"><img src="imgs/img_in_image_box_245_1321_468_1464.jpg" alt="Image" width="18%" /></div>
