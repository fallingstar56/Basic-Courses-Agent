## 1 -5 Superposition Principle

It is valid because the wave equation is  $ \underline{\text{linear.}} $

If  $ \psi_{1}, \psi_{2} $ are solutions to wave equation (1-1) or (1-2), then  $ \psi = \psi_{1} + \psi_{2} $ is also a solution. (Note, it is also assumed that  $ \nu $ is a constant, independent of  $ \psi_{1}, \psi_{2} $, this is certainly true in cases where light travels in vacuum but in cases where  $ \nu $ depends on  $ \psi $,complication arises, we will see in the later section on group velocity)

<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_199_748_501_1023.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_522_749_823_1019.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_199_1048_499_1318.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_523_1047_824_1315.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;">The figure (Hecht’s figure 2.14) shows the superposition of waves with different phase difference. The case (a) with equal phase (phase difference is 0 or  $ 2n\pi $) is called constructive; the case (d) with opposite</div>
