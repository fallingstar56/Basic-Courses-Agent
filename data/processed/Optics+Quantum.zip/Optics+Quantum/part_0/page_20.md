 $$ \tilde{E}_{1}\tilde{E}_{2}^{*}=A_{1}A_{2}e^{i(\delta_{1}-\delta_{2})}\xrightarrow{r e a l}\neq E_{1}E_{2} $$ 

In the above calculation, using complex expression would give incorrect answers. Fortunately such calculation is not often in real physics, in most cases where we are interested in the multiplications, we are interested in its time average! I.e. we are interested in:

 $$ <E_{1}E_{2}>_{T}=\frac{1}{T}\int\limits_{0}^{T}E_{1}E_{2}dt $$ 

 $$ <E_{1}E_{2}>_{T}=\frac{1}{T}\int_{0}^{T}E_{1}E_{2}dt=\frac{1}{2}A_{1}A_{2}\frac{1}{T}\int_{0}^{T}[\cos(\delta_{1}-\delta_{2})+\cos(2\omega t+\delta_{1}+\delta_{2})]dt $$ 

If the average time  $ T \gg $ the time period of the oscillation, i.e.  $ T \gg \frac{2\pi}{\omega} $, the second term in the integral will become  $ \sim $0 after divided by T, then:

 $$ <E_{1}E_{2}>_{T}=\frac{1}{2}A_{1}A_{2}\cos(\delta_{1}-\delta_{2})=\frac{1}{2}\mathrm{Re}\left\{\tilde{E}_{1}\tilde{E}_{2}^{*}\right\} $$ 

Thus we can use complex expression  $ \tilde{E}_1\tilde{E}_2^* $ to evaluate the time average of the product, up to a constant factor 1/2. This is the basis that I will use complex expression to calculate the time average product of the fields in this course. One particular example is the average energy flux of the light is :

 $ <E_1E_1>_{T}=\frac{1}{2}A_1^2=\frac{1}{2}\tilde{E}_1\tilde{E}_1^* $

Here I use E to represent real physical field and  $ \tilde{E} $ to represent its complex expression. In this course, all the calculations involved satisfy the condition that the two representations would give same results (i.e. superposition, differentiation, time average of products etc.), so in my lecture notes, I just use E to represent the field in both cases to save bookkeeping time.

The reason I shall use Euler formula (the complex exponential form) to represent wave is not only due to math simplification as it may bring, but also the complex form of wave is a must later in the quantum mechanics, so we’d better get used to it as early as possible.

Phasor: vector representation of the complex representation, just like the