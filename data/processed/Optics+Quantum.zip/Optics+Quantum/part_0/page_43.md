flow across a surface per unit time and per unit area, so is called flux density).

For plane waves:

 $$ \vec{S}=\vec{E}_{0}\times\vec{H}_{0}\cos^{2}(\vec{k}\bullet\vec{r}-\omega t) $$ 

It’s time Average:

 $$ \langle S\rangle=\frac{1}{2}\vec{E}_{0}\times\vec{H}_{0}=\frac{1}{2}E_{0}H_{0}\frac{\vec{k}}{\left|\boldsymbol{k}\right|} $$ 

 $$ \left(\left\langle\cos^{2}\omega t\right\rangle_{t}=\frac{1}{2}\mathrm{i f}t\gg2\pi\Big/\omega\mathrm{s e e p r o b l e m s e t}1\right) $$ 

In isotropic media, the direction of energy flow is same as the propagation direction of the wave front.

Define  $ \langle \vec{S} \rangle $ 's value (or module) is:

 $$ I=\frac{1}{2}E_{0}H_{0}=\frac{1}{2}n c_{0}\varepsilon_{0}E_{0}^{2}=\frac{1}{2}\frac{n}{c_{0}\mu_{0}}E_{0}^{2}\propto E_{0}^{2} $$ 

“I” has the name of  $ \underline{\text{radiant flux density}} $; it measures the energy flow per unit time and unit area. Sometimes it is also called “irradiance” or “excitance”, depending whether the energy flow into or out of some surface. Sometimes “I” is also called intensity, this is loosely fine and is what I will use in this course, since intensity, rigorously speaking is defined differently. For the thorough discussion on the various terms on Radiometry which will not be covered in this course, please refer to Zhao’s Book, pg120-137.