band corresponding to Rb87  $ F = 2 \rightarrow F' $, there are should be 3 fine structures:  $ F = 2 \rightarrow F' = 3, 2, 1 $. They are hidden because each one is Doppler broadened.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_267_481_863_815.jpg" alt="Image" width="50%" /></div>


The probe beam due to its overlapping with the saturation beam will experience saturation effect, and most important because of the head-to-head configuration, only certain atoms with suitable velocity can “enjoy” saturation effect, this will decrease of absorption in reference beams from certain atoms will show dips in the absorption of the probe beam and thus reveal the fine structure of the atom. Below is the absorption spectrum of the same  $ F = 2 \rightarrow F' $ Rb87 of the probe beam, notice those dips in the spectrum.

<div style="text-align: center;"><img src="imgs/img_in_chart_box_194_1090_604_1391.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;">*Supplement 2: Prove Doppler Effect using special relativity</div>
