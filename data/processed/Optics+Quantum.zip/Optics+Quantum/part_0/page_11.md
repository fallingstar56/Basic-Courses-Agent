monochromatic)

The monochromatic wave is an idealization (as mass point with fixed energy in mechanics) because nothing last forever. Any real waves are at best quasi-chromatic, and usually are a superposition of monochromatic waves:

Example: limited wave train

<div style="text-align: center;"><img src="imgs/img_in_image_box_263_593_898_783.jpg" alt="Image" width="53%" /></div>


A wave train with limited length L (It only lasts from 0 to L att = 0), and thus strictly speaking is not a wave with single frequency (or wavelength). By looking at it, it is not hard to see that as the L gets large, the wave train will be pretty much a ideal harmonic wave with single frequency at certain  $ k_{0} $; but if L is very small, it is far from it. The detailed math will be presented later in the due course (Fourier transform), here I shall just present the result. For such wave train, it can be expressed as a superposition of many harmonic waves with different wave vectors k:

 $$ \psi(x)\Big|_{t=0}=\int\limits_{-\infty}^{+\infty}\varphi(k)\cos(kx)dk $$ 

Above is the Fourier Expansion of the wave function  $ \psi(x) $, and  $ \varphi(k) $