## Question: Classical or Quantum?

Why bother to treat the light field classically (classical optics) since we have a more accurate description quantum mechanically. (Quantum optics)

Answer:

1. Quantum theory is though more accurate, but also more complicated.

In many cases, the classical theory is much simple, as well as

2. Accurate: If we treat the statistical behavior (such as average) of large number of photons, the classical Electro-Magnetic theory is good enough.

For Example: In spectroscopy, the light field (laser or conventional source) is treated classically, i.e. the effect of many photons can be represented very accurately by the classical electro-magnetic field; the atoms/molecules are treated quantum mechanically and this is called semi-classical theory.

In most of this course, we are going to deal with the situations where  $ \underline{\text{Light can be treated as Electro-Magnetic wave}} $ (obeying Maxwell equation).

It is instructive to first review some general properties of wave as Chapter 2 in Hecht's book