There are ways to overcome the Doppler broadening, the most straightforward is to cool the atom/molecule to low temperature; another clever technique is saturated absorption.

##  $ ^{*} $Supplement1: Saturated absorption to get rid of Doppler broadening

As the figure below demonstrates, this is using the effect we call saturation, i.e. if the atoms are shined with a strong light, it will absorb that light, so that the number of atoms at ground state will decrease $ ^{2} $. Now if we introduce another weaker light beam simultaneously passing the atoms, this weak light beam will be much less absorbed due to the decrease of the available ground state atoms.

<div style="text-align: center;"><img src="imgs/img_in_image_box_180_603_973_996.jpg" alt="Image" width="66%" /></div>


In the above figure, the laser (ECDL in the figure) generate an output whose frequency can be scanned (means adjusted continuously). The laser output was separated into 3 parts by the beam splitter: The strongest one (90% of energy, the thick red line) will be acting like saturation beam; two weaker lights will pass the atomic cell as reference and probe beam. The trick is to arrange the saturation beam overlapping with one of the weaker beam (the lower one in the figure, and this weak beam is termed probe in this case) in the head-to-head configuration. The other weak beam that does not overlap with saturation is then the reference beam.

The reference beam will then experience no saturation effect and its absorption would be the regular one with Doppler broadening: As the figure below shows (which shows F=2 and F=1 transition for both R 87 and Rb85 isotopes so total of four bands). Under each of these bands there are fine structures hidden, say under the leftmost