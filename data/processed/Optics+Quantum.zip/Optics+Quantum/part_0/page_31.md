 $$ d N=\rho(v)d v $$ 

k: Boltzmann constant.

m: mass of single particle.

 $ \Delta v $ is the full width at half maximum (FWHM)

Then the line width (FWHM) due to Doppler Broadening is:

 $$ \frac{\Delta\nu}{\nu_{0}}=\frac{\Delta\nu}{\nu}=\frac{2\sqrt{2\ln2}}{\nu}\sqrt{\frac{kT}{m}} $$ 

Such broadening can be quite nuisance to spectroscopicist, since it will smear out many fine structures of close lying atomic/molecular energy levels.

For example: the hyperfine structure of atomic lines.

Use  $ ^{87}Rb $ as example.

<div style="text-align: center;"><img src="imgs/img_in_image_box_176_1013_1000_1524.jpg" alt="Image" width="69%" /></div>


but due to Doppler broadening, only two broad features observed in conventional spectroscopy.

observed broad feature.

(Fine structures are buried under it)