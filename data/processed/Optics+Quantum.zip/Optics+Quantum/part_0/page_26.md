<div style="text-align: center;"><img src="imgs/img_in_image_box_225_158_456_460.jpg" alt="Image" width="19%" /></div>


(Fig 2.20, pg 25 Hecht)

 $$ \psi(r,t)=A e^{i(\vec{k}\bullet\vec{r}-\omega t)}=A e^{i(k_{x}x+k_{y}y+k_{z}z-\omega t)} $$ 

Where

 $$ \left|k\right|=\sqrt{k_{x}^{2}+k_{y}^{2}+k_{z}^{2}}=\frac{2\pi}{\lambda} $$ 

 $$ \nu_{\varphi}=\frac{\omega}{k} $$ 

The more general plane waves that are solutions of equation (1-2)

 $ \nabla \psi(r,t) = \frac{\partial^2 \psi}{\partial t^2} $ is given in (2-66) of Hecht's book, which can be

treated as superposition of harmonic plane waves.

1-7-2 Spherical waves: waves from an isotropic point source.

The wave equation for an isotropic point source:  $ \underline{\text{(Hecht eqn. 2.70)}} $

$$\frac{1}{r}\frac{\partial^{2}}{\partial r^{2}}=\frac{1}{\nu^{2}}\frac{\partial^{2}\psi}{\partial t^{2}}\ \text{in spherical coordinate.}$$

The general solution is of the form of  $ \underline{\text{(Hecht's eqn. 2.73)}} $

The spherical wave has characters:

(1). Wave front is a sphere