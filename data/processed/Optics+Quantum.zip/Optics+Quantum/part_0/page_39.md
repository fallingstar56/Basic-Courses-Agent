n is called the index of refraction (or refractive index).

n is a function of  $ \omega $, the dependence of n with frequency of light is called  $ \underline{\text{dispersion}} $. In a media, light travels at less speed than vacuum, and light with different freq. travels at different speed.

Explain (as an exercise) the seemingly difference between the measured n and  $ \sqrt{\varepsilon\mu} $, where  $ \varepsilon $,  $ \mu $ are  $ \underline{\text{static}} $ dielectric and magnetic coefficient. (Hecht's pg66)

<div style="text-align: center;">TABLE 3.2 Maxwell's Relation</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="3">Gases at 0°C and 1 atm</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Substance</td><td style='text-align: center; word-wrap: break-word;'>$ \sqrt{K_{E}} $</td><td style='text-align: center; word-wrap: break-word;'>n</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Air</td><td style='text-align: center; word-wrap: break-word;'>1.000294</td><td style='text-align: center; word-wrap: break-word;'>1.000293</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Helium</td><td style='text-align: center; word-wrap: break-word;'>1.000034</td><td style='text-align: center; word-wrap: break-word;'>1.000036</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Hydrogen</td><td style='text-align: center; word-wrap: break-word;'>1.000131</td><td style='text-align: center; word-wrap: break-word;'>1.000132</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Carbon dioxide</td><td style='text-align: center; word-wrap: break-word;'>1.00049</td><td style='text-align: center; word-wrap: break-word;'>1.00045</td></tr></table>

<div style="text-align: center;">Liquids at  $ 20^{\circ} $C</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Substance</td><td style='text-align: center; word-wrap: break-word;'>$ \sqrt{K_{E}} $</td><td style='text-align: center; word-wrap: break-word;'>n</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Benzene</td><td style='text-align: center; word-wrap: break-word;'>1.51</td><td style='text-align: center; word-wrap: break-word;'>1.501</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Water</td><td style='text-align: center; word-wrap: break-word;'>8.96</td><td style='text-align: center; word-wrap: break-word;'>1.333</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Ethyl alcohol (ethanol)</td><td style='text-align: center; word-wrap: break-word;'>5.08</td><td style='text-align: center; word-wrap: break-word;'>1.361</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Carbon tetrachloride</td><td style='text-align: center; word-wrap: break-word;'>4.63</td><td style='text-align: center; word-wrap: break-word;'>1.461</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Carbon disulfide</td><td style='text-align: center; word-wrap: break-word;'>5.04</td><td style='text-align: center; word-wrap: break-word;'>1.628</td></tr></table>

<div style="text-align: center;">Solids at room temperature</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Substance</td><td style='text-align: center; word-wrap: break-word;'>$ \sqrt{K_{E}} $</td><td style='text-align: center; word-wrap: break-word;'>n</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Diamond</td><td style='text-align: center; word-wrap: break-word;'>4.06</td><td style='text-align: center; word-wrap: break-word;'>2.419</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Amber</td><td style='text-align: center; word-wrap: break-word;'>1.6</td><td style='text-align: center; word-wrap: break-word;'>1.55</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Fused silica</td><td style='text-align: center; word-wrap: break-word;'>1.94</td><td style='text-align: center; word-wrap: break-word;'>1.458</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Sodium chloride</td><td style='text-align: center; word-wrap: break-word;'>2.37</td><td style='text-align: center; word-wrap: break-word;'>1.50</td></tr></table>

Values of  $ K_E $ correspond to the lowest possible frequencies, in some cases as low as 60 Hz, whereas  $ n $ is measured at about  $ 0.5 \times 10^{15} $ Hz. Sodium D light was used ( $ \lambda = 589.29 $ nm).

(Hecht Optics 4th edition)