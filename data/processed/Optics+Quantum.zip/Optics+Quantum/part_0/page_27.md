(2). The amplitude  $ \propto \frac{1}{r} $

The special case of harmonic spherical wave is:

 $$ \psi(r,t)=\frac{A}{r}e^{i(k r\mp\omega t)} $$ 

Here the A/r in (1-8) is the amplitude of the field, and drops as distance increases. The A is called source strength whose physical meaning is related to the power emitted by the source (energy flow out of the source/unit time), which can be readily seen using energy flow formula (Poynting vector next chapter). The drop of the amplitude with distance r is a requirement of energy conservation as we shall see that the energy flux (energy flow/unit area.unit time) will be proportional to the square of the amplitude for the wave.

At large r, spherical wave and plane wave would be similar.

## 1 -8 Doppler Effect:

When we talk about the frequency of a wave above, we presume that the observer is stationary relative to the wave source. If the source and the observer are in relative motion, the observed frequency will be different from that in stationary---Doppler Effect. This is familiar phenomenon even in daily life, as well as has scientific significance.