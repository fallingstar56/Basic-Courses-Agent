The most general solution for wave equation (1-1) will be in the form of  $ \psi(x,t)=F(x-vt)+G(x+vt) $ where the functional form of F and G need to be determined by the initial conditions and boundary value, which will not be fully discussed in our course. It requires Fourier Transform we shall discuss in the later part of the course $ ^{1} $. We shall focus on some simple forms of the solution, as the next section concerns.

## 1 -3 Harmonic waves (a quick summary)

(1) This is the simplest as well as a very important form of wave.

(2) Any other wave function  $ \psi(x,t) $ can be represented as a superposition of such harmonic waves. (Fourier Expansion)

For a harmonic wave (1-dimension):

 $$ \psi(x,t)=A\cos k(x-v t) $$ 

Or  $ \psi(x,t)=A\cos(kx-\omega t) $

Then:  $ \omega = k\nu \Rightarrow \nu = \frac{\omega}{k} $

 $$  Where\ k=\frac{2\pi}{\lambda}=2\pi\overline{v};\omega=2\pi\upsilon=\frac{2\pi}{T} $$ 

The k is wave vector (in l-D is just a number);  $ |k| $ is the angular