<div style="text-align: center;"><img src="imgs/img_in_image_box_392_242_722_380.jpg" alt="Image" width="27%" /></div>


The red phasor represents  $ \tilde{\psi}_{1} $, green represents  $ \tilde{\psi}_{2} $, the blue is the summation. In the convention we choose  $ (e^{-i\omega t}) $, the phasor will rotate clockwise with  $ \omega $. It is a simple geometry problem to find the expression of the blue phasor:

Its argument (angle) is  $ \frac{\phi}{2} $ (it lags in phase comparing the red one  $ \tilde{\psi}_1 $ by this  $ \frac{\phi}{2} $), it also rotates clockwise with same angular frequency  $ \omega $, so the phase part is:  $ e^{-i\omega t} e^{i\frac{\phi}{2}} $

Its amplitude is given by cosine laws of triangle:

 $$ |\tilde{\psi}|=\sqrt{A^{2}+A^{2}+2A^{2}\cos\phi}=\sqrt{2A^{2}(1+\cos\phi)}=\sqrt{4A^{2}\cos^{2}(\frac{\phi}{2})} $$ 

I hope through this simple example I convince you the equivalence of these methods. The complex or phasor (the phasor one is just geometrical variation of the complex method) method will be preferred in this course because the complex expression of wave finds wider application in physics as I mentioned earlier.