In the following sections when we are only interested in the relative intensity in same media, the propotinonal constatnt in front will be same, so I will often just use  $ I = |E|^2 = |E_0|^2 $.

One word of comment: this will make dimension analysis a nightmare since I neglect the unit of the proportion constant, and when you really care about the absolute value of intensity, of course you should use formula in (2-13).

*Supplement: Energy of the E-M field and energy flux (the Poynting vector)

I did not give the derivation in the notes above, since this is usually given in E-M class. The derivation below is mainly for self-containment.

The energy of the field can be understood from the work-energy theorem, i.e. the work done by (or to) the field equals the energy change of the field. The force here during the interaction between the field and the matter would be Lorentz force:

Suppose the field is created by certain charge-current configuration and if some free charges move a small distance, dl, and then the work done by the field is:

 $$ d W_{work}=\vec{F}\cdot d\vec{l}=q(\vec{E}+\vec{v}\times\vec{B})\cdot\vec{v}dt=q\vec{E}\cdot\vec{v}dt,with q=\rho d V,and\rho\vec{v}=\vec{j} $$ 

Where  $ \rho $ volume charge density and j is the current density. Then the total power (dW/dt) is:

$$P_{workpower} = \iiint_V \vec{E} \cdot \vec{j} dV \, , \quad j = \nabla \times H - \frac{\partial D}{\partial t} \quad (I \text{ did not put the little arrow on the vector for time saving, and I hope this would not cause confusion})$$