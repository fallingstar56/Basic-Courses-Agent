From the Doppler shift, we can conclude that the expansion of the universe. The further the star away from earth, the faster it is moving away.

(2). Doppler broadening of spectral line.

—A nuisance to spectroscopic and the ways to overcome it.

<div style="text-align: center;"><img src="imgs/img_in_image_box_173_548_998_882.jpg" alt="Image" width="69%" /></div>


what is the absorption spectra

would look like for a ensemble of

such atoms at Room T.

Ideally, if all atoms are motionless, they

will absorb at single frey.

So ideally the atomic absorption line of the simplified energy structure involved (only two levels: ground and excited) should be a single dip in spectrum. However, atoms are moving around:

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_1158_941_1270.jpg" alt="Image" width="59%" /></div>


For atom 2 which moves towards light, it will experience a shift to higher frequency (blue shift, all the frequencies here are referring to the frequency stationary to the source), If the light frequency is  $ \upsilon_{0} $, atoms 2 would feel as if  $ \upsilon_{0} + \Delta \upsilon $, it will then not absorb at this frequency. It will