## 1 -7 Plane waves and Spherical waves

(Hecht's p25-31. Zhao's p140-p148)

The simple harmonic wave treated above is 1-dimensional.

Its equivalence in 3-dimensional case is harmonic plane wave.

General harmonic wave has the form of: (monochromatic wave)

 $$ \psi(r,t)=A(r)e^{i\varphi(r,t)}=A(r)e^{i\varphi(r)}e^{-i\omega t} $$ 

Concept of wave front: the surface that the phases of points on it are equal.

1-7-1 A harmonic plane wave (in 3-D) is defined as:

(1). The amplitude A(r) is constant for all r.

(2). The wave front at certain time is a plane  $ \perp $ propagation vector k

 $ \varphi(r) = k \bullet \vec{r} $ satisfies the requirement, geometrically,  $ \vec{k} \cdot \vec{r} = $ constant is a plane perpendicular to vector k.

Thus a harmonic plane wave is: