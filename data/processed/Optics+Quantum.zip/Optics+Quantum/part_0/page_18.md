is still true) we need nonlinear optics to solve such problems which is out of the scope of this course. The systems considered in this class are all treated as linear systems, i.e. the E fields are all weak enough to safely neglect higher order contributions in the response.

## 1 -6 Complex Representation and Phasors

Sinusoidal representation of harmonic waves, though simple in itself, it can be awkward in algebra manipulation, such as addition and multiplication, the complex representation of waves is  $ \underline{\text{physically equivalent}} $ but  $ \underline{\text{mathematically simple}} $ description of waves.

 $$ \begin{array}{l} \text{Euler formula: } e^{i\theta} = \cos\theta + i\sin\theta \\ \text{A(p)cos}\left[\varphi(p,t)\right] \quad \varphi(p,t) \xlongequal{1-\dim} kx + \varphi_{0} - wt \\ \quad = \varphi(p) - wt \\ \quad \Delta\varphi\left[x_{1}-x_{0}\right),t_{0} \quad \stackrel{x_{1}>x_{0}}{>} o \\ \quad \text{The phase at } x_{1} \gg x_{0} \quad \text{actually} \\ \quad \underline{\text{Lacks}} \quad \text{in phase compared with } x_{0}. \\ \quad \Delta\varphi\left[(x_{1}-x_{0}),t_{0}\right] < \bullet \quad \text{for } x_{1}<x_{0} \\ \quad \text{but the phase at } x_{1} \quad \text{Leads that at } x_{0}. \\ \quad \text{Similar arguments applies for} \\ \quad \times \text{fixed, } t \text{ varies.} \end{array} $$ 

So with this complex convention  $ (e^{i\varphi(p,t)} $ instead of  $ e^{-i\varphi(p,t)} $ as we discussed previously with sinusoidal case)