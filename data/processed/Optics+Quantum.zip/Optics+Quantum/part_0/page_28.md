<div style="text-align: center;"><img src="imgs/img_in_image_box_298_184_586_376.jpg" alt="Image" width="24%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_682_177_1048_275.jpg" alt="Image" width="30%" /></div>


What are the frequencies experienced by 2 and 3 in the above figure? It is going to be shifted from  $ \upsilon_{0} $, the  $ \upsilon_{0} $ is the frequency experienced by 1 which is stationary to the light source.

The shift in frequency is given by:

 $$ \frac{\Delta\upsilon}{\upsilon_{0}}=\pm\frac{\nu}{\nu_{0}}=\frac{-\vec{\nu}\bullet\hat{n}_{0}}{\left|\vec{\nu}_{0}\right|} $$ 

 $ \hat{n}_{0} $ is a unit vector representing direction of wave vector k. We see that in 1-D case what is important is the motion along the direction of wave propagation.

The derivation of the Doppler Effect had been extensively carried out in my notes on special relativity and one version is supplied below in supplement. There is also 2-D Doppler Effect and we will not consider here in this course.

The Doppler Effect finds its way in many scientific applications, among them are:

(1). Big Bang Theory