 $$ \Rightarrow p_{v}=\frac{S}{C^{2}} $$ 

From the photon picture, each photon carries energy:

 $$ E=h\upsilon=\hbar\omega $$ 

Then from 2-14, the momentum of each photon would be :

 $$ \begin{aligned}&p=\frac{E}{c}=\frac{h}{\lambda}=\hbar k\\ &\\ Or\quad\vec{p}=\hbar\vec{k}\\ \end{aligned} $$ 

If the photon number density is n (number of photons per volume), then the energy flux density will be: $S = n\hbar\omega c$, and the momentum density will be $p_v = n\hbar k$, and we will have exactly same relation as (2-17) from this photon’s point of view.

Comments:

(1) The momentum of light (E-M field ) is simple to visualize using the photon picture, just as air pressure is created from collision of molecules with the surface, the light pressure is created by the change of photon momentum.

(2) Classically, the momentum of the E-M field can be understood from Lorentz Force:

 $$ F=q(\vec{E}+\vec{\nu}\times\vec{B})\qquad\qquad\mathrm{f o r~c h a r g e d~p a r t i c l e} $$ 