absorb at light frequency  $ \nu_0 - \Delta \nu $. Similarly, atom 3 would absorb at  $ \nu = \nu_0 + \Delta \nu $, where  $ \Delta \nu $ is given by (1-9), the Doppler shift formula. The absorption would be something shown in the figure below.

As there is a distribution (Boltzmann distribution) of velocities that atoms are traveling at certain T, the absorption spectrum will reflect such distribution, and the spectral line would be broadened. This is called Doppler broadening

<div style="text-align: center;"><img src="imgs/img_in_image_box_281_570_826_826.jpg" alt="Image" width="45%" /></div>


The real situation involves many atoms/molecules whose velocity has a continuous distribution at certain temperature. From Boltzmann distribution of velocity of atoms/molecules (here only consider 1-D, the direction along the light propagation), we can derive line width due to Doppler broadening.

<div style="text-align: center;"><img src="imgs/img_in_image_box_187_1184_507_1326.jpg" alt="Image" width="26%" /></div>


 $$ \rho(\nu)=e^{\frac{-\frac{1}{2}mv^{2}}{(\frac{kT}{}})} $$ 

 $$ \Delta\nu=\frac{2\sqrt{(2\ln2)kT}}{\sqrt{m}} $$ 

 $ \rho(v) $ is the probability density of atoms at velocity v, i.e. the number of atoms dN with velocity v in the small interval dv around it is: