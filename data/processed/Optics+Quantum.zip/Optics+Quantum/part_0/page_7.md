## Chapter 1 General Properties of Wave

## 1 -1 Physical Feature:

Classically:

Particle: Localized quantity (or property), recall a mass point.

Wave: non-localized, recall a sound wave etc.

Such classical distinction between wave & particle will fail in quantum theory.

## 1 -2 Mathematical Description of Wave-----Differential Wave Equation

 $ \psi(x,t) $: 1-dimension wave function, represents a spatial distribution and time evolution of wave:

 $$ \frac{\partial^{2}\psi(x,t)}{\partial x^{2}}=\frac{1}{\nu^{2}}\frac{\partial^{2}\psi(x,t)}{\partial t^{2}} $$ 

v in the  $ (1-1) $ is the velocity of the wave.

For 3-dimensional case, wave equation is:

 $$ \nabla^{2}\psi(r,t)=\frac{1}{\nu^{2}}\frac{\partial^{2}\psi(r,t)}{\partial t^{2}} $$ 