## 1 -4 Phase and Phase velocity

 $$ \psi(x,t)=A\cos(kx-\omega t+\varepsilon_{_{0}}) $$ 

A: is the amplitude

Phase:  $ kx - \omega t + \varepsilon_{0} \equiv \phi(x, t) $;  $ \varepsilon_{0} $ is called initial phase

Phase velocity: Refer to fig.1 above.

For the two points on the two curves at different times  $ (x_{0},t_{0}) $,  $ (x_{0}+\Delta x,t_{0}+\Delta t) $ they have equal phase, thus equal  $ \varphi(x,t) $ means:

 $$ k x_{_{0}}-\omega t_{_{0}}+\varepsilon_{_{0}}=k(x_{_{0}}+\Delta x)-\omega(t_{_{0}}+\Delta t)+\varepsilon_{_{0}} $$ 

 $$ \frac{\Delta x}{\Delta t}=\frac{\omega}{k}=v_{\varphi} $$ 

$$(\frac{\partial x}{\partial t})_{\varphi} = \frac{\omega}{k} = \nu_{\varphi} \quad \leftarrow \text{Propagation speed of points with equal case.}$$

phase.

Another more general derivation is given in Hecht’s Book (pg19)

 $$ \left(\frac{\partial x}{\partial t}\right)_{\varphi}=\frac{-(\frac{\partial\varphi}{\partial t})_{x}}{(\frac{\partial\varphi}{\partial x})_{t}}=\frac{\omega}{k}=v_{\varphi} $$ 

(The reason for the minus sign in the second part is from math on partial derivative, it can be proved by using chain rule:  $ d\varphi = \left(\frac{\partial\varphi}{\partial x}\right)_t dx + \left(\frac{\partial\varphi}{\partial t}\right)_x dt $, please carry out yourself)