is the weighting factor of the  $ k^{th} $ component, it is the expansion coefficient and also termed Fourier transform of  $ \psi(x) $. There is a famous and important relation between the distribution width between original wave function  $ \psi(x) $ and its Fourier Transform  $ \varphi(k) $:

 $$ \Delta k\Delta x\approx2\pi $$ 

And in the above wave train  $ \Delta x = L $

As L→large,  $ \Delta k \approx 0 \rightarrow \psi(x) \rightarrow \cos kx $

we see as L becomes large, the wave train approaches a harmonic wave, and this is called quasi-monochromatic.

Comment 2: The phase signs and relation with phase lead or lag

In this course, very often we will compare the phase difference between two or more waves, from their phase difference we may say certain wave is leading or lagging in phase comparing with others. Here I shall discuss in detail about the relation of phase difference and lagging-leading in phase.

(1)We use sinusoidal function (or complex function) to represent a wave, there is a choice of sign for the phase part:

 $ E(z,t) = A\cos(kz - \omega t + \delta) $ is the  $ \underline{\text{conventional}} $ choice for a traveling wave along the +z direction (another choice is to put a minus sign inside the Cosine, since  $ \cos(\theta) = \cos(-\theta) $ this will give same physical results with physical reality attached to different signs). In this choice, the phase