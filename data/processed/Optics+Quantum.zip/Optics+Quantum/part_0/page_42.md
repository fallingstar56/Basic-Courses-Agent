 $$ H=\frac{n}{\sqrt{\frac{\mu_{0}}{\varepsilon_{0}}}}E $$ 

 $$ \sqrt{\frac{\mu_{0}}{\varepsilon_{0}}}=377\Omega $$ 

vacuum Impendence

So the magnetic field usually much smaller than the  $ \vec{E} $, and that’s why people usually concentrate on the electric aspect of the Electro-Magnetic waves. But this is not a very good argument since E and B field are in different units. The correct argument that why most materials respond strongly to electric field is because: The force of interaction between the charges with the field, which is the Lorentz force:

 $ F = q(\vec{E} + \vec{v} \times \vec{B}) $, since  $ |E| = c|B| $, and generally  $ v \ll c $, so the first term in Lorentz force which corresponds to the interaction of charge with the E field is much larger than the second term. (E and v x B have same units now and comparison becomes meaningful)

## 2 -4 Energy carried by E-M wave

The energy carried by E-M wave is specified by Poynting vector, defined as:

 $$ \vec{S}=\vec{E}\times\vec{H}\ (\mathrm{In\ unit\ ofWatts/m^{2}}) $$ 

It is the energy flow per unit area, per unit time, and is also called energy flux density (flux the flow across a surface per unit time, here we have