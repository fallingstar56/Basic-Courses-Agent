 $$ \therefore\vec{k}\times\vec{E}=\mu\omega\vec{H} $$ 

Similarly from other M-equations:  $ \vec{k} \times \vec{H} = -\varepsilon \omega \vec{E} $

 $$ \vec{k}\bullet\vec{E}=\vec{k}\bullet\vec{H}=0 $$ 

Thus:

(1)  $ \vec{E}, \vec{H}, \vec{k} $ are mutually perpendicular, and form a right-hand Cartesian coordinate system.

 $$ \vec{E}\times\vec{H}\rightarrow\vec{k} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_214_675_394_822.jpg" alt="Image" width="15%" /></div>


(2)Relation between  $ \vec{E} $,  $ \vec{H} $'s amplitude.

From (2-9)  $ \vec{k} \times \vec{E} = kE = \mu \omega H $

 $$ \Longrightarrow E=\frac{\mu\omega}{k}H=\mu c H=c B $$ 

 $$ \begin{aligned}&\because\quad c=\frac{1}{\sqrt{\varepsilon\mu}}\\ &\\ &\Rightarrow E=\sqrt{\frac{\mu}{\varepsilon}}H\approx\sqrt{\frac{\mu_{0}}{\varepsilon}}H=\sqrt{\frac{\mu_{0}}{K_{E}\varepsilon_{0}}}H\\ \end{aligned} $$ 

 $$ \because n=\sqrt{K_{_{E}}} $$ 