4-13 Aberration ..... - 149     
Chapter 5 Interference, Interferometer and Coherence ..... - 153     
5-1 Superposition of Waves ..... - 154     
5-1-1 Superposition principle in linear optics ..... - 155     
5-1-2 Superposition of Waves with same ω, Parallel ∇₀ ..... - 157     
5-1-3 Standing Waves ..... - 158     
5-1-4 The addition of waves of different frequency ..... - 162     
5-2 Interference and Coherence ..... - 169     
5-3 Wavefront Splitting Interference ..... - 175     
5-3-1 Interference of Two Point Sources ..... - 175     
5-3-2 Young’s Experiment ..... - 177     
5-3-3 A more Strict and Systematic Treatment ..... - 180     
5-4 Amplitude Splitting Interferometer--Interference by Thin film ..... - 185     
5-4-1 Fringes of Equal Thickness ..... - 187     
5-4-2 Fringes of equal inclination ..... - 190     
5-4-3 Michelson Interferometer ..... - 192     
5-5 Multiple Beam interference and Fabry-Perot interferometer ..... - 197     
5-5-1 Fabry-Perot Interferometer ..... - 201     
5-6 Coherent Theory ..... - 206     
5-6-1 Extended Monochromatic Source and Spatial Coherence ..... - 208     
5-6-2 Effect of Non-Monochromatic Light---Temporal Coherence ..... - 211     
5-6-3 Correlation Function — Formal treatment of Coherence ..... - 217     
Chapter 6 Diffraction ..... - 229     
6-1 What’s Diffraction ..... - 229     
6-1-1 Definition ..... - 229     
6-1-2 Fraunhoffer and Fresnel Diffraction ..... - 232     
6-2 Huygens-Fresnel Principle (HFP) and Kirchhoff equation ..... - 234     
6-3 Fresnel Diffraction through an open aperture ..... - 235     
6-3-1 Method of Half-Wavelength (λ/2) Plate ..... - 236     
6-3-2 Phasor Treatment and Vibrational Spirals (curves) ..... - 241     
6-3-4 Babinet Principle ..... - 245     
6-3-5 Fresnel Zone Plate ..... - 246     
6-4 Fraunhoffer Diffraction by Single Slit ..... - 249     
6-4-1 Single Slit ..... - 250     
6-4-2 Rectangular Aperture ..... - 253     
6-4-3 The Characteristic of Diffraction Distribution ..... - 255     
6-4-4 Fraunhoffer Diffraction by Circular Aperture and Image Resolution ..... - 258     
6-5 Diffraction by Many Slits (Fraunhoffer Type) ..... - 262     
6-5-1 Fraunhoffer-Diffraction by Many Slits ..... - 262     
6-5-2 Diffraction Grating and Grating Spectrometer ..... - 272     
Chapter 7 Fourier Optics ..... - 285     
7-1 Fourier Expansion (Fourier Series) and Fourier integrals ..... - 285     
7-1-1 Fourier Expansion of a Periodic Function ..... - 287 -