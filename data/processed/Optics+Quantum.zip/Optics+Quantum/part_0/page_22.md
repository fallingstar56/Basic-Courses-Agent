 $$ \psi_{2}=A\cos(k x-\omega t+\phi) $$ 

For simplicity I also set the two waves with same amplitude, but a phase difference  $ \phi $. I shall consider their superposition at a certain point and will choose that point as origin, i.e. x=0 point. Thus the waves at that point will be (adding two oscillations at that point):  $ \psi_1 = A \cos(-\omega t) $,  $ \psi_2 = A \cos(-\omega t + \phi) $, and their sum will be:

### I. Sinusoidal expression

 $$ \psi=\psi_{1}+\psi_{2}=A\cos(-\omega t)+A\cos(-\omega t+\phi) $$ 

 $$  Using cosine formula:\cos\alpha+\cos\beta=2\cos(\frac{\alpha+\beta}{2})\cos(\frac{\alpha-\beta}{2}) $$ 

(in case you forgot above formula, try proving it with Euler formula)

 $$ \psi=2A\cos(-\frac{\phi}{2})\cos(-\omega t+\frac{\phi}{2})=2A\cos(\frac{\phi}{2})\cos(\omega t-\frac{\phi}{2}) $$ 

The instantaneous intensity is:

 $$ |\psi|^{2}=4A^{2}\cos^{2}(\frac{\phi}{2})\cos^{2}(\omega t-\frac{\phi}{2}) $$ 

The average of the intensity (assume  $ T \gg \frac{2\pi}{\omega} $, then average over  $ \cos^2 $ term will give  $ 1/2 $ because  $ \cos^2 \alpha = \frac{1 + \cos 2\alpha}{2} $):

 $$ I=<\left|\psi\right|^{2}>=2A^{2}\cos^{2}(\frac{\phi}{2}) $$ 