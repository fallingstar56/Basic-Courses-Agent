wave number;  $ \bar{\nu} = \frac{1}{\lambda} $ is the wave number; T is the period;  $ \upsilon = \frac{1}{T} $ is the frequency;  $ \omega $ is the angular frequency;  $ \nu = \frac{\omega}{k} $ is the phase velocity.

Given any two of $\omega$, $k$, $v$ (or $v$, $\lambda$, $v$ ..... ), you can calculate the other.

A wave has both spatial and temporal period.

<div style="text-align: center;"><img src="imgs/img_in_image_box_290_618_783_810.jpg" alt="Image" width="41%" /></div>


Fixed spatial point,  $ x = x_{0} $

Fig 1.

<div style="text-align: center;"><img src="imgs/img_in_image_box_324_845_711_985.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;">Fig2.7 (pg17, Hecht) can be used as depicting generation of a harmonic wave from a harmonic oscillation source.</div>


*Comment1: the harmonic waves represented by (1-3) are an idealized case, i.e. it is not realizable in real case. It is a wave with single frequency. To have this frequency defined, the wave train has to extend from  $ -\infty $ to  $ +\infty $ in space and time domain (that is how mathematically defining a periodic function). Such wave is called  $ \underline{\text{Monochromatic Wave}} $. (Since color is related to frequency, and single frequency is also called