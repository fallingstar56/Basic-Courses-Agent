This simple calculation will be used often later, and its physical interpretation is clear. It shows adding two waves with same frequency, amplitude but with a phase difference will result in another wave of same frequency and a phase difference in half; what is more important is the effect of phase difference on the amplitude. When the phase difference is 0 (in phase) the amplitude is largest, the two waves add constructively; when the phase difference is  $ \pi $, the two wave cancel each other result in 0 amplitude, add up destructively.

### II. Euler Formula

Now let me work the same problem with complex expression:

 $$ \tilde{\psi}_{1}=A e^{-i\omega t};\quad\tilde{\psi}_{2}=A e^{-i\omega t}e^{i\phi} $$ 

 $$ \tilde{\psi}=\tilde{\psi}_{1}+\tilde{\psi}_{2}=A e^{-i\omega t}(1+e^{i\phi})=A e^{-i\omega t}e^{i\frac{\phi}{2}}(e^{-i\frac{\phi}{2}}+e^{i\frac{\phi}{2}})=2A\cos\frac{\phi}{2}e^{-i\omega t}e^{i\frac{\phi}{2}} $$ 

If we take the real part, we will get back the sinusoidal result.

Average intensity is proportional to:

 $$ I\propto\tilde{\psi}\tilde{\psi}^{*}=|\tilde{\psi}|^{2}=4A^{2}\cos^{2}(\frac{\phi}{2}) $$ 

(Take 1/2 of it will give us the average intensity as I discussed in the comment in last section)

### III. Phasor method