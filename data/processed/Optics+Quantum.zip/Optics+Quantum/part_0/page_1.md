## Contents

Chapter 1 General Properties of Wave ..... - 3     
1-1 Physical Feature: ..... - 3     
1-2 Mathematical Description of Wave-----Differential Wave Equation ..... - 3     
1-3 Harmonic waves (a quick summary) ..... - 5     
1-4 Phase and Phase velocity ..... - 11     
1-5 Superposition Principle ..... - 12     
1-6 Complex Representation and Phasors ..... - 14     
1-7 Plane waves and Spherical waves ..... - 21     
1-8 Doppler Effect: ..... - 23     
Chapter2 Light as Electro-Magnetic Wave ..... - 32     
2-1 Maxwell Equation and Electro-Magnetic Wave ..... - 32     
2-2 Speed of light ..... - 34     
2-3 Transverse Wave ..... - 36     
2-4 Energy carried by E-M wave ..... - 38     
2-5 Momentum of E-M Field ..... - 41     
2-6 Photons ..... - 45     
2-7 Radiation (light) sources——A classical treatment ..... - 45     
2-8 One Word on Polarization ..... - 51     
Chapter 3 The propagation of Light ..... - 58     
3-1 Treatise Based on Macroscopic Observations ..... - 59     
3-2 Huygens's Principle ..... - 61     
3-3 Fermat's Principle ..... - 63     
3-4 Two examples using Snell's equation ..... - 67     
3-5 Propagation of Light from Scattering Point of View ..... - 70     
3-6 Fresnel Equations ..... - 77     
3-6-1 Amplitude, Brewster angle and Total Internal Reflection ..... - 82     
3-6-2 Phase shift ..... - 84     
3-6-3 Stokes Relation ..... - 87     
3-6-4 Evanescent Wave ..... - 90     
Chapter 4 Geometric Optics ..... - 95     
4-1 Jargons in geometric optic ..... - 97     
4-2 Fermat's Principle ..... - 100     
4-3 Refraction at a Single Spherical Surface ..... - 102     
4-4 Paraxial Approximation ..... - 103     
4-5 Finite Imagery and Transverse Magnification ..... - 110     
4-6 Multiple Surfaces and Lagrange-Helmholtz Relation ..... - 113     
4-7 Thin Lens ..... - 115     
4-8 Thin lens combination ..... - 120     
4-9 Thick Lenses and Lens System ..... - 121     
4-10 Graphical Method of Image Formation ..... - 127     
4-11 Analytical Ray Tracing and Matrix Method ..... - 130     
4-12 Apertures ..... - 139 -