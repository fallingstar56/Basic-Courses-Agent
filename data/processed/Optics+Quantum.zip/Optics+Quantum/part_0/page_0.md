LectureNote on GP3

By Shuo Jiang

Tsinghua University