## Electrodynamics)

Comment: Above I expressed M-equations using E and H vectors, which is not the usual fundamental forms. (The reason I use E, H is because they are mostly specified in real experiments, since you manipulate E by potential and H by free current) The equations in the note are correct and so are the derivations from there. They are one of the variations of the fundamental M-equations in a homogeneous media, applying the media relation (for linear media) between E and D, B and H:

 $$ \vec{D}=\varepsilon\vec{E};\ \vec{B}=\mu\vec{H}\ \left(\mathrm{in some books}\ \varepsilon=\varepsilon_{r}\varepsilon_{0};\mu=\mu_{r}\mu_{0};\varepsilon_{r}=1+\chi_{e}=K_{E};\mu_{r}=1+\chi_{m}=K_{M}\right) $$ 

Here just for self-containment, I also include the M-equations in its fundamental forms:

 $$ \nabla\bullet\vec{E}=\rho\bigg/\varepsilon_{0};\quad\nabla\bullet\vec{B}=0 $$ 

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t};\ \nabla\times\vec{B}=\mu_{0}j+\mu_{0}\varepsilon_{0}\frac{\partial\vec{E}}{\partial t} $$ 

In vacuum, the charge and current would be simply the free charge and current. In a media, however, the charge and current should include bound charges and induced currents. To simplify the matter to only count the free charge and current, two auxiliary vectors are introduced; the D and H, and the M-equations in a media are usually in the form of:

 $$ \nabla\bullet\vec{D}=\rho_{_{free}};\quad\nabla\bullet\vec{B}=0 $$ 

 $$ \nabla\times\vec{E}=-\frac{\partial\vec{B}}{\partial t};\ \nabla\times\vec{H}=j_{free}+\frac{\partial\vec{D}}{\partial t} $$ 

With the E, D and B, H relation given above.

(2) Electro-Magnetic Wave

Since.  $ \nabla \times (\nabla \times) = \nabla (\nabla \bullet \nabla^2 (\nabla \cdot \nabla \times)) = \nabla \times (\nabla \times) = \nabla \times (\nabla \times) = \nabla \times (\nabla \times) $

Then:  $ \nabla \times (\nabla \times \vec{E}) = \nabla \left( \nabla \bullet \vec{E} \right) - \nabla^2 \vec{E} = -\nabla^2 \vec{E} $

From Maxwell Equation: