 $$ \nabla\times(\nabla\times\vec{E})=-\mu_{0}\frac{\partial\left(\nabla\times\vec{H}\right)}{\partial t}=-\varepsilon_{0}\mu_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}} $$ 

 $$ \therefore\nabla^{2}\vec{E}=\varepsilon_{0}\mu_{0}\frac{\partial^{2}\vec{E}}{\partial t^{2}} $$ 

Likewise:

 $$ \nabla^{2}\vec{H}=\varepsilon_{0}\mu_{0}\frac{\partial^{2}\vec{H}}{\partial t^{2}} $$ 

(2-5), (2-6) are just standard wave equations.

So,  $ \vec{E} $,  $ \vec{H} $ are some forms of wave, they are E-M wave.

## 2 -2 Speed of light

From (2-5), (2-6) it is easy to see that

 $$ C_{0}=\frac{1}{\sqrt{\varepsilon_{0}\mu_{0}}} $$ 

(2-7)——speed of light in vacuum

In a media with dielectric, magnetic coefficient

 $$ \varepsilon,\mu:\varepsilon=\varepsilon_{r}\varepsilon_{0}=K_{E}\varepsilon_{0};\mu=\mu_{r}\mu_{0}=K_{M}\mu_{0} $$ 

Similar derivation using relations of vector operator  $ \nabla $

 $$ \begin{aligned}&\nabla^{2}\vec{E}=\varepsilon\mu\frac{\partial^{2}\vec{E}}{\partial t^{2}}\quad&\nabla^{2}\vec{H}=\varepsilon\mu\frac{\partial^{2}\vec{H}}{\partial t^{2}}\\ &C=\frac{1}{\sqrt{\varepsilon\mu}}\\ &\frac{C_{0}}{C}=\sqrt{\frac{\varepsilon\mu}{\varepsilon_{0}\mu_{0}}}=\sqrt{K_{E}K_{M}}=n\approx\sqrt{K_{E}}\quad&(2-8)\\ \end{aligned} $$ 