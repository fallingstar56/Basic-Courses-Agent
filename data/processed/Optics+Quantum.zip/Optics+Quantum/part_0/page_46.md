From E-M Theory (detailed proof is in Jackson's "Classical Electrodynamics" section 6.7. A simple argument can be found in 年绪成 波动与光子 3.2.2 ), the change of momentum in the E-M field is proportional to the energy absorbed by the surface. This is not surprise since we learned from special relativity that the momentum and energy of the light are related by the famous: p=E/c

 $$ \Delta p=\frac{\Delta W}{c}\hat{u}_{\bar{k}} $$ 

 $$ \Delta W=SA\Delta t $$ 

$\Delta W$ is the energy absorbed (lost by the light to the surface), $S$ is the value of Poynting vector and $A$ is the area, $\hat{u}_{\bar{k}}$ is unit vector along light propagation.

Thus:

 $$ \vec{F}=\frac{\Delta p}{\Delta t}=\frac{S A}{c}\vec{u}_{k} $$ 

 $$ P_{r e s s u r e}=\frac{F}{A}=\frac{S}{C} $$ 

Radiant Pressure:  $ <P_{\text{ressure}} \geq \frac{\langle S \rangle}{C} = \frac{I}{C} $ (2-16) (<> means time average)

Momentum change is:  $ \Delta p = p_v(c\Delta tA) $ ( $ p_v $: Momentum Density; A: area)