is the period between the two equal-phase wavefront in S (i.e. T is the period of light observed by a stationary observer relative to light source and  $ \upsilon_0 = \frac{1}{T} $ is the frequency in this frame); i.e. the wavefront2 is at (x1-cT, t1) at event 1. At event 2, the wavefront 2 (travels at velocity c along +x) will meet observer (travels with -u) at (x2, t2):

 $$ \Delta t=t2-t1 $$ 

 $$ x2-x1=-u\Delta t\quad and\quad x2-(x1-cT)=c\Delta t $$ 

 $$ \Delta t=\frac{c}{c+u}T $$ 

Now from the L-Transform, in the frame of S' (observer is stationary), applying  $ \Delta x' = 0 $ or directly from above  $ x2 - x1 = -u\Delta t $, will give):

 $$ \Delta t^{^{\prime}}=\frac{\Delta t+\frac{u\Delta x}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}}=\frac{\Delta t+\frac{u(-u\Delta t)}{c^{2}}}{\sqrt{1-\frac{u^{2}}{c^{2}}}}=\Delta t\sqrt{1-\frac{u^{2}}{c^{2}}}=\sqrt{1-\frac{u^{2}}{c^{2}}}\frac{c}{c+u}T=\sqrt{\frac{c-u}{c+u}}T=\sqrt{\frac{1-u/c}{1+u/c}}T $$ 

 $ \nu' = \frac{1}{\Delta t'} = \sqrt{\frac{1 + \beta}{1 - \beta}} \nu_0 \quad \text{where } \beta \equiv \frac{u}{c}, \text{ if } \beta << 1, \text{ use Taylor expansion (only to first order)} $:

 $$ \upsilon^{\prime}=\sqrt{\frac{1+\beta}{1-\beta}}\upsilon_{0}\approx\upsilon_{0}(1+\beta) $$ 

 $$ \frac{\upsilon^{\prime}-\upsilon_{0}}{\upsilon_{0}}=\frac{u}{c} $$ 

This is the relation of Doppler shift given in the notes when observer is traveling against light source. The case when the observer traveling along the light source (with +u along +x) has same derivation (just replace -u with +u) and you may write the explicit results yourself.