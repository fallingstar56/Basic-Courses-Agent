## Chapter2 Light as Electro-Magnetic Wave

## 2 -1 Maxwell Equation and Electro-Magnetic Wave

## (1) The Maxwell Equations

In  $ \underline{vacuum} $, no free charge and current, M-equations are:

 $$ \nabla\cdot\vec{E}=0 $$ 

 $$ \nabla\cdot\vec{H}=0 $$ 

 $$ \nabla\times\vec{E}=-\mu_{0}\frac{\partial\vec{H}}{\partial t} $$ 

 $$ \nabla\times\vec{H}=\varepsilon_{0}\frac{\partial\vec{E}}{\partial t} $$ 

 $ \vec{E} $,  $ \vec{H} $ are vectors representing electric field and magnetic field.

Where:

 $$ \mu_{0}\vec{H}=\vec{B} $$ 

 $$ \varepsilon_{0}\vec{E}=\vec{D} $$ 

 $ \mu_0 $ : permeability

 $$ 4\pi\times10^{-7}\ \mathrm{Henry}/\mathrm{meter} $$ 

 $ \varepsilon_0 $: permittivity

 $$ 8.854 \times 10^{-12} \text{ Faraday/meter} $$ 

Once again, I stress that above relations apply to the vacuum case. For the general property of the E-M field, please see the textbook of E-M theory for some detailed quantitative description. For the quantitative derivation, see the textbook for Electrodynamics (Jackson's Classical