We basically rescale the position and energy above, and (12-60) becomes:

 $$ \frac{d^{2}}{d\xi^{2}}\psi+(K-\xi^{2})\psi=0 $$ 

Let’s first take a look on the asymptote behavior of the equation, when  $ x(or \xi) \to \pm \infty $, where we can neglect the K term and the equation is in forms of:  $ \frac{d^2}{d\xi^2}\psi - \xi^2\psi = 0 $

It is not hard to guess the asymptote solution will be in the general form of:  $ \psi(\xi) = A e^{-\frac{\xi^2}{2}} + B e^{\frac{\xi^2}{2}} $, we can reject the B part on the ground that it explodes for large x and won’t be normalizable, thus the asymptotic solution has to be in forms of:  $ \psi(\xi) \to e^{-\frac{\xi^2}{2}} $. For very large x, the exponential term will dominate; for any  $ \xi $, the A is not a constant here; otherwise it won’t solve the equation. So we use the polynomial method, guess the solution may be in form of:

 $$ \psi(\xi)=h(\xi)e^{-\frac{\xi^{2}}{2}} $$ 

The h( $ \xi $) is a polynomial whose coefficients need to be determined, and we hope in the due process we can also get possible K (or E) values.

The general form of  $ h(\xi) $ part is:

 $$ h(\xi)=a_{0}+a_{1}\xi+a_{2}\xi^{2}+\ldots=\sum_{j=0}^{\infty}a_{j}\xi^{j} $$ 