Now we can define the reflection and transmission as ratio between the reflected and transmitted current versus the initial, thus:

 $$ R=\frac{j_{r e f}}{j_{i n i}}=|\frac{B}{A}|^{2}\quad T=\frac{j_{t r a n}}{j_{i n i}}=\frac{k_{2}}{k_{1}}|\frac{C}{A}|^{2} $$ 

Note the transmission ratio T has extra ratio of k besides probability density, since the two waves have different momentum in the two regions (Analogous to the R, T in optics). We see that by knowing the S matrix, we learned ratio of the amplitude and thus the R and T, put the (12-22) into (12-28), we have for the step potential, and E>V₀:

 $$ R=\left(\frac{k_{1}-k_{2}}{k_{1}+k_{2}}\right)^{2}\quad T=\frac{4k_{1}k_{2}}{\left(k_{1}+k_{2}\right)^{2}} $$ 

As this relation shows, even in the E>V₀ case, there is reflection and the transmission ratio is less than 1. It is the result of wave behavior of the ‘particle’ (duality). Of course it is clearly T+R=1.

(b) $ 0 \leq E \leq V_{0} $

In region I, same form of wave function as above; in the region 2, with  $ k_2' = \sqrt{2m(V_0 - E)} / \hbar $, the equation is:

 $$ \frac{d^{2}\psi_{_{II}}}{d x^{^{2}}}-k_{_{2}}^{\prime2}\psi_{_{II}}=0 $$ 

The general form of solution becomes:

 $$ \begin{aligned}&\psi_{I}(x)=Ae^{ik_{1}x}+Be^{-ik_{1}x}\\&\psi_{II}(x)=Ce^{k^{\prime}_{2}x}+De^{-k^{\prime}_{2}x}\\ \end{aligned} $$ 

The C has to be zero, otherwise the wave function will explode in