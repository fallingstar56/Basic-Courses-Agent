 $$ \mathrm{Proof}:|\varphi>=\sum_{j}c_{j}|\phi_{i}^{j}> $$ 

 $$ A\mid\varphi>=\sum_{j}c_{j}A\mid\phi_{i}^{j}>=\sum_{j}c_{j}a_{i}\mid\phi_{i}^{j}>=a_{i}\sum_{j}c_{j}\mid\phi_{i}^{j}>=a_{_{i}}\mid\varphi> $$ 

For a commutable observable B, we see that:

 $$ A(B\mid\phi_{i}^{j}>)=BA\mid\phi_{i}^{j}>=a_{i}(B\mid\phi_{i}^{j}>) $$ 

So  $ B|\phi_{i}^{j}> $ is within the subspace which is generally:

 $$ B\mid\phi_{i}^{1}>=c_{1}\mid\phi_{i}^{1}>+c_{2}\mid\phi_{i}^{2}> $$ 

 $$ B\mid\phi_{i}^{2}>=c_{1}^{^{\prime}}\mid\phi_{i}^{1}>-c_{2}^{^{\prime}}\mid\phi_{i}^{2}> $$ 

This means  $ |\phi_i^J > \text{may not be eigenstates of } B $. We can also see this from another point of view. The matrix of B within the subspace of  $ |\phi_i^J > \text{in this two dimensional case is just} $:

 $ B_{in-subspace-spanned\ by-|\phi_i^j>}=\begin{pmatrix}c_1&c_1'\\c_2&c_2'\end{pmatrix} $ which is not diagonal.

However, for the Hermitian B, we could take a certain linear

combinations of  $ |\phi_{i}^{j}> $, to reform a basis in this subspace so that B is

diagonal, and these new basis (a linear combination of  $ |\phi_{i}^{j}> $) would

be eigenvectors of B. The diagonalization of the above  $ 2x2 $ is trivial,

let's say the combination of:

 $$ |\boldsymbol{\varphi}_{i}^{1}>=d_{1}|\boldsymbol{\phi}_{i}^{1}>+d_{2}|\boldsymbol{\phi}_{i}^{2}> $$ 

 $$ |\varphi_{i}^{2}>=d_{1}^{^{\prime}}|\phi_{i}^{1}>+d_{2}^{^{\prime}}|\phi_{i}^{2}> $$ 

Under this basis for the subspace of A, the B would also be diagonal.

i.e.  $  B_{in-subspace-spanned\ by-|\varphi_i^j>} = \begin{pmatrix} b_1 & 0 \\ 0 & b_2 \end{pmatrix}  $, so  $  |\varphi_i^j>  $ would be

eigenvectors for B with eigenvalues of b_j. Because  $  |\varphi_i^j>  $ is just a