Take  $ |\alpha| = \Delta A |\varphi| > $

 $ |\beta| = \Delta B |\varphi| > |\varphi| \text{ is just some arbitrary ket} $

From Lemmal, the Schwarz Inequality, we have:

 $$ <\left(\Delta A\right)^{2}><\left(\Delta B\right)^{2}>\ \geq\ |\<\Delta A\Delta B>\|^{2} $$ 

 $$ \Delta A\Delta B=\frac{1}{2}[\Delta A,\Delta B]+\frac{1}{2}\{\Delta A,\Delta B\} $$ 

The  $ \{A,B\} $ is the notation for anti-commutator, it is defined as

 $ \{A,B\}=AB+BA $ for any A,B including the variation operators above.

Please prove yourself that the commutator is always anti-Hermitian

and anti-commutator is always Hermitian. Then using Lemma 2 and

3:

 $$ \begin{aligned}&<\Delta A\Delta B>=\frac{1}{2}<[\Delta A,\Delta B]>+\frac{1}{2}<\{\Delta A,\Delta B\}>\\ &\\ &|\lt\Delta A\Delta B\rangle|^{2}=\frac{1}{4}|<[\Delta A,\Delta B]>|^{2}+\frac{1}{4}|<\{\Delta A,\Delta B\}>|^{2}\geq\frac{1}{4}|<[\Delta A,\Delta B]>|^{2}\\ \end{aligned} $$ 

This proves the relation 11-73. This means that if two physical quantities can be determined simultaneously, i.e. with zero variation, the two operators representing the physical quantity has to be commute, [A,B]=0; otherwise, there will be uncertainty relations governed by the expectation value of the commutator <[A,B]>. If you put in the commutation relations between X,P, [X,P]=ih, you will get our familiar uncertainty relation: