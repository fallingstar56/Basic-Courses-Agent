Let  $ n \equiv 2m_{0} + p $ (12-69)

Since  $ m_{0} $ is an integer 0, 1, 2... (Depend on number of nonzero terms in the series), p=0 or 1, so n is an integer whose value can be 0, 1, 2, 3... Put in relation between K and E in (12-61):

 $$ E_{n}=(n+\frac{1}{2})\hbar\omega\ n=0,1,2\ldots $$ 

This is the allowed energy values which can give physical meaningful wave function. Clearly it is quantized. The boundary condition once again put a limit on the possible energy values, this time it is just a bit more complicated.

The energy spectrum is quite unique for the oscillator, it is equally spaced with interval  $ \hbar\omega $. The lowest energy state has energy  $ \frac{1}{2}\hbar\omega $. As in the infinite potential it is not zero and also demonstrates the uncertainty relation.

(4) Determine the wave functions associated with  $ E_{n} $

I have mentioned following the recursion formula that once we know the K (E_n) and certain a, we can find all other coefficients with recursion formula. Given an arbitrary n (and thus E_n), it fixed largest m_0 and p (even or odd series), clearly if n is even, p=0, the wave function will be even; if n is odd, p=1, the function is odd. But how do we get at least one a_{2m}? Well the recursion formula will allow us writing the coefficients in terms of the lowest a, i.e. the ratio between