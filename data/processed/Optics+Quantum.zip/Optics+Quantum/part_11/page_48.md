For the odd wave functions associated with odd n, the lowest (the second in the complete energy spectrum) is n=1, with  $ E_1 = \frac{3}{2} \hbar \omega $, this is  $ m_0 = 0 $, p=1, the odd series.  $ h_1(\xi) = a_0' \xi = a_1 \xi $ (I change the label back to 1, 3,... in the odd series)

The wave function is  $ \psi_{1}=a_{1}\xi e^{-\frac{\xi^{2}}{2}} $, after normalization:

 $$ \psi_{1}=\sqrt{2}(\frac{m\omega}{\pi\hbar})^{\frac{1}{4}}\xi e^{-\frac{\xi^{2}}{2}} $$ 

For the n=3 (m₀=1, p=1, K=7), it contains  $ a_1\xi + a_3\xi^3 $, using (12-71):

 $ a_3 = -\frac{2}{3}a_1 $. The overall factor will be set by normalization.

So you see how to get wave functions knowing the energy. For the general formula with $E_n$ (n=0, 1, 2...), it had been worked out. The $h(\xi)$ is related to Hermite Polynomial up to a normalization factor. Hermite Polynomial is related to the so called special functions you will encounter in quantum and the details on this will be left for the math book$^{72}$. The conventional Hermite Polynomial $H(x)$ is given by (Griffiths table2.1):

 $$ H_{0}=1, $$ 

 $$ H_{1}=2x, $$ 

 $$ H_{2}=4x^{2}-2, $$ 

 $$ H_{3}=8x^{3}-12x, $$ 

 $$ H_{4}=16x^{4}-48x^{2}+12, $$ 

 $$ H_{5}=32x^{5}-160x^{3}+120x. $$ 

The convention is to set the coefficient of the highest order term (say 5