theorem).

In quantum mechanics, we have the total probability  $ \langle \psi \rangle $ is conserved (always 1 for normalized  $ \mid \psi \rangle $), and we will see that for the wave function satisfying S-equation, we can define a probability current, so that the local conservation is also satisfied, here is how (I only use 1-D for derivation and extend result to 3-D):

 $$ i\hbar\frac{\partial\psi}{\partial t}=(-\frac{\hbar^{2}}{2m}\frac{d^{2}}{d x^{2}}+V)\psi $$ 

The local probability density is clearly:

 $$ \rho(x,t)=\psi^{*}\psi $$ 

And

 $$ \frac{\partial\rho(x,t)}{\partial t}=\psi^{*}\frac{\partial\psi}{\partial t}+\psi\frac{\partial\psi^{*}}{\partial t} $$ 

To get something similar to 12-23, this suggest we multiply  $ \psi^* $ to the S-equation, and  $ \psi $ to the conjugate of S-equation and subtract them (since i changes sign in conjugation), resulting:

 $$ \frac{\partial\rho}{\partial t}+\frac{\hbar}{2m i}[\psi^{*}\frac{d^{2}}{d x^{2}}\psi-\psi\frac{d^{2}}{d x^{2}}\psi^{*}]=0 $$ 

In the l-D case, the divergence is simple d/dx, the second part of the above can be written as:

 $$ \frac{\hbar}{2mi}[\psi^{*}\frac{d^{2}}{dx^{2}}\psi-\psi\frac{d^{2}}{dx^{2}}\psi^{*}]=\frac{\hbar}{2mi}\frac{d}{dx}[\psi^{*}\frac{d\psi}{dx}-\psi\frac{d\psi^{*}}{dx}] $$ 

We have then:

 $$ j(x,t)\equiv\frac{\hbar}{2mi}[\psi^{*}\frac{d\psi}{dx}-\psi\frac{d\psi^{*}}{dx}]=\frac{1}{m}\mathrm{Re}[\psi^{*}\frac{\hbar}{i}\frac{d\psi}{dx}] $$ 