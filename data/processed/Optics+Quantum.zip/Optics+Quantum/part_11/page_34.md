 $$ \sinh(k_{2}^{\prime}a)\stackrel{k_{2}^{\prime}a>1}{\approx}e^{k_{2}^{\prime}a}\bigg/2 $$ 

And T can be approximated by  $ (1/(1+\text{big}) \sim 1/\text{big}) $:

 $$ T\approx16\varepsilon(1-\varepsilon)e^{-2k_{2}^{\prime}a} $$ 

It is usually defined a threshold for width of barrier:

 $$ a_{_{0}}=\frac{1}{k_{_{2}}^{\prime}}=\frac{\hbar}{\sqrt{2m(V_{_{0}}-E)}} $$ 

When  $ a < a_{0} $, the particle has considerable T and thus non-negligible tunneling effect. We see such threshold is extremely small for any macroscopic particle and that is we do not see tunneling in classical mechanics. For electron, the (12-49) becomes:

 $$ a_{_{0(e)}}\approx\frac{1.96\stackrel{\circ}{A}}{\sqrt{V_{_{0}}-E}}\;~e n e r g y~i n~e V $$ 

It is on the order of  $ \AA $, which is the scale of atom/molecule; for the heavier particle such as neutron, the width need to be  $ \sqrt[1]{\sqrt{1800}} $ smaller.

## 12 -4 Finite Square Potential Well

Let’s consider a potential well with width 2a and finite depth  $ V_{0} $:

 $$ \begin{aligned}&\overline{\quad}\quad\quad\quad\quad I\quad&\quad&\quad&\quad\quad\quad I I I\quad&\quad&V=0\\&\quad&\quad&\quad&\quad&\quad\quad\quad-V_{0}\quad&\quad&\quad\\&\quad&x=-a\quad&\quad&x=a\quad&\quad&\quad\end{aligned} $$ 