As a conclusion remark on this section, let me further illustrate analogy here and that in optics. I hope I have convinced you there is great similarity between them. This is not a surprise but as expected, since both are waves described by the same mathematical wave functions (but different physical interpretation).

The time-independent S equation is in forms of:

 $$ \frac{d^{2}\psi}{d x^{2}}+\frac{2m(E-V)}{\hbar^{2}}\psi=0 $$ 

The wave equation in 1-D from Maxwell equations of EM wave in a media with index n is:

 $$ \frac{\partial U^{2}}{\partial x^{2}}-\frac{n^{2}}{c^{2}}\frac{\partial^{2}U}{\partial t^{2}}=0 $$ 

Taking the U in a standard plane wave form with time dependence of  $ e^{-i\omega t} $, we have:

 $$ \frac{\partial U^{2}}{\partial x^{2}}+\frac{n^{2}\omega^{2}}{c^{2}}U=0 $$ 

The two differential equations will be same, if we make substitution:

 $$ \begin{aligned}&k^{2}\equiv\frac{2m(E-V)}{\hbar^{2}}=\frac{n^{2}\omega^{2}}{c^{2}}\\ &or\ n=\frac{kc}{\omega}\\ \end{aligned} $$ 

The two equations will be same, and k is what we called wave vector before. The boundary conditions here is continuity of wave and its  $ 1^{st} $ derivative; while in optics, it is continuity of the electro and magnetic field, but this continuity can be demonstrated for the 1-D plane wave