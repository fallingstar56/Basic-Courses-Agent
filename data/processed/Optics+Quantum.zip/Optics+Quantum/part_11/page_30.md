 $$ \begin{aligned}&A+B=C+D\\&k_{1}(A-B)=k_{2}(C-D)\quad(12-36)\\&Ce^{ik_{2}a}+De^{-ik_{2}a}=Fe^{ik_{1}a}+Ge^{-ik_{1}a}\\&k_{2}(Ce^{ik_{2}a}-De^{-ik_{2}a})=k_{1}(Fe^{ik_{1}a}-Ge^{-ik_{1}a})\\ \end{aligned} $$ 

The strategy is to eliminate the C and D, to get relation between A, B, F, G, which are related to the reflection and transmission. It is quite nasty calculation, the systematic way is to use matrix form of (12-36) and (12-37), from (12-36), we can get

 $$ \begin{aligned}&\begin{bmatrix}C\\ D\end{bmatrix}=\begin{bmatrix}matrix}matrix\\ matrix1\end{bmatrix}\begin{bmatrix}A\\ B\end{bmatrix},then using(12-37)to get:\\ &\begin{bmatrix}F\\ G\end{bmatrix}=\begin{bmatrix}matrix}matrix\\ matrix2\end{bmatrix}\begin{bmatrix}C\\ D\end{bmatrix}=M\begin{bmatrix}A\\ B\end{bmatrix}\\ \end{aligned} $$ 

The transfer matrix M can be calculated this way, and we can relate F, G with A, B. If we set the initial condition so that only have waves travelling towards right, then G=0. We can get ratio between B/A and F/A which are related to reflection and transmission. However, the calculation even using matrix is lengthy and tedious, I skipped steps, only give the result (please test it yourself as a challenge for your computation ability):

 $$ \begin{aligned}\frac{F}{A}=&4k_{1}k_{2}e^{-ik_{1}a}[(k_{1}+k_{2})^{2}e^{-ik_{2}a}-(k_{1}-k_{2})^{2}e^{ik_{2}a}]^{-1}\\=&4k_{1}k_{2}e^{-ik_{1}a}[4k_{1}k_{2}\cos(k_{2}a)-2i(k_{1}^{2}+k_{2}^{2})\sin(k_{2}a)]^{-1}\end{aligned} $$ 

I shall not write the B/A, since F/A will allow us to get T and using T+R=1 to get R.

Using the probability current expression (12-27) for plane waves in