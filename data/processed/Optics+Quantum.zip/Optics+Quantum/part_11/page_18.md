 $$ \begin{aligned}&\psi(x,t=0)=\sum_{n}c_{n}\psi_{n}(x)\\&c_{n}=\int\psi_{n}^{*}\psi(x,t=0)dx\\ \end{aligned} $$ 

Then the time evolution is:

 $$ \psi(x,t)=\sum_{n}c_{n}e^{-i\omega_{n}t}\psi_{n}(x)\quad\omega_{n}=\frac{E_{n}}{\hbar} $$ 

The expectation values of various physical properties then can be calculated.

## 12 -3 Potential Step and Barrier

It may seem natural to discuss the finite square well next, but it turns out it is easier to discuss simple potential step first. For the infinite well above, all the physical possible states are “bound states”, meaning restricted by the potential. For potential with finite height, we will encounter states with higher energy (E>V_{max}) which are extended all over space, these are unbound states (also called scattering states). We have seen this in case of free space (V=0 everywhere), and the potential barrier here is another example, where we will see reflection and transmission (corresponding to probability of particle bounced back or shoot through the barrier). We shall define the probability current associated with wave function (analogous to energy flux Poynting vector associated with EM wave), and use it to calculate the reflection and transmission coefficients (analogous to Fresnel equations in optics). We shall see wave behavior which is strange in classical particle sense, the evanescent wave and