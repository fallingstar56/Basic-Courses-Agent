region I and III (with G=0), we have:

 $$ T=\frac{k_{1}}{k_{1}}\vert\frac{F}{A}\vert^{2}=\frac{4k_{1}^{2}k_{2}^{2}}{4k_{1}^{2}k_{2}^{2}+(k_{1}^{2}-k_{2}^{2})^{2}\sin^{2}(k_{2}a)}=\left[1+\frac{1}{4}(\frac{k_{1}^{2}-k_{2}^{2}}{k_{1}k_{2}})^{2}\sin^{2}(k_{2}a)\right]^{-1} $$ 

This form is quite like the Airy function in Fabry_Perot case and different from classical particle prediction where T=1 when E>V₀.

Using T+R=1, we get (an honest calculation should get B/A from M matrix and then the R form, and indeed the R+T=1 satisfied):

 $$ \begin{aligned}&R=\frac{(k_{1}^{2}-k_{2}^{2})^{2}\sin^{2}(k_{2}a)}{4k_{1}^{2}k_{2}^{2}+(k_{1}^{2}-k_{2}^{2})^{2}\sin^{2}(k_{2}a)}\quad(12-40)\\ &Since\quad(\frac{k_{1}^{2}-k_{2}^{2}}{k_{1}k_{2}})^{2}=\frac{V_{0}^{2}}{E(E-V_{0})}=\frac{1}{\varepsilon(\varepsilon-1)}\quad\varepsilon=\frac{E}{V_{0}}\\ \end{aligned} $$ 

The above T, R can be expressed as:

 $$ T=[1+\frac{1}{4\varepsilon(\varepsilon-1)}\sin^{2}(k_{2}a)]^{-1} $$ 

 $$ R=\frac{\sin^{2}(k_{2}a)}{4\varepsilon(\varepsilon-1)+\sin^{2}(k_{2}a)} $$ 

The transmission is maximum (T=1) whenever:

 $$ k_{2}a=m\pi,m=1,2,3\ldots $$ 

The relation is called resonance condition and the scattering satisfying it is called resonance scattering. This is not very surprise if we recall the F-P case, where we have  $ 2kl = 2m\pi $ (same as 12-42), then all the transmitted wave due to multireflection will be in phase, another way of saying is the incoming light is in resonance with the cavity mode (standing wave), and thus the output is maximum.