here for the scattering state do not fix the energy (we do not have quantization of k), which is kind of expected if we recall the standing wave case in optics, the one end cavity does not put restriction on k at all.

You may also expect the relation (12-22) is related to the reflection and transmission coefficients. That is very good guess (look it and compare the Fresnel equation for normal illuminations in 1-D, you see the similarity between k and n, the index refraction in optics, I shall argue their relation later), but first I shall digress to discuss the probability current and define clearly what are reflection and transmission here.

## Digression: Probability Current in Quantum

We have learned current associated with local conservation of certain physical property in classical physics. The familiar one is the local conservation of charge, the total charge of a closed system is conserved (global conservation), also the local change of charge will associate to an electrical current (local conservation), i.e.

 $$ \frac{\partial\rho(r,t)}{\partial t}+\nabla\cdot\vec{j}(r,t)=0 $$ 

This tells us the local change of charge has to equal to the negative

divergence of current density, thus the decrease of charge locally will

equal to the flow of current out of the enclosed surface (Gauss