you may solve this problem from beginning (do this as an exercise), or

use the results we obtained above, the functions in this case is just

shifted sines:

 $$ \psi_{_{n}}(x)=\sqrt{2/a}\sin(\frac{n\pi}{a}(x+\frac{a}{2}))=\begin{cases}\sqrt{2/a}\cos(\frac{n\pi}{a}x)&n\text{odd}\\\sqrt{2/a}\sin(\frac{n\pi}{a}x)&n\text{even}\end{cases} $$ 

(2) These wave functions (stationary states, the eigen-functions of energy) do form orthonormal basis. The orthogonal condition is obvious due to sinusoidal functions. The completeness is usually an assumption, but here in this case, it is from completeness of Fourier expansion.

(3)Other measurement probability can be calculated knowing the wave functions. For example, the expectation value of X and P are:

 $$ \begin{aligned}&<X>_{\psi_{n}}=<\psi_{n}\mid X\mid\psi_{n}>=<\psi_{n}\mid x><x\mid X\mid\psi_{n}>dx=\int\psi_{n}^{*}x\psi_{n}dx\\ &\\&<P>_{\psi_{n}}=\int<\psi_{n}\mid x><x\mid P\mid\psi_{n}>dx=-i\hbar\int\psi_{n}^{*}\frac{d\psi_{n}}{dx}dx\quad(12\\ \end{aligned} $$ 

They are zero for the stationary states due to odd even symmetry. For the  $ \langle X^{2}\rangle $ and  $ \langle P^{2}\rangle $, you may carry out the calculation, and verify the uncertainty relation is indeed satisfied, the  $ (\Delta x)^{2} \equiv \langle X^{2} \rangle - \langle X \rangle^{2} $, the root mean squared deviation. (Griffith's problem 2.4)

(4) Time evolution of an arbitrary initial state.

If at t=0, we have a state that is not one of the eigenstates, as we have discussed in last chapter, the general strategy is: Expand the state on basis of stationary states,