another operator C which is commute with A and with B, so that

 $ |a_{i},b_{j},c_{k}> $ would uniquely specify a state, which is common

eigenstate for A,B and C. A typical example is how we describe the

electronic state in hydrogen atom and alike ions, there we use  $ |n,l,m> $

to specify the state, related to the energy, orbit anaular momentum and

its directional component (projection). This process can go on till

we remove any degeneracy, and we will get the C.S.C.O. Such

C.S.C.O would have following properties:

(i) All observables A, B, C ... commute by pair.

(ii) Specifying the eigenvalues (from the measurement) would

uniquely determine a common eigenstate. $ ^{61} $