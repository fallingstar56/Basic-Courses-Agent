elements of S and M matrix first):

 $$ M=\left[\begin{array}{cc}\frac{k_{1}+k_{2}}{2k_{2}}&\frac{k_{2}-k_{1}}{2k_{2}}\\\frac{k_{2}-k_{1}}{2k_{2}}&\frac{k_{1}+k_{2}}{2k_{2}}\end{array}\right] $$ 

 $$ S=\begin{bmatrix}\frac{k_{1}-k_{2}}{k_{1}+k_{2}}&\frac{2k_{2}}{k_{1}+k_{2}}\\ \frac{2k_{1}}{k_{1}+k_{2}}&\frac{k_{2}-k_{1}}{k_{1}+k_{2}}\end{bmatrix} $$ 

Of course the S and M matrix are related, you can easily derive their relation (Griffiths problem 2.53). The boundary conditions fixed the S (or M) matrix, their expressions explicitly given above; and to know the relation between various components, we need to know clearly the initial condition.

Let's assume we only have waves travelling towards right at the beginning, there will be no waves in region II travelling towards left then, so that this put limit D=0, and now we can find ratios between components, directly read from (12-19) and (12-21) with D=0:

 $$ \frac{B}{A}=\frac{k_{1}-k_{2}}{k_{1}+k_{2}};\frac{C}{A}=\frac{2k_{1}}{k_{1}+k_{2}} $$ 

Of course for this simple problem, you can directly derive this relation without bothering the M or S matrix, the point here is of course introducing a systematic matrix way treating the boundary conditions. I do not pursue the normalization to get A here, because such scattering state cannot be normalized. Also the boundary conditions