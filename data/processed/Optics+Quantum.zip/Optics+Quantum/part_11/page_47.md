the coefficients are fixed by the recursion, and then we can use the normalization condition to determine the overall factor. In the following it is helpful to rewrite the recursion (12-67) as (same as Griffiths):

 $$ a_{_{j+2}}=\frac{-2(n-j)}{(j+1)(j+2)}a_{_{j}}\begin{cases}n odd\rightarrow odd j\\ n even\rightarrow even j\end{cases}(12-71) $$ 

In the formula above, I use  $ j = 2m + p $,  $ K = 2n + 1 $,  $ n = j_0 = 2m_0 + p $ which gives the highest nonzero term, and re-label the odd series index as 1, 3, 5...

Let's start from the lowest energy which only contains one coefficient to see how this works:

For the lowest energy n=0, then  $ m_0=0 $, p=0. This is an even function, and the only nonzero term in  $ h(\xi) $ (the highest is  $ a_{2m_0}\xi^{2m_0} $) is  $ a_0 $:

 $ \psi_0 = a_0e^{\frac{\xi^2}{2}} $, and normalization  $ \int\psi_0^*\psi_0dx = 1 $ gives:

 $$ \psi_{0}=(\frac{m\omega}{\pi\hbar})^{\frac{1}{4}}e^{-\frac{\xi^{2}}{2}} $$ 

This is the wave function corresponding to lowest energy. For the next higher energy in the even series, i.e. n=2, m₀=1, p=0. The polynomial part of wave function corresponding to E₂ is h₂(ξ) = a₀ + a₂ξ²,

Using the recursion formula (12-71): a₂ = -2a₀; the normalization will fixed the overall factor.

For the other higher even n number, you repeat the above to find all the nonzero terms in the h(ξ).