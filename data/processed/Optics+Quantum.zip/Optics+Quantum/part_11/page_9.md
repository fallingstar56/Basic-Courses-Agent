Now we can express the general form of S-equation in space representation, let us time bra  $ \langle x| $ from left to  $ (12-1) $, and because  $ |x\rangle $ is eigenstate of time independent operator X,  $ |x\rangle $ is independent of time, so:

 $$ \begin{aligned}&i\hbar\frac{\partial<x\mid\psi>}{\partial t}=<x\mid H\mid\psi>\\&i\hbar\frac{\partial\psi(x,t)}{\partial t}=\frac{1}{2m}<x\mid P^{2}\mid\psi>+<x\mid V(X)\mid\psi>\\ \end{aligned} $$ 

Now apply the relation in (12-3) and (12-4), we have (an exercise for you to prove it, involves Taylor expansion of functions of operator)

 $$ i\hbar\frac{\partial\psi(x,t)}{\partial t}=[-\frac{\hbar^{2}}{2m}\frac{d^{2}}{d x^{2}}+V(x)]\psi(x,t) $$ 

This is the Schrodinger equation in 1-d space. In 3-d, it becomes:

 $$ i\hbar\frac{\partial\psi(x,t)}{\partial t}=[-\frac{\hbar^{2}}{2m}\Delta+V(r)]\psi(x,t)\quad\Delta\equiv\nabla^{2}=\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}} $$ 

We have discussed in last chapter, usually to study the time evolution, we have a nice strategy. We do not need to solve the time-dependent S-equation above. Instead, we solve the time-independent S-equation to find out the eigenstates (stationary states) first, these states have very simple time evolution behavior; then we expand the initial wave function (wave function at t=0) in terms of stationary states, then the time evolution will be determined. So we need to work out the time independent S-equation, its space representation is:

 $$ [-\frac{\hbar^{2}}{2m}\frac{d^{2}}{d x^{2}}+V(x)]\psi_{_{E}}(x)=E\psi_{_{E}}(x) $$ 