## 12 -2 Infinite Square Potential Well

 $$ \begin{aligned}&\begin{vmatrix} \\{{{I}}} \\{{{\begin{vmatrix}}}} \\{{{II}}} \\{{{III}}} \\{{{V=0}}} \\\end{vmatrix}\\ &x=0\quad\quad x=a\\ \end{vmatrix}\\ \end{aligned} $$ 

The potential is given as:

 $$ V(x)=\begin{cases}0&0\leq x\leq a\\\infty&x>a,x<0\end{cases} $$ 

It is a squared well type and unrealistic due to infinity and discontinuity (the steep boundary) but simple to solve, and I divide the region in I, II and III. The strategy is to find solutions in these regions respectively and find those that meet the boundary conditions.

The region I and III are outside the well  $ (x<0, x>a) $. Because of the infiniteness of V in these two regions, the solution of S-equation with infinite V in region I and II could only be zero. This of course has very clear physical meaning, that due to the infinite potential barrier, the particle cannot escape the well at all (we do not have particle with infinite energy).

Let’s focus on rigation II inside the well, the S-equation is in forms of:

 $$ -\frac{\hbar^{2}}{2m}\frac{d^{2}\psi(x)}{d x^{2}}+0=E\psi(x) $$ 

Both energy eigenvalue E (we know it is >0 here, since total energy has to be larger than minimum of the potential) and wave function form need