This is the probability current in 1-D case. In 3-D, it is:

 $$ \vec{j}(r,t)=\frac{\hbar}{2m i}[\psi^{*}\nabla\psi-\psi\nabla\psi^{*}]=\frac{1}{m}\mathrm{R e}[\psi^{*}\frac{\hbar}{i}\nabla\psi] $$ 

The reason to write it as last part is to show this current is related to probability amplitude (the wave function) and momentum, which is indeed what a current is about (density times velocity).

With the above definition of probability current (12-24), we can calculate it for a plane wave type function, for if

 $$ \begin{aligned}&\psi(x,t)=A e^{i(kx-\omega t)}\\ &\\ &j(x,t)=\mid A\mid^{2}\frac{\hbar k}{m}\\ \end{aligned} $$ 

Where  $ |A|^{2} $ is the probability density and  $ \frac{\hbar k}{m} $ is related to velocity. This is analogous to the intensity (Poynting vector) in EM wave, the energy flow is related to amplitude square and velocity (there expressed as index of refraction and c)

For the wave function given in (12-16) and (12-17), (12-16) corresponds to an initial plane wave with amplitude A and a reflected wave with amplitude B, and (12-17) a plane wave transmitted with amplitude C (D=0) so:

 $$ j_{i n i}=\frac{\hbar k_{1}}{m}\left|\begin{array}{l l}A\end{array}\right|^{2}\quad j_{r e f}=\frac{\hbar k_{1}}{m}\left|\begin{array}{l}B\end{array}\right|^{2}\quad j_{t r a n s}=\frac{\hbar k_{2}}{m}\left|\begin{array}{l}C\end{array}\right|^{2} $$ 