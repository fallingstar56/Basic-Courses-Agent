$$\frac{\xi^{2}}{m}.$$ From this, you see that if the $h(\xi)$ has infinite terms, it will

approach an exponential at large $\xi$, because:

e^{\xi^2} = \sum_{m=0}^{\infty} \frac{1}{m!} \xi^{2m}, the ratio between adjacent terms is also  $ \frac{\xi^2}{m} $. So the asymptote behavior of  $ h(\xi) $ will be proportional to  $ e^{\xi^2} $. (The reason for proportion is that we only compare the ratio above. For the odd series, p=1 case, the series actually proportional to  $ \xi e^{\xi^2} $) But such asymptote behavior is physically unacceptable, because this means the wave function which is  $ h(\xi)e^{-\frac{\xi^2}{2}} $, at large  $ \xi $, will be like  $ \frac{\xi^2}{e^2} $, renders the wave function normalization impossible.

The above argument is based on the $h(\xi)$ has infinite terms, and higher order terms dominate at large $\xi$; so the way out of the unnormalizable dilemma requires the series only has limited terms, i.e. the series truncates at certain $m$, and higher order terms are all zero. I use $m_0$ to label this largest $m$ of nonzero term, meaning the largest power in the series is $a_{2m_0}\xi^{2m_0}$, with nonzero $a_{2m_0}$. The next higher term $a_{2m_0+2}\xi^{2m_0+2}$ is zero only if the $a_{2m_0+2}=0$, and the rest of higher terms will also be zero from the recursion formula. Using the recursion formula (12-67), we see that $a_{2m_0+2}=0$, $a_{2m_0}\neq 0$ means:

 $$ \frac{2(2m_{0}+p)+1-K}{(2m_{0}+p+2)(2m_{0}+p+1)}=0\quad or $$ 

 $$ K=2(2m_{0}+p)+1 $$ 