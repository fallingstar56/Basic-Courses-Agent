measure property A,B on a state  $ |\phi_{i}> $, you get values  $ a_{i} $,  $ b_{i} $. These common eigenvectors will form a orthonormal basis for the sate space.

In summary, this theorem states:

For two commutable observables, it is possible to construct an

orthonormal basis of the state space by the eigenstates that are

common to both observables.

The necessary condition is also true, i.e. if there is such basis by the common eigenstates, then [A, B]=0. This is easy to prove, since

 $$ \left(A B-B A\right)\mid\phi_{i}>=(\boldsymbol{a}_{i}\boldsymbol{b}_{i}-\boldsymbol{b}_{i}\boldsymbol{a}_{i})\mid\phi_{i}>=0 $$ 

For any arbitrary state which can be written as linear combination of

the eigenstates, the above relation would also be true. (prove it

yourself), then AB-BA=0

To prove the sufficient condition, i.e. the theorem in italic above would require more work. It is extremely simple if the eigenspace for A,B are not degenerate, i.e. all eigenvalues are different, and each eigenvalue is associated with an eigenstate. Let's first consider this case.

Suppose  $ |\phi_i\rangle $ is an eigenstate of A with eigenvalue  $ a_i $, then  $ B|\phi_i\rangle $ is also the eigenstate of A with same eigenvalue.

Proof:  $ A(B \mid \phi_i >) = BA \mid \phi_i >= a_i(B \mid \phi_i >) $

From the definition of eigenvalues and eigenstates, this proves the above statement. Since the eigenvalues are non-degenerate, so the