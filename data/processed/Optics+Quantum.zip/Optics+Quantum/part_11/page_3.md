eigenstates of the same eigenvalue could only be different by a common factor, let's call this common factor  $ b_{i} $, i.e.

 $$ B\mid\phi_{i}>=b_{i}\mid\phi_{i}> $$ 

This proves that  $ |\phi_i > \text{is also an eigenstates for } B \text{ with eigenvalue } b_i $.

So  $ |\phi_i > \text{ would be the orthonormal basis we are looking for.} $

In case of degeneracy, the above relation  $ B|\phi_{i}>=b_{i}|\phi_{i}> \text{ may not be true. But we still can still find the common eigenstates and form a orthonormal basis. For simplicity of discussion, let me just take a simple case for example, but can be easily extended to more general situation:} $

Still the  $ |\phi_i> $ would be eigenstates of A, but in this case A has degenerate eigenvalues. Assume for one eigenvalue number  $ a_i $, it is doubly degenerate, i.e. there are two eigenvalues taking the number  $ a_i $. There will be two eigenvectors associated with this eigenvalue number  $ a_i $:

 $$ A\mid\phi_{i}^{1}>=a_{i}\mid\phi_{i}^{1}> $$ 

 $$ A\mid\phi_{i}^{2}>=a_{i}\mid\phi_{i}^{2}> $$ 

 $ |\phi_i^1 > \text{and} |\phi_i^2 > \text{are independent and orthogonal vectors.}^59 $

Important lemma: any combination of  $ |\phi_i^j> $ would also be

eigenvectors of A with eigenvalue of  $ a_i $. The  $ |\phi_i^j> $ spans a subspace in

the eigenspace of A.