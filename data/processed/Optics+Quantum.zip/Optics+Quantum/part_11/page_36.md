and the other end will satisfy automatically:

 $$ \begin{aligned}&D\cos(k_{2}a)=Ae^{-k_{1}a}\\&k_{2}D\sin(k_{2}a)=k_{1}Ae^{-k_{1}a}\\ \end{aligned} $$ 

Here we have 3 independent variable (A, D, and E energy, both k related to E) and 2 relations. Thus the condition set a limit on the possible energy (quantization), and once we know the possible energy, we could know the relation between A, D. Let's focus on the possible energies here. Divide the two relations in (12-52), we have:

 $$ k_{2}\tan(k_{2}a)=k_{1} $$ 

This is a transcendent equation and cannot be solved analytically. I shall first do some “cosmetics”:

Let:

 $$ \begin{aligned}&z\equiv k_{2}a\\ &since\ k_{1}^{2}+k_{2}^{2}=\frac{2mV_{0}}{\hbar^{2}}\\ &then\ k_{1}\bigg/k_{2}=\sqrt{\frac{2mV_{0}}{\hbar^{2}k_{2}^{2}}-1}=\sqrt{\frac{2ma^{2}V_{0}}{\hbar^{2}k_{2}^{2}a^{2}}-1}=\sqrt{\frac{z_{0}^{2}}{z^{2}}-1}\\ &z_{0}\equiv\frac{a\sqrt{2mV_{0}}}{\hbar}\qquad(12-55)\\ \end{aligned} $$ 

 $ z_{0} $ is known provides with  $ V_{0} $ and width

Equation (12-53) has the new form:

 $$ \tan(z)=\sqrt{\frac{z_{0}^{2}}{z^{2}}-1}\quad even states\qquad(12-56) $$ 

Above are for the even states, and for the odd states, we can get (prove it as exercise):