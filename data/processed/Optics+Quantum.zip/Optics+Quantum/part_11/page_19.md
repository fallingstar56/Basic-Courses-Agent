tunneling effect.

The simplest potential to illustrate above is a square potential step, and that is what we first discuss in this section, then we shall discuss finite square potential barrier.

The general strategy is same as that in infinite potential well, I shall repeat again here:

(1)We divide the regions given the potential form, since within each region, the S-equation (time independent) have simple solutions due to the simple potential form in that region.

(2) Apply the boundary (separate regions) conditions (continuity of wave function and its first space derivative when applies) to find the suitable general solutions, i.e. use boundary conditions to determine the unknown parameters (usually within a common normalization factor)

## 12 -3-1 Potential Step

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_1133_651_1317.jpg" alt="Image" width="34%" /></div>


The potential is shown above, its form is:

 $$ V(x)=V_{0}\theta(x)=\begin{cases}V_{0}&x>0\\ 0&x<0\end{cases}\quad\theta(x)is step function $$ 

First, let's talk about classical picture: It is like a car rolling up a very