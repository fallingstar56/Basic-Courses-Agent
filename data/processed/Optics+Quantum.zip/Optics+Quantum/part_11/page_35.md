Without solving equations, we can guess the result using the results we had learned on other forms of potentials so far. (1) When  $ -V_{0} < E < 0 $, we expect to have bound state in region II and evanescent in region I and III. The bound state will be similar to that in infinite well, but due to finite depth, can leak into the forbidden region. (2) When E>0, we shall have unbound state (scattering state), and we will have reflection and transmission at the boundary separate regions. (3) Here I make the potential even, so we shall expect the wave functions be even or odd.

## (a) Bound state when  $ -V_{0}<E<0 $

The wave function in region I and III are:

 $$ \psi_{_{I}}=A e^{k_{1}x}\quad x\leq-a,\;k_{_{1}}=\sqrt{2m(-E)}\bigg/\hbar\quad(the other half will explode and $$ 

thus discarded)

 $$ \psi_{III}=Ge^{-k_{1}x}\quad x\geq a $$ 

In region II, we have:

 $$ \psi_{_{II}}=C\sin(k_{2}x)+D\cos(k_{2}x)\quad k_{2}=\sqrt{2m(V_{_{0}}+E)}\bigg/\hbar\quad-a<x<a $$ 

Now we can throw in the boundary conditions and proceed as before.

We could also exploit the requirement on the odd and evenness of the wave function here to simplify a bit.

For the even solution:

 $$ \psi_{_{I}}=A e^{k_{1}x},\psi_{_{II}}=D\cos(k_{2}x),\psi_{_{III}}=A e^{-k_{1}x} $$ 

We could only consider the boundary condition at one end, say x=a,