Group the coefficients for the same power, say  $ \xi^{2m+p} $, and for the series equals zero (variables are linear independent), the coefficient has to be zero. In the grouping the index m in the first half has to be  $ m+1 $ to have same  $ \xi $ power as the second half, then:

 $$ \begin{aligned}&(2m+2+p)(2m+p+1)a_{2m+2}-[2(2m+p)+K\underset{ 伱 }{=}a_{2m}=0\\ &\\ &a_{2m+2}=\frac{2(2m+p)+1-K}{(2m+p+2)(2m+p+1)}a_{2m}\quad(12-67)\\ \end{aligned} $$ 

This is the recursion formula $ ^{71} $. For the p=0 (even series), if we know the K (energy) and the first coefficient  $ a_{0} $, the rest can be known. For the p=1 case, if we know the K and first coefficient  $ a_{0} $ (same as  $ a_{1} $), the rest can be known.

(3) Boundary condition and truncation of the polynomial, quantization of energy

Now since we have the recursion formula, though we do not know

exact form of the polynomial (need K and initial coefficients for that),

we can study the asymptote behavior (I mean when the x (or  $ \xi $) is

large, what this polynomial approaches) and combined with

exponential part  $ e^{-\frac{\xi^{2}}{2}} $ to see whether it is normalizable.

For the large  $ \xi $, the higher powers (large m) will dominate. The

recursion formula (12-67) then can be approximated when m is large:

 $ \frac{a_{2m+2}}{a_{2m}} \rightarrow \frac{1}{m} $, or the ratio between adjacent terms in power series is