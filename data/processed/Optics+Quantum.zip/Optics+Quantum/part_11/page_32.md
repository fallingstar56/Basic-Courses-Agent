(b) $ 0 \leq E \leq V_{0} $

We expect difference in region II where the wave function will be with real exponent. The wave forms in region I and III will be exactly same as case (a). In region II, the wave function is in forms of:

 $$ \psi_{_{II}}=C e^{k_{2}^{\prime}x}+D e^{-k_{2}^{\prime}x}\quad k_{2}^{\prime}=\sqrt{2m(V_{_{0}}-E)}\bigg/\hbar $$ 

Because the x is limited between 0 and a, so both parts (C and D) are acceptable.

The boundary conditions are:

 $$ \begin{aligned}&A+B=C+D\\&ik_{1}(A-B)=k_{2}^{\prime}(C-D)\quad(12-44)\\&Ce^{k_{2}^{\prime}a}+De^{-k_{2}^{\prime}a}=Fe^{ik_{1}a}+Ge^{ik_{1}a}\\&k_{2}^{\prime}(Ce^{k_{2}^{\prime}a}-De^{-k_{2}^{\prime}a})=ik_{1}(Fe^{ik_{1}a}-Ge^{ik_{1}a})\\ \end{aligned} $$ 

You may carry out honest computation to get M matrix relating A, B and F, G, but actually there is an easier way. We see that boundary conditions will be exactly same as (12-36) and (12-37) in case (a), if replacing  $ k_{2}^{\prime}=ik_{2} $. This suggests that we can replace the  $ k_{2} $ in (12-38) (or in the M matrix elements) with  $ -ik_{2}^{\prime} $:

 $$ \frac{F}{A}=e^{-ik_{1}a}[\cosh(k_{2}^{\prime}a)+\frac{i(k_{2}^{\prime2}-k_{1}^{2})}{2k_{1}k_{2}^{\prime}}\sinh(k_{2}^{\prime}a)]^{-1}\qquad67 $$ 