The energy is thus quantized. This is actually not surprise from wave point of view, we see the relation like (12-8) in standing wave bounded by total reflective cavity! You see (12-8) is exactly same as the standing wave condition, due to exactly same wave form and boundary condition. The wave functions corresponding to energies are:

 $$ \psi_{_{n}}(x)=C\sin(\frac{n\pi}{a}x) $$ 

Using the normalization,  $ \int_{0}^{a}\psi^{*}\psi dx = 1 $ we get:

 $ \psi_{n}(x) = C\sin(\frac{n\pi}{a}x) = \sqrt{\frac{2}{a}}\sin(\frac{n\pi}{a}x) $ (12-9)

These wave functions are same (except the normalization factor) as standing waves in a total reflective cavity. The first couple functions were shown before, as following: (Griffiths, fig. 2.2)

<div style="text-align: center;"><img src="imgs/img_in_chart_box_185_962_430_1088.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_471_963_714_1089.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_754_964_997_1089.jpg" alt="Image" width="20%" /></div>


Comments: The following are just applications of the general principles we discussed before to this particular case.

(1) The states are actually either even or odd functions. The potential form we have above is not even symmetry, but we can shift the coordinate to make it even. From the general discussion before, the wave functions for even potential should be even or odd. Indeed if we shift the coordinate to make explicit symmetry, i.e.  $ V(x)=0 $, if  $ -a/2<x,+a/2 $,