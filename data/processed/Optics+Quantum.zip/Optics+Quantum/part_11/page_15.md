to be determined.

Let's define:  $  k = \sqrt{2mE} / \hbar  $, the ODE becomes:

 $$ \frac{d^{2}\psi(x)}{d x^{2}}+k^{2}\psi(x)=0 $$ 

It has solution in the general form of:

 $$ \psi(x)=Ae^{ikx}+Be^{-ikx}=C\sin kx+D\cos kx $$ 

Above two expressions are equivalent (we had talked about this a while ago on solving the ODE for harmonic oscillator in classical mechanics) and you may choose either form, however a practical trick is the sine, cosine form will be easier to apply the boundary condition for the bound state.

Now we will use boundary (between region I and II, II and III) conditions at x=0 and x=a to determine the wave form and E value. We only have continuity of wave function here due to infinite potential jump.

At x=0, the boundary condition requires:

 $$ \psi_{_{II}}(0)=C\sin0+D\cos0=\psi_{_{I}}(0)=0\ ,then D=0 $$ 

The wave function will be in form of:

 $$ \psi_{II}(x)=C\sin kx $$ 

At x=a, we have:

 $ C \sin ka = 0 $

This requires:

 $$ ka=n\pi\rightarrow E=\frac{\hbar^{2}\pi^{2}}{2ma^{2}}n^{2}\quad n=1,2,3\ldots $$ 