 $$ V(x)=\frac{1}{2}kx^{2} $$ 

We have seen the importance of harmonic oscillator in classical physics. It also has many important applications in quantum, such as molecular vibration; the quantum field theory (where the field will be treated as a collection of harmonic-like operators) etc.

We can solve this problem by the formalism we have used by now in this chapter, i.e. directly solve the differential equation and apply the boundary condition. This is called analytic method and I shall discuss in somewhat detail here. This is a quite straightforward (knowing the potential and attack the equation directly) method but with messy mathematics. However, similar method will be used in solving the solution for hydrogen atom, so it is worth going through all this mess.

There is another quite different but clean and elegant way of solving this problem, by using operator property (first used by Dirac), constructing the so called creator and annihilator. This is called algebra or operator method, and will be used not only in harmonic oscillator, but also in angular momentum. Such method will not be discussed in detail here and its treatment will be left for later quantum course $ ^{69} $. This unfortunately means we may not be able to use some powerful tools and methods in dealing with problems on harmonic oscillator.

The focus in this section is to show the energy spectrum of the oscillator