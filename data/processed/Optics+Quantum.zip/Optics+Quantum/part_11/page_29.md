same as continuity of E field and its  $ 1^{st} $ derivative (please do this yourself as an exercise). Since the equation and boundary conditions are essentially same, no surprise we get same result: with relation (12-34), the R and T derived here were same as those in Fresnel equations in optics.

## 12 -3-2 Potential Barrier

In this section, we consider the square V barrier with width a:

<div style="text-align: center;"><img src="imgs/img_in_image_box_276_649_648_819.jpg" alt="Image" width="31%" /></div>


 $$ V(x)=\begin{cases}V_{0}&0<x<a\\0&everywhere else\end{cases} $$ 

 $$ (a)\mathrm{E}\geqq\mathrm{V}_{0} $$ 

We consider solutions in 3 regions and join those using boundary conditions.

The stationary wave functions in I, II, III are:

 $$ \begin{aligned}&\psi_{_{I}}=Ae^{ik_{1}x}+Be^{-ik_{1}x}\quad k_{_{1}}=\sqrt{2mE}\bigg/\hbar\\&\psi_{_{II}}=Ce^{ik_{2}x}+De^{-ik_{2}x}\quad k_{_{2}}=\sqrt{2m(E-V_{_{0}})}\bigg/\hbar\\&\psi_{_{III}}=Fe^{ik_{1}x}+Ge^{-ik_{1}x}\\ \end{aligned} $$ 

Their time evolution form will just attach the  $ e^{-t-\frac{t}{h}} $. The boundary at x=0 and x=a will give us: