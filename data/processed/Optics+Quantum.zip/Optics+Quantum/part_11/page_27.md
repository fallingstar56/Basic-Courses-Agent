region II, and so the physical meaningful solution in region II is:

 $$ \psi_{_{II}}(x)=De^{-k^{\prime}_{2}x} $$ 

Now applying the boundary conditions:

 $$ A+B=D $$ 

 $$ i k_{1}(A-B)=-k_{2}^{\prime}D $$ 

We do not need M or S matrix method for this simple case, we have:

 $$ \frac{B}{A}=\frac{k_{1}-ik_{2}^{\prime}}{k_{1}+ik_{2}^{\prime}}\quad\frac{D}{A}=\frac{2k_{1}}{k_{1}+ik_{2}^{\prime}} $$ 

The reflected current is same as case (a); for the transmitted current, it is zero here, because the exponential dependence on x is real in region II, the two conjugate parts in (12-24) are same and cancel. Thus:

 $$ R=\mid\frac{k_{1}-ik_{2}^{\prime}}{k_{1}+ik^{\prime}}\mid^{2}=1\quad T=0 $$ 

So there will be total reflection with no transmission. However, just analogous to the total internal reflection in optics, the probability wave in the classical forbidden region II is not zero, but decays exponentially (12-31), it is an evanescent wave. The particle can penetrate into the forbidden region, and then bounced back, and thus the reflected wave will have some extra phase difference comparing to the initial one. In our infinite wide potential step, such evanescent wave dies quickly with increasing x. We will expect if the potential barrier becomes narrow; the particle with less energy than the barrier may penetrate into the barrier, and leak to the other side. That is the tunneling effect we shall see next in finite potential barrier.