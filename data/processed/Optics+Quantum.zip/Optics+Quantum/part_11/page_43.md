(2) The recursion formula for the polynomial

We can actually do better in the guess on the form of polynomial, using the even symmetry of the potential form. The solution then has to be either even or odd functions, meaning the polynomial contain either even or odd power, i.e. the solution should be:

 $$ \begin{aligned}&h_{even}(\xi)=a_{0}+a_{2}\xi^{2}+a_{4}\xi^{4}+\ldots\\&h_{odd}(\xi)=a_{1}\xi+a_{3}\xi^{3}+a_{5}\xi^{5}+\ldots\\ \end{aligned} $$ 

In the derivation on relations of the coefficients, I shall combine the above two in one form:

 $$ h(\xi)=\xi^{p}(a_{0}+a_{2}\xi^{2}+\ldots)=\xi^{p}\sum_{m=0}^{\infty}a_{2m}\xi^{2m} $$ 

Here, the power p in the  $ \xi^{p} $ can be either 0 or 1 corresponding to the even or odd series $ ^{70} $.

Throw the form of wave function (12-63) into equation (12-62), we get equation on $h(\xi)$ polynomial after cancel the exponential part:

 $$ \frac{d^{2}h}{d\xi^{2}}-2\xi\frac{dh}{d\xi}+(K-1)h=0 $$ 

Throw in the form of h (12-65) in, this will give us relations between the coefficients (recursion formula):

 $$ \sum_{m}(2m+p)(2m+p-1)a_{2m}\xi^{2m+p-2}-\sum_{m}[2(2m+p)+K\textcircled{m}1]a_{2m}\xi^{2m+p}=0 $$ 