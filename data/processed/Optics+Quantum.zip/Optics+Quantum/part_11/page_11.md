This requirement on solutions of wave function will be very useful, they essentially establish the boundary condition: wherever, there is a sudden change of potential (the boundary), the continuity of wave function and its first derivative at the boundary set the limit (or condition) on the possible solutions, and we shall see these boundary condition will limit the possible energy (not all values are allowed), i.e. the quantization of energy. When the potential change is infinite, then we do not have continuity on first derivative of wave function.

So in summary, the wave function goes “smoothly” through boundary of finite height; but will have a “kink” at the boundary with infinite height.

(2)The solutions of physical realizable wave function should be normalizable, i.e.

 $$ <\psi\mid\psi>=\int\psi^{*}(x)\psi(x)d x\quad\mathrm{s h o u l d~b e~f i n i t e}^{64}. $$ 

Comment: This is true for many solutions, for example the bound state (I mean the energy is less than the maximum of potential, thus the particle is “bound” by the potential and its wave function only extends over limited space, dies away when x goes big), this sometimes expressed as requirement that  $ \psi(\infty)=0 $. This is a rather