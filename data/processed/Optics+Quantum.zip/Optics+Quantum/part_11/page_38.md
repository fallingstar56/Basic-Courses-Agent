graph, easy to see that the when the  $ \sqrt{\frac{z_{0}^{2}}{z^{2}}}-1 $ curve reaches 0 when  $ z=z_{0} $, so if  $ z_{0}\geq\frac{n}{2}\pi, n=0,1,2\ldots $, we have  $ n+1 $ intersections and these many bound states. For example, if  $ z_{0}<\frac{\pi}{2} $ (a narrow and shallow well), we can only have one intersection with the  $ \tan(z) $ curve, and there will be only one even bound state (the ground state). As  $ V_{0} $ approaches infinity, so will be the  $ z_{0} $, and the intersection z approaches the  $ \frac{n}{2}\pi $ ( $ n=1,2\ldots $) lines, which is the solution for the infinite well.

Once we find out the solutions for energies, we can use (12-52) to get the wave function (up to a normalization factor).

## (b) Scattering states when E>0

This problem is actually already been solved in the potential barrier case (the E>V₀ there), here the only differences are in the region II,  $ k_2 = \sqrt{2m(E + V_0)} / \hbar $ is defined slightly different than before, and the width is 2a. We plug all these into relation (12-39):

 $$ T=[1+\frac{1}{4}(\frac{k_{1}^{2}-k_{2}^{2}}{k_{1}k_{2}})^{2}\sin^{2}(k_{2}2a)]^{-1}=[1+\frac{1}{4\varepsilon(1+\varepsilon)}\sin^{2}(k_{2}2a)]^{-1} $$ 

 $ \varepsilon \equiv \frac{E}{V_0} $. We have a very similar expression and same resonance condition  $ k_2(2a) = m\pi $ for the maximum T.