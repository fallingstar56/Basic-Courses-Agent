 $$ -\cot(z)=\sqrt{\frac{z_{0}^{2}}{z^{2}}-1}\quad odd states\qquad(12-57) $$ 

The equations can be used to determine z, and thus  $ k_{2} $ then the energy E for the even and odd states respectively. To determine the z satisfying either (12-56) or (12-57), we have to resort to graphical method, plot the  $ \tan(z) $ (or  $ -\cot $) and  $ \sqrt{\frac{z_{0}^{2}}{z^{2}}-1} $ curves and find their intersection.

<div style="text-align: center;"><img src="imgs/img_in_image_box_259_589_831_859.jpg" alt="Image" width="48%" /></div>


This method is shown qualitatively above. Some general features are quite obvious from the graph:

(1) The allowed energies are quantized (z can only take certain values at the intersection), and its value will be less than the case of infinite well. There the  $ k(2a)=m\pi $ (since here the well’s width is 2a) gives us the allowed energy. Here for the finite well, the intersection happens below it, so the energy above the potential bottom will be less than the infinite  $ V_{0} $ case.

(2)  $ Z_{0} $ sets the limit on the number of bound states.  $ Z_{0} $ itself is set by the  $ V_{0} $ and a, the depth and width of the potential well. From the