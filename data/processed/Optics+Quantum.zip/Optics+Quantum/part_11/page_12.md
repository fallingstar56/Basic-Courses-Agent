physical requirement, since we don't have anything real can extend to

infinity. However, we do see unphysical solutions contradict this, the

idealized plane wave of particle in free space (analogy to

monochromatic light with single frequency). Those idealized solutions

are unrealizable in real world, they are useful because they are simple

and we can construct realistic wave packet out of these idealized plane

wave. In conclusion, I stress that for the bound state, the wave

functions are normalizable; while for the free particle-like states

(those extends all over space, unbound by the potential, also they are

called scattering states), we accept the plane wave type solution

though they are unnormalizable.

(3) If the potential possess space symmetry, i.e.  $ V(x)=V(-x) $ is an even function of space, then the solution wave function should be even or odd functions.

Comment: This is not as general as the previous two, only applies to even potential. The proof of this is as following:

If the  $ \psi(x) $ is a solution of 12-6, and if the  $ V(x)=V(-x) $, you make parameter change  $ x'=-x $, and you see right away that the  $ \psi(x')=\psi(-x) $ is also the solution to the same equation. Since the S-equation (12-6) is linear, so that combination of  $ \psi(x)+\psi(-x) $ (an even function) or  $ \psi(x)-\psi(-x) $ (an odd function) are also solutions. In 1-D problem, we can prove that the eigenstates