and its wave function form. The strategy of the analytic method is same as before: writing out the differential equation, guess the general form of the wave function, and using boundary condition to see what kind of requirement it puts on solution. Here since the potential changes continuously all over space and up to infinity, states with all energy will be bounded and the boundary condition is that the states should be normalizable.

You should be able to guess the general shape of the wave function from what we had discussed on the infinite square potential. The wave function will be something similar, but can leak out of the potential here. For the lowest states, they are somethings like:

<div style="text-align: center;"><img src="imgs/img_in_image_box_191_911_469_1126.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_486_865_711_958.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_729_847_953_936.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_486_983_710_1131.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_731_1014_954_1118.jpg" alt="Image" width="18%" /></div>


Of course the details have to be solved rigorously as following:

(1) The S-equation and general solution form

 $$ (-\frac{\hbar^{2}}{2m}\frac{d^{2}}{dx^{2}}+\frac{1}{2}kx^{2})\psi=E\psi $$ 

Let's make some cosmetic to make equation looks better:

 $$ \omega^{2}\equiv\frac{k}{m},\xi\equiv\sqrt{\frac{m\omega}{\hbar}}x,K\equiv\frac{2E}{\hbar\omega} $$ 