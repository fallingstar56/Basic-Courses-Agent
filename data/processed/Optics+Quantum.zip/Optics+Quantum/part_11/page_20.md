steep uphill. If the initial energy is larger than the potential  $ V_{0} $, the car will roll up the hill (or we say 100% pass it); if the E is less, then the car will roll back (or we say 100% reflected). We will see results of quantum will be quite different due to the wave nature.

It is helpful we divide the energy E in two cases:

(a)  $ E \geq V_0 $

(b)  $ 0 < E \leq V_0 $ Here we shall see evanescent wave in x > 0 region.

Of course you may choose not to make such division at the beginning, but will come to same consideration in the due process.

## (a) When  $ E \geq V_{0} $

In region I (x ≤ 0), we have

 $$ \frac{d^{2}\psi(x)}{d x^{2}}+k_{1}^{2}\psi(x)=0\quad k_{1}=\sqrt{2m E}\Big/\hbar $$ 

In region II, we have

 $$ \frac{d^{2}\psi(x)}{d x^{2}}+k_{2}^{2}\psi(x)=0\quad k_{2}=\sqrt{2m(E-V_{0})}\bigg/\hbar $$ 

The general solutions of (12-14), (12-15) are obvious:

 $$ \begin{aligned}&\psi_{I}(x)=Ae^{ik_{1}x}+Be^{-ik_{1}x}\\ &\\ &\psi_{II}(x)=Ce^{ik_{2}x}+De^{-ik_{2}x}\\ \end{aligned} $$ 

These are the stationary state with energy E, their time evolution are simple, just attach  $ e^{-i\omega t} $,  $ \omega = E/\hbar $.

We have finished step (1) in our general strategy. Let's pause a while to see what these general solutions tell us, the two terms in each