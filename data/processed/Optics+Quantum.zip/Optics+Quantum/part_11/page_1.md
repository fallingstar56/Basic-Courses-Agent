 $$ (\Delta X)^{2}(\Delta P)^{2}\geq\frac{\hbar^{2}}{4}\rightarrow\Delta X\Delta P\geq\frac{\hbar}{2} $$ 

58

 $ \Delta X $ is defined as  $ \sqrt{<(\Delta X)^2>} $ etc.

##### Supplement (C): C.S.C.O

(c) Commutable Observables, Common Eigenstates and Complete Set of Commutable Observables (C.S.C.O)

From the discussion in (b), we see that if two physical observables are not commute, then they cannot be determined simultaneously. You probably guessed (though it does not count as proof) that if the observables are commutable, then they can be determined simultaneously.

This is the first part I shall show you indeed the case. I shall try to prove that for commutable observables, you can construct eigenvectors that are common to them. That is:

If for two observables, their operators are A, B and they commute, i.e.

[A,B]=0 or AB=BA, then it is possible to find a vector so that:

 $$ A\mid\phi_{i}>=a_{i}\mid\phi_{i}> $$ 

 $$ B\mid\phi_{i}>=b_{i}\mid\phi_{i}> $$ 

 $ |\phi_i> $ is the common eigenvector for both A and B (with different eigenvalues of course, since A,B represent different physical property, say one is energy, the other is total angular momentum). If you