in H_{5}) in the series equals to 2^{n}, then you can use the recursion formula (12-67) or (12-71) to coefficients of lower terms. With such convention on H(x) and normalization condition we have the wave function associated with E_{n}:

 $$ \psi_{_{n}}=\left(\frac{m\omega}{\pi\hbar}\right)^{\frac{1}{4}}\frac{1}{\sqrt{2^{^{n}}n!}}H_{_{n}}(\xi)e^{-\frac{\xi^{^{2}}}{2}} $$ 

(You may throw in (12-61) if you want to express it as function of x)

The form of the several lowest states had been plotted in the figure shown at the beginning of the section, though the functional form is quite different from that in square well, the similarity in shape is clear. For the state with large energy (large n), it looks like:

<div style="text-align: center;"><img src="imgs/img_in_chart_box_253_843_773_1020.jpg" alt="Image" width="43%" /></div>


The probability amplitude is actually higher close to the classical turning point. For the oscillator with large energy, the quantization is less obvious, the energy can be treated almost as continuous, and it approaches the classical limit. In classical mechanics, at the turning point, the particle has lowest velocity and spend more time there, so you are more likely (large probability) to find particle there.

This concludes our discussion on harmonic oscillator in quantum. I tried to solve the equation directly and find out energy quantization (12-70)