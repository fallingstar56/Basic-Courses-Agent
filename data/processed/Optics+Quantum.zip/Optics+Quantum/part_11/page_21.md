solution corresponding to a plane wave (once we plugging the time factor in) travelling towards left and right.

Now let's carry out step (2), applying boundary requirement (the continuity of  $ 1^{st} $ derivative applies here in finite potential case):

 $$ \begin{aligned}&A+B=C+D\\&k_{1}(A-B)=k_{2}(C-D)\\ \end{aligned} $$ 

The two relations cannot determine the relative ratio between them (need at least 3 independent relations for that), I shall rewrite above in matrix form, so that you see what kind of relations they provide:

 $$ \begin{pmatrix}{{{1}}}&{{{1}}} \\{{{k_{1}}}}&{{{-k_{1}}}}\end{pmatrix}\begin{bmatrix}{{{A}}} \\{{{B}}}\end{bmatrix}=\begin{pmatrix}{{{1}}}&{{{1}}} \\{{{k_{2}}}}&{{{-k_{2}}}}\end{bmatrix}\begin{bmatrix}{{{C}}} \\{{{D}}}\end{bmatrix}\quad(I just express above in matrix) $$ 

This can be used to get:

 $$ \begin{bmatrix}C\\ D\end{bmatrix}=M\begin{bmatrix}A\\ B\end{bmatrix} $$ 

M is called M matrix or transfer matrix, just one useful way to express the relation between coefficients. Another variation which is more often used is S matrix, defined as:

 $$ \begin{bmatrix}\boldsymbol{B}\\ \boldsymbol{C}\end{bmatrix}=\boldsymbol{S}\begin{bmatrix}\boldsymbol{A}\\ \boldsymbol{D}\end{bmatrix} $$ 

It is called S matrix or scattering matrix, because above shows if we have two incoming waves from left and right initially (represented by the A, D part), the component of outgoing wave (represented by B, C) can be known from S matrix. The M and S matrix here are (verify mine yourself please, by working out the relation between the