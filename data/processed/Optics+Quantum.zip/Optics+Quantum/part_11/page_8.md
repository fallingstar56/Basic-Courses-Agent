## 12 -1 Schrodinger Equation in Space Representation and General Property of Wave Function Solution

First, let me list the results of last chapter. We have learned the general form of S-equation is:

 $$ i\hbar\frac{\partial\left|\psi\right.>}{\partial t}=\hat{H}\left|\psi\right.> $$ 

H is the Hamilton operator, corresponding to the energy of the system:

 $$ \hat{H}=\frac{\hat{P}^{2}}{2m}+V(\hat{R}) $$ 

Where P and V(R) are operators of momentum and position, and the semicircle “hat” on top remind you they are operators. For the rest of these chapters, I shall use capital letter to represent the operator and I hope in most cases this won’t cause confusion. In 1-d case, we have discussed these operators, their representation in space are:

 $$ \begin{aligned}&<x\mid X\mid\psi>=x\psi(x,t)\quad\psi(x,t)=<x\mid\psi>\\ &\\ <x\mid P\mid\psi>=-i\hbar\frac{d}{dx}\psi(x,t)\quad&(12-4)\\ \end{aligned} $$ 

The  $ \psi(x,t) $ is the space representation of state vector, and it is called wave function. We see that in 1-d space, the effect of position operator is just times eigenvalue x to the wave function; the effect of momentum operator is space derivative of the wave function. In higher dimension, the wave function will depend on  $ (r, t) $, and the momentum operator would be  $ -i\hbar\nabla\psi(r,t) $.