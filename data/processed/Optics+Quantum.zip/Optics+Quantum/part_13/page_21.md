here: $ ^{96} $

 $$ S\equiv<\phi_{1}\mid\phi_{2}>=e^{-\rho}[1+\rho+\frac{1}{3}\rho^{2}] $$ 

Here all the lengths are rescaled using Bohr radius (i.e. in atomic units)

 $$ \rho\equiv\frac{R}{a_{0}},\rho_{1}\equiv\frac{r_{1}}{a_{0}},\rho_{2}\equiv\frac{r_{2}}{a_{0}}\qquad(14-16) $$ 

Because the non-zero overlap integral, the secular equation for energy eigenvalue will be different from (14-8) above, here is how we derive it:

 $$ H\mid\psi>=E\mid\psi> $$ 

 $$ H(c_{1}\mid\phi_{1}>+c_{2}\mid\phi_{2}>)=E(c_{1}\mid\phi_{1}>+c_{2}\mid\phi_{2}>) $$ 

Dot product above with bra  $ <\phi_{1}|,\langle\phi_{2}| $ respectively:

 $$ \begin{aligned}&H_{11}c_{1}+H_{12}c_{2}=Ec_{1}+ESc_{2}\quad&(14-17)\\&H_{21}c_{1}+H_{22}c_{2}=ESc_{1}+Ec_{2}\end{aligned} $$ 

In matrix form, it is:

 $$ \begin{bmatrix}H_{11}-E&H_{12}-ES\\ H_{21}-ES&H_{22}-E\end{bmatrix}\begin{bmatrix}c_{1}\\ c_{2}\end{bmatrix}=0\qquad(14-18) $$ 

Of course when $S=0$ (orthogonal), the (14-18) is reduced to (14-8).

Now we can solve it, express $E$ in terms of $H$ elements and overlap

integral $S$. The solution is actually quite simple, if we take the fact

that $H_{11}=H_{22}$ (for our symmetric diatomic molecule), $H_{12}=H_{21}$ (the

$\phi_{100}$ is a real function, and so will be the integral will $H$, that means