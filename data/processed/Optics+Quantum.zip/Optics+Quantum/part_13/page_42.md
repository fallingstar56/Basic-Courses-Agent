multiply 1 to a number) and is a very useful ‘trick’ to apply, as the below shows.

Now we can have a  $ 3^{rd} $ method to find out the matrix representation of an operator:

For an operator O, in a basis spanned by unit vectors  $ |i> $ (inserting identity matrix before and after O):

 $$ \hat{O}=\sum_{i}\left|i><i\right|\hat{O}\sum_{j}\left|j><j\right|=\sum_{i,j}<i\left|\hat{O}\right|j>\left|i><j\right|=\sum_{i j}o_{i j}\left|i><j\right| $$ 

|i><j|is not exactly an projector, it is called dyad and what it does is shown below explicitly for |2><1| (this part is also in the quantum note ):

 $$ \begin{aligned}|2>=&\begin{bmatrix}{{{0}}} \\{{{1}}} \\{{{0}}} \\{{{0}}} \\{{{\cdot}}} \\{{{\cdot}}}\end{bmatrix},\quad<1|=\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}}&{{{\cdot}}} \\\end{bmatrix}\qquad|2><1|=\begin{pmatrix}{{{0}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{\ddots}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\\end{pmatrix}\end{aligned} $$ 

It is just a rank one matrix with 1 at position 21, and the rest are zeroes.

So the  $ o_{ij} \mid i < j $ is just another way to say the matrix element at ith

row, jth column is  $ o_{ij} $ and the whole matrix is a summation of these

kinds of terms. Relation (9) is just same as method 2 to get matrix

elements. But now consider we use the eigenvectors of the  $ \hat{O} $ as basis,

the eigenvalues are  $ \lambda_{i} $ and associated eigenvector is  $ |\phi_{i}\rangle $:

 $$ \hat{O}\mid\phi_{i}>=\lambda_{i}\mid\phi_{i}> $$ 

With the eigenvector as basis, the O will be diagonal, with eigenvalues