(14-3), the two localized Is orbital, as the basis. The molecular orbital would be in form of:

 $$ \left|{{\psi}}\right>=c_{1}\left|{{\phi_{1}}}\right>+c_{2}\left|{{\phi_{2}}}\right>\qquad(14-13) $$ 

The two linear independent (LI) base vectors will form two LI molecular orbitals, corresponding to the lowest bonding and antibonding orbitals. One obvious defect is that we only include two base vectors, while we should include more (such as 2s, 2p, 3s, 3p, 3d...) if we need accurate results. As I mentioned in last section, the two 1s will make the most important contribution and also are sufficient to illustrate the basic character in chemical bond, so I shall use the two base vectors only (this makes it a 2-level system).

In the usual treatment in 2-level system, the zeroth order states are usually chosen orthonormal, which is what I used in last section. However, a look on the  $ |\phi_1>,|\phi_2> $ will reveal that their dot product  $ <\phi_1|\phi_2>\neq0 $. The  $ |\phi_1>,|\phi_2> $ here are two real functions centered at two nuclei drop exponentially, and the dot product:

 $$ <\phi_{1}\mid\phi_{2}>=\int\phi_{100}(r_{1})\phi_{100}(r_{2})d r^{3}\qquad(14-14) $$ 

It is the overlap of the two 1s orbitals centered at  $ N_{1} $,  $ N_{2} $ with R

distance between them. Only when the R is large, the overlap is close

to zero. This integral is thus called overlap integral; it can be

computed by using elliptical coordinate, and only the results given