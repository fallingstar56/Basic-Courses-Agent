the Q_H (Q for quarter-wave, H for fast axis along H direction), in the |H>, |V> basis:

 $ \hat{Q}_H \left| H \right\rangle = e^{i\varphi_H} \left| H \right\rangle; \hat{Q}_H \left| V \right\rangle = e^{i\varphi_V} \left| V \right\rangle, \varphi_H - \varphi_V = -\frac{\pi}{2}, \text{then the matrix form of } Q_H \text{ is then:} $

 $$ \left(Q_{11}=\left\langle H\left|\hat{Q}_{H}\right|H\right\rangle,\mathbf{e t c}\right) $$ 

 $$ \hat{Q}_{H}=\begin{pmatrix}{{{e^{i\varphi_{H}}}}}&{{{0}}} \\{{{0}}}&{{{e^{i\varphi_{V}}}}}\end{pmatrix}=e^{i\varphi_{H}}\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{i}}}\end{pmatrix} $$ 

There are still other methods to get the expression of operator in certain basis, but I have to introduce an important operation first:

## Projector

Though here I used the polarization of light as example, but the discussion is general and can be extended to the vector state in Q.M and higher dimensional space (polarization is 2-D)

For a Jones vector representation of polarization, let's say |E> to represent this vector, to write out the vector explicitly, in the Jones vector form, of course we need basis (orthonormal vectors form basis, in 2-D, a basis consist 2 vectors, orthogonal and normalized to 1, so called orthonormal), the one easy to imagine is the H-V basis consists of horizontally and vertically polarized light as basis vector, in such basis:

 $$ \left|\boldsymbol{E}\right\rangle=\begin{bmatrix}h\\ v\end{bmatrix}=h\begin{bmatrix}1\\ 0\end{bmatrix}+v\begin{bmatrix}0\\ 1\end{bmatrix}=h\left|\boldsymbol{H}\right\rangle+v\left|\boldsymbol{V}\right\rangle $$ 

 $ \begin{bmatrix} h \\ v \end{bmatrix} $ then is the Jones vector of the polarization  $ |E> $ in H-V basis