 $$ \left\langle E\Big|E\right\rangle=\left[a^{*}b^{*}\right]\begin{bmatrix}a\\ b\end{bmatrix}=a^{*}a+b^{*}b $$ 

(the last directly follows from matrix product rules of linear algebra), the dot product results in a scalar value which is exactly same as dot product of the ‘old’ representation which you may be more familiar or comfortable with.

A note here, because matrix product are sensitive to the order of matrix, so direct product can only be represented by the “Braket”  $ \langle E|E\rangle $ (the order is important, where  $ |E\rangle\langle E| $ represents a total different physical meaning, it is a ‘projector’ I shall show you right away that it is an operator in 2 x 2 matrix form (in 2-D), not a scalar number as dot product); where in old representation,  $ \vec{E} \cdot \vec{E} = \vec{E} \cdot \vec{E}^* $, the order does not matter.

Recall that in linear algebra, the inner product (another name for scalar or dot product) is represented as  $ E^{T}E $, and the projector as  $ EE^{T} $, for vectors in real space; for the vectors in complex space, the transposed matrix would be replaced by the adjoint matrix  $ E^{+} $, which is the transposed and complex conjugated matrix of the original one. Dirac notation just uses another bookkeeping to express these linear algebra relations: ‘Ket’ vector in matrix representation would be column vector, ‘Bra’ would be transposed and complex conjugated.

(4)The matrix representation of an Operator (physical operation that