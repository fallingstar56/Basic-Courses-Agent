Secondly what is the eigenstate of the detection? We know that there are two exclusive events here in the detection: one is as in fig.3-9 (a), the spin up ends in D1, and spin down in D2; the other would be spin up ends in D2, spin down in D1 as in fig. 3-9 (b). Let's consider the eigenstates for the case (a): one electron with spin up being scattered into direction  $ \theta $, while the other with spin down into  $ \pi-\theta $. The proper description for this eigenstate would be:

 $$ \begin{aligned}|\uparrow,\theta;\downarrow,\pi-\theta>=\frac{\sqrt{2}}{2}(|1,\uparrow,\theta;2,\downarrow,\pi-\theta>-|1,\downarrow,\pi-\theta;2,\uparrow,\theta>)\end{aligned} $$ 

Now we could calculate the probability of detection in case (a):

 $$ P(\uparrow D1,\downarrow D2)=|\langle\uparrow,\theta;\downarrow,\pi-\theta\mid\psi_{12}\rangle|^{2} $$ 

We can put above expressions for the states to evaluate the Bracket:

 $$ \begin{aligned}<\uparrow,\theta;\downarrow,\pi-\theta\mid\psi_{12}>=&\frac{1}{2}(<1,\uparrow,\theta;2,\downarrow,\pi-\theta|-<1,\downarrow,\pi-\theta;2,\uparrow,\theta|)\\&\hat{\mathrm{O}}(|1,\uparrow,L;2,\downarrow,R>-|1,\downarrow,R;2,\uparrow,L>)\\\end{aligned} $$ 

There will be total of four terms in forms of BraKet, I will evaluate each term below:

 $$ <1,\uparrow,\theta;2,\downarrow,\pi-\theta\mid\hat{O}\mid1,\uparrow,L;2,\downarrow,R>=<1,\theta;2,\pi-\theta\mid\hat{O}\mid1,L;2,R>=f(\theta) $$ 

Here use the orthonormal conditions of the spin states for each particle and the result of this term will give the  $ f(\theta) $ same meaning as before. Of course I assume here that the interaction during the collision (the O operator) do not change the spin state (that is why I can take the spin state out of operator and dot product them). Indeed if the spin state can be switched during the collision, then you cannot tell the spin up ends at