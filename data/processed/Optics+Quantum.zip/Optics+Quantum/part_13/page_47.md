The +45 linear polarizer, its eigenvector is  $ |+45> $ linear polarized light with eigenvalue 1; another eigenvector is  $ |-45> $ and the eigenvalue is 0.

 $$ \begin{aligned}&\hat{L}_{+45}=1\mid+45><+45\mid+0\mid-45><-45\mid=\mid+45><+45\mid\\ &\mid+45>=\frac{\sqrt{2}}{2}(|1>+|2>)=\frac{\sqrt{2}}{2}\begin{bmatrix}{{{1}}} \\{{{1}}}\end{bmatrix},<+45\mid=\frac{\sqrt{2}}{2}\begin{bmatrix}{{{1}}}&{{{1}}} \\\end{bmatrix}\\ &\mid+45><+45\mid=\frac{1}{2}\begin{bmatrix}{{{1}}} \\{{{1}}}\end{bmatrix}\begin{bmatrix}{{{1}}}&{{{1}}} \\\end{bmatrix}=\frac{1}{2}\begin{pmatrix}{{{1}}}&{{{1}}} \\{{{1}}}&{{{1}}}\end{pmatrix}\\ \end{aligned} $$ 

To solve this simple problem with 4 different methods is indeed like shooting a bug with cannon, but this kind of systematic treatment will be important in quantum mechanics.

In the homework, you may be asked to calculate the matrix form of a right circular polarizer under  $ |H\rangle,|V\rangle $ basis. Please try all the methods above as a practice for yourself. I will list the solution below, but you may choose to do that yourself first before reading my answer (or skip completely my answer below, since nothing new there)

Answers to the matrix form of Right-Circular Polarizer in  $ |H\rangle, |V\rangle $ basis:

The notations and base vectors relations:

R is the symbol for operator that acts as right-circular polarizer. What it does is let right-circular light pass completely and block the left-circular polarized light. i.e. the right circular polarized is an eigenvector to R with eigenvalue 1; left circular light is another eigenvector with eigenvalue 0. Let  $ |H> = |I>| $,  $ |V> = |2> $;  $ (\vert H\rangle, \vert V\rangle $ are linear polarized light)