momentum for the excited helium configuration 1s2s. Such wave

functions will play important roles in the accurate calculation of

energy state in multi-electron atoms.

## 13 -3-2 Collisions between Identical Particles

After we have equipped with this knowledge for many body system of identical particles, the results of experiment shown in fig.3-8 at the beginning of this chapter can be fully derived from using quantum postulates.

(1)Interference term in collisions among identical particles

For the two Boson particles ( $ \alpha $ particles for instance), the initial state is:

 $$ |\psi_{1,2}>_{iboson}=\frac{\sqrt{2}}{2}(|1,L;2,R>+|2,L;1,R>) $$ 

(This state is quite different from that of non-identical case, which is

 $$ |A,L;B,R>\mathrm{o n l y}) $$ 

The product state after collision is:

 $ \psi_{1,2} >_{boson} = \hat{O} \mid \psi_{1,2} >_{ibonson} $, where  $ \hat{O} $ is the interaction operator during collision.

Expand this product state into components of in terms of  $ |1,\theta;2,\pi-\theta> $ (please refer to the part of non-identical case for the meaning of notations used below):