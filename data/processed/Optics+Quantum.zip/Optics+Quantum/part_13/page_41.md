association rules)

Clearly  $ \sum_{i=a,b}|E_i\rangle\langle E_i| $ should be 1 (the identity matrix)  $ \begin{bmatrix}1&0\\ 0&1\end{bmatrix} $.

 $ |E_i\rangle\langle E_i| $ is an operator, it is called projector, what it does is to ‘project’ any vector to show its component of  $ |E_i\rangle $, like  $ |E_a\rangle\langle E_a| $ acts on  $ |E> $. it produce  $ a|E_a\rangle $. In matrix form (in 2-D), this projector is 2X2 matrix. For example, in the H-V basis,  $ |H\rangle\langle H| $ is the projector gives the H components of any vector

 $$ \left|\boldsymbol{H}\right\rangle=\begin{bmatrix}{{{1}}} \\{{{0}}}\end{bmatrix},\quad\left\langle\boldsymbol{H}\right|=\left[\begin{matrix}{{{1}}}&{{{0}}}\end{matrix}\right],\quad\left|\boldsymbol{H}\right\rangle\left\langle\boldsymbol{H}\right|=\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{pmatrix} $$ 

If you act this  $ |H\rangle\langle H| $ on any vector state  $ |E\rangle=\begin{bmatrix}h\\ v\end{bmatrix} $, then it will project the H component (horizontal linear polarized)out:

 $$ \left|H\right\rangle\left\langle H\right|\left|E\right\rangle=\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{pmatrix}\begin{bmatrix}{{{h}}} \\{{{v}}}\end{bmatrix}=\begin{bmatrix}{{{h}}} \\{{{0}}}\end{bmatrix}=h\left|H\right\rangle $$ 

This is what a projector does. (Please also refer to linear algebra to see how projector there is represented, you should be able to see that it is the same as discussed here)

 $$ \sum_{i=a,b}\left|E_{i}\right\rangle\left\langle E_{i}\right|={\bf1} $$ 

this means if the basis is complete, then knowing all of each component (also called “projection”) is equivalent of knowing the complete vector, this is the condition to test whether a basis is complete, but in 2-D space, it is obvious 2 orthogonal vectors would satisfy it. The 1 identity matrix can be inserted into the equation and will not affect the relation (similar to