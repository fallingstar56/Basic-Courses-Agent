I shall do this in atomic unit: (a reminder:  $ m_e = 1, a_0 = 1 $,  $ \frac{e}{\sqrt{4\pi \varepsilon_0}} = 1 $,  $ \hbar = 1 $,  $ E_{1s(\text{hydrogen})} = \frac{1}{2} $)

Hamiltonian (14-1) in atomic units will be:

 $$ H(in\ a u)=-\frac{1}{2}\Delta-\frac{1}{\rho_{1}}-\frac{1}{\rho_{2}}+\frac{1}{\rho}\qquad(14-22) $$ 

Note:  $ H_1 \equiv -\frac{1}{2} \Delta - \frac{1}{\rho_1}, H_2 \equiv -\frac{1}{2} \Delta - \frac{1}{\rho_2} $ are just  $ H $ for hydrogen atoms with  $ |\phi_1>, |\phi_2> $ are eigenstates respectively.

The Matrix element for H in (14-22) in basis of  $ \left|\phi_{1}>, \left|\phi_{2}\right>\right. $ are:

 $$ \begin{aligned}&H_{11}=<\phi_{1}\mid H\mid\phi_{1}>=<\phi_{1}\mid H_{1}\mid\phi_{1}>-<\phi_{1}\mid\frac{1}{\rho_{2}}\mid\phi_{1}>+<\phi_{1}\mid\frac{1}{\rho}\mid\phi_{1}>\\ &<\phi_{1}\mid H_{1}\mid\phi_{1}>=-\frac{1}{2}\quad(forls energy in hydrogen)\\ &C\equiv<\phi_{1}\mid\frac{1}{\rho_{2}}\mid\phi_{1}>={\int\frac{\mid\phi_{100}(\rho_{1})\mid^{2}}{\rho_{2}}dr^{3}}\quad(14-23)\\ \end{aligned} $$ 

This is the Coulomb attraction between the nucleus at N₂ to the electron at r₁. (You will have similar term in H₂₂, but r₁, r₂ are switched) This is why this integral is called Coulomb integral.

 $$ <\phi_{1}\mid\frac{1}{\rho}\mid\phi_{1}>=\frac{1}{\rho}<\phi_{1}\mid\phi_{1}>=\frac{1}{\rho} $$ 

This is the result of Born-Oppenheimer approximation, the R (and ρ)

here is some fixed parameter. The the H is:

 $$ H_{11}=-\frac{1}{2}-C+\frac{1}{\rho}\qquad(14-24) $$ 

For the H12: