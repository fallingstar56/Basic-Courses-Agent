 $$ \hat{S}=\begin{bmatrix}{{{<1^{\prime}|1>}}}&{{{<1^{\prime}|2>}}} \\{{{<2^{\prime}|1>}}}&{{{<2^{\prime}|2>}}}\end{bmatrix}=\frac{\sqrt{2}}{2}\begin{pmatrix}{{{1}}}&{{{1}}} \\{{{-1}}}&{{{1}}}\end{pmatrix},\quad\hat{S}^{-1}=\hat{S}^{T}=\frac{\sqrt{2}}{2}\begin{pmatrix}{{{1}}}&{{{-1}}} \\{{{1}}}&{{{1}}}\end{pmatrix} $$ 

 $$ \hat{L}_{+45(|1>,|2>)}=\hat{S}^{-1}\hat{L}_{+45(|1^{\prime}\rangle,|2^{\prime}\rangle)}\hat{S}=\frac{1}{2}\binom{1\quad-1}{1\quad1}\binom{1\quad0}{0\quad0}\binom{1\quad1}{-1\quad1}=\frac{1}{2}\binom{1\quad1}{1\quad1} $$ 

That is quite a long derivation for this simple problem. Of course the point is to show you the similarity transform.

b) Method 1: Apply the +45 linear polarizer on the |1> and |2> base vectors

If the +45 polarizer act on the  $ |1> $ (The H linear polarized light), the output will be a +45 linear polarized light with  $ \frac{\sqrt{2}}{2} $ amplitude:

 $$ \hat{L}_{+45}\mid1>=\frac{\sqrt{2}}{2}\mid+45>=\frac{1}{2}(\mid1>+\mid2>)=\frac{1}{2}\begin{bmatrix}1\\ 1\end{bmatrix} $$ 

As I proved before, this will give us the first column of the matrix  $ L_{+45} $.

Similarly:

 $$ \hat{L}_{+45}\mid2>=\frac{\sqrt{2}}{2}\mid+45>=\frac{1}{2}(\mid1>+\mid2>)=\frac{1}{2}\begin{bmatrix}1\\ 1\end{bmatrix} $$ 

So the matrix form of L in  $ |1>-|2> $ basis is:

 $$ \hat{L}_{+45(|1>,|2>)}=\frac{1}{2}\binom{1\quad1}{1\quad1} $$ 

c) Method 2: direct calculate the matrix element

 $$ l_{11}=<1\mid L_{+45}\mid1>=\frac{\sqrt{2}}{2}<1\mid+45>=\frac{1}{2};l_{12}=<1\mid L_{+45}\mid2>=\frac{\sqrt{2}}{2}<1\mid+45>=\frac{1}{2} $$ 

For other elements, the calculation is similar. It is about same amount work as method 1.

d) Method 3: Projector