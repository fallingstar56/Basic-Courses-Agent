conjugate:  $ <2'| = -\frac{\sqrt{2}}{2}i(<1|-<2|) $. Of course the above can also be directly read from matrix S)

The reason I express  $ |1\rangle $,  $ |2\rangle $ in terms of  $ |1'\rangle $,  $ |2'\rangle $ is because the action of operator  $ R $ on  $ |1'\rangle $,  $ |2'\rangle $ are obvious (they are eigenstates of  $ R $), i.e.  $ \widehat{R} |1'\rangle = |1'\rangle $;  $ \widehat{R} |2'\rangle = 0 |2'\rangle = 0 $. To write the  $ R $ in  $ |1\rangle $,  $ |2\rangle $ basis, we act  $ R $ on  $ |1\rangle $ first to get the first column of the matrix (need to be expressed in  $ |1\rangle $,  $ |2\rangle $ basis):

 $ \hat{R} \mid 1 \geq \frac{\sqrt{2}}{2} \mid 1' \geq \frac{1}{2} \left[1 - i\right] $, this is the first column of  $ R $ in  $ |1>, |2> $ basis.

 $ \hat{R} \mid 2 \geq \frac{\sqrt{2}}{2} i \mid 1' \geq \frac{1}{2} i \begin{bmatrix} 1 \\ -i \end{bmatrix} = \frac{1}{2} \begin{bmatrix} i \\ 1 \end{bmatrix} \quad 2^{nd} \text{ column.} $

c) Method 2:

 $$ R_{11}=<1\mid R\mid1>=\frac{1}{2}(<1^{\prime}|+<2^{\prime}|)R(\mid1^{\prime}>+\mid2^{\prime}>)=\frac{1}{2} $$ 

 $$ R_{12}=<1\mid R\mid2>=\frac{1}{2}(<1^{\prime}|+<2^{\prime}|)R(i\mid1^{\prime}>-i\mid2^{\prime}>)=\frac{1}{2}i $$ 

 $$ R_{_{21}}=<2\mid R\mid1>=\frac{1}{2}(-i)(<1^{\prime}|-<2^{\prime}|)R(\mid1^{\prime}>+\mid2^{\prime}>)=-\frac{1}{2}i $$ 

 $$ R_{22}=<2\mid R\mid2>=\frac{1}{2}(-i)(<1^{\prime}|-<2^{\prime}|)R(i\mid1^{\prime}>-i\mid2^{\prime}>)=\frac{1}{2} $$ 

d) Method 3:

 $$ \hat{R}=1\left|1^{\prime}><1^{\prime}\right|+0\left|2^{\prime}><2^{\prime}\right|=\left|1^{\prime}><1^{\prime}\right|=\frac{1}{2}\begin{bmatrix}{{{1}}} \\{{{-i}}}\end{bmatrix}\left[1\quad i\right]=\frac{1}{2}\begin{pmatrix}{{{1}}}&{{{i}}} \\{{{-i}}}&{{{1}}}\end{pmatrix} $$ 

(5)The matrix form of the operator acts in the complex conjugate (the ‘bra’) space