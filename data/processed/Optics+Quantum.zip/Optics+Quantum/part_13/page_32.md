(2)Dirac’s notation and its matrix form

Any vectors expanded on this basis will have component along  $ |1> $ or  $ |2> $,

let's say a and b are the coefficients:

Then  $ |E\rangle = a|1\rangle + b|2\rangle $ (the usual way represent a vector in 2-D Cartesian coordinate is an example:  $ \vec{E} = a\vec{i} + b\vec{j} $).

We could use a ordered array of a,b to represent the vector too (ordered means we already arrange the basis, such as 1st entry of the column matrix is the coefficient of expansion along |1>, 2nd is along |2>, etc)

Then: in matrix form

 $$ \left|\boldsymbol{E}\right\rangle=\begin{bmatrix}a\\ b\end{bmatrix}=a\begin{bmatrix}1\\ 0\end{bmatrix}+b\begin{bmatrix}0\\ 1\end{bmatrix} $$ 

where  $ \begin{bmatrix} 1 \\ 0 \end{bmatrix} $ and  $ \begin{bmatrix} 0 \\ 1 \end{bmatrix} $ are the matrix representation of base vector  $ |1> $ and  $ |2> $, and the complex-conjugate of the vector  $ |1> $,  $ |2> $, the  $ <1| $,  $ <2| $ are represented by  $ [1\ 0] $ and  $ [0\ 1] $, the row matrix form (Here, 0,1 are real so complex conjugates are same)

Here using a column matrix  $ (n \times 1 \text{ matrix}) $ to represent vector is a traditional but an artificial choice, and the following calculation are according to this choice. (if you choose a row matrix to represent the vector, then the physics is still same, but the calculation will be different) Using the orthonormal property of the base vectors, the expansion coefficient a, b can be calculated or just written as:

 $ a=\langle1|E\rangle,b=\langle2|E\rangle $, the dot product between the base vectors and the vector