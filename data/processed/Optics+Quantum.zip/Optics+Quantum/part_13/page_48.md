 $ |R>=|1',|L>=|2';(|R>,|L>\text{ are circular polarized light, and they} $

form another orthonormal basis)

 $$ \left|1^{\prime}\right\rangle=\frac{\sqrt{2}}{2}\begin{bmatrix}1\\ -i\end{bmatrix}=\frac{\sqrt{2}}{2}\left(\left|1>-i\right|2\right) $$ 

 $$ \left|2^{\prime}\right\rangle=\frac{\sqrt{2}}{2}\begin{bmatrix}1\\ i\end{bmatrix}=\frac{\sqrt{2}}{2}(\left|1\right\rangle+i\left|2\right\rangle) $$ 

From these coefficients we can get  $ \hat{S}^{-1} = \hat{S}^{+} $ (whose elements are <I | I '>, etc. i.e, the |I '> expression gives the first column in  $ \hat{S}^{-1} = \hat{S}^{+} $)

 $$ \hat{S}^{-1}=\hat{S}^{+}=\frac{\sqrt{2}}{2}\begin{pmatrix}{{{1}}}&{{{1}}} \\{{{-i}}}&{{{i}}}\end{pmatrix},\hat{S}=\frac{\sqrt{2}}{2}\begin{pmatrix}{{{1}}}&{{{i}}} \\{{{1}}}&{{{-i}}}\end{pmatrix} $$ 

Of course, same result can be obtained by expressing  $ |1\rangle $,  $ |2\rangle $ in terms of  $ |1'\rangle $,  $ |2'\rangle $ and find out S first like what I did before.

## a) Method 0:

The matrix form for R under  $ |1\rangle, |2\rangle $ basis is simple:

 $$ \widehat{R}_{|1^{\prime}>,|2^{\prime}>}=\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{pmatrix} $$ 

In the  $ |1\rangle, |2\rangle $ basis, It is:

 $$ \widehat{R}_{|1>,|2>}=\widehat{S}^{-1}\widehat{R}_{|1>,|2>},\widehat{S}=\frac{1}{2}\binom{1\quad1}{-i\quad i}\binom{1\quad0}{0\quad0}\binom{1\quad i}{1\quad-i}=\frac{1}{2}\binom{1\quad i}{-i\quad1} $$ 

b) Method 1:

 $$ |I>=<I^{\prime}|I>|I^{\prime}>+<2^{\prime}|I>|2^{\prime}>=\frac{\sqrt{2}}{2}(|1^{\prime}>+|2^{\prime}>) $$ 

 $$ |2>=<1^{\prime}|2>|1^{\prime}>+<2^{\prime}|2>|2^{\prime}>=\frac{\sqrt{2}}{2}i(|1^{\prime}>-|2^{\prime}>) $$ 

(be careful when take conjugate of  $ |2'\rangle $ to get  $ <2' $|, need to complex