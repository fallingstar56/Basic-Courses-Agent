## References for Quantum Part:

(the order reflects how close related to our course)

1. D. Griffiths. Introduction to Quantum Mechanics Chap.1-5

2. Feynman et al. Feynman lectures on Physics Vol. III, Chap. 1-8

3. R. Shankar. Principles of Quantum Mechanics. Chap 1-7

4. C. Cohen-Tannoudji et al. Quantum Mechanics. Vol. one, Chap 1-7; Vol. two, Chap. 10, 14

5. JJ. Sakura. Modern Quantum Mechanics. Chap1,2

6. D.F. Lawden. The Mathematical Principles of Quantum Mechanics.

Chap. 1-4

7. S. Thornton and A. Rex. Modern physics—for Scientists and Engineers. (3 $ ^{rd} $ edition, international student edition) Chap 1-6.

8. 杨福家 原子物理学（第四版）高教出版社

9. P.A. Dirac. Principles of Quantum Mechanics

10. D. Bohm. Quantum Theory. (1951) Chap1-10

11. L. Pauling and E.B. Wilson Introduction to Quantum Mechanics

12. L.I. Schiff. Quantum Mechanics

13. N. Zettili. Quantum Mechanics Concepts and Applications

14. I.N. Levine. Quantum Chemistry (6th edition)