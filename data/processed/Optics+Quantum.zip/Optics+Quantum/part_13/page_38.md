 $$ \begin{bmatrix}a^{\prime}\\ b^{\prime}\end{bmatrix}=\begin{pmatrix}o_{11}&o_{12}\\ o_{21}&o_{22}\end{pmatrix}\begin{bmatrix}a\\ b\end{bmatrix} $$ 

The matrix elements of ☑ can be found out by:

 $$ o_{ij}=\left\langle i\left|\hat{O}\right|j\right\rangle $$ 

i,j are the base vectors. This can be easily seen as following:

 $$ \begin{aligned}&a^{\prime}=\left\langle1\right|E^{\prime}\rangle=\left\langle1\right|\hat{O}\left|E\right\rangle=\left\langle1\right|\hat{O}\left\{1\right\}\left\langle1\right|+\left|2\right\rangle\left\langle2\right|\}\left|E\right\rangle\\ &=\left\langle1\right|\hat{O}\left|1\right\rangle a+\left\langle1\right|\hat{O}\left|2\right\rangle b\\ \end{aligned} $$ 

(here I used completeness of base 1,2, i.e. inserting  $ \sum_{i=1,2}|i\rangle\langle i|=1 $ into the equation, this is of course just express the  $ |E> $ in terms of its components along  $ |1> $ and  $ |2> $ )

Compare with the beginning relation of this section, clearly  $ o_{ij} = \langle i | \hat{O} | j \rangle $.

(I only prove half but the rest is same).

The physical meaning of this  $ o_{ij}=\langle i|\hat{O}|j\rangle $, is of course direct from definition, that an operation acts on the base vector, this may change the base vector into some other vectors, the resulting vectors components along basis gives the corresponding matrix elements of the operation, so that in short, the matrix form of a operator in some basis is determined by its action on the basis vectors. (This is not a surprising but an expected behavior, since every vector can be expanded into a complete basis, then if the operators action on the basis vector is known, its action on any vectors in the space can be analyzed, I repeated here of what I discussed earlier as in method 1. Indeed this method2 are essentially same as method 1). For example the quarter wave plate with fast axis horizontal,