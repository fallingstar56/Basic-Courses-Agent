along the diagonal, i.e.:

 $$ <\phi_{i}\mid\hat{O}\mid\phi_{j}>=\lambda_{i}\delta_{ij} $$ 

Under this eigenvector basis, the O can be expressed as:

 $$ \hat{O}=\sum_{i}\lambda_{i}\mid\phi_{i}><\phi_{i}\mid $$ 

It is a summation of projectors with eigenvalues in front of it. Though (12) is proved using eigenvector as basis, it can be used to find the expression of O in other basis, just throw in the expression of eigenvectors in that particular basis. This is true because relation like (12) is a tensor relation which should hold independent of choice of basis.

All these methods are best illustrated by examples. In the polarization part, I derived the matrix form for a +45 linear polarizer. Here I shall show the details using various methods:

In the optics notes I used transform between basis to find out the +45 linear polarizer in |H>,|V> basis, that is basically similarity transform in linear algebra, and I shall call it method 0.

## a) Method 0: Similarity Transform

The  $ |H\rangle $,  $ |V\rangle $ linear polarized light will be termed as  $ |1\rangle $,  $ |2\rangle $; The  $ |+45\rangle $,  $ |-45\rangle $ linear polarized light will be termed as basis  $ |1\rangle $,  $ |2\rangle $.

The +45 polarizer’s matrix form in the 1’, 2’ basis is clear, it allows a complete pass of |1’>, and completely block |2’> (that is the property of the +45 linear polarizer), so the matrix form of +45 polarizer in basis|1’>,|2’> is: