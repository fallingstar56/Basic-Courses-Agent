<div style="text-align: center;"><img src="imgs/img_in_image_box_214_174_477_471.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;">Fig. 4–3. A double scattering into nearby final states.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_542_193_818_476.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;">Fig. 4–4. The scattering of n particles into nearby final states.</div>


This is really a natural conclusion from the  $ |f(\theta)+f(\pi-\theta)|^2 $ results in boson scattering. We see there that due to interference, along certain direction which corresponds to the final state of the particle, the probability of bosons being scattered into that direction is enhanced. The book contains a detailed arguments in two boson case. It shows that  $ P_2 $, the probability for two bosons ending in the same final state, is twice as big as that for two non-identical particles. Following the derivation given in the example 4 here, we can derive this probability (the case in fig. 4-3):

Initial state for two photon, one along path a and the other along b:

 $$ |\psi_{12}>=\frac{\sqrt{2}}{2}(|1,a;2,b>+|1,b;2,a>) $$ 

The final state after scattering is: 94

 $$ |1,\theta;2,\theta> $$ 

Then the probability for the initial photons ending into the final state: