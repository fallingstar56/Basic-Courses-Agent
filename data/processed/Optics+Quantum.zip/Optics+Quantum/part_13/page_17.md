case  $ (H_{11}=H_{22}) $ are shown in the figure above.

Clearly from (14-9), we have energy splitting due to the interactions between electron with all nuclei (the extra terms in H). In our case when  $ H_{11}=H_{22} $, the splitting comes from the off-diagonal term. The lower energy will be more stable, and the wave function associated to it is called “bonding” orbital; the higher energy state is not stable, it likes to dissociate into atoms, and the wave function associated to it is thus called “anti-bonding”. Now let’s solve the wave function forms for the bonding and anti-bonding (We have already solved a similar problem in homework for the eigenstates of spin matrix). It is straightforward to get:

 $$ \begin{aligned}&|\psi_{+}>=\cos\frac{\theta}{2}e^{-i\frac{\varphi}{2}}|\phi_{1}>+\sin\frac{\theta}{2}e^{i\frac{\varphi}{2}}|\phi_{2}>\\&|\psi_{-}>=-\sin\frac{\theta}{2}e^{-i\frac{\varphi}{2}}|\phi_{1}>+\cos\frac{\theta}{2}e^{i\frac{\varphi}{2}}|\phi_{2}>\\ \end{aligned} $$ 

The  $ \theta,\varphi $ are:

 $$ \begin{aligned}&\tan\theta=\frac{2\left|H_{21}\right|}{H_{11}-H_{22}}\quad0\leq\theta\leq\pi\\&H_{21}=\left|H_{21}\right|e^{i\varphi}\\ \end{aligned} $$ 

Above are general formulas for any 2-level system.

For our  $ H_{2}^{+} $,  $ H_{11}=H_{22} $, thus  $ \theta=\frac{\pi}{2} $; we do not know the form of  $ H_{21} $ yet, but it can be shown for the attractive system (in the formation of molecule, we expect the attractive will win over the repulsion), it is a negative number (this will be shown in the next section when we