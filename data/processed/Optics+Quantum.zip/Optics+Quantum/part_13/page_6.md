the detector comes from right or left! Then we would expect some interference.

 $$ <1,\downarrow,\pi-\theta;2,\uparrow,\theta\mid\hat{O}\mid1,\uparrow,L;2,\downarrow,R>=0 $$ 

Because of for particle 1 or 2,  $ \langle\uparrow\downarrow\rangle=0^{93} $

Similarly:

 $$ <1,\uparrow,\theta;2,\downarrow,\pi-\theta|\hat{O}|1,\downarrow,R;2,\uparrow,L>=0 $$ 

 $$ <1,\downarrow,\pi-\theta;2,\uparrow,\theta\mid\hat{O}\mid1,\downarrow,R;2,\uparrow,L>=f(\theta) $$ 

So:

 $$ P(\uparrow D1,\downarrow D2)=|\langle\uparrow,\theta;\downarrow,\pi-\theta\mid\psi_{12}>|^{2}=|\frac{1}{2}(f(\theta)+f(\theta))|^{2}=|f(\theta)|^{2} $$ 

For the case (b), you should be able to find out that:

 $$ P(\downarrow D1,\uparrow D2)=|\prec\downarrow,\theta;\uparrow,\pi-\theta\mid\psi_{12}>|^{2}=|f(\pi-\theta)|^{2} $$ 

The probability for detector D1 to detect either spin up or down would be the summation of the two probabilities calculated above, since these two events are exclusive.

You may now ask what happened if both electrons are spin up? Well this is actually already solved before without explicitly involving the spin states. Here if we include the spin states, I will only outline the procedure without detailed calculation.

First the description of the initial state would be: