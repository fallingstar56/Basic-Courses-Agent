 $$ P_{2b o s o n}=|<1,\theta;2\theta\mid\psi_{12}>|^{2}=\frac{1}{2}\mid a b+b a\mid^{2}=2\mid a\mid^{2}\mid b\mid^{2} $$ 

Here:

 $$ \begin{aligned}&<1,\theta;2,\theta\mid1,a;2,b>=<1,\theta\mid1,a><2,\theta\mid2,b>=ab\\&<1,\theta;2,\theta\mid1,b;2,a>=<1,\theta\mid1,b><2,\theta\mid2,a>=ba\\ \end{aligned} $$ 

If the detector has a small area of  $ \Delta s $, then the probability for single particle taking the a (or b) path to be scattered into final state is  $ |a|^2 \Delta s $ (or  $ |b|^2 \Delta s $ for b), the probability amplitude would be  $ a(\Delta s)^{1/2} $ and  $ b(\Delta s)^{1/2} $ respectively for the two paths. The above results would be adjusted:

 $$ P_{_{2boson}}=\frac{1}{2}\left|ab\Delta s+ba\Delta s\right|^{2}=2\left|a\right|^{2}\left|b\right|^{2}\left(\Delta s\right)^{2} $$ 

The |a|2|b|2(Δs)² is just the probability for two non-identical particles

being scattered into the detector. So this shows:

P(2boson → same state) = 2P(2 non−identical → same state)

(for fermions this probability would be zero)

Another way to put the above results is this: If there is already a boson in

certain final state (here in this example, it is the final direction, let's say

photon along path b has already been scattered into this direction,

 $ |b|^2\Delta s=1 $, another boson will be more likely to go into the same state.

Comparing to the probability of single particle, the probability is

increased by 2.

As the number of bosons increases, this tendency is even more obvious.

For the n bosons all scattered into the same state is given by (4-20) in

Feynman's, it is easy to derive: