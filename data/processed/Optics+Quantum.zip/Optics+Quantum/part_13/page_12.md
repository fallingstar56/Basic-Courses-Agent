## Chapter 14 Application of Quantum Theory to Molecule and Solid State

In this chapter, I shall apply what we have learned to the more

complicated system, namely molecules and solid state. Of course I have

to confess there are quite a few basic topics needed for a somewhat

detailed discussion on these; such as angular momentum, approximation

methods etc. which I have not covered. Also as in multi-electron atom

case, we do not have rigorous analytic solutions for most cases. However,

from what we had learned, I can show you why the molecule bond

together; why there is so called energy band structure in solid. These are

the main focus in this chapter. I shall explain in detail in the molecular

case, using the simplest molecular ion  $ H_{2}^{+} $ as example; while for the

solid state, the Griffiths' section 5.3 gives a nice discussion, and hence I

shall leave you to read that for the solid part.

## 14 -1 Molecular Obital and Bonding in  $ H_{2}^{+} $

When you come across molecule in chemistry (high school or college), people usually say that the reason we have a stable molecule is due to mutual balance between attraction (lowing the energy) between electron-nuclei and repulsion (raise) between nucleus-nucleus and electron-electron. The resulting is there are energetically stable states (so