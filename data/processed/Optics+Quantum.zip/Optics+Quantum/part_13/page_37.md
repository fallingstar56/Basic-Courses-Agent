gives you the second column. The determination of matrix T is completed if you know the T's action on each basis vector. This also make the choice of basis becomes crucial to determine the T. A nice choice of basis would make T's representation simple (the simplest is diagonal), and that's where eigenstates of the operation becomes important.

The above is a general discussion, even though I chose a 2-D to 2-D transform as example for simplicity (and we only use this type for this course), but it can be extended to n-D to m-D transformation (T in this case would be in what form? And how you find its form? Please think this yourself, though I will not put it in test)

Another example: (I shall call this method 2 to find out T)

If the input vector has a,b components along |1>, |2>, let's imagine a physical operation alters it linearly so that the output would have different components a' and b'. (we see many examples of this type already in analytical ray tracing, light reflection and transmission and change of polarization state of light)

 $$ a^{\prime}=o_{11}a+o_{12}b $$ 

 $$ b^{\prime}=o_{21}a+o_{22}b $$ 

Then in matrix form the above process is summarized as:  $ |E'\rangle = \hat{O}|E\rangle $,  $ \hat{O} $ is called the operator which is the physical operation or measurement,  $ |E\rangle $ and  $ |E'\rangle $ are the input and the output state of the system (such as a polarization state passing through a polarizer or waveplate), in the basis of  $ |1\rangle $ and  $ |2\rangle $, the above is: