 $$ \begin{aligned}|\psi_{12}>=&\frac{\sqrt{2}}{2}\hat{O}(|1,\uparrow,L;2,\uparrow,R>-|2,\uparrow,L;1,\uparrow,R>)\\=&\frac{\sqrt{2}}{2}\hat{O}(|1,\uparrow,L;2,\uparrow,R>-|1,\uparrow,R;2,\uparrow,L>)\\\end{aligned} $$ 

Second the eigenstate for detection is:

 $$ \begin{aligned}|\uparrow,\theta;\uparrow,\pi-\theta>=\frac{\sqrt{2}}{2}(|1,\uparrow,\theta;2,\uparrow,\pi-\theta>-|1,\uparrow,\pi-\theta;2,\uparrow,\theta>)\end{aligned} $$ 

Here case (a) and (b) becomes indistinguishable and the eigenstate is given as above. Then you carry out the calculation for the detection, you will find that the probability for D1 detecting an electron would be:  $ |f(\theta) - f(\pi - \theta)|^2 $.

In summary, all the above discussions showed that for identical particles and indistinguishable processes, the probability is squared of summation of amplitudes. For Bosons, it has the form of  $ \left|f(\theta)+f(\pi-\theta)\right|^{2} $, and  $ \left|f(\theta)-f(\pi-\theta)\right|^{2} $ for fermions. Interference comes directly from this form. (Recall the previous discussion of interference of light in classical theory, where math form is exactly same). Here the numbers  $ f(\theta) $ and  $ f(\pi-\theta) $ are generally complex numbers, so the results really depend on their relative phases. In one special case, where

$$f(\theta)=f(\pi-\theta)\quad(\theta=90^{\circ}),\text{then the probability for detecting Bosons}$$

along this direction would be $4f^{2}$; and that for fermions would be 0; while

for non-identical particles, this value is $2f^{2}$.

(2) ‘Antisocial’ electrons and ‘social’bosons

The symmetry and anti-symmetry with respect to the permutation for