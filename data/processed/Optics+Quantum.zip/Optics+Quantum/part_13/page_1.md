 $$ \begin{aligned}&|\psi_{1,2}>_{b o s o n}=\hat{O}\left|\psi_{1,2}\right>_{i}=\frac{\sqrt{2}}{2}\hat{O}(|1,L;2,R>+|2,L;1,R>)\\ &=\frac{\sqrt{2}}{2}\sum...+(f(\theta)\left|1,\theta;2,\pi-\theta>+f(\pi-\theta)\right|1,\pi-\theta;2,\theta>)+\\ &\quad(f(\pi-\theta)\left|1,\theta;2,\pi-\theta\right)+f(\theta)\left|1,\pi-\theta;2,\theta>\right)+...\\ &=\frac{\sqrt{2}}{2}\sum...[f(\theta)+f(\pi-\theta)]\left|\varphi_{\theta}>+[f(\theta)+f(\pi-\theta)]\right|\varphi_{\pi-\theta}>+...\\ \end{aligned} $$ 

The eigenstate of the detection is also the state representing this

two-identical particle case, so that it would also satisfy the permutation

symmetry. The state is one particle goes to direction  $ \theta $ and the other goes

to direction  $ \pi - \theta $. The proper expression for this eigenstate is:

 $$ |\theta;\pi-\theta>_{b o s o n}=\frac{\sqrt{2}}{2}(|1,\theta;2,\pi-\theta>+|1,\pi-\theta;2,\theta>)=\frac{\sqrt{2}}{2}(|\varphi_{\theta}>+|\varphi_{\pi-\theta}>) $$ 

Then the probability of the detection from that of postulate 3 is:

 $$ P(D_{1})_{b o s o n}=|\langle\theta;\pi-\theta|\psi_{12}>|^{2}=|f(\theta)+f(\pi-\theta)|^{2} $$ 

If you did not expand the initial state in terms of  $ |1, \theta; 2, \pi - \theta> $ above, you could also work out the results directly from:

 $$ \begin{aligned}&<\theta;\pi-\theta\left|\psi_{12}\right>=\frac{\sqrt{2}}{2}(<1,\theta;2,\pi-\theta|+<1,\pi-\theta;2,\theta|)\frac{\sqrt{2}}{2}\hat{O}(|1,L;2R>+|1,R;2L>)\\ &=\frac{1}{2}(<1,\theta;2,\pi-\theta\left|\hat{O}\right|1,L;2R>+<1,\theta;2,\pi-\theta\left|\hat{O}\right|1,R;2L>+\\ &\quad<1,\pi-\theta;2,\theta\left|\hat{O}\right|1,L;2R>+<1,\pi-\theta;2,\theta\left|\hat{O}\right|1,R;2L>)\\ &=\frac{1}{2}(f(\theta)+f(\pi-\theta)+f(\pi-\theta)+f(\theta))\\ &=f(\theta)+f(\pi-\theta)\\ \end{aligned} $$ 

Same result as above. Here  $ f(\theta) = <1, \theta; 2, \pi - \theta \mid \hat{O} | 1, L; 2R> $, the probability amplitude for one particle from the left to end into detector