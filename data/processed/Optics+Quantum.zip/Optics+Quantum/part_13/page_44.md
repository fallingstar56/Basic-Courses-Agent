 $$ \hat{L}_{+45(|1^{\prime}>,|2^{\prime}>)}=\begin{pmatrix}{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{pmatrix} $$ 

The question is to find its expression under  $ |1\rangle, |2\rangle $ basis. That is similarity transform in LA.

 $$ \begin{array}{l}\left|1^{\prime}>=<1\left|1^{\prime}>\right|1>+<2\left|1^{\prime}>\right|2>\right.\\\left|2^{\prime}>=<1\left|2^{\prime}>\right|1>+<2\left|2^{\prime}>\right|2>\right.\left.\left|2>=<1^{\prime}\right|2>|1^{\prime}>+<2^{\prime}|2>|2^{\prime}>\right.\end{array} $$ 

Above are the transformation between basis (i.e. express the  $ |1'\rangle $ as combination of  $ |1\rangle $,  $ |2\rangle $ etc.)

For a vector being expressed in either basis:

 $$ \left|r>=x\right|1>+y\left|2>=x^{\prime}\right|1^{\prime}>+y^{\prime}\left|2^{\prime}>\right. $$ 

The relation between x,y (the coordinate of vector in basis 1-2) and x',y' (the coordinate of vector in basis 1'-2') can be found out through basis transform relations:

 $$ \begin{aligned}x\mid1>+y\mid2>=x(<1^{\prime}\mid1>|1^{\prime}>+<2^{\prime}|\mid1>|2^{\prime}>)+y(<1^{\prime}\mid2>|1^{\prime}>+<2^{\prime}|\mid2>|2^{\prime}>)\\=&(x<1^{\prime}|\mid1>+y<1^{\prime}|\mid2>)|\mid1^{\prime}>+(x<2^{\prime}|\mid1>+y<2^{\prime}|\mid2>)|\mid2^{\prime}>\end{aligned} $$ 

the above should be equal to  $ x'|1' > +y'|2'> $, this gives the transform relation between the expression (coordinates) of a vector in different basis:

 $$ \begin{bmatrix}x^{\prime}\\ y^{\prime}\end{bmatrix}=\begin{bmatrix}<1^{\prime}|1>&<1^{\prime}|2>\\ <2^{\prime}|1>&<2^{\prime}|2>\end{bmatrix}\begin{bmatrix}x\\ y\end{bmatrix}=\hat{S}\begin{bmatrix}x\\ y\end{bmatrix}\quad and $$ 

 $$ \begin{bmatrix}x\\ y\end{bmatrix}=\hat{S}^{-1}\begin{bmatrix}x^{\prime}\\ y^{\prime}\end{bmatrix} $$ 

§ is called transform matrix from 1−2→1′−2′basis. (noticed the coordinate x′−y′ transform differently as the basis vector |1′>,|2′>, that is called contra-variance) It is just dot product between basis vectors,