applied everywhere in QM.

For a vector in physics, though it usually visualized as an ‘arrow’ pointing in space, it is essentially the superposition principle, i.e. the physical entity can be decomposed into components (usually we decompose it into orthogonal components), knowing how big each component are (that is knowing the expansion coefficient along each component) and knowing the basis that it is expanded onto is equivalent of knowing the vector itself. (The two knowledge: basis set and corresponding coefficients are complete knowledge for a vector $ ^{98} $) Such expansion coefficients of course can be arranged into numerical arrays (an ordered list of the coefficients and the basis units) so that matrix naturally comes into play to represent them. In the following discussion I still use polarization of light as example so limits it to 2-D, but as usual the discussion is general and can be extended to higher dimensions easily.

## (1) Orthogonal basis:

The Jones representation of polarization of the electrical field depends on the basis chosen (the vector itself is basis independent, but the detailed