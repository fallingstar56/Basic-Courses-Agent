This concludes my discussion on the formation of molecule using the simplest 2-level system. The splitting of energy is a general result due to the existence of off-diagonal Hamiltonian elements. Next we shall investigate this more quantitatively, taken the non-orthogonality of atomic orbital basis into consideration.

Before doing that, I should mention, there are other ways to see the splitting of energy. For example, we can approximate the attraction of two nuclei with electron as 2 delta function potential (of course, this is not exactly Coloumb, so a crude approximation to ease computation) separated by distance R. The repulsion between nuclei is just a constant term shift the energy by a fixed  $ \frac{e^{2}}{4\pi\varepsilon_{0}R} $ for a given R. Then the electron with double-delta potential can be solved exactly in 1-D, as the problem 2.27 in Griffiths. Please do that and you will see the similar results (splitting of energy comparing to the energy of single delta potential; and the forms of wave fucntions with high and low energy).

## (3) Detailed LCAO-MO treatment

In this section, we follow the idea introduced above: Using the atomic orbitals as zeroth order state and linear combine them to form molecular orbitals that diagonalize the Hamiltonian, i.e. the stationary state for molecule.

In the crude approximation, we only use the |φ1>,|φ2> in (14-2) and