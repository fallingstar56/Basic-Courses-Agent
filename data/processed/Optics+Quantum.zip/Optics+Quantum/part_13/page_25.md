 $$ E_{2}=\frac{H_{11}-H_{12}}{1-S}=-\frac{1}{2}+\frac{1}{\rho}+\frac{A-C}{1-S} $$ 

The first term is just the energy of electron in single hydrogen 1s

orbital; the second is repulsion of nuclei. The  $ E_{1} $ has bigger negative

term and thus be the lower energy state (also refer to figure below),

and the orbital in (14-20) is the bonding molecular orbital. This

agrees to our initial more crude treatment in section (2). The integrals

for  $ H_{2}^{+} $actually can be computed rigorously, the result is a function of

R (or  $ \rho $), the result is shown graphically below (there

 $$ \Delta E\equiv E-E(R=\infty)=E+\frac{1}{2}); $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_245_791_652_1051.jpg" alt="Image" width="34%" /></div>


The graph is only qualitative correct, It drops too fast and the anti-bonding energy curve actually does not have a shallow well. This is because we only include two atomic orbitals in basis. More elaborate LCAO-MO method will include more hydrogen-like orbitals (such s and p to make hybrid orbitals which is better because it includes the polarity of electron due to the appearance of the proton in H₂⁺); modification by introducing the adjustable parameters to