heart in linear algebra. You may want to review linear algebra for details.

The best linear algebra textbook (for physicist and engineer) in my personal opinion is the book by Prof. Gilbert Strang at MIT. (He has two similar books on introductory linear algebra, one is: 'Introduction to linear algebra' which I have a pdf file; the other is 'Linear algebra and its applications' which I have a hard copy and you could also buy from Amazon with RMB200+. If you cannot find sources and indeed in need, I would be happy to help)

In 2-D, two orthogonal vectors form a complete basis, i.e. any other vector can be written as a superposition of them. Let  $ |1> $ and  $ |2> $ to represent the unit vector of this base (I will give you a detailed discussion of this in section 3), the orthonormal condition between them is defined by direct product between these two:

 $$ \begin{aligned}\left\langle i\right|j\rangle=\delta_{ij}=&1(if i=j)\\=&0(if i\neq j),\quad i,j=1or2\end{aligned} $$ 

And  $ \sum_{i=1,2}|i\rangle\langle i|=1 $ (1 here is identity matrix) is meaning the completeness of the basis.  $ |i> $ is the Dirac’s notation (bookkeeping) for a vector,  $ <i| $ is the notation for the vector’s conjugate (complex conjugate if in complex space), the  $ <i|j> $ is notation for the scalar (dot) product, i.e.  $ \vec{i}\cdot\vec{j} $ in conventional vector case, and  $ i^T j $ (real space),  $ i^\dagger j $ in linear algebra. More details on this notation are below.