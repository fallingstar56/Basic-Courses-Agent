and columns are just base vector  $ |i> $ expressed in the  $ |i’> $ basis. If the  $ |1> $,  $ |2> $ and  $ |1’> $,  $ |2’> $ are orthogonal basis (it is obvious here for linear polarized light), then we have important conclusion from linear algebra: The inverse of matrix of S is extremely easy to get.

 $ \hat{S}^{-1} = \hat{S}^{T} $ (Inverse=Transpose in real number space) (13)

 $ \hat{S}^{-1} = \hat{S}^{+} $ (Inverse=Transposed and complex conjugate in complex space) (14)

(13) and (14) are called Orthogonal transformation and Unitary Transformation respectively. They represent a very important (and probably most used) transformation in physics since we always choose orthogonal basis whenever possible.

Suppose an operator O change  $ (x_1, y_1) $ to  $ (x_2, y_2) $ in  $ |1->|2> $ basis:

 $ \begin{bmatrix} x_2 \\ y_2 \end{bmatrix} = \hat{O}_{1-2} \begin{bmatrix} x_1 \\ y_1 \end{bmatrix} $, then we switch the basis to  $ |1’->|2’> $:

 $$ \hat{S}^{-1}\begin{bmatrix}x_{2}^{^{\prime}}\\ y_{2}^{^{\prime}}\end{bmatrix}=\hat{O}_{1-2}\hat{S}^{-1}\begin{bmatrix}x_{1}^{^{\prime}}\\ y_{1}^{^{\prime}}\end{bmatrix} $$ 

 $$ \begin{bmatrix}x_{2}^{^{\prime}}\\ y_{2}^{^{\prime}}\end{bmatrix}=\hat{S}\hat{O}_{1-2}\hat{S}^{-1}\begin{bmatrix}x_{1}^{^{\prime}}\\ y_{1}^{^{\prime}}\end{bmatrix} $$ 

Thus the matrix represent the operator in the |1’>-|2’> basis should be:

 $$ \hat{O}_{1^{\prime}-2^{\prime}}=\hat{S}\hat{O}_{1-2}\hat{S}^{-1} $$ 

 $$ \hat{O}_{1-2}=\hat{S}^{-1}\hat{O}_{1^{\prime}-2^{\prime}}\hat{S} $$ 

Above I basically give a derivation on similarity transform between matrices. Now back to our particular problem: