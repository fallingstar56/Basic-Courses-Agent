Of course in other basis (such as that formed by other othonormal base vectors like Right and Left circular polarization), the Jones vector would take different value than h, v.

More general, let  $ \left|Ea\right\rangle $,  $ \left|Eb\right\rangle $ be a pair othonormal base vectors, then

 $$ \left|E\right\rangle=a\left|E_{a}\right\rangle+b\left|E_{b}\right\rangle $$ 

Using orthonormal relation between  $ \left|Ea\right\rangle,\left|Eb\right\rangle $

 $$ a=\left\langle E_{a}\left|E\right.\right\rangle,\quad b=\left\langle E_{b}\left|E\right.\right\rangle $$ 

(<Ea| is the conjugate vector of |Ea> in a complex space, in matrix form it

is the transposed and conjugate of the original |Ea>)

Then we rewrite above equation of expansion of  $ |E> $:

 $$ \left|E\right\rangle=\left\langle E_{a}\left|E\right\rangle\right|E_{a}\rangle+\left\langle E_{b}\left|E\right\rangle\right|E_{b}\rangle $$ 

This is nothing new of course, just restated that the  $ \left|E\right> $ has two components whose amplitude is given by a and b or rewrite a, b in direct product form, the physical meaning of the coefficient a,b is that they tell you how big each components are, or how often (the probability amplitude)you may find  $ \left|E\right> $ in  $ \left|Ea\right> $ or  $ \left|Eb\right> $.

Now let's rearrange the above relation:

 $$ \begin{aligned}\left|E\right>=&\left\langle E_{a}\left|E\right\rangle\right|E_{a}\rangle+\left\langle E_{b}\left|E\right\rangle\right|E_{b}\rangle\\ =&\left|E_{a}\right\rangle\left\langle E_{a}\left|E\right\rangle+\left|E_{b}\right\rangle\left\langle E_{b}\left|E\right\rangle\right.\\=&\left(\sum_{i=a,b}\left|E_{i}\right\rangle\left\langle E_{i}\right|\right)\left|E\right\rangle\end{aligned} $$ 

(nothing new in second step, just rearrange terms,  $ \langle E_a | E \rangle $ is just a number; the third step is because all these product are matrix operations, and in matrix operation though the order is important, it also obeys