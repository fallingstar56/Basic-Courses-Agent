be true?

This puzzle will disappear if we work out this problem from the postulates

of Q.M. directly rather than from Feynman's principle. Here is how it is

solved from this:

First the description of the initial state: Here is what we know. The electron from the left always is in spin up state; the electron from right always with spin down. So the state property in this case would be ↑L; ↓R. Put this in a state description for 1 electron in the ↑L state, the other in ↓R would be:

 $$ |1,\uparrow,L;2,\downarrow,R>91 $$ 

However, we learned that the labeling for identical particles are arbitrary and exchange them has to satisfy the permutation symmetry. For the fermions, the proper state for these two particle system would be:

 $$ \begin{aligned}|\psi_{12}>_{i}=&\frac{\sqrt{2}}{2}(|1,\uparrow,L;2,\downarrow,R>-|2,\uparrow,L;1,\downarrow,R>)\\=&\frac{\sqrt{2}}{2}(|1,\uparrow,L;2,\downarrow,R>-|1,\downarrow,R;2,\uparrow,L>)^{92}\end{aligned} $$ 

After collision the product state will be:

 $$ |\psi_{12}>={\hat{O}}|\psi_{12}>_{i} $$ 