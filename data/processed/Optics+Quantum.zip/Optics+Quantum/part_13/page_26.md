atomic orbitals (this is better because it takes the “shielding” effect of electrons into consideration), etc. To accurately calculate the energy states of more and more complex molecules is still a challenge to theoretical chemists and computational physicists.

### 14.2 Free Electron Gas and Kronig-Penney Model for Solids

The Griffiths book contains a nice discussion on these simplified but quite basic models. Since I have no add-on, please refer to the section 5.3 in his book. They are good examples showing how to apply the simple quantum models we had learned to a more complex system.

Just note that in the free-electron gas model, it is just a 3-D infinite potential well, and the method of counting the number of “modes” (possible LI states) is what we had used in black-body radiation. While in Kronig-Penney model, it may be more realistic to use a periodic finite potential well; the delta potential however is much simpler in computation and also reveals to band structure.