study the form of  $ H_{12} $ or  $ H_{21} $), thus  $ \varphi = \pi $. With these, the wave functions with higher and lower energies are:

 $$ \begin{aligned}&|\psi_{+}>=\frac{\sqrt{2}}{2}(|\phi_{1}>-|\phi_{2}>)\\&|\psi_{-}>=\frac{\sqrt{2}}{2}(|\phi_{1}>+|\phi_{2}>)\\ \end{aligned} $$ 

These are the eigenstates of the molecular Hamiltonian (14-1), and they are called molecular orbital. They are linear combinations of atomic orbitals, so this method is called LCAO-MO (linear combination of atomic orbitals to form molecular orbital). Graphically, I can draw the bonding  $ |\psi_{-}\rangle $ and the anti-bonding  $ |\psi_{+}\rangle $:

<div style="text-align: center;"><img src="imgs/img_in_image_box_222_771_519_959.jpg" alt="Image" width="24%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_641_800_965_1002.jpg" alt="Image" width="27%" /></div>


From the graph, we can interpret the calculation result as: for the electron in bonding orbital, it has considerable probability in space between the nuclei, i.e. there is considerable constructive overlap between the atomic orbitals. The electron will experience attractive force from both nuclei and also it shields the repulsion between the nuclei more effectively in such orbital. Thus it has lower energy and stable. That is the reason behind the qualitative description at the beginning of this section.