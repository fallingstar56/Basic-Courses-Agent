 $$ |\psi_{n-b o s o n s}>=\frac{1}{\sqrt{n!}}\sum_{\substack{p e r m u t a t i o n\\ o f\ n\ t e r m s}}|1,a;2,b;3,c;...> $$ 

 $$ P_{n-boson}=|<1,\theta;2,\theta;3,\theta...|\psi_{n-boson}>|^{2}=n!|a|^{2}|b|^{2}|c|^{2}...(\Delta s)^{n} $$ 

The probability for n non-identical particles to end into one state is:

 $$ P_{n}(non-identical)=|a|^{2}|b|^{2}|c|^{2}\ldots(\Delta s)^{n} $$ 

 $$ So\quad P_{n}(bosons)=n!P_{n}(non-identical) $$ 

Also, let's imaging that we add another boson to the n-bosons, and what

is the probability of this extra boson to end into the final state with n

bosons already there. For the extra boson, if it is alone (along come

initial path  $ \omega $, its probability into final direction is:

 $$ \left|<1,\theta\right|1,path\ \omega>|^{2}\Delta s=\left|\omega\right|^{2}\Delta s $$ 

To have n+1 bosons into same state, from 11-34 the probability is:

 $$ P_{n+1}(bosons)=(n+1)\mid\omega\mid^{2}\Delta s P_{n}(bosons) $$ 

This last relation means that if there are already n bosons in the final

state (given by Pn), then for another boson to end up in the same state is

enhanced by a factor of  $ n+1 $, comparing to the single boson case

 $$ (|\omega|^{2}\Delta s). $$ 

An interesting application of this is discussed in Feynman's 4-4, the absorption and emission of light.