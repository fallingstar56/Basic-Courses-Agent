The question is to find the matrix representation for a certain operation in this basis. We use T to represent the operation, how can you find the matrix form of T given a basis? The idea is simple. Since any vectors in such space would be a linear combination of the basis vectors, so if we know the result of an operation on the basis vectors, we would know its effect on any input vectors! (because the operation is also linear) This is expressed in math as:

 $$ T\begin{bmatrix}x\\ y\end{bmatrix}=xT\mid H>+yT\mid V> $$ 

If we know the operation of  $ |H> $ and  $ |V> $, we know the operation for any input vector. The determination of  $ T|H> $ and  $ T|V> $ would require detailed knowledge of the physical interaction involved, this is where physics kicked in.

As an example of this method (I shall call this method 1 to get the expression of T), let’s assume an operation changes a 2-D vector into another vector also in 2-D, (the T in this case is a 2X2 matrix) and through physical analysis, we also know the T|H> and T|V>, then T is determined:  $ T = \begin{bmatrix} a_{11} & a_{12} \\ a_{21} & a_{22} \end{bmatrix} $, the four elements need to be determined.

But we know the T|H> and T|V>, which is:

 $$ \begin{aligned}&T\mid H>=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}1\\ 0\end{bmatrix}=\begin{bmatrix}a_{11}\\ a_{21}\end{bmatrix}\\ &T\mid V>=\begin{bmatrix}a_{11}&a_{12}\\ a_{21}&a_{22}\end{bmatrix}\begin{bmatrix}0\\ 1\end{bmatrix}=\begin{bmatrix}a_{12}\\ a_{22}\end{bmatrix}\\ \end{aligned} $$ 

So if you know the T|H>, you know the first column of matrix T; and T|V>