the H12 should be real, from Hermitian property, we have H12=H21),

this means from secular equation, we have:

 $$ \left(H_{11}-E\right)^{2}=\left(H_{12}-E S\right)^{2}\rightarrow H_{11}-E=\pm(H_{12}-E S) $$ 

So, the two energies are:

 $$ E_{1}=\frac{H_{11}+H_{12}}{1+S};\quad E_{2}=\frac{H_{11}-H_{12}}{1-S}\qquad(14-19) $$ 

Here we do not know which energy is higher (in last section, I assume  $ H_{12} $ is negative, and thus  $ E_{1} $ is the  $ E_{-} $, I shall prove this later). First we can calculate the eigenstates for these two energies, I only do it for  $ E_{1} $, the other is similar. Put the  $ E_{1} $ back to (14-18), easy to find:

 $$ c_{1}=c_{2} $$ 

So the state will be in form of:

 $$ |\psi_{1}>=c_{1}(|\phi_{1}>+|\phi_{2}>) $$ 

The normalization can fix the c:

 $$ 1=<{\psi_{1}}\mid{\psi_{1}}>=c_{1}^{2}(2+2S)\rightarrow c_{1}=\frac{1}{\sqrt{2(1+S)}} $$ 

 $$ |\psi_{1}>=\frac{1}{\sqrt{2(1+S)}}(|\phi_{1}>+|\phi_{2}>)\qquad(14-20) $$ 

Similarly:

 $$ |\psi_{_{2}}>=\frac{1}{\sqrt{2(1-S)}}(|\phi_{_{1}}>-|\phi_{_{2}}>) $$ 

Now what I need to do is to investigate the H element form to see which energy is higher: