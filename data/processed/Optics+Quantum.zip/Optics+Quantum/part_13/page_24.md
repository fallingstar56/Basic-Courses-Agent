 $$ \begin{aligned}&H_{12}=<\phi_{1}\mid H_{2}\mid\phi_{2}>-<\phi_{1}\mid\frac{1}{\rho_{1}}\mid\phi_{2}>+<\phi_{1}\mid\frac{1}{\rho}\mid\phi_{2}>\\ &<\phi_{1}\mid H_{2}\mid\phi_{2}>=-\frac{1}{2}<\phi_{1}\mid\phi_{2}>=-\frac{1}{2}S\\ &A\equiv<\phi_{1}\mid\frac{1}{\rho_{1}}\mid\phi_{2}>={\int}\phi_{1}^{*}(\rho_{1})\frac{1}{\rho_{1}}\phi_{2}(\rho_{2})d r^{3}\quad(14-25)\\ \end{aligned} $$ 

This term has no classical interpretation as the Coulomb integral. In the atomic basis used here, this tells you that the electron can “exchange” from one orbital close to  $ N_{1} $ to orbital close to  $ N_{2} $. This is the effect of “resonance” in two-level system. The two zero order states are not stationary any more (otherwise the H will be diagonal). That is why this term is called resonance integral (or exchange integral, though the name is also used for a similar integral form in multi-electron atoms). Please also note both the C and A terms are some positive numbers since all the integrands are positive.

 $$ <\phi_{1}|\frac{1}{\rho}|\phi_{2}>=\frac{1}{\rho}S $$ 

Thus:

 $$ H_{12}=-\frac{S}{2}-A+\frac{S}{\rho}\qquad(14-26) $$ 

You see from above, in the last section, I neglect S (treat atomic orbitals orthogonal, S=0), the  $ H_{12}=-A $ a negative number.

Now put (14-24) and (14-26) into energy (14-19):

 $$ E_{1}=\frac{H_{11}+H_{12}}{1+S}=-\frac{1}{2}+\frac{1}{\rho}-\frac{C+A}{1+S} $$ 