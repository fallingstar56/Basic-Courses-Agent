called bonding molecular orbitals), meaning the energy of the molecule is lower than that of the separated atoms composing the molecule. Chemists also like to use very intuitive picture showing the ‘bonds’ between atoms in molecule, claiming the more overlap between the ‘electron cloud’ (the atomic orbitals) the stronger the bond (the lower the energy). The above of course are true; but you have to wonder how these conclusions come from and it is the purpose of this section to use quantum theory to explain these. And for this purpose, I chose the simplest molecular ion  $ H_{2}^{+} $. It is simple because it contains one electron (so I do not need to worry about exchange degeneracy in identical particles) and we know the hydrogen atomic orbitals (states), but it is also sufficient to show us the basics in molecular bonding, i.e. how the energy is lowered in molecule; how the molecular orbital (state) is constructed with atomic orbitals; why the overlap of atomic orbitals forms bond.

## (1) Born-Oppenheimer approximation

The Hamiltonian for the  $ H_{2}^{+} $ is:

 $$ H=-\frac{\hbar^{2}}{2m}\Delta+\frac{1}{4\pi\varepsilon_{0}}(-\frac{e^{2}}{r_{1}}-\frac{e^{2}}{r_{2}}+\frac{e^{2}}{R}) $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_373_1270_721_1409.jpg" alt="Image" width="29%" /></div>


The r's and R are shown in the figure, N₁ and N₂ are the two nuclei.

Both r's and R can change in reality, however when consider the