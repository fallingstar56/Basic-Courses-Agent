Note: the writing of it as column form needs the fact of orthogonal basis.

Then, the eigenvalue and eigenvector solution is a standard problem we had encountered several times:

 $$ \begin{aligned}&H\mid\psi>=E\mid\psi>\\&\begin{bmatrix}H_{11}-E&H_{12}\\H_{21}&H_{22}-E\end{bmatrix}\begin{bmatrix}c_{1}\\c_{2}\end{bmatrix}=0\\ \end{aligned} $$ 

The secular equation is:

 $$ (H_{11}-E)(H_{22}-E)-H_{12}H_{12}^{*}=0 $$ 

The solutions are:

 $$ \begin{aligned}&E_{+}=\frac{1}{2}(H_{11}+H_{22})+\frac{1}{2}\sqrt{(H_{11}-H_{22})^{2}+4\left|H_{12}\right|^{2}}\\ &E_{-}=\frac{1}{2}(H_{11}+H_{22})-\frac{1}{2}\sqrt{(H_{11}-H_{22})^{2}+4\left|H_{12}\right|^{2}}\\ \end{aligned} $$ 

Above is the general solution for 2-levelsystem with orthogonal basis.

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_982_945_1180.jpg" alt="Image" width="60%" /></div>


 $$ \begin{array}{ccc} \underline{{E_{+}}} \\ \hline H_{11} & & \underline{{E_{-}}} \end{array} \quad \begin{array}{ccc} & \underline{{}} \\ & H_{22} \\ \hline \end{array} $$ 

In our special case of  $ H_2^+ $, with  $ |\phi_1>,|\phi_2> $ in forms of (14-2) and (14-3), it is easy to see that  $ H_{11}=H_{22} $ (in the integral of  $ H_{22} $, if we switch label  $ r_1,r_2 $, the result will be exactly  $ H_{11} $; of course this is true because we have two same nuclei; it won’t hold for heteroatomic molecules). The energy splitting for the general case, and special