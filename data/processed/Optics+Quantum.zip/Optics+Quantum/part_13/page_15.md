reason I only consider the above two-zero order states, neglecting other possible states (such 2s,2p...states in hydrogen), is because these two will have the largest contribution to the lowest energy state (ground state) in molecule; the contribution to molecular ground state by the high energy atomic state will be small (neglected here in my 2-level treatment). $ ^{95} $

So if I choose the basis as  $ |\phi_1>, |\phi_2> $, the H will not be diagonal when all the terms included. The following is a standard treatment for 2-level system, an easy one by diagonalizing a  $ 2 \times 2 $ matrix:

The Hamiltonian matrix in the basis of zero order states is:

 $$ \boldsymbol{H}=\begin{bmatrix}H_{11}&H_{12}\\ H_{21}&H_{22}\end{bmatrix} $$ 

 $$ H_{ii}=<\phi_{i}\mid H\mid\phi_{i}> $$ 

 $$ H_{ij}=<\phi_{i}\mid H\mid\phi_{j}>=H_{ji}^{*} $$ 

When the bases are orthogonal, i.e.  $ \langle \phi_i \mid \phi_j \rangle = \delta_{ij} $ (a note here: the  $ |\phi_1\rangle $,  $ |\phi_2\rangle $ localized atomic orbitals are actually not orthogonal, I shall treat them as orthogonal here as in the standard 2-level problem; I shall consider the effect of non-orthogonal in next section where the overlap integral will arise)

Let the eigenstate of H to be:

 $$ \left|\psi\right\rangle=\boldsymbol{c}_{1}\left|\phi_{1}\right\rangle+\boldsymbol{c}_{2}\left|\phi_{2}\right\rangle=\begin{bmatrix}\boldsymbol{c}_{1}\\ \boldsymbol{c}_{2}\end{bmatrix} $$ 