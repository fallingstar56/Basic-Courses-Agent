D1 (so the other particle from right would end in D2 direction) and similar meanings for other <|> terms. This is exactly the meaning of  $ f(\theta) $ defined before.

Similar calculation for the two identical fermions such as electrons, the results is (try it yourself with the antisymmetric states):

 $$ |f(\theta)-f(\pi-\theta)|^{2} $$ 

Feynman's summary that if the events or processes (or other names) are distinguishable, then it is the summation of probability (i.e. no interference); if the events are indistinguishable, it is the square of the summation of amplitudes that gives the probability. This is a useful summary, you may treat it as a principle as stated in his book. But what I have shown here and in example 2 in chapter 11, Feynman's summary is the results of postulates of Q.M., which are the principles underlying his statement.

Let me discuss this example a little further. Considering the collision between two electrons (fermions) but this time with different spin states, say the electron from the left with spin 1/2 (I shall use the conventional symbol  $ \uparrow $ for this), the other electron from the right side with spin -1/2( $ \downarrow $). Then what is the result for detector D1 register the electron? The D1 here does not recognize the spin state, it just record the particle no matter what is its spin state. (this is shown in Feynman's fig.3-9):