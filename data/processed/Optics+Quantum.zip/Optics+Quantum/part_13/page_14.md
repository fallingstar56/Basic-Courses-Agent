electron’s motion, we shall treat the nuclei as fixed in space due to their slow motions. Thus R will be treated as a parameter rather than a variable in the calculation for electron. This ‘decoupling’ between the motion of electron and nuclei is the essential idea of

Born-Oppenheimer approximation. After calculate the electronic energy for a given R, it can be repeated for various R to get energy values E(R).

## (2) Two-Level system treatment

I shall first simplify the problem to a 2-level system, which is easy to solve as we shall see. Though this is a quite approximation, it illustrates many important aspects in forming molecules from atoms. When the R is large, the system is reduced to a hydrogen atom and a proton; the lowest energy for the electron will be in the 1s orbital of hydrogen. If the electron is close to N₁, the r₂ and R terms in H can be neglected at limit of large R, and the eigenstate for energy is just:

 $$ |\phi_{1}>\rightarrow<r|\phi_{1}>=\phi_{100}(r_{1}) $$ 

If the electron is close to N_{2}, the state is:

 $$ |\phi_{2}>\rightarrow<r|\phi_{2}>\Rightarrow\phi_{100}(r_{2}) $$ 

Above are eigenfunctions of the H only in the case of large R.

These two states (the localized atomic orbital) will act as zero order

state as R gets smaller and the extra terms in H cannot be neglected.

Since only two states involved, it is a typical two-level system. The