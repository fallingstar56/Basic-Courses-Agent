(2) The principal peaks have narrower width and higher intensity as N increases.

(3)Between the principal maxima, there are N-1 minima and N-2 subsidiary maxima.

(4) Total diffraction pattern of many slits diffraction is the many-slits interference monitored by the envelope of single slit diffraction.

<div style="text-align: center;"><img src="imgs/img_in_image_box_250_554_1013_911.jpg" alt="Image" width="64%" /></div>


The explanation lies within  $ \tilde{U}(\theta) \propto \frac{\sin \alpha}{\alpha} \frac{\sin N\beta}{\sin \beta} $, whereas  $ \theta $ varies,  $ \frac{\sin N\beta}{\sin \beta} $ changes faster compared to  $ \frac{\sin \alpha}{\alpha} $; So  $ \frac{\sin N\beta}{\sin \beta} $ term is responsible for the principal maxima, minima and sub maxima; the  $ \frac{\sin \alpha}{\alpha} $ acts as modulation to it.

(1) Principal maxima (PM):

 $$ \begin{aligned}&\frac{\sin N\beta}{\sin\beta}\quad is maximum\rightarrow\quad\sin\beta=0\quad or\quad\beta=m\pi;m=0,\pm1,\ldots\\&\frac{\sin N\beta}{\sin\beta}=N,\quad d\sin\theta=m\lambda\quad(\end{aligned} $$ 