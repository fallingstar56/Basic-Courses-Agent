approximation as long as the two wavelengths are close).

That's why we only consider the  $ \tilde{N}(\theta) $ part here for  $ \theta $ varies over a limited range. Certainly the single diffraction element has its effect. You go to higher order of P.M, the intensity drops due to the decrease of  $ \tilde{\mu}(\theta) $. Even within the same order, if  $ \theta $ varies over large range for various  $ \lambda $,  $ \tilde{\mu}(\theta) $ can be quite different.

Though the single slit diffraction also has some dispersion power for the sub-maxima, however not only it suffers great intensity loss (the secondary maxima is only a small percent of Major maximum in single slit diffraction, the major maximum however is not dispersive.), but has less resolution compared with the multi-slits interference term as well. So the high resolution of grating is due to interference among multiple slits. This is in close analogy to the two beam interference like Young's double slits and the multi-beam interference in Fabry-Perot. The double slit Young's Experiment, though different freq. of light appears at different location, but the resolution is poor, very low Finesse, F; F-P on the other hand has much higher F due to multi-beam interference.

We shall see that the grating in many ways, is very much like the F-P interferometer.

(2) Chromatic Dispersion of Grating

 $$ D_{\theta}=\frac{\delta\theta}{\delta\lambda}\quad\mathrm{Angular~Dispersion} $$ 

The larger  $ D_{\theta} $, the more effective to separate different freq. of light