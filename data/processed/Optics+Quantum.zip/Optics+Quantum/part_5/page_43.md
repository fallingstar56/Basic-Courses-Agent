in (7-2), but can be more readily expressed using orthogonal relations:

 $$ \int\limits_{-\frac{\lambda}{2}}^{\frac{\lambda}{2}}e^{i(m-n)kx}dx=\lambda\delta_{mn} $$ 

 $$ C_{n}=\frac{1}{\lambda}\int\limits_{-\frac{\lambda}{2}}^{\frac{\lambda}{2}}f(x)e^{-inkx}dx $$ 

This procedure is really analogous to finding the components of a vector in an orthonormal basis. Here the function  $ f(x) $ is analogous to arbitrary vector; the sinusoidal functions are “base vectors”, and (7-3) is the orthogonal condition for the base vectors. (7-4) is like finding the components by dot product.

If $f(x)$ possess certain symmetry, i.e. if $f(x)$ is even function with respect to $(x)$, $f(x)=f(-x)$, then clearly $B_m=0$ (only cosine left); if $f(x)$ the odd function: $A_m=0$ (only sine left).

The symmetry sometimes simplifies the evaluation.

<div style="text-align: center;">Example 1. For the square wave in Hecht's Fig 7.18</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_208_1212_835_1479.jpg" alt="Image" width="52%" /></div>
