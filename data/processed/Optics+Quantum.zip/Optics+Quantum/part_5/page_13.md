integral will result in Bessel function (one type of so called special functions) and is skipped here (see Hecht's 10.2.5 for detail). The diffraction pattern observed on the screen is in forms of bright and dark circular rings. Its distribution is given by:

 $$ I(\theta)=I_{0}(\frac{2J_{1}(x)}{x})^{2},\mathrm{a n d}x=\frac{kD\sin\theta}{2}=\frac{\pi D\sin\theta}{\lambda} $$ 

 $ J_{1}(x) $ is the first order Bessel function and its value for different x are given in the Hecht book, table 10.1, also the figure 10.22 in Hecht's:

<div style="text-align: center;"><img src="imgs/img_in_image_box_198_720_578_929.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">The I(θ) pattern is plotted as Fig. 10.23 in Hecht's.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_175_1101_449_1493.jpg" alt="Image" width="23%" /></div>
