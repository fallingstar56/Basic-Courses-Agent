 $$ \begin{aligned}&\Delta\beta=\beta_{m}-\beta_{-}=\beta_{+}-\beta_{m}=\frac{\beta_{+}-\beta_{-}}{2}=\frac{1}{N}\pi\\ &\quad\searrow\\ &\Delta(\frac{\pi d\sin\theta}{\lambda})=\frac{\pi d}{\lambda}\Delta(\sin\theta)=\frac{\pi d}{\lambda}\cos\theta\Delta\theta=\frac{1}{N}\pi\\ &\therefore\cos\theta\Delta\theta=\frac{\lambda}{Nd}\qquad(6-35)\\ \end{aligned} $$ 

For $\theta$ is small, $\cos\theta\approx1$, 6-35 reduces to $\Delta\theta=\frac{\lambda}{Nd}$. Thus width $\Delta\theta$ is reversely depends on N as expected.

## (4) Subsidiary Maxima

Between zero points, there has to be a subsidiary maximum, N-1

zeroes between adjacent principle maxima  $ \rightarrow $ N-2 sub. max. The

exact location of the sub. max. can be found by evaluating

 $ \frac{d}{d\theta}(\frac{\sin^{2}N\beta}{\sin^{2}\beta})=0 $, but since their intensity is only a small percentage of

that of the principle maxima, we shall neglect them most of the time.

## (5) Missing orders – Effect of single slit diffraction

For a certain  $ \theta $, if at this diffraction angle:

 $$ \beta=m_{1}\pi\rightarrow\theta\leftarrow\alpha=m_{2}\pi $$ 

 $$ m_{1}=\stackrel{0,\pm1,\ldots}{\uparrow}\qquad m_{2}=\stackrel{\pm1,\ldots}{\uparrow} $$ 

principal max zeroes in single slits diffraction

 $$ \begin{aligned}&\sin\theta=\frac{m_{1}\lambda}{d}=\frac{m_{2}\lambda}{a}\\ &\therefore\frac{m_{1}}{m_{2}}=\frac{d}{a}\\ \end{aligned} $$ 

Say  $ \frac{d}{a}=3 $, then the 3rd principal max. would overlap with 1st order