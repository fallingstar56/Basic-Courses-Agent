are from the odd  $ -\lambda/2 $ plates, with the even plates blocked (case b in the figure; or vice versa as case a in the figure). Then there will be no cancellation between the  $ \lambda/2 $ plates, the light field at P would be strongly enhanced and the intensity could be much larger than the free propagation case. The Fresnel zone plate thus has the power to concentrate energy into certain points just as a focusing lens does. It is indeed used as lens in the wavelength region where no material is suitable for conventional lens.

<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_275_607_516_842.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_568_605_819_832.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;">As the example of 10 odd−λ/2 plates (or even −λ/2 plates), make light field at P about 20A₀, and intensity 400I₀.</div>


The central question is then given $S_0(\text{source})$, $P(\text{field point})$, and their distance to the aperture, what is the radius of the $m^{\text{th}}$ $\lambda/2$ plate? Knowing this we can make the zone plate (A derivation is given in Hecht's book, 10.3.5).

Here gives another derivation as in Zhao’s book: