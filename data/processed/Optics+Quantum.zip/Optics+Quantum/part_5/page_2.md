<div style="text-align: center;"><img src="imgs/img_in_image_box_237_172_810_404.jpg" alt="Image" width="48%" /></div>


For the  $ m^{th}\lambda/2 $ plate,  $ r = b + \frac{m}{2}\lambda $, m=1, 2, ...

What is  $ \rho_{m} $ then?

 $$ \rho_{m}^{2}=R^{2}-(R-x)^{2}=x(2R-x) $$ 

Neglect  $ x^{2} \therefore \rho_{m}^{2} = 2Rx $

 $$ \rho_{m}^{2}+(b+x)^{2}=r^{2}=(b+\frac{m}{2}\lambda)^{2}\approx b^{2}+m b\lambda $$ 

Neglect  $ x^{2} $,  $ \rho_{m}^{2} + (b + x)^{2} = 2Rx + b^{2} + 2bx $

 $$ \Longrightarrow x=\frac{mb\lambda}{2(R+b)} $$ 

 $$ \rho_{m}^{2}=\frac{Rb}{R+b}m\lambda $$ 

 $$ \rho_{_{m}}=\sqrt{m}\rho_{_{1}},\quad\rho_{_{1}}=\sqrt{\frac{Rb\lambda}{R+b}} $$ 

 $ \rho_1 = \sqrt{b\lambda} $ if  $ R \to \infty $ (i.e. plane wave as incoming light)

Another way to write (6-14) is then:

 $$ \frac{1}{R}+\frac{1}{b}=\frac{m\lambda}{\rho_{m}^{2}}=\frac{\lambda}{\rho_{1}^{2}} $$ 

If we define  $ f = \frac{\rho_{1}^{2}}{\lambda} $, (6-16) will be in forms of Gaussian formula for image formation, i.e. P is an image of point source S.