 $ \omega_0 = m\omega $, the  $ V_{out} $ then would be a summation of the truncated series and would distort from the original the output, and  $ V_{out} $ would be something like given in the figure above.

Example 3. Forced oscillator under periodic driving force.

Earlier in the course, we discussed the oscillation of a oscillator driven by a harmonic force, i.e.:

 $ m\ddot{x}+\gamma\dot{x}+kx=F(t) $, where  $ F(t)=F\cos\omega t $ Harmonic driving force.

 $ x \propto A \cos(\omega t + \phi) $

Now, what happens if the $F(t)$ is periodic not necessarily harmonic?

The solution to the problem is simple, since we can expand $F(t)$ into

Fourier Series, which has components of $\cos\omega t$, $\sin\omega t$, $\cos2\omega t$, $\sin2\omega t,....$

For each $\cos m\omega t$, the solution is known, the final solution would be

superposition of them.

From the discussions above, we can see that the usefulness of Fourier Expansion. The system response to harmonic functions, i.e.  $ \sin \kappa x, \cos \kappa x $ or  $ e^{i\kappa x} $ sometimes are much easier to evaluate; then for the linear system knowing its harmonic response, (linear here means: if the system response to input signals  $ S_1 $ is  $ R(S_1) $; then for the multiple inputs, the response is:  $ R(S_1 + S_2 + S_3 + \ldots) = R(S_1) + R(S_2) + R(S_3) + \ldots $) the response to summation of input equals to the summation of response to the individual components. Then using Fourier Expansion, the system's