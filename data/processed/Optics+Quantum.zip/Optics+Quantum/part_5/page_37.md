direction of incident light, $\theta_{b}$ above the base normal $\vec{N}$; The zero$^{th}$ order P.M. is $\theta_{b}$ below the $\vec{N}$, as indicated by dashed arrow, according to 6-44, setting $m=0$ there and find the diffracted angle for the $0^{th}$ P.M.(or $- \theta_{b}$, - means below $\vec{N}$)

Now, the direction  $ +\theta_b $ (above  $ \overline{N} $) would correspond to higher order of P.M. for certain  $ \lambda $, using 6-44, but with  $ \theta $ on the same side of  $ \overline{N} $:  $ d2\sin\theta_b = m\lambda $ (6-45)

Now the major maximum of single element diffraction overlaps with higher order of P.M. for certain wavelength of light. For example, if we need to analyze the light around 600nm, and using  $ 1^{st} $ order (m=1), the grating constant d=800nm, then the blazed angle can be determined with (6-45) for type 1 illumination, it is  $ \arcsin(\frac{600}{1600}) $.

There is another arrangement for incoming light (type 2 illumination):

<div style="text-align: center;"><img src="imgs/img_in_image_box_221_1001_1011_1410.jpg" alt="Image" width="66%" /></div>


<div style="text-align: center;"> $ \theta_{i}=0 $ in this case. The incoming light is along the base normal direction.</div>
