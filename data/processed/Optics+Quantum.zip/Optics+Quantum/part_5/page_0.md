versa.

The Babinet principle offers a way to estimate the diffraction pattern of the complementary screens, i.e. if the diffraction by one screen is known; then diffraction by the complementary screen is also known. A special case is that if the  $ U_{\Sigma_{0}}(P)=0 $ for a space point P in open space case, then  $ U_{\Sigma_{a}}(P)=-U_{\Sigma_{b}}(P) $ and  $ I_{\Sigma_{a}}(P)=I_{\Sigma_{b}}(P) $, the complementary screen generate same intensity and thus same pattern at P.

The Fresnel diffraction by the complementary aperture and obstacle offers an illustration to the Babinet Principle:

<div style="text-align: center;"><img src="imgs/img_in_image_box_274_724_580_1023.jpg" alt="Image" width="25%" /></div>


 $$ U_{\Sigma_{0}}=\overrightarrow{A_{0}} $$ 

 $$ U_{\Sigma_{a}}=\overrightarrow{A_{a}} $$ 

 $$ \overrightarrow{A_{a}}+\overrightarrow{A_{b}}=\overrightarrow{A_{0}} $$ 

 $$ U_{\Sigma_{b}}=\overrightarrow{A_{b}} $$ 

## 6 -3-5 Fresnel Zone Plate

Imagine for a device as depicted in the picture below, a zone plate for a pair of source and field point P, if all the light passing through the plate