diffraction (recall that the single element maximum is always in the direction according to the geometric optics). In this case, it is not different much from the transmitting grating. It is also interesting to see the geometric mirror reflection can be derived from wave-optics multi-elements diffraction, and this is left as exercise for students (using fact of d=a, the spacing between elements equals elements width and missing order).

The blazed grating as depicted in the figure below (also in Fig 2.3, Zhao's book or 10.37, 10.38, Hecht's) will shift the major maximum of the single element from zero $ ^{th} $ order P.M. It works as follow:

<div style="text-align: center;"><img src="imgs/img_in_image_box_231_778_1059_1206.jpg" alt="Image" width="69%" /></div>


The incident light is along  $ \vec{n} $, the facet normal (this is one of the typical arrangement of incoming light, we can call it type 1 illumination)

Where is the major maximum of single element diffraction?

Where is the zero $ ^{th} $ order of P.M?

The major maximum of diffraction by single element is also the