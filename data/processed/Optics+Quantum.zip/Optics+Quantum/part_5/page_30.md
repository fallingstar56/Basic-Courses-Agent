 $$ d\cos\theta_{m}\delta\theta=m\delta\lambda $$ 

From (6-33):

 $$ \delta\theta=\frac{m\delta\lambda}{d\cos\theta_{m}} $$ 

 $$ \therefore D_{\theta}=\frac{m}{d\cos\theta_{m}} $$ 

 $$ D_{l}\equiv\frac{\delta l}{\delta\lambda}=f D_{\theta}=\frac{m f}{d\cos_{\theta}} $$ 

 $ D_{l} $ is called linear dispersion and f is the focal length of the lens in use.

<div style="text-align: center;"><img src="imgs/img_in_image_box_270_603_681_822.jpg" alt="Image" width="34%" /></div>


Dₗ is usually in unit of mm/Å, (i.e. if the wavelength of light differs by 1 Å, how much the mᵗʰ P.M separated in space in millimeter). Sometimes in the specification of a spectrometer, it usually specifies the 1/Dₗ in unit of Å/1mm.

(3) Chromatic Resolution

The P.M is not a single line, it has width.

The half angular width of the P.M's is given by (6-35)

 $$ \Delta\theta=\frac{\lambda}{Nd\cos\theta} $$ 

The  $ \delta\theta $, the angular separation of two different  $ \lambda $ is given by (6-38)

and Rayleigh criteria for resolution are: