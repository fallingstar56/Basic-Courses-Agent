you encounter in physics, the above is true. Actually for piece-wise continuous function, Fourier series (or integral) exist).

The question now is what are the coefficients  $ A_{n}, B_{n} $ of each frequency component  $ \left[\frac{A_{0}}{2}\right. $ is the DC component (direct current)]. They can be evaluated by applying the orthogonal condition of sine, cosine functions, i.e.:

 $$ \begin{aligned}&\int\limits_{0}^{\lambda}\sin akx\cos bkxdx=0,a,b are integers\\&\int\limits_{0}^{\lambda}\sin akx\sin bkxdx=\frac{\lambda}{2}\delta_{ab}\\&\int\limits_{0}^{\lambda}\cos akx\cos bkxdx=\frac{\lambda}{2}\delta_{ab}\\&\begin{cases}\delta_{ab}=0(a\neq b)\\\delta_{ab}=1(a=b)\end{cases}the Kronecker delta.\end{aligned} $$ 

Then the  $ A_{n}, B_{n} $ can be calculated easily:

 $$ \begin{array}{l l}\int\limits_{0}^{\lambda}f(x)\cos m k x d x=\frac{\lambda}{2}A_{m}&\int\limits_{0}^{\lambda}f(x)d x=\frac{\lambda}{2}A_{0}\\ \int\limits_{0}^{\lambda}f(x)\sin m k x d x=\frac{\lambda}{2}B_{m}\end{array} $$ 

 $$ \begin{cases}A_{m}=\displaystyle\frac{2}{\lambda}\int\limits_{0}^{\lambda}f(x)\cos mkxdx\leftarrow\quad(7-4.1)\\B_{m}=\displaystyle\frac{2}{\lambda}\int\limits_{0}^{\lambda}f(x)\sin mkxdx\end{cases} $$ 

When we find the Fourier series expression for a function, we can use Euler formula to re-express the expansion in terms of  $ e^{imkx} $, and here m can take both positive and negative values, the expansion coefficients are