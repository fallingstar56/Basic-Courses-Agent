For a grating with 1200 lines/mm→d~8000Å. Then the maximum measurable in the first order is  $ \lambda_{\text{max}}^{1st} \sim 8000 $ Å, between 8000 Å-4000 Å, each λ only corresponds to a single θ, there is 1↔1 relation between λ,θ. However as λ reaches below 4000 Å, each λ may correspond to multiple values of θ. θ₁ for the first order, θ₂ for the second order …. Reversely, below  $ \lambda_{\text{min}}^{1st} = 4000 $ Å, each θ may correspond various λ, λ₁ for 1st order, λ₂ for 2nd order …. This will cause confusion and make the spectral analysis impossible. This puts a limit to the range of wavelength of the input light. The spectral analysis would be unambiguous if the incoming light’s wavelength falls within the free-spectral-range of the spectrometer.

The free spectral range is the wavelength (or freq.) range that corresponds to the same order of m, so that within this range, the 1↔1 relation between λ,θ holds.

 $$ \begin{aligned}&d\sin\theta_{max}=m\lambda_{m}=(m+1)\lambda_{m+1}\\ &\quad\Delta\lambda_{fsr}=\lambda_{m}-\lambda_{m+1}=\frac{\lambda_{m+1}}{m}=\frac{\lambda_{m}}{m+1}\\ \end{aligned} $$ 

 $ \lambda_m $ is the max. dispersible wavelength for the  $ m^{\text{th}} $ order

In frequency ( $ v_m = \frac{c}{\lambda_m} $), then:

 $$ \Delta v_{fsr}=\frac{V_{m}}{m}\quad(6-42) $$ 

(v is the smallest freq. in the mth order)

Thus, as it seems that the chromatic resolution can be improved by