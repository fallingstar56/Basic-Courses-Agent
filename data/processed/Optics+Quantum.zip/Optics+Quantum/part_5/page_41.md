 $$ f(x)=\sum_{n=-\infty}^{+\infty}C_{n}e^{ikx},\left\{\begin{aligned}C_{n}&=\frac{1}{2}(A_{n}-iB_{n})\\ C_{-n}&=\frac{1}{2}(A_{n}+iB_{n})\end{aligned}\right.,n>0 $$ 

 $$ C_{0}=A_{0}/2 $$ 

The expansion is Fourier expansion (see below for detail).

## 7 -1-1 Fourier Expansion of a Periodic Function

 $ f(x) $ is a periodic function of  $ x $, i.e.  $ f(x + \lambda) = f(x) $,  $ \lambda $ is the period, then  $ k = 2\pi f = \frac{2\pi}{\lambda} $.

For such periodic function, $f(x)$ can be expanded into series of $\sin(nkx), \cos(nkx)$, or $e^{inkx}$, the harmonic components with different frequency, the frequency is a multiple of the fundamental frequency $k$.

i.e.:

 $$ f(x)=\frac{A_{0}}{2}+\sum_{n=1}^{\infty}A_{n}\cos n k x+\sum_{n=1}^{\infty}B_{n}\sin n k x $$ 

n is integer.

 $$ \begin{aligned}\mathbf{or}\quad&f(x)=\sum_{n=-\infty}^{+\infty}C_{n}e^{ikx},\left\{\begin{aligned}C_{n}=&\frac{1}{2}(A_{n}-iB_{n})\\ C_{-n}=&\frac{1}{2}(A_{n}+iB_{n})\end{aligned}\right.,n>0\\&C_{0}=A_{0}/2\end{aligned} $$ 

Of course there is one issue whether such series expansion convergent, i.e. the series closely resemble the original function  $ f(x) $. This question is a complexed mathematical problem and we shall not consider it here. The Strategy is “assume” such series exist and convergent (For the functions