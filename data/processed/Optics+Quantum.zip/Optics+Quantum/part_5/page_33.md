increasing the order of the grating m, as in (6-40), the free spectral range

narrows.

Comparison between Grating and Fabry-Perot

Dispersion

Relation

Chromatic

 $$ \frac{\delta\theta}{\delta\lambda}=\frac{m}{d\cos\theta}\quad 夢 \quad\frac{\delta h}{\delta\lambda}=\frac{m}{2n} $$ 

Resolution

Free Spectral Range  $ \Delta v_{fsr} = \frac{C}{d \sin \theta} \quad \Delta v_{fsr} = \frac{C}{2nh} = \frac{V_{m}}{m} = \frac{V_{m}}{m} $

It is clear that for grating, its finesse is N, the total number of diffraction elements, or equivalently the number of elements taking part in interference. The higher N there is, the more interfering elements and the higher finesse are. This is analogous to the F-P, since in F-P, F is determined by R, higher R, and more reflected beams in interference.