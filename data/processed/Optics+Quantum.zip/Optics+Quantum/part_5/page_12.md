 $$ F(u)\propto\int_{-\infty}^{+\infty}g(v)e^{i u v}d v;g(v)\propto\int_{-\infty}^{+\infty}F(u)e^{i u v}d u $$ 

Δu, Δv is distribution width in F(u) and g(v).

Then  $ \Delta u\Delta v \doteq 2\pi $; here  $ \Delta x \approx a;\Delta(k\theta) = k\Delta\theta; $

 $ \Delta x\Delta(k\theta)\doteq2\pi\rightarrow a\Delta\theta=\lambda $

Relation 6-24 indicates:

a) As a is large, $\Delta\theta \rightarrow 0$, this approaches the geometric limit, $U(\theta)$ only has values along the original propagation direction of the incoming wave from source.

b) As a is small, comparable to  $ \lambda, \Delta\theta \neq 0 $. The smaller a (or the restriction along one direction becomes more serious), the larger  $ \Delta\theta $ (or the more obvious of diffraction), which is the general observation for diffraction.

Sometimes we may use term of Full Angular Width (which is width of maximum from one minimum side to the other), which is obviously  $ 2\Delta\theta=\frac{2\lambda}{a} $. The full linear width:  $ \Delta l=f\cdot2\Delta\theta $, where f is the focal length of the imaging lens.

## 6 -4-4 Fraunhoffer Diffraction by Circular Aperture and Image Resolution

The diffraction screen is a circular aperture with radius a, or diameter D (figure 10.21, Hecht’s), the source and observer satisfy the Fraunhoffer type diffraction. The derivation for this case is a little complicated, the