 $$ f(x)=\left\{\begin{aligned}&+1(0<x<\frac{\lambda}{2})\\ &-1(\frac{\lambda}{2}<x<\lambda)\end{aligned}\right. $$ 

The Fourier expansion of f(x) then is (see the Hecht's book for detail)

 $$ f(x)=\frac{4}{\pi}(\sin kx+\frac{1}{3}\sin3kx+\frac{1}{5}\sin5kx+\ldots)\quad k=\frac{2\pi}{\lambda} $$ 

Figure below shows the Matlab graphical results, a single harmonic  $ \sin kx $ is a poor approximation for the square wave, however, as the number of harmonic increases, the summation looks more like the square wave (the figure is the Matlab result for first 2, 3 and 10 sine components)

<div style="text-align: center;"><img src="imgs/img_in_chart_box_211_785_835_1036.jpg" alt="Image" width="52%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_212_1056_836_1264.jpg" alt="Image" width="52%" /></div>
