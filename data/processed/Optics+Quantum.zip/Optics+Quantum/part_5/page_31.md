 $$ \delta\theta\geq\Delta\theta $$ 

This condition gives the minimum resolvable wavelength difference  $ \delta\lambda_{m} $ and resolving power.

 $$ \begin{aligned}&\frac{m\delta\lambda_{m}}{d\cos\theta}=\frac{\lambda}{Nd\cos\theta}\\ &\delta\lambda_{_{m}}=\frac{1}{mN}\lambda\\ &\frac{\lambda}{\delta\lambda_{_{m}}}=mN\\ \end{aligned} $$ 

m is the order of the P.M., and N is total number of the diffraction elements

(4) Free Spectral Range.

 $$ d\sin\theta=m\lambda $$ 

The maximum dispersible  $ \lambda_{\max}=d $ (1st order,  $ \theta=90^{\circ} $). It is the maximum dispersible wavelength corresponding to the maximum diffraction angle.

As $\theta$ decreases from $90^{\circ}$, it corresponds to smaller $\lambda$, there is a one-to-one correspondence between diffraction angle and wavelength, such one-to-one relationship enable us to tell the wavelength from measuring diffraction angle. But this nice one-to-one relationship ceases to exist when it reaches certain wavelength which I call $\lambda_{\min}$ for this order, where $d = \lambda_{\max}^{1st} = 2\lambda_{\min}^{1st} = 2\lambda_{\max}^{2nd}$, i.e. the first order of $\lambda_{\max}$ overlaps with the second order and $\lambda_{\max}^{2nd} = \lambda_{\min}^{1st}$. This is better be illustrated by an example,