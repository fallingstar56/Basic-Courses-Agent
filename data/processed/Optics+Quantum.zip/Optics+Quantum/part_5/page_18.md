 $$ \mu(\theta)=a_{0}\frac{\sin\alpha}{\alpha}\quad\alpha=\frac{ka\sin\theta}{2}=\frac{\pi a\sin\theta}{\lambda} $$ 

or more generally, is the Fourier transform of  $ \tilde{U}_{0}(x) $

Multi-slits interference term is:

 $$ \begin{aligned}&\widetilde{N}(\theta)=\sum_{j=0}^{N-1}e^{i k L_{j}}\\&L_{j}=L_{0}+j d\sin\theta,j=0,1,...,N-1\\&\widetilde{N}(\theta)=e^{i k L_{0}}[1+e^{i k\Delta L}+...+e^{i k(N-1)\Delta L}]\\&\Delta L=d\sin\theta,k\Delta L=2\frac{d\sin\theta}{\lambda}\pi=2\beta\\&\therefore\widetilde{N}(\theta)=e^{i k L_{0}}\frac{1-e^{i2N\beta}}{1-e^{i2\beta}}\\&=e^{i k L_{0}}\frac{e^{i N\beta}(e^{-i N\beta}-e^{i N\beta})}{e^{i\beta}(e^{-i\beta}-e^{i\beta})}\\&=e^{i k L_{0}}e^{i(N-1)\beta}\frac{\sin N\beta}{\sin\beta}=e^{i\varphi(\theta)}\frac{\sin N\beta}{\sin\beta}\\&\widetilde{U}(\theta)=\widetilde{M}(\theta)\widetilde{N}(\theta)\\&=a_{0}\frac{\sin\alpha}{\alpha}\frac{\sin N\beta}{\sin\beta}e^{i\varphi(\theta)}\\ \end{aligned} $$ 

With  $ \alpha=\frac{a\sin\theta}{\lambda}\pi;\beta=\frac{d\sin\theta}{\lambda}\pi $ given above.

 $$ \begin{aligned}I(\theta)&=I_{0}(\frac{\sin^{2}\alpha}{\alpha^{2}})(\frac{\sin N\beta}{\sin\beta})^{2}\\&\uparrow\end{aligned} $$ 

 $ I_{0}=a_{0}^{2} $, the irradiance by single slit at  $ \theta=0 $