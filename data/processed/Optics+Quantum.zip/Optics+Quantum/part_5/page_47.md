response to other functions will be known too.

For such periodic function $f(x)$, with frequency $\kappa$, the harmonic components in Fourier expansion are discrete, i.e. only $m\kappa$, the integer multiple of $\kappa$, another way to say this is that its Fourier Spectrum is discrete.

Not only periodic function, but also functions  $ f(x) $ that only defines in a limited space, has discrete Fourier Spectrum. To see this, take a look of the example

 $$ f(x)=\left\{\begin{aligned}&x(|x|<\frac{L}{2})\\ &undefined(|x|>\frac{L}{2})\end{aligned}\right. $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_626_677_972_848.jpg" alt="Image" width="29%" /></div>


For such $f(x)$, it can be treated as periodic, with period of $L$ (or $mL$) (certainly many ways to construct such periodic function, but in the $|x|<\frac{L}{2}$ region, $f(x)$ is fixed). Then the Fourier Expansion for periodic function applies here too, with fundamental frequency of $\kappa=\frac{2\pi}{L}$ (or $\frac{2\pi}{mL}$ depending on the construction).

## 7 -1-2 Non-periodic functions – Fourier Transform (Fourier Integral)

We shall see in this section that for the non-periodic functions, the Fourier spectrum would become continuous, i.e. for component  $ e^{ikx} $, its