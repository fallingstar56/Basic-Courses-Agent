<div style="text-align: center;"><img src="imgs/img_in_chart_box_210_151_760_601.jpg" alt="Image" width="46%" /></div>


Example 2. The response of a low pass filter to the square wave input as given in the last example:

<div style="text-align: center;"><img src="imgs/img_in_image_box_210_853_627_971.jpg" alt="Image" width="35%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_508_1019_855_1151.jpg" alt="Image" width="29%" /></div>


 $ V_{in} $ is the input in forms of

then what is  $ V_{out} $, the RC circuit forms a low pass filter that cuts freq. at

 $ \omega_{0}=\sqrt{RC} $



The square wave by Fourier analysis can be treated as superposition of many harmonic components, and the expansion is given in the previous example, basically it contains  $ \omega,3\omega,5\omega\ldots $ components. The low pass filter will truncate higher frequency component, say  $ m\omega $, (i.e.