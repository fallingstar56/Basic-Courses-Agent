start from HFP, relation (6-28):

 $$ \begin{aligned}&\widetilde{U}(\theta)=C\int\widetilde{U}_{0}(x)e^{ikr}dx\\ &=(\int_{-a}^{+a}e^{-ikx\sin\theta}dx)e^{ikL_{0}}+(\int_{-\frac{a}{2}}^{+\frac{a}{2}}e^{-ikx\sin\theta}dx)e^{ikL_{1}}\\ \end{aligned} $$ 

 $$ L_{1}=L+d\sin\theta.\ldots.. $$ 

Or we can treat the slit like 3 slit case:

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_478_333_679.jpg" alt="Image" width="8%" /></div>


and the work will be exactly as example 2.

[Here each single slit has same  $ \tilde{\mu}(\theta) $, and the  $ \tilde{U}(\theta) $ can be expressed into  $ \tilde{\mu}(\theta)\tilde{N}(\theta) $]

## 6 -5-2 Diffraction Grating and Grating Spectrometer

### 6 -5-2-1. Diffraction Grating

Diffraction Grating: A repetitive array of some diffraction elements, which periodically alter the phase, amplitude or both of the emergent wave.

The many slit diffraction studied earlier is a simple example of such grating, in the previous section we worked square type and cosine (sine) type of transmitting gratings, there are many other types of arrangement