 $$ \frac{d}{d\alpha}(\frac{\sin^{2}\alpha}{\alpha^{2}})=0\rightarrow\tan\alpha=\alpha $$ 

Besides  $ \alpha=0 $, the rest  $ \alpha $ corresponds the minor maxima, which can be solved by graphical method,  $ \alpha=1.43\pi,\pm2.46\pi,\ldots $ (refer to figure of the sinc function on pg 250 of this note). At these minor maxima, they are small (only a few percent) compared to the major maxima.

## (4) Half-Angular Width

The Width of the major maximum is defined as width between max, and the first minimum (between  $ \alpha = 0 $ and  $ \alpha = \pi $).

 $$ \Delta\alpha=\frac{\Delta(\pi a\sin\theta)}{\lambda}=\pi\rightarrow a\Delta\sin\theta\approx a\Delta\theta=\lambda $$ 

(6-24) gives results that the relation between the widths of diffraction

slit and angular distribution width of the diffraction maximum.

This is not surprising, and we actually come across to similar results before (i.e.  $ b\Delta\theta \approx \lambda $ in spatial coherence,  $ \Delta T\Delta\upsilon = 1 $ in temporal coherence). As we can see from relation (6-19):

 $$ \tilde{U}(\theta)\propto\int_{-\frac{a}{2}}^{\frac{a}{2}}e^{-i k\sin\theta x}d x\leftarrow\mathrm{Fourier Transform}. $$ 

 $ k\sin\theta $ (or  $ k\theta $) and x are two variables of functions  $ (U(\theta), g(x); g(x)) $ is a square function in single slit case, two-dimensional square function in rectangular aperture case) related by the Fourier Transform, and the relation 6-24 just reflects the usual distribution width relation among the conjugate variables in Fourier Transform.