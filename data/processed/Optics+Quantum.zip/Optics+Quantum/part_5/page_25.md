<div style="text-align: center;"><img src="imgs/img_in_image_box_283_175_553_365.jpg" alt="Image" width="22%" /></div>


 $$ \begin{aligned}&\widetilde{U}(\theta)=\widetilde{\mu}(\theta)\widetilde{N}(\theta)\\&\widetilde{\mu}(\theta)=C\frac{\sin\alpha}{\alpha},\alpha=\frac{\pi a\sin\theta}{\lambda}\\&\widetilde{N}(\theta)=e^{i\varphi(\theta)}[1+e^{i k2d\sin\theta}+e^{i k3d\sin\theta}]\\&=e^{i\varphi(\theta)}[1+e^{i4\beta}+e^{i6\beta}],\beta=\frac{\pi d\sin\theta}{\lambda}=\frac{kd\sin\theta}{2}\\&I(\theta)=\widetilde{\mu}(\theta)\widetilde{\mu}^{*}(\theta)\widetilde{N}(\theta)\widetilde{N}^{*}(\theta)\\&\quad\underbrace{}_{I_{0}(\frac{\sin\alpha}{\alpha})^{2}}[1+e^{i4\beta}+e^{i6\beta}][1+e^{-i4\beta}+e^{-i6\beta}]\end{aligned} $$ 

or you may use phasor method:

<div style="text-align: center;"><img src="imgs/img_in_image_box_243_848_458_1040.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;">Example 3: problem 6, Zhao's book, pg. 17.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_249_1182_371_1374.jpg" alt="Image" width="10%" /></div>


Here since the single slit diffraction  $ \tilde{\mu}(\theta) $ is different for the two silts, then generally,  $ \tilde{U}(\theta) $ will not be in form of  $ \tilde{\mu}(\theta)\tilde{N}(\theta) $. You can