fall into this category, such as well-ordered crystals, give rise to X-ray diffraction.

The derivation in the last section provides the basic of discussion of grating. More generally for the Fraunhoffer type diffraction by multiple equivalent elements, we have from (6-32):

 $$ \tilde{U}(\theta)=\tilde{\mu}(\theta)\tilde{N}(\theta) $$ 

 $ \tilde{U}(\theta) $ is the diffraction field.

 $ \tilde{\mu}(\theta) $ is the diffraction due to single element.

 $ \tilde{N}(\theta) $ is the interference between elements.

### 6 -5-2-2. Grating Spectrometer (Transmitting Case)

Spectrometer is a device that separates the frequency component of light; it is essentially a dispersive device like a prism. The light with different frequency will appear at different place (or time) so that its spectrum can be analyzed (a spectrum is a recording of intensity of frequency components).

## (1) Grating equation:

From the previous discussion, the  $ m^{th} $ principal maximum (P.M) due to the  $ \tilde{N}(\theta) $ the multiple-interference term is:

 $$ d\sin\theta=m\lambda,m=0,\pm1,\ldots $$ 

(6-33) is called grating equation and is most important in application of grating. It gives us the dispersive relation between frequency (here