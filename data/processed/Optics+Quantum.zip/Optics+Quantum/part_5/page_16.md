the resolution power of the image formation, we can either decrease the wavelength (such as the electron microscope in biology) or use large diameter lens (large D telescope in astronomy)

## 6 -5 Diffraction by Many Slits (Fraunhoffer Type)

## 6 -5-1 Fraunhoffer-Diffraction by Many Slits

<div style="text-align: center;"><img src="imgs/img_in_image_box_244_655_897_1061.jpg" alt="Image" width="54%" /></div>


Multiple Slits, slit's width: a; Spacing between slits: d. The slits are arranged periodically.

Question: What is the amplitude and intensity pattern for a point on the observing screen  $ P_{\theta} $?

 $ U(P) $ have contributions from :

(1) Diffraction of single slit.

All the slits though shifted in space, create same single slit