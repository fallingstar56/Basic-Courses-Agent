<div style="text-align: center;"><img src="imgs/img_in_chart_box_237_140_855_1003.jpg" alt="Image" width="51%" /></div>


<div style="text-align: center;">(Figure 10.17 in Hecht's. Noticed the notation difference, and I apologize for using different set from his;  $ \alpha,\beta $ in the figure is reversed from definition in this note, also he used a for spacing between slit and b for single slit width.)</div>


With relations 6-32, and definition of  $ \alpha, \beta $, it is easy to derive all the properties of many slits diffraction.

The observations of multi-slits diffraction:

<div style="text-align: center;">(1) Several principal maxima (principal peaks).</div>
