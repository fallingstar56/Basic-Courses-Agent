wavelength) and space distribution. In case of  $ m \neq 0 $, i.e. higher order diffraction maxima occur at different angle  $ \theta $ with different  $ \lambda $. That is the higher order principle maxima have dispersive power. The zero $ ^{th} $ order, however is not dispersive, all wavelengths are at the same angle. So the higher order principal maxima are useful in separation of light with different frequency, while the zero $ ^{th} $ is useless on this.

In order to have the higher order  $ m \neq 0 $, from 6-33, put a limit on the applicable wavelength for a certain grating with grating period d:

 $$ \lambda_{max}\leq\frac{d}{m} $$ 

 $ \lambda_{\text{max}} $ is the maximum dispersible wavelength for the m $ ^{th} $ order of P.M.

Here we only consider the dispersion arise from many-slits interference, and treat the single element diffraction factor almost as constant, since it varies much slower with respect to  $ \theta $ comparing with the P.M.

The diffraction pattern for different wavelength at different order m is

like in the figure below:

<div style="text-align: center;"><img src="imgs/img_in_chart_box_249_1183_552_1373.jpg" alt="Image" width="25%" /></div>


The effect of single diffraction elements on the P.M. of various  $ \lambda $ components within same order is almost same (of course this is an