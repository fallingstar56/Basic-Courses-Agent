diffraction pattern. But the intensity at  $ P_{\theta} $ is not the summation of the irradiance of the slits. Because →

(2) Interference among slits.

Let's start from the HFP and Kirchhoff equation to derive the expression for the field at point P:

 $$ \begin{aligned}&\tilde{U}(x^{\prime})=\tilde{U}(\theta)=C\int_{\Sigma}\tilde{U}_{0}(x)e^{i k r}d x\\ &=\sum_{j=0}^{n-1}C\int_{\Sigma_{j}}\tilde{U}_{0}(x_{j})e^{i k r_{j}}d x_{j}\\ \end{aligned} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_270_474_896_820.jpg" alt="Image" width="52%" /></div>


 $$ C=-\frac{i}{\lambda f}\overline{f(0,\theta_{0})} $$ 

 $ r_{j}=L_{j}-x_{j}\sin\theta,L_{j} $ is the OPL to point P measured from center of each slit.

 $$ \tilde{U}(\theta)=C\int_{-\frac{a}{2}}^{+\frac{a}{2}}\tilde{U}_{0}(x)e^{-i k x\sin\theta}d x(\sum_{j=0}^{N-1}e^{i k L_{j}}) $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_269_971_943_1259.jpg" alt="Image" width="56%" /></div>


 $ \mu(\theta) $, Single Slit Diffraction Multi-slits

(same for all slit in this case) Interference Term

 $ \mu(\theta) $ is the diffraction for a single slit with width a, i.e.  $ \tilde{U}_0(x) $ is:

<div style="text-align: center;"><img src="imgs/img_in_image_box_258_1355_641_1534.jpg" alt="Image" width="32%" /></div>
