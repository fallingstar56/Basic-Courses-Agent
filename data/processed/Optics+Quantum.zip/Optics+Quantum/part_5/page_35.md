the dispersive part of higher order P.M suffers intensity loss due to the smaller  $ \mu(\theta) $, thus most energy is wasted. This can be rectified in blazed grating and most practical spectrometer uses this type of grating.

## (1) General treatment of reflecting grating

Let's first consider a plain mirror type reflection, but treat it using diffraction method.

 $ \theta_{m},\theta_{i} $ are diffracted and incident angles and they are measured from the  $ \overline{N} $, the direction of base normal.

<div style="text-align: center;"><img src="imgs/img_in_image_box_175_660_1049_1386.jpg" alt="Image" width="73%" /></div>


 $$ \begin{aligned}&\Delta L=\overline{A}\overline{B}-\overline{C}\overline{D}\\ &=d(\sin\theta_{m}\mp\sin\theta_{i})\\ \end{aligned} $$ 

The zero $ ^{th} $ P.M. is at  $ \theta_{m} = \theta_{i} $, for the flat reflecting surface as drawn above, this is also the direction of the major maximum of the single element