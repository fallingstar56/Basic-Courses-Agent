Such expansion can be useful in physics. As we already mentioned before, that for a potential  $ V(x) $, close to the equilibrium point, it can be approximated by  $ Ax^{2} $, a harmonic potential.

<div style="text-align: center;"><img src="imgs/img_in_image_box_201_359_358_470.jpg" alt="Image" width="13%" /></div>


much like harmonic potential.

Another very useful expansion is to express $f(\mu)$ in terms of sinusoidal functions $\sin\kappa\mu$, $\cos\kappa\mu$ or $e^{i\kappa\mu}$, here $\mu$ is some general variable, $\kappa$ is the general angular frequency, where $\kappa=2\pi f$, $f$ is the generalized frequency.

If  $ \mu \to t $, then  $ \kappa \to \omega, e^{i\kappa\mu} \to e^{i\omega t} $ harmonic oscillation.

If  $ \mu \rightarrow x $, the spatial dependent of wave,  $ \kappa \rightarrow k = \frac{2\pi}{\lambda} $,  $ e^{i\kappa\mu} \rightarrow e^{i\kappa x} $

wave vector

If $\mu \to x$, the general coordinate of a spatial distribution, such as a pattern on the screen, then $\kappa$ is the spatial angular frequency of the distribution, $\kappa = 2\pi f = 2\pi f = 2\pi \frac{1}{d}$, where $f$ the spatial freq., $d$ is the

<div style="text-align: center;"><img src="imgs/img_in_image_box_368_1211_643_1301.jpg" alt="Image" width="23%" /></div>


spatial period,

Such expansion of  $ f(x) $ generally takes the form of: