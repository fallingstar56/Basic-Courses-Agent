m=0 corresponds to the major maximum, the zeroth order.

or  $ a\sin\theta = m\lambda, m = \pm1, \pm2, \ldots $

This can be understood by the destructive interference between pairs of light beam with OPL different by  $ \Delta L = \frac{\lambda}{2} $.  $ a \sin \theta = m \lambda $ means that the slit contains even number of such  $ \lambda/2 $ zones and the resulting diffraction would be minimum due to cancellation (Recall the  $ \frac{\lambda}{2} $ plate in Fresnel Diffraction).

<div style="text-align: center;"><img src="imgs/img_in_image_box_308_657_569_899.jpg" alt="Image" width="21%" /></div>


i.e.

zone 1 cancels zone2.

(3) Minor Maxima

<div style="text-align: center;"><img src="imgs/img_in_image_box_222_1069_656_1407.jpg" alt="Image" width="36%" /></div>


Between adjacent minima, there are minor maxima. Their location can be determined by condition: