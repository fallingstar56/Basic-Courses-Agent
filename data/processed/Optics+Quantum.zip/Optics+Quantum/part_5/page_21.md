In (6-33)  $ m \neq 0 $ non-zero integers, d has to be  $ >\lambda $. If  $ d < \lambda $, only  $ m = 0, \theta = 0 $ will satisfy (6-33), only the zeros order maximum in  $ d < \lambda $ case, the  $ 0^{\text{th}} $ order as we shall see has little use in application.

The (6-33) determines the position of the principal maxima, and its intensity  $ \propto N^{2}(I_{0}\frac{\sin^{2}\alpha}{\alpha^{2}}) $, the intensity is  $ N^{2} $ times that of the single slit diffraction. (Instead of N times if no interference, the energy is more concentrate in the phase space. We actually already encountered similar situation in Fabry-Perot interferometer cases, which is a result of multi-beam interference) Also as in Fabry-Perot cases, as more beams take part in interference (large R in F-P case, large N in multi-slits here), the width of energy distribution narrows. But first we study the position of minimum.

(2) Minimum between the maxima.

 $$ \begin{aligned}&\sin N\beta=0,\sin\beta\neq0\\&\therefore N\beta=n\pi,\quad n=\pm1,\ldots,\pm N-1\quad(6-34)\\&\beta=\frac{n}{N}\pi\quad&N-1&zeroes between adjacent maxima.\end{aligned} $$ 

For the  $ m^{th} $ principle maxima, the closest zeros at:  $ \beta_{\pm} = (m \pm \frac{1}{N})\pi $

## (3) Width of the Principal Maxima

The width is defined as the difference between the maximum to its closest zero.