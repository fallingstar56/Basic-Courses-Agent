The zero $ ^{th} $ order P.M. is also along  $ \theta = 0 $

The major max. of single element diffraction:  $ 2\theta_{b} $

The  $ m^{th} $ P.M. in this direction is:

 $$ d(\sin2\theta_{b}-\sin\theta_{i})=d\sin2\theta_{b}=m\lambda $$ 

In the example above but for type 2 illumination, the blazed angle will be  $ \frac{1}{2}\arcsin(\frac{600}{800}) $.

Starting with (6-44), we can derive the chromatic dispersion, resolution, ... for the reflection type grating, they will be the same as those in transmitting case.

### 6 -5-2-4. Blazed Grating Spectrometer

<div style="text-align: center;"><img src="imgs/img_in_image_box_193_899_832_1228.jpg" alt="Image" width="53%" /></div>


<div style="text-align: center;">Figure 10.32 The Littrow autocollimation mounting.</div>


The working principles have been discussed in the sections above. Refer to the book for description and use the homework as practice.