The Finesse of grating is N can also be proven by the definition of it, the ratio between separation of principle maxima and its half angular width.

 $ \Delta\beta = \pi $ for the adjacent P.M.

 $$ \delta\beta=\frac{\pi}{N}\ (\mathrm{see~6-34})\ \mathrm{half~angular~width~in}\ \beta $$ 

 $$ \mathrm{The~F_{grating}=\frac{\Delta\beta}{\delta\beta}=N~} $$ 

The F-P interferometer usually has higher F, or better chromatic resolution, due to large m and F, but it has much smaller free spectral range (2nh~cm,  $ \Delta\nu_{fsr} \sim 10^{10} $ Hz for F-P;  $ d\sin\theta \sim \mu m $,  $ \Delta\nu_{fsr} \sim 10^{14} $ Hz for grating)

So the grating spectrometer can scan larger spectral range and is very useful in spectroscopy.

### 6 -5-2-3. Blazed Grating

(Fig 10.36, 10.37, 10.38, Hecht's)

Purpose: Overlap the major maximum of the single element diffraction (maximum of the  $ \frac{\sin\alpha}{\alpha} $ term) with the higher order of the principal maxima.

In the conventional transmitting type grating, the maximum of single element diffraction overlaps with the non-dispersive zero $ ^{th} $ order of P.M;