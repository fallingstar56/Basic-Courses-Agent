the two images are resolvable (see figure 10.24, 10.25 in Hecht's and the figure below).

<div style="text-align: center;"><img src="imgs/img_in_image_box_236_302_986_1217.jpg" alt="Image" width="63%" /></div>


<div style="text-align: center;">Fig 10.25 in Hecht's</div>


<div style="text-align: center;">So the minimum angular separation between the image points is:</div>


 $$ \Delta\varphi_{\min}=\Delta\theta=1.22\frac{\lambda}{D} $$ 

 $ \lambda $ is the wavelength of light and D is the diameter of the lens. To improve