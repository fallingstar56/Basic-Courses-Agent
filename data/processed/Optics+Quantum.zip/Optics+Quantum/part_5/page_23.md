zeroes of single diffraction → missing 3rd order principal max.

Examples1: cosine slit, (Zhao's book pg. 14, Vol. II)

Now take a look the case that  $ \tilde{U}(x) $ for single slit is a cosine type function instead of a square function.

 $$ \tilde{U}(x_{i})=\left\{\begin{aligned}&1+\cos\frac{2\pi}{d}x_{i},-\frac{d}{2}<x_{i}<\frac{d}{2}\\ &0\end{aligned}\right. $$ 

 $$ x_{i}=x-x_{i0} $$ 

 $ x_{i0} $ is the center of i^{th} slit.

Here the multi-slits are N slits with light transmission given above, and its graph is shown below; the slit width is d and the spacing between slits is also d.

<div style="text-align: center;"><img src="imgs/img_in_image_box_229_888_1053_1066.jpg" alt="Image" width="69%" /></div>


using 6-29:

 $$ \tilde{U}(\theta)=\tilde{\mu}(\theta)\widetilde{N}(\theta),\widetilde{N}(\theta)=\frac{\sin N\beta}{\sin\beta};\beta=\frac{\pi d\sin\theta}{\lambda} $$ 

 $ \tilde{\mu}(\theta) $ the single slit diffraction is: