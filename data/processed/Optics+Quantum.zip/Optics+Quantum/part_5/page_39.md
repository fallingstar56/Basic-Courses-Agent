## Chapter 7 Fourier Optics

(Zhao's, Chap 5, §1-§5; Hecht's 7.3, 7.4.1; Chap 11: 11.2, 11.3)

Here I only intend to introduce the Fourier optics quite briefly. The detailed derivation and discussion are both out of the scope this course, and should be addressed in a complete course, and out of the range of my expertise.

First I shall make a brief discussion on Fourier Transform, simply give out the important results without rigorous math derivation. Then I shall continue to its application in optics, especially focus on the relation with Fraunhoffer diffraction.

It is a nice and important example and is sufficient enough to illustrate many important concepts.

## 7 -1 Fourier Expansion (Fourier Series) and Fourier integrals

(Hecht 7.3, 7.4.1, 11.2; Zhao's §5, chap 5, Vol II)

For an arbitrary function, say $f(x)$, $x$ is some general variable, it is sometimes very useful expanding it into series, i.e. into components of simpler functions. One famous one is Taylor expansion, $f(x)$ is expanded into polynomial form, with the coefficient of component $x^{m}$ corresponds to $\frac{d^{m}f}{dx^{m}}$.