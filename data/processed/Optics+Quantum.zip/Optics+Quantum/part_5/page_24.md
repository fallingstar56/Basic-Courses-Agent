 $$ \begin{aligned}&\widetilde{\mu}(\theta)=C\int_{\frac{d}{2}}^{\frac{d}{2}}(1+\cos\frac{2\pi}{d}x)e^{-ik\sin\theta x}dx\\ &=C\int_{\frac{d}{2}}^{\frac{d}{2}}1+\frac{1}{2}e^{i\frac{2\pi}{d}x}+\frac{1}{2}e^{-i\frac{2\pi}{d}x})e^{-ik\sin\theta x}dx\\ &=C[\frac{\sin\beta}{\beta}+\frac{1}{2}\frac{\sin(\beta-\pi)}{\beta-\pi}+\frac{1}{2}\frac{\sin(\beta+\pi)}{\beta+\pi}]\\ \end{aligned} $$ 

 $$ \begin{aligned}\tilde{U}(\theta)\propto&\frac{\sin\beta}{\beta}\frac{\sin N\beta}{\sin\beta}+\frac{1}{2}\frac{\sin(\beta-\pi)}{\beta-\pi}\frac{\sin N\beta}{\sin\beta}+\frac{1}{2}\frac{\sin(\beta+\pi)}{\beta+\pi}\frac{\sin N\beta}{\sin\beta}\\&\downarrow\quad\quad\quad\quad\downarrow\quad\quad\quad\quad\downarrow\\&only nonzero\quad&only nonzero\quad&only nonzero\\&around\quad\beta=0\quad&around\quad\beta=\pi\quad&around\quad\beta=-\pi\end{aligned} $$ 

So only  $ 0,\pm1 $ order of the principal maxima from  $ \frac{\sin N\beta}{\sin\beta} $ survives,

the rest are missing orders due to single slit modulation.

Also from missing order relation:  $ \frac{m_{1}}{m_{2}}=\frac{d}{a} $, if  $ d=a $, then only  $ m_{1}=0, m_{2}=0 $ survives. The resulting diffraction pattern would be that given in Zhao's, Vol. II, Fig 1-9.

In this example, you may also start with relation (6-28)

 $$ \tilde{U}(\theta)=C\int_{-\frac{Nd}{2}}^{\frac{Nd}{2}}(1+\cos\frac{2\pi}{d}x)e^{-ik\sin\theta x}dx $$ 

which would generate same results. This can also be looked at from view point of Fourier Transform later.

Example 2. problem 5, pg. 17, Zhao's Vol. II.