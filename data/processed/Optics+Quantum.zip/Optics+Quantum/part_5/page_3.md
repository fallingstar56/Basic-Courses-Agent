 $$ f=\frac{\rho_{1}^{2}}{\lambda}\quad(6-17) $$ 

This f is the primary focus of zone plate. It is heavily depending on  $ \lambda $, so it has chromatic aberration. Fresnel zone plate also has many secondary foci, at position of f/3, f/5, f/7 ... .(please reasoning this by yourself) as well as virtual foci (see Zhao's pg. 206).

(Such phenomena could also be understood from Fourier Transform optic, which will be discussed later.)

## 6 -4 Fraunhoffer Diffraction by Single Slit

As we stated earlier in the section of introduction that the Fraunhoffer diffraction is a special case in which both the source, and the field point P satisfy far field and paraxial condition. With respect to the diffraction screen  $ \Sigma $. i.e.:

<div style="text-align: center;"><img src="imgs/img_in_image_box_239_1078_720_1237.jpg" alt="Image" width="40%" /></div>


S, P are far away from  $ \Sigma $,  $ r, R \gg \frac{a^{2}}{\lambda} $, under this condition, the incoming wave towards the  $ \Sigma $, and outgoing wave towards P can both be treated as plane wave, which result in much simplified calculation.