## 6 -4-1 Single Slit

The 1-dimension slit is an over simplification, and real object would be at least approximately 2-dimensional. So the 1-d slit treated here is a special case for the more general 2-d apertures. It offers a good starting point to treat Fraunhoffer type diffraction.

<div style="text-align: center;"><img src="imgs/img_in_image_box_233_517_1038_865.jpg" alt="Image" width="67%" /></div>


<div style="text-align: center;">a is the width of 1-d. slit (In reality as we shall see that can be a long slit with large extension along y direction, and with width a along x direction). The slit puts restriction along x direction and we shall observe diffraction (deviation from rectilinear propagation of light) along this direction too. So we need to find the pattern (field distribution) on the observing screen $U(P)$ or $\tilde{U}(\theta),\tilde{U}(x)$.</div>


From HFP (Kirchhoff equation):

 $$ \tilde{U}(P)=\tilde{U}(\theta)=-\frac{i}{\lambda f_{2}}\iint_{\Sigma}\tilde{U}_{0}e^{i k r}d x\quad(6-1) $$ 

↑Why is this $f_{2}$ here? It is clearly resulting from drop of amplitude of the secondary wavelets on the