remember for the tensor product of space is very intuitive (I use 2-D X, Y space to illustrate, and ‘digitize’ X into N₁ points (N₁ dimension) and Y into N₂ points) and I shall summarize below (what you had known for a long time in language of functions, but now expressed in terms of vector in linear algebra):

(1) The dimension of space is  $ N_1N_2 $, base vector  $ |x_i, y_j \geq \mid x_i \rangle \otimes \mid y_j \rangle $, sometimes we even neglect the  $ \otimes $ symbol.

(2) State vector which is a tensor product, its wave function will be just

product of the two wave functions in each space:

Let:  $ <x_i \mid \Phi(x) \geq \phi(x_i), <y_j \mid \Theta(y) \geq \theta(y_j) $, then the tensor product state vector:  $ |\Psi \geq |\Phi \otimes |\Theta\rangle $, or write it out explicitly with base vectors:  $ |\Psi \geq \sum_{i,j} \phi(x_i) \theta(y_j) |x_i \rangle |y_i\rangle $, so the wave

function is:

 $$ <x_{i},y_{j}\mid\Psi>=\psi(x_{i},y_{j})=\phi(x_{i})\theta(y_{j}) $$ 

Please note the above is true if the state vector in the complete space (X, Y here) is a tensor product. $ ^{81} $

(3) The operator act in one space would only affect the corresponding component of the state vector:

 $$ \hat{R}(x)\left|\Psi\right\rangle=\left(\hat{R}(x)\left|\Phi\right\rangle\right\rangle\otimes\left|\Theta\right\rangle\qquad\left(S u c h~a s\quad\frac{\partial}{\partial x}\right) $$ 