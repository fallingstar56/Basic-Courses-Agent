determinants will be orthogonal. Here the difference means there are different orthogonal single-particle wave functions in the matrix, say one determinant contains  $ \phi_{1}\alpha $, in the other  $ \phi_{1}\alpha $ is replaced by  $ \phi_{1}\beta $,  $ \alpha,\beta $ are orthogonal; then the two determinants will be orthogonal too. (Please prove it yourself)

## (4) Pauli Exclusion Principle:

No two fermions can occupy the same state.

This famous result is a direct consequence of the anti-symmetric requirement on the total state or wave function. If the two fermions occupy the same state, for instance, they both have  $ \psi_{100}\alpha $ i.e. both electrons are in 1s orbital with spin up. Then there will be two identical columns in the determinant, and the total wave function will be zero.

## 13 -3 Examples

Here I shall give some relatively simple examples to illustrate what we had learned above on identical particles. First, I shall talk about wave functions for a multi-electron atom (use Helium mostly as example). There are still quite a lot knowledges missing here, such as how we calculate the wave functions (the so called Hartree-Fock method), how we determine the good quantum numbers (the addition of angular