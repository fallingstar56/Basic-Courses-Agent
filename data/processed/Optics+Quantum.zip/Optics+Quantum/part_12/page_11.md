 $$ \rho\frac{d^{2}v}{d\rho^{2}}+2(l+1-\rho)\frac{d v}{d\rho}+[\rho_{0}-2(l+1)]v=0 $$ 

Put in the polynomial form, group the coefficients for the same power of  $ \rho $ together and from linear independence of  $ \rho^{0}, \rho^{1}, \rho^{2} $…, the coefficients has to be zero, we finally reach the recursion formula:

 $$ c_{_{j+1}}=c_{_{j}}[\frac{2(j+l+1)-\rho_{_{0}}}{(j+1)(j+2l+2)}] $$ 

 $$ (12-101) $$ 

So knowing one term, say  $ c_{0} $ (which can be determined by normalization), the rest will be known from the recursion provided with the energy (that determines the  $ \rho_{0} $).

## (c) Polynomial truncation and quantization of energy

We can show if the polynomial has unlimited terms and obeys the recursion formula (12-101), the asymptotic (at large r or  $ \rho $ where high power terms dominate) behavior of such polynomial would approach exponential form of:

 $$ v(\rho)\stackrel{\rho\to\infty}{\rightarrow}e^{2\rho}\qquad(Prove it yourself or read the book) $$ 

This will make the complete solution (12-99) approaches  $ e^{\rho} $ at large  $ \rho $, and the solution is physically unacceptable.

To wiggle out this dilemma, the polynomial has to be truncated at certain order with the highest order nonzero term to be  $ c_{j_0}\rho^{j_0} $, the  $ j_0 $ is the index for this highest nonzero term.  $ c_{j > j_0} = 0 $ when:

 $$ 2(j_{0}+l+1)=\rho_{0} $$ 

Let's define another quantum number n: