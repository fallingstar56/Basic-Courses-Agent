in the table (taken from Griffiths):

Legendre Polynomial:  $ P_{L} $

<div style="text-align: center;"><img src="imgs/img_in_image_box_263_323_617_593.jpg" alt="Image" width="29%" /></div>


 $$ \mathbf{P}_{2}=\frac{1}{2}(3x^{2}-1) $$ 

 $$ \mathrm{P}_{3}=\frac{1}{2}(5x^{3}-3x) $$ 

 $$ \mathrm{P}_{4}=\frac{1}{8}\left(35x^{4}-30x^{2}+3\right) $$ 

 $$ \mathrm{P}_{5}=\frac{1}{8}(63x^{5}-70x^{3}+15x) $$ 

<div style="text-align: center;">a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_640_285_1098_644.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">b)</div>


The associated Legendre function  $ P_{l}^{m}(\cos\theta) $:


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{0}^{0}=1  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{2}^{0}=\frac{1}{2}(3\cos^{2}\theta-1)  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{1}^{1}=\sin\theta  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{3}^{3}=15\sin\theta(1-\cos^{2}\theta)  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{1}^{0}=\cos\theta  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{3}^{2}=15\sin^{2}\theta\cos\theta  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{2}^{2}=3\sin^{2}\theta  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{3}^{1}=\frac{3}{2}\sin\theta(5\cos^{2}\theta-1)  $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{2}^{1}=3\sin\theta\cos\theta  $</td><td style='text-align: center; word-wrap: break-word;'>$  \mathrm{P}_{3}^{0}=\frac{1}{2}(5\cos^{3}\theta-3\cos\theta)  $</td></tr></table>

<div style="text-align: center;">a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_676_807_989_1123.jpg" alt="Image" width="26%" /></div>


<div style="text-align: center;">b)</div>


With solution in  $ \Phi(\phi) $ (12-83) and  $ \Theta(\theta) $ (12-87), we have the total angular solution  $ Y(\theta,\phi) $ in (12-81). Since its function form will depend on quantum number l and m, it is expressed as  $ Y_{l}^{m}(\theta,\phi) $. It needs to be normalized over angular part of space, i.e.:

 $$ \int\limits_{\theta=0}^{\pi}\int\limits_{\phi=0}^{2\pi}Y_{l}^{m*}Y_{l}^{m}\sin\theta d\theta d\phi=1 $$ 

The normalization factor A can be determined, the results are listed in