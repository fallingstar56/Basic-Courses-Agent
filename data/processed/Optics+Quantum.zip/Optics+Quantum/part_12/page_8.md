(you may prove this hack way or as in angular momentum theory, since these functions are eigenfunctions for a Hermitian operator L, they must be orthogonal), meaning:

 $$ \int\limits_{\theta=0}^{\pi}\int\limits_{\phi=0}^{2\pi}Y_{l^{\prime}}^{m^{\prime}*}Y_{l}^{m}\sin\theta d\theta d\phi=\delta_{l l^{\prime}}\delta_{m m^{\prime}} $$ 

I’d better make a quick summary on this lengthy section on the angular solution. The most important facts for this course is through the solution of angular part (12-80), we can put restrictions on the quantum number l and m (12-90); and the wave functions on angular part can also be determined (12-83), (12-87) and (12-91).

## (4) Radial solution and quantum number n

We still need to solve the radial equation (12-79) to have a complete solution for electron in hydrogen atom. I shall list out crucial steps below and left some details out. You can find step by step derivation in Griffiths.

(a) Reformulate (12-79) into better form

Let's define a function:

 $$ u(r)\equiv rR(r) $$ 

In terms of u(r), the (12-79) becomes:

 $$ -\frac{\hbar^{2}}{2m}\frac{d^{2}u}{d r^{2}}+\left[V(r)+\frac{l(l+1)\hbar^{2}}{2m r^{2}}\right]u=E u $$ 

This equation is exactly a particle moving in a 1-D potential, the