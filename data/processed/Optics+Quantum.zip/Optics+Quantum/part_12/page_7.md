the table for some normalized  $ Y_{l}^{m}(\theta,\phi) $

 $$ \mathbf{Y}_{0}^{0}=\left(\frac{1}{4\pi}\right)^{1/2} $$ 

 $$ \mathrm{Y}_{2}^{\pm2}=\left(\frac{15}{32\pi}\right)^{1/2}\sin^{2}\theta\mathrm{e}^{\pm2\mathrm{i}\phi} $$ 

 $$ \mathbf{Y}_{1}^{0}=\left(\frac{3}{4\pi}\right)^{1/2}\cos\theta $$ 

 $$ \Upsilon_{3}^{0}=\left(\frac{7}{16\pi}\right)^{1/2}\left(5\cos^{3}\theta-3\cos\theta\right) $$ 

 $$ \mathbf{Y}_{1}^{\pm1}=\mp\left(\frac{3}{8\pi}\right)^{1/2}\sin\theta\mathbf{e}^{\pm\mathrm{i}\phi} $$ 

 $$ \mathbf{Y}_{3}^{\ast1}=\mp\left(\frac{21}{64\pi}\right)^{1/2}\sin\theta(5\cos^{2}\theta-1)\mathbf{e}^{\ast\mathrm{i}\phi} $$ 

 $$ \mathbf{Y}_{2}^{0}=\left(\frac{5}{16\pi}\right)^{1/2}\left(3\cos^{2}\theta-1\right) $$ 

 $$ \mathbf{Y}_{3}^{\pm2}=\left(\frac{105}{32\pi}\right)^{1/2}\sin^{2}\theta\cos\theta\mathbf{e}^{\pm2\mathrm{i}\phi} $$ 

 $$ \mathbf{Y}_{2}^{\pm1}=\mp\left(\frac{15}{8\pi}\right)^{1/2}\sin\theta\cos\theta\mathbf{e}^{\pm i\phi} $$ 

 $$ \mathrm{Y}_{3}^{\pm3}=\mp\left(\frac{35}{64\pi}\right)^{1/2}\sin^{3}\theta\mathrm{e}^{\pm3\mathrm{i}\phi} $$ 

 $ Y_{l}^{m}(\theta,\phi) $ is called spherical harmonics, it is the eigenfunction for the orbital angular momentum, and it is probably one of the most important functions in quantum mechanics. For more on the properties (such as parity property) on the spherical harmonics, please refer to special functions in math books or Cohen-Tannoudji's book complement  $ A_{VI} $ for details (we do not need much of them in this course, but they play important roles in later advanced topics, such as transition probability and selection rules in spectroscopy, i.e. tell you what kind of change of energy state in atom/molecule is allowed through the interaction with light).

The general formula for the spherical harmonics is:

 $$ Y_{l}^{m}(\theta,\phi)=\varepsilon\sqrt{\frac{(2l+1)}{4\pi}\frac{(l-|m|)!}{(l+|m|)!}}e^{i m\phi}P_{l}^{m}(\cos\theta) \varepsilon=(-1)^{m}\quad m\stackrel{\equiv}{\leq}0;\qquad\varepsilon=1\quad m<0 $$ 

These functions form an orthonormal basis over the angular space