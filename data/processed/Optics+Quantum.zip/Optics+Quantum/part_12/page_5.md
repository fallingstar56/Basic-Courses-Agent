the students who want to learn more beyond this course, please refer to these references.

The solution to  $ (12-86) $ is:

 $$ \Theta(\theta)=A P_{l}^{m}(\cos\theta) $$ 

A is a factor can be determined by normalization.  $ P_{l}^{m}(x) $ is so-called associated Legendre function, which can be calculated from the Legendre polynomial:

 $$ P_{l}^{m}(x)\equiv(1-x^{2})^{\frac{|m|}{2}}(\frac{d}{d x})^{|m|}P_{l}(x) $$ 

 $ P_{1}(x) $ is the Legendre polynomial, which can be worked out by the generating formula:

 $$ P_{l}(x)\equiv\frac{1}{2^{l}l!}(\frac{d}{dx})^{l}(x^{2}-1)^{l} $$ 

These solutions put a restriction on the possible l and m:

The Legendre polynomial is meaningful only if $l$ is non-negative integer; from (12-89) the highest order of $x$ is $x^l$, to have non-zero $P_l^m(x)$ from (12-89), the $|m|\leq l$. Thus the restriction on the $l$ and $m$: $l=0,1,2,\ldots$ (12-90)

 $$ m=-l,-l+1....l-1,l $$ 

For any given value $l$, there are $2l+1$ possible m. In the angular momentum theory, the $l$ corresponds to the magnitude of angular momentum, i.e. $|L|=\sqrt{l(l+1)}\hbar$; $m$ corresponds to the directional component of angular momentum, say the $z$ component: $L_z=m\hbar$.

Some lower order of the polynomial and associated function are listed