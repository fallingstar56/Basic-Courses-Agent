## Chapter 13 Identical Particles and Permutation Symmetry

So far we have discussed mostly on the system containing only one particle, for example the single electron in the potential well in last chapter, the spin of single electron in Stern-Gerlach. The only case we involve multiple particles is the double slit experiment example with electron-photon scattering, but there the particles are “distinguishable” meaning “not identical” (we shall give more detail on the meaning of distinguishable and identical below). In this chapter, we shall discuss on system involving multi-particles (mostly I shall talk about particle number N=2 system to illustrate the principle which can be extended to N>2 case). Let’s first take a look on the distinguishable particles case.

## 13 -1 Non-identical and Identical Particles

I shall use collision between particles as an example for this discussion.

The example is discussed in Feynman's 3.4 and 4.1; it acts as a prelude

where the Q.M. treatment for identical particles is introduced. Things will

be a little different from our previous discussion where we consider single

particle cases. Here many-body is involved and we shall see how Q.M.

works for this non-identical system. The important class of identical

particles, such as Bosons and Fermions will be introduced in next section.

Let's first take a look of the experimental setup before starting a formal