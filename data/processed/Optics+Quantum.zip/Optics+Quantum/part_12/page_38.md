description of the system of identical particles.

The above is summarized as a postulate modifying the postulate 1:

The state vector describing the identical particle system has to be either symmetric (for Bosons) or anti-symmetric (for Fermions) with respect to permutation.

Which particles are Bosons and which are Fermions then? The answer is their spin quantum numbers (though I cannot prove it here). For a particle whose spin is an integer (integers of $\hbar$, such as $0\hbar,1\hbar\ldots$), it is a Boson. If the spin is half integer ($\frac{1}{2}\hbar,\frac{3}{2}\hbar\ldots$), it is a Fermion.$^{86}$ For the fundamental particles, the spin is just the spin of the particle (electron, proton, neutron with spin of $\frac{1}{2}\hbar$ are Fermions; photon with spin of $\hbar$ is a Boson). For composite particles (nuclei or atoms made of fundamental particles), the spin is the total spin (summation of spin numbers of the particle it consists). Spin equals integer there means even number of the composing fermions (such as the $\alpha$ particle with 2 protons (one $+1/2$, one $-1/2$), 2 neutrons (one $+1/2$, one $-1/2$) and 0 electron, $S=0$); while spin equals half-integer means odd number of fermions.

This permutation symmetry requirement is better be illustrated by