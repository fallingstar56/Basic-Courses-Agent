|D_{i}> are determinant forms in (13-12), its antisymmetric but may not be eigenfunctions of total angular momentum. |D_{i}> are orthogonal so that we can find out antisymmetric form as (13-19). For example, the state with form of (13-16) will only have |D_{1}>component:

<D_{1}|\phi_{1s}(1)\phi_{2s}(2)\alpha(1)\alpha(2)>={\frac{1}{\sqrt{2}}}, the rest of the coefficients in (13-19) will be zero. So the |0,0,1,1> state only contains the |D_{1}> and with renormalization within the antisymmetric subspace, we have:

 $$ |0,0,1,1>=\mid D_{1}> $$ 

It will be same as first relation in (13-17) with (13-12) for  $ |D_1\rangle $.

For the  $ |0,0,1,0\rangle $, we can start from direct product combining (13-13)

and (13-14):

 $ |0,0,1,0 \rightarrow \phi_{1s}(1)\phi_{2s}(2)\frac{1}{\sqrt{2}}[\alpha(1)\beta(2) + \alpha(2)\beta(1)] $ which is not symmetry adapted, but can find out the  $ |D> $ component and with proper normalization, the result is:

 $$ |0,0,1,0>=\frac{1}{\sqrt{2}}(|D_{2}>+|D_{3}>) $$ 

Similarly

 $$ \begin{aligned}&|0,0,1,-1>=\mid D_{4}>\\&|0,0,0,0>=\frac{1}{\sqrt{2}}(\mid D_{2}>-\mid D_{3}>)\end{aligned} $$ 

These will be same as given in (13-17) and (13-18) if you plug in the specific form of the D's.

These wave functions are symmetry adapted and with certain angular