 $$ \hat{P}_{j k}\mid\psi_{1,2,3..j..k..}>=\mid\psi_{1,2,3..k..j..}> $$ 

 $ \hat{P}_{jk} $ is a permutation operator that does exactly as describe above,

exchange the labeling. Both vectors before and after the permutation

should represent the same physical state due to the identical property (this

is actually a postulate and a quite intuitive one). i.e.:

 $$ \hat{P}_{j k}\mid\psi_{1,2,3..j..k..}>=|\psi_{1,2,3..k..j..}>={\varepsilon}\mid\psi_{1,2,3..j..k..}>\quad{\varepsilon}\quad{\mathrm{i s~a~c o n s t a n t.}} $$ 

From the definition, it is obvious that:

 $ \hat{P}_{jk}\hat{P}_{jk}\equiv(\hat{P}_{jk})^2=I $, the identity matrix.

 $$ (\hat{P}_{j k})^{2}\mid\psi_{1,2,3..j..k..}>=\varepsilon^{2}\mid\psi_{1,2,3..j..k..}>=\mid\psi_{1,2,3..j..k..}> $$ 

So  $ \varepsilon^{2}=1 $, and  $ \varepsilon=1 $ or  $ -1^{85} $.

So for every physical state describing the system of many identical particles, they should satisfy either:

 $$ \hat{P}_{j k}\mid\psi_{1,2,3..j..k..}>=|\psi_{1,2,3..j..k..}> $$ 

Or

 $$ \hat{P}_{j k}\mid\psi_{1,2,3..j..k..}>=-\mid\psi_{1,2,3..j..k..}> $$ 

 $ |\psi_{1,2,3...j...k...}> $ is the eigenstate for permutation operator.It has clear

symmetry upon permutation. The one associated with eigenvalue 1

(13-4) is called symmetric state, and it describes the state of Boson particle.

The one associated with eigenvalue -1(13-5) is called anti-symmetric, and

describes the state of Fermion. These symmetric or anti-symmetric with

respect to permutation put a restriction on the proper mathematical