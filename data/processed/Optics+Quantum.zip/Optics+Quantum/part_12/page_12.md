 $$ n\equiv j_{0}+l+1\qquad(12-102) $$ 

Then:

 $$ \rho_{_{0}}=2n\qquad(12-103) $$ 

The n can only take positive integers 1, 2, 3..., since both  $ j_{0} $ and l are non-negative integers. We then have energy relation:

 $$ \begin{aligned}&\rho_{_{0}}^{^{2}}\equiv\frac{m_{_{e}}^{^{2}}e^{^{4}}}{(2\pi\varepsilon_{_{0}}\hbar^{^{2}})^{^{2}}k^{^{2}}}=-\frac{m_{_{e}}e^{^{4}}}{8\pi^{^{2}}\varepsilon_{_{0}}^{^{2}}\hbar^{^{2}}E}\\ &E=-\frac{1}{n^{^{2}}}[\frac{m_{_{e}}}{2\hbar^{^{2}}}(\frac{e^{^{2}}}{4\pi\varepsilon_{_{0}}})^{^{2}}]=\frac{E_{_{1}}}{n^{^{2}}}\\ &E_{_{1}}=-\frac{m_{_{e}}}{2\hbar^{^{2}}}(\frac{e^{^{2}}}{4\pi\varepsilon_{_{0}}})^{^{2}}=-13.6eV\\ \end{aligned} $$ 

This is the ground state energy of electron in hydrogen. The higher energy levels corresponds to larger n. We thus have the formula for the complete energy spectrum of electron in hydrogen.

 $$ \begin{aligned}&k=\frac{m_{e}e^{2}}{2\pi\varepsilon_{0}\hbar^{2}\rho_{0}}=\frac{1}{n}(\frac{m_{e}e^{2}}{4\pi\varepsilon_{0}\hbar^{2}})=\frac{1}{a_{0}n}\\&a_{0}=\frac{m_{e}e^{2}\equiv}{4\pi\varepsilon_{0}\hbar^{2}}=0.529^{\circ}\quad(12-107)\\ \end{aligned} $$ 

This is the Bohr radius (the radius of the orbital for the ground state electron) in Bohr's model. Of course there is no orbital in quantum; the $a_{0}$ is actually where the electron has the largest radial probability density (problem 4.14 in Griffiths). To prove this we have to know the wave function.

Digression: Atomic Units

In atomic physics, it is more convenient to use atomic unit by rescale