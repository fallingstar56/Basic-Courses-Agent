 $$ V(r)=-\frac{e^{2}}{4\pi\varepsilon_{0}r}\ r=\mid r_{e}-R_{n}\mid $$ 

The total Hamiltonian includes both kinetic energy of nucleus and electron. We have learned the way to simplify such problems by using center of mass frame, the Hamiltonian will decompose into the free-particle motion of the total mass, and relative motion of reduced mass. We know how to solve the free particle and here we shall only concentrate on the relative motion, whose Hamiltonian is:

 $$ H=-\frac{\hbar^{2}}{2}\frac{1}{m}\Delta+V(r)\Delta\equiv\nabla^{2} $$ 

The m should be the reduced mass  $ \left(m_{e}M_{n}/m_{e}+M_{n}\right) $, but very close to  $ m_{e} $.

(2) Spherical symmetry of the potential and separation of variables of the S equation

Since the potential V(r) (r>0) only depends on distance, not on direction. It has what is called spherical symmetry. This implies the (12-76) should be worked in spherical coordinate and we need the explicit form of it.

 $$ \begin{aligned}\Delta=&\frac{\partial^{2}}{\partial x^{2}}+\frac{\partial^{2}}{\partial y^{2}}+\frac{\partial^{2}}{\partial z^{2}}\quad(Cartesian)\\=&\frac{1}{r^{2}}\frac{\partial}{\partial r}(r^{2}\frac{\partial}{\partial r})+\frac{1}{r^{2}\sin\theta}\frac{\partial}{\partial\theta}(\sin\theta\frac{\partial}{\partial\theta})+\frac{1}{r^{2}\sin^{2}\theta}\frac{\partial^{2}}{\partial\phi^{2}}\end{aligned} $$ 

The relations can be derived directly from the relation between

Cartesian and Spherical coordinate  $ (x = r \sin \theta \cos \phi, y = r \sin \theta \sin \phi, $