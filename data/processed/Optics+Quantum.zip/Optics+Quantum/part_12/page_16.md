 $$ (c_{0}=\sqrt{\frac{2}{a}}\mathrm{~from~normalization~for~R_{20}}) $$ 

The complete wave function for state  $ |2,0,0> $ would be:  $ \psi_{200}=R_{20}Y_{0}^{0} $.

For the case of  $ |2,1,0> $:

 $ J_{0}=0 $, so only  $ c_{0} $ term in polynomial, and :

 $$ R_{21}(r)=\frac{c_{0}}{r}\big(\frac{r}{2a_{0}}\big)^{2}e^{-\frac{r}{2a_{0}}}=\frac{c_{0}}{4a_{0}^{2}}re^{-\frac{r}{2a_{0}}}\quad(c_{0}=\sqrt{\frac{2}{3a_{0}}}\quad for R_{21}) $$ 

The complete wave function would be:  $ \psi_{210} = R_{21}Y_1^0 $; for the  $ [2,1,1>2,1,-1> $ case, just replace it with proper spherical harmonics.

For the simple examples given above, we can find wave functions term by term with recursion. The radial function  $ R_{nl} $ has a general formula, using the so called associated Largurre function:

 $$ R_{n l}=\sqrt{(\frac{2}{n a_{0}})^{3}\frac{(n-l-1)!}{2n[(n+l)!]^{3}}}(\frac{2r}{n a_{0}})^{l}e^{-\frac{r}{n a_{0}}}[L_{n-l-1}^{2l+1}(\frac{2r}{n a_{0}})] $$ 

The L in the monster formula is associated Laguerre function:

 $$ L_{q-p}^{p}(x)\equiv(-1)^{p}(\frac{d}{d x})^{p}L_{q}(x) $$ 

 $ L_{q}(x) $ is the Laguerre polynomial defined as:

 $$ L_{q}(x)\equiv e^{x}(\frac{d}{dx})^{q}(e^{-x}x^{q}) $$ 

You can find the first couple polynomials and associated functions

tabled in Griffiths' book, and the first couple radial function  $ R_{nl} $ are: