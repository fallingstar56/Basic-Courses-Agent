distinguishable and exclusive for non-identicals.

<div style="text-align: center;"><img src="imgs/img_in_image_box_240_207_699_447.jpg" alt="Image" width="38%" /></div>


According to Feynman’s arguments and our discussion in Example 2 (chapter 11), the probability of different distinguishable events is the sum of the probability of individual event. This is really in analogy of the ‘which-way’ experiment in interference. There if the individual paths can be determined, then just sum of probability and no interference.

Enough for the semi-quantitative argument, I shall proceed to prove it from the postulates in Q.M.

<div style="text-align: center;"><img src="imgs/img_in_image_box_251_966_556_1150.jpg" alt="Image" width="25%" /></div>


For a particle A coming from left and B from right, where  $ A \neq B $, the initial state of the system can be described as a state vector (Dirac's

Ket):

 $$ |\psi_{_{AB}}>_{i}=|A,L;B,R>=|A,L>\otimes|B,R> $$ 

This abstract math representation means an initial state (the subscript I stands for) where particle A from right and particle B from left and the