examples:

For a two-Boson particle system (such as collision between two  $ \alpha $ particles), we used symbol containing combinations of  $ |1, L; 2, R> $ type to represent one particle coming from left and one from right. The permutation symmetry will remove the exchange degeneracy on state description. Please note:

 $$ |2,L;1,R>\neq|1,L;2,R>\stackrel{87}{} $$ 

But we can construct easily a mathematical representation that satisfies the (13-4) by:

 $$ |\psi_{1,2}>_{b o s o n}=\frac{\sqrt{2}}{2}(|1,L;2,R>+|2,L;1,R>) $$ 

This state is obvious symmetric with respect to permutation and it removes the exchange degeneracy, i.e. fixes the relationship of the coefficients.  $ \frac{\sqrt{2}}{2} $ is just the normalization factor. More generally, for a system of two Bosons, one at state with some property (or properties)  $ \varepsilon_{1} $, the other with property  $ \varepsilon_{2} $, the proper form of the physical state is:

 $$ |\psi_{_{1,2}}>_{b o s o n}=\frac{\sqrt{2}}{2}(|1,\varepsilon_{_{1}};2,\varepsilon_{_{2}}>+|2,\varepsilon_{_{1}};1,\varepsilon_{_{2}}>)^{88} $$ 