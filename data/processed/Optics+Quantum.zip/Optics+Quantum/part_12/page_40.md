Since within |2,  $ \varepsilon_1 $;1,  $ \varepsilon_2 $ >, where you put particles with associated property is arbitrary, i.e. |2,  $ \varepsilon_1 $;1,  $ \varepsilon_2 $ >=|1,  $ \varepsilon_2 $;2,  $ \varepsilon_1 $ > So, I will also write (13-6) in terms of:

 $$ |\psi_{1,2}>_{b o s o n}=\frac{\sqrt{2}}{2}(|1,\varepsilon_{1};2,\varepsilon_{2}>+|1,\varepsilon_{2};2,\varepsilon_{1}>) $$ 

Obviously with the form of 13-6 (or 13-6'), it satisfies the symmetry requirement for Boson (13-4), i.e.  $ \hat{P}_{12} \mid \psi_{12} \geq \mid \psi_{12} \rangle $ for these two-particle systems. For many Boson particles, say N, then:

 $$ |\psi_{1,2,\ldots N}>_{b o s o n}=\frac{1}{\sqrt{N!}}\sum_{\substack{p e r m u t a t i o n o f N t e r m s}}^{\perp}\mathcal{E}_{1};2,\mathcal{E}_{2}...;N,\mathcal{E}_{N}> $$ 

For the two-Fermions case (such as two electron), similar argument with respect to the symmetry requirement by 13-5 would lead us to the proper description of the physical state:

 $$ \begin{aligned}|\psi_{1,2}>_{fermion}=&\frac{\sqrt{2}}{2}(|1,\varepsilon_{1};2,\varepsilon_{2}>-|2,\varepsilon_{1};1,\varepsilon_{2}>)\\=&\frac{\sqrt{2}}{2}(|1,\varepsilon_{1};2,\varepsilon_{2}>-|1,\varepsilon_{2};2,\varepsilon_{1}>)\end{aligned} $$ 

(13-8) satisfies (13-5). For the case of many fermions, the expression of the state would be in a form given by Slater Determinant :

If we have total of n fermions, and we have n normalized states specified by some quantum number  $ \varepsilon_{i} $ occupied by the fermions, the total state that