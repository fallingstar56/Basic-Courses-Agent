the length, mass, charge etc. It is quite straightforward from above

relations; the form can be greatly simplified if we define new units as:

 $ m_{e}=1 $ au (mass)

 $$ \frac{e}{\sqrt{4\pi\varepsilon_{0}}}=1\ a u\ (charge) $$ 

 $$ a_{_{0}}=1au(length) $$ 

Then  $ \hbar = 1 $ in atomic unit (it is the unit for angular momentum).

To find au for time or speed, we use the fact the following combination would be a dimensionless constant:

 $$ \alpha\equiv\frac{\hbar}{a_{0}m_{e}c}\approx\frac{1}{137} $$ 

The $\alpha$ is called fine structure constant. It appears quite often in atomic physics. Then $\alpha c$ is the au for velocity. In terms of au, the energy (12-105) will be $E_{1}=-\frac{1}{2}	au$. The au for energy is called Hartree, and 1 Hartree=27.2 eV.

(d) Quantum numbers and Wave functions corresponding to them

After determining the energy form, we know the  $ \rho_{0} $ in the recursion formula (12-101) and the radial wave function can be determined, where the  $ c_{0} $ can be fixed by normalization condition:

 $$ \int\limits_{0}^{\infty}R^{*}(r)R(r)r^{2}dr=1 $$ 

Because the angular part wave function is already normalized in forms