molecules, these are called hybrid orbitals, such as  $ sp^{3} $,  $ sp^{2} $, sp hybrids etc.

One more thing need to be mentioned: degeneracy

We have seen that the energy in hydrogen only depends on principal quantum number n. For a given n, in the n>1 case, there are many distinct (linear independent) states correspond to the same energy, 4 for the n=2 case. The situation that many distinct states correspond to same energy is called degeneracy, meaning specify energy only cannot fix the state. For example with n=2 energy, any linear combination of the 4 states can be eigenstates with same energy. That is why we need extra quantum numbers l and m to specify the state, those quantum numbers correspond to orbital angular momentum and its directional component. $ ^{78} $ The number of degeneracy (numbers of distinct states correspond to same energy) can be calculated for hydrogen:

 $$ g_{n}=\sum_{l=0}^{n-1}(2l+1)=n^{2} $$ 

The reason that different orbital angular momentum l has same energy is “accidental” in the hydrogen case, for the potential with 1/r form $ ^{79} $. For other potential form, or inclusion of electron repulsion in multielectron atoms, or including the relativistic effect (the spin-orbit