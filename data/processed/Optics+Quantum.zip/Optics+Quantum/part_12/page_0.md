and wave functions (12-74). If you are happy with the process, great; if not at least you know the results.

I must confess the math is not pretty here. Even provided with wavefucntions as (12-74), it is still a nightmare to calculate other physical parameters, such as  $ \langle x^2 \rangle $ or  $ \langle p^2 \rangle $ (the  $ \langle x \rangle = 0, \langle p \rangle = 0 $ is easy by using odd even symmetry). The operator method will be more clean and beautiful, and also provides easier ways in estimate terms (so-called matrix element) in the energy eigenbasis, such as  $ \langle x^2 \rangle $ or  $ \langle p^2 \rangle $.

## 12 -6 Hydrogen Atom

This is the only atomic element which has a single electron and thus simplest Hamiltonian and has rigorous analytic solution in quantum. It also serves as a model and starting point in calculation for other multi-electron atoms. It is still the more complicated calculation so far and in this section, I shall list out the major procedures in solving the S-equation for hydrogen atom, with some math details neglected $ ^{73} $.

## (1) The S-equation for H atom

The total Hamiltonian with Coulomb potential between nucleus and electron is in form of (in space representation):

 $$ H_{total}=-\frac{\hbar^{2}}{2}(\frac{1}{M}\Delta+\frac{1}{m}\Delta)+V(r) $$ 