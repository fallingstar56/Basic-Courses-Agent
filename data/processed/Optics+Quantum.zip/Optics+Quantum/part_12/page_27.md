quantum treatment.

<div style="text-align: center;"><img src="imgs/img_in_image_box_219_231_753_464.jpg" alt="Image" width="44%" /></div>


<div style="text-align: center;">(fig.3-7, Feynman)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_213_510_801_760.jpg" alt="Image" width="49%" /></div>


<div style="text-align: center;">Fig. 3–8. The scattering of electrons on electrons. If the incoming electrons have parallel spins, the processes (a) and (b) are indistinguishable.</div>


<div style="text-align: center;">(fig.3-8)</div>


The setups are shown in the above figures (fig. 3-7 and 3-8 in Fynman’s) for the collision between the non-identical and identical particles respectively. The setup is easy to understand. The particles collide and then scatter to different angles. If one of the particles being scattered into angle  $ \theta_{1} $ and can be picked up by detector D1. From the conservation of momentum, the other particle will be scattered into the angle  $ \pi - \theta_{1} $ (this is of course in the reference frame of the center of mass, i.e. a coordinate system moving with the center of mass of the two particles) and be detected by detector D2.

The classical theory would give the results same for both non-identical and identical cases, only a difference in the probability of the particle