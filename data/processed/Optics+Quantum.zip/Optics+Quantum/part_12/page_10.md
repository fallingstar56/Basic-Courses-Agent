 $$ \frac{d^{2}u}{k^{2}dr^{2}}=[1-\frac{me^{2}}{2\pi\varepsilon_{0}\hbar^{2}k}\frac{1}{kr}+\frac{l(l+1)}{\left(kr\right)^{2}}]u $$ 

With substitution:

 $$ \rho\equiv k r,\rho_{0}\equiv\frac{m e^{2}}{2\pi\varepsilon_{0}\hbar^{2}k} $$ 

We have:

 $$ \frac{d^{2}u}{d\rho^{2}}=[1-\frac{\rho_{0}}{\rho}+\frac{l(l+1)\hbar^{2}}{\rho^{2}}]u $$ 

At the limit of the r, one end is infinity where both potential terms

vanish except constant 1; the other end is r=0, where the centrifugal

term dominates. We can get the asymptotic behavior of the solution

close to these two limits by neglecting the appropriate terms:

 $$ u\xrightarrow{\rho\rightarrow\infty}A e^{-\rho}+B e^{\rho}\quad\quad u\xrightarrow{\rho\rightarrow0}C\rho^{l+1}+D\rho^{-l} $$ 

The normalizable solution requires B and D to be zero. (It should be kept in mind that it is  $ R(r)=u(r)/r $ required to be normalizable, that kills D even for the  $ l=0 $ case) Thus the suitable guess for the general solution would be:

 $$ u(r)=v(\rho)\rho^{l+1}e^{-\rho} $$ 

 $ v(\rho) $ is a polynomial whose coefficients to be determined:

 $$ \nu(\rho)=c_{0}+c_{1}\rho+...=\sum_{j=0}^{\infty}c_{j}\rho^{j} $$ 

Here the potential is not symmetric in r, so I do not have even or odd series.

Put form (12-99) into (12-98) we get: