 $$ \begin{aligned}&\hat{R}(x)\otimes\hat{P}(y)\mid\Psi>=\left(\hat{R}(x)\mid\Phi>\right)\otimes\left(\hat{P}(y)\mid\Theta>\right)\\ &\\ &\frac{\partial^{2}}{\partial x\partial y}act on\phi(x)\theta(y))\\ \end{aligned} $$ 

With the above knowledge, I can now talk about the electron state in hydrogen with inclusion of spin. We have seen that the  $ |n,l,m> $ completely specify the eigenstate of Hamiltonian in 3-D space, and these  $ |n,l,m> $ do form a complete and orthogonal basis in 3-D (eigenstates of Hermitian operator); and spin is spanned by the  $ |S,S_{z}> $, so the tensor product of them will form a complete and orthogonal basis for the tensor product space of 3-D and spin. These basis vectors are expressed as:

 $$ |n,l,m,S,S_{z}>{\equiv}|n,l,m>\otimes|S,S_{z}>\qquad(12-I I8) $$ 

If expressed in wave function:

 $$ <x,y,z,\alpha\mid n,l,m,S,S_{z}>=\psi_{n l m}\alpha_{i} $$ 

The  $ \alpha $ above is just abstract parameter symbolizes the spin degree of freedom, and the  $ \alpha_{i} $ is just  $ \alpha_{\pm} $ in (12-117) depend on the value of  $ S_{z} $, they are just column vectors  $ \begin{bmatrix} 1 \\ 0 \end{bmatrix}, \begin{bmatrix} 0 \\ 1 \end{bmatrix} $ if  $ \alpha_{\pm} $ are the base vectors in spin space.

For any arbitrary state, it can be expressed as combination of base vectors. More specifically, for any arbitrary tensor product state:

 $$ \begin{aligned}&|\psi,\chi_{s}>=\mid\psi>\otimes\mid\chi_{s}>=\sum c\mid n,l,m,S,S_{z}>\\&c=<n,l,m\mid\psi><\alpha_{\pm}\mid\chi_{s}>=(\int\psi_{n l m}^{*}\psi d^{3}r)<\alpha_{\pm}\mid\chi_{s}>\\ \end{aligned} $$ 