and $z=r\cos\theta$ and reverse relations), please confirm (12-77) as an exercise$^{74}$. Of course, the stationary wave function is expressed in term of: $\psi(r,\theta,\phi)$.

We shall exploit separation of variables in solving the:

 $$ -\frac{\hbar^{2}}{2m}[\frac{1}{r^{2}}\frac{\partial}{\partial r}(r^{2}\frac{\partial}{\partial r})+\frac{1}{r^{2}\sin\theta}\frac{\partial}{\partial\theta}(\sin\theta\frac{\partial}{\partial\theta})+\frac{1}{r^{2}\sin^{2}\theta}\frac{\partial^{2}}{\partial\phi^{2}}]\psi+V(r)\psi=E\psi $$ 

First if the wave function can be separated as product of radial and angular part, i.e.:

 $$ \psi(r,\theta,\phi)=R(r)Y(\theta,\phi) $$ 

Insert this into (12-77), we will get (after some rearrangement):

 $$ \frac{1}{R}\frac{d}{d r}(r^{2}\frac{d R}{d r})-\frac{2m r^{2}}{\hbar^{2}}[V(r)-E]=-\frac{1}{Y}[\frac{1}{\sin\theta}\frac{\partial}{\partial\theta}(\sin\theta\frac{\partial Y}{\partial\theta})+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}Y}{\partial\phi^{2}}] $$ 

The left and right part depends on r and angles separately, and for the equation to be valid for any variables, the two ends has to equal to some constants, and we shall write the constant in forms of  $ l(l+1)^{75} $:

 $$ \frac{1}{R}\frac{d}{d r}(r^{2}\frac{d R}{d r})-\frac{2m r^{2}}{\hbar^{2}}[V(r)-E]=l(l+1) $$ 

 $$ \frac{1}{Y}[\frac{1}{\sin\theta}\frac{\partial}{\partial\theta}(\sin\theta\frac{\partial Y}{\partial\theta})+\frac{1}{\sin^{2}\theta}\frac{\partial^{2}Y}{\partial\phi^{2}}]=-l(l+1) $$ 

These are the two differential equations need to be solved. I shall only give the result mostly in the following for the solutions for these