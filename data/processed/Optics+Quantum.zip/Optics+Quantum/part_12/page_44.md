## (1) Ground state helium

The electron configuration is  $ 1s^{2} $, meaning one electron in the 1s orbital with spin up and the other in the same 1s with spin down. Here I should mention that the 1s orbital here is different from the  $ \psi_{100} $ in hydrogen. It has to be calculated with the Hamiltonian in helium which contains electron repulsion term (try to write the Hamiltonian for the He yourself). Solving that with approximation method will give us the 1s, 2s... orbitals. These are single electron wave functions bears some resemblance to the hydrogen, and we call it hydrogen-like orbitals. The total wave functions have to be antisymmetric, and there is only one determinant form for this configuration:

 $$ |\varepsilon_{1}>\rightarrow\phi_{1s}\alpha,\quad|\varepsilon_{2}>\rightarrow\phi_{1s}\beta $$ 

 $$  I use\quad\alpha\rightarrow|+>=|S=\frac{1}{2},S_{z}=\frac{1}{2}>,\\ \beta\rightarrow|->=|S=\frac{1}{2},S_{z}=-\frac{1}{2}>(\text{instead} $$ 

of α_ used before to save some type).

The total wave function in Slater determinant is:

 $$ \begin{aligned}\psi_{ground}=&\frac{1}{\sqrt{2}}\left|\phi_{1s}(1)\alpha(1)\quad\phi_{1s}(1)\beta(1)\right|\\=&\frac{1}{\sqrt{2}}[\phi_{1s}(1)\alpha(1)\phi_{1s}(2)\beta(2)-\phi_{1s}(1)\beta(1)\phi_{1s}(2)\alpha(2)]\end{aligned} $$ 

Rearrange above:

 $$ \psi_{ground}=\phi_{1s}(1)\phi_{1s}(2)\frac{1}{\sqrt{2}}[\alpha(1)\beta(2)-\beta(1)\alpha(2)] $$ 

The reason for the form of  $ (13-11) $ will be clear once you learned the