directions. Since those won't be detected, so they are omitted here.

(Though the angular distribution would be continuous, I shall use discrete simplification here too) Let's call:

 $$ |\varphi_{\theta}>=|A,\theta;B,\pi-\theta>;|\varphi_{\pi-\theta}>=|A,\pi-\theta;B,\theta> $$ 

Then:  $ \langle \varphi_{\theta_i} \mid \varphi_{\theta_j} \rangle = \delta_{ij} $

 $$ \begin{array}{l} And\quad f(\theta)=<\varphi_{\theta}\mid\psi_{AB}>,f(\pi-\theta)=<\varphi_{\pi-\theta}\mid\psi_{AB}>\\\end{array} $$ 

The probability for D1 detects either A or B is:

 $$ \begin{aligned}P(D_{1})=&<\psi_{_{AB}}\begin{vmatrix}|\varphi_{\theta}><\varphi_{\theta}|\\ +\\ \|\varphi_{\pi-\theta}><\varphi_{\pi-\theta}\|\end{vmatrix}\psi_{_{AB}}>\\ =&\left\langle f(\theta)^{*}<\varphi_{\theta}|+\\ &f(\pi-\theta)^{*}<\varphi_{\pi-\theta}|\end{vmatrix}\begin{vmatrix}|\varphi_{\theta}><\varphi_{\theta}|\\ +\\ \|\varphi_{\pi-\theta}><\varphi_{\pi-\theta}\|\end{vmatrix}\left\lvert f(\theta)|\varphi_{\theta}>+\right.\\ =&\left|f(\theta)\right|^{2}+|f(\pi-\theta)|^{2}\end{aligned} $$ 

 $ |\varphi_\theta><\varphi_\theta| $ is the detection of A by D1, and  $ |\varphi_{\pi-\theta}><\varphi_{\pi-\theta}| $ is the detection of B by D1. The probability result is exactly same as Feynman’s 3-14.

(2) A more complex case: scattering between identical particles

First define what identical particles are. They have the same intrinsic properties (such as mass, spin, charge, etc.) and cannot be distinguished in any experiment.

In classical mechanics, of course there are these particles with same intrinsic properties. However, even these particles can be distinguished, because they may follow different paths (trajectory). Imagine a pool of