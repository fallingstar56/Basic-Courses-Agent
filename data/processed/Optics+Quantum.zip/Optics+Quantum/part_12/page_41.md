is antisymmetric with respect to permutation is given by:

 $$ |\psi>_{f e r}=\frac{1}{\sqrt{n!}}\left|\begin{matrix}|1,\varepsilon_{1}>&|1,\varepsilon_{2}>&\ldots|1,\varepsilon_{n}>\\ |2,\varepsilon_{1}>&|2,\varepsilon_{2}>&\ldots|2,\varepsilon_{n}>\\ \end{matrix}\right|\\ \left|\begin{matrix}\\ |n,\varepsilon_{1}>&|n,\varepsilon_{2}>&\ldots|n,\varepsilon_{n}>\\ \end{matrix}\right.\\ \end{matrix}\right. $$ 

Often, we express the vector in the wave function form, such as electrons in the hydrogen-like orbitals (include the spin), in this case:

|1,  $ \varepsilon_1 $  $ \rightarrow $  $ \phi_1\chi_1(1) $, where  $ \phi $ is the spatial orbital,  $ \chi $ is the spin function, and (1) means for the electron labeled with 1, the Slater determinant:

 $$ \psi_{f e r}=\frac{1}{\sqrt{n!}}\left|\begin{matrix}\phi_{1}\chi_{1}(1)&\phi_{2}\chi_{2}(1)...&\phi_{n}\chi_{n}(1)\\ \phi_{1}\chi_{1}(2)&\phi_{2}\chi_{2}(2)...&\phi_{n}\chi_{n}(2)\\ &\\ &\phi_{1}\chi_{1}(n)&\phi_{2}\chi_{2}(n)...&\phi_{n}\chi_{n}(n)\end{matrix}\right| $$ 

Comment on Slater determinant:

(1) The form of the matrix is easy to remember, for the  $ a_{ij} $ element: i is the particle label; j is the wave function label. There are n! terms in the determinant, each is a tensor product of single-particle type functions (just multiplications); the  $ \frac{1}{\sqrt{n!}} $ is for normalization.

(2) Using the determinant property, it is easy to see that if we exchange labels of two fermions (permutation), it is equivalent to exchange two rows of the determinant, the result is clearly antisymmetric (-1). You can also use the transposed matrix to represent the state for fermion.

(3) The two antisymmetric states represented by two different