## 13-2 Exchange Deneneracy and Permutation Symmetry Requirement in Identical Particles

In the example of collision among identical particles, the key is how we describe the state, is it a simple tensor product of two particles? The answer is NO, because they are identical, there is an ambiguity called exchange degeneracy. In the last example, since we cannot tell during the interaction between 1, 2 particles (here I use 1 and 2 instead of A,B for the label of identical particles), which comes from left or right, the following states:

 $$ \left|1,L;2,R>,\ \left|2,L;1,R>,\ a\ \left|1,L;2,R>+b\ \left|2,L;1,R>\right.\right.\right.\right. $$ 

may all be suitable for the description of the state, this ambiguity in state description has to be removed, since our physical measurement result does depend on the specific form of state (recall that though the overall phase factor will be equivalent for state description; the relative relation between the coefficients is important).

For the final product state in the collision, we have similar problem on state description:

 $$ \left|1,\theta;2,\pi-\theta>,\right|2,\theta;1,\pi-\theta>,c\left|1,\theta;2,\pi-\theta>+d\right|2,\theta;1,\pi-\theta> $$ 

These seem are all possible descriptions of the final states, there is ambiguity (exchange degeneracy) here too.