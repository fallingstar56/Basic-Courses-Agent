effective potential is:

 $$ V_{eff}=V+\frac{l(l+1)\hbar^{2}}{2mr^{2}} $$ 

This probably reminds you of the central field problem we learned in classical mechanics. There we encounter same effective potential in forms of  $ V + \frac{L^2}{2\mu r^2} $, where  $ \mu $ is the reduced mass and L is angular momentum. In quantum, the magnitude of angular momentum is  $ \sqrt{l(l+1)}\hbar $, so 12-95 is really analogous to the classical case. Solving the equation with Coulomb potential has similar procedures as solving the harmonic potential: Guess the general solution form by investigating the asymptotic behavior of solution; find the recursion formula for the polynomial, that will give us solution form; the polynomial has to be truncated to keep the solution normalizable, that will give us the quantization on energy.

(b) Asymptotic behavior of the solution and recursion formula for polynomial

Now we throw in the form of Coulomb potential:

 $$ V(r)=-\frac{e^{2}}{4\pi\varepsilon_{0}r}\mathrm{~a n d~d e f i n e:} $$ 

 $$ k\equiv\frac{\sqrt{-2mE}}{\hbar} $$ 

We expect the energy is less than zero for the bound state. (12-94)

becomes: