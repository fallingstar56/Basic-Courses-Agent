the  $ \alpha $ (or e) particles, but we do not know the particle is originally from left or right. i.e.:

These two events (the D1 records particle coming from left or particle from right) become indistinguishable $ ^{84} $. Then what is probability in this case for D1 registering a hit? Is it in a form of summation of probability as in non-identical case? Or is it in a form of (summation of probability amplitude) $ ^{2} $ as in interference? From the previous experience, you may make a sensible guess that it will be in a form of (summation of probability amplitude) $ ^{2} $, from the rules stated in Feynman’s lecture at the end of section 3-2; or using the analogy of ‘which-way’ experiment in the interference (here you really have no idea which way the particle originates when the D1 record a hit). So the previous discussion helps you developing a quantum instinct, which enables you to make a reasonable guess.



<div style="text-align: center;"><img src="imgs/img_in_image_box_220_272_752_502.jpg" alt="Image" width="44%" /></div>


Even it is in the form of (summation of probability amplitude)$^2$, then is

it $|f(\theta)+f(\pi-\theta)|^2$ or $|f(\theta)-f(\pi-\theta)|^2$ or other combinations

such as $|\alpha f(\theta)+\beta f(\pi-\theta)|^2$?