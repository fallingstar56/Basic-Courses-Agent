being scattered into certain angles due to difference of particles involved.

(i.e. the cross section for alpha-oxygen and electron-electron collision

will be different) But quantum mechanics would give drastic difference

between the non-identical and identical cases!

(1) Simple one: Collision between non-identical particles

Here non-identical means there are differences in some intrinsic properties (such as mass, charge, spin, etc.) between the particles, so that these particles can be distinguished.

For example, in the experiment shown in fig.3-7, the scattering between an  $ \alpha $ particle ( $ He_{4}^{2+} $) and a ion of oxygen ( $ O_{6}^{2+} $). These two particles are different and in principle can be distinguished. Let's imagine we have such device, for instance, our detector is a chemical reaction device. When the  $ He_{4}^{2+} $ particle strikes the detector, it will trigger a chemical reaction that would generate a red light (a photon with low frequency); while if the  $ O_{6}^{2+} $ strikes the detector, it would trigger a different reaction and give out green light (a photon with high frequency). So by detecting the light, we know that a particle strikes the detector; and by knowing the color of light, we would also know the kind of the particle. So these  $ He_{4}^{2+} $,  $ O_{6}^{2+} $ are in principle distinguishable, they are non-identical.

In this kind of experiment, you probably already guessed that the probability for any detector, say D1, to pick up a signal (either from