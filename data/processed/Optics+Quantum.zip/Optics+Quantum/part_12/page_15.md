Let’s work out the explicit function form given the quantum numbers.

For instance if n=1, we could only have $j_{0}=0$, meaning only has one

constant term in polynomial: $v_{n-1}(\rho)=c_{0}$ ; and $l=0$, meaning

restriction on angular quantum number, the angular function could

only be (since if $l=0$, m=0 too) $Y_{l}^{m}=Y_{0}^{0}$

 $$ R_{10}(r)=\frac{u(\rho)}{r}=\frac{u(\left.\frac{r}{a_{0}}\right.)}{r}=\frac{c_{0}\rho^{1}e^{-\rho}}{r}=c_{0}\frac{1}{a_{0}}e^{-r/a_{0}} $$ 

After normalization  $ c_0 = \frac{2}{\sqrt{a_0}} $, and  $ Y_0^0 = \sqrt{\frac{1}{4\pi}} $, then complete wave function for the ground state electron in hydrogen is:

 $$ \psi_{100}=\frac{1}{\sqrt{\pi a_{0}^{3}}}e^{-r/a_{0}} $$ 

Now let's consider the case for n=2. The energy is:

 $$ E_{2}=-\frac{E_{1}}{4} $$ 

There are 4 wave functions associated with this energy with different l or m. The possible combinations are:

 $ l=0,m=0; l=1,m=0,\pm1 $ total 4 of them.

For the case of  $ |n,1,m| \geq |2,0,0\rangle $, from (12-102) we see  $ j_0 = 1 $, meaning the polynomial has up to the order of  $ \rho^1 $, i.e.  $ v_{20}(\rho) = c_0 + c_1\rho $,

Using recursion formula  $ (\rho_{0}=2n=4\text{ here}) $:  $ c_{1}=-c_{0} $,  $ \rho=\frac{r}{2a_{0}} $

 $$ R_{20}(r)=\frac{c_{0}}{r}(1-\frac{r}{2a_{0}})\frac{r}{2a_{0}}e^{-\frac{r}{2a_{0}}}=\frac{c_{0}}{2a_{0}}(1-\frac{r}{2a_{0}})e^{-\frac{r}{2a_{0}}} $$ 