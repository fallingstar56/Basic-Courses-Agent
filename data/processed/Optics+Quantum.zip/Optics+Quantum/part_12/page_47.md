Here is how:

The addition of two s orbitals (l=0) could only give total L=0 (M=0); the addition of two spin=1/2 will be a bit complicated, it can give total spin S=1, and thus  $ S_{z}=1,0,-1 $; it can also give a total S=0 ( $ S_{z}=0 $). The results of eigenfunction of L and S given as combination of eigenfunction of individual angular momentum are (all the paragraph and (13-13 to 13-15) are given without proof):

Orbital part: L = 0 (M = 0) → φ1s (1) φ2s (2)

Spin Part:

 $$ S=1\begin{cases}S_{z}=1\rightarrow\alpha(1)\alpha(2)\\S_{z}=0\rightarrow\frac{1}{\sqrt{2}}[\alpha(1)\beta(2)+\alpha(2)\beta(1)]\\S_{z}=-1\rightarrow\beta(1)\beta(2)\end{cases} $$ 

 $$ S=0\rightarrow\frac{1}{\sqrt{2}}[\alpha(1)\beta(2)-\alpha(2)\beta(1)] $$ 

The complete state with certain L, M, S,  $ S_{z} $ will be tensor product of

above so far. For example:

 $$ |L=0,M=0,S=1,S_{z}=1\geq\phi_{1s}(1)\phi_{2s}(2)\alpha(1)\alpha(2) $$ 

However, we have to be aware that the permutation symmetry have not been considered yet above, and the wave function (13-16) though it is an eigenfunction with unique angular momentum, obviously does not fit the antisymmetry requirement. There is extra exchange degeneracy, the  $ \phi_{1s}(2)\phi_{2s}(1) $ is also the eigenfunction of L=0. We can find out the symmetry adapted wave functions from above results