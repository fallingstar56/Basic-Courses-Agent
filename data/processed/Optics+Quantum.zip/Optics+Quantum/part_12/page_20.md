coupling), the energy degeneracy on l will be removed. The energy

degeneracy on m is related to the isotropic space and thus more

persistent, only by applying external field (say a magnetic field along

z direction) will remove the degeneracy (by saying remove of

degeneracy, I mean the energy will depend on that quantum number).

We finally finished calculation for electron in hydrogen atom, the simplest atomic structure in physics and chemistry, and unfortunately the only possible rigorous solution we can get (besides other hydrogen-like ions which only has one electron, but Z charged nucleus). In going to multielectron atoms (Helium and beyond), there will be extra term in Hamiltonian due to mutual repulsion among electrons, which make the rigorous analytic solution impossible, approximation method (variation or perturbation) has to be used.

Now back to the summary of hydrogen atom, the most important parts for this course are: we have computed energy and wave functions by solving the S-equation, and in the due process quantum numbers n, l, m appear. These numbers let us fix the energy and the wave functions, so the state can be specified $ ^{80} $ as  $ |n,l,m\rangle $. The relations between these numbers (12-110) were also derived.

(5) Including the spin for electron