equations. First let's talk about solutions of (12-80) called angular part (this is also because the solution is the eigenfunction for the angular momentum).

(3) Angular part solution and quantum number L and m

(12-80) still have two variables $(\theta,\phi)$; we need further separation of variables by guessing:

 $$ Y(\theta,\phi)=\Theta(\theta)\Phi(\phi) $$ 

After insertion, (12-80) becomes:

 $$ \frac{1}{\Theta}[\sin\theta\frac{d}{d\theta}(\sin\theta\frac{d\Theta}{d\theta})]+l(l+1)\sin^{2}\theta=-\frac{1}{\Phi}\frac{d^{2}\Phi}{d\phi^{2}} $$ 

Since the two sides depend on different variables, each has to be equal to some constant, and let's designate it as  $ m^{2} $ (m is some complex number like l, still undetermined). Then the  $ \Phi(\phi) $'s general form can be solved easily:

 $$ -\frac{1}{\Phi}\frac{d^{2}\Phi}{d\phi^{2}}=m^{2}\rightarrow\frac{d^{2}\Phi}{d\phi^{2}}+m^{2}\Phi=0 $$ 

Thus the general form of  $ \Phi(\phi) $ is:

 $$ \Phi(\phi)=e^{i m\phi} $$ 

(the -m can be absorbed by allow m both negative and positive, and coefficient in front will be fixed by normalization)

Next we shall use boundary condition to determine m by requiring

after  $ 2\pi $ change of  $ \phi $, the wave function be back to itself: