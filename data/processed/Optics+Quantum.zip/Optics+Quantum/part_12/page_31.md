Of course, in a specific spatial representation  $ \langle r|A,L\rangle $ will be a wave packet with group velocity  $ V_A $ from left to right;  $ \langle r|B,R\rangle $ will be a wave packet with group velocity  $ V_B $ from right to left. The  $ |A,L;B,R\rangle $ will be a tensor product of  $ |A,L\rangle $ and  $ |B,R\rangle $. The more general way to express the Ket for these two particles would be  $ |A,\varepsilon_A;B,\varepsilon_B\rangle $, with  $ \varepsilon_A,\varepsilon_B $ (such as position, spin state etc.) to specify the state that A and B are. The key is that this tensor product expression of state (13-1) uniquely specifies the state for the non-identical particles.

The two particles will approach each other and collide. The state after collision is related to the initial state by:

 $$ \left|\psi_{_{AB}}>={\hat{O}}\right|\psi_{_{AB}}>_{i} $$ 

The $O$ stands for the operator representing the interaction between particles during the collision (it may involve time evolution propagator, such details is not needed for our purpose), and $|\psi_{AB}>$ is the product state.

To get the probability of D1 detecting either A or B, the product state

 $ |\psi_{AB}> $ needs to be expanded onto basis by eigenstates of the

detection:  $ |A,\theta_{A};B,\theta_{B}> $. This means after collision, particle A will go

into direction  $ \theta_{A} $ and B into  $ \theta_{B} $. In our center of mass frame,

 $ \theta_{B}=\pi-\theta_{A} $ due to conservation of momentum.

 $$ |\psi_{_{AB}}>=\sum...+f(\theta)\left|A,\theta;B,\pi-\theta>+f(\pi-\theta)\right|A,\pi-\theta;B,\theta>+... $$ 

... in the equation means the particles may be scattered into other