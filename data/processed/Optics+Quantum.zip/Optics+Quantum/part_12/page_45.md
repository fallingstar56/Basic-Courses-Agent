addition of angular momentum.Since we have not formally discussed

angular momentum in quantum, leave alone their additions. I shall

only give the result without proof on this addition of angular

momentum issue.

Each electron has orbital angular momentum and spin, with wave

functions associated to them. Now we have two electrons, it turns out

the good quantum number (the one from the operators commuting

with Hamiltonian) comes from the total orbital angular momentum:

 $ \widehat{L} = \widehat{l}_{1} + \widehat{l}_{2} $ and total spin:  $ \widehat{S} = \widehat{S}_{1} + \widehat{S}_{2} $ (we neglect spin-orbit coupling).

Knowing the eigenfuctions of the individual angular momentum, we

can find out the eigenfunction of the total angular momentum (it is

essentially a base transformation and the matrix elements related to

them are Clebsch-Gordan coefficients) $ ^{89} $.

The  $ \phi_{ls}(1)\phi_{ls}(2) $ is the eigenfunction with total orbital angular momentum  $ L=0 $ (M=0 too then); and  $ \frac{1}{\sqrt{2}}[\alpha(1)\beta(2)-\beta(1)\alpha(2)] $ is the eigenfunction with total spin  $ S=0 $ ( $ S_{z}=0 $ too). The atomic symbol for such state is:

 $ ^{2S+1}L $ (and historically people use S for L=0,P for L=1, D for L=2...)

The 2S+1 is called multiplets, and if 2S+1=1, it is called siglet; if it is

3, triplets... So for the ground state Helium, the wave function is

(13-11) and the symbol is:  $ ^{1}S $