<div style="text-align: center;"><img src="imgs/img_in_image_box_231_165_1022_703.jpg" alt="Image" width="66%" /></div>


<div style="text-align: center;"> $ (3,1,0) $</div>


<div style="text-align: center;"> $ (4, 1, 0) $</div>


<div style="text-align: center;"> $ (4,0,0) $</div>


<div style="text-align: center;"> $ (4,2,0) $</div>


<div style="text-align: center;"> $ (4,3,0) $</div>


<div style="text-align: center;">I probably should mention that there is another often used label for quantum number for historical reason. People use letters s,p,d,f....to represent $l=0,1,2,3\ldots$ (fortunately we do not encounter too high angular momentum and do not run out of letters), so in this terminology, $|211>\mathrm{is}$ called $2p_{1},|430>\mathrm{is}$ $4f_{0}$. Chemists also likes to use linear combinations of states with same $n$, $l$ but different $m$ (since these states have same energy, combination of them is also eigenstates of the energy), to have $p$ orbitals along $x,y,z$ direction, such as $2p_{x},2p_{y}$ (both are linear combination of $2p_{1},2p_{-1})^{77}$, and $2p_{z}$ (which is $2p_{0}$); the combination of different $m$ states with $l=2$ will result in so called $d_{z^{2}},d_{x^{2}-y^{2}},d_{xz},d_{yz},d_{xy}$ orbitals. There are also other linear combinations used by chemists in explaining the bonding of</div>
