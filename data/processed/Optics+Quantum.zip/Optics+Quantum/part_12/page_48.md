(13-13 to 13-16). This can be done in two ways.

First method: we notice the spin part (13-14) for S=1 are symmetric with permutation, so that if the total wave function need to be antisymmetric, the orbital part has to be antisymmetric, and it can be antisymmetrize to:  $ \frac{1}{\sqrt{2}}[\phi_{1s}(1)\phi_{2s}(2) - \phi_{1s}(2)\phi_{2s}(1)] $. Thus, the correct forms (symmetry adapted eigenfunctions of angular momentum for 2 electrons)  $ |L,M,S,S_z> $ are (these are the states for atomic symbol  $ ^3S $):

 $$ \begin{aligned}&|0,0,1,1>=\frac{1}{\sqrt{2}}[\phi_{1s}(1)\phi_{2s}(2)-\phi_{1s}(2)\phi_{2s}(1)]\alpha(1)\alpha(2)\\&|0,0,1,-1>=\frac{1}{\sqrt{2}}[\phi_{1s}(1)\phi_{2s}(2)-\phi_{1s}(2)\phi_{2s}(1)]\beta(1)\beta(2)\\&|0,0,1,0>=\frac{1}{2}[\phi_{1s}(1)\phi_{2s}(2)-\phi_{1s}(2)\phi_{2s}(1)][\alpha(1)\beta(2)+\alpha(2)\beta(1)]\\ \end{aligned} $$ 

For the S=0 state, the spin part is antisymmetric, then the orbital part has to be symmetric (this is the state for atomic symbol  $ 2^{1}S $, since the ground state is also a  $ ^{1}S $, that is why this one has 2 in front of it):

 $$ |0,0,0,0>=\frac{1}{\sqrt{2}}\phi_{1s}(1)\phi_{2s}(2)[\alpha(1)\beta(2)-\alpha(2)\beta(1)] $$ 

Second method: we can start from (13-16) which does not have particular symmetric property, but we can project out the antisymmetric part $ ^{90} $:

 $$ |\psi>=\sum_{i}<D_{i}|\psi>|D_{i}> $$ 