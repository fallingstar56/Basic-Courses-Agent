of spherical harmonics, then the complete wave function  $ \psi(r,\theta,\phi)=R_{nl}(r)Y_{l}^{m}(\theta,\phi) $ will be normalized over space. Note, since the form of  $ \mathrm{R}(\mathrm{r}) $ will clearly depend on the quantum number n and l, it is natural to use symbol  $ R_{nl}(r) $. You see that the total wave function will depend on the quantum numbers n, l, m.

We have seen the restrictions between $l$ and $m$ in (12-90); the definition on $n$ in (12-102) put extra restriction between $n$, $l$. Since the $j_0$ is non-negative integer, the biggest $l$ for a given $n$, could be $n-1$.

Thus the complete restriction among n, l, m are:

 $ n=1,2,3\ldots $

 $ l=n-1,n-2,\ldots,0 $ (n possible value for given n) (12-110)

 $ m=l,l-1,\ldots,-l $  $ (2l+1\text{ possible value for given }l) $

The wave functions will be determined by these quantum numbers (as we shall explicitly demonstrate below). The n is called principal quantum number, because it determines the energy; the l is called orbital (short for orbital angular momentum) quantum number, because it fixes the magnitude of orbital angular momentum; m is called magnetic quantum number, it fixes the directional component of angular momentum, and will cause energy shift when interacting with external magnetic field (Zeeman effect).

The wave functions corresponding to these quantum numbers are expressed as (in Dirac’s notation and space wave function):

 $$ |n,l,m>\quad\xrightarrow{in space representation}\quad\psi_{nlm}(r,\theta,\phi) $$ 