 $$ \Phi(\phi+2\pi)=\Phi(\phi)\qquad(12-84)^{76} $$ 

Then  $ e^{im2\pi}=1 $, meaning:

 $$ m=0,\pm1,\pm2\ldots $$ 

For the  $ \theta $ part:

 $$ \frac{1}{\Theta}[\sin\theta\frac{d}{d\theta}(\sin\theta\frac{d\Theta}{d\theta})]+l(l+1)\sin^{2}\theta=m^{2} $$ 

Both function and quantum number $l$ need to be determined. In the following only the solutions are provided with details neglected. The (12-80) (as well as the 12-82 and 12-86 which come out of 12-80) is actually the eigenvalue problem for orbital angular momentum, and the treatment with “ladder” operator (constructing creator $L_{+}$ and annihilator $L_{-}$, analogous to the operator method in harmonic oscillator) is best to deal with the eigenvalue and eigen function problem in angular momentum. There the restriction on the quantum number $l$, $m$ can be derived more clearly; the wave functions can be worked out by using the property of the creator or annihilator with simpler differential equations. Since we have not talked about formal definition of angular momentum in quantum, this treatment is thus out of the hand at present. Most textbooks have the details on the topic, such as Shankar’s Chap. 12, or Cohen-Tannoudji et al’s Chap. 6. For