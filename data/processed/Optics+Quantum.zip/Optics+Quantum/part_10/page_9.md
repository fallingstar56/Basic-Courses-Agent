The above figure (taken from Cohen-Tannoudji's book, vol.1 p388) shows a typical setup of Stern-Gerlach experiment. The electrons $ ^{42} $ will pass a non-uniform magnetic field (here in the figure, the B field has large gradient along the Z direction, which is arbitrarily chosen in the lab, interact with the magnetic field and then detected by the electron detectors at the screen P.

The interaction between the electron and the magnetic field is given by (Below is basically classical argument, and quantum will kick in by introducing spin as angular momentum and its eigenvalues determined by quantum mechanics):

 $$ W=-\mu\bullet B $$ 

Where W is the interaction energy,  $ \mu $ is the magnetic moment of the electron and B is the magnetic field. We have seen the  $ \mu $ is related to the angular momentum of the particle, but now the angular momentum is not orbital (we purposely set electron does not have L, see footnote above), it is the spin instead:

 $$ \vec{\mu}=g_{s}\vec{S} $$ 

 $$ (11-30)^{43} $$ 

where  $ \vec{S} $ is the spin and  $ g_{s} $ is a constant called gyromagnetic ratio for