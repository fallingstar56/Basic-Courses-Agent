 $$ |\psi,t>=\int\varphi(p)e^{-i\frac{E_{p}}{\hbar}t}\mid p> $$ 

In the X representation, it is:

 $$ \psi(x,t)=<x\mid\psi,t>=\frac{1}{\sqrt{2\pi\hbar}}\int\varphi(p)e^{i(\frac{p}{\hbar}x-\frac{E_{p}}{\hbar}t)}dp=\frac{1}{\sqrt{2\pi}}\int g(k)e^{i(kx-\omega t)}dk $$ 

(11-62)

 $ g(k) = \varphi(p)\sqrt{\hbar} $ and it is the Fourier Transform of wave function at time 0  $ \psi(x,0) $.

So if we know the wave function at certain time (that time can be set as 0), then we can find its Fourier transform g(k), adding the time evolution phase  $ e^{-i\omega t} $, using the above relation to get the wave function at later time. This strategy is better illustrated with an explicit example: The propagation of a Gaussian wave packet.

Example: The initial wave function is a Gaussian:

 $$ \psi(x,0)=e^{-\frac{x^{2}}{\sigma^{2}}}e^{i k_{0}x} $$ 

(a) The state given is not proper due to the normalization is not 1, so first I need to make it proper by:

 $$ \int\psi^{*}\psi dx=\int e^{-\frac{2x^{2}}{\sigma^{2}}}dx $$ 

Use the integration table (or calculate it with complex variable):

 $$ \int e^{-\alpha^{2}(\xi+\beta)^{2}}d\xi=\frac{\sqrt{\pi}}{\alpha} $$ 

In the normalization integral,  $ \alpha^{2} = \frac{2}{\sigma^{2}} $