on  $ |\psi> $ in  $ |x> $ basis can also be determined:

 $$ <x\mid\hat{A}\mid\psi>=\int<x\mid\hat{A}\mid x^{\prime}><x^{\prime}\mid\psi>dx^{\prime} $$ 

(above can also be seen as matrix product, similar to  $ d_i = \sum_{j} A_{ij} c_j $)

<x| $ \widehat{A} $|x' > is the matrix element in the |x> basis (similar to the A_{ij} in the discrete basis, but here we have a continuous basis), it can be evaluated knowing the <a|x>:

 $$ <x\mid\widehat{A}\mid x^{\prime}>=\sum_{i,j}<x\mid a_{i}><a_{i}\mid\widehat{A}\mid a_{j}><a_{j}\mid x^{\prime}> $$ 

The matrix form of A in its eigenbasis is diagonal with eigenvalues along diagonal, and relations  $ \langle a | x \rangle $ would certainly allow us to get A's matrix form in  $ |x\rangle $ basis (of course above relation is just the similarity transform of matrices)

(2) Momentum operator and momentum (p) representation

The momentum operator and its eigenstate can be expressed as:

 $$ \hat{p}\mid p>=p\mid p>\quad(11-47) $$ 

This is just a restatement of definition of eigenstate. The important (and interesting) point is what this representation related to that of position? If we know the position representation, can we find out the momentum representation and vice versa? If not the QM would be hopelessly complicated and almost useless, since we need to express the abstract state vector onto some basis, and if no relations between basis, then knowing the expression in one basis cannot allow us to