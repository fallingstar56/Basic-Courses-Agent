choose the X direction which would make  $ \theta_{+}=0 $. In such convention,

the final expression for  $ |+x\rangle $,  $ |-x\rangle $,  $ |+y\rangle $,  $ |-y\rangle $ are:

 $$ \begin{aligned}&|+x\geq\frac{\sqrt{2}}{2}|+z>+\frac{\sqrt{2}}{2}|-z>\\&|-x\geq\frac{\sqrt{2}}{2}|+z>-\frac{\sqrt{2}}{2}|-z>\\&|+y\geq\frac{\sqrt{2}}{2}|+z>+\frac{\sqrt{2}}{2}i|-z>\\&|-y\geq\frac{\sqrt{2}}{2}|+z>-\frac{\sqrt{2}}{2}i|-z>\end{aligned} $$ 

(so  $ |+z\rangle $,  $ |-z\rangle $ is like H-V basis;  $ |+x\rangle $,  $ |-x\rangle $ is like 45—(-45) basis;  $ |+y\rangle $,  $ |-y\rangle $ is like circular basis in polarization)

3. With the knowledge of basis vectors, determination of  $ S_x $,  $ S_y $ in the  $ |+z\rangle $,  $ |-z\rangle $ basis would be easy. (I listed 3 ways to find matrix form above, you may use either)

 $ S_x = \frac{\hbar}{2} \begin{pmatrix} 0 & 1 \\ 1 & 0 \end{pmatrix} $; and  $ S_y = \frac{\hbar}{2} \begin{pmatrix} 0 & -i \\ i & 0 \end{pmatrix} $

So knowing the input state  $ |\varphi \geq a| + z > +b| - z > $, the measurement results of  $ S_{z}, S_{x} $ and  $ S_{y} $ can be easily predicted using the postulate 3 of Q.M. (the probability of detected eigenvalues)

Actually the  $ S_{x}, S_{y}, S_{z} $ and the identity matrix I would form a complete basis for any measurement in 2-D space. (The matrix has 4 elements, so it is a 4-dimensional space, and the 4 matrix above form a basis)