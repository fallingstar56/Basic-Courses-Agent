 $ |p> $ basis, we can find the expression of  $ <x|p> $ from the above definition of momentum operator in  $ |x> $ basis:

 $$ \begin{aligned}&\hat{P}\mid p>=p\mid p>\stackrel{|x>basis}{\rightarrow}<x\mid\hat{P}\mid p>=p<x\mid p>\\&-i\hbar\frac{d<x\mid p>}{dx}=p<x\mid p>\end{aligned} $$ 

Let  $  p(x) = \langle x \mid p \rangle  $ (wave function of momentum)

 $$ -i\hbar\frac{dp(x)}{dx}=pp(x) $$ 

 $$ p(x)=e^{i\frac{p}{\hbar}x} $$ 

The wave function  $ \langle x|p\rangle $ is in a standard from of harmonic oscillation! Using our convention, we can define wave vector (in 1-D just a number):

 $$ \frac{p}{\hbar}=k=\frac{2\pi}{\lambda}\rightarrow p=\frac{h}{\lambda} $$ 

This is the de-Broglie relation.

## (d) Proper wave function of p(x)

The wave function  $ p(x) $ we get is not properly normalized. The  $ |p\rangle $s just like  $ |x\rangle $s form a continuous basis, and in analogy to the  $ |x\rangle $ basis, we would like to have orthonormal condition:

 $$ <p^{\prime}|p>=\delta(p-p^{\prime}) $$ 

We can use the above p(x) to calculate the  $ \langle p' | p \rangle $ to see what we get:

 $$ <p^{\prime}|p>=\int<p^{\prime}|x><x|p>d x=\int e^{\frac{i\frac{(p-p^{\prime})}{\hbar}x}{}}d x $$ 