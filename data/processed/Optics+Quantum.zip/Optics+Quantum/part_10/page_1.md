when the photon detected by D1 only comes from electron passing hole1, thus you only collect the electrons passing through hole1. The result will not have interference but a single hole diffraction. (Feynman, fig.3-4 (a))

<div style="text-align: center;"><img src="imgs/img_in_image_box_281_425_572_681.jpg" alt="Image" width="24%" /></div>


In case of $b=a$, or $C=A$. Then the interference pattern is observed.

(fig.3-4(b)) Here electrons passing hole 1 and 2 have equal probability scattering the photon into detector D1, so recording photons reveals nothing about which way the electron path is. (You do still have electron-photon interaction, this is reflected in the expansion that after the scattering, the electron state changes from |1>,|2> into |\psi_e>. The electron passing 1 or 2 will subject to the same perturbation and thus the phase perturbation cancels)

Similar results for the electron hitting X, and photon goes to D2:

$P_{(X,\theta_e)} = |\langle \gamma_\theta, | \langle X | S \rangle | \gamma_l \rangle^2 = |B + D|^2$

(2) What happens if both D1 and D2 are placed.

You recorded the electrons whenever either D1 or D2 register a photon count. As state above, this is a single electron experiment,