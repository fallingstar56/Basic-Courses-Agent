 $$ \begin{aligned}\left|S>\right|\gamma_{_{l}}>=...+<1\left|S>\right|1>|\gamma_{_{l}}>+<2\left|S>\right|2>|\gamma_{_{l}}>+...\\=&...+<1\left|S>a\right|\psi_{_{e}}>|\gamma_{_{\theta_{1}}}>+<1\left|S>b\right|\psi_{_{e}}^{^{\prime}}>|\gamma_{_{\theta_{2}}}>\\&+<2\left|S>b\right|\psi_{_{e}}>|\gamma_{_{\theta_{1}}}>+<2\left|S>a\right|\psi_{_{e}}^{^{\prime}}>|\gamma_{_{\theta_{2}}}>+...\\=&...+<1|S>a<X\left|\psi_{_{e}}>|X>\right|\gamma_{_{\theta_{1}}}>+<1\left|S>b<X\right|\psi_{_{e}}^{^{\prime}}>|X>|\gamma_{_{\theta_{2}}}>\\&+<2\left|S>b<X\right|\psi_{_{e}}>|X>|\gamma_{_{\theta_{1}}}>+<2\left|S>a<X\right|\psi_{_{e}}^{^{\prime}}>|X>|\gamma_{_{\theta_{2}}}>+...\\=&...+A\left|X>\right|\gamma_{_{\theta_{1}}}>+B\left|X>\right|\gamma_{_{\theta_{2}}}>+C\left|X>\right|\gamma_{_{\theta_{1}}}>+D\left|X>\right|\gamma_{_{\theta_{2}}}>+...\\=&...+(A+C)\left|X>\right|\gamma_{_{\theta_{1}}}>+(B+D)\left|X>\right|\gamma_{_{\theta_{2}}}>+...\\\end{aligned} $$ 

Now we have expanded the initial state into basis of the eigenstates of the observable, then the probabilities in the measurement can be derived from this with postulate 3.

(1) Only detect photon at D1 (i.e. no D2) and measure electron at X (the only projection here is  $ |X| > |\gamma_{\theta_1}| $). Then the probability of this detection result is:

 $$ P_{(X,\theta_{1})}=|\langle\gamma_{\theta_{1}}|<\boldsymbol{X}|\boldsymbol{S}>\mid\gamma_{l}>\mid^{2}=<\gamma_{l}|<\boldsymbol{S}|\hat{\boldsymbol{P}}_{X,\theta_{1}}|\boldsymbol{S}>\mid\gamma_{l}> $$ 

 $$ \hat{P}_{X,\theta_{1}}\equiv\left|X>\right|\gamma_{\theta_{1}}><\gamma_{\theta_{1}}\left|<X\right|\text{a projection operator} $$ 

Use the orthonormal conditions of the eigenstates:

 $$ <\gamma_{\theta_{j}}\mid\gamma_{\theta_{i}}>=\delta_{ij};<X_{j}\mid X_{i}>=\delta_{ij}^{41} $$ 

 $ P_{(X,\theta_1)} = |A + C|^2 $ equivalent to that in Feynman's. It is the probability amplitude summation and then squared.

If say $b=0$ (i.e. the electron passing hole2 will not scatter the photon to D1), then $C=0$. The result would be only $|A|^{2}$. This is