<div style="text-align: center;"><img src="imgs/img_in_image_box_249_153_443_380.jpg" alt="Image" width="16%" /></div>


For example, if the magnetic field is along the u direction as shown above, the measurement would correspond to  $ S_{u} $. The matrix expression for it under certain basis for  $ S_{u} $ can be easily worked out with  $ S_{x} $,  $ S_{y} $ and  $ S_{z} $.

 $$ S_{u}=\sin\theta\cos\varphi(S_{x})+\sin\theta\sin\varphi(S_{y})e+\cos\theta(S_{z})=\frac{\hbar}{2}\left(\begin{aligned}&\cos\theta&\sin\theta\mathrm{e}^{-i\varphi}\\&\sin\theta e^{i\varphi}&-\cos\theta\end{aligned}\right) $$ 

With this you can work out the results of a given state subjected to the  $ S_{u} $ measurement $ ^{45} $.

Example4: Expression of state vector in position and momentum representation and particle in free space.

This is the example that will illustrate what we had talked about the postulates of QM. I will use the postulates to solve quantitatively a simple system: Particle in free space. (This is a typical example in standard QM course. I tried to avoid spoiling your fun when you take the