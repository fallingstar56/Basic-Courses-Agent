 $ |+z>, |-z> $ is a suitable basis, so does  $ |+x>, |-x> $ pair and etc. You can imagine many other basis formed by eigenstates of spins measured along different directions. (This is really like the cases in the polarization state of light)

The question now is from the above experimental results, how we construct a description in math? All the operators (S_z, S_x or S_y) and states (|+z>, |-z>, |+x>...) are abstract Dirac notations. The appearance of their mathematical expressions depends on the choice of basis.

I shall work out in the following by using the ‘stupid’ method (no math tricks) to show you the detailed forms (in matrix) of the expressions of the operator and basis. Knowing this would enable you to work out the quantum predictions given any input state. (This is very much like the polarization state of light. Knowing the basis and matrix forms of optical elements, given the input, you can work out the polarization state of the output)

I will first choose a basis.  $ |+z> $ and  $ |-z> $. They form an orthonormal basis set in this 2-D space. Then I will work out the expressions of  $ S_z $,  $ S_x $,  $ S_y $ and their eigenstates on this basis.

1. The simple case for  $ S_z $ and  $ |+z\rangle $,  $ |-z\rangle $:

The matrix forms for them are obvious.

 $$ \left|+z\right\rangle=\begin{bmatrix}1\\ 0\end{bmatrix},\left|-z\right\rangle=\begin{bmatrix}0\\ 1\end{bmatrix} $$ 