from the postulates of Q.M and probability theory (i.e. probability

of OR events)

Actually the fact we detect photons at D1 or D2 is just to let us

select a part of electrons for observation. If the scattered photons

can only go into  $ \theta_{1} $ or  $ \theta_{2} $ two directions (of course an

idealization), then whether we detect the photon or not will not

affect the electron pattern, since it is the interaction between the

electron and photon that determines the interference pattern, the

interaction is always there independent of the detection of photon.

 $$ |X>|\gamma_{\theta_{1}}><\gamma_{\theta_{1}}|<X|+|X>|\gamma_{\theta_{2}}><\gamma_{\theta_{2}}|<X| $$ 

 $$ \begin{aligned}=\mid X>(\mid\gamma_{\theta_{1}}><\gamma_{\theta_{1}}\mid+\mid\gamma_{\theta_{2}}><\gamma_{\theta_{2}})\mid)<X\mid=\mid X>I<X\mid=\mid X><X\mid\end{aligned} $$ 

Here we assume only two directions for photon, so

 $ |\gamma_{\theta_{1}}><\gamma_{\theta_{1}}|+|\gamma_{\theta_{2}}><\gamma_{\theta_{2}}|=I $

In the more realistic model, where photon can take many directions (a continuous distribution in fact), we still ‘digitize’ them into many discrete directions for simplicity.

If we do not detect the photon and only measure the electron's distribution after its interaction with the photon, this is equivalent to place many 'virtual' photo-detectors at all possible angles, and record the electron distribution whenever one of the 'virtual' photo-detectors register a count. Here we arrange the experimental condition so that whenever an electron passes the light zone, one and only one photon will be deflected. We neglect other processes