QM course, but I cannot help showing you this though you probably will learn it again next semester because not only this will act as concrete an example for the postulates, but also showing you what we have learned previously about waves will be useful in QM)

I shall talk about following subjects in this example:

(1) Position (x) representation of state vector---wave function  $ \psi(x) $

(2)Momentum operator and momentum (p) representation of state vector

(3)Particle in free space

The first 2 topics are about how we describe the state of our system; the last is a simple case of state evolution. (A review on my supplementary on matrix representation of vector and Dirac notation would be helpful)

## (1) Position (x) representation

The state vector  $ |\psi\rangle $ will be expressed as combination (projection) of eigenstates of position  $ |x\rangle $, i.e. if the particle is in  $ |x\rangle $ we know its position is x. If I use  $ \hat{X} $ as symbol for position observable:

 $$ \hat{X}\mid x>=x\mid x> $$ 

The  $ |x> $ form a complete orthonormal basis:

 $ \begin{array}{l} <x^{\prime} | x \> = \delta(x - x^{\prime}) \quad (11-39) $ (orthonormal condition for continuous basis)

 $$ \int\left|x><x\right|dx=I $$ 

(11-40) (completeness of basis)

For any state |ψ > to be expressed in this |x> basis:

 $$ \left|\psi\right\rangle=I\left|\psi\right\rangle=\int\left|x^{\prime}\right\rangle\left\langle x^{\prime}\right|\psi\left\langle d x^{\prime}\right\rangle=\int\left\langle x^{\prime}\right|\psi\left\langle\right|x^{\prime}\left\langle d x^{\prime}\right| $$ 