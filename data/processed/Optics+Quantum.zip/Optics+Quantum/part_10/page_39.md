particles property and its time evolution are completely determined.

In microscopic world, due to wave-particle duality and Uncertainty

Relations, the above classical description is no longer valid. The

results of measurements will be probabilistic in the general cases. i.e.

given a particle, we measure its physical property, we find that we will

get some values ( $ \lambda_{i} $) with some probability, expressed in terms of

probability amplitude ( $ a_{i} $),  $ |a_{i}|^{2} $ is the probability to get  $ \lambda_{i} $ in the

measurement. (of course, we have to prepare many particles in the

same state, and repeat measurements on these )

From these measurements we have a description of the physical system (the state of the particle under study in this case). This is a very reasonable and sound way to describe a system. So we shall characterize the state of a system by giving probability amplitude to the possible outcomes of measurement. i.e.

 $$ |\psi>=(a_{1}(\lambda_{1}),a_{2}(\lambda_{2}),a_{3}(\lambda_{3}).....) $$ 

Where  $ |\psi> $ is just a symbol to represent the physical state;  $ a_{i}(\lambda_{i}) $ is the probability amplitude to get the physical measurement result  $ \lambda_{i} $ has to be real number because it is a measured value,  $ a_{i}(\lambda_{i}) $ is generally a complex number because only requirement is that its square to be real. $ ^{50} $