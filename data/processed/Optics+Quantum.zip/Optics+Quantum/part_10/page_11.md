isotropic). For the electrons (or atoms) coming out of the furnace, its

angular momentum’s direction is random in space, so the projection along

z-direction would be continuously, i.e.  $ S_{z} = S \cos \theta, (0 \leq \theta \leq \pi) $ from the

classical picture. So the distribution on the detection screen would also be

continuous. The results of Stern-Gerlach (SG) experiment are totally

surprising. The electrons are concentrated in two spots with equal

probability on the screen. (see figure below)

<div style="text-align: center;"><img src="imgs/img_in_image_box_226_593_389_955.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;">FIGURE 3</div>


<div style="text-align: center;">Spots observed on the plate $P$ in the Stern-Gerlach experiment. The magnetic moments $\mathbf{M}$ of the atoms emitted from the furnace $E$ are distributed randomly in all directions of space, so classical mechanics predicts that a measurement of $\mathbf{M}_{z}$ can yield with equal probability all values included between $+|\mathbf{M}|$ and $-|\mathbf{M}|$. One should therefore observe only one spot (dashed lines in the figure). In reality, the result of the experiment is completely different: two spots, centered at $N_{1}$ and $N_{2}$, are observed. This means that a measurement of $\mathbf{M}_{z}$ can yield only two possible results (quantization of the measurement result).</div>


The SG’s result demonstrated not only the electron has spin but more, it also shows what we call the quantization of the projection of angular moment along certain direction. In the microscopic world, quantum theory will show not only the angular momentum is quantized, but also its directional projection!⁴⁴ To understand the quantization of angular momentum and its directional components, you have to study the quantum mechanical treatment on angular momentum which is not my