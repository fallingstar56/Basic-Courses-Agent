 $$ |\psi(x,0)|^{2}\propto e^{-2\frac{x^{2}}{a^{2}}}\rightarrow\Delta x=\sigma/2 $$ 

 $$ |g(k)|^{2}\propto e^{-\frac{(k-k_{0})^{2}\sigma^{2}}{2}}\rightarrow\Delta k=1/\sigma $$ 

 $$ \Delta x\Delta k=\frac{1}{2}\stackrel{49}{\quad} $$ 

 $$ p=\hbar k\rightarrow\Delta x\Delta p=\hbar/2 $$ 

So for Gauss wave function, the uncertainty meets the lower limit.

(c) The time evolution of the wave function

Now we can evaluate the  $ \psi(x,t) $ from its initial form, using relation (11-51) above:

 $$ \psi(x,t)=\frac{1}{\sqrt{2\pi}}\int g(k)e^{i(kx-\omega t)}dk,\quad\omega=\frac{\hbar k^{2}}{2m} $$ 

Throw in the g(k), and calculate the monster integral:

 $$ \begin{aligned}\psi(x,t)=&\frac{1}{\sqrt{2\pi}}(2\pi)^{-\frac{1}{4}}\sigma^{\frac{1}{2}}\int e^{-\frac{\sigma^{2}}{4}(k-k_{0})^{2}}e^{i(kx-\frac{\hbar k^{2}}{2m}t)}d k\\=&(\frac{2\sigma^{2}}{\pi})^{\frac{1}{4}}\frac{e^{i(k_{0}x+\varphi_{0})}\equiv}{(\sigma^{4}+4\hbar^{2}t^{2}\bigg/m^{2})^{\frac{1}{4}}}\exp[-\frac{(x-\frac{\hbar k_{0}}{m}t)^{2}}{\sigma^{2}+i2\hbar t}]\\ \end{aligned} $$ 

 $$ |\psi(x,t)|^{2}=\sqrt{\frac{2\sigma^{2}}{\pi}}\frac{1}{\sigma^{2}(1+4\hbar^{2}t^{2}/\sigma^{4}m^{2})^{\frac{1}{2}}}\exp[-\frac{2\sigma^{2}(x-\frac{\hbar k_{0}t}{m})^{2}}{\sigma^{4}+4\hbar^{2}t^{2}/m^{2}}] $$ 

Let’s focus only on the time dependent part in this monster.

i. The amplitude of the wave function or its square drops as time increases. The total probability is still normalized