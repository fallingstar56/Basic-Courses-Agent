 $$ S_{z}=\frac{\hbar}{2}\binom{1\ 0}{0\ -1} $$ 

If you do not understand how I get  $ S_{z} $ expression. Try the systematic method I discussed in the class to get expression of operators in certain basis:

 $$ S_{z}\mid+z>=\frac{\hbar}{2}\mid+z>=\frac{\hbar}{2}\begin{bmatrix}1\\ 0\end{bmatrix}\quad\leftarrow first column in 2x2S_{z} matrix $$ 

a.

 $$ S_{z}\mid-z>=-{\frac{\hbar}{2}}\mid-z>={\frac{\hbar}{2}}{\left[\begin{array}{l}0\\ -1\end{array}\right]}\leftarrow\mathrm{s e c o n d~c o l u m n~i n~}2\mathrm{x}2\mathrm{~S}_{z}\mathrm{~m a t r i x} $$ 

b.  $ <+z|S_z|+z>=\hbar/2 $  $ \leftarrow $ gives the  $ S_{11} $ matrix element ...

c.  $  S_z = \frac{\hbar}{2} | +z \rangle + z \langle +z | +(-\frac{\hbar}{2}) | -z \rangle \langle -z |  $ the rest is simple matrix multiplication.

2. How about the  $ S_x $ and  $ |+x\rangle $,  $ |-x\rangle $ expression in basis of  $ |+z\rangle $ and  $ |-z\rangle $?

In  $ |+x\rangle $,  $ |-x\rangle $ basis, the answer would be simple, same as above

actually. However, in  $ |+z\rangle $,  $ |-z\rangle $ basis, their forms are not obvious (at

least to me). The problem is basically a transform of basis! As we

discussed in the polarization case, the key is to find the relation

between the basis, i.e. the expression of  $ |+x\rangle $,  $ |-x\rangle $ in terms of  $ |+z\rangle $ and

 $ |-z\rangle $, then everything else would be straightforward. We need to find:

 $$ \begin{aligned}&|+x>=c_{++}\mid+z>+c_{+-}\mid-z>\\&|-x>=c_{-+}\mid+z>+c_{--}\mid-z>\end{aligned} $$ 

The 4 coefficients need to be determined. Since each c is a complex number in general, so there are actually 8 unknowns in total.  $ c_{++} = |c_{++}| e^{i\theta_{+}} \ldots $ both the module and the phase need to be determined. However, we know that for a given state, there is an arbitrary total