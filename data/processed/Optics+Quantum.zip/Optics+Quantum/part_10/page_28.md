the position basis, the effect is equivalent to a space differentiation and  $ -ih $ as some sort of proportional constant. You may treat the above as one definition of some crazy operator, but the point here is why I say that operator is momentum? The argument may be a bit long (I adopt the argument as in Dirac's which I think is more rigorous, you may refer to other books such as that in Griffiths for simpler version) but worth trying.

(a) The operator defined above is Hermite:

I need to prove $\hat{P} = \hat{P}^\dagger$, or equivalently: $<\varphi|\hat{P}|\psi>=<\psi|\hat{P}|\varphi>$, since $<\psi|\hat{P}|\varphi>^{*}=<\varphi|\hat{P}^\dagger|\psi>$, if above relation holds for any $|\psi>|\varphi>$, then the operator is Hermitian.

 $$ \begin{align*}<\varphi\mid\hat{P}\mid\psi>=&\int<\varphi\mid x><x\mid\hat{P}\mid\psi>dx=\int\varphi^{*}(x)(-i\hbar)\frac{d\psi(x)}{dx}dx\\=&-i\hbar\psi\varphi^{*}\big|_{-\infty}^{+\infty}+i\hbar\int\psi\frac{d\varphi^{*}}{dx}dx\end{align*} $$ 

From the physical argument that any realistic physical state cannot last forever, that means the wave functions go to zero at infinity, so that the first term would be zero. Then:

 $$ <\varphi\mid\hat{P}\mid\psi>=i\hbar\int\psi\frac{d\varphi^{*}}{d x}d x=[\int\psi^{*}(-i\hbar)\frac{d\varphi}{d x}d x]^{*}=<\psi\mid\hat{P}\mid\varphi>^{*} $$ 

So indeed the operator defined above is a Hermitian.

(b)Commutation rules between  $ \hat{X}.\hat{P} $

 $$ [\hat{X},\hat{P}]=\hat{X}\hat{P}-\hat{P}\hat{X} $$ 

Let's see its action on any wave function (let this commutator act