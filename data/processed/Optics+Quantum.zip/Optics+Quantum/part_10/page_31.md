Recall what we learned from Fourier transform, the delta function can be expressed as:

 $$ \begin{aligned}&\delta(x)=\frac{1}{2\pi}\int e^{i K x}d K\\ &\\ &Let\ x/\hbar=K,d x=\hbar d K\\ &\\ &<p^{\prime}|p>=\hbar\int e^{i(p-p^{\prime})K}d K=2\pi\hbar\delta(p-p^{\prime})\\ \end{aligned} $$ 

So the properly normalized  $ \langle x|p\rangle $ should be:

 $$ p(x)=<x\mid p>=\frac{e^{\frac{i\frac{p}{\hbar}x}{\hbar}}}{\sqrt{2\pi\hbar}}=\frac{e^{\frac{i\frac{p}{\hbar}x}{\hbar}}}{\sqrt{h}} $$ 

## Comments:

The meaning of  $ \langle x|p\rangle $ from the postulate is that given the state with definite momentum p, the probability amplitude find position at x. This probability is just  $ |\langle x|p\rangle|^{2}=1/h $. It is same for all x, i.e. you have equal probability of finding particle at any position! This is agreeable with the uncertainty relation, since in  $ |p\rangle $ the uncertainty of p is zero. However, the total probability of particle at  $ |p\rangle $ in the position space will explode (diverge), which is a headache for the quantum formalism, and a defect in the theory. But this is not a serious one because the state  $ |p\rangle $ (and  $ |x\rangle $) are idealization and not realizable in physics.

(e) Transformation between x and p spaces

 $$ p(x)=<x\mid p>=\frac{e^{^{i\frac{p}{\hbar}x}}}{\sqrt{2\pi\hbar}}=\frac{e^{^{i\frac{p}{\hbar}x}}}{\sqrt{h}} $$ 