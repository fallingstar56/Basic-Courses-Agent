even for the simplest case for a particle in free space (no external force or potential), its dimension to describe the position or momentum would be infinite (even we ‘digitize’ the results to make them discrete instead of continuous, they are still infinite numbers of them). This complexity is indeed imposed in quantum by the uncertainty principle and we have to bear with it.

Not only the dimension of the space is big in quantum, there are also many different bases in quantum corresponding to different physical properties under measurement (i.e. position, momentum, energy…). This means there are different ways to express the physical state  $ |\psi\rangle $ depending on which physical property in concern thus which basis is in use. The vector may be invariant in different bases (this is the blessing of the vector so that physical relations expressed by them would be independent of base), but its expression will be different in different bases (to work out problem, often you need explicit expressions of vectors with certain base). Here are two more examples to illustrate this point:

(1) The expression of photon state in terms of polarization or spin

For a photon if we only interested in its polarization state $ ^{51} $. Of

course if we know its  $ |H\rangle $,  $ |V\rangle $ components (the expansion

coefficients---the probability amplitude, complex numbers in