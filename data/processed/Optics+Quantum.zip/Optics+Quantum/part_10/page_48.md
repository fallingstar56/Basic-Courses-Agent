\hat{D}=\frac{1}{2}(\hat{x}\hat{p}_{x}+\hat{p}_{x}\hat{x})\equiv\frac{1}{2}\{\hat{x},\hat{p}_{x}\} to represent this physical quantity in quantum. $ ^{55} $ The {A,B} is called anti-commutator, it is not Poisson Bracket in classical mechanics.

## Supplement (B): Uncertainty

(b) Uncertainty relations between observables derived from the postulate.

We first need to define the expression for the uncertainty, the variation of the measurements of some observable A. If the measurements result in many values, $a_{i}$'s, then the variation is :

$(\Delta a)^{2} = <(a_{i} - <a_{i}>)^{2} >$, here <...> means average. From the above discussion, we could use an operator to represent this variation (the variation is a physical measurable quantity). The variation operator for observable A would be (just replace the numbers with operator A):

 $$ \begin{aligned}&<\left(\Delta A\right)^{2}>=<\left(A-<A>\right)^{2}>=<A^{2}-2A<A>+<A>^{2}>\\&\quad\quad\quad\quad=<A^{2}>-<A>^{2}\\&Thus\Delta A=A-<A>\\ \end{aligned} $$ 

A is the operator and <A> is the expectation value evaluated over some state. Since A is Hermitian,  $ \Delta A $ defined above is also a Hermitian as required by physical measurement.

It can be proved that for any two observables, the uncertainty between them obeys:

 $$ <(\Delta A)^{2}><(\Delta B)^{2}>\;\geq\;\frac{1}{4}|<[A,B]>|^{2} $$ 