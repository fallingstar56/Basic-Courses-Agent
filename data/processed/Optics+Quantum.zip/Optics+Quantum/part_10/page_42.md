general):

 $ |\psi \rangle = c_1 | H \rangle + c_2 | V \rangle $ or Jones Vector  $ \begin{bmatrix} c_1 \\ c_2 \end{bmatrix} $

This is a specific expression of state  $ \left| \psi \right\rangle $ in the  $ \left| H \right\rangle, \left| V \right\rangle $ base.

What’s its expression if we are interested in the spin state of the

photon? This time the base is  $ \left|+1\right\rangle $,  $ \left|-1\right\rangle $, corresponding to the

photon spin  $ +1\hbar $ and  $ -1\hbar $ along k, the direction of photon

propagation. IN this case, the  $ \left|+1\right\rangle $ and  $ \left|-1\right\rangle $ are related to the

polarization state $ ^{52} $:

 $$ |+1>=\left|L>,|-1>=\right|R> $$ 

 $$ \left|\psi\right>=c_{1}^{^{\prime}}\left|L\right>+c_{2}^{^{\prime}}\left|R\right> $$ 

The expression would be quite different in this base. However, with the simple relation between  $ \langle H|L\rangle,\langle H|R\rangle,\langle V|L\rangle,\langle V|R\rangle $ (the 4 elements in a transform matrix), you can find out the relation between  $ c_1 $,  $ c_2 $ and  $ c_1' $,  $ c_2' $.

(2) State of particle inside an infinite potential.

<div style="text-align: center;"><img src="imgs/img_in_image_box_252_1187_531_1405.jpg" alt="Image" width="23%" /></div>


You worked this out in a homework, the energy of the particle can