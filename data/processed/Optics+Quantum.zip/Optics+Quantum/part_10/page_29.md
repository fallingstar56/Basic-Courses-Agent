on any state and see what the expression in the  $ |x> $ basis):

 $$ \begin{aligned}<x|\hat{X}\hat{P}-\hat{P}\hat{X}|\psi>=&<x|\hat{X}\hat{P}|\psi>-<x|\hat{P}\hat{X}|\psi>\\=&<x|\hat{P}|\psi>-<x|\hat{P}|\psi^{\prime}>\quad|\psi^{\prime}>=\hat{X}|\psi>\\=&-i\hbar x\frac{d\psi}{d x}+i\hbar\frac{d<x|\hat{X}|\psi>}{d x}=-i\hbar x\frac{d\psi}{d x}+i\hbar\frac{d}{d x}(x\psi)\\=&i\hbar\psi=i\hbar<x|\psi>\end{aligned} $$ 

Since the above relation holds for arbitrary  $ |\psi> $, this means:

 $$ [\hat{X},\hat{P}]=\hat{X}\hat{P}-\hat{P}\hat{X}=i\hbar $$ 

This seemingly simple relation plays a very important role in the development of quantum theory. We have proved Ehrenfest theorem, and in the homework you have proved that: giving the above commutation relation, we can prove that the expectation values will obey Hamilton's equation of classical mechanics, i.e.

 $$ \frac{d<\hat{X}>}{dt}=\frac{<\hat{P}>}{m};\frac{d<\hat{P}>}{dt}=-\frac{dU(\hat{X})}{dx}>\mathrm{if}[\hat{X},\hat{P}]=\hat{X}\hat{P}-\hat{P}\hat{X}=i\hbar $$ 

This justifies the operator defined as above in relation (11-48) to be called momentum operator. $ ^{46} $

(c) Eigenstate of  $ \hat{P} $ and its expression in  $ |x> $ basis:  $ <x|p> $

Finally we come to the key to the transformation between  $ |x> $ and