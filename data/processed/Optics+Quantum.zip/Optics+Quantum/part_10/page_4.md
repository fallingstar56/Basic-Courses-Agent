between photon-electron interactions, such as no interaction at all (no photon deflected); an electron can scatter multiple photons during the passage, etc.

The expansion of the initial state will be:

 $$ |S>|\gamma_{l}>\rightarrow\sum_{i}(a_{i1}+a_{i2})|\gamma_{\theta_{i}}>|X> $$ 

$a_{i1}$ is the probability amplitude of electron through hole 1 scattering the photon into direction $\theta_{i}$; $a_{i2}$ is the probability amplitude of electron through hole 2 scattering the photon into direction $\theta_{i}$.

The detection of electron corresponds to projection along all  $ |\gamma_{\theta_i}>|X> $ states, i.e.

 $$ \hat{P}_{X,all\theta}=\mid X><X\mid=\mid X>(\sum_{i}\mid\gamma_{\theta_{i}}><\gamma_{\theta_{i}}\mid)<X\mid $$ 

And the resulting probability of electron at X no matter where the photon goes is:

 $$ P_{X,all\theta}=<\gamma_{l}\left|<S\mid\hat{P}_{X,all\theta}\mid S>\right|\gamma_{l}>=\sum_{i}\left|a_{i1}+a_{i2}\right|^{2} $$ 

This is a long example. Once you understand this, there will be no difficulty for you to understand Feynman's example in his chap.3, such as neutron scattering by a crystal in section 3-3. (Please read it yourself)

## Example3: Stern-Gerlach Experiment and Electron Spin

## (1) Magnetic Dipole and Motion in Magnetic Field (Classical)