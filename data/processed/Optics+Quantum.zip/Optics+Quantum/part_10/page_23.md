The expansion coefficient is a function of x for this continuous basis:

 $$ <x\mid\psi>=\psi(x) $$ 

 $ \psi(x) $ is usually called wave function and we see that it is expression of state vector onto x basis.

The probability density of finding particle at x is (according to postulate 3):

 $$ \left|<x\mid\psi>|^{2}=|\psi(x)|^{2}=<\psi\mid x><x\mid\psi>={\psi}^{*}(x)\psi(x)\right. $$ 

The proper state  $ |\psi> $ need to be normalized:

 $$ <\psi\mid\psi>=<\psi\mid I\mid\psi>=\int<\psi\mid x><x\mid\psi>dx=\int\psi^{*}\psi dx=1 $$ 

Dot product between state vectors is:

 $$ <\varphi\mid\psi>=\int\varphi^{*}(x)\psi(x)dx $$ 

If we act  $ \hat{X} $ on  $ |\psi> $, the state may change (unless the  $ |\psi> $ is one of eigenstates  $ |x> $):

 $$ \hat{X}\mid\psi>=\mid\psi^{\prime}> $$ 

This is not much helpful just a math expression of what I stated above.

The point is the output  $ |\psi'\rangle $ and input  $ |\psi\rangle $ are related:

 $$ \begin{aligned}&|\psi^{\prime}>={\hat{X}}\mid\psi>=\int{\hat{X}}\mid x><x\mid\psi>d x=\int x\psi(x)\mid x>d x\\ &\psi^{\prime}(x)=<x\mid\psi^{\prime}>=\int x^{\prime}\psi(x^{\prime})<x\mid x^{\prime}>d x^{\prime}=\int x^{\prime}\psi(x^{\prime})\delta(x-x^{\prime})d x^{\prime}=x\psi(x)\\ \end{aligned} $$ 

In short I have shown that:

 $$ <x\mid\hat{X}\mid\psi>=x\psi(x) $$ 

This is the expression of position operator acting on any state in x basis.