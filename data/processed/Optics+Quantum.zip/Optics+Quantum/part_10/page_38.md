(which I will skip the proof by integration), this means the wave packet will get broadened, which is indeed reflected in the exponential term.

ii. The center of the wave packet (also its maximum) travels at group velocity corresponds to the classical particle's velocity.

 $$ x-\left.\hbar k_{0}t\right|_{m}=0\quad(the center changes with time) $$ 

 $$ x\left/t=\hbar k_{0}\right/m=p\bigg/m $$ 

The width of the wave packet spreads:

 $$ \Delta x=\frac{\sigma}{2}\sqrt{1+\frac{4\hbar^{2}t^{2}}{\sigma^{4}m^{2}}} $$ 

The spreads rate is in accordance of the drop of the amplitude as expected.

We have discussed the most important postulates in Q.M, and worked out some examples to illustrate them. Now let me add some extra comments as summary.

Let's consider the single particle here for simplicity. In classical mechanics, the single particle is described by set of variables in real 3-D space, i.e.  $ q_{1}, q_{2}, q_{3} $ and their canonical conjugate momentum  $ p_{1}, p_{2}, \ldots, p_{n} $, and  $ p_{3} $, total of 6 variables. Knowing the environment (such as force or potential) and the initial conditions of the particle, the