first to propose the spin in order to explain the extra spectra lines in atomic spectroscopy (we now know these are called fine structures due to the spin-orbit coupling), and Dirac's relativistic equation contains them. The existence of unclassical spin have been again and again proved with experimental observation and I shall discuss the famous Stern-Gerlach experiment below. It not only shows the existence of spin, and spin of electron actually provides a very nice and simple system (so called two-level system) to works with and offers a excellent example to illustrate the postualtes we discussed, so now let's take a look.

## (2) Electron Spin and Stern-Gerlach Experiment

<div style="text-align: center;"><img src="imgs/img_in_image_box_250_812_913_1369.jpg" alt="Image" width="55%" /></div>


## FIGURE 1

<div style="text-align: center;">Schematic drawing of the Stern-Gerlach experiment. In figure a is shown the trajectory of a silver atom emitted from the high-temperature furnace E. This atom is deflected by the gradient of the magnetic field created by the electromagnet A and then condenses at N on plate P.</div>


<div style="text-align: center;">Figure b shows a cross section in the xOz plane of the electromagnet A; the lines of force of the magnetic field are shown in dashed lines. Bz has been assumed to be positive and  $ \partial B_z/\partial z $, negative. Consequently, the trajectory of figure a corresponds to a negative component  $ M_z $ of the magnetic moment, that is, to a positive component of  $ S_z $ ( $ \gamma $ is negative for a silver atom).</div>
