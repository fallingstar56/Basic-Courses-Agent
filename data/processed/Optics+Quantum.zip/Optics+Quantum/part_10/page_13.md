 $$ \begin{aligned}&\left|S\right|=\sqrt{\frac{1}{2}(\frac{1}{2}+1)\hbar}\\ &S_{z}=\frac{1}{2}\hbar or-\frac{1}{2}\hbar\\ \end{aligned} $$ 

More generally, the quantum mechanics shows for angular momentum represented by j:

 $$ \begin{aligned}&|j|=\sqrt{j(j+1)}\hbar\\&j_{z}=m_{z}\hbar\\ \end{aligned} $$ 

Where j is called angular momentum quantum number, it can only take intergers (1, 2, 3...) or half intergers (1/2, 3/2...); the  $ m_{z} $ is the direction quantization number; also called magnetic quantum number, since it plays roles when interaction with B field as we shall see. The  $ m_{z} $ is restricted within a given j,  $ m_{z} $ can only take j, j-1,...-j, total of 2j+1 value. If you accept this quantum result, you see (11-32) for spin 1/2 (angular momentum quantum number is 1/2) certainly fits in. The relation (11-33) can be rigorously derived from quantum mechanics and here I just throw out these to you.

Since the SG essentially measures the z-component of the electron spin. It has only two possible values (eigenvalues of the observable) and the two corresponding eigenstates (Postulate 3 of QM). Electron’s spin is also called spin-1/2 system. It belongs to a general class of two-level systems whose treatment is the simplest in Q.M (only in a generalized 2-Dimensional space). The focus here is to show you the Q.M treatment for such two-level system, illustrating the postulates and mathematical