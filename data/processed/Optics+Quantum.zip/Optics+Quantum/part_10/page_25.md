value (expectation value) etc.

Indeed we can do that as I will show you next with momentum operator, but first a general discussion may help. For a physical observable represented by operator A, is eigenvalues and eigenvectors are $a$ and $|a>.$ The measurement of A given the state $|\psi>\$ will have probability amplitude: $|a|\psi>, since we know the wave function $\psi(x)$, we’d like to evaluate the probability amplitude of A in $|x>\$ basis:

 $$ <a\mid\psi>=\int<a\mid x><x\mid\psi>dx=\int<a\mid x>\psi(x)dx=\int<x\mid a>^{*}\psi(x)dx=\int a^{*}\psi dx $$ 

$a^{*}$ is the conjugate of wave function of eigenvector $|a>.$ The above expression can also be seen as an expression for the matrix product, $I$ mean $|a|$ is a row vector with $a^{*}$ as its element (coefficients) while $| \psi >$ is a column vector with $\psi(x)$ as its elements.

So we see that the key is the  $ <a|x> $, the relation between basis vectors, which is no surprise at all from our discussion on polarization of light and spin 1/2 particles in Stern-Gerlach experiment. To work with operator A, the natural choice of basis would be its eigenbasis (eigenvector as base vectors and indeed most of time we shall choose such basis), but since I'd like to show how to work in  $ |x> $ basis, I need to do base transformation, and the key to base transformation is the relation between the base vectors.

Above shows that knowing  $ <a|x> $, we can compute probability amplitude of getting value a in measurement. The expression of A acting