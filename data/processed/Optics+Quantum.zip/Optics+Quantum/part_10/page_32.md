From this, I know the  $ \langle p|x\rangle $ (the expression of base  $ |x\rangle $ in p space)

which is the complex conjugate of  $ \langle x | p\rangle $:

 $$ x(p)=<p\mid x>=(<x\mid p>)^{*}=\frac{e^{-i\frac{p}{\hbar}x}}{\sqrt{2\pi\hbar}} $$ 

This is if the particle has definite location x, the probability of finding momentum p world be same for all p.

For any state  $ |\psi> $, its expression in x space and p space are:

Expression in x space:  $ <x|\psi \geq \psi(x) $

Expression in p space:  $ <p|\psi\rangle=\varphi(p) $

The two expressions are related, and knowing one will enable us to get the other:

 $$ \begin{aligned}&\psi(x)=<x\mid\psi>=<\langle x\mid p><p\mid\psi>dp=\frac{1}{\sqrt{2\pi\hbar}}\int\varphi(p)e^{\frac{i\frac{p}{h}x}{\hbar}}dp\\ &\\ &\varphi(p)=<p\mid\psi>=<\langle p\mid x><x\mid\psi>dx=\frac{1}{\sqrt{2\pi\hbar}}\int\psi(x)e^{-\frac{p}{\hbar}x}dx\\ \end{aligned} $$ 

The two are indeed related by the Fourier transform as advertised, except by a difference of constant factor. We can then make some ‘cosmetic’ by substitute:

 $$ k=\frac{p}{\hbar},d p=\hbar d k,\varphi(p)=g(k)/\sqrt{\hbar},then: $$ 

 $$ \begin{aligned}&\psi(x)=\frac{1}{\sqrt{2\pi}}\int g(k)e^{ikx}dk\\ &g(k)=\frac{1}{\sqrt{2\pi}}\int\psi(x)e^{-ikx}dx\\ \end{aligned} $$ 

This is exactly the definition of Fourier Transform.