It is our familiar plane wave, expressing the wave function of a particle with definite momentum in free space at any time.

 $$ k=\frac{p}{\hbar},\omega=\frac{E_{p}}{\hbar}=\frac{p^{2}}{2m\hbar}=\frac{\hbar k^{2}}{2m} $$ 

The phase velocity of the wave is:

 $$ \nu_{_{p}}=\frac{\omega}{k}=\frac{\hbar k}{2m}=\frac{p}{2m} $$ 

The group velocity is:

 $$ \nu_{g}=\frac{d\omega}{d k}=\frac{\hbar k}{m}=\frac{p}{m} $$ 

It is the group velocity that corresponds to the velocity of classical particle, which in a certain analogy, should not be surprise, since we see that in wave theory, it is the group velocity corresponds to the energy propagation of the wave packet.

The above plane wave is the ideal unrealizable case of for particle with definite momentum p (in analogy to monochromatic light wave), any real wave packet representing the particle will be a superposition of such plane waves. Say at time 0, the state of the system is a combination of different states of  $ |p> $ (i.e. express the state as combination of eigenstates of energy):

 $$ \left|\psi,t=0\right>=\int<p\left|\psi>\right|p>d p=\int\varphi(p)\left|p>d p\right. $$ 

Then at later time, the state of the system is: