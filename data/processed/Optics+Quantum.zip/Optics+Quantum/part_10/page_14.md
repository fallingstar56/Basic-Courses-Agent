manipulation.

First let me summarize what the observations of SG type experiments tell us:

1) Electron is only located at two places. The two and only two possible value means the observable correspond to the measurement of the  $ S_{z} $ only has two eigenvalues, and two distinct eigenstates associated with them. (electrons hitting above or below)

2) I shall use Dirac’s notation  $ |+Z> $ and  $ |-Z> $ to represent the two eigenstates of the Sz measurement that correspond to the  $ 1/2\hbar $ and  $ -1/2\hbar $. In math, it is just:  $ S_z\left|+z\right|=\frac{1}{2}\hbar\left|+z\right| $,  $ S_z\left|-z\right|=-\frac{1}{2}\hbar\left|-z\right| $. The  $ |+z\rangle $ and  $ |-z\rangle $ are chosen to be orthonormal, i.e.  $ <+z|+z\rangle=1 $ and  $ <-z|+z\rangle=0 $. They also form a complete basis in a 2-D space, i.e. closure relation  $ |+z\rangle\langle+z|+|-z\rangle\langle-z|=\mathrm{I} $ (the identity).

3) What happened for the x or y components of the spin? The results would be same if we use  $ |+x\rangle $,  $ |-x\rangle $ or  $ |+y\rangle $,  $ |-y\rangle $ as basis for the Sx or Sy measurement respectively. (this is expected from isotropic symmetry of the problem)

4) Now let's consider a series of SG experiment by let electrons passing a series of B field aligned at different angles. First consider the case as two B field all along the z direction: