 $ g_L = -\frac{e}{2m_e} $, then:

 $$ \vec{\mu}=g_{L}\vec{L} $$ 

Noticed due to the negative charge, the dipole direction and L direction is antiparallel for electron.

When such dipole is placed in a magnetic field B (as illustrated in the figure right above), it will experience a torque, which is:

 $$ \vec{\tau}=\vec{\mu}\times\vec{B} $$ 

Then the angular momentum change can be calculated with the formula:

 $$ \frac{d\vec{L}}{d t}=\vec{\tau}=\vec{\mu}\times\vec{B}\quad\mathrm{o r~i n s e r t~(11-25):} $$ 

 $$ \frac{d\vec{\mu}}{d t}=\vec{\mu}\times g\vec{B} $$ 

Recall what we learned in classical mechanics for any vector, if:

 $$ \frac{d\vec{A}}{dt}=\vec{\omega}\times\vec{A} $$ 

The vector A is pressing with a agular frequency.

So the (11-26) shows us the m-dipole presseses around B with certain frequency, rewrite it as:

 $$ \frac{d\vec{\mu}}{d t}=\vec{\mu}\times g\vec{B}=-g\vec{B}\times\vec{\mu}=\vec{\omega}\times\vec{\mu} $$ 

 $$ \vec{\omega}=-g\vec{B}=\frac{e}{2m_{e}}\vec{B} $$ 

This shows the in the figure right above, the m-dipole will presses around B with this frequency, and this frequency is called Larmour frequency.