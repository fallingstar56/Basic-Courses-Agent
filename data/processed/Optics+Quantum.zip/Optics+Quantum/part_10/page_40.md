To express these ideas in concrete math forms, this is realized by the postulate 1, 2, and 3. The forms of  $ |\psi\rangle=(a_{1}(\lambda_{1}),a_{2}(\lambda_{2}),a_{3}(\lambda_{3}).....) $ can be rewritten in a vector form (postulate 1):

 $$ \left|\psi\right>=a_{1}\left|\lambda_{1}\right>+a_{2}\left|\lambda_{2}\right>+a_{3}\left|\lambda_{3}\right>+\ldots $$ 

 $ |\lambda_{i}> $ is the eigenvector associated with eigenvalue  $ \lambda_{i} $ of the

observable. The observable is in form of Hermitian operator (postulate

2)would guarantee the real eigenvalue and orthogonality and

completeness of the eigenvectors (orthogonal comes from the fact that

the property of the system should be single valued, i.e. if the particle at

position  $ x_{1} $, it cannot appear at  $ x_{2} $ at the same time. Completeness

comes from that fact that we have to list ALL the possible

measurement outcomes). Postulate 3 would allow us to predict the

outcomes (in terms of probability, from the expansion coefficients-the

probability amplitude). This is the physical reasoning behind those

abstract postulates.

This quantum description may seem far less satisfactory than the classical one. There a particle is specified by only 6 variables and if you state it in a vector sense, the state vector in classical mechanics is in a phase space of dimension=6. In quantum, the state vector will be generally in a space with many dimensions or infinite dimension,