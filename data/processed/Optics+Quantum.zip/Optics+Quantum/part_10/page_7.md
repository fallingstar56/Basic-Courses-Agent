Above is purely classical treatment, our next question is how the quantum treat magnetic dipole interaction with B field, i.e. what is the observable related to the dipole?, what is the interaction energy of m-dipole with B field? And also what is the quantum treatment of the field?

Below is a brief discussion on the above questions:

First the field here will be treated as parameter, just the quantity as in classical field theory, the quantization of the field in QED will not be introduced here. This is of course an approximation, but works in cases where interaction between atoms/molecules with many photons. The magnetics dipole is related to the angular momentum, and we apply the quantization rules (as discussed in supplement a) to make it (the observable or operator) as:

 $$ \mu=g_{L}L $$ 

Here the form is same as (11-25) but here the meanings are different, the L is the angular momentum operator in quantum mechanics. The detailed quantum treatment of angular momentum (how to express L's operator and find its eigenvalue and eigenstate) will not be treated here. The key point is only to show the relation between the magnetic dipole is related to angular momentum observable.

Besides the angular momentum related to the orbital motion of electron (or any particle), there is another angular momentum which does not has classical analogy, it is called spin! Uhlenbeck and Goudsmit were the