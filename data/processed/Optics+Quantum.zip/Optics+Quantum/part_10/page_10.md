spin, it is not same as g_{L}, but very closely twice of it, i.e.

 $ g_{s} \approx 2g_{L} $

The reason for this difference is relativistic in origin, it is related to the Thomas precession. Here we need to just accept this difference and this relation was first introduced by Ulrenbeck and Goudsmit purely from experimental result.

Thus the force experienced by the electron with certain angular momentum in the B field is:

 $$ F=\nabla(\mu\bullet B)=\nabla(\mu_{z}B_{z})=\mu_{z}\nabla B_{z} $$ 

The reason that I only consider the gradient of  $ \mu_{z}B_{z} $ and neglect the x, y components is two folds:  $ B_{z} $ is the largest in the apparatus shown in the above figure; and due to the precession of the electron motion in the B field (a rotation along the Z direction) would make the average contribution of the  $ \mu_{x}, \mu_{y} $ to zero.

So the force exerted on the electron is proportional to the z-component of angular momentum. Electrons with different  $ \mu_{z} $ (or  $ S_{z} $) will experience different force while travelling through the B field, and will split and hit different locations on the detection screen. So by measuring the electron's distribution, you can learn the electron's angular momentum along the z-direction (projection of the total angular momentum along one direction, you can of course measure the x, y components just by rotating the B field and the results would be same as the z case because of the space is