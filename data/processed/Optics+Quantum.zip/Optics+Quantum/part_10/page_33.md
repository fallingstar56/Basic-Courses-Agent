(3) Particle in free space and time evolution of its wave function

A particle in free space is that it has no interaction, the potential energy is thus 0. The energy is only due to kinetic energy (the rest mass energy can be taken as a constant and set the 0 point for energy measurement). The Hamiltonian operator in this case is (see the discussion on supplement (a) for more details):

 $$ \hat{H}=\frac{\hat{p}^{2}}{2m}=\frac{\hat{p}\hat{p}}{2m} $$ 

The eigenstate of momentum  $ |p> $ is the also the eigenstate of energy:

 $$ \hat{H}\mid p>=\frac{\hat{p}}{2m}p\mid p>=\frac{p^{2}}{2m}\mid p>=E_{p}\mid p> $$ 

 $ |p> $ is the eigenstate of  $ \hat{H} $ with eigenvalue (energy)  $ E_p=\frac{p^2}{2m} $. A result agree with classical theory for particle free of potential $ ^{47} $.

Once we know the eigenstate of $H$, we can predict the time evolution of any state$^{48}$. In particular, say at time 0, the initial state is $|p\rangle$, then at time t, the state will be:

 $$ |p,t>=e^{^{-i\frac{E_{p}}{\hbar}t}}|p> $$ 

In X-representation, the above is:

 $$ \varphi(p,t)=<x\mid p,t>=e^{-i\frac{E_{p}}{\hbar}t}<x\mid p>=\frac{1}{\sqrt{2\pi\hbar}}e^{i(\frac{p}{\hbar}x-\frac{E_{p}}{\hbar}t)}=\frac{1}{\sqrt{2\pi\hbar}}e^{i(k x-\omega t)} $$ 