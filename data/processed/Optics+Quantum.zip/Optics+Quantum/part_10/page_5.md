Here is the review of what you probabl $ \underline{\text{u know about the motion of}} $ magnetic dipole in a B field. The key is to show the relation between angular momentum and magnetic dipole.

<div style="text-align: center;"><img src="imgs/img_in_image_box_212_355_349_430.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_617_335_704_481.jpg" alt="Image" width="7%" /></div>


We know that the current loop will generate the magnetic dipole and its formular is:

 $$ \vec{\mu}=I\hat{A}\hat{n} $$ 

Where I is current (the arrow in the figure shows the current direction, while electrons motion would be reversed), A is area of the loop and n is normal direction of the area (as illustrated by figure left above). In the case of electron motion around nuclei, it also possesses a current and thus a magnetic dipole, imaging electron moves in a circular loop with radius r: Its current will be:

 $ I = -e \frac{v}{2\pi r} $, (minus sign of course due to negative charge for electron)

Then the m-dipole will be:

 $$ \vec{\mu}=-\frac{e v}{2\pi r}\pi r^{2}\hat{n}=-\frac{e}{2m_{e}}m_{e}v r\hat{n}=-\frac{e}{2m_{e}}\vec{L} $$ 

L is the angular momentum of the motion.

So we see that the m-dipole is proportional to the angular momentum, the proportion constant is called gyromagnetic coefficient, usually shortened as gyro, it is defined as: