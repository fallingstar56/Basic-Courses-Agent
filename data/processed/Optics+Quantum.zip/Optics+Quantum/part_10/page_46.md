the theory.

## Supplement (A): Quantization Rules

(a) The relation between the observables and its correspondence to the physical relation in classical theory.

I only discussed some simple observables and their operators, such as position, spin. What about other physical quantities and how to express their operators if we already know some operator forms. The most important one would be what is the form of energy operator (Hamiltonian) in terms of other operators such as momentum and position?

From the correspondence principle as in Ehrenfest theorem, that the quantum expectation value would follow the classical theory, we have a method to construct the quantum observables (the operator). The classical energy is in forms of:

$$H = \frac{p^{2}}{2m} + V(x)\ \text{(here, H, p, x are just numbers)}$$

Express this in the expectation values in quantum:

 $$ \begin{aligned}<\varphi|\hat{H}|\varphi>=&<\varphi|\frac{\hat{P}\hat{P}}{2m}|\varphi>+<\varphi|V(\hat{x})|\varphi>\\ =<&\varphi|\frac{\hat{P}\hat{P}}{2m}+V(\hat{x})|\varphi>\end{aligned} $$ 

Here  $ \hat{H},\hat{P},\hat{x} $ are operators, and  $ V(\hat{x}) $ is a function of operators whose meaning is clearer in Taylor expansion. Since the state  $ |\varphi> $ is