<div style="text-align: center;"><img src="imgs/img_in_image_box_238_169_631_277.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">FIGURE 7</div>


<div style="text-align: center;">The first apparatus (a "source" composed of the furnace  $ E_1 $ and the slit  $ F_1 $, plus a "polarizer" formed by the magnet  $ A_1 $ and the pierced plate  $ P_1 $) prepares the atoms in the state  $ |+\rangle $. The second one (an "analyzer" composed of the magnet  $ A_2 $ and the plate  $ P_2 $) measures the component  $ S_2 $. The result obtained is certain  $ (+\hbar/2) $.</div>


In this case, the first  $ B_1 $ prepare the electron into  $ |+z> $ state (postulate

III, measurement cause the collapse of the input state into the

eigenstates). If we let the electron at the  $ |+z> $ state pass  $ B_2 $ (also along

the z), of course we will always get  $ +1/2 $ in the final measurement.

(This is really analogical to the light passing a series of polarizers).

5) Same figure above, now let's put the second B field to another direction, say along the x (or y) direction. The results would show that the  $ |+z> $ state out of the first SG apparatus, after passing the B2, it will hit two positions with equal probability along the x (or y) direction. This shows that the  $ |+z> $ state is not an eigenstate for the  $ S_x $ (or  $ S_y $) measurement. (There is no common state which is eigenstate for both  $ S_z $ and  $ S_x $; another saying of the same is that the  $ S_z $ and  $ S_x $ are not compatible and their operators are not commute). The  $ S_z $ measurement on a  $ |+z> $ state is:

 $ S_{x} \mid +z \rightarrow 50\% $ probability collaps to  $ |+x> $ and  $ 50\% $ into  $ |-x> $ (same for y or any pair combination of x-y-z)

So for the measurement of spin-1/2 along certain direction, it can be treated in a 2-D space spanned by the eigenstates of the spin-operators.