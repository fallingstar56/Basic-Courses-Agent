arbitrary, the above relation suggests the relation between the energy

operator and that of position and momentum are:

 $$ \hat{H}=\frac{\hat{P}\hat{P}}{2m}+V(\hat{x}) $$ 

In fact the simple rule is to replace the variables (the measurable quantities) in classical relation of physical properties with operator, you will get the quantum operator. Since in classical mechanics, the x, p describes the state of system, and all physical properties can be expressed as function of (x,p), thus we can construct the operator form from the classical relations. Of course this only applies to the observable that has classical correspondence. For the spin, we have to construct the operator based on experimental results as what I did in Stern-Gerlach example.

There is a pitfall in this method because of the uncertainty relation.

For example, we could define a quantity which is  $ D = xp_x $ in classical theory. Then what is the corresponding operator for D in quantum theory?⁵⁴ Is  $ \hat{D} = \hat{x}\hat{p}_x $ or  $ \hat{D} = \hat{p}_x\hat{x} $ ? Because  $ x $,  $ p_x $ are not commutable, i.e.  $ [\hat{x}, \hat{p}_x] = \hat{x}\hat{p}_x - \hat{p}_x\hat{x} = i\hbar \neq 0 $. So the two expressions are really different. Each expression is not even a Hermitian as required by the quantum theory. (You check it yourself). It turns out the correct form would be so called symmetrised product (a Hermitian):