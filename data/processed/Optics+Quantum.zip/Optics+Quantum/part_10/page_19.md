 $$ \left|+x\right\rangle=\frac{\sqrt{2}}{2}\left|+z\right\rangle+\frac{\sqrt{2}}{2}e^{i\theta_{+}}\left|-z\right\rangle $$ 

 $$ \left|-x\right|=\frac{\sqrt{2}}{2}\left|+z\right|-\frac{\sqrt{2}}{2}e^{i\theta_{+}}\left|-z\right> $$ 

Only one phase angle is undetermined now.

All the above argument would be applied equally well to the  $ |+y\rangle, |-y\rangle $ cases with  $ c' $ and  $ \theta' $ as coefficients, and we shall have the expression for  $ |+y\rangle, |-y\rangle $:

 $$ \left|+y\right\rangle=\frac{\sqrt{2}}{2}\left|+z\right\rangle+\frac{\sqrt{2}}{2}e^{i\theta_{+}^{-}}\left|-z\right\rangle $$ 

 $$ \left|-y\right\rangle=\frac{\sqrt{2}}{2}\left|+z\right\rangle-\frac{\sqrt{2}}{2}e^{i\theta_{+}^{^{\prime}}}\left|-z\right\rangle $$ 

There is one more experiment result we have not used, the relation between the x and y's. If the input state is  $ |+x> $ (or  $ |-x> $), passing through a  $ S_y $ measurement, you would get same results as the  $ S_z $ case. i.e.

 $$ \begin{aligned}&|<+y\mid+x>|^{2}=\mid\frac{1}{2}+\frac{1}{2}e^{i(\theta_{+}-\theta_{+}^{\prime})}\mid^{2}=\frac{1}{2}+\frac{1}{2}\cos(\theta_{+}-\theta_{+}^{\prime})=\frac{1}{2}\\ &so\theta_{+}-\theta_{+}^{\prime}=-\frac{\pi}{2}\\ \end{aligned} $$ 

(other relations between x and y would give same result) Still only one angle is not determined ( $ \theta_{+} $). Why there is this ‘free’ variable? Well, think the experiment setup. With the Z direction fixed, there are obvious many ways to choose X-Y directions. The X-Y can be rotated around the Z direction. So it is this arbitrary choice of X (with X fixed, then the Y will be fixed too) will give rise to the free variable. I shall