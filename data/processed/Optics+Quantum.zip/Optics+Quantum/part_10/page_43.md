have is in forms of  $ E=m^{2}E_{0} $, where m is an integer number determined by the standing wave condition  $ 2L=m\lambda $ ( $ m=1,2,3\ldots $)

The eigenstate of the energy (energy observable, represented by H, the Hamiltonian operator) forms a complete basis set. The initial state's expression in terms of the expansion of this basis set is:

 $$ |\psi>=\sum_{i}c_{i}\mid E_{i}> $$ 

Knowing the coefficients  $ c_{i} $, the results of energy measurement can be predicted (the probability of course).

Now you may ask the expression of the state in terms of position. The expression of the state in the base formed by position eigenstates  $ |x\rangle $ would be different:

 $$ <x\left|\psi>=\sum_{n}c_{_{n}}<x\right|E_{_{n}}>=\sum_{n}c_{_{n}}\sin(k_{_{n}}x)=\sum_{n}c_{_{n}}(\sin\frac{n\pi}{L}x)\quad(0\leq x\leq L) $$ 

So the state expressed in terms of |x> would be:

 $$ \left|\psi\right\rangle=\int\left|x\right\rangle\left\langle x\right|\psi\left\langle d x\right\rangle=\int[\sum_{n}c_{n}(\sin\frac{n\pi}{L}x)]\left|x\right\rangle d x $$ 

Both expressions represent the same initial state. Their expression can be quite different. In this case, it is also impossible to find a common basis set which are eigenstates for both the energy and position measurement, as in the polarization and spin case for photon. This is due to the uncertainty relation, the position and momentum (the energy in this case directly related to  $ p^{2} $) cannot be determined simultaneously.