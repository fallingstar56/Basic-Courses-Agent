phase factor which would have no physical significance, this would reduce the 8 unknowns to 6.

 $$ \left|+x\right\rangle=\left|c_{++}\right|e^{i\theta_{++}}\left|+z\right\rangle+\left|c_{+-}\right|e^{i\theta_{+-}}\left|-z\right\rangle=e^{i\theta_{++}}\left(\left|c_{++}\right|\left|+z\right\rangle+\left|c_{+-}\right|e^{i(\theta_{+-}-\theta_{++})}\left|-z\right\rangle\right) $$ 

We can neglect the common phase factor  $ e^{i\theta_{+}} $ (by set the phase angle 0), and let  $ \theta_{+} \equiv \theta_{+} - \theta_{++} $; similar to the  $ |-x> $ case. So 6 unknowns of which 4 are modules and 2 are phase angles.

We shall use orthonormal conditions of the  $ |+x\rangle, |-x\rangle $ (similar for  $ y $'s) and the experimental results of the SG experiment (the one list in 5 above) to determine them.

 $$ \begin{aligned}&<+x\mid+x>=\mid c_{++}\mid^{2}+\mid c_{+-}\mid^{2}=1\\&<-x\mid-x>=\mid c_{-+}\mid^{2}+\mid c_{--}\mid^{2}=1\\&<-x\mid+x>=\mid c_{++}\mid\mid c_{-+}\mid+\mid c_{+-}\mid\mid c_{--}\mid e^{i(\theta_{+}-\theta_{-})}=0\\ \end{aligned} $$ 

From the observation 5 above, we learned that if the input state is  $ |+x\rangle $ (or  $ |-x\rangle $), put it through  $ S_z $ measurement, there will be 1/2 probability ends in  $ |+z\rangle $ and 1/2 probability ends in  $ |-z\rangle $, this means (postulate 3):

 $$ \left|<+z\right|+x>\left|^{2}\right|=|c_{++}|^{2}=\frac{1}{2},\quad\left|c_{++}\right|=\frac{\sqrt{2}}{2} $$ 

Similarly  $ |c_{+}|=|c_{-}|=|c_{-}|=\frac{\sqrt{2}}{2} $ too. Put this in the orthogonal

relation above:

 $$ \begin{aligned}&<-x\mid+x>=\mid c_{++}\mid\mid c_{-+}\mid+\mid c_{+-}\mid\mid c_{--}\mid e^{i(\theta_{+}-\theta_{-})}=0\\&\frac{1}{2}+\frac{1}{2}e^{i(\theta_{+}-\theta_{-})}=0\\&then\theta_{+}-\theta_{-}=\pi\\ \end{aligned} $$ 

Put all these into expressions for  $ |+x\rangle, |-x\rangle $