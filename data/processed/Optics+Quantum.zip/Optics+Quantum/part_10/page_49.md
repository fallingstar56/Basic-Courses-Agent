This states that the uncertainty has a lower bound which is given by the module of the expectation value of the commutator between A,B. [A,B]=AB-BA. To prove 11-73, we shall need some Lemmas. $ ^{56} $

Lemma 1. The Schwarz Inequality

 $$ <\alpha\mid\alpha><\beta\mid\beta>\geq\mid<\alpha\mid\beta>\vert^{2} $$ 

The above relation is obvious for any real vectors in 3-D space, the module of the direct product is obvious less than the product of individual lengths. They are related by a cosine, only equal when the two vectors parallel. For any arbitrary vectors in the Hilbert space:

 $$ \begin{aligned}&||\alpha>+\lambda|\beta>|^{2}\geq0\text{for all}\lambda\\&(<\alpha|+\lambda^{*}<\beta|)(|\alpha>+\lambda|\beta>)=<\beta|\beta>\lambda^{2}+2\mathrm{Re}(\lambda<\alpha|\beta>)+<\alpha|\alpha>\geq0\\ \end{aligned} $$ 

This is equivalent for a parabolic function larger than 0, i.e.

 $ ax^2 + bx + c \geq 0 $ for all  $ x $, and the condition is:  $ b^2 \leq 4ac $. This will give the inequality in 11-74.

Lemma 2. The expectation value for a Hermitian operator is real.

Proof.  $ A = A^{\dagger} $

 $$ \left(<\varphi\mid A\mid\varphi>\right)^{*}=<\varphi\mid A^{\dagger}\mid\varphi>=<\varphi\mid A\mid\varphi> $$ 

Lemma3. The expectation value for an anti-Hermitian  $ (A^{+}=-A) $ is purely imaginary.

The proof for this is obvious, similar to lemma 2.

Equipped with these 3 lemmas, we can prove relation 11-73.