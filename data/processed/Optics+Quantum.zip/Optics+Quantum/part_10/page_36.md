 $$ \int\psi^{*}\psi dx=\int e^{\frac{2x^{2}}{\sigma^{2}}}dx=\sigma\sqrt{\pi}\bigg/\sqrt{2}=(\frac{\sigma^{2}\pi}{2})^{\frac{1}{2}} $$ 

Then the proper normalized initial wave function is:

 $$ \psi(x,0)=\left(\frac{2}{\pi\sigma^{2}}\right)^{\frac{1}{4}}e^{-\frac{x^{2}}{\sigma^{2}}}e^{-i k_{0}x} $$ 

(b) Finding its Fourier Transform:

The Fourier transform can be directly found by definition:

 $$ g(k)=\frac{1}{\sqrt{2\pi}}\int\psi(x,0)e^{-ikx}dx $$ 

You will need formula for calculation, but I will take the known Gauss transform:

 $$ f(x)=e^{-\frac{x^{2}}{\sigma^{2}}}\xrightarrow{FT}g(K)=\frac{\sigma}{\sqrt{2}}e^{-\frac{K^{2}\sigma^{2}}{4}} $$ 

For our given initial wave function, its FT then is(use above formula and phase shift property of FT):

 $$ g(k)=\left(\frac{2}{\pi\sigma^{2}}\right)^{\frac{1}{4}}\frac{\sigma}{\sqrt{2}}e^{-\frac{(k-k_{0})^{2}\sigma^{2}}{4}}=(2\pi)^{\frac{1}{4}}\sigma^{\frac{1}{2}}e^{-\frac{(k-k_{0})^{2}\sigma^{2}}{4}} $$ 

The FT of a Gaussian is another Gaussian.

Comments: Width of distribution of Gauss packet meets the lower limit in Uncertainty relation. The width of Gaussian is defined as:

For  $ f(x)=e^{-\frac{x^2}{\sigma^2}} $,  $ \Delta x \equiv \sigma/\sqrt{2} $ (This is defined from standard deviation of distribution.  $ (\Delta x)^2 = \langle x - \langle x \rangle \rangle^2 = \langle x^2 \rangle - \langle x \rangle^2 $)

For the given wave function, the probability (the square of the wave function) is: