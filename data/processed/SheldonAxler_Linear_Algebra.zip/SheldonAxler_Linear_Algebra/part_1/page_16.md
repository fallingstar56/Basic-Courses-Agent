### 3. C 矩阵

## 用矩阵表示线性映射

我们知道，若  $ v_{1},\ldots,v_{n} $ 是 V 的基，且  $ T:V\to W $ 是线性的，则  $ Tv_{1},\ldots,Tv_{n} $ 的值确定了 T 在 V 的任意向量上的值（见 3.5）。我们马上就会看到，利用 W 的基，矩阵可用以有效地记录这些  $ Tv_{j} $ 的值。

 $$ A_{j,k} $$ 

设 m 和 n 都是正整数.  $ m \times n $ 矩阵 A 是由 F 的元素构成的 m 行 n 列的矩形阵列:

 $$ \boldsymbol{A}=\left(\begin{array}{ccc}A_{1,1}&\cdots&A_{1,n}\\\vdots&&\vdots\\A_{m,1}&\cdots&A_{m,n}\end{array}\right). $$ 

记号  $ A_{j,k} $ 表示位于 A 的第 j 行第 k 列处的元素．也就是说，第一个下标代表行，第二个下标代表列．

因此  $ A_{2,3} $ 表示位于矩阵 A 的第 2 行第 3 列处的元素.

3.31 例 若  $ A=\left(\begin{array}{ccc}8 & 4 & 5-3i \\ 1 & 9 & 7\end{array}\right) $，则  $ A_{2,3}=7 $.

下面是本节的一个关键定义：

3.32 定义 线性映射的矩阵（matrix of a linear map）， $  \mathcal{M}(T)  $

设  $ T \in \mathcal{L}(V, W) $，并设  $ v_1, \ldots, v_n $ 是  $ V $ 的基， $ w_1, \ldots, w_m $ 是  $ W $ 的基。规定  $ T $ 关于这些基的矩阵为  $ m \times n $ 矩阵  $ \mathcal{M}(T) $，其中  $ A_{j,k} $ 满足

如果这些基不是上下文自明的，则采用记号  $ \mathcal{M}(T, (v_1, \ldots, v_n), (w_1, \ldots, w_m)) $.

线性映射  $ T \in \mathcal{L}(V, W) $ 的矩阵  $ \mathcal{M}(T) $ 依赖于 V 的基  $ v_1, \ldots, v_n $ 与 W 的基  $ w_1, \ldots, w_m $ 以及 T. 然而，基在上下文中应当是自明的，因此通常将其从记号中省略掉.

为了记住如何从 T 构造  $ \mathcal{M}(T) $，可以将定义域的基向量  $ v_{1}, \ldots, v_{n} $ 横写在顶端，并将 T 映到的那个向量空间的基向量  $ w_{1}, \ldots, w_{m} $ 竖写在左侧，如下所示：