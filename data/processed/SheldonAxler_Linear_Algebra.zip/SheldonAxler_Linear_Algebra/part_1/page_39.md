13 设 U 是 V 的子空间， $ v_{1} + U, \ldots, v_{m} + U $ 是 V/U 的基， $ u_{1}, \ldots, u_{n} $ 是 U 的基．证明  $ v_{1}, \ldots, v_{m}, u_{1}, \ldots, u_{n} $ 是 V 的基．

14 设  $ U = \{(x_1, x_2, \ldots) \in \mathbf{F}^\infty : \text{只有有限多个 } j \text{ 使得 } x_j \neq 0\} $.

(a) 证明 U 是  $ F^{\infty} $ 的子空间.

(b) 证明  $ F^{\infty}/U $ 是无限维的.

15 设  $ \varphi \in \mathcal{L}(V, \mathbf{F}), \varphi \neq 0 $. 证明  $ \dim V / (\text{null } \varphi) = 1 $.

16 设 $U$ 是 $V$ 的子空间使得 $\dim V/U = 1$. 证明存在 $\varphi \in \mathcal{L}(V, \mathbf{F})$ 使得 $\text{null} \varphi = U$.

17 设 U 是 V 的子空间使得 V/U 是有限维的．证明存在 V 的子空间 W 使得  $ \dim W = \dim V/U $ 且  $ V = U \oplus W $．

18 设  $ T \in \mathcal{L}(V, W) $，并设  $ U $ 是  $ V $ 的子空间。用  $ \pi $ 表示  $ V $ 到  $ V/U $ 的商映射。证明：存在  $ S \in \mathcal{L}(V/U, W) $ 使得  $ T = S \circ \pi $ 当且仅当  $ U \subset \text{null} T $。

19 对有限集给出一个类比于 3.78 的恰当陈述，使得集合的并类比于子空间的和，不交并类比于直和.

20 设 U 是 V 的子空间.  $ \Gamma\colon\mathcal{L}(V/U,W)\to\mathcal{L}(V,W) $ 定义为  $ \Gamma(S)=S\circ\pi $.

(a) 证明  $ \Gamma $ 是线性映射.

(b) 证明  $ \Gamma $ 是单的.

(c) 证明 range  $ \Gamma = \{T \in \mathcal{L}(V, W) : \text{对所有 } u \in U \text{ 有 } Tu = 0\} $.

### 3. F 对偶

## 对偶空间与对偶映射

映到标量域 F 的线性映射在线性代数中扮演了重要角色，因此它们有一个特别的名字：

3.92 定义 线性泛函（linear functional）

V 上的线性泛函是从 V 到 F 的线性映射．也就是说，线性泛函是  $ \mathcal{L}(V, \mathbf{F}) $ 中的元素.

### 3.93 例 线性泛函

• 定义  $ \varphi: \mathbf{R}^3 \to \mathbf{R} $ 为  $ \varphi(x, y, z) = 4x - 5y + 2z $。则  $ \varphi $ 是  $ \mathbf{R}^3 $ 上的线性泛函。

• 取定  $ (c_{1},\ldots,c_{n})\in\mathbf{F}^{n} $．定义  $ \varphi:\mathbf{F}^{n}\to\mathbf{F} $ 为  $ \varphi(x_{1},\ldots,x_{n})=c_{1}x_{1}+\cdots+c_{n}x_{n} $ 则  $ \varphi $ 是  $ \mathbf{F}^{n} $ 上的线性泛函.

· 定义  $ \varphi: \mathcal{P}(\mathbf{R}) \to \mathbf{R} $ 为  $ \varphi(p) = 3p''(5) + 7p(4) $. 则  $ \varphi $ 是  $ \mathcal{P}(\mathbf{R}) $ 上的线性泛函.

· 定义  $ \varphi: \mathcal{P}(\mathbf{R}) \to \mathbf{R} $ 为  $ \varphi(p) = \int_0^1 p(x) \, \mathrm{d}x $。则  $ \varphi $ 是  $ \mathcal{P}(\mathbf{R}) $ 上的线性泛函。