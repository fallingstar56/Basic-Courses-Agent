### 3.78 和为直和当且仅当维数相加

设 V 是有限维的，且  $ U_1, \ldots, U_m $ 均为 V 的子空间．则  $ U_1 + \cdots + U_m $ 是直和当且仅当  $ \dim(U_1 + \cdots + U_m) = \dim U_1 + \cdots + \dim U_m $．

证明 3.77 中的映射  $ \Gamma $ 是满的．所以由线性映射基本定理 3.22， $ \Gamma $ 是单的当且仅当

 $$ \dim(U_{1}+\cdots+U_{m})=\dim(U_{1}\times\cdots\times U_{m}). $$ 

利用 3.77 和 3.76 可知， $ U_{1}+\cdots+U_{m} $ 是直和当且仅当

 $$ \dim(U_{1}+\cdots+U_{m})=\dim U_{1}+\cdots+\dim U_{m}. $$ 

当 m = 2 时， $ U_{1} + U_{2} $ 是直和当且仅当  $ \dim(U_{1} + U_{2}) = \dim U_{1} + \dim U_{2} $ 。利用 1.45 和 2.43 可以给出这一结果的另一个证明。

## 向量空间的商

我们先定义向量与子空间的和，以便引入商空间.

设  $ v \in V $， $ U $ 是  $ V $ 的子空间。则  $ v + U $ 是  $ V $ 的子集，定义如下：

 $$ \nu+U=\{\nu+u:u\in U\}. $$ 

3.80 例 设

 $$ U=\left\{(x,2x)\in\mathbf{R}^{2}:x\in\mathbf{R}\right\}. $$ 

则 U 是  $ R^{2} $ 中过原点的斜率为 2 的直线.

于是

 $$ (17,20)+U $$ 

是  $ R^{2} $ 中包含点 (17,20) 的斜率为 2 的直线.

<div style="text-align: center;"><img src="imgs/img_in_image_box_477_818_718_1042.jpg" alt="Image" width="26%" /></div>


3.81 定义 仿射子集（affine subset）、平行（parallel）

• V 的仿射子集是 V 的形如  $ v + U $ 的子集，其中  $ v \in V $，U 是 V 的子空间。

• 对于  $ v \in V $ 和  $ V $ 的子空间  $ U $，称仿射子集  $ v + U $ 平行于  $ U $.

### 3.82 例 平行的仿射子集

• 在上面的例 3.80 中， $ R^{2} $ 中所有斜率为 2 的直线均平行于 U.