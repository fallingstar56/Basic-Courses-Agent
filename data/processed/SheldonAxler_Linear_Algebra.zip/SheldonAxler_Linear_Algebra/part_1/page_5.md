尽管线性映射在整个数学中是广泛存在的，但并不是像某些学生想象的那样无处不在。这些呆萌的学生写下  $ \cos 2x = 2\cos x $ 和  $ \cos(x + y) = \cos x + \cos y $，似乎认为  $ \cos $ 是  $ \mathbf{R} $ 到  $ \mathbf{R} $ 的线性映射。

请自行验证如上定义的  $ S + T $ 和  $ \lambda T $ 的确是线性映射．也就是说，若  $ S, T \in \mathcal{L}(V, W) $， $ \lambda \in \mathbf{F} $，则  $ S + T \in \mathcal{L}(V, W) $， $ \lambda T \in \mathcal{L}(V, W) $．

由于我们已经定义了  $ \mathcal{L}(V,W) $ 上的加法和标量乘法，下面的结果就不足为奇了.

### 3.7 $ \mathcal{L}(V,W) $ 是向量空间

按照上面定义的加法和标量乘法， $ \mathcal{L}(V,W) $ 是一个向量空间.

请自行证明上述命题．注意  $ \mathcal{L}(V,W) $ 的加法单位元就是本节早先定义的零映射.

一般来说，向量空间中的两个元素相乘是没有意义的，但是对于一对适当的线性映射却存在一种有用的乘积．我们还需要第三个向量空间，所以现在假设 U 是 F 上的向量空间.

3.8 定义 线性映射的乘积（product of linear maps）

若  $ T \in \mathcal{L}(U, V) $， $ S \in \mathcal{L}(V, W) $，则定义乘积  $ ST \in \mathcal{L}(U, W) $ 如下：

对任意  $ u \in U $， $ (ST)(u) = S(Tu) $.

也就是说，ST 恰为通常的函数复合  $ S \circ T $。但是，若两个函数都是线性的，则大多数数学家都写成 ST 而不是  $ S \circ T $。请验证当  $ T \in \mathcal{L}(U, V), S \in \mathcal{L}(V, W) $ 时 ST 的确是从 U 到 W 的线性映射。

注意，只有当 T 映到 S 的定义域内时 ST 才有定义.

### 3.9 线性映射乘积的代数性质

3.9 线性映射和酉酉酉酉