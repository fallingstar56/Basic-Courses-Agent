证明 已知 M 是线性的，故只需证明 M 既单又满．这些都很容易．先从单性开始．如果  $ T \in \mathcal{L}(V, W) $ 并且  $ \mathcal{M}(T) = 0 $，则  $ T v_k = 0, k = 1, \ldots, n $．因为  $ v_1, \ldots, v_n $ 是 V 的基，所以 T = 0．于是 M 是单的（由于 3.16）．

为了证明 M 是满的，设  $ A \in \mathbf{F}^m, n $。设 T 是从 V 到 W 的线性映射使得

 $$ T\nu_{k}=\sum_{j=1}^{m}A_{j,k}w_{j}, $$ 

其中  $ k = 1, \ldots, n $（见 3.5）。显然  $ \mathcal{M}(T) $ 等于  $ A $，所以  $ \mathcal{M} $ 的值域等于  $ \mathbf{F}^m, n $。

现在可以确定从一个向量空间到另一个向量空间的所有线性映射构成的向量空间的维数.

 $$ 3.61\dim\mathcal{L}(V,W)=(\dim V)(\dim W) $$ 

设 V 和 W 都是有限维的，则  $ \mathcal{L}(V,W) $ 是有限维的且

 $$ \dim\mathcal{L}(V,W)=(\dim V)(\dim W). $$ 

证明 由 3.60、3.59 和 3.40 证得.

## 将线性映射视为矩阵乘

前面定义了线性映射的矩阵．现在来定义向量的矩阵．

3.62 定义 向量的矩阵（matrix of a vector）， $ M(v) $

设  $ v \in V $，并设  $ v_1, \ldots, v_n $ 是  $ V $ 的基。则规定  $ v $ 关于这个基的矩阵是  $ n \times 1 $ 矩阵

 $$ \mathcal{M}(\nu)=\left(\begin{array}{c}c_{1}\\ \vdots\\ c_{n}\end{array}\right), $$ 

这里  $ c_{1},\ldots,c_{n} $ 是使得下式成立的标量：

 $$ \nu=c_{1}\nu_{1}+\cdots+c_{n}\nu_{n}. $$ 

向量  $ v \in V $ 的矩阵  $ \mathcal{M}(v) $ 与  $ V $ 的基  $ v_1, \ldots, v_n $ 有关，也与向量  $ v $ 有关。然而，基通常是上下文自明的，所以就不把基包括在记号中了。

### 3.63 例 向量的矩阵

•  $ 2 - 7x + 5x^{3} $ 关于  $ \mathcal{P}_{3}(\mathbf{R}) $ 的标准基的矩阵为

 $$ \left(\begin{array}{c}2\\ -7\\ 0\\ 5\end{array}\right). $$ 