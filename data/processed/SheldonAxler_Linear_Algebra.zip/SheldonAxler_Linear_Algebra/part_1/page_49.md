5 设  $ V_{1}, \ldots, V_{m} $ 均为向量空间．证明  $ (V_{1} \times \cdots \times V_{m})' $ 和  $ V_{1}' \times \cdots \times V_{m}' $ 是同构的向量空间.

6 设 V 是有限维的， $ v_1, \ldots, v_m \in V $。定义线性映射  $ \Gamma: V' \to F^m $ 如下：

 $$ \Gamma(\varphi)=\big(\varphi(\nu_{1}),\ldots,\varphi(\nu_{m})\big). $$ 

(a) 证明  $ v_{1}, \ldots, v_{m} $ 张成 V 当且仅当  $ \Gamma $ 是单的.

(b) 证明  $ v_{1}, \ldots, v_{m} $ 是线性无关的当且仅当  $ \Gamma $ 是满的.

7 设 m 是正整数. 证明  $ \mathcal{P}_{m}(\mathbf{R}) $ 的基  $ 1, x, \ldots, x^{m} $ 的对偶基是  $ \varphi_{0}, \varphi_{1}, \ldots, \varphi_{m} $，其中  $ \varphi_{j}(p) = \frac{p^{(j)}(0)}{j!} $， $ p^{(j)} $ 表示 p 的 j 次导数，p 的 0 次导数规定为 p.

8 设 m 是正整数.

(a) 证明  $ 1, x - 5, \ldots, (x - 5)^m $ 是  $ \mathcal{P}_m(\mathbf{R}) $ 的基.

(b) 求 (a) 中的基的对偶基.

9 设  $ v_{1}, \ldots, v_{n} $ 是 V 的基， $ \varphi_{1}, \ldots, \varphi_{n} $ 是  $ V' $ 的相应的对偶基．设  $ \psi \in V' $．证明

 $$ \psi=\psi(\nu_{1})\varphi_{1}+\cdots+\psi(\nu_{n})\varphi_{n}. $$ 

10 证明 3.101 的前两条.

11 设 A 是  $ m \times n $ 矩阵且  $ A \neq 0 $。证明 A 的秩是 1 当且仅当存在  $ (c_{1}, \ldots, c_{m}) \in \mathbf{F}^{m} $ 和  $ (d_{1}, \ldots, d_{n}) \in \mathbf{F}^{n} $ 使得对任意  $ j = 1, \ldots, m $ 和  $ k = 1, \ldots, n $ 有  $ A_{j,k} = c_{j} d_{k} $。

12 证明 V 的恒等映射的对偶映射是  $ V' $ 的恒等映射.

13 定义  $ T: \mathbf{R}^{3} \rightarrow \mathbf{R}^{2} $ 为  $ T(x,y,z) = (4x + 5y + 6z, 7x + 8y + 9z) $. 设  $ \varphi_{1}, \varphi_{2} $ 是  $ R^{2} $ 的标准基的对偶基， $ \psi_{1}, \psi_{2}, \psi_{3} $ 是  $ R^{3} $ 的标准基的对偶基.

(a) 描述线性泛函  $ T'(\varphi_{1}) $ 和  $ T'(\varphi_{2}) $.

(b) 将  $ T'(\varphi_{1}) $ 和  $ T'(\varphi_{2}) $ 写成  $ \psi_{1}, \psi_{2}, \psi_{3} $ 的线性组合.

14 定义  $ T: \mathcal{P}(\mathbf{R}) \to \mathcal{P}(\mathbf{R}) $ 如下：对  $ x \in \mathbf{R} $ 有  $ (Tp)(x) = x^2 p(x) + p''(x) $.

(a) 设  $ \varphi \in \mathcal{P}(\mathbf{R})' $ 定义为  $ \varphi(p) = p'(4) $. 描述  $ \mathcal{P}(\mathbf{R}) $ 上的线性泛函  $ T'(\varphi) $.

(b) 设  $ \varphi \in \mathcal{P}(\mathbf{R})' $ 定义为  $ \varphi(p) = \int_0^1 p(x) \, \mathrm{d}x $. 求  $ (T'(\varphi))(x^3) $.

15 设 W 是有限维的， $ T \in \mathcal{L}(V, W) $。证明  $ T' = 0 $ 当且仅当 T = 0。

16 设 V 和 W 都是有限维的．证明将  $ T \in \mathcal{L}(V, W) $ 变为  $ T' \in \mathcal{L}(W', V') $ 的映射是  $ \mathcal{L}(V, W) $ 到  $ \mathcal{L}(W', V') $ 的同构.

17 设  $ U \subset V $. 说明为什么  $ U^0 = \{\varphi \in V' : U \subset \text{null} \varphi\} $.

18 设 V 是有限维的， $ U \subset V $。证明  $ U = \{0\} $ 当且仅当  $ U^0 = V' $。

19 设 V 是有限维的，U 是 V 的子空间．证明 U = V 当且仅当  $ U^{0} = \{0\} $

20 设 U 和 W 均为 V 的子集， $ U \subset W $。证明  $ W^{0} \subset U^{0} $。