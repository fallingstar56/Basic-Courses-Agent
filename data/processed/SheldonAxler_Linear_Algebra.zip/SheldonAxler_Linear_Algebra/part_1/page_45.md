 $$ \begin{aligned}\dim range T^{\prime}&=\dim W^{\prime}-\dim null T^{\prime}\\&=\dim W-\dim(range T)^{0}\\&=\dim range T,\end{aligned} $$ 

这里第一个等号是利用线性映射基本定理 3.22，第二个等号是利用 3.95 和 3.107(a)，第三个等号是利用 3.106.

(b) 首先设  $ \varphi \in \text{range} T' $．则存在  $ \psi \in W' $ 使得  $ \varphi = T'(\psi) $．若  $ v \in \text{null} T $，则

 $$ \varphi(\nu)=\left(T^{\prime}(\psi)\right)\nu=(\psi\circ T)(\nu)=\psi(T\nu)=\psi(0)=0. $$ 

所以  $ \varphi \in (\text{null} T)^0 $。这表明 range  $ T' \subset (\text{null} T)^0 $。

为完成证明，我们要证明 range  $ T' $ 和  $ (\text{null}T)^{0} $ 的维数相同，为此，注意到

 $$ \begin{aligned}\dim range T^{\prime}&=\dim range T\\&=\dim V-\dim null T\\&=\dim(null T)^{0},\end{aligned} $$ 

这里第一个等号是利用 (a)，第二个等号是利用线性映射基本定理 3.22，第三个等号是利用 3.106.

下面的结果应当与 3.108 相对照.

3.110 T 是单的等价于  $ T' $ 是满的

设 V 和 W 都是有限维的， $ T \in \mathcal{L}(V, W) $。则 T 是单的当且仅当  $ T' $ 是满的。

证明 映射  $ T \in \mathcal{L}(V, W) $ 是单的当且仅当  $ null T = \{0\} $，当且仅当  $ (\text{null } T)^0 = V' $，当且仅当 range  $ T' = V' $（由于 3.109(b)），当且仅当  $ T' $ 是满的。

## 对偶映射的矩阵

现在我们定义矩阵的转置.

3.111 定义 转置（transpose）， $ A^{t} $

矩阵 A 的转置（记为  $ A^t $）是通过互换 A 的行和列的角色所得到的矩阵．确切地说，若 A 是  $ m \times n $ 矩阵，则  $ A^t $ 是  $ n \times m $ 矩阵，其元素由下面的等式给出：

 $$ (A^{\mathrm{t}})_{k,j}=A_{j,k}. $$ 

3.112 例 若  $ A=\left(\begin{array}{cc}5 & -7 \\ 3 & 8 \\ -4 & 2\end{array}\right) $，则  $ A^{t}=\left(\begin{array}{ccc}5 & 3 & -4 \\ -7 & 8 & 2\end{array}\right) $.

注意这里 A 是  $ 3 \times 2 $ 矩阵， $ A^{1} $ 是  $ 2 \times 3 $ 矩阵.