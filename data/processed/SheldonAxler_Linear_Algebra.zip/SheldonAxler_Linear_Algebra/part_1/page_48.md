证明 设  $ v_1, \ldots, v_n $ 是  $ V $ 的基， $ w_1, \ldots, w_m $ 是  $ W $ 的基。则将  $ w \in \text{span}(Tv_1, \ldots, Tv_n) $ 变为  $ \mathcal{M}(w) $ 的函数是从  $ \text{span}(Tv_1, \ldots, Tv_n) $ 到  $ \text{span}\left(\mathcal{M}(Tv_1), \ldots, \mathcal{M}(Tv_n)\right) $ 的同构。于是  $ \text{dim}_{\text{span}}(Tv_1, \ldots, Tv_n) = \text{dim}_{\text{span}}\left(\mathcal{M}(Tv_1), \ldots, \mathcal{M}(Tv_n)\right) $，这里最后一个维数等于  $ \mathcal{M}(T) $ 的列秩。

容易看出 range  $ T = \text{span}(Tv_1, \ldots, Tv_n) $。于是  $ \text{dim range } T = \text{dim span}(Tv_1, \ldots, Tv_n) = \mathcal{M}(T) $ 的列秩。

在例 3.116 中行秩和列秩相等．以下命题表明这个结论恒成立.

### 3.118 行秩等于列秩

设  $ A \in \mathbf{F}^m, n $，则  $ A $ 的行秩等于  $ A $ 的列秩。

证明 定义  $ T: \mathbf{F}^{n,1} \rightarrow \mathbf{F}^{m,1} $ 为 Tx = Ax. 则  $ \mathcal{M}(T) = A $，这里  $ \mathcal{M}(T) $ 按  $ \mathbf{F}^{n,1} $ 和  $ \mathbf{F}^{m,1} $ 的标准基计算. 现在

 $$ \begin{aligned}A 的列秩 &=\mathcal{M}(T) 的列秩 \\&=\dim range T\\&=\dim range T^{\prime}\\&=\mathcal{M}(T^{\prime}) 的列秩 \\&=A^{t} 的列秩 \\&=A 的行秩 ,\end{aligned} $$ 

这里第二个等号是利用 3.117，第三个等号是利用 3.109(a)，第四个等号是利用 3.117（其中  $ \mathcal{M}(T') $ 按照标准基的对偶基计算），第五个等号是利用 3.114，最后一个等号是利用定义.

以上命题使得我们可以不区分 “行秩” 和 “列秩” 这两个术语，而直接使用更简单的术语 “秩”.

3.119 定义秩（rank）

矩阵的  $ A \in F^{m,n} $ 的秩定义为 A 的列秩.

### 习题 3.F

1 解释为什么每个线性泛函或者是满的或者是零映射.

2 给出  $ R^{[0,1]} $ 上三个不同的线性泛函的例子.

3 设 V 是有限维的， $ v \in V $ 且  $ v \neq 0 $。证明存在  $ \varphi \in V' $ 使得  $ \varphi(v) = 1 $。

4 设 V 是有限维的，U 是 V 的子空间使得  $ U \neq V $。证明存在  $ \varphi \in V' $ 使得对每个  $ u \in U $ 有  $ \varphi(u) = 0 $ 但  $ \varphi \neq 0 $。