上述命题的一个例子：对于含有 4 个变量和 5 个方程的非齐次线性方程组，可以选取某些常数项使方程组无解.

### 习题 3.B

1 给出线性映射 T 使得 dim null T = 3 且 dim range T = 2.

2 设 V 是向量空间， $ S, T \in \mathcal{L}(V, V) $ 使得 range  $ S \subset \text{null} T $。证明  $ (ST)^2 = 0 $。

3 设  $ v_{1}, \ldots, v_{m} $ 是 V 中的向量组. 定义  $ T \in \mathcal{L}(\mathbf{F}^{m}, V) $ 如下:

 $$ T(z_{1},\cdots,z_{m})=z_{1}\nu_{1}+\cdots+z_{m}\nu_{m}. $$ 

(a) T 的什么性质相当于  $ v_{1}, \ldots, v_{m} $ 张成 V?

(b) T 的什么性质相当于  $ v_{1}, \ldots, v_{m} $ 是线性无关的？

4 证明  $ \{T \in \mathcal{L}(\mathbf{R}^5, \mathbf{R}^4) : \dim \text{null } T > 2\} $ 不是  $ \mathcal{L}(\mathbf{R}^5, \mathbf{R}^4) $ 的子空间.

5 给出线性映射  $ T: \mathbb{R}^4 \to \mathbb{R}^4 $ 使得 range  $ T = \text{null} T $.

6 证明不存在线性映射  $ T: \mathbf{R}^5 \to \mathbf{R}^5 $ 使得 range  $ T = \text{null} T $.

7 设 V 和 W 都是有限维的，且  $ 2 \leq \dim V \leq \dim W $．证明  $ \{T \in \mathcal{L}(V, W) : T $ 不是单的\} 不是  $ \mathcal{L}(V, W) $ 的子空间.

8 设 V 和 W 都是有限维的，且  $ \dim V \geq \dim W \geq 2 $。证明  $ \{T \in \mathcal{L}(V, W) : T $ 不是满的\} 不是  $ \mathcal{L}(V, W) $ 的子空间。

9 设  $ T \in \mathcal{L}(V, W) $ 是单的， $ v_1, \ldots, v_n $ 在 V 中线性无关．证明  $ Tv_1, \ldots, Tv_n $ 在 W 中线性无关．

10 设  $ v_1, \ldots, v_n $ 张成  $ V $，并设  $ T \in \mathcal{L}(V, W) $。证明组  $ Tv_1, \ldots, Tv_n $ 张成 range  $ T $。

11 设  $ S_{1}, \ldots, S_{n} $ 均为单的线性映射且  $ S_{1}S_{2} \cdots S_{n} $ 有意义．证明  $ S_{1}S_{2} \cdots S_{n} $ 是单射．

12 设  $ V $ 是有限维的， $ T \in \mathcal{L}(V, W) $。证明  $ V $ 有一个子空间  $ U $ 使得  $ U \cap \text{null} T = \{0\} $ 且  $ \text{range} T = \{Tu : u \in U\} $。

13 设 T 是从  $ F^{4} $ 到  $ F^{2} $ 的线性映射使得 null T =  $ \left\{(x_{1}, x_{2}, x_{3}, x_{4}) \in \mathbf{F}^{4} : x_{1} = 5x_{2}, x_{3} = 7x_{4}\right\} $. 证明 T 是满的.

14 设 U 是  $ R^8 $ 的一个 3 维子空间，T 是  $ R^8 $ 到  $ R^5 $ 的一个线性映射使得 null T = U.

证明 T 是满的.

15 证明不存在零空间等于  $ \left\{(x_{1},x_{2},x_{3},x_{4},x_{5})\in\mathbf{F}^{5}:x_{1}=3x_{2},x_{3}=x_{4}=x_{5}\right\} $ 的  $ F^{5} $ 到  $ F^{2} $ 的线性映射.

16 假设在 V 上存在一个线性映射，其零空间和值域都是有限维的．证明 V 是有限维的.

17 设 V 和 W 都是有限维的．证明存在一个 V 到 W 的单的线性映射当且仅当  $ \dim V \leq \dim W $．