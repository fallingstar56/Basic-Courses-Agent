(b) 对每组  $ c_1, \ldots, c_n \in \mathbb{F} $ 下面的方程组都有解：

 $$ \left\{\begin{aligned}\sum_{k=1}^{n}A_{1,k}x_{k}&=c_{1},\\ \vdots\\ \sum_{k=1}^{n}A_{n,k}x_{k}&=c_{n}.\end{aligned}\right. $$ 

### 3. E 向量空间的积与商

## 向量空间的积

通常在处理多个向量空间时，这些向量空间都应当在同一个域上。

3.71 定义 向量空间的积（product of vector spaces）

设  $ V_1, \ldots, V_m $ 均为 F 上的向量空间.

- 规定积  $ V_1 \times \cdots \times V_m $ 为

 $ V_1 \times \cdots \times V_m = \{(v_1, \ldots, v_m) : v_1 \in V_1, \ldots, v_m \in V_m\} $.

- 规定  $ V_1 \times \cdots \times V_m $ 上的加法为

 $ (u_1, \ldots, u_m) + (v_1, \ldots, v_m) = (u_1 + v_1, \ldots, u_m + v_m) $.

- 规定  $ V_1 \times \cdots \times V_m $ 上的标量乘法为

 $ \lambda(v_1, \ldots, v_m) = (\lambda v_1, \ldots, \lambda v_m) $.

3.72 例  $ \mathcal{P}_2(\mathbf{R}) \times \mathbf{R}^3 $ 中的元素是长度为 2 的组，组的第一项是  $ \mathcal{P}_2(\mathbf{R}) $ 中的元素，第二项是  $ \mathbf{R}^3 $ 中的元素。例如  $ (5 - 6x + 4x^2, (3, 8, 7)) \in \mathcal{P}_2(\mathbf{R}) \times \mathbf{R}^3 $。

以下命题表明向量空间的积按上面定义的加法和标量乘法构成向量空间.

### 3.73 向量空间的积是向量空间

设  $ V_1, \ldots, V_m $ 均为 F 上的向量空间，则  $ V_1 \times \cdots \times V_m $ 是 F 上的向量空间。

上述结果的证明留给读者．注意  $ V_{1} \times \cdots \times V_{m} $ 的加法单位元是  $ (0, \ldots, 0) $，这里第 j 个位置的 0 是  $ V_{j} $ 的加法单位元． $ (v_{1}, \ldots, v_{m}) \in V_{1} \times \cdots \times V_{m} $ 的加法逆元是  $ (-v_{1}, \ldots, -v_{m}) $．

3.74 例  $ R^{2} \times R^{3} $ 等于  $ R^{5} $ 吗？ $ R^{2} \times R^{3} $ 同构于  $ R^{5} $ 吗？

解  $  \mathbf{R}^2 \times \mathbf{R}^3  $ 的元素是组  $  \left((x_1, x_2), (x_3, x_4, x_5)\right)  $，其中  $  x_1, x_2, x_3, x_4, x_5 \in \mathbf{R}  $.

 $  \mathbf{R}^5  $ 的元素是组  $  (x_1, x_2, x_3, x_4, x_5)  $，其中  $  x_1, x_2, x_3, x_4, x_5 \in \mathbf{R}  $.