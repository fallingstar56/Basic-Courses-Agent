证明 设  $ T \in \mathcal{L}(V, W) $. 则

 $$ \begin{aligned}\dim null T&=\dim V-\dim range T\\&\geq\dim V-\dim W\\&>0,\end{aligned} $$ 

其中等号成立是由于线性映射基本定理 3.22. 上述不等式表明 dim null T > 0. 这意味着 null T 包含非零向量. 因此 T 不是单的（由于 3.16）.

下面的命题表明从一个有限维向量空间到更大的向量空间的线性映射不可能是满的，这里“更大”是用维数来衡量的.

### 3.24 到更大维数向量空间的线性映射不是满的

如果 V 和 W 都是有限维向量空间，并且  $ \dim V < \dim W $，那么 V 到 W 的线性映射一定不是满的.

证明 设  $ T \in \mathcal{L}(V, W) $. 则由线性映射基本定理 3.22 可得

 $$ \begin{aligned}\dim range T&=\dim V-\dim null T\\&\leq\dim V\\&<\dim W,\end{aligned} $$ 

上述不等式表明  $ \dim \text{range } T < \dim W $．这意味着 null T 不等于 W．因此 T 不是满的．

我们马上就会看到 3.23 和 3.24 在线性方程组的理论中有重要的应用，其想法是用线性映射来表述线性方程组的问题.

3.25 例 用线性映射重述齐次线性方程组是否有非零解的问题.

解 取定正整数 m 和 n，设  $ A_{j,k} \in \mathbf{F} $ （其中  $ j = 1, \ldots, m, k = 1, \ldots, n $）。考虑齐次线性方程组

这里齐次的意思是每个方程右端的常数项都等于0.



 $$ \left\{\begin{aligned}\sum_{k=1}^{n}A_{1,k}x_{k}&=0,\\ &\vdots\\ \sum_{k=1}^{n}A_{m,k}x_{k}&=0.\end{aligned}\right. $$ 

显然  $ x_{1}=\cdots=x_{n}=0 $ 是上述方程组的一个解．问题是，是否还有其他解．

定义  $ T: F^n \to F^m $ 如下：

 $$ T(x_{1},\cdots,x_{n})=\big(\sum_{k=1}^{n}A_{1,k}x_{k},\cdots,\sum_{k=1}^{n}A_{m,k}x_{k}\big). $$ 

方程  $ T(x_{1},\ldots,x_{n})=0 $（其中 0 是  $ F^{m} $ 的加法单位元，即，由 0 组成的长度为 m 的组）与上述齐次线性方程组是一样的.