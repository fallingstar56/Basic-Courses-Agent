18 设 V 和 W 都是有限维的．证明存在一个 V 到 W 的满的线性映射当且仅当  $ \dim V \geq \dim W $．

19 设 V 和 W 都是有限维的，且 U 是 V 的子空间．证明存在  $ T \in \mathcal{L}(V, W) $ 使得  $ null T = U $ 当且仅当  $ \dim U \geq \dim V - \dim W $.

20 设 W 是有限维的， $ T \in \mathcal{L}(V, W) $。证明 T 是单的当且仅当存在  $ S \in \mathcal{L}(W, V) $ 使得 ST 是 V 上的恒等映射。

21 设 V 是有限维的， $ T \in \mathcal{L}(V, W) $。证明 T 是满的当且仅当存在  $ S \in \mathcal{L}(W, V) $ 使得 TS 是 W 上的恒等映射。

22 设 U 和 V 都是有限维的向量空间，并设  $ S \in \mathcal{L}(V, W) $,  $ T \in \mathcal{L}(U, V) $. 证明

 $$ \dim\operatorname{n u l l}S T\leq\dim\operatorname{n u l l}S+\dim\operatorname{n u l l}T. $$ 

23 设 U 和 V 都是有限维的向量空间，并设  $ S \in \mathcal{L}(V, W), T \in \mathcal{L}(U, V) $. 证明

 $$ \operatorname{dim range}ST\leq\operatorname*{min}\{\operatorname{dim range}S,\operatorname{dim range}T\}. $$ 

24 设 W 是有限维的，并设  $ T_1, T_2 \in \mathcal{L}(V, W) $。证明 null  $ T_1 \subset \text{null} T_2 $ 当且仅当存在  $ S \in \mathcal{L}(W, W) $ 使得  $ T_2 = ST_1 $。

25 设  $ V $ 是有限维的，并设  $ T_1, T_2 \in \mathcal{L}(V, W) $。证明 range  $ T_1 \subset \text{range} T_2 $ 当且仅当存在  $ S \in \mathcal{L}(V, V) $ 使得  $ T_1 = T_2S $。

26 设  $ D \in \mathcal{L}(\mathcal{P}(\mathbf{R}), \mathcal{P}(\mathbf{R})) $ 使得对每个非常数多项式  $ p \in \mathcal{P}(\mathbf{R}) $ 均有  $ \deg D p = (\deg p) - 1 $。证明 D 是满的。

这里采用 $D$ 这个记号是想让你联想到微分映射，它将 $p$ 变为 $p'$. 即使不知道多项式的求导公式（但知道它将多项式的次数降低 1 次），我们也可以使用这个习题来证明，对于每个多项式 $q \in \mathcal{P}(\mathbf{R})$，均存在多项式 $p \in \mathcal{P}(\mathbf{R})$ 使得 $p' = q$.

27 设  $ p \in \mathcal{P}(\mathbf{R}) $。证明存在多项式  $ q \in \mathcal{P}(\mathbf{R}) $ 使得  $ 5q'' + 3q' = p $。

本题可以不用线性代数的知识来做，不过用线性代数的知识做更有意思。

28 设  $ T \in \mathcal{L}(V, W) $，并设  $ w_1, \ldots, w_m $ 是 range  $ T $ 的基．证明存在  $ \varphi_1, \ldots, \varphi_m \in \mathcal{L}(V, \mathbf{F}) $ 使得对每个  $ v \in V $ 均有  $ T v = \varphi_1(v) w_1 + \cdots + \varphi_m(v) w_m $.

29 设  $ \varphi \in \mathcal{L}(V, \mathbf{F}) $。假定  $ u \in V $ 不属于 null  $ \varphi $。证明  $ V = \text{null} \varphi \oplus \{au : a \in \mathbf{F}\} $。

30 设  $ \varphi_{1} $ 和  $ \varphi_{2} $ 都是 V 到 F 的线性映射，且具有相同的零空间．证明存在常数  $ c \in F $ 使得  $ \varphi_{1} = c\varphi_{2} $．

31 给出  $ R^{5} $ 到  $ R^{2} $ 的两个线性映射  $ T_{1} $ 和  $ T_{2} $，使得它们具有相同的零空间，但  $ T_{1} $ 不是  $ T_{2} $ 的标量倍.