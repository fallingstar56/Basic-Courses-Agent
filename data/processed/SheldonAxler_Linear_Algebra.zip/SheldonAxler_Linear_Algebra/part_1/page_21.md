3.44 记号  $ A_{j} $， $ A_{k} $

设 A 是  $ m \times n $ 矩阵.

• 若  $ 1 \leq j \leq m $，则  $ A_{j} $。表示 A 的第 j 行组成的  $ 1 \times n $ 矩阵。

• 若  $ 1 \leq k \leq n $，则 A.  $ k $ 表示 A 的第  $ k $ 列组成的  $ m \times 1 $ 矩阵。

3.45 例 若  $ A=\left(\begin{array}{ccc}8 & 4 & 5 \\ 1 & 9 & 7\end{array}\right) $，则  $ A_{2,2} $ 是 A 的第 2 行，而  $ A_{,2} $ 是 A 的第 2 列。也就是说，

 $$ A_{2,\cdot}=\left(\begin{array}{ccc}1&9&7\end{array}\right)\quad 和 \quad A_{\cdot,2}=\left(\begin{array}{c}4\\ \\ 9\end{array}\right) $$ 

1×n矩阵与n×1矩阵的乘积是1×1矩阵．然而，我们经常把1×1矩阵和它的元素看成是一样的.

3.46 例  $ \left(\begin{array}{cc}3 & 4\end{array}\right)\left(\begin{array}{c}6 \\ 2\end{array}\right)=\left(\begin{array}{c}26\end{array}\right) $，因为  $ 3\cdot6+4\cdot2=26 $。然而，我们可以将  $ \left(\begin{array}{c}26\end{array}\right) $ 和 26 看成是一样的，写成  $ \left(\begin{array}{cc}3 & 4\end{array}\right)\left(\begin{array}{c}6 \\ 2\end{array}\right)=26 $。

下面的命题给出了理解矩阵乘法的另一种方式．AC 的第 j 行第 k 列元素等于 A 的第 j 行乘以 C 的第 k 列．

### 3.47 矩阵乘积的元素等于行乘以列

设 A 是  $ m \times n $ 矩阵，C 是  $ n \times p $ 矩阵．则对于  $ 1 \leq j \leq m $ 和  $ 1 \leq k \leq p $， $ (AC)_{j,k} = A_{j,k}, C_{,k} $

上述结果的证明由定义立得.

3.48 例 上述结果和例 3.46 说明了为什么例 3.42 中矩阵乘积的第 2 行第 1 列的元素等于 26.

下面的命题给出了理解矩阵乘法的另一种方式：它是说 AC 的第 k 列等于 A 乘以 C 的第 k 列.