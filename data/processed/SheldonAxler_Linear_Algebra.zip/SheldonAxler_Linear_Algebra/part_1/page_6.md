上述结果的证明留给读者.

线性映射的乘法不是交换的．也就是说，ST = TS 未必成立，即使这个等式的两边都有意义．

3.10 例 设  $ D \in \mathcal{L}(\mathcal{P}(\mathbf{R}), \mathcal{P}(\mathbf{R})) $ 是例 3.4 定义的微分映射， $ T \in \mathcal{L}(\mathcal{P}(\mathbf{R}), \mathcal{P}(\mathbf{R})) $ 是本节前面定义的乘  $ x^2 $ 映射，证明  $ TD \neq DT $.

证明 我们有

 $$ \begin{aligned}\left((TD)p\right)(x)&=x^{2}p^{\prime}(x)\quad 但 \quad\left((DT)p\right)(x)=x^{2}p^{\prime}(x)+2xp(x).\end{aligned} $$ 

也就是说，先乘以  $ x^{2} $ 再微分和先微分再乘以  $ x^{2} $ 是不同的.

### 3.11 线性映射将 0 映为 0

设 T 是 V 到 W 的线性映射．则  $ T(0)=0 $

证明 利用加性，我们有

 $$ T(0)=T(0+0)=T(0)+T(0). $$ 

在上式两端都加上  $ T(0) $ 的加法逆元，即得  $ T(0)=0 $.

### 习题 3.A

1 设  $ b, c \in \mathbb{R} $. 定义  $ T: \mathbb{R}^3 \to \mathbb{R}^2 $ 如下:

 $$ T(x,y,z)=(2x-4y+3z+b,6x+cxyz). $$ 

证明 T 是线性的当且仅当 b = c = 0.

2 设  $ b, c \in \mathbb{R} $. 定义  $ T: \mathcal{P}(\mathbf{R}) \to \mathbf{R}^2 $ 如下:

 $$ T p=\Big(3p(4)+5p^{\prime}(6)+b p(1)p(2),\int_{-1}^{2}x^{3}p(x)\mathrm{d}x+c\sin p(0)\Big). $$ 

证明 T 是线性的当且仅当 b = c = 0.

3 设  $ T \in \mathcal{L}(\mathbf{F}^n, \mathbf{F}^m) $. 证明存在标量  $ A_{j,k} \in \mathbf{F} $（其中  $ j = 1, \ldots, m, k = 1, \ldots, n $）使得对任意  $ (x_1, \ldots, x_n) \in \mathbf{F}^n $ 都有

 $$ T(x_{1},\cdots,x_{n})=(A_{1,1}x_{1}+\cdots+A_{1,n}x_{n},\cdots,A_{m,1}x_{1}+\cdots+A_{m,n}x_{n}). $$ 

本题表明 T 具有在例 3.4 的最后一条中提及的那种形式.

4 设  $ T \in \mathcal{L}(V, W) $ 且  $ v_1, \ldots, v_m $ 是  $ V $ 中的向量组，使得  $ T v_1, \ldots, T v_m $ 在  $ W $ 中是线性无关的．证明  $ v_1, \ldots, v_m $ 是线性无关的．

5 证明 3.7 中的结论.