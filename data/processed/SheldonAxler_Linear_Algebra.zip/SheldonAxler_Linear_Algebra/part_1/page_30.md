 $$ \dim range T=\dim V-\dim null T=\dim V. $$ 

于是 range T = V. 从而 T 是满的. 因此 (b) 蕴涵 (c).

现在假设(c)成立，T 是满的，从而 range T = V 。由线性映射基本定理 3.22，

 $$ \dim null T=\dim V-\dim range T=0. $$ 

于是 null  $ T = \{0\} $. 故 T 是单的（由于 3.16），从而 T 是可逆的（已知 T 是满的）. 因此 (c) 蕴涵 (a).

下面的例子展示了上述命题的用处．虽然下面例子的结果也可以不用线性代数证明，但是用线性代数来证明更为简洁容易．

3.70 例 证明对每个多项式  $ q \in \mathcal{P}(\mathbf{R}) $ 都存在一个多项式  $ p \in \mathcal{P}(\mathbf{R}) $ 使得

 $$ \left((x^{2}+5x+7)p\right)^{\prime\prime}=q. $$ 

证明 例 3.68 表明 3.69 之妙法不能用于无限维向量空间  $ \mathcal{P}(\mathbf{R}) $ 。然而每个非零多项式 q 都有次数 m 。仅考虑  $ \mathcal{P}_{m}(\mathbf{R}) $ ，我们就可以在有限维向量空间上做了。

设  $ q \in \mathcal{P}_m(\mathbf{R}) $。定义  $ T: \mathcal{P}_m(\mathbf{R}) \to \mathcal{P}_m(\mathbf{R}) $ 为  $ Tp = \left((x^2 + 5x + 7)p\right)^{\prime\prime} $。

用  $ (x^{2} + 5x + 7) $ 去乘一个非零多项式，将使这个多项式的次数增加 2，然后做两次微分次数又降低 2，所以 T 的确是  $ \mathcal{P}_{m}(\mathbf{R}) $ 上的算子.

二阶导数为 0 的多项式形如  $ ax + b $，其中  $ a, b \in \mathbb{R} $。于是  $ nullT = \{0\} $。因此 T 是单的。

现在 3.69 表明 T 是满的．因此有多项式  $ p \in \mathcal{P}_m(\mathbf{R}) $ 使得  $ (x^2 + 5x + 7)p)'' = q $．

6. A 节的习题 30 给出了 3.69 的一个类似但更炫的应用．这个习题中的结果不使用线性代数很难证明.

### 习题 3.D

1 设  $ T \in \mathcal{L}(U, V) $ 和  $ S \in \mathcal{L}(V, W) $ 都是可逆的线性映射．证明  $ ST \in \mathcal{L}(U, W) $ 可逆且  $ (ST)^{-1} = T^{-1}S^{-1} $

2 设 V 是有限维的且  $ \dim V > 1 $．证明 V 上不可逆的算子构成的集合不是  $ \mathcal{L}(V) $ 的子空间.

3 设 V 是有限维的，U 是 V 的子空间，且  $ S \in \mathcal{L}(U, V) $。证明：存在可逆的算子  $ T \in \mathcal{L}(V) $ 使得对每个  $ u \in U $ 均有  $ Tu = Su $ 当且仅当 S 是单射。

4 设 W 是有限维的， $ T_1, T_2 \in \mathcal{L}(V, W) $。证明： $ \text{null} T_1 = \text{null} T_2 $ 当且仅当存在可逆的算子  $ S \in \mathcal{L}(W) $ 使得  $ T_1 = ST_2 $。

5 设 V 是有限维的， $ T_1, T_2 \in \mathcal{L}(V, W) $。证明： $ \text{range} T_1 = \text{range} T_2 $ 当且仅当存在可逆的算子  $ S \in \mathcal{L}(V) $ 使得  $ T_1 = T_2 S $。