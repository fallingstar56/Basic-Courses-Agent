3.86 定义 V/U 上的加法和标量乘法（addition and scalar multiplication on V/U）

设 U 是 V 的子空间．则 V/U 上的加法和标量乘法定义为：对任意  $ v, w \in V $ 和  $ \lambda \in F $，

 $$ \left(\nu+U\right)+\left(w+U\right)=\left(\nu+w\right)+U, $$ 

 $$ \lambda(\nu+U)=(\lambda\nu)+U. $$ 

作为以下命题证明的一部分，我们将证明上述定义是有意义的.

### 3.87 商空间是向量空间

设 U 是 V 的子空间．则 V/U 按照上面定义的加法和标量乘法构成向量空间.

证明 在上面定义的  $ V/U $ 上的加法和标量乘法中，一个潜在的问题是平行于  $ U $ 的仿射子集的表示并不是唯一的。具体来说，设  $ v, w \in V $，假设  $ \hat{v}, \hat{w} \in V $ 使得  $ v + U = \hat{v} + U $ 和  $ w + U = \hat{w} + U $。要证明上面给出的  $ V/U $ 上的加法是有意义的，必须证明  $ (v + w) + U = (\hat{v} + \hat{w}) + U $。

由 3.85 有

 $$ \nu-\hat{\nu}\in U,\quad w-\hat{w}\in U. $$ 

因为 $U$ 是 $V$ 的子空间，所以在加法下封闭，这说明 $(v - \hat{v}) + (w - \hat{w}) \in U$。于是 $(v + w) - (\hat{v} + \hat{w}) \in U$。再使用 3.85 可得

 $$ \left(\nu+w\right)+U=\left(\hat{\nu}+\hat{w}\right)+U. $$ 

因此 V/U 上的加法定义是合理的.

类似地，设  $ \lambda \in \mathbf{F} $。因为  $ U $ 是  $ V $ 的子空间，所以在标量乘法下封闭，从而有  $ \lambda(v - \hat{v}) \in U $。于是  $ \lambda v - \lambda \hat{v} \in U $。因此 3.85 表明  $ (\lambda v) + U = (\lambda \hat{v}) + U $。所以  $ V/U $ 上的标量乘法的定义是有意义的。

既然我们已经在 V/U 上定义了加法和标量乘法，验证这些运算使得 V/U 成为向量空间就是简单的事了，留给读者．注意 V/U 上的加法单位元是  $ 0 + U $（等于 U）， $ v + U $ 的加法逆元是  $ (-v) + U $．

下面的概念将给出计算 V/U 的维数的简单方法.

### 3.88 定义 商映射（quotient map）， $ \pi $

设 $U$ 是 $V$ 的子空间．商映射 $\pi$ 是如下定义的线性映射 $\pi: V \to V/U$：对任意 $v \in V$，

 $$ \pi(\nu)=\nu+U. $$ 