- 向量  $ x \in \mathbf{F}^n $ 关于标准基的矩阵就是以  $ x $ 的坐标为元素而得到的  $ n \times 1 $ 矩阵。也就是说，若  $ x = (x_1, \ldots, x_n) \in \mathbf{F}^n $，则

 $$ \begin{align*}\mathcal{M}(x)=\left(\begin{array}{c}x_1\\ \vdots\\ x_n\end{array}\right).\end{align*} $$ 

有时我们想把 V 中的元素视为  $ n \times 1 $ 矩阵．一旦选定了  $ v_1, \ldots, v_n $，函数  $ M $ 将  $ v \in V $ 变为  $ M(v) $，就是  $ V $ 到  $ F^n, 1 $ 的同构，这就实现了上述想法．

回想一下，若 A 是  $ m \times n $ 矩阵，则  $ A_{,k} $ 表示 A 的第 k 列，看作一个  $ m \times 1 $ 矩阵．下面的命题计算  $ \mathcal{M}(T\nu_{k}) $ 关于 W 的基  $ w_{1}, \ldots, w_{m} $ 的矩阵．

3.64  $ \mathcal{M}(T)_{,k} = \mathcal{M}(T\nu_k) $.

设  $ T \in \mathcal{L}(V, W) $， $ \nu_1, \ldots, \nu_n $ 是 V 的基， $ w_1, \ldots, w_m $ 是 W 的基。设  $ 1 \leq k \leq n $。则  $ \mathcal{M}(T) $ 的第 k 列（记为  $ \mathcal{M}(T)_{,k} $）等于  $ \mathcal{M}(T\nu_k) $。

证明 由  $ \mathcal{M}(T) $ 和  $ \mathcal{M}(\nu_{k}) $ 的定义立得.

下面的命题表明线性映射的矩阵、向量的矩阵以及矩阵乘法是如何联系到一起的.

### 3.65 线性映射的作用类似于矩阵乘

设  $ T \in \mathcal{L}(V, W) $,  $ v \in V $. 设  $ v_1, \ldots, v_n $ 是  $ V $ 的基,  $ w_1, \ldots, w_m $ 是  $ W $ 的基. 则  $ \mathcal{M}(Tv) = \mathcal{M}(T) \mathcal{M}(v) $.

证明 设  $ \nu = c_{1}\nu_{1} + \cdots + c_{n}\nu_{n} $，其中  $ c_{1}, \ldots, c_{n} \in \mathbf{F} $。则

3.66

 $$ T\nu=c_{1}T\nu_{1}+\cdots+c_{n}T\nu_{n}. $$ 

因此

 $$ \begin{aligned}\mathcal{M}(T\nu)&=c_{1}\mathcal{M}(T\nu_{1})+\cdots+c_{n}\mathcal{M}(T\nu_{n})\\&=c_{1}\mathcal{M}(T).._{,1}+\cdots+c_{n}\mathcal{M}(T).._{,n}\\&=\mathcal{M}(T)\mathcal{M}(\nu),\\ \end{aligned} $$ 

这里第一个等号由 3.66 以及 M 的线性得出，第二个等号由 3.64 得出，最后一个等号由 3.52 得出.

每个  $ m \times n $ 矩阵  $ A $ 诱导一个从  $ \mathbf{F}^n $,  $ 1 $ 到  $ \mathbf{F}^m $,  $ 1 $ 的线性映射，即将  $ x \in \mathbf{F}^n $,  $ 1 $ 变为  $ Ax \in \mathbf{F}^m $,  $ 1 $ 的矩阵乘。由上述命题，通过同构  $ \mathcal{M} $，我们可以把（从有限维向量空间到有限维向量空间的）线性映射当作矩阵乘映射。具体来说，若  $ T \in \mathcal{L}(V, W) $，并将  $ v \in V $ 等同于  $ \mathcal{M}(v) \in \mathbf{F}^n $,  $ 1 $，则上述命题说，我们可以将  $ T v $ 等同于  $ \mathcal{M}(T) \mathcal{M}(v) $。