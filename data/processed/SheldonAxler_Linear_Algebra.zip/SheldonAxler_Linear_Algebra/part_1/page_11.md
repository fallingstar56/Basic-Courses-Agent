## 线性映射基本定理

下面的结果非常重要，所以它有一个引人注目的名字.

### 3.22 线性映射基本定理

设 V 是有限维的， $ T \in \mathcal{L}(V, W) $。则 range T 是有限维的并且

 $$ \dim V=\dim null T+\dim range T. $$ 

证明 设  $ u_1, \ldots, u_m $ 是 null  $ T $ 的基，则  $ \dim \text{null} T = m $，且线性无关组  $ u_1, \ldots, u_m $ 可以扩充成  $ V $ 的基  $ u_1, \ldots, u_m, v_1, \ldots, v_n $（由于 2.33）。于是  $ \dim V = m + n $。为完成证明，只需证明 range  $ T $ 是有限维的，并且  $ \dim \text{range} T = n $。为此，往证  $ T v_1, \ldots, T v_n $ 是 range  $ T $ 的基。

设  $ v \in V $。因为  $ u_1, \ldots, u_m, v_1, \ldots, v_n $ 张成  $ V $，所以

 $$ \nu=a_{1}u_{1}+\cdots+a_{m}u_{m}+b_{1}\nu_{1}+\cdots+b_{n}\nu_{n}, $$ 

其中的这些 a 和 b 都含于 F. 用 T 作用上式两端可得

 $$ T\nu=b_{1}T\nu_{1}+\cdots+b_{n}T\nu_{n}, $$ 

其中没有出现形如  $ Tu_j $ 的项，这是因为每个  $ u_j \in \text{null} T $。上式表明  $ Tv_1, \ldots, Tv_n $ 张成 range  $ T $。特别地，range  $ T $ 是有限维的。

为了证明  $ Tv_1, \ldots, Tv_n $ 是线性无关的，设  $ c_1, \ldots, c_n \in \mathbf{F} $ 并且

 $$ c_{1}T\nu_{1}+\cdots+c_{n}T\nu_{n}=0. $$ 

那么

 $$ T(c_{1}\nu_{1}+\cdots+c_{n}\nu_{n})=0. $$ 

因此

 $$ c_{1}\nu_{1}+\cdots+c_{n}\nu_{n}\in\mathrm{n u l l}T. $$ 

由于  $ u_{1},\ldots,u_{m} $ 张成 null T，我们有

 $$ c_{1}\nu_{1}+\cdots+c_{n}\nu_{n}=d_{1}u_{1}+\cdots+d_{m}u_{m}, $$ 

其中的这些 d 都含于 F．这个等式表明，所有的 c（和 d）都是 0（因为  $ u_{1},\ldots,u_{m}, $  $ v_{1},\ldots,v_{n} $ 线性无关）．于是  $ Tv_{1},\ldots,Tv_{n} $ 是线性无关的，故为 range T 的基．

现在我们可以证明，从一个有限维向量空间到更小的向量空间的线性映射不可能是单的，这里“更小”是用维数来衡量的。

### 3.23 到更小维数向量空间的线性映射不是单的

如果 V 和 W 都是有限维向量空间，并且  $ \dim V > \dim W $，那么 V 到 W 的线性映射一定不是单的.