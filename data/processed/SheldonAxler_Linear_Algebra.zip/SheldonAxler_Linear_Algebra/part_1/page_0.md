6 (a) 设  $ U = \{p \in \mathcal{P}_4(\mathbf{F}) : p(2) = p(5)\} $，求  $ U $ 的一个基.

(b) 将 (a) 中求得的基扩充为  $ \mathcal{P}_{4}(\mathbf{F}) $ 的基.

(c) 求  $ \mathcal{P}_4(\mathbf{F}) $ 的一个子空间 W 使得  $ \mathcal{P}_4(\mathbf{F}) = U \oplus W $.

7 (a) 设  $ U = \{p \in \mathcal{P}_4(\mathbf{F}) : p(2) = p(5) = p(6)\} $，求  $ U $ 的一个基.

(b) 将 (a) 中求得的基扩充为  $ \mathcal{P}_{4}(\mathbf{F}) $ 的基.

(c) 求  $ \mathcal{P}_{4}(\mathbf{F}) $ 的一个子空间 W 使得  $ \mathcal{P}_{4}(\mathbf{F}) = U \oplus W $.

8 (a) 设  $ U = \{p \in \mathcal{P}_4(\mathbf{R}) : \int_{-1}^{1} p = 0\} $，求  $ U $ 的一个基.

(b) 将 (a) 中求得的基扩充为  $ \mathcal{P}_{4}(\mathbf{R}) $ 的基.

(c) 求  $ \mathcal{P}_4(\mathbf{R}) $ 的一个子空间  $ W $ 使得  $ \mathcal{P}_4(\mathbf{R}) = U \oplus W $.

9 设  $ v_{1}, \ldots, v_{m} $ 在 V 中是线性无关的，并设  $ w \in V $．证明

 $$ \dim span(v_{1}+w,\cdots,v_{m}+w)\geq m-1. $$ 

10 假设  $ p_{0}, p_{1}, \ldots, p_{m} \in \mathcal{P}(\mathbf{F}) $ 使得每个  $ p_{j} $ 的次数为 j. 证明  $ p_{0}, p_{1}, \ldots, p_{m} $ 是  $ \mathcal{P}_{m}(\mathbf{F}) $ 的基.

11 设 U 和 W 是  $ R^{8} $ 的子空间使得  $ \dim U = 3 $,  $ \dim W = 5 $,  $ U + W = R^{8} $. 证明  $ R^{8} = U \oplus W $.

12 设 U 和 W 均为  $ R^9 $ 的 5 维子空间．证明  $ U \cap W \neq \{0\} $．

13 设 U 和 W 均为  $ C^{6} $ 的 4 维子空间. 证明在  $ U \cap W $ 中存在两个向量使得其中任何一个都不是另一个的标量倍.

14 设  $ U_{1}, \ldots, U_{m} $ 均为 V 的有限维子空间. 证明  $ U_{1} + \cdots + U_{m} $ 是有限维的且

 $$ \dim(U_{1}+\cdots+U_{m})\leq\dim U_{1}+\cdots+\dim U_{m}. $$ 

15 设 V 是有限维的且  $ \dim V = n \geq 1 $。证明存在 V 的 1 维子空间  $ U_1, \ldots, U_n $ 使得

 $$ V=U_{1}\oplus\cdots\oplus U_{n}. $$ 

16 设  $ U_{1},\ldots,U_{m} $ 均为 V 的有限维子空间，使得  $ U_{1}+\cdots+U_{m} $ 是直和．证明  $ U_{1}\oplus\cdots\oplus U_{m} $ 是有限维的且

 $$ \dim U_{1}\oplus\cdots\oplus U_{m}=\dim U_{1}+\cdots+\dim U_{m}. $$ 

本题深化了子空间的直和与子集的不交并这两个概念之间的类比．特别地，把本题与下面的明显陈述比较一下：如果一个集合写成了有限子集的不交并，那么这个集合的元素个数等于这些不相交子集的元素个数之和.

17 通过与有限集合中三个子集之并的元素个数公式相类比，我们可能猜测，如果  $ U_{1}, U_{2}, U_{3} $ 是有限维向量空间的子空间，那么

 $$ \begin{aligned}\dim(U_{1}+U_{2}+U_{3})&=\dim U_{1}+\dim U_{2}+\dim U_{3}\\&\quad-\dim(U_{1}\cap U_{2})-\dim(U_{1}\cap U_{3})-\dim(U_{2}\cap U_{3})\\&\quad+\dim(U_{1}\cap U_{2}\cap U_{3}).\end{aligned} $$ 

证明它或给出反例.