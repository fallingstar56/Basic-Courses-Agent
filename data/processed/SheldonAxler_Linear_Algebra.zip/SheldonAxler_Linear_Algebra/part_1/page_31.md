6 设 $V$ 和 $W$ 是有限维的，$T_1, T_2 \in \mathcal{L}(V, W)$。证明：存在可逆的算子 $R \in \mathcal{L}(V)$ 和 $S \in \mathcal{L}(W)$ 使得 $T_1 = ST_2 R$ 当且仅当 $\dim \text{null } T_1 = \dim \text{null } T_2$。

7 设 V 和 W 是有限维的， $ v \in V $， $ E = \{T \in \mathcal{L}(V, W) : Tv = 0\} $.

(a) 证明 E 是  $ \mathcal{L}(V, W) $ 的子空间.

(b) 假设  $ v \neq 0 $，则  $ \dim E $ 等于多少？

8 设 V 是有限维的， $ T:V \to W $ 是 V 到 W 的满的线性映射．证明存在 V 的子空间 U 使得  $ T|_{U} $ 是 U 到 W 的同构．（这里  $ T|_{U} $ 表示函数 T 限制在 U 上．也就是说， $ T|_{U} $ 是一个函数，其定义域为 U，且对任意  $ u \in U $ 有  $ T|_{U}(u) = Tu $.）

9 设 V 是有限维的， $ S, T \in \mathcal{L}(V) $。证明 ST 可逆当且仅当 S 和 T 都可逆。

10 设 V 是有限维的， $ S, T \in \mathcal{L}(V) $。证明 ST = I 当且仅当 TS = I。

11 设 V 是有限维的， $ S, T, U \in \mathcal{L}(V) $ 且 STU = I. 证明 T 可逆且  $ T^{-1} = US $.

12 说明上题的结果在 V 不是有限维时未必成立.

13 设 V 是有限维的，并设  $ R, S, T \in \mathcal{L}(V) $ 使得 RST 是满射．证明 S 是单射．

14 设  $ v_{1}, \ldots, v_{n} $ 是 V 的基. 映射  $ T: V \to F^{n,1} $ 定义为  $ T v = M(v) $，这里  $ M(v) $ 是  $ v \in V $ 关于基  $ v_{1}, \ldots, v_{n} $ 的矩阵. 证明 T 是 V 到  $ F^{n,1} $ 的同构.

15 证明  $ F^{n,1} $ 到  $ F^{m,1} $ 的每个线性映射都是矩阵乘．也就是说，若  $ T \in \mathcal{L}(\mathbf{F}^{n,1}, \mathbf{F}^{m,1}) $，则存在  $ m \times n $ 矩阵 A 使得对每个  $ x \in \mathbf{F}^{n,1} $ 都有 Tx = Ax.

16 设  $ V $ 是有限维的， $ T \in \mathcal{L}(V) $。证明： $ T $ 是标量乘以恒等映射当且仅当对每个  $ S \in \mathcal{L}(V) $ 均有  $ ST = TS $。

17 设 $V$ 是有限维的，且 $\mathcal{E}$ 是 $\mathcal{L}(V)$ 的子空间使得对所有 $S \in \mathcal{L}(V)$ 和所有 $T \in \mathcal{E}$ 均有 $ST \in \mathcal{E}$ 和 $TS \in \mathcal{E}$。证明 $\mathcal{E} = \{0\}$ 或 $\mathcal{E} = \mathcal{L}(V)$。

18 证明 V 和  $ \mathcal{L}(\mathbf{F}, V) $ 是同构的向量空间.

19 设  $ T \in \mathcal{L}(\mathcal{P}(\mathbf{R})) $ 是单的，且对每个非零多项式  $ p \in \mathcal{P}(\mathbf{R}) $ 均有  $ \deg T p \leq \deg p $.

(a) 证明 T 是满的.

(b) 证明对每个非零的  $ p \in \mathcal{P}(\mathbf{R}) $ 均有  $ \deg T p = \deg p $.

20 设  $ n $ 是正整数， $ A_{i,j} \in \mathbf{F}, i, j = 1, \ldots, n $。证明下面两个陈述等价（注意：以下方程组中方程的数目都等于变量的数目）：

(a) 平凡解  $ x_{1}=\cdots=x_{n}=0 $ 是下面的齐次方程组的唯一解：

 $$ \begin{aligned}&\left\{\begin{aligned}\sum_{k=1}^{n}A_{1,k}x_{k}&=0,\\&\vdots\\\sum_{k=1}^{n}A_{n,k}x_{k}&=0.\end{aligned}\right.\end{aligned} $$ 