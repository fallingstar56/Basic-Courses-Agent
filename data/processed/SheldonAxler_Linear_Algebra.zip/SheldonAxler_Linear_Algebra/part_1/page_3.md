这个函数是线性的，此结论只是把关于微分的下述基本结果换了一种说法：对任意可微函数  $ f, g $ 和常数  $ \lambda $ 都有  $ (f + g)' = f' + g', (\lambda f)' = \lambda f' $.

## 积分（integration）

定义  $ T \in \mathcal{L}(\mathcal{P}(\mathbf{R}), \mathbf{R}) $ 如下：

 $$ T p=\int_{0}^{1}p(x)\mathrm{d}x. $$ 

这个函数是线性的，此结论只是把关于积分的下述基本结果换了一种说法：两个函数之和的积分等于这两个函数积分的和，常数与函数乘积的积分等于常数乘以函数的积分.

乘以  $ x^{2} $ (multiplication by  $ x^{2} $)

定义  $ T \in \mathcal{L}(\mathcal{P}(\mathbf{R}), \mathcal{P}(\mathbf{R})) $ 如下：对所有  $ x \in \mathbf{R} $

 $$ (T p)(x)=x^{2}p(x). $$ 

## 向后移位（backward shift）

回忆一下， $  \mathbf{F}^\infty  $ 表示  $  \mathbf{F}  $ 中元素的无穷序列构成的向量空间．定义  $  T \in \mathcal{L}(\mathbf{F}^\infty, \mathbf{F}^\infty)  $ 如下：

 $$ T(x_{1},x_{2},x_{3},\cdots)=(x_{2},x_{3},\cdots). $$ 

从  $ R^{3} $ 到  $ R^{2} $ （from  $ R^{3} $ to  $ R^{2} $）

定义  $ T \in \mathcal{L}(\mathbf{R}^3, \mathbf{R}^2) $ 如下：

 $$ T(x,y,z)=(2x-y+3z,7x+5y-6z). $$ 

从  $ F^{n} $ 到  $ F^{m} $ （from  $ F^{n} $ to  $ F^{m} $）

把前一个例子推广一下，设  $ m $ 和  $ n $ 都是正整数， $ A_{j,k} \in \mathbf{F}, j = 1, \ldots, m, k = 1, \ldots, n $，定义  $ T \in \mathcal{L}(\mathbf{F}^n, \mathbf{F}^m) $ 如下：

 $$ T(x_{1},\cdots,x_{n})=(A_{1,1}x_{1}+\cdots+A_{1,n}x_{n},\cdots,A_{m,1}x_{1}+\cdots+A_{m,n}x_{n}). $$ 

事实上从  $ F^{n} $ 到  $ F^{m} $ 的每个线性映射都是这种形式的.

以下命题的存在性部分表明线性映射可根据其在一个基上的取值来构造，而唯一性部分表明一个线性映射完全由其在基上的取值确定.

### 3.5 线性映射与定义域的基

设  $ v_1, \ldots, v_n $ 是  $ V $ 的基， $ w_1, \ldots, w_n \in W $。则存在唯一一个线性映射  $ T: V \to W $ 使得对任意  $ j = 1, \ldots, n $ 都有

 $$ \begin{align*}Tv_j=w_j.\end{align*} $$ 