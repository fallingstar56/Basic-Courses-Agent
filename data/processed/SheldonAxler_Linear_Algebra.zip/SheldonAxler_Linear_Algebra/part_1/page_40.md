向量空间  $ \mathcal{L}(V,\mathbf{F}) $ 也有一个特别的名字和一个特别的记号：

3.94 定义 对偶空间（dual space）， $ V' $
V 上的所有线性泛函构成的向量空间称为 V 的对偶空间，记为  $ V' $。也就是说， $ V' = \mathcal{L}(V, \mathbf{F}) $。

3.95  $ \dim V' = \dim V $
设 V 是有限维的．则  $ V' $ 也是有限维的，且  $ \dim V' = \dim V $

证明 由 3.61 证得.

前面的 3.5 表明，在下面的定义中每个  $ \varphi_{j} $ 都是合理定义的.

### 3.96 定义 对偶基（dual basis）

设  $ v_{1},\ldots,v_{n} $ 是 V 的基，则  $ v_{1},\ldots,v_{n} $ 的对偶基是  $ V' $ 中的元素组  $ \varphi_{1},\ldots,\varphi_{n} $，其中每个  $ \varphi_{j} $ 都是 V 上的线性泛函，使得

 $$ \varphi_{j}(\nu_{k})=\begin{cases}1,& 当 k=j,\\0,& 当 k\neq j.\end{cases} $$ 

3.97 例 求  $ F^{n} $ 的标准基  $ e_{1},\ldots,e_{n} $ 的对偶基.

解 对于  $ 1 \leq j \leq n $，定义  $ \varphi_j $ 是  $ \mathbf{F}^n $ 上的线性泛函，它将  $ \mathbf{F}^n $ 中的向量变为它的第  $ j $ 个坐标。也就是说，对于  $ (x_1, \ldots, x_n) \in \mathbf{F}^n $，

 $$ \varphi_{j}(x_{1},\cdots,x_{n})=x_{j}. $$ 

显然

 $$ \varphi_{j}(e_{k})=\begin{cases}1,& 当 k=j,\\0,& 当 k\neq j.\end{cases} $$ 

于是  $ \varphi_{1},\ldots,\varphi_{n} $ 是  $ F^{n} $ 的标准基  $ e_{1},\ldots,e_{n} $ 的对偶基.

以下命题表明对偶基的确是基．所以“对偶基”这个术语名正言顺．

### 3.98 对偶基是对偶空间的基

设 V 是有限维的．则 V 的一个基的对偶基是  $ V' $ 的基.

证明 设  $ v_{1},\ldots,v_{n} $ 是 V 的基. 用  $ \varphi_{1},\ldots,\varphi_{n} $ 表示其对偶基.

为了证明  $ \varphi_{1},\ldots,\varphi_{n} $ 是  $ V' $ 的一组线性无关的元素，设  $ a_{1},\ldots,a_{n}\in F $ 使得

 $$ a_{1}\varphi_{1}+\cdots+a_{n}\varphi_{n}=0. $$ 