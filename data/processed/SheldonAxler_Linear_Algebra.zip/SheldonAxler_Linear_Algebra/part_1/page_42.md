证明 前两条的证明留给读者.

为了证明第三条，设  $ \varphi \in W' $。则

 $$ (S T)^{\prime}(\varphi)=\varphi\circ(S T)=(\varphi\circ S)\circ T=T^{\prime}(\varphi\circ S)=T^{\prime}\big(S^{\prime}(\varphi)\big)=(T^{\prime}S^{\prime})(\varphi), $$ 

其中第一个、第三个和第四个等号成立是由于对偶映射的定义，第二个等号成立是因为函数的复合是结合的，最后一个等号是利用复合的定义.

对所有  $ \varphi \in W' $，上述等式的第一项都等于最后一项，这表明  $ (ST)' = T'S' $。

有些书用  $ V^{*} $ 和  $ T^{*} $ 来表示对偶空间  $ V' $ 和对偶映射  $ T' $。然而，我们将用  $ T^{*} $ 表示伴随，在第 7 章学习内积空间的线性映射时将引入这一概念。



## 线性映射的对偶的零空间和值域

本小节的目的是利用 range T 和 null T 来描述 null T' 和 range T'. 为此我们需要下面的定义.

3.102 定义 零化子（annihilator）， $ U^{0} $

对于  $ U \subset V $，U 的零化子（记为  $ U^{0} $）定义如下：

 $$ U^{0}=\{\varphi\in V^{\prime}: 对所有 u\in U 都有 \varphi(u)=0\}. $$ 

3.103 例 设 $U$ 是 $\mathcal{P}(\mathbf{R})$ 的用 $x^2$ 乘以所有多项式所得到的子空间．若 $\varphi$ 是 $\mathcal{P}(\mathbf{R})$ 上由 $\varphi(p) = p'(0)$ 定义的线性泛函，则 $\varphi \in U^0$．

对于  $ U \subset V $，零化子  $ U^{0} $ 是对偶空间  $ V' $ 的子集。于是  $ U^{0} $ 依赖于包含 U 的向量空间，所以记号  $ U_{V}^{0} $ 应该更准确。然而包含 U 的向量空间通常在上下文中是自明的，所以我们采用更简单的记号  $ U^{0} $。

3.104 例 用  $ e_{1}, e_{2}, e_{3}, e_{4}, e_{5} $ 表示  $ R^{5} $ 的标准基，用  $ \varphi_{1}, \varphi_{2}, \varphi_{3}, \varphi_{4}, \varphi_{5} $ 表示  $ (\mathbf{R}^{5})' $ 的对偶基. 设

 $$ U=\mathrm{span}(e_{1},e_{2})=\left\{(x_{1},x_{2},0,0,0)\in\mathbf{R}^{5}:x_{1},x_{2}\in\mathbf{R}\right\}. $$ 

证明  $ U^{0}=\mathrm{span}(\varphi_{3},\varphi_{4},\varphi_{5}). $

证明 回想一下（见 3.97）， $ \varphi_{j} $ 是  $ R^{5} $ 上将向量变为它的第 j 个坐标的线性泛函：

 $$ \varphi_{j}(x_{1},x_{2},x_{3},x_{4},x_{5})=x_{j}. $$ 

设  $ \varphi \in \operatorname{span}(\varphi_3, \varphi_4, \varphi_5) $。则有  $ c_3, c_4, c_5 \in \mathbb{R} $ 使得  $ \varphi = c_3\varphi_3 + c_4\varphi_4 + c_5\varphi_5 $。若  $ (x_1, x_2, 0, 0, 0) \in U $，则

 $$ \varphi(x_{1},x_{2},0,0,0)=(c_{3}\varphi_{3}+c_{4}\varphi_{4}+c_{5}\varphi_{5})(x_{1},x_{2},0,0,0)=0. $$ 