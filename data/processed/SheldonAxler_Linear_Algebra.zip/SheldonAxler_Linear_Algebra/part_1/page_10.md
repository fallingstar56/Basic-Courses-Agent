### 3.18 例 值域

• 若 $T$ 是 $V$ 到 $W$ 的零映射，即对所有 $v \in V$ 都有 $T_v = 0$，则 range $T = \{0\}$.

• 设 $T \in \mathcal{L}(\mathbf{R}^2, \mathbf{R}^3)$ 定义为 $T(x, y) = (2x, 5y, x + y)$，则
    range $T = \{(2x, 5y, x + y) : x, y \in \mathbf{R}\}$.
    range $T$ 的一个基为 $(2, 0, 1), (0, 5, 1)$.

• 设 $D \in \mathcal{L}(\mathcal{P}(\mathbf{R}), \mathcal{P}(\mathbf{R}))$ 是微分映射 $D_p = p'.$ 由于对每个多项式 $q \in \mathcal{P}(\mathbf{R})$ 均存在多项式 $p \in \mathcal{P}(\mathbf{R})$ 使得 $p' = q$，故 $D$ 的值域是 $\mathcal{P}(\mathbf{R})$.

下面的命题证明了线性映射的值域是目标空间的子空间.

有些数学家使用像这个词，意思与值域相同.



### 3.19 值域是一个子空间

若  $ T \in \mathcal{L}(V, W) $，则 range T 是 W 的子空间。

证明 设  $ T \in \mathcal{L}(V, W) $. 则  $ T(0) = 0 $ (由 3.11), 故  $ 0 \in \text{range} T $.

若  $ w_1, w_2 \in \text{range} T $，则存在  $ v_1, v_2 \in V $ 使得  $ T v_1 = w_1, T v_2 = w_2 $。于是

 $$ T(\nu_{1}+\nu_{2})=T\nu_{1}+T\nu_{2}=w_{1}+w_{2}. $$ 

故  $ w_1 + w_2 \in \text{range} T $。因此  $ \text{range} T $ 对加法封闭。

若  $ w \in \text{range} T, \lambda \in \mathbf{F} $，则存在  $ v \in V $ 使得  $ Tv = w $。于是

 $$ T(\lambda\nu)=\lambda T\nu=\lambda w. $$ 

故  $ \lambda w \in \text{range } T $。因此  $ \text{range } T $ 对标量乘法封闭

我们已经证明了 range T 包含 0，并且对加法和标量乘法都封闭，故 range T 是 W 的子空间（由于 1.34）.

3.20 定义 满的（surjective）
如果函数  $ T: V \rightarrow W $ 的值域等于 W，则称 T 为满的.

为了解释上述定义，注意到在 3.18 中计算过其值域的那些线性映射，只有微分映射是满的（除了零映射在  $ W = \{0\} $ 的特殊情形下是满的之外）.

线性映射是不是满的与其映到哪个向量空间有关.

许多数学家采用映上这个术语，意思与满的相同.



3.21 例 定义为  $ Dp = p' $ 的微分映射  $ D \in \mathcal{L}(\mathcal{P}_5(\mathbf{R}), \mathcal{P}_5(\mathbf{R})) $ 不是满的，因为多项式  $ x^5 $ 不包含于  $ T $ 的值域。然而，定义为  $ Sp = p' $ 微分映射  $ S \in \mathcal{L}(\mathcal{P}_5(\mathbf{R}), \mathcal{P}_4(\mathbf{R})) $ 是满的，因为其值域等于  $ \mathcal{P}_4(\mathbf{R}) $，它就是  $ S $ 映到的向量空间。