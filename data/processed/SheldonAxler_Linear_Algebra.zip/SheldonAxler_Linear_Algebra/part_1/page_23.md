2 设  $ D \in \mathcal{L}(\mathcal{P}_3(\mathbf{R}), \mathcal{P}_2(\mathbf{R})) $ 是微分映射  $ D p = p' $。求  $ \mathcal{P}_3(\mathbf{R}) $ 的一个基和  $ \mathcal{P}_2(\mathbf{R}) $ 的一个基，使得 D 关于这些基的矩阵为

 $$ \left(\begin{array}{c c c c}{1}&{0}&{0}&{0}\\ {0}&{1}&{0}&{0}\\ {0}&{0}&{1}&{0}\end{array}\right). $$ 

请比较本题与例 3.34. 下题推广了本题.

3 设 V 和 W 都是有限维的， $ T \in \mathcal{L}(V, W) $。证明存在 V 的一个基和 W 的一个基，使得关于这些基， $ \mathcal{M}(T) $ 除了第 j 行第 j 列  $ (1 \leq j \leq \dim \text{range } T) $ 的元素等于 1 以外，其余元素均为 0。

4 设  $ v_{1}, \ldots, v_{m} $ 是 V 的基，且 W 是有限维的．设  $ T \in \mathcal{L}(V, W) $．证明存在 W 的一个基  $ w_{1}, \ldots, w_{n} $ 使得，在 T 关于基  $ v_{1}, \ldots, v_{m} $ 和  $ w_{1}, \ldots, w_{n} $ 的矩阵  $ \mathcal{M}(T) $ 中，除了第 1 行第 1 列处的元素可能为 1 之外，第 1 列的其余元素均为 0．

与习题3不同，本题给定了V的一个基，而不是可以选取V的一个基。

5 设  $ w_{1}, \ldots, w_{n} $ 是 W 的基，且 V 是有限维的．设  $ T \in \mathcal{L}(V, W) $．证明存在 V 的一个基  $ v_{1}, \ldots, v_{m} $ 使得，在 T 关于基  $ v_{1}, \ldots, v_{m} $ 和  $ w_{1}, \ldots, w_{n} $ 的矩阵  $ \mathcal{M}(T) $ 中，除了第 1 行第 1 列处的元素可能为 1 之外，第 1 行的其余元素均为 0．

与习题 3 不同，本题给定了 W 的一个基，而不是可以选取 W 的一个基.

6 设 V 和 W 都是有限维的， $ T \in \mathcal{L}(V, W) $。证明 dim range T = 1 当且仅当 V 和 W 各有一个基使得关于这些基  $ \mathcal{M}(T) $ 的所有元素都等于 1。

7 验证 3.36.

8 验证 3.38.

9 证明 3.52.

10 设 A 是  $ m \times n $ 矩阵，C 是  $ n \times p $ 矩阵．证明对于  $ 1 \leq j \leq m $，

 $$ (AC)_{j,.}=A_{j,.}C. $$ 

也就是说，证明 AC 的第 j 行等于 A 的第 j 行乘以 C.

11 设  $ a = \left( \begin{array}{ccc} a_{1} & \cdots & a_{n} \end{array} \right) $ 是  $ 1 \times n $ 矩阵，C 是  $ n \times p $ 矩阵．证明

 $$ a C=a_{1}C_{1,\cdot}+\cdots+a_{n}C_{n,\cdot}. $$ 

也就是说，证明 aC 是 C 的诸行的线性组合，其中的标量来自 a.

12 举一个  $ 2 \times 2 $ 矩阵的例子，说明矩阵乘法不是交换的．也就是说，找两个  $ 2 \times 2 $ 矩阵 A 和 C 使得  $ AC \neq CA $．

13 证明矩阵的加法和乘法满足分配性质．换言之，设 A、B、C、D、E、F 均为矩阵，且其大小使  $ A(B+C) $ 和  $ (D+E)F $ 都有意义．证明： $ AB+AC $ 和  $ DF+EF $ 都有意义，而且我们有  $ A(B+C)=AB+AC $ 且  $ (D+E)F=DF+EF $．