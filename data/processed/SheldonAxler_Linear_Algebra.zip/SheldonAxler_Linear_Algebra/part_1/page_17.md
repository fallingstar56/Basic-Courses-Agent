 $$ \begin{array}{l}\nu_{1} \quad \cdots \quad \nu_{k} \quad \cdots \quad \nu_{n}\end{array} $$ 

 $$ \begin{array}{ccc}&\boldsymbol{w}_{1}&&\\ \boldsymbol{\mathcal{M}}(T)&:\ &\boldsymbol{\vdots}\\ &&\boldsymbol{w}_{m}&\end{array}\quad\begin{array}{ccc}&\boldsymbol{A}_{1,k}&&\\ &:\ &\boldsymbol{\vdots}\\ &&\boldsymbol{A}_{m,k}&\end{array}. $$ 

把  $ T\nu_{k} $ 写成  $ w_{1},\ldots,w_{m} $ 的线性组合： $ T\nu_{k}=\sum_{j=1}^{m}A_{j,k}w_{j} $，其中的这些系数就组成了  $ \mathcal{M}(T) $ 的第 k 列.

如果 T 是从 n 维向量空间到 m 维向量空间的一个线性映射，则

 $ M(T) $ 是一个  $ m \times n $ 矩阵.

在上面的矩阵中，只列出了第 k 列，因此所列出的这些元素的第二个下标都是 k 。上图会让我们想到， $ T v_{k} $ 也可以从矩阵  $ \mathcal{M}(T) $ 计算出来：将矩阵的第 k 列的每个元素与左侧的列中相应的 w 相乘，然后再将所得向量相加。



如果 T 是  $ F^{n} $ 到  $ F^{m} $ 的线性映射，那么除非特殊说明，总设所考虑的基是标准基（其中第 k 个基向量的第 k 个位置是 1，其他位置都是 0）。如果把  $ F^{m} $ 中的元素看成由 m 个数组成的列，那么可以把  $ \mathcal{M}(T) $ 的第 k 列视为 T 对第 k 个标准基向量的作用。

3.33 例 设  $ T \in \mathcal{L}(\mathbf{F}^2, \mathbf{F}^3) $ 定义如下：

 $$ T(x,y)=(x+3y,2x+5y,7x+9y). $$ 

求 T 关于  $ F^{2} $ 和  $ F^{3} $ 的标准基的矩阵.

解 由于  $ T(1,0)=(1,2,7) $,  $ T(0,1)=(3,5,9) $，所以 T 关于标准基的  $ 3 \times 2 $ 矩阵如下：

 $$ \mathcal{M}(T)=\left(\begin{array}{l l}{1}&{3}\\ {2}&{5}\\ {7}&{9}\end{array}\right). $$ 

在考虑  $ \mathcal{P}_{m}(\mathbf{F}) $ 时，除非特别声明，总使用标准基  $ 1, x, x^{2}, \ldots, x^{m} $.

3.34 例 设  $ D \in \mathcal{L}(\mathcal{P}_3(\mathbf{R}), \mathcal{P}_2(\mathbf{R})) $ 是微分映射  $ D p = p' $. 求 D 关于  $ \mathcal{P}_3(\mathbf{R}) $ 和  $ \mathcal{P}_2(\mathbf{R}) $ 的标准基的矩阵.

解 由于  $ (x^{n})^{\prime}=nx^{n-1} $，所以 D 关于标准基的  $ 3\times4 $ 矩阵如下：

 $$ \mathcal{M}(D)=\left(\begin{array}{c c c c}{0}&{1}&{0}&{0}\\ {0}&{0}&{2}&{0}\\ {0}&{0}&{0}&{3}\\ \end{array}\right). $$ 