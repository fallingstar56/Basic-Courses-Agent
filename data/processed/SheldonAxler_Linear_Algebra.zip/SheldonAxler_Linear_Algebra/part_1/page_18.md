## 矩阵的加法与标量乘法

在本节的余下部分，总假定 V 和 W 是有限维的且已取定 V 和 W 的基．则对于每个从 V 到 W 的线性映射，我们都可以谈论它的矩阵（当然，是关于这些取定的基的）．两个线性映射之和的矩阵是否等于这两个映射的矩阵之和呢？

这个问题现在还没有意义，这是因为，尽管我们定义了两个线性映射的和，但是还没有定义两个矩阵的和。幸好矩阵的和有明显的定义，而且此定义恰好就有这样的性质。具体地，我们有如下定义。

### 3.35 定义 矩阵加法（matrix addition）

规定两个同样大小的矩阵的和是把矩阵中相对应的元素相加得到的矩阵：

 $$ \begin{aligned}\left(\begin{array}{ccc}A_{1,1}&\cdots&A_{1,n}\\\vdots&&\vdots\\A_{m,1}&\cdots&A_{m,n}\\\end{array}\right)&+\left(\begin{array}{ccc}C_{1,1}&\cdots&C_{1,n}\\\vdots&&\vdots\\C_{m,1}&\cdots&C_{m,n}\\\end{array}\right)\\&=\left(\begin{array}{ccc}A_{1,1}+C_{1,1}&\cdots&A_{1,n}+C_{1,n}\\\vdots&&\vdots\\A_{m,1}+C_{m,1}&\cdots&A_{m,n}+C_{m,n}\\\end{array}\right).\\ 也就是说 ,(A+C)_{i,k}=A_{i,k}+C_{i,k}.\end{aligned} $$ 

在下面命题中，假设所有三个线性映射  $ S + T $、S、T 都使用同样的基.

### 3.36 线性映射的和的矩阵

设  $ S, T \in \mathcal{L}(V, W) $，则  $ \mathcal{M}(S + T) = \mathcal{M}(S) + \mathcal{M}(T) $.

上述结果的证明留给读者.

仍然假设我们已经取定了某些基，标量与线性映射之积的矩阵是否等于标量与线性映射的矩阵之积？这个问题现在还没有意义，这是因为我们还没有定义矩阵的标量乘法．幸好矩阵的标量乘法有明显的定义，而且此定义恰好就有这样的性质．

### 3.37 定义 矩阵的标量乘法（scalar multiplication of a matrix）

标量与矩阵的乘积就是用该标量乘以矩阵的每个元素：

 $$ \lambda\left(\begin{array}{ccc}A_{1,1}&\cdots&A_{1,n}\\\vdots&&\vdots\\A_{m,1}&\cdots&A_{m,n}\\\end{array}\right)=\left(\begin{array}{ccc}\lambda A_{1,1}&\cdots&\lambda A_{1,n}\\\vdots&&\vdots\\\lambda A_{m,1}&\cdots&\lambda A_{m,n}\\\end{array}\right). $$ 

也就是说， $ (\lambda A)_{j,k} = \lambda A_{j,k}. $

在下面命题中，假设线性映射  $ \lambda T $ 和 T 使用相同的基.