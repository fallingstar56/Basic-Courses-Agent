则对于  $ j = 1, \ldots, n $ 有  $ (a_{1}\varphi_{1} + \cdots + a_{n}\varphi_{n})(\nu_{j}) = a_{j} $ 。上面的等式表明  $ a_{1} = \cdots = a_{n} = 0 $ 。所以  $ \varphi_{1}, \ldots, \varphi_{n} $ 是线性无关的。

现在 2.39 和 3.95 表明  $ \varphi_{1},\ldots,\varphi_{n} $ 是  $ V' $ 的基.

在下面的定义中，若 T 是 V 到 W 的线性映射，则  $ T' $ 是  $ W' $ 到  $ V' $ 的线性映射.

3.99 定义 对偶映射 (dual map),  $ T' $

若  $ T \in \mathcal{L}(V, W) $，则  $ T $ 的对偶映射是线性映射  $ T' \in \mathcal{L}(W', V') $：对于  $ \varphi \in W' $， $ T'(\varphi) = \varphi \circ T $。

若  $ T \in \mathcal{L}(V, W) $ 且  $ \varphi \in W' $，则  $ T'(\varphi) $ 被定义为线性映射  $ \varphi $ 与  $ T $ 的复合。于是  $ T'(\varphi) $ 的确是  $ V $ 到  $ \mathbf{F} $ 的线性映射，也就是说， $ T'(\varphi) \in V' $。

容易验证  $ T' $ 是  $ W' $ 到  $ V' $ 的线性映射：

- 若  $ \varphi, \psi \in W' $，则  $ T'(\varphi + \psi) = (\varphi + \psi) \circ T = \varphi \circ T + \psi \circ T = T'(\varphi) + T'(\psi) $。
- 若  $ \lambda \in \mathbf{F} $， $ \varphi \in W' $，则  $ T'(\lambda \varphi) = (\lambda \varphi) \circ T = \lambda(\varphi \circ T) = \lambda T'(\varphi) $。

在下面的例子中，记号  $ ' $ 有两种毫不相关的意义： $ D' $ 表示线性映射  $ D $ 的对偶映射，而  $ p' $ 表示多项式  $ p $ 的导数。

3.100 例 定义  $ D: \mathcal{P}(\mathbf{R}) \to \mathcal{P}(\mathbf{R}) $ 为  $ Dp = p' $。

- 设  $ \varphi $ 是  $ \mathcal{P}(\mathbf{R}) $ 上由  $ \varphi(p) = p(3) $ 定义的线性泛函。则  $ D'(\varphi) $ 是  $ \mathcal{P}(\mathbf{R}) $ 上如下定义的线性泛函：
    $ \left(D'(\varphi)\right)(p) = (\varphi \circ D)(p) = \varphi(Dp) = \varphi(p') = p'(3) $。
   也就是说， $ D'(\varphi) $ 是  $ \mathcal{P}(\mathbf{R}) $ 上将  $ p $ 变为  $ p'(3) $ 的线性泛函。

- 设  $ \varphi $ 是  $ \mathcal{P}(\mathbf{R}) $ 上由  $ \varphi(p) = \int_0^1 p(x) \, dx $ 定义的线性泛函。则  $ D'(\varphi) $ 是  $ \mathcal{P}(\mathbf{R}) $ 上如下定义的线性泛函：
    $ \left(D'(\varphi)\right)(p) = (\varphi \circ D)(p) = \varphi(Dp) = \varphi(p') = \int_0^1 p'(x) \, dx = p(1) - p(0) $。
   也就是说， $ D'(\varphi) $ 是  $ \mathcal{P}(\mathbf{R}) $ 上将  $ p $ 变为  $ p(1) - p(0) $ 的线性泛函。

下面结果的前两条表明将 T 变为  $ T' $ 的函数是  $ \mathcal{L}(V, W) $ 到  $ \mathcal{L}(W', V') $ 的线性映射.

在下面的第三条中，注意 ST 与  $ T^{\prime}S^{\prime} $ 复合顺序是相反的（这里我们假定 U 是 F 上的向量空间）.

### 3.101 对偶映射的代数性质

• 对所有  $ S, T \in \mathcal{L}(V, W) $ 有  $ (S + T)' = S' + T' $.

• 对所有  $ \lambda \in \mathbf{F} $ 和所有  $ T \in \mathcal{L}(V, W) $ 有  $ (\lambda T)' = \lambda T' $.

 $$ T\in\mathcal{L}(U,V) $$ 

 $$ S\in\mathcal{L}(V,W) $$ 

 $$ (ST)^{\prime}=T^{\prime}S^{\prime} $$ 