读者应当验证  $ \pi $ 的确是线性映射．虽然  $ \pi $ 同时依赖于 U 和 V，但它们并未出现在记号中，这是因为它们在上下文中是自明的.

### 3.89 商空间的维数

设 V 是有限维的，U 是 V 的子空间．则

 $$ \dim V/U=\dim V-\dim U. $$ 

证明 设  $ \pi $ 是 V 到 V/U 的商映射. 由 3.85 我们有 null  $ \pi = U $. 显然 range  $ \pi = V/U $.

于是线性映射基本定理 3.22 表明

 $$ \dim V=\dim U+\dim V/U, $$ 

由此可得要证明的结果.

V 上的每个线性映射 T 都诱导  $ V/(\text{null}T) $ 上的一个线性映射  $ \tilde{T} $，现在就来定义它.

3.90 定义  $ \tilde{T} $

设  $ T \in \mathcal{L}(V, W) $. 定义  $ \tilde{T}: V / (\text{null } T) \to W $ 如下:

 $ \tilde{T}(v + \text{null } T) = T v. $

为了证明  $ \tilde{T} $ 的定义是有意义的，设  $ u, v \in V $ 使得  $ u + \text{null} T = v + \text{null} T $。由 3.85 有  $ u - v \in \text{null} T $。于是  $ T(u - v) = 0 $。所以  $ Tu = Tv $。因此  $ \tilde{T} $ 的定义是有意义的。

### 3.91 T 的零空间与值域

3.91  $ \tilde{T} $ 的.
设  $ T \in \mathcal{L}(V, W) $. 则
(a)  $ \tilde{T} $ 是  $ V/(null T) $ 到  $ W $ 的线性映射；
(b)  $ \tilde{T} $ 是单的；
(c) range  $ \tilde{T} = \text{range } T $;
(d)  $ V/(null T) $ 同构于 range  $ T $.

证明

(a) 验证  $ \tilde{T} $ 是线性的留给读者.

(b) 设  $ v \in V $， $ \tilde{T}(v + \text{null}T) = 0 $。则  $ Tv = 0 $。于是  $ v \in \text{null}T $。所以 3.85 说明  $ v + \text{null}T = 0 + \text{null}T $。这表明  $ \text{null} \tilde{T} = \{0\} $，因此  $ \tilde{T} $ 是单的。

(c)  $ \tilde{T} $ 的定义表明 range  $ \tilde{T} = \text{range} T $.

(d) (b) 和 (c) 表明，若将  $ \tilde{T} $ 视为到 range T 的映射，则  $ \tilde{T} $ 是  $ V/(\text{null} T) $ 到 range T 的同构.