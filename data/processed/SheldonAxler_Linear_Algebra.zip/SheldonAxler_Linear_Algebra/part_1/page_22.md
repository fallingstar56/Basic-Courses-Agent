### 3.49 矩阵乘积的列等于矩阵乘以列

设 A 是  $ m \times n $ 矩阵，C 是  $ n \times p $ 矩阵．则对于  $ 1 \leq k \leq p $，

 $$ (AC)._{,k}=AC._{,k}. $$ 

上述结果的证明依然可由定义立得，其证明留给读者。

3.50 例 利用上述结果以及等式

 $$ \left(\begin{array}{l l}{{{1}}}&{{{2}}} \\{{{3}}}&{{{4}}} \\{{{5}}}&{{{6}}}\end{array}\right)\left(\begin{array}{l}{{{5}}} \\{{{1}}}\end{array}\right)=\left(\begin{array}{l}{{{7}}} \\{{{19}}} \\{{{31}}}\end{array}\right), $$ 

我们看到为什么 3.42 中矩阵乘积的第 2 列等于上式的右端.

再给出一种理解  $ m \times n $ 矩阵与  $ n \times 1 $ 矩阵乘积的方式．下例阐释了如何这样做．

3.51 例 在上面的例子中， $ 3 \times 2 $ 矩阵与  $ 2 \times 1 $ 矩阵的乘积是  $ 3 \times 2 $ 矩阵的诸列的线性组合，线性组合中的标量取自那个  $ 2 \times 1 $ 矩阵．具体来说，

 $$ \left(\begin{array}{c}7\\ 19\\ 31\end{array}\right)=5\left(\begin{array}{c}1\\ 3\\ 5\end{array}\right)+1\left(\begin{array}{c}2\\ 4\\ 6\end{array}\right). $$ 

下面的命题推广了上述例子，其证明还是可由定义立得，留给读者.

3.52 列的线性组合

设 A 是  $ m \times n $ 矩阵， $ c = \begin{pmatrix} c_{1} \\ \vdots \\ c_{n} \end{pmatrix} $ 是  $ n \times 1 $ 矩阵．则

 $ ^{4} $

 $$ \begin{align*}Ac=c_1A_{\cdot,1}+\cdots+c_nA_{\cdot,n}.\end{align*} $$ 

也就是说，Ac 是 A 的诸列的线性组合，其中的标量来自 c.

习题 10 和习题 11 中还给出了理解矩阵乘法的另外两种方式.

### 习题 3.C

1 设 V 和 W 都是有限维的， $ T \in \mathcal{L}(V, W) $。证明对于 V 和 W 的任意基，T 的矩阵都至少有 dim range T 个非零元。