1 设 T 是 V 到 W 的函数. 定义 T 的图为  $ V \times W $ 的如下子集:

 $$ T 的图 =\left\{\left(\nu,T\nu\right)\in V\times W:\nu\in V\right\}. $$ 

证明 T 是线性映射当且仅当 T 的图是  $ V \times W $ 的子空间.

正式地讲，V 到 W 的函数 T 是  $ V \times W $ 的一个子集 T，使得对每个  $ v \in V $ 都恰有一个元素  $ (v, w) \in T $。也就是说，函数正式地讲就是上面所谓的图。我们通常并不把函数看成上面的这种正式形式。然而，如果采用上面的正式形式，则本题可以重述为：证明 V 到 W 的函数 T 是线性映射当且仅当 T 是  $ V \times W $ 的子空间。

2 设  $ V_{1}, \ldots, V_{m} $ 均为向量空间使得  $ V_{1} \times \cdots \times V_{m} $ 是有限维的．证明对每个  $ j = 1, \ldots, m $ 来说  $ V_{j} $ 都是有限维的.

3 给出一个向量空间 V 与它的两个子空间  $ U_{1} $ 和  $ U_{2} $ 的例子，使得  $ U_{1} \times U_{2} $ 同构于  $ U_{1} + U_{2} $，但  $ U_{1} + U_{2} $ 不是直和.

提示：向量空间 V 一定是无限维的.

4 设  $ V_{1}, \ldots, V_{m} $ 均为向量空间. 证明  $ \mathcal{L}(V_{1} \times \cdots \times V_{m}, W) $ 和  $ \mathcal{L}(V_{1}, W) \times \cdots \times \mathcal{L}(V_{m}, W) $ 是同构的向量空间.

5 设  $ W_{1},\ldots,W_{m} $ 均为向量空间. 证明  $ \mathcal{L}(V,W_{1}\times\cdots\times W_{m}) $ 和  $ \mathcal{L}(V,W_{1})\times\cdots\times\mathcal{L}(V,W_{m}) $ 是同构的向量空间.

6 对于正整数 n，定义  $ V^{n} $ 如下：

 $$ V^{n}=\underbrace{V\times\cdots\times V}_{n 个 V}. $$ 

证明  $ V^{n} $ 和  $ \mathcal{L}(\mathbf{F}^{n}, V) $ 是同构的向量空间.

7 设 v 和 x 均为 V 中的向量，U 和 W 均为 V 的子空间， $ v + U = x + W $．证明 U = W．

8 证明：V 的非空子集 A 是 V 的仿射子集当且仅当对于所有的  $ v, w \in A $ 和  $ \lambda \in F $ 均有  $ \lambda v + (1 - \lambda)w \in A $.

9 设  $ A_{1} $ 和  $ A_{2} $ 均为 V 的仿射子集．证明交  $ A_{1} \cap A_{2} $ 是 V 的仿射子集或者空集．

10 证明 V 的任意一族仿射子集的交是 V 的仿射子集或者空集.

11 设  $ v_{1}, \ldots, v_{m} \in V $. 令

 $$ A=\{\lambda_{1}\nu_{1}+\cdots+\lambda_{m}\nu_{m}:\lambda_{1},\ldots,\lambda_{m}\in\mathbf{F} 且 \lambda_{1}+\cdots+\lambda_{m}=1\}. $$ 

(a) 证明 A 是 V 的仿射子集.

(b) 证明 V 的每个包含  $ v_{1}, \ldots, v_{m} $ 的仿射子集均包含 A.

(c) 证明有某个  $ v \in V $ 及 V 的某个子空间 U 使得  $ A = v + U $ 且  $ \dim U \leq m - 1 $.

12 设 U 是 V 的子空间使得 V/U 是有限维的．证明 V 同构于  $ U \times (V/U) $．