证明 首先我们证明存在满足上述性质的线性映射 T. 定义  $ T: V \to W $ 如下：

 $$ T(c_{1}\nu_{1}+\cdots+c_{n}\nu_{n})=c_{1}w_{1}+\cdots+c_{n}w_{n}, $$ 

其中  $ c_{1}, \ldots, c_{n} $ 是 F 的任意元素．由于组  $ v_{1}, \ldots, v_{n} $ 是 V 的基，所以上面的等式的确定义了从 V 到 W 的函数 T（因为 V 的每个元素都可唯一地写成  $ c_{1}v_{1} + \cdots + c_{n}v_{n} $ 的形式）.

在上述等式中，对每个 j，取  $ c_{j}=1 $ 并取其他的 c 为 0，则有  $ Tv_{j}=w_{j} $.

若  $ u, v \in V $，其中  $ u = a_1 v_1 + \cdots + a_n v_n $， $ v = c_1 v_1 + \cdots + c_n v_n $，则

 $$ \begin{aligned}T(u+\nu)&=T\big((a_{1}+c_{1})\nu_{1}+\cdots+(a_{n}+c_{n})\nu_{n}\big)\\&=(a_{1}+c_{1})w_{1}+\cdots+(a_{n}+c_{n})w_{n}\\&=(a_{1}w_{1}+\cdots+a_{n}w_{n})+(c_{1}w_{1}+\cdots+c_{n}w_{n})\\&=Tu+Tv.\\ \end{aligned} $$ 

类似地，若  $ \lambda \in \mathbf{F} $， $ \nu = c_1 \nu_1 + \cdots + c_n \nu_n $，则

 $$ \begin{aligned}T(\lambda\nu)&=T(\lambda c_{1}\nu_{1}+\cdots+\lambda c_{n}\nu_{n})\\&=\lambda c_{1}w_{1}+\cdots+\lambda c_{n}w_{n}\\&=\lambda(c_{1}w_{1}+\cdots+c_{n}w_{n})\\&=\lambda T\nu.\\ \end{aligned} $$ 

因此 T 是 V 到 W 的线性映射.

为了证明唯一性，现在假设  $ T \in \mathcal{L}(V, W) $ 且  $ Tv_j = w_j, j = 1, \ldots, n $。设  $ c_1, \ldots, c_n \in \mathbf{F} $。由 T 的齐次性，有  $ T(c_j v_j) = c_j w_j, j = 1, \ldots, n $。由 T 的加性，有

 $$ T(c_{1}\nu_{1}+\cdots+c_{n}\nu_{n})=c_{1}w_{1}+\cdots+c_{n}w_{n}. $$ 

故  $ T $ 在  $ \text{span}(v_1, \ldots, v_n) $ 上由上式唯一确定．由于  $ v_1, \ldots, v_n $ 是  $ V $ 的基，故  $ T $ 在  $ V $ 上是唯一确定的．

##  $ \mathcal{L}(V,W) $ 上的代数运算

我们先在  $ \mathcal{L}(V,W) $ 上定义加法和标量乘法.

3.6 定义  $ \mathcal{L}(V,W) $ 上的加法和标量乘法
(addition and scalar multiplication on  $ \mathcal{L}(V,W) $)
设  $ S, T \in \mathcal{L}(V, W) $， $ \lambda \in \mathbf{F} $。定义和  $ S + T $ 与积  $ \lambda T $ 是 V 到 W 的两个线性映射：对所有  $ v \in V $ 都有
 $ (S + T)(v) = Sv + Tv,\quad (\lambda T)(v) = \lambda(Tv). $