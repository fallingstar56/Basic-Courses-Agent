3.38 标量乘以线性映射的矩阵

设  $ \lambda \in \mathbf{F}, T \in \mathcal{L}(V, W) $，则  $ \mathcal{M}(\lambda T) = \lambda \mathcal{M}(T) $.

这一结果的证明也留给读者.

由于已经定义了矩阵的加法和标量乘法，由此产生一个向量空间就不足为奇了，只需一个记号来表示这个新的向量空间.

 $$ \mathbf{F}^{m,n} $$ 

对于正整数 m 和 n，元素取自 F 的所有  $ m \times n $ 矩阵的集合记为  $ F^{m,n} $.

3.40  $ \dim F^{m,n} = mn $

设 m 和 n 均为正整数．按照上面定义的矩阵加法和标量乘法， $ F^{m,n} $ 是 mn 维向量空间．

证明 证明  $ F^{m,n} $ 是向量空间留给读者．注意  $ F^{m,n} $ 的加法单位元是元素均为 0 的  $ m \times n $ 矩阵．

读者还应该证明某个位置为1其余元素均为0的全体 $ m\times n $矩阵构成 $ F^{m,n} $的基. 共有mn个这样的矩阵, 所以 $ F^{m,n} $的维数等于mn.

## 矩阵乘法

如前，设  $ v_{1}, \ldots, v_{n} $ 是 V 的基， $ w_{1}, \ldots, w_{m} $ 是 W 的基，并设 U 是另一个向量空间， $ u_{1}, \ldots, u_{p} $ 是 U 的基.

考虑线性映射  $ T: U \to V $ 和  $ S: V \to W $，它们的复合映射  $ ST $ 是从  $ U $ 到  $ W $ 的线性映射。 $ \mathcal{M}(ST) $ 是否等于  $ \mathcal{M}(S)\mathcal{M}(T) $？这个问题没有意义，因为还没有定义矩阵乘法。我们要定义一种矩阵乘法使上述问题有肯定的回答。现在来看看该怎么做。

设  $ \mathcal{M}(S) = A, \mathcal{M}(T) = C $. 对于  $ 1 \leq k \leq p $ 我们有

 $$ \begin{align*}(ST)u_{k}&=S\big(\sum_{r=1}^{n} C_{r,k}\nu_{r}\big)\\&=\sum_{r=1}^{n} C_{r,k}S\nu_{r}\\&=\sum_{r=1}^{n} C_{r,k}\sum_{j=1}^{m} A_{j,r}w_{j}\\&=\sum_{j=1}^{m}\big(\sum_{r=1}^{n} A_{j,r}C_{r,k}\big)w_{j}.\end{align*} $$ 

因此  $ M(ST) $ 是  $ m \times p $ 矩阵，它的第 j 行第 k 列元素等于