转置有很好的代数性质：对所有  $ m \times n $ 矩阵 A, C 和所有  $ \lambda \in \mathbf{F} $ 均有  $ (A + C)^{\mathrm{t}} = A^{\mathrm{t}} + C^{\mathrm{t}} $ 且  $ (\lambda A)^{\mathrm{t}} = \lambda A^{\mathrm{t}} $ （见习题 33）.

以下命题表明两个矩阵的乘积的转置等于其转置按相反的顺序相乘.

### 3.113 矩阵乘积的转置

若 A 是  $ m \times n $ 矩阵，C 是  $ n \times p $ 矩阵，则

 $$ (AC)^{\mathrm{t}}=C^{\mathrm{t}}A^{\mathrm{t}}. $$ 

证明 设  $ 1 \leq k \leq p $， $ 1 \leq j \leq m $，则

 $$ \begin{align*}\left((AC)^\mathsf{t}\right)_{k,j}&=(AC)_{j,k}\\&=\sum_{r=1}^{n}A_{j,r}C_{r,k}\\&=\sum_{r=1}^{n}(C^\mathsf{t})_{k,r}(A^\mathsf{t})_{r,j}\\&=(C^\mathsf{t}A^\mathsf{t})_{k,j}.\end{align*} $$ 

于是  $ (AC)^{\mathrm{t}} = C^{\mathrm{t}} A^{\mathrm{t}} $

对以下命题，我们假定有 V 的基  $ v_{1}, \ldots, v_{n} $ 及  $ V' $ 的对偶基  $ \varphi_{1}, \ldots, \varphi_{n} $，并假定有 W 的基  $ w_{1}, \ldots, w_{m} $ 及  $ W' $ 的对偶基  $ \psi_{1}, \ldots, \psi_{m} $。于是  $ \mathcal{M}(T) $ 是按 V 和 W 的上述基计算， $ \mathcal{M}(T') $ 是按  $ W' $ 和  $ V' $ 的上述对偶基计算。

 $$ T^{\prime} $$ 

 $$ T\in\mathcal{L}(V,W) $$ 

 $$ \mathcal{M}(T^{\prime})=\left(\mathcal{M}(T)\right)^{t} $$ 

证明 设  $ A = \mathcal{M}(T) $， $ C = \mathcal{M}(T') $，再设  $ 1 \leq j \leq m $， $ 1 \leq k \leq n $.

由  $ \mathcal{M}(T') $ 的定义我们有

 $$ \begin{align*}T^{\prime}(\psi_j)=\sum\limits_{r=1}^n C_{r,j}\varphi_r.\end{align*} $$ 

上面等式的左端等于  $ \psi_j \circ T $。于是将等式两端作用到  $ v_k $ 上得到

 $$ \begin{align*}(\psi_{j}\circ T)(\nu_{k})&=\sum_{r=1}^{n} C_{r,j}\varphi_{r}(\nu_{k})\\&=C_{k,j}.\end{align*} $$ 

我们还有

 $$ \begin{align*}(\psi_j\circ T)(\nu_k)&=\psi_j(T\nu_k)\\&=\psi_j\left(\sum_{r=1}^{m}A_{r,k}w_r\right)\end{align*} $$ 