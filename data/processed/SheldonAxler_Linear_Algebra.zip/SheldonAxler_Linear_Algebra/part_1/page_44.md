下面结果中的(a)的证明并不需要用到 V 和 W 都是有限维的这一假设.

3.107  $ T' $ 的零空间

设 V 和 W 都是有限维， $ T \in \mathcal{L}(V, W) $。则

(a) null  $ T' = (\text{range } T)^{0} $;

(b) dim null  $ T' = \dim \text{null } T + \dim W - \dim V $.

证明

(a) 首先设  $ \varphi \in \text{null} T' $．则  $ 0 = T'(\varphi) = \varphi \circ T $．故对任意  $ v \in V $ 有

 $$ 0=(\varphi\circ T)(\nu)=\varphi(T\nu). $$ 

于是  $ \varphi \in (\text{range } T)^0 $。这表明  $ \text{null } T' \subset (\text{range } T)^0 $。

为了证明反方向的包含关系，设  $ \varphi \in (\text{range} T)^0 $。则对任意向量  $ \nu \in V $ 有  $ \varphi(Tv) = $ 0。所以  $ 0 = \varphi \circ T = T'(\varphi) $。也就是说  $ \varphi \in \text{null} T' $，这表明  $ (\text{range} T)^0 \subset \text{null} T' $，这就证明了 (a).

(b) 我们有

 $$ \begin{aligned}\dim null T^{\prime}&=\dim(\mathrm{range}T)^{0}\\&=\dim W-\dim\mathrm{range}T\\&=\dim W-(\dim V-\dim\mathrm{null}T)\\&=\dim\mathrm{null}T+\dim W-\dim V,\end{aligned} $$ 

这里第一个等号是利用(a)，第二个等号是利用3.106，第三个等号是利用线性映射基本定理3.22.

下面的命题很有用，因为有时候证明  $ T' $ 是单的比直接证明 T 是满的要更容易.

3.108 T 是满的等价于  $ T' $ 是单的
设 V 和 W 都是有限维的， $ T \in \mathcal{L}(V, W) $。则 T 是满的当且仅当  $ T' $ 是单的。

证明 映射  $ T \in \mathcal{L}(V, W) $ 是满的当且仅当 range  $ T = W $，当且仅当  $ (\text{range } T)^0 = \{0\} $，当且仅当 null  $ T' = \{0\} $（由于 3.107(a)），当且仅当  $ T' $ 是单的。

### 3.109 T' 的值域

设 V 和 W 都是有限维的， $ T \in \mathcal{L}(V, W) $。则
(a) dim range  $ T' = \dim range T; $
(b) range  $ T' = (\text{null } T)^{0} $.

证明

(a) 我们有