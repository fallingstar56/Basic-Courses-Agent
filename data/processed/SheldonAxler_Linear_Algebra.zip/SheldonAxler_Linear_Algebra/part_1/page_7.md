6 证明 3.9 中的结论.

7 证明每个从一维向量空间到其自身的线性映射都是乘以某个标量．准确地说，证明：若  $ \dim V = 1 $ 且  $ T \in \mathcal{L}(V, V) $，则有  $ \lambda \in \mathbf{F} $ 使得对所有  $ v \in V $ 都有  $ T v = \lambda v $.

8 给出一个函数  $ \varphi: \mathbf{R}^2 \to \mathbf{R} $，使得对所有  $ a \in \mathbf{R} $ 和所有  $ v \in \mathbf{R}^2 $ 有

 $$ \varphi(a\nu)=a\varphi(\nu), $$ 

但 $ \varphi $不是线性的.

本题和下题表明齐性并不蕴涵线性，加性也不蕴涵线性。

9 给出一个函数  $ \varphi: \mathbf{C} \to \mathbf{C} $，使得对所有  $ w, z \in \mathbf{C} $ 都有

 $$ \varphi(w+z)=\varphi(w)+\varphi(z), $$ 

但  $ \varphi $ 不是线性的。（这里 C 视为一个复向量空间。）

也存在函数  $ \varphi: \mathbf{R} \to \mathbf{R} $ 使得  $ \varphi $ 满足上述加性条件但  $ \varphi $ 不是线性的。但是，证明其存在性涉及更高等的工具。

10 设 U 是 V 的子空间且  $ U \neq V $。设  $ S \in \mathcal{L}(U, W) $ 且  $ S \neq 0 $（这意味着对某个  $ u \in U $ 有  $ Su \neq 0 $）。定义  $ T: V \to W $ 如下

 $$ T v=\begin{cases}S v,& 若 v\in U,\\0,& 若 v\in V 且 v\notin U.\end{cases} $$ 

证明 T 不是 V 上的线性映射.

11 设 V 是有限维的．证明 V 的子空间上的线性映射可以扩张成 V 上的线性映射．也就是说，证明：如果 U 是 V 的子空间， $ S \in \mathcal{L}(U, W) $，那么存在  $ T \in \mathcal{L}(V, W) $ 使得对所有  $ u \in U $ 都有  $ Tu = Su $.

12 设 V 是有限维的且  $ \dim V > 0 $，再设 W 是无限维的．证明  $ \mathcal{L}(V, W) $ 是无限维的.

13 设  $ v_{1},\ldots,v_{m} $ 是 V 中的一个线性相关的向量组，并设  $ W \neq \{0\} $ 。证明存在  $ w_{1},\ldots,w_{m} \in W $ 使得没有  $ T \in \mathcal{L}(V,W) $ 能满足  $ T v_{k}=w_{k}, k=1,\ldots,m $ 。

14 设 V 是有限维的且  $ \dim V \geq 2 $。证明存在  $ S, T \in \mathcal{L}(V, V) $ 使得  $ ST \neq TS $。

### 3. B 零空间与值域

## 零 空间与单射性

本节我们将学习与每一个线性映射紧密联系的两个子空间．先来看被映为0的向量构成的集合．