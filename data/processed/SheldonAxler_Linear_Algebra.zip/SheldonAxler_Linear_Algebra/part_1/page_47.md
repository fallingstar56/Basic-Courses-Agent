 $$ \begin{aligned}&=\sum_{r=1}^{m}A_{r,k}\psi_{j}(w_{r})\\&=A_{j,k}.\\ \end{aligned} $$ 

比较上面两组等式的最后一行得  $ C_{k,j} = A_{j,k} $ 。于是  $ C = A^{t} $ 。也就是说  $ \mathcal{M}(T') = \left(\mathcal{M}(T)\right)^{\mathrm{t}} $ 。

## 矩阵的秩

我们首先定义与矩阵有关的两个非负整数.

3.115 定义 行秩（row rank）、列秩（column rank）

设 A 是元素属于 F 的  $ m \times n $ 矩阵.

• A 的行秩是 A 的诸行在  $ F^{1,n} $ 中的张成空间的维数.

• A 的列秩是 A 的诸列在  $ F^{m,1} $ 中的张成空间的维数.

3.116 例 设  $ A=\left(\begin{array}{ccc}4 & 7 & 1 \\ 3 & 5 & 2\end{array}\right) $，求 A 的行秩和列秩.

解 A 的行秩等于  $ F^{1,4} $ 中

 $$ \operatorname{span}\left(\left(\begin{array}{llll}4&7&1&8\end{array}\right),\left(\begin{array}{llll}3&5&2&9\end{array}\right)\right) $$ 

的维数.  $ F^{1,4} $ 中这两个向量任何一个都不是另一个的标量倍，所以这个长度为 2 的组的张成空间的维数为 2. 也就是说，A 的行秩是 2.

A 的列秩是  $ F^{2,1} $ 中

 $$ \mathrm{span}\left(\left(\begin{array}{l}4\\ 3\end{array}\right),\left(\begin{array}{l}7\\ 5\end{array}\right),\left(\begin{array}{l}1\\ 2\end{array}\right),\left(\begin{array}{l}8\\ 9\end{array}\right)\right) $$ 

的维数.  $ F^{2,1} $ 中上述组的前两个向量中的任何一个都不是另一个的标量倍，所以这个长度为 4 的组的张成空间的维数至少是 2. 因为  $ \dim F^{2,1} = 2 $，所以  $ F^{2,1} $ 中这个向量组的张成空间的维数不可能大于 2. 于是这个向量组的张成空间的维数是 2. 也就是说，A 的列秩是 2.

注意在下面结果的陈述中并没有出现基．虽然下面结果中的  $ \mathcal{M}(T) $ 依赖于 V 和 W 的基的选取，但是下面的结果表明  $ \mathcal{M}(T) $ 的列秩对于选定的每一组基都是相同的（因为 range T 并不依赖于基的选取）.

### 3.117 range T 的维数等于  $ \mathcal{M}(T) $ 的列秩

设 V 和 W 都是有限维的， $ T \in \mathcal{L}(V, W) $。则  $ \dim \text{range } T $ 等于  $ \mathcal{M}(T) $ 的列秩。