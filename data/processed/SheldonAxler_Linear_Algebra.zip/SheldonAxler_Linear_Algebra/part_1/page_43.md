于是  $ \varphi \in U^{0} $. 也就是说我们已证明了  $ \operatorname{span}(\varphi_{3}, \varphi_{4}, \varphi_{5}) \subset U^{0} $.

为了证明另一个方向的包含，设  $ \varphi \in U^{0} $。由于对偶基是  $ (\mathbf{R}^{5})' $ 的基，存在  $ c_{1}, c_{2}, c_{3}, c_{4}, c_{5} \in \mathbf{R} $ 使得  $ \varphi = c_{1}\varphi_{1} + c_{2}\varphi_{2} + c_{3}\varphi_{3} + c_{4}\varphi_{4} + c_{5}\varphi_{5} $。由  $ e_{1} \in U $ 和  $ \varphi \in U^{0} $ 可得

 $$ 0=\varphi(e_{1})=(c_{1}\varphi_{1}+c_{2}\varphi_{2}+c_{3}\varphi_{3}+c_{4}\varphi_{4}+c_{5}\varphi_{5})(e_{1})=c_{1}. $$ 

类似地， $ e_2 \in U $，所以  $ c_2 = 0 $。因此我们有  $ \varphi = c_3\varphi_3 + c_4\varphi_4 + c_5\varphi_5 $。于是  $ \varphi \in \text{span}(\varphi_3, \varphi_4, \varphi_5) $，这表明  $ U^0 \subset \text{span}(\varphi_3, \varphi_4, \varphi_5) $。

3.105 零化子是子空间

设  $ U \subset V $，则  $ U^0 $ 是  $ V' $ 的子空间.

证明 显然  $ 0 \in U^0 $（这里 0 表示  $ V $ 上的零线性泛函），因为零线性泛函将  $ U $ 中每个向量变为 0.

设  $ \varphi, \psi \in U^0 $。则  $ \varphi, \psi \in V' $ 且对每个  $ u \in U $ 有  $ \varphi(u) = \psi(u) = 0 $。若  $ u \in U $，则  $ (\varphi + \psi)(u) = \varphi(u) + \psi(u) = 0 + 0 = 0 $。于是  $ \varphi + \psi \in U^0 $。

类似地， $ U^0 $ 在标量乘法下封闭。于是 1.34 表明  $ U^0 $ 是  $ V' $ 的子空间。

下面的命题表明  $ \dim U^0 $ 是  $ \dim V $ 与  $ \dim U $ 的差。例如，这意味着如果  $ U $ 是  $ \mathbb{R}^5 $ 的二维子空间，则  $ U^0 $ 是  $ (\mathbb{R}^5)' $ 的三维子空间，见例 3.104。

下面的命题可以仿照例 3.104 的方法来证明：选择  $ U $ 的一个基  $ u_1, \ldots, u_m $，将其扩充为  $ V $ 的基  $ u_1, \ldots, u_m, \ldots, u_n $。设  $ \varphi_1, \ldots, \varphi_m, \ldots, \varphi_n $ 是  $ V' $ 的对偶基，然后证明  $ \varphi_{m+1}, \ldots, \varphi_n $ 是  $ U^0 $ 的基，这就证明了想要的结果。

请读者按照上一段给出的证明梗概写出完整的证明，尽管下面我们给出了一个更简明的证明。

3.106 零化子的维数
设 V 是有限维的，U 是 V 的子空间．则
 $ \dim U + \dim U^{0} = \dim V. $

证明 设  $ i \in \mathcal{L}(U, V) $ 是包含映射，定义如下：对  $ u \in U $ 有  $ i(u) = u $。则  $ i' $ 是  $ V' $ 到  $ U' $ 的线性映射。对  $ i' $ 应用线性映射基本定理 3.22 得

 $$ \dim range i^{\prime}+\dim null i^{\prime}=\dim V^{\prime}. $$ 

而 null  $ i' = U^0 $（可由定义得到）且  $ \dim V' = \dim V $（由于 3.95），故上述等式变为

 $$ \dim range i^{\prime}+\dim U^{0}=\dim V. $$ 

若  $ \varphi \in U' $，则  $ \varphi $ 可以扩张为  $ V $ 上的线性泛函  $ \psi $（例如，见 3.A 节的习题 11）。 $ i' $ 的定义表明  $ i'(\psi) = \varphi $。所以  $ \varphi \in \text{range} i' $，这表明  $ \text{range} i' = U' $。因此  $ \text{dim range} i' = \text{dim} U' = \text{dim} U $，这就得到了想要的结论。