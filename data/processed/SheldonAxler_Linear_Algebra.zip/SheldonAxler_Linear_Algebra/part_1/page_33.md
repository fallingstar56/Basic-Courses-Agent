虽然它们看起来几乎一样，但并不是同一种对象.  $ R^{2} \times R^{3} $ 的元素是长度为 2 的组（该组的第一项是长度为 2 的组，第二项是长度为 3 的组）， $ R^{5} $ 的元素是长度为 5 的组. 所以  $ R^{2} \times R^{3} $ 不等于  $ R^{5} $.

将向量  $ \left((x_{1}, x_{2}), (x_{3}, x_{4}, x_{5})\right) \in \mathbf{R}^{2} \times \mathbf{R}^{3} $ 变为  $ (x_{1}, x_{2}, x_{3}, x_{4}, x_{5}) \in \mathbf{R}^{5} $ 的线性映射显然是  $ R^{2} \times R^{3} $ 到  $ R^{5} $ 的同构．所以这两个向量空间是同构的．

这个同构非常自然，只是把元素换了种写法．有些人甚至通俗地说  $ R^{2} \times R^{3} $ 等于  $ R^{5} $，这种说法严格来说是不正确的，但却抓住了通过改变写法就可使二者等同这一本质.

下面的例子说明了 3.76 的证明思想.

3.75 例 求  $ \mathcal{P}_2(\mathbf{R}) \times \mathbf{R}^2 $ 的一个基.

解 考虑  $ \mathcal{P}_{2}(\mathbf{R}) \times \mathbf{R}^{2} $ 中元素构成的长度为 5 的组：

 $$ \left(1,\left(0,0\right)\right),\left(x,\left(0,0\right)\right),\left(x^{2},\left(0,0\right)\right),\left(0,\left(1,0\right)\right),\left(0,\left(0,1\right)\right). $$ 

上述组是线性无关的且张成  $ \mathcal{P}_2(\mathbf{R}) \times \mathbf{R}^2 $，因此是  $ \mathcal{P}_2(\mathbf{R}) \times \mathbf{R}^2 $ 的基。

### 3.76 积的维数等于维数的和

设  $ V_{1}, \ldots, V_{m} $ 均为有限维向量空间．则  $ V_{1} \times \cdots \times V_{m} $ 是有限维的，且

 $$ \dim(V_{1}\times\cdots\times V_{m})=\dim V_{1}+\cdots+\dim V_{m}. $$ 

证明 选取每个  $ V_j $ 的一个基．对于每个  $ V_j $ 的每个基向量，考虑  $ V_1 \times \cdots \times V_m $ 的如下元素：第  $ j $ 个位置为此基向量，其余位置为 0．所有这些向量构成的组是线性无关的，且张成  $ V_1 \times \cdots \times V_m $，因此是  $ V_1 \times \cdots \times V_m $ 的基．这个基的长度是  $ \dim V_1 + \cdots + \dim V_m $．

## 积与直和

在以下命题中，由  $ U_{1}+\cdots+U_{m} $ 的定义，映射  $ \Gamma $ 是满的．所以这个命题中的最后一个词 “单射” 可以改为 “满射”．

### 3.77 积与直和

设  $ U_{1},\ldots,U_{m} $ 均为 V 的子空间. 线性映射  $ \Gamma:U_{1}\times\cdots\times U_{m}\rightarrow U_{1}+\cdots+U_{m} $ 定义为  $ \Gamma(u_{1},\ldots,u_{m})=u_{1}+\cdots+u_{m} $. 则  $ U_{1}+\cdots+U_{m} $ 是直和当且仅当  $ \Gamma $ 是单射.

证明 线性映射  $ \Gamma $ 是单的当且仅当将 0 表示为  $ U_j $ 的元素之和  $ u_1 + \cdots + u_m $ 时只能取每个  $ u_j $ 等于 0. 于是 1.44 表明  $ \Gamma $ 是单的当且仅当  $ U_1 + \cdots + U_m $ 是直和.