### 3.12 定义零空间（null space），null T

对于  $ T \in \mathcal{L}(V, W) $， $ T $ 的零空间（记为 null  $ T $）是指  $ V $ 中那些被  $ T $ 映为 0 的向量构成的子集：

 $$ \mathrm{n u l l}T=\{\nu\in V:T\nu=0\}. $$ 

### 3.13 例 零空间

• 若 T 是 V 到 W 的零映射，也就是说对每个  $ v \in V $ 有  $ Tv = 0 $，则  $ nullT = V $.

设  $ \varphi \in \mathcal{L}(\mathbf{C}^3, \mathbf{F}) $ 定义为  $ \varphi(z_1, z_2, z_3) = z_1 + 2z_2 + 3z_3 $。则  $ \text{null} \varphi = \{(z_1, z_2, z_3) \in \mathbf{C}^3 : z_1 + 2z_2 + 3z_3 = 0\} $，并且  $ \text{null} \varphi $ 的一个基为  $ (-2, 1, 0), (-3, 0, 1) $。

- 设  $ D \in \mathcal{L}(\mathcal{P}(\mathbf{R}), \mathcal{P}(\mathbf{R})) $ 是微分映射  $ D p = p' $。只有常函数的导数才能等于零函数。于是，T 的零空间是常函数组成的集合。

• 设  $ T \in \mathcal{L}(\mathcal{P}(\mathbf{R}), \mathcal{P}(\mathbf{R})) $ 是乘  $ x^2 $ 映射  $ (Tp)(x) = x^2 p(x) $. 在  $ x \in \mathbf{R} $ 时满足  $ x^2 p(x) = 0 $ 的多项式  $ p $ 只有 0 多项式. 于是  $ null T = \{0\} $.

• 设  $ T \in \mathcal{L}(\mathbf{F}^{\infty}, \mathbf{F}^{\infty}) $ 是向后移位映射

 $$ T(x_{1},x_{2},x_{3},\ldots)=(x_{2},x_{3},\ldots). $$ 

显然， $ T(x_1, x_2, x_3, \ldots) $ 等于 0 当且仅当  $ x_2, x_3, \ldots $ 都是 0. 于是  $ nullT = \{(a, 0, 0, \ldots) : a \in \mathbf{F}\} $.

下面的命题证明了线性映射的零空间是定义域的子空间．特别地，0包含于每个线性映射的零空间.

有些数学家使用术语核而不是零空间．null一词的意思是零．术语“零空间”提醒我们这一概念与0有关.



### 3.14 零空间是子空间

设  $ T \in \mathcal{L}(V, W) $，则 null T 是 V 的子空间。

证明 因为 T 是线性映射，我们知道  $ T(0) = 0 $（由于 3.11）。所以  $ 0 \in \text{null} T $。

设  $ u, v \in \text{null} T $. 则

 $$ T(u+v)=Tu+Tv=0+0=0. $$ 

故  $ u + v \in \text{null} T $。于是  $ \text{null} T $ 对加法封闭。

设  $ u \in \text{null} T $ 且  $ \lambda \in \mathbf{F} $. 则

 $$ T(\lambda u)=\lambda T u=\lambda0=0. $$ 

故  $ \lambda u \in \text{null} T $。于是  $ \text{null} T $ 对标量乘法封闭。