证明 为证 (a)，设  $ v_{1}, \ldots, v_{n} $ 是实向量空间 V 的基．那么，在复向量空间  $ V_{C} $ 中  $ \operatorname{span}(v_{1}, \ldots, v_{n}) $ 包含了所有的  $ v_{1}, \ldots, v_{n}, \mathrm{iv}_{1}, \ldots, \mathrm{iv}_{n} $．因此  $ v_{1}, \ldots, v_{n} $ 张成了复向量空间  $ V_{C} $．

为证  $ v_1, \ldots, v_n $ 在复向量空间  $ V_C $ 中线性无关，设  $ \lambda_1, \ldots, \lambda_n \in \mathbb{C} $ 且

 $$ \lambda_{1}\nu_{1}+\cdots+\lambda_{n}\nu_{n}=0. $$ 

那么，由上面的等式和我们的定义可得

 $$ \left(\operatorname{Re}\lambda_{1}\right)\nu_{1}+\cdots+\left(\operatorname{Re}\lambda_{n}\right)\nu_{n}=0\quad 且 \quad\left(\operatorname{Im}\lambda_{1}\right)\nu_{1}+\cdots+\left(\operatorname{Im}\lambda_{n}\right)\nu_{n}=0. $$ 

由于  $ v_{1},\ldots,v_{n} $ 在 V 上是线性无关的，由上面的等式可得  $ \mathrm{Re}\lambda_{1}=\cdots=\mathrm{Re}\lambda_{n}=0 $ 且  $ \mathrm{Im}\lambda_{1}=\cdots=\mathrm{Im}_{n}=0 $ 。于是  $ \lambda_{1}=\cdots=\lambda_{n}=0 $ 。因此  $ v_{1},\ldots,v_{n} $ 在  $ V_{C} $ 中是线性无关的，这就完成了 (a) 的证明。

显然，由(a)立即可得(b).

## 算子的复化

现在我们可以定义算子的复化.

9.5 定义 $T$ 的复化（complexification of $T$），$T_C$

设 $V$ 是实向量空间，$T \in \mathcal{L}(V)$。$T$ 的复化是定义为 $T_C(u + iv) = Tu + iTv$ 的算子 $T_C \in \mathcal{L}(V_C)$，其中 $u, v \in V$。

请自行验证，如果  $ V $ 是实向量空间， $ T \in \mathcal{L}(V) $，则  $ T_C $ 确实属于  $ \mathcal{L}(V_C) $。这里的关鍵是，我们对复标量乘法的定义可用来证明：对所有  $ u, v \in V $ 和所有复数  $ \lambda $ 有  $ T_C(\lambda(u + iv)) = \lambda T_C(u + iv) $。

以下例子是理解典型算子复化的好方法.

9.6 例 设  $ A $ 是  $ n \times n $ 的实矩阵．定义  $ T \in \mathcal{L}(\mathbf{R}^n) $ 为  $ Tx = Ax $，其中将  $ \mathbf{R}^n $ 中元素看作  $ n \times 1 $ 列向量．将  $ \mathbf{C}^n $ 等同于  $ \mathbf{R}^n $ 的复化，对每个  $ z \in \mathbf{C}^n $ 有  $ T_{\mathbf{C}}z = Az $，其中仍将  $ \mathbf{C}^n $ 中元素看作  $ n \times 1 $ 列向量．

也就是说，如果 T 是 A 确定的  $ R^{n} $ 上的矩阵乘算子，那么复化  $ T_{C} $ 也是 A 确定的矩阵乘算子，只是作用在更大的定义域  $ C^{n} $ 上.

以下命题是有意义的，因为 9.4 告诉我们，实向量空间的基也是它的复化的基。以下命题的证明由定义立即可得.

### 9.7 $ T_{C} $ 的矩阵等于 T 的矩阵

设  $ v_1, \ldots, v_n $ 是实向量空间  $ V $ 的基， $ T \in \mathcal{L}(V) $。则  $ \mathcal{M}(T) = \mathcal{M}(T_C) $，其中这两个矩阵都是关于基  $ v_1, \ldots, v_n $ 的矩阵。