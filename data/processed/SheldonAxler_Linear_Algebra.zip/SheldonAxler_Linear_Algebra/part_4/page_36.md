我们更仔细地把这些基明确地包含在记号中．定理成立是根据矩阵乘法的定义（参见3.43及其前面的内容）.

### 10.4 线性映射之积的矩阵

假设  $ u_{1},\ldots,u_{n} $ 和  $ v_{1},\ldots,v_{n} $ 以及  $ w_{1},\ldots,w_{n} $ 都是 V 的基. 设  $ S,T\in\mathcal{L}(V) $. 则

 $$ \mathcal{M}(S T,(u_{1},\ldots,u_{n}),(w_{1},\ldots,w_{n}))= $$ 

 $$ \mathcal{M}\big(S,\big(\nu_{1},\dots,\nu_{n}\big),\big(w_{1},\dots,w_{n}\big)\big)\mathcal{M}\big(T,\big(u_{1},\dots,u_{n}\big),\big(\nu_{1},\dots,\nu_{n}\big)\big). $$ 

以下定理讨论的是恒等算子 I 关于两个不同的基的矩阵．注意，把  $ u_{k} $ 写成  $ v_{1},\ldots,v_{n} $ 的线性组合，所用的标量就构成  $ \mathcal{M}\big(I,(u_{1},\ldots,u_{n}),(v_{1},\ldots,v_{n})\big) $ 的第 k 列.

### 10.5 恒等算子关于两个基的矩阵

设  $ u_{1},\ldots,u_{n} $ 和  $ v_{1},\ldots,v_{n} $ 都是 V 的基．则矩阵  $ \mathcal{M}(I,(u_{1},\ldots,u_{n}),(v_{1},\ldots,v_{n})) $ 和  $ \mathcal{M}(I,(v_{1},\ldots,v_{n}),(u_{1},\ldots,u_{n})) $ 都是可逆的，且它们互为逆.

证明 在 10.4 中，用  $ u_{j} $ 代替  $ w_{j} $，用 I 代替 S 和 T，可得

 $$ I=\mathcal{M}\big(I,\big(\nu_{1},\ldots,\nu_{n}\big),\big(u_{1},\ldots,u_{n}\big)\big)\mathcal{M}\big(I,\big(u_{1},\ldots,u_{n}\big),\big(\nu_{1},\ldots,\nu_{n}\big)\big). $$ 

互换诸 u 和诸 v 的角色，可得

 $$ \mathcal{M}\left(I,\left(u_{1},\ldots,u_{n}\right),\left(v_{1},\ldots,v_{n}\right)\right)\mathcal{M}\left(I,\left(v_{1},\ldots,v_{n}\right),\left(u_{1},\ldots,u_{n}\right)\right). $$ 

由这两个等式即得所要的结果.

10.6 例 考虑  $ F^{2} $ 的基  $ (4,2) $， $ (5,3) $ 和  $ (1,0) $， $ (0,1) $。显然

 $$ \mathcal{M}\Big(I,\big((4,2),(5,3)\big),\big((1,0),(0,1)\big)\Big)=\left(\begin{array}{cc}{{{4}}}&{{{5}}} \\{{{2}}}&{{{3}}} \\\end{array}\right), $$ 

因为  $ I(4,2)=4(1,0)+2(0,1) $ 且  $ I(5,3)=5(1,0)+3(0,1) $.

请自行验证，上面矩阵的逆是

 $$ \left(\begin{array}{c c}{\frac{3}{2}}&{-\frac{5}{2}}\\ {-1}&{2}\end{array}\right), $$ 

于是由 10.5 可得

 $$ \mathcal{M}\Big(I,\big((1,0),(0,1)\big),\big((4,2),(5,3)\big)\Big)=\left(\begin{array}{c c}\frac{3}{2}&-\frac{5}{2}\\ -1&2\end{array}\right). $$ 

现在我们可以看到在基变更时 T 的矩阵是怎样变化的．在以下定理中，我们有 V 的两个不同的基．回忆一下，记号  $ \mathcal{M}(T,(u_{1},\ldots,u_{n})) $ 是  $ \mathcal{M}(T,(u_{1},\ldots,u_{n}),(u_{1},\ldots,u_{n})) $ 的缩写.