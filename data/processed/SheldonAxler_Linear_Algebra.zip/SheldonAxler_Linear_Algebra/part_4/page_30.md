9.31  $ \sum_{j=1}^{m}\|Te_{j}\|^{2}=A $ 的元素绝对值的平方和.

对每个  $ j \in \{1, \ldots, m\} $， $ \|T^* e_j\|^2 $ 等于  $ A $ 和  $ B $ 的第  $ j $ 行元素的绝对值的平方和。因此

9.32

 $$ \sum_{j=1}^{m}\left\|T^{*}e_{j}\right\|^{2}=A 和 B 的元素绝对值的平方和 . $$ 

因为 T 是正规的，根据 7.20，对每个 j 都有  $ \|T e_{j}\| = \|T^{*} e_{j}\| $。于是

 $$ \sum_{j=1}^{m}\left\|T e_{j}\right\|^{2}=\sum_{j=1}^{m}\left\|T^{*}e_{j}\right\|^{2}. $$ 

由这个等式和 9.31 及 9.32 可知，B 的元素绝对值的平方和等于 0. 也就是说，B 是所有元素均为 0 的矩阵. 于是

 $$ e_{1}\quad\ldots\quad e_{m}\quad f_{1}\quad\ldots\quad f_{n} $$ 

9.33

 $$ \begin{aligned}\mathcal{M}(T)&=\begin{array}{c}e_{1}\\\vdots\\e_{m}\\f_{1}\\\vdots\\f_{n}\\\end{array}\begin{array}{c}e_{1}\cdots e_{m}J_{1}\cdots J_{n}\\\end{array}\\&\begin{array}{c}A\\0\\0\\0\\C\\\end{array}\end{array}\\ \end{aligned}. $$ 

这表明，对每个  $ k $， $ Tf_k $ 在  $ f_1, \ldots, f_n $ 张成的子空间中．因为  $ f_1, \ldots, f_n $ 是  $ U^\perp $ 的基，从而只要  $ v \in U^\perp $ 就有  $ Tv \in U^\perp $．也就是说  $ U^\perp $ 在  $ T $ 下不变．这就证明了 (a)．

要让 (b)，注意到  $ \mathcal{M}(T) $ 的共轭转置  $ \mathcal{M}(T^{*}) $ 的左下角有一个由 0 构成的块（这是因为，如上所示， $ \mathcal{M}(T) $ 在右上角有一个由 0 构成的块）。也就是说，每个  $ T^{*}e_{j} $ 可写成  $ e_{1},\ldots,e_{m} $ 的线性组合。于是 U 在  $ T^{*} $ 下不变。这就证明了 (b).

要证 (c)，令  $ S = T|_{U} \in \mathcal{L}(U) $。取定  $ \nu \in U $。则对所有  $ u \in U $ 都有

 $$ \langle S u,\nu\rangle=\langle T u,\nu\rangle=\langle u,T^{*}\nu\rangle. $$ 

根据 (b)， $ T^*v \in U $，所以上式表明  $ S^*v = T^*v $。也就是说  $ (T|_U)^* = (T^*)|_{U} $。这就证明了 (c)。

要证 (d)，注意到 T 与  $ T^{*} $ 可交换（因为 T 是正规的），并且由 (c) 知  $ (T|U)^{*} = (T^{*})|U $．于是， $ T|U $ 与它的伴随可交换，因此是正规的．根据 (a)，互换 U 和  $ U^{\perp} $ 的角色可知  $ T|_{U^{\perp}} $ 也是正规的．这就证明了 (d)．

以下定理表明实内积空间上的正规算子接近于有对角矩阵．具体来说，我们得到每个块最大为  $ 2 \times 2 $ 的分块对角矩阵.

我们不能指望得到比以下定理更好的结

注意，若算子 T 关于某个基有分块

对角矩阵，则这个矩阵的对角线上

每个  $ 1 \times 1 $ 块上的元素都是 T 的本

征值.

