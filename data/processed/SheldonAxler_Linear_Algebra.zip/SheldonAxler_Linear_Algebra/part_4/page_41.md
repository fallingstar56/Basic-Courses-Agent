其中第一个和最后一个等式由 10.16 得到．根据矩阵的迹的定义，第三个等式是显然的．

以下定理的叙述并未涉及，但其简短证明却用到了迹．在数学中一旦有类似的事情发生，我们可以确信背后一定隐藏着一个很好的定义．

利用前面这些方法可以得到下面的奇妙结果．这个结果在无限维向量空间上的推广可以导出现代物理（特别是量子理论）的一些重要结论.



### 10.19 恒等算子不是 ST 与 TS 之差

不存在算子  $ S, T \in \mathcal{L}(V) $ 使得  $ ST - TS = I $.

证明 设  $ S, T \in \mathcal{L}(V) $. 取 V 的一个基. 则

 $$ \begin{aligned}\mathrm{trace}(ST-TS)&=\mathrm{trace}(ST)-\mathrm{trace}(TS)\\&=\mathrm{trace}\mathcal{M}(ST)-\mathrm{trace}\mathcal{M}(TS)\\&=\mathrm{trace}\big(\mathcal{M}(S)\mathcal{M}(T)\big)-\mathrm{trace}\big(\mathcal{M}(T)\mathcal{M}(S)\big)\\&=0,\end{aligned} $$ 

第一个等式由 10.18 得到，第二个等式由 10.16 得到，第三个等式由 3.43 得到，第四个等式由 10.14 得到．显然 I 的迹等于 dim V，不等于 0．因为 ST-TS 和 I 有不同的迹，所以它们不相等．

### 习题 10.A

1 设  $ T \in \mathcal{L}(V) $， $ v_1, \ldots, v_n $ 是 V 的基．证明：矩阵  $ \mathcal{M}(T, (v_1, \ldots, v_n)) $ 是可逆的当且仅当 T 是可逆的.

2 设 A 和 B 是大小相同的方阵且 AB = I. 证明 BA = I.

3 设  $ T \in \mathcal{L}(V) $ 关于  $ V $ 的每个基的矩阵都相同．证明  $ T $ 是恒等算子的标量倍．

4 设  $ u_{1},\ldots,u_{n} $ 和  $ v_{1},\ldots,v_{n} $ 都是 V 的基．设算子  $ T\in\mathcal{L}(V) $ 使得对  $ k=1,\ldots,n $ 都有  $ Tv_{k}=u_{k} $．证明：

 $$ \mathcal{M}\big(T,(\nu_{1},\dots,\nu_{n})\big)=\mathcal{M}\big(I,(u_{1},\dots,u_{n}),(\nu_{1},\dots,\nu_{n})\big). $$ 

5 设 B 是复方阵，证明：存在可逆的复方阵 A 使得  $ A^{-1}BA $ 是上三角矩阵.

6 找出一个实向量空间  $ V $ 及  $ T \in \mathcal{L}(V) $ 的例子，使得  $ \text{trace}(T^2) < 0 $.

7 设  $ V $ 是实向量空间， $ T \in \mathcal{L}(V) $， $ V $ 有一个由  $ T $ 的本征向量组成的基．证明  $ \text{trace}(T^2) \geq 0 $．

8 设 V 是内积空间， $ v,w \in V $。定义  $ T \in \mathcal{L}(V) $ 为  $ Tu = \langle u,v \rangle w $。求 trace  $ T $。

9 设  $ P \in \mathcal{L}(V) $ 满足  $ P^{2} = P $。证明 trace  $ P = \dim \text{range} P $。