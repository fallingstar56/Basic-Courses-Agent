### 8.59 定义 若尔当基（Jordan basis）

设  $ T \in \mathcal{L}(V) $.  $ V $ 的基称为  $ T $ 的若尔当基，如果  $ T $ 关于这个基具有分块对角矩阵

 $$ \left(\begin{array}{c c c}{A_{1}}&{}&{0}\\ {}&{\ddots}&{}\\ {}&{}&{A_{p}}\\ {0}&{}&{}\\ \end{array}\right), $$ 

其中每个  $ A_{j} $ 都是形如

 $$ \boldsymbol{A}_{j}=\left(\begin{array}{c c c c}{{{\lambda_{j}}}}&{{{1}}}&{{{0}}} \\{{{\ddots}}}&{{{\ddots}}} \\{{{\ddots}}}&{{{1}}} \\{{{0}}}&{{{\lambda_{j}}}}\end{array}\right) $$ 

的上三角矩阵.

### 8.60 若尔当形

设 V 是复向量空间．如果  $ T \in \mathcal{L}(V) $，则 V 有一个基是 T 的若尔当基．

证明 首先考虑幂零算子  $ N \in \mathcal{L}(V) $ 和 8.55 给出的向量  $ v_1, \ldots, v_n \in V $。注意到，对于每个  $ j $， $ N $ 都将组  $ N^{m_j}v_j, \ldots, Nv_j, v_j $ 中的第一个向量映成  $ 0 $，并且  $ N $ 将这个组中除第一个向量之外的其余向量映成了它的前一个向量。也就是说，8.55 给出了  $ V $ 的一个基，关于这个基， $ N $ 具有分块对角矩阵，其中对角线上的每个矩阵都形如

 $$ \begin{pmatrix}{{{0}}}&{{{1}}}&{{{0}}} \\{{{\ddots}}}&{{{\ddots}}} \\{{{\ddots}}}&{{{1}}} \\{{{0}}}&{{{0}}}\end{pmatrix}. $$ 

因此结论对幂零算子成立.

现在设  $ T \in \mathcal{L}(V) $。设  $ \lambda_1, \ldots, \lambda_m $ 是  $ T $ 的所有不同的本征值。于是有广义本征空间分解

 $$ V=G(\lambda_{1},T)\oplus\cdots\oplus G(\lambda_{m},T), $$ 

其中每个  $ (T - \lambda_j I)|_{G(\lambda_j, T)} $ 都是幂零的（参见 8.21）。于是每个  $ G(\lambda_j, T) $ 的某个基是  $ (T - \lambda_j I)|_{G(\lambda_j, T)} $ 的若尔当基（参见上一段）。将这些基组合起来就得到了  $ V $ 的一个基，并且是  $ T $ 的若尔当基。