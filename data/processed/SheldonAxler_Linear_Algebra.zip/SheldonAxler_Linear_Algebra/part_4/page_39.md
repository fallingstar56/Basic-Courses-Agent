### 10.14 AB 的迹等于 BA 的迹

如果 A 和 B 是相同阶数的方阵，则  $ \mathrm{trace}(AB)=\mathrm{trace}(BA) $.

证明 假设

 $$ \boldsymbol{A}=\left(\begin{array}{ccc}A_{1,1}&\cdots&A_{1,n}\\\vdots&&\vdots\\A_{n,1}&\cdots&A_{n,n}\\\end{array}\right),\quad\boldsymbol{B}=\left(\begin{array}{ccc}B_{1,1}&\cdots&B_{1,n}\\\vdots&&\vdots\\B_{n,1}&\cdots&B_{n,n}\\\end{array}\right). $$ 

AB的对角线上的第j项等于

 $$ \sum_{k=1}^{n}A_{j,k}B_{k,j}. $$ 

因此

 $$ \begin{aligned}trace(AB)&=\sum_{j=1}^{n}\sum_{k=1}^{n}A_{j,k}B_{k,j}\\&=\sum_{k=1}^{n}\sum_{j=1}^{n}B_{k,j}A_{j,k}\\&=\sum_{k=1}^{n}(BA 对角线上的第 k 项 )\\&=trace(BA).\end{aligned} $$ 

证毕.

现在可以证明，算子关于某个基的矩阵的对角线元素之和并不依赖于这个基。

### 10.15 算子的矩阵的迹不依赖于基

设  $ T \in \mathcal{L}(V) $. 如果  $ u_1, \ldots, u_n $ 和  $ v_1, \ldots, v_n $ 都是 V 的基，则

 $$ \mathrm{t r a c e}\mathcal{M}\big(T,(u_{1},\ldots,u_{n})\big)=\mathrm{t r a c e}\mathcal{M}\big(T,(\nu_{1},\ldots,\nu_{n})\big). $$ 

证明 设  $ A = \mathcal{M}(I, (u_1, \ldots, u_n), (v_1, \ldots, v_n)) $．则

 $$ \begin{align*}\mathrm{trace}\mathcal{M}\big(T,(u_{1},\ldots,u_{n})\big)&=\mathrm{trace}\Big(A^{-1}\big(\mathcal{M}\big(T,(\nu_{1},\ldots,\nu_{n})\big)A\big)\Big)\\&=\mathrm{trace}\Big(\big(\mathcal{M}\big(T,(\nu_{1},\ldots,\nu_{n})\big)A\big)A^{-1}\Big)\\&=\mathrm{trace}\mathcal{M}\big(T,(\nu_{1},\ldots,\nu_{n})\big),\end{align*} $$ 

其中第一个等式由 10.7 得到，第二个等式由 10.14 得到.

以下定理是本节最重要的结果，说的是算子的迹等于该算子的矩阵的对角线元素之和．这个定理没有指明所用到的基，因为根据上面的结果，对每个基来说，算子的矩阵的对角线元素之和都相同.