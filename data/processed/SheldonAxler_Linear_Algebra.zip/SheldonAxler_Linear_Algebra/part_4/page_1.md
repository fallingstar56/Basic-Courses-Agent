前面我们观察到，若  $ T \in \mathcal{L}(V) $，则 null T 和 range T 都在 T 下不变（参见 5.3 的 (c) 和 (d)）。现在我们要证明，T 的每个多项式的零空间和像空间也在 T 下不变。

8.20  $ p(T) $ 的零空间和像空间在 T 下是不变的
如果  $ T \in \mathcal{L}(V) $ 且  $ p \in \mathcal{P}(\mathbf{F}) $，则  $ null_{p}(T) $ 和  $ range_{p}(T) $ 在 T 下不变.
证明 如果  $ v \in \text{null} p(T) $，则  $ p(T)v = 0 $。因此
 $ \left((p(T))(Tv)=T(p(T)v)=T(0)=0.\right. $
从而  $ Tv \in \text{null} p(T) $。于是  $ \text{null} p(T) $ 在 T 下不变。
如果  $ v \in \text{range} p(T) $，则存在  $ u \in V $ 使得  $ v = p(T)u $。因此
 $ Tv = T(p(T)u) = p(T)(Tu). $
从而  $ Tv \in \text{range} p(T) $。于是  $ \text{range} p(T) $ 在 T 下不变。

下面的主要结构定理说明，复向量空间上的每个算子都可以看成是由几部分组成的，其中每一部分都是恒等算子的标量倍加上一个幂零算子．事实上，在广义本征空间  $ G(\lambda,T) $ 的讨论中已经完成所有困难的工作，所以现在的证明就简单了.

8.21 复向量空间上算子的刻画

假设 V 是复向量空间， $ T \in \mathcal{L}(V) $。设  $ \lambda_1, \ldots, \lambda_m $ 是 T 的不同本征值，则

(a)  $ V = G(\lambda_1, T) \oplus \cdots \oplus G(\lambda_m, T) $;

(b) 每个  $ G(\lambda_j, T) $ 在 T 下都是不变的；

(c) 每个  $ (T - \lambda_j I)|_{G(\lambda_j, T)} $ 都是幂零的.

证明 令  $ n = \dim V $ 。回想一下，对每个 j 有  $ G(\lambda_{j}, T) = \text{null}(T - \lambda_{j} I)^{n} $ （由于 8.11）。由 8.20（取  $ p(z) = (z - \lambda_{j})^{n} $）可得 (b)。显然，由定义可得 (c)。

我们将通过对 n 用归纳法来证明 (a). 首先，注意到结果对 n = 1 成立. 因此假设 n > 1 且结果对所有更小维数的向量空间都成立.

因为 V 是复向量空间，所以 T 有一个本征值（参见 5.21），于是  $ m \geq 1 $ 。将 8.5 应用到  $ (T - \lambda_{1}I) $ 上得到

### 8.22 

 $$ V=G(\lambda_{1},T)\oplus U, $$ 

其中  $ U = \text{range}(T - \lambda_1 I)^n $。利用 8.20（取  $ p(z) = (z - \lambda_1)^n $），我们看到  $ U $ 在  $ T $ 下不变。由于  $ G(\lambda_1, T) \neq \{0\} $，我们有  $ \dim U < n $。于是可以对  $ T |_U $ 应用归纳假设。

因为 T 的所有相应于  $ \lambda_{1} $ 的广义本征向量都在  $ G(\lambda_{1}, T) $ 中，所以  $ T|_{U} $ 没有相应于本征值  $ \lambda_{1} $ 的广义本征向量．于是  $ T|_{U} $ 的每个本征值都在  $ \{\lambda_{2}, \ldots, \lambda_{m}\} $ 中．

由归纳假设， $ U = G(\lambda_2, T |_U) \oplus \cdots \oplus G(\lambda_m, T |_U) $。把它与8.22结合起来可知，要完成证明，只需证明对 $ k = 2, \ldots, m $均有 $ G(\lambda_k, T |_U) = G(\lambda_k, T) $。