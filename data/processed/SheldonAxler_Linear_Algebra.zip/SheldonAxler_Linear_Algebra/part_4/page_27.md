2 设 V 是实向量空间， $ T \in \mathcal{L}(V) $。证明  $ T_C \in \mathcal{L}(V_C) $。

3 设 V 是实向量空间， $ v_{1}, \ldots, v_{m} \in V $。证明： $ v_{1}, \ldots, v_{m} $ 在  $ V_{C} $ 上线性无关当且仅当  $ v_{1}, \ldots, v_{m} $ 在 V 上线性无关。

4 设 V 是实向量空间， $ v_{1}, \ldots, v_{m} \in V $。证明： $ v_{1}, \ldots, v_{m} $ 张成  $ V_{C} $ 当且仅当  $ v_{1}, \ldots, v_{m} $ 张成 V。

5 设 V 是实向量空间， $ S, T \in \mathcal{L}(V) $。证明： $ (S + T)_\mathbf{C} = S_\mathbf{C} + T_\mathbf{C} $， $ (\lambda T)_\mathbf{C} = \lambda T_\mathbf{C} $ ( $ \lambda \in \mathbf{R} $).

6 设 V 是实向量空间， $ T \in \mathcal{L}(V) $。证明： $ T_C $ 可逆当且仅当  $ T $ 可逆。

7 设  $ V $ 是实向量空间， $ N \in \mathcal{L}(V) $。证明： $ N_C $ 是幂零的当且仅当  $ N $ 是幂零的。

8 设  $ T \in \mathcal{L}(\mathbf{R}^3) $，5,7 是 T 的本征值。证明  $ T_C $ 没有非实的本征值。

9 证明没有算子  $ T \in \mathcal{L}(\mathbf{R}^7) $ 使得  $ (T^2 + T + I) $ 是幂零的.

10 找出一个算子  $ T \in \mathcal{L}(\mathbf{C}^7) $ 使得  $ (T^2 + T + I) $ 是幂零的.

11 设 V 是实向量空间， $ T \in \mathcal{L}(V) $，存在  $ b, c \in \mathbb{R} $ 使得  $ T^2 + bT + cI = 0 $。证明：T 有本征值当且仅当  $ b^2 \geq 4c $。

12 设 V 是实向量空间， $ T \in \mathcal{L}(V) $，存在  $ b, c \in \mathbb{R} $ 使得  $ b^2 < 4c $ 且  $ (T^2 + bT + cI) $ 是幂零的．证明 T 没有本征值．

13 设  $ V $ 是实向量空间， $ T \in \mathcal{L}(V) $， $ b, c \in \mathbb{R} $ 使得  $ b^2 < 4c $。证明：对于每个正整数  $ j $， $ \text{null}(T^2 + bT + cI)^j $ 的维数都是偶数。

14 设 V 是实向量空间， $ \dim V = 8, T \in \mathcal{L}(V) $ 使得  $ (T^{2} + T + I) $ 是幂零的．证明  $ (T^{2} + T + I)^{4} = 0 $

15 设  $ V $ 是实向量空间， $ T \in \mathcal{L}(V) $ 没有本征值．证明： $ V $ 的每个在  $ T $ 下不变的子空间都是偶数维的．

16 设 V 是实向量空间．证明：存在  $ T \in \mathcal{L}(V) $ 使得  $ T^{2} = -I $ 当且仅当 V 是偶数维的．

17 设  $ V $ 是实向量空间， $ T \in \mathcal{L}(V) $ 满足  $ T^2 = -I $。在  $ V $ 上定义复标量乘法如下：若  $ a, b \in \mathbb{R} $ 则  $ (a + bi)v = av + bTv $。证明：

(a) 上面定义的 V 上复标量乘法和 V 上的加法使 V 成为一个复向量空间.

(b) V 作为复向量空间的维数是 V 作为实向量空间的维数的一半.

18 设 V 是实向量空间， $ T \in \mathcal{L}(V) $。证明以下条件等价：

(a)  $ T_{C} $ 的所有本征值都是实的.

(b) V 有一个基使得 T 关于这个基有上三角矩阵.

(c) V 有一个由 T 的广义本征向量组成的基.

19 设 V 是实向量空间， $ \dim V = n, T \in \mathcal{L}(V) $ 使得  $ \text{null } T^{n-2} \neq \text{null } T^{n-1} $。证明：T 最多有两个不同的本征值， $ T_C $ 没有非实的本征值。