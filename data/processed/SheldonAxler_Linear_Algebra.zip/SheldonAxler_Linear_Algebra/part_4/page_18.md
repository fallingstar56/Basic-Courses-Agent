1 求例 8.53 中算子 N 的特征多项式和极小多项式.

2 求例 8.54 中算子 N 的特征多项式和极小多项式.

3 设  $ N \in \mathcal{L}(V) $ 是幂零的．证明：N 的极小多项式是  $ z^{m+1} $，其中 m 是 N 关于任意若尔当基的矩阵中紧位于对角线上方的直线上连续出现的 1 的最大个数．

4 设  $ T \in \mathcal{L}(V) $， $ v_1, \ldots, v_n $ 是  $ V $ 的基，且为  $ T $ 的若尔当基。试描述  $ T $ 关于基  $ v_n, \ldots, v_1 $ 的矩阵。

5 设  $ T \in \mathcal{L}(V) $， $ v_1, \ldots, v_n $ 是  $ V $ 的基，且为  $ T $ 的若尔当基。试描述  $ T^2 $ 关于这个基的矩阵。

6 设  $ N \in \mathcal{L}(V) $ 是幂零的， $ v_1, \ldots, v_n $ 和  $ m_1, \ldots, m_n $ 如 8.55 中所示．证明  $ N^{m_1} v_1, \ldots, N^{m_n} v_n $ 是 null N 的基．

由本题可知， $ n $ 等于 dim null N，只依赖于 N，不依赖于为 N 选取的那个特殊的若尔当基．

7 设  $ p, q \in \mathcal{P}(\mathbf{C}) $ 是具有相同零点的首一多项式， $ q $ 是  $ p $ 的多项式倍．证明：存在  $ T \in \mathcal{L}(\mathbf{C}^{\deg q}) $ 使得  $ T $ 的特征多项式是  $ q $ 且  $ T $ 的极小多项式是  $ p $．

8 设  $ V $ 是复向量空间， $ T \in \mathcal{L}(V) $。证明： $ V $ 不能分解成  $ V $ 的两个在  $ T $ 下不变的真子空间的直和当且仅当  $ T $ 的极小多项式形如  $ (z - \lambda)^{\dim V} $，其中  $ \lambda \in \mathbb{C} $。