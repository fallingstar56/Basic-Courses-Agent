 $$ R\nu=R_{1}u_{1}+\cdots+R_{m}u_{m}. $$ 

请自行验证，这个算子 R 是 T 的平方根.

仿照本节的方法能够证明：如果 V 是复向量空间， $ T \in \mathcal{L}(V) $ 是可逆的，那么对每个正整数 k，T 都有 k 次方根。

### 习题 8.B

1 设 V 是复向量空间， $ N \in \mathcal{L}(V) $ 且 0 是 N 仅有的本征值．证明 N 是幂零的．

2 找出有限维实向量空间上的一个算子 T，使得 0 是 T 仅有的本征值，但 T 不是幂零的.

3 设  $ T \in \mathcal{L}(V) $. 设  $ S \in \mathcal{L}(V) $ 是可逆的. 证明 T 和  $ S^{-1}TS $ 有相同的本征值, 且它们的重数也相同.

4 设 V 是 n 维复向量空间，T 是 V 上的算子使得  $ \mathrm{null}T^{n-2} \neq \mathrm{null}T^{n-1} $ 。证明 T 最多有两个不同的本征值。

5 设  $ V $ 是复向量空间， $ T \in \mathcal{L}(V) $。证明： $ V $ 有一个由  $ T $ 的本征向量组成的基当且仅当  $ T $ 的每个广义本征向量都是  $ T $ 的本征向量。

对于 F = C，本题给 5.41 的等价条件列表添加了一个等价条件。

6 定义  $ N \in \mathcal{L}(\mathbf{F}^5) $ 为

 $$ N(x_{1},x_{2},x_{3},x_{4},x_{5})=(2x_{2},3x_{3},-x_{4},4x_{5},0). $$ 

求 $ (I+N) $的一个平方根.

7 设 V 是复向量空间．证明 V 上的每个可逆算子都有三次方根．

8 设  $ T \in \mathcal{L}(V) $，3 和 8 都是 T 的本征值。令  $ n = \dim V $。证明：

 $$ V=(\mathrm{n u l l}T^{n-2})\oplus(\mathrm{r a n g e}T^{n-2}). $$ 

9 设 A 和 B 是形如

 $$ \boldsymbol{A}=\left(\begin{array}{ccc}{{{\boldsymbol{A}_{1}}}}&{{{0}}} \\{{{\ddots}}} \\{{{0}}}&{{{\boldsymbol{A}_{m}}}} \\\end{array}\right),\quad\boldsymbol{B}=\left(\begin{array}{ccc}{{{\boldsymbol{B}_{1}}}}&{{{0}}} \\{{{\ddots}}} \\{{{0}}}&{{{\boldsymbol{B}_{m}}}} \\\end{array}\right) $$ 

的分块对角矩阵，对于  $ j = 1, \ldots, m $， $ A_j $ 与  $ B_j $ 大小相同．证明：AB 是分块对角矩阵

 $$ \boldsymbol{A}\boldsymbol{B}=\left(\begin{array}{ccc}{{{\boldsymbol{A}_{1}\boldsymbol{B}_{1}}}}&{{{0}}} \\{{{\ddots}}} \\{{{0}}}&{{{\boldsymbol{A}_{m}\boldsymbol{B}_{m}}}}\end{array}\right). $$ 

10 设  $ \mathbf{F} = \mathbf{C} $， $ T \in \mathcal{L}(V) $。证明：存在  $ D, N \in \mathcal{L}(V) $ 使得  $ T = D + N $，算子  $ D $ 是可对角化的， $ N $ 是幂零的， $ DN = ND $。

11 设  $ T \in \mathcal{L}(V) $， $ \lambda \in \mathbf{F} $。证明：对  $ V $ 的每个使得  $ T $ 有上三角矩阵的基， $ \lambda $ 出现在  $ T $ 的矩阵的对角线上的次数等于  $ \lambda $ 作为  $ T $ 的本征值的重数。