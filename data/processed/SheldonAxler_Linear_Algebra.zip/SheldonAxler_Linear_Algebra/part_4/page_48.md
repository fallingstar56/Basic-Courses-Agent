都不是自然顺序，则现在它和那两个被交换的元素都是自然顺序．如果一个中间元素最初只与那两个被交换的元素之一是自然顺序，则结果仍是如此．于是，对于中间的每个元素来说，非自然顺序数对的数目的净改变量为2、-2或0（都是偶数）.

对于所有其他的元素，非自然顺序数对的数量没有变化．所以非自然顺序数对的数量的变化总量是一个奇数．于是第二个排列的符号等于 -1 乘以第一个排列的符号．

下一个定义的动机来自 10.29.

### 10.33 定义 矩阵的行列式（determinant of a matrix），det A

 $ n \times n $ 矩阵

 $$ \boldsymbol{A}=\left(\begin{array}{ccc}A_{1,1}&\cdots&A_{1,n}\\\vdots&&\vdots\\A_{n,1}&\cdots&A_{n,n}\end{array}\right) $$ 

的行列式（记作  $ \det A $）定义为

 $$ \det A=\sum_{(m_{1},\ldots,m_{n})\in\mathrm{perm}n}\left(\mathrm{sign}(m_{1},\ldots,m_{n})\right)A_{m_{1},1}\cdots A_{m_{n},n}. $$ 

### 10.34 例 行列式

• 若 A 是  $ 1 \times 1 $ 矩阵  $ (A_{1,1}) $，则  $ \det A = A_{1,1} $，因为 perm1 只有一个元素，即 (1)，所以它的符号是 1.

• 显然 perm2 有两个元素，即  $ (1,2) $ 和  $ (2,1) $. 其符号分别是 1 和 -1. 因此

 $$ \det\left(\begin{array}{cc}A_{1,1}&A_{1,2}\\A_{2,1}&A_{2,2}\\\end{array}\right)=A_{1,1}A_{2,2}-A_{2,1}A_{1,2}. $$ 

为保证理解这个过程，你应该仅用上面给出的定义找出任意  $ 3 \times 3 $ 矩阵的行列式公式.

perm3 有 6 个元素. 一般来说,

perm n 有 n! 个元素. 注意, 随着

n 的增大, n! 迅速增大.



### 10.35 例 计算上三角矩阵

 $$ \boldsymbol{A}=\left(\begin{array}{ccc}A_{1,1}&&*\\&\ddots&\\&&0&A_{n,n}\end{array}\right) $$ 

的行列式.

解 排列  $ (1,2,\ldots,n) $ 的符号为 1，因此对 10.33 中定义  $ \det A $ 的求和式贡献了一项  $ A_{1,1}\cdots A_{n,n} $。任意其他的排列  $ (m_1,\ldots,m_n)\in\operatorname{perm}n $ 至少包含一个元素  $ m_j $ 使得