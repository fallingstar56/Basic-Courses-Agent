9.35 例 设  $ \theta \in \mathbb{R} $. 则  $ R^2 $ 上（以原点为中心）的逆时针旋转  $ \theta $ 角度的算子是等距同构，这在几何上看是显然的. 这个算子关于标准基的矩阵是

 $$ \left(\begin{array}{c c}{\cos\theta}&{-\sin\theta}\\ {}&{}\\ {\sin\theta}&{\cos\theta}\\ \end{array}\right). $$ 

若  $ \theta $ 不是  $ \pi $ 的整数倍，则  $ R^{2} $ 上没有可以映为其自身的标量倍的非零向量，因此这个算子没有本征值.

以下定理表明，实内积空间上的每个等距同构由以下三部分组成：一部分是二维子空间上的旋转，一部分是恒等算子，一部分是乘以 -1.

### 9.36 F = R 时等距同构的刻画

设 V 是实内积空间， $ S \in \mathcal{L}(V) $。则以下条件等价：

(a) S 是等距同构.

(b) V 有规范正交基使得 S 关于这个基有分块对角矩阵，对角线上的每个块是由 1 或 -1 构成的  $ 1 \times 1 $ 矩阵，或者是形如

 $$ \left(\begin{array}{cc}\cos\theta&-\sin\theta\\ \sin\theta&\cos\theta\end{array}\right) $$ 

的  $ 2 \times 2 $ 矩阵，其中  $ \theta \in (0, \pi) $.

证明 首先假设 (a) 成立，则 S 是等距同构。因为 S 是正规的，根据定理 9.34，V 有规范正交基，S 关于这个基有分块对角矩阵，对角线上的每个块是  $ 1 \times 1 $ 矩阵，或者是形如

9.37

 $$ \left(\begin{array}{cc}a&-b\\ b&a\end{array}\right) $$ 

的  $ 2 \times 2 $ 矩阵，其中 b > 0.

如果  $ \lambda $ 是 S（关于上述基）的矩阵对角线上  $ 1 \times 1 $ 矩阵的元素，那么存在基向量  $ e_{j} $ 使得  $ Se_{j} = \lambda e_{j} $ 。因为 S 是等距同构，所以  $ |\lambda| = 1 $ 。于是  $ \lambda = 1 $ 或  $ \lambda = -1 $ ，因为只有这两个实数的绝对值是 1 。

现在考虑位于 S 的矩阵对角线上形如 9.37 的  $ 2 \times 2 $ 矩阵．有基向量  $ e_{j}, e_{j+1} $ 使得

 $$ Se_{j}=ae_{j}+be_{j+1}. $$ 

于是

 $$ \begin{align*}1=\Vert e_j\Vert^2=\Vert S e_j\Vert^2=a^2+b^2.\end{align*} $$ 

由上式及 b > 0 可知，存在  $ \theta \in (0, \pi) $ 使得  $ a = \cos \theta $ 且  $ b = \sin \theta $。于是矩阵 9.37 具有所要求的形式，这就完成了这个方向的证明。