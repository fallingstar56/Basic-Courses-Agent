### 10.7 基变更公式

设  $ T \in \mathcal{L}(V) $. 令  $ u_{1}, \ldots, u_{n} $ 和  $ v_{1}, \ldots, v_{n} $ 是 V 的基.  $ A = \mathcal{M}(I, (u_{1}, \ldots, u_{n}), (v_{1}, \ldots, v_{n})) $. 则

 $$ \mathcal{M}\big(T,(u_{1},\ldots,u_{n})\big)=A^{-1}\mathcal{M}\big(T,(\nu_{1},\ldots,\nu_{n})\big)A. $$ 

证明 在 10.4 中，用  $ u_{j} $ 代替  $ w_{j} $，用 I 代替 S，得到

 $$ \mathcal{M}\big(T,(u_{1},\dots,u_{n})\big)=A^{-1}\mathcal{M}\big(T,(u_{1},\dots,u_{n}),(\nu_{1},\dots,\nu_{n})\big), $$ 

其中用到了 10.5.

再利用 10.4，此时用  $ v_{j} $ 代替  $ w_{j} $ 。同时也用 I 代替 T，用 T 代替 S，得到

 $$ \mathcal{M}\big(T,(u_{1},\ldots,u_{n}),(\nu_{1},\ldots,\nu_{n})\big)=\mathcal{M}\big(T,(\nu_{1},\ldots,\nu_{n})\big)A. $$ 

将上面的等式代入 10.8 即得所要的结果.

## 迹：算子与矩阵间的联系

假设  $ T \in \mathcal{L}(V) $， $ \lambda $ 是 T 的本征值。令  $ n = \dim V $。回忆一下，我们定义  $ \lambda $ 的重数为广义的本征空间  $ G(\lambda, T) $ 的维数（参见 8.24），且这个重数等于  $ \dim \text{null}(T - \lambda I)^n $（参见 8.11）。再回忆一下，若 V 是复向量空间，则 T 的所有本征值的重数之和等于  $ n $（参见 8.26）。

在下面的定义中，“按重数重复”的全体本征值之和指的是，若  $ \lambda_{1},\ldots,\lambda_{m} $ 是 T 的互不相同的本征值（或  $ T_{C} $ 的互不相同的本征值，若 V 是实向量空间），且其重数分别为  $ d_{1},\ldots,d_{m} $，则这个和为

 $$ d_{1}\lambda_{1}+\cdots+d_{m}\lambda_{m}. $$ 

或者，如果你更喜欢将本征值按其重数重复地列出来，全体本征值可记为  $ \lambda_{1},\ldots,\lambda_{n} $ （其中 n 等于 dim V），则 “按重数重复” 的全体本征值之和等于

 $$ \lambda_{1}+\cdots+\lambda_{n}. $$ 

义 算子的迹（trace of an operator）
设  $ T \in \mathcal{L}(V) $.
• 若 F = C，则 T 的迹等于 T 的按重数重复的全体本征值之和.
• 若 F = R，则 T 的迹等于  $ T_{C} $ 的按重数重复的全体本征值之和.
T 的迹记为 trace T.