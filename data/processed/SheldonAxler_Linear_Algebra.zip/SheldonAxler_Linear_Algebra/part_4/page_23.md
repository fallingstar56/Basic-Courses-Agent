综合前面两段可知，p 是  $ T_{C} $ 的极小多项式.

## 复化的本征值

现在转向算子的复化的本征值问题．和前面一样，我们期望成立的性质都成立.

先来证明  $ T_{C} $ 的所有实本征值恰为 T 的所有本征值．我们给出这一结果的两种不同的证明．第一种证明更初等，但第二种证明更短，并且给出一些有用的见解.

### 9.11 $ T_{C} $ 的实本征值

 $$ T\in\mathcal{L}(V),\ \lambda\in\mathbf{R} $$ 

 $$ T_{\mathrm{c}} $$ 

证明 1 首先假设 λ 是 T 的本征值．则存在  $ v \in V $ 且  $ v \neq 0 $ 使得  $ Tv = \lambda v $．于是  $ T_C v = \lambda v $，这就证明了  $ \lambda $ 是  $ T_C $ 的本征值，从而完成证明的一个方面．

要证明另一个方面，现在假设  $ \lambda $ 是  $ T_C $ 的本征值．则存在  $ u, v \in V $ 且  $ u + iv \neq 0 $ 使得

 $$ T_{\mathbf{C}}(u+\mathrm{i}v)=\lambda(u+\mathrm{i}v). $$ 

由上式可知  $ T_u = \lambda_u $ 且  $ T_v = \lambda_v $。因为  $ u \neq 0 $ 或  $ v \neq 0 $，所以  $ \lambda $ 是  $ T $ 的本征值。

证明 2 由于 8.49， $ T $ 的所有（实）本征值是  $ T $ 的极小多项式的所有（实）零点。仍由 8.49， $ T_C $ 的所有实本征值是  $ T_C $ 的极小多项式的所有实零点。由于 9.10，这两个极小多项式相同。于是  $ T $ 的所有本征值恰为  $ T_C $ 的所有实本征值。

以下定理表明， $ T_{C} $ 对于本征值  $ \lambda $ 与其复共轭  $ \bar{\lambda} $ 的表现是对称的.

9.12  $ T_{\mathbf{C}} - \lambda I $ 和  $ T_{\mathbf{C}} - \bar{\lambda} I $

设  $ V $ 是实向量空间， $ T \in \mathcal{L}(V) $， $ \lambda \in \mathbf{C} $， $ j $ 是非负整数， $ u, v \in V $。则

 $ (T_{\mathbf{C}} - \lambda I)^{j}(u + \mathrm{iv}) = 0 $ 当且仅当  $ (T_{\mathbf{C}} - \bar{\lambda} I)^{j}(u - \mathrm{iv}) = 0. $

证明 对 j 用归纳法．首先注意到，若 j = 0 ，则（因为一个算子的 0 次幂是恒等算子）这个定理断言  $ u + iv = 0 $ 当且仅当  $ u - iv = 0 $ ，这显然是对的.

于是，现在假设  $ j \geq 1 $ 且定理对 j - 1 成立．设  $ (T_{\mathbf{C}} - \lambda I)^{j}(u + \mathrm{iv}) = 0 $．则

9.13

 $$ (T_{\mathbf{C}}-\lambda I)^{j-1}\big((T_{\mathbf{C}}-\lambda I)(u+\mathrm{i}\nu)\big)=0. $$ 

记  $ \lambda = a + bi $，其中  $ a, b \in \mathbb{R} $，我们有

9.14

 $$ (T_{\mathbf{C}}-\lambda I)(u+\mathrm{i}v)=(T u-a u+b v)+\mathrm{i}(T v-a v-b u) $$ 

且

9.15

 $$ (T_{\mathbf{C}}-\bar{\lambda}I)(u-\mathrm{i}\nu)=(T u-a u+b\nu)-\mathrm{i}(T\nu-a\nu-b u). $$ 

由归纳法假设以及 9.13 和 9.14 可得