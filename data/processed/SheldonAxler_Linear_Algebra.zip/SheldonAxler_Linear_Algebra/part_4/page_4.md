8.28 例  $ 5 \times 5 $ 矩阵

 $$ \boldsymbol{A}=\left(\begin{array}{c c c c c}{{{\left(\begin{array}{l}4\end{array}\right)}}}&{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{\left(\begin{array}{l}2}}}&{{{-3}}} \\{{{0}}}&{{{2}}}\end{array}\right)&\left(\begin{array}{l l l}{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}\end{array}\right)\\{{{0}}}&{{{0}}}&{{{0}}}&{{{\left(\begin{array}{l}1}}}&{{{7}}} \\{{{0}}}&{{{1}}}\end{array}\right)\end{array}\right) $$ 

是分块对角矩阵

 $$ \boldsymbol{A}=\left(\begin{array}{ccc}{{{\boldsymbol{A}_{1}}}}&{{{0}}} \\{{{A_{2}}}} \\{{{0}}}&{{{\boldsymbol{A}_{3}}}} \\\end{array}\right), $$ 

其中

 $$ A_{1}=\left(\begin{array}{l}{{{4}}}\end{array}\right),\quad A_{2}=\left(\begin{array}{cc}{{{2}}}&{{{-3}}} \\{{{0}}}&{{{2}}}\end{array}\right),\quad A_{3}=\left(\begin{array}{cc}{{{1}}}&{{{7}}} \\{{{0}}}&{{{1}}}\end{array}\right). $$ 

这里，我们将  $ 5 \times 5 $ 矩阵分解成一块一块的的内部矩阵，以便说明它如何看作一个分块对角矩阵.

注意，在以下命题中，T 的矩阵比上三角矩阵有更多的零.

### 8.29 具有上三角块的分块对角矩阵

假设  $ V $ 是复向量空间， $ T \in \mathcal{L}(V) $。设  $ \lambda_1, \ldots, \lambda_m $ 是  $ T $ 的所有互不相同的本征值，重数分别为  $ d_1, \ldots, d_m $。则  $ V $ 有一个基使得  $ T $ 关于这个基有分块对角矩阵

 $$ \left(\begin{array}{c c c}{A_{1}}&{}&{0}\\ {}&{\ddots}&{}\\ {}&{}&{A_{m}}\\ {0}&{}&{}\\ \end{array}\right), $$ 

其中每个  $ A_{j} $ 都是如下所示的  $ d_{j} \times d_{j} $ 上三角矩阵：

 $$ A_{j}=\left(\begin{array}{ccc}\lambda_{j}&&*\\&\ddots&\\&&0&\lambda_{j}\\\end{array}\right). $$ 

证明 每个  $ (T - \lambda_j I)|_{G(\lambda_j, T)} $ 都是幂零的（参见 8.21(c)）。对每个  $ j $， $ G(\lambda_j, T) $ 是  $ d_j $ 维向量空间，取  $ G(\lambda_j, T) $ 的一个基，使得  $ (T - \lambda_j I)|_{G(\lambda_j, T)} $ 关于这个基的矩阵形如 8.19。于是， $ T|_{G(\lambda_j, T)} $ [等于  $ (T - \lambda_j I)|_{G(\lambda_j, T)} + \lambda_j I|_{G(\lambda_j, T)} $] 关于这个基的矩阵就是上面给出的  $ A_j $ 的形式。