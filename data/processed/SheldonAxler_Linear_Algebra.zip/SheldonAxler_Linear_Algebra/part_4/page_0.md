8 证明或给出反例：V 上的幂零算子的集合是  $ \mathcal{L}(V) $ 子空间.

9 设  $ S, T \in \mathcal{L}(V) $ 且 ST 是幂零的．证明 TS 是幂零的．

10 设  $ T \in \mathcal{L}(V) $ 不是幂零的．令  $ n = \dim V $．证明  $ V = \text{null } T^{n-1} \oplus \text{range } T^{n-1} $．

11 证明或给出反例：若 V 是复向量空间， $ \dim V = n, T \in \mathcal{L}(V) $，则  $ T^n $ 是可对角化的.

12 设  $ N \in \mathcal{L}(V) $，V 有一个基使得 N 关于这个基有上三角矩阵，其对角线上元素均为 0。证明 N 是幂零的。

13 设 V 是内积空间， $ N \in \mathcal{L}(V) $ 是正规的并且是幂零的．证明 N = 0．

14 设  $ V $ 是内积空间， $ N \in \mathcal{L}(V) $ 是幂零的．证明： $ V $ 有一个规范正交基使得  $ N $ 关于这个基有上三角矩阵．

若  $ F = \mathbf{C} $，则无需假设  $ N $ 是幂零的，这个结果即可由舒尔定理 6.38 得出．于是本题只需对  $ \mathbf{F} = \mathbf{R} $ 的情况证明即可．

15 设  $ N \in \mathcal{L}(V) $ 使得  $ \text{null} N^{\dim V - 1} \neq \text{null} N^{\dim V} $。证明：N 是幂零的，并且对每个满足  $ 0 \leq j \leq \dim V $ 的整数 j 都有  $ \dim \text{null} N^j = j $。

16 设  $ T \in \mathcal{L}(V) $. 证明:

 $$ V=\mathrm{range}T^{0}\supset\mathrm{range}T^{1}\supset\cdots\supset\mathrm{range}T^{k}\supset\mathrm{range}T^{k+1}\supset\cdots. $$ 

17 设  $ T \in \mathcal{L}(V) $， $ m $ 是使得  $ \text{range} T^m = \text{range} T^{m+1} $ 的非负整数．证明：对每个  $ k > m $ 都有  $ \text{range} T^k = \text{range} T^m $．

18 设  $ T \in \mathcal{L}(V) $. 令  $ n = \dim V $. 证明:

 $$ \mathrm{range}T^{n}=\mathrm{range}T^{n+1}=\mathrm{range}T^{n+2}=\cdots. $$ 

19 设  $ T \in \mathcal{L}(V) $， $ m $ 是非负整数．证明：

 $$  nullT^{m}=nullT^{m+1}\quad 当且仅当 \quad range T^{m}=range T^{m+1}. $$ 

20 设  $ T \in \mathcal{L}(\mathbf{C}^5) $ 使得 range  $ T^4 \neq \text{range } T^5 $。证明 T 是幂零的。

21 找出一个向量空间  $ W $ 和  $ T \in \mathcal{L}(W) $，使得对每个正整数  $ k $ 都有  $ \text{null} T^k \subset \text{null} T^{k+1} $ 且  $ \text{range} T^k \supseteq \text{range} T^{k+1} $.

### 8. B 算子的分解

## 复向量空间上算子的刻画

前面我们看到，即使在有限维的复向量空间上，算子的定义域也未必能分解成本征空间的直和．本节我们将会看到，有限维的复向量空间上的每个算子都有足够多的广义本征向量来给出一个分解.