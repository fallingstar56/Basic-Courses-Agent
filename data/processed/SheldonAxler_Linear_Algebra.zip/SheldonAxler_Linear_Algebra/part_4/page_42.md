10 设 V 是内积空间， $ T \in \mathcal{L}(V) $。证明 trace  $ T^* = \overline{\text{trace } T} $。

11 设 V 是内积空间， $ T \in \mathcal{L}(V) $ 是正算子，trace  $ T = 0 $。证明 T = 0。

12 设 V 是内积空间， $ P, Q \in \mathcal{L}(V) $ 是正交投影．证明  $ \text{trace}(PQ) \geq 0 $

13 设算子  $ T \in \mathcal{L}(\mathbf{C}^3) $ 的矩阵是

 $$ \left(\begin{array}{ccc}{51}&{-12}&{-21}\\ {60}&{-40}&{-28}\\ {57}&{-68}&{1} \end{array}\right). $$ 

已知 -48 和 24 是 T 的本征值．不用计算机也不用纸和笔，求 T 第三个本征值.

14 设  $ T \in \mathcal{L}(V) $， $ c \in \mathbf{F} $。证明  $ \text{trace}(cT) = c\text{trace}T $。

15 设  $ S, T \in \mathcal{L}(V) $. 证明  $ \text{trace}(ST) = \text{trace}(TS) $.

16 证明或给出反例：若  $ S, T \in \mathcal{L}(V) $ 则  $ \text{trace}(ST) = (\text{trace} S)(\text{trace} T) $.

17 设  $ T \in \mathcal{L}(V) $ 使得对所有  $ S \in \mathcal{L}(V) $ 都有  $ \text{trace}(ST) = 0 $。证明 T = 0。

18 设 V 是内积空间， $ e_1, \ldots, e_n $ 是 V 的规范正交基， $ T \in \mathcal{L}(V) $。证明：

 $$ \mathrm{t r a c e}(T^{*}T)=\|T e_{1}\|^{2}+\cdots+\|T e_{n}\|^{2}. $$ 

试说明上式右端与 V 的规范正交基  $ e_{1}, \ldots, e_{n} $ 的选取无关.

19 设 V 是内积空间．证明： $ \langle S,T\rangle=\mathrm{trace}(ST^{*}) $ 定义了  $ \mathcal{L}(V) $ 上的一个内积.

20 设 V 是复内积空间， $ T \in \mathcal{L}(V) $， $ \lambda_1, \ldots, \lambda_n $ 是 T 的按重数重复的全体本征值。设

 $$ \left(\begin{array}{c c c}A_{1,1}&\cdots&A_{1,n}\\\vdots&&\vdots\\A_{n,1}&\cdots&A_{n,n}\\\end{array}\right) $$ 

是 T 关于 V 的某个规范正交基的矩阵．证明：

 $$ |\lambda_{1}|^{2}+\cdots+|\lambda_{n}|^{2}\leq\sum_{k=1}^{n}\sum_{j=1}^{n}|A_{j,k}|^{2}. $$ 

21 设 V 是内积空间， $ T \in \mathcal{L}(V) $，对每个  $ v \in V $ 都有  $ \|T^*v\| \leq \|Tv\| $。证明 T 是正规的。

本题对无限维内积空间不成立，从而引出所谓的亚正规算子，其理论已经比较成熟。

### 10. B 行列式

## 算子的行列式

现在可以定义算子的行列式了．注意下面的定义仿照定义迹的方法，用本征值之积代替了本征值之和．