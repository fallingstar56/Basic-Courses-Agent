1.19 定义 向量空间（vector space）
向量空间就是带有加法和标量乘法的集合 V，满足如下性质：
交换性（commutativity）
对所有  $ u, v \in V $ 都有  $ u + v = v + u $;
结合性（associativity）
对所有  $ u, v, w \in V $ 和  $ a, b \in F $ 都有  $ (u + v) + w = u + (v + w) $ 和  $ (ab)v = a(bv) $;
加法单位元（additive identity）
存在元素  $ 0 \in V $ 使得对所有  $ v \in V $ 都有  $ v + 0 = v $;
加法逆元（additive inverse）
对每个  $ v \in V $ 都存在  $ w \in V $ 使得  $ v + w = 0 $;
乘法单位元（multiplicative identity）
对所有  $ v \in V $ 都有  $ 1v = v $;
分配性质（distributive properties）
对所有  $ a, b \in F $ 和  $ u, v \in V $ 都有  $ a(u + v) = au + av $ 和  $ (a + b)v = av + bv $.

下面的几何语言有时更直观.

1.20 定义 向量（vector）、点（point）
向量空间中的元素称为向量或点.

向量空间的标量乘法依赖于 F．因此，在需要确切指明时，我们会说 V 是 F 上的向量空间，而不是简单地说 V 是向量空间．例如， $ R^{n} $ 是 R 上的向量空间， $ C^{n} $ 是 C 上的向量空间．

1.21 定义 实向量空间（real vector space）、复向量空间（complex vector space）
• R 上的向量空间称为实向量空间.
• C 上的向量空间称为复向量空间.

一般来说，F 的选取在上下文中是很明显的或者是无关紧要的，所以我们通常都假设 F 是自明的.

请自行验证在通常的加法和标量乘法下  $ F^{n} $ 是 F 上的向量空间．正是这个例子为我们定义向量空间提供了动因．

最简单的向量空间只含有一个点，

即  $ \{0\} $ 是向量空间.

