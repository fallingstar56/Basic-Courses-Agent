1.3 复数的算术性质

交换性（commutativity）

对所有  $ \alpha, \beta \in \mathbf{C} $ 都有  $ \alpha + \beta = \beta + \alpha, \alpha\beta = \beta\alpha $;

结合性（associativity）

对所有  $ \alpha, \beta, \lambda \in \mathbf{C} $ 都有  $ (\alpha + \beta) + \lambda = \alpha + (\beta + \lambda), (\alpha\beta)\lambda = \alpha(\beta\lambda) $;

单位元（identities）

对所有  $ \lambda \in \mathbf{C} $ 都有  $ \lambda + 0 = \lambda, \lambda1 = \lambda $;

加法逆元（additive inverse）

对每个  $ \alpha \in \mathbf{C} $ 都存在唯一的  $ \beta \in \mathbf{C} $ 使得  $ \alpha + \beta = 0 $;

乘法逆元（multiplicative inverse）

对每个  $ \alpha \in \mathbf{C}, \alpha \neq 0 $ 都存在唯一的  $ \beta \in \mathbf{C} $ 使得  $ \alpha\beta = 1 $;

分配性质（distributive property）

对所有  $ \lambda, \alpha, \beta \in \mathbf{C} $ 都有  $ \lambda(\alpha + \beta) = \lambda\alpha + \lambda\beta $.

上述性质可以利用我们所熟悉的实数性质以及复数的加法与乘法的定义来证明.下面的这个例子给出了复数乘法的交换性的证明.其他性质的证明留作习题.

1.4 例 证明  $ \alpha\beta = \beta\alpha $ 对所有  $ \alpha, \beta \in \mathbb{C} $ 成立.

证明 假设  $ \alpha = a + bi $， $ \beta = c + di $，其中  $ a, b, c, d \in \mathbb{R} $。那么，复数乘法的定义表明

 $$ \begin{aligned}\alpha\beta&=(a+bi)(c+di)\\&=(ac-bd)+(ad+bc)i\end{aligned} $$ 

并且

 $$ \begin{aligned}\beta\alpha&=(c+di)(a+bi)\\&=(ca-db)+(cb+da)i.\end{aligned} $$ 

上面这两组等式和实数的加法与乘法的交换性表明  $ \alpha\beta = \beta\alpha $.