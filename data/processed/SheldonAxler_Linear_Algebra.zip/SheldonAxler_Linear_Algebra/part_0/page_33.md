22 设  $  U = \{(x, y, x + y, x - y, 2x) \in \mathbf{F}^5 : x, y \in \mathbf{F} \}  $，找出  $  \mathbf{F}^5  $ 的三个非  $  \{0\}  $ 子空间  $  W_1, W_2, W_3  $ 使得  $  \mathbf{F}^5 = U \oplus W_1 \oplus W_2 \oplus W_3  $.

23 证明或给出反例：如果  $ U_{1}, U_{2}, W $ 是 V 的子空间，使得  $ V = U_{1} \oplus W $ 且  $ V = U_{2} \oplus W $，则  $ U_{1} = U_{2} $.

24 函数  $ f: \mathbf{R} \to \mathbf{R} $ 称为偶函数，如果对所有  $ x \in \mathbf{R} $ 均有  $ f(-x) = f(x) $。函数  $ f: \mathbf{R} \to \mathbf{R} $ 称为奇函数，如果对所有  $ x \in \mathbf{R} $ 均有  $ f(-x) = -f(x) $。用  $ U_e $ 表示  $ \mathbf{R} $ 上实值偶函数的集合，用  $ U_0 $ 表示  $ \mathbf{R} $ 上实值奇函数的集合。证明  $ \mathbf{R}^\mathbf{R} = U_e \oplus U_0 $。