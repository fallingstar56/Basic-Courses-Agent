1.17 定义  $ F^n $ 中的标量乘法（scalar multiplication in  $ F^n $）

一个数  $ \lambda $ 与  $ F^n $ 中的一个向量的乘积这样来计算：用  $ \lambda $ 乘以向量的每个坐标，即

 $ \lambda(x_1, \ldots, x_n) = (\lambda x_1, \ldots, \lambda x_n) $,

其中  $ \lambda \in \mathbf{F} $,  $ (x_1, \ldots, x_n) \in \mathbf{F}^n $.

 $ R^{2} $ 中的标量乘法有很好的几何解释．如果  $ \lambda $ 是正数， $ x $ 是  $ R^{2} $ 中的向量，则向量  $ \lambda x $ 的方向与  $ x $ 相同，而其长度为  $ x $ 长度的  $ \lambda $ 倍．也就是说，为了得到  $ \lambda x $，只需将  $ x $ 收缩或者伸长  $ \lambda $ 倍，这取决于  $ \lambda < 1 $ 或者  $ \lambda > 1 $．

如果  $ \lambda $ 是负数， $ x $ 是  $ R^2 $ 中的向量，则向量  $ \lambda x $ 的方向与  $ x $ 相反，而其长度为  $ x $ 长度的  $ |\lambda| $ 倍，如右图所示。

在标量乘法中，我们把一个标量和一个向量相乘，得到一个向量。你也许熟悉  $ R^2 $ 或者  $ R^3 $ 中的点积，它把两个向量相乘而得到一个标量。在第 6 章我们将研究内积，这时点积的推广便尤为重要。



<div style="text-align: center;"><img src="imgs/img_in_image_box_503_525_823_656.jpg" alt="Image" width="35%" /></div>


<div style="text-align: center;">标量乘法</div>


## 关于域的题外话

一个域是一个集合，至少包含有两个分别称为 0 和 1 的不同元素，并带有加法和乘法运算，而且这些运算满足 1.3 中列出的所有性质．因此，R 和 C 都是域，有理数集合连同通常的加法和乘法运算也是域．域的另一个例子是集合  $ \{0,1\} $，带有通常的加法和乘法运算，但规定  $ 1+1 $ 等于 0.

在本书中，我们无需处理 R 和 C 以外的域。然而，线性代数中许多对 R 和 C 有效的定义、定理、证明都可照搬到任意域上。如果想这么做，在第 1～3 章中，我们尽可以把 F 当作任意的域，而不仅仅是 R 或 C，只有个别例子和习题要求对于任意正整数 n 必有  $ 1 + 1 + \cdots + 1 \neq 0 $。

### 习题 1.A

1 设 a 和 b 是不全为 0 的实数. 求实数 c 和 d 使得  $ 1/(a+bi)=c+di $.

2 证明  $ \frac{-1+\sqrt{3}i}{2} $ 是 1 的立方根（即它的立方等于 1）.

3 求 i 的两个不同的平方根.

4 证明对所有  $ \alpha, \beta \in \mathbf{C} $ 有  $ \alpha + \beta = \beta + \alpha $.

5 证明对所有  $ \alpha, \beta, \lambda \in \mathbb{C} $ 有  $ (\alpha + \beta) + \lambda = \alpha + (\beta + \lambda) $.

6 证明对所有  $ \alpha, \beta, \lambda \in \mathbf{C} $ 有  $ (\alpha\beta)\lambda = \alpha(\beta\lambda) $.