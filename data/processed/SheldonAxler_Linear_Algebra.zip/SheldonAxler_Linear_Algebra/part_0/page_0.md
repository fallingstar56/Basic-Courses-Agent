完全抛开行列式来描述线性算子的基本理论

被斯坦福大学等全球40多个国家、300余所高校采纳为教材

Linear Algebra Done Right, 3E

## 线性代数 应该这样学

(第3版)new

[美] Sheldon Axler 著

杜现昆 刘大艳 马晶 译