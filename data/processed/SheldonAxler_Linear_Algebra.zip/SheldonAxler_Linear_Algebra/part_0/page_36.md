### 2.5 定义 张成空间（span）

V 中一组向量  $ v_{1}, \ldots, v_{m} $ 的所有线性组合所构成的集合称为  $ v_{1}, \ldots, v_{m} $ 的张成空间，记为  $ \operatorname{span}(v_{1}, \ldots, v_{m}) $ 。也就是说，

 $$ \operatorname{span}(\nu_{1},\cdots,\nu_{m})=\left\{a_{1}\nu_{1}+\cdots+a_{m}\nu_{m}:a_{1},\cdots,a_{m}\in\mathbf{F}\right\}. $$ 

空间量组（）的张成空间定义为  $ \{0\} $.

2.6 例 前面的例子表明在  $ F^{3} $ 中，

 $$ (17,-4,2)\in\operatorname{span}\left((2,1,-3),(1,-2,4)\right); $$ 

 $$ \bullet \quad (17,-4,5)\notin\operatorname{s p a n}\big((2,1,-3),(1,-2,4)\big). $$ 

有些数学家采用术语线性张成空间，意思与张成空间一样。

### 2.7 张成空间是包含这组向量的最小子空间

V 中一组向量的张成空间是包含这组向量的最小子空间.

证明 设  $ v_{1}, \ldots, v_{m} $ 是 V 中的一组向量.

先证明  $ \operatorname{span}(v_{1},\ldots,v_{m}) $ 是 V 的子空间. 加法单位元属于  $ \operatorname{span}(v_{1},\ldots,v_{m}) $, 因为

 $$ 0=0\nu_{1}+\cdots+0\nu_{m}. $$ 

其次， $ \operatorname{span}(v_{1},\ldots,v_{m}) $ 在加法下封闭，因为

 $$ (a_{1}\nu_{1}+\cdots+a_{m}\nu_{m})+(c_{1}\nu_{1}+\cdots+c_{m}\nu_{m})=(a_{1}+c_{1})\nu_{1}+\cdots+(a_{m}+c_{m})\nu_{m}. $$ 

再次， $ \operatorname{span}(v_{1},\ldots,v_{m}) $ 在标量乘法下封闭，因为

 $$ \lambda(a_{1}\nu_{1}+\cdots+a_{m}\nu_{m})=\lambda a_{1}\nu_{1}+\cdots+\lambda a_{m}\nu_{m}. $$ 

于是  $ \operatorname{span}(v_{1},\ldots,v_{m}) $ 是 V 的子空间（由于 1.34）.

每个  $ v_{j} $ 都是  $ v_{1},\ldots,v_{m} $ 的线性组合（为了证明这一点，在 2.3 中令  $ a_{j}=1 $ 并令其他 a 都等于 0）。于是  $ \operatorname{span}(v_{1},\ldots,v_{m}) $ 包含每一个  $ v_{j} $。反之，由于子空间对加法和标量乘法都封闭，从而 V 的包含所有  $ v_{j} $ 的子空间必定都包含  $ \operatorname{span}(v_{1},\ldots,v_{m}) $。因此  $ \operatorname{span}(v_{1},\ldots,v_{m}) $ 是 V 的包含所有向量  $ v_{1},\ldots,v_{m} $ 的最小子空间。

### 2.8 定义 张成（spans）

若  $ \operatorname{span}(v_{1},\ldots,v_{m}) $ 等于 V，则称  $ v_{1},\ldots,v_{m} $ 张成 V.

### 2.9 例设 n 是正整数．证明

 $$ (1,0,\cdots,0),(0,1,0,\cdots,0),\cdots,(0,\cdots,0,1) $$ 