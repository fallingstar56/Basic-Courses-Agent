在下面的定义中，我们约定  $ -\infty < m $，这意味着恒等于 0 的多项式属于  $ \mathcal{P}_m(\mathbf{F}) $。

### 2.13 定义  $ \mathcal{P}_{m}(\mathbf{F}) $

对于非负整数 m，用  $ \mathcal{P}_{m}(\mathbf{F}) $ 表示系数在 F 中且次数不超过 m 的所有多项式构成的集合.

要验证下面的例子，只需注意到  $ \mathcal{P}_{m}(\mathbf{F}) = \operatorname{span}(1, z, \ldots, z^{m}) $ 。此处我们用  $ z^{k} $ 表示函数，这有点滥用记号。

2.14 例 对每个非负整数 m， $ P_{m}(\mathbf{F}) $ 是有限维向量空间.

2.15 定义 无限维向量空间（infinite-dimensional vector space）

一个向量空间如果不是有限维的，则称为无限维的.

### 2.16 例 证明  $ \mathcal{P}(\mathbf{F}) $ 是无限维的

证明 考虑  $ \mathcal{P}(\mathbf{F}) $ 中任意一组元素．记 m 为这组多项式的最高次数．则这个组的张成空间中的每个多项式的次数最多为 m．因此  $ z^{m+1} $ 不属于这个组的张成空间．从而没有组能够张成  $ \mathcal{P}(\mathbf{F}) $．所以  $ \mathcal{P}(\mathbf{F}) $ 是无限维的．

## 线性无关

设  $ v_1, \ldots, v_m \in V $ 且  $ v \in \text{span}(v_1, \ldots, v_m) $。由张成空间的定义，有  $ a_1, \ldots, a_m \in \mathbf{F} $ 使得

 $$ \nu=a_{1}\nu_{1}+\cdots+a_{m}\nu_{m}. $$ 

考虑上式中标量选取的唯一性问题．假设  $ c_{1},\ldots,c_{m} $ 是另一组标量也使得

 $$ \nu=c_{1}\nu_{1}+\cdots+c_{m}\nu_{m}. $$ 

两式相减得

 $$ \begin{align*}0=(a_1-c_1)\nu_1+\cdots+(a_m-c_m)\nu_m.\end{align*} $$ 

于是我们把 0 写成了  $ v_{1}, \ldots, v_{m} $ 的线性组合．如果 0 只能用显然的方式（每个标量都取零）写成  $ v_{1}, \ldots, v_{m} $ 的线性组合，则每个  $ a_{j} - c_{j} $ 都等于 0，即每个  $ a_{j} $ 都等于  $ c_{j} $ （因此标量的取法确实是唯一的）．这种情况很重要，所以我们给它起一个特殊的名字——线性无关，这正是我们现在要定义的．