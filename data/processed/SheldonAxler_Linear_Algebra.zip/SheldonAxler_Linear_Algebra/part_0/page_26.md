5 证明在向量空间的定义 1.19 中，关于加法逆元的那个条件可替换为

 $$  对所有 \nu\in V 都有 0\nu=0. $$ 

这里，等式左端的 0 是数 0，右端的 0 是 V 的加法单位元。（在一个定义中，“某个条件可替换为另一个条件”是指把这个条件换成另一个条件后所定义的是同一类对象。）

6 设  $ \infty $ 和  $ -\infty $ 是两个不同的对象，它们都不属于  $ \mathbf{R} $。根据记号就能猜出如何在  $ \mathbf{R} \cup \{\infty\} \cup \left\{-\infty\right\} $ 上定义加法和标量乘法。具体来说，两个实数的加法和乘法按通常的实数运算法则定义，并且对  $ t \in \mathbf{R} $ 定义

 $$ t\infty=\begin{cases}-\infty,& 若 \;t<0,\\0,& 若 \;t=0,\\\infty,& 若 \;t>0,\end{cases}\quad t(-\infty)=\begin{cases}\infty,& 若 \;t<0,\\0,& 若 \;t=0,\\-\infty,& 若 \;t>0,\end{cases} $$ 

 $$ t+\infty=\infty+t=\infty,\qquad t+(-\infty)=(-\infty)+t=-\infty, $$ 

 $$ \infty+\infty=\infty,\qquad(-\infty)+(-\infty)=-\infty,\qquad\infty+(-\infty)=0. $$ 

试问  $  \mathbf{R} \cup \{\infty\} \cup \{- \infty\}  $ 是否为  $  \mathbf{R}  $ 上的向量空间？说明理由。

### 1. C 子空间

通过考虑子空间，我们可以大量地扩充向量空间的例子.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>1.32 定义 子空间（subspace）</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>如果  $ V $ 的子集  $ U $（采用与  $ V $ 相同的加法和标量乘法）也是向量空间，则称  $ U $ 是  $ V $ 的子空间.</td></tr></table>

1.33 例  $ \{(x_1, x_2, 0): x_1, x_2 \in \mathbf{F}\} $ 是  $ \mathbf{F}^3 $ 的子空间.

下面的结果给出了判断向量空间的一个子集是否为子空间的最简单的方法.

有些数学家采用线性子空间这个术语，意思与子空间一样。

