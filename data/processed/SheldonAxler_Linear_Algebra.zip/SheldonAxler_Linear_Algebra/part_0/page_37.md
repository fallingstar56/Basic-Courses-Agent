张成  $ F^n $。上面向量组中的第  $ j $ 个向量是第  $ j $ 个元素为 1 其余元素均为 0 的  $ n $ 元组。

证明 设  $ (x_1, \ldots, x_n) \in \mathbf{F}^n $。则

 $$ (x_{1},\cdots,x_{n})=x_{1}(1,0,\cdots,0)+x_{2}(0,1,0,\cdots,0)+\cdots+x_{n}(0,\cdots,0,1). $$ 

于是  $ (x_{1},\ldots,x_{n})\in\mathrm{span}\left((1,0,\ldots,0),(0,1,0,\ldots,0),\ldots,(0,\ldots,0,1)\right) $

现在我们给出线性代数中的一个关键定义：

### 2.10 定义 有限维向量空间（finite-dimensional vector space）

如果一个向量空间可以由该空间中的某个向量组张成，则称这个向量空间是有限维的.

回想一下，根据定义，每个组都具有有限长度。

上面的例 2.9 表明对任意正整数 n， $ F^{n} $ 是有限维向量空间.

多项式的定义对我们来说无疑是很熟悉的。

2.11 定义 多项式（polynomial）， $ \mathcal{P}(\mathbf{F}) $

- 对于函数  $ p: \mathbf{F} \to \mathbf{F} $，若存在  $ a_0, \ldots, a_m \in \mathbf{F} $ 使得对任意  $ z \in \mathbf{F} $ 均有

 $$ p(z)=a_{0}+a_{1}z+a_{2}z^{2}+\cdots+a_{m}z^{m}, $$ 

则称 p 为系数属于 F 的多项式.

•  $ \mathcal{P}(\mathbf{F}) $ 是系数属于 F 的全体多项式所组成的集合.

在通常的（多项式）加法和标量乘法下， $ \mathcal{P}(\mathbf{F}) $ 是 F 上的向量空间（请自行验证）。也就是说， $ \mathcal{P}(\mathbf{F}) $ 是  $ \mathbf{F}^{\mathbf{F}} $（F 到 F 的全体函数构成的向量空间）的子空间。

如果一个多项式（视为 F 到 F 的函数）可用两组系数来表示，将这两个表达式相减得到一个多项式，该多项式作为 F 上的函数是恒等于零的函数，因此该多项式的系数均为 0（如果你不熟悉这一事实，先承认它，我们后面会给出证明：见 4.7）。结论：一个多项式的系数由该多项式唯一确定。因此，下面定义的多项式的次数是唯一确定的。

2.12 定义 多项式的次数（degree of a polynomial），deg p

- 对于多项式  $  p \in \mathcal{P}(\mathbf{F})  $，若存在标量  $  a_0, a_1, \ldots, a_m \in \mathbf{F}  $，其中  $  a_m \neq 0  $，使得对任意  $  z \in \mathbf{F}  $ 有

 $$ p(z)=a_{0}+a_{1}z+\cdots+a_{m}z^{m}, $$ 

则说 p 的次数为 m. 若 p 的次数为 m, 则记  $ \deg p = m $.

·规定恒等于0的多项式的次数为 $ -\infty $.