1.5 定义  $ -\alpha $，减法（subtraction）、 $ 1/\alpha $，除法（division）

设  $ \alpha, \beta \in \mathbb{C} $.

· 令  $ -\alpha $ 表示  $ \alpha $ 的加法逆元．因此  $ -\alpha $ 是使得

 $$ \alpha+(-\alpha)=0 $$ 

的唯一复数.

· C 上的减法定义为

 $$ \beta-\alpha=\beta+(-\alpha). $$ 

• 对于  $ \alpha \neq 0 $，令  $ 1/\alpha $ 表示  $ \alpha $ 的乘法逆元。因此  $ 1/\alpha $ 是使得

 $$ \alpha(1/\alpha)=1 $$ 

的唯一复数.

· C 上的除法定义为

 $$ \beta/\alpha=\beta(1/\alpha). $$ 

为了使下文中给出的定义和证明的定理对于实数和复数都适用，我们将采用如下记号：

1.6 记号 F

在本书中 F 总是表示 R 或 C.

选用字母 F 是因为 R 和 C 都是所谓域（field）的例子.

于是，如果我们证明了一个涉及 F 的定理，那么将其中的 F 换成 R 或 C，定理仍然成立.



F 中的元素称为标量（scalar）．“标量”是用来代表“数”的一个很别致的词，通常用来强调一个对象是数，而不是向量（马上就会给出向量的定义）．

对  $ \alpha \in \mathbf{F} $ 及正整数  $ m $，我们把  $ \alpha^m $ 定义为  $ m $ 个  $ \alpha $ 的乘积：

 $$ \alpha^{m}=\underbrace{\alpha\cdots\cdots\alpha}_{m 个 }. $$ 

显然，对所有  $ \alpha, \beta \in \mathbf{F} $ 及正整数 m, n 都有  $ (\alpha^{m})^{n} = \alpha^{mn} $ 和  $ (\alpha\beta)^{m} = \alpha^{m}\beta^{m} $.

组

在给出  $ R^{n} $ 和  $ C^{n} $ 的定义之前先来看两个重要的例子.

1.7 例  $ R^{2} $ 和  $ R^{3} $

• 集合  $ R^{2} $ 由全体有序实数对构成：

 $$ \mathbf{R}^{2}=\{(x,y):x,y\in\mathbf{R}\}, $$ 