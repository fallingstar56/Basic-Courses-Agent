7 证明对每个  $ \alpha \in \mathbb{C} $ 都存在唯一的  $ \beta \in \mathbb{C} $ 使得  $ \alpha + \beta = 0 $.

8 证明对每个  $ \alpha \in \mathbf{C} (\alpha \neq 0) $ 都存在唯一的  $ \beta \in \mathbf{C} $ 使得  $ \alpha\beta = 1 $.

9 证明对所有  $ \lambda, \alpha, \beta \in \mathbb{C} $ 都有  $ \lambda(\alpha + \beta) = \lambda \alpha + \lambda \beta $.

10 求  $ x \in \mathbb{R}^4 $ 使得  $ (4,-3,1,7)+2x=(5,9,-6,8) $.

11 解释为什么不存在  $ \lambda \in \mathbb{C} $ 使得  $ \lambda(2-3\mathrm{i}, 5+4\mathrm{i}, -6+7\mathrm{i}) = (12-5\mathrm{i}, 7+22\mathrm{i}, -32-9\mathrm{i}) $.

12 证明对所有  $ x, y, z \in \mathbb{F}^n $ 都有  $ (x + y) + z = x + (y + z) $.

13 证明对所有  $ x \in \mathbf{F}^n $ 和  $ a, b \in \mathbf{F} $ 都有  $ (ab)x = a(bx) $.

14 证明对所有  $ x \in \mathbf{F}^n $ 都有  $ 1x = x $.

15 证明对所有  $ x, y \in \mathbf{F}^n $ 都有  $ \lambda(x + y) = \lambda x + \lambda y $.

16 证明对所有  $ a, b \in \mathbf{F} $ 和  $ x \in \mathbf{F}^n $ 都有  $ (a + b)x = ax + bx $.

### 1. B 向量空间的定义

促使我们定义向量空间的动因源自  $ F^{n} $ 上加法和标量乘法的性质：加法具有交换性和结合性，并且有单位元。每个元素都有加法逆元。标量乘法具有结合性，用数1与向量做标量乘法不改变该向量，与预期一样。加法和标量乘法通过分配性质联系在一起。

我们把向量空间定义为带有加法和标量乘法的集合 V，使得加法和标量乘法具有上一段所描述的性质.

1.18 定义 加法（addition）、标量乘法（scalar multiplication）

- 集合  $ V $ 上的加法是一个函数，它把每一对  $ u, v \in V $ 都对应到  $ V $ 的一个元素  $ u + v $.

- 集合  $ V $ 上的标量乘法是一个函数，它把任意  $ \lambda \in \mathbb{F} $ 和  $ v \in V $ 都对应到一个元素  $ \lambda v \in V $.

现在我们可以给出向量空间的正式定义.