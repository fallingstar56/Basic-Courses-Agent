1. A  $ R^{n} $ 与  $ C^{n} $

## 复数

我们已经熟悉实数集 R 的基本性质．复数的发明使得我们可以对负数取平方根．大致的想法是假定 -1 有平方根，记为 i，并且遵循通常的算术法则．下面是正式的定义：

1.1 定义 复数（complex number）

• 一个复数是一个有序对  $ (a, b) $，其中  $ a, b \in \mathbb{R} $，但我们把它写成  $ a + bi $.

• 所有复数构成的集合记为 C:

 $$ \mathbf{C}=\{a+b\mathbf{i}:a,b\in\mathbf{R}\}. $$ 

· C 上的加法和乘法定义为

 $$ (a+bi)+(c+di)=(a+c)+(b+d)i, $$ 

 $$ (a+bi)(c+di)=(ac-bd)+(ad+bc)i, $$ 

其中  $ a, b, c, d \in \mathbb{R} $.

如果  $ a \in \mathbb{R} $，我们就把  $ a + 0i $ 等同于实数  $ a $。于是可以把  $ \mathbb{R} $ 看作  $ \mathbb{C} $ 的一个子集。我们也常把  $ 0 + bi $ 写成  $ bi $，并且把  $ 0 + 1i $ 写成  $ i $。

1777 年瑞士数学家莱昂哈德·欧拉

最先使用符号 i 来表示  $ \sqrt{-1} $.

请自行验证在如上定义的乘法下  $ i^{2} = -1 $. 不要去背上面的复数乘法公式，只要记住  $ i^{2} = -1 $ 并利用通常的算术法则（见 1.3）就可以把它推导出来.



1.2 例 计算  $ (2+3\mathrm{i})(4+5\mathrm{i}) $.

解

 $$ \begin{aligned}(2+3\mathrm{i})(4+5\mathrm{i})&=2\cdot4+2\cdot(5\mathrm{i})+(3\mathrm{i})\cdot4+(3\mathrm{i})(5\mathrm{i})\\&=8+10\mathrm{i}+12\mathrm{i}-15\\&=-7+22\mathrm{i}.\end{aligned} $$ 