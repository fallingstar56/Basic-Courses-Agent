证明 设  $ u_{1},\ldots,u_{m} $ 是  $ U_{1}\cap U_{2} $ 的基，则  $ \dim(U_{1}\cap U_{2})=m $ 。因为  $ u_{1},\ldots,u_{m} $ 是  $ U_{1}\cap U_{2} $ 的基，所以它在  $ U_{1} $ 中线性无关，因此可以扩充成  $ U_{1} $ 的基  $ u_{1},\ldots,u_{m},v_{1},\ldots,v_{j} $ （由于 2.33）。于是  $ \dim U_{1}=m+j $ 。再将  $ u_{1},\ldots,u_{m} $ 扩充成  $ U_{2} $ 的基  $ u_{1},\ldots,u_{m},w_{1},\ldots,w_{k} $ ，于是  $ \dim U_{2}=m+k $ 。

为完成证明，我们只需证明  $ u_{1},\ldots,u_{m},v_{1},\ldots,v_{j},w_{1},\ldots,w_{k} $ 是  $ U_{1}+U_{2} $ 的基，因为由此可得

 $$ \begin{aligned}\dim(U_{1}+U_{2})&=m+j+k\\&=(m+j)+(m+k)-m\\&=\dim U_{1}+\dim U_{2}-\dim(U_{1}\cap U_{2}).\end{aligned} $$ 

显然  $ \operatorname{span}(u_{1},\ldots,u_{m},v_{1},\ldots,v_{j},w_{1},\ldots,w_{k}) $ 包含  $ U_{1} $ 和  $ U_{2} $，故等于  $ U_{1} + U_{2} $。因此为了证明这个组是  $ U_{1} + U_{2} $ 的基，只需证明它是线性无关的。为此，假设

 $$ a_{1}u_{1}+\cdots+a_{m}u_{m}+b_{1}\nu_{1}+\cdots+b_{j}\nu_{j}+c_{1}w_{1}+\cdots+c_{k}w_{k}=0, $$ 

其中所有的 a, b, c 都是标量．往证所有的标量 a, b, c 都等于 0．上式可以写成

 $$ c_{1}w_{1}+\cdots+c_{k}w_{k}=-a_{1}u_{1}-\cdots-a_{m}u_{m}-b_{1}v_{1}-\cdots-b_{j}v_{j}, $$ 

即  $ c_1w_1 + \cdots + c_kw_k \in U_1 $。因为所有的  $ w $ 都属于  $ U_2 $，所以  $ c_1w_1 + \cdots + c_kw_k \in U_1 \cap U_2 $。

又因为  $ u_1, \ldots, u_m $ 是  $ U_1 \cap U_2 $ 的基，所以有标量  $ d_1, \ldots, d_m $ 使得

 $$ c_{1}w_{1}+\cdots+c_{k}w_{k}=d_{1}u_{1}+\cdots+d_{m}u_{m}. $$ 

但是  $ u_{1},\ldots,u_{m},w_{1},\ldots,w_{k} $ 是线性无关的，故由上式可知所有的 c（和 d）都等于 0.

因此最初的那个包含这些 a, b, c 的等式变成

 $$ a_{1}u_{1}+\cdots+a_{m}u_{m}+b_{1}\nu_{1}+\cdots+b_{j}\nu_{j}=0. $$ 

因为组  $ u_{1},\ldots,u_{m},v_{1},\ldots,v_{j} $ 是线性无关的，所以由这个等式可知所有的 a,b 都是 0.这就证明了所有的 a,b,c 都等于 0.

### 习题 2.C

1 设 V 是有限维的，U 是 V 的子空间使得  $ \dim U = \dim V $。证明 U = V。

2 证明  $ R^{2} $ 的子空间恰为： $ \{0\} $、 $ R^{2} $、 $ R^{2} $ 中过原点的所有直线.

3 证明  $ R^{3} $ 的子空间恰为： $ \{0\} $、 $ R^{3} $、 $ R^{3} $ 中过原点的所有直线、 $ R^{3} $ 中过原点的所有平面.

4 (a) 设  $ U = \{p \in \mathcal{P}_4(\mathbf{F}) : p(6) = 0\} $，求  $ U $ 的一个基.

(b) 将 (a) 中求得的基扩充为  $ \mathcal{P}_{4}(\mathbf{F}) $ 的基.

(c) 求  $ \mathcal{P}_4(\mathbf{F}) $ 的一个子空间  $ W $ 使得  $ \mathcal{P}_4(\mathbf{F}) = U \oplus W $.

5 (a) 设  $ U = \{p \in \mathcal{P}_4(\mathbf{R}): p''(6) = 0\} $，求  $ U $ 的一个基.

(b) 将 (a) 中求得的基扩充为  $ \mathcal{P}_{4}(\mathbf{R}) $ 的基.

(c) 求  $ \mathcal{P}_4(\mathbf{R}) $ 的一个子空间  $ W $ 使得  $ \mathcal{P}_4(\mathbf{R}) = U \oplus W $.