则对每个  $ \nu \in V $ 均有

 $$ 0=\langle\nu,u_{1}\rangle-\langle\nu,u_{2}\rangle=\langle\nu,u_{1}-u_{2}\rangle. $$ 

取  $ v = u_{1} - u_{2} $ 可得  $ u_{1} - u_{2} = 0 $，即  $ u_{1} = u_{2} $，这就完成了唯一性的证明.

6.44 例 求  $ u \in \mathcal{P}_2(\mathbf{R}) $ 使得对每个  $ p \in \mathcal{P}_2(\mathbf{R}) $ 均有

 $$ \int_{-1}^{1}p(t)\big(\cos(\pi t)\big)\mathrm{d}t=\int_{-1}^{1}p(t)u(t)\mathrm{d}t. $$ 

解 设  $ \varphi(p)=\int_{-1}^{1}p(t)\left(\cos(\pi t)\right)dt $ 。应用上面证明中的公式 6.43，并使用例 6.33 中的规范正交基，可得

 $$ \begin{align*}u(x)&=\Big(\int_{-1}^{1}\sqrt{\frac{1}{2}}\big(\cos(\pi t)\big)\mathrm{d}t\Big)\sqrt{\frac{1}{2}}+\Big(\int_{-1}^{1}\sqrt{\frac{3}{2}}t\big(\cos(\pi t)\big)\mathrm{d}t\Big)\sqrt{\frac{3}{2}}x\\&\quad+\Big(\int_{-1}^{1}\sqrt{\frac{45}{8}}\big(t^{2}-\frac{1}{3}\big)\big(\cos(\pi t)\big)\mathrm{d}t\Big)\sqrt{\frac{45}{8}}\big(x^{2}-\frac{1}{3}\big).\end{align*} $$ 

计算可得

 $$ \begin{align*}u(x)=-{45\over2\pi^2}\left(x^2-{1\over3}\right).\end{align*} $$ 

设 $V$ 是有限维的且 $\varphi$ 是 $V$ 上的线性泛函．则 6.43 给出了求向量 $u$ 的公式使其满足对所有 $v \in V$ 均有 $\varphi(v) = \langle v, u \rangle$．具体来说，就是

 $$ u=\overline{\varphi(e_{1})}e_{1}+\cdots+\overline{\varphi(e_{n})}e_{n}. $$ 

看起来等式右端依赖于规范正交基  $ e_1, \ldots, e_n $ 和  $ \varphi $。然而，定理 6.42 告诉我们  $ u $ 是由  $ \varphi $ 唯一确定的。所以等式右端与  $ V $ 的规范正交基  $ e_1, \ldots, e_n $ 的选取无关。

### 习题 6.B

1 (a) 设  $ \theta \in \mathbb{R} $. 证明

 $$ \left(\cos\theta,\sin\theta\right),\left(-\sin\theta,\cos\theta\right)\quad 和 \quad\left(\cos\theta,\sin\theta\right),\left(\sin\theta,-\cos\theta\right) $$ 

都是  $ R^{2} $ 的规范正交基.

(b) 证明  $ R^{2} $ 的规范正交基必形如 (a) 中的二者之一.

2 设  $ e_{1}, \ldots, e_{m} $ 是 V 的规范正交组. 设  $ v \in V $. 证明

 $$ \|\nu\|^{2}=|\langle\nu,e_{1}\rangle|^{2}+\cdots+|\langle\nu,e_{m}\rangle|^{2} $$ 

当且仅当  $ v \in \text{span}(e_1, \ldots, e_m) $.

3 设  $ T \in \mathcal{L}(\mathbb{R}^3) $ 关于基  $ (1,0,0) $， $ (1,1,1) $， $ (1,1,2) $ 具有上三角矩阵．求  $ \mathbb{R}^3 $ 的一个规范正交基（采用  $ \mathbb{R}^3 $ 上通常的内积）使得 T 关于这个基具有上三角矩阵．