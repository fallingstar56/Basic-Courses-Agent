### 7. A 自伴算子与正规算子

## 伴随

### 7.2 定义 伴随（adjoint）， $ T^{*} $

设  $ T \in \mathcal{L}(V, W) $。 $ T $ 的伴随是满足如下条件的函数  $ T^*: W \to V $：对所有  $ v \in V $ 和所有  $ w \in W $ 均有  $ \langle T v, w \rangle = \langle v, T^* w \rangle $。

伴随这个词在线性代数中还有另一个意思。在本书中我们不需要第二种意思，要是你在别处遇到伴随的第二种含义的话，要注意，伴随的这两种意思之间没有任何联系。

想要看出上面的定义有意义，我们设  $ T \in \mathcal{L}(V, W) $，并取定  $ w \in W $。考虑 V 上将  $ v \in V $ 映成  $ \langle Tv, w \rangle $ 的线性泛函，这个线性泛函依赖于 T 和 w。由里斯表示定理 6.42，存在 V 中唯一一个向量使得该线性泛函是通过与该向量做内积给出的，我们将这个唯一的向量记为



 $ T^*w $. 也就是说， $ T^*w $ 是  $ V $ 中唯一一个满足下面条件的向量：对每个  $ v \in V $ 均有  $ \langle T v, w \rangle = \langle v, T^*w \rangle $.

7.3 例 定义  $ T: \mathbb{R}^3 \to \mathbb{R}^2 $ 为  $ T(x_1, x_2, x_3) = (x_2 + 3x_3, 2x_1) $. 求  $ T^* $.

解  $ T^* $ 是  $ \mathbb{R}^2 $ 到  $ \mathbb{R}^3 $ 的函数. 要计算  $ T^* $, 取定一个点  $ (y_1, y_2) \in \mathbb{R}^2 $, 那么对于每个  $ (x_1, x_2, x_3) \in \mathbb{R}^3 $ 有

 $$ \begin{aligned}\langle(x_{1},x_{2},x_{3}),T^{*}(y_{1},y_{2})\rangle&=\langle T(x_{1},x_{2},x_{3}),(y_{1},y_{2})\rangle\\&=\langle(x_{2}+3x_{3},2x_{1}),(y_{1},y_{2})\rangle\\&=x_{2}y_{1}+3x_{3}y_{1}+2x_{1}y_{2}\\&=\langle(x_{1},x_{2},x_{3}),(2y_{2},y_{1},3y_{1})\rangle.\end{aligned} $$ 

于是  $ T^{*}(y_{1},y_{2})=(2y_{2},y_{1},3y_{1}). $

7.4 例 取定  $ u \in V $ 和  $ x \in W $。定义  $ T \in \mathcal{L}(V, W) $ 如下：对每个  $ v \in V $ 有  $ Tv = \langle v, u \rangle x $。求  $ T^* $。

解 取定  $ w \in W $。则对每个  $ \nu \in V $ 有

 $$ \begin{align*}\langle\nu,T^*w\rangle&=\langle T\nu,w\rangle\\&=\big\langle\langle\nu,u\rangle x,w\rangle\\&=\big\langle\nu,u\big\rangle\langle x,w\rangle\\&=\big\langle\nu,\langle w,x\rangle u\big\rangle.\end{align*} $$ 

于是  $ T^{*}w = \langle w, x \rangle u. $