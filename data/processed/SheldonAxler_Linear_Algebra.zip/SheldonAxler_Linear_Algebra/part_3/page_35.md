现在假设(f)成立，即  $ SS^{*}=I $ 。若  $ v\in V $ ，则

 $$ \|S^{*}\nu\|^{2}=\langle S^{*}\nu,S^{*}\nu\rangle=\langle S S^{*}\nu,\nu\rangle=\langle\nu,\nu\rangle=\|\nu\|^{2}. $$ 

因此  $ S^{*} $ 是等距同构，这证明了 (g) 成立.

现在假设(g)成立，即  $ S^{*} $ 是等距同构．已知  $ (a) \Rightarrow (e) $ 且  $ (a) \Rightarrow (f) $，这是因为我们已证明了  $ (a) \Rightarrow (b) \Rightarrow (c) \Rightarrow (d) \Rightarrow (e) \Rightarrow (f) $．利用  $ (a) \Rightarrow (e) $ 及  $ (a) \Rightarrow (f) $，并将其中的 S 换成  $ S^{*} $ 可得  $ SS^{*} = I $ 且  $ S^{*}S = I $．因此 S 可逆且  $ S^{-1} = S^{*} $，也就是说  $ (h) $ 成立．

现在假设 (h) 成立，即 S 可逆且  $ S^{-1} = S^{*} $。于是  $ S^{*}S = I $。若  $ v \in V $，则

 $$ \|S\nu\|^{2}=\langle S\nu,S\nu\rangle=\langle S^{*}S\nu,\nu\rangle=\langle\nu,\nu\rangle=\|\nu\|^{2}. $$ 

因此 S 是等距同构，这证明了 (a) 成立.

我们已经证明 (a)  $ \Rightarrow $ (b)  $ \Rightarrow $ (c)  $ \Rightarrow $ (d)  $ \Rightarrow $ (e)  $ \Rightarrow $ (f)  $ \Rightarrow $ (g)  $ \Rightarrow $ (h)  $ \Rightarrow $ (a).

上述定理证明了每个等距同构都是正规的（见 7.42 的 (a), (e), (f)）。于是，正规算子的刻画可以用来给出等距同构的描述。复的情形见以下定理，实的情形在第 9 章（见 9.36）。

### 7.43 F = C 时等距同构的描述

设 V 是复内积空间， $ S \in \mathcal{L}(V) $。则以下条件等价：

(a) S 是等距同构.

(b) V 有一个由 S 的本征向量组成的规范正交基，相应的本征值的绝对值均为 1.

证明 我们已经证明了(b)蕴涵(a)（见例7.38）.

为了证明另一个方面，假设 (a) 成立，即 S 是等距同构。由复谱定理 7.24，V 有一个由 S 的本征向量组成的规范正交基  $ e_{1}, \ldots, e_{n} $。对于  $ j \in \{1, \ldots, n\} $，设  $ \lambda_{j} $ 是相应于  $ e_{j} $ 的本征值，则

 $$ |\lambda_{j}|=\|\lambda_{j}e_{j}\|=\|S e_{j}\|=\|e_{j}\|=1. $$ 

因此 S 的每个本征值的绝对值都是 1，这就完成了证明.

### 习题 7.C

1 证明或给出反例：若  $ T \in \mathcal{L}(V) $ 是自伴的，且  $ V $ 有一个规范正交基  $ e_1, \ldots, e_n $ 使得对每个  $ j $ 有  $ \langle Te_j, e_j \rangle \geq 0 $，则  $ T $ 是正算子。

2 设 T 是 V 上的正算子．设  $ v, w \in V $ 使得

 $$ T\nu=w\quad 且 \quad T w=\nu. $$ 

证明  $ v = w. $

3 设 T 是 V 上的正算子，且 U 是 V 的在 T 下不变的子空间．证明  $ T|_{U} \in \mathcal{L}(U) $ 是 U 上的正算子．