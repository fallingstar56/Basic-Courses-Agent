19 设  $ T \in \mathcal{L}(V) $. 证明 T 关于 V 上由  $ d(u, v) = \|u - v\| $ 定义的度量 d 是一致连续的.

20 设  $ S, T \in \mathcal{L}(V) $. 设 s 表示 S 的最大奇异值，t 表示 T 的最大奇异值，r 表示  $ S + T $ 的最大奇异值. 证明  $ r \leq s + t $.