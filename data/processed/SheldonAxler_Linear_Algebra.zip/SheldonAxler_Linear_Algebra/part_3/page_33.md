## 等距同构

保持范数的算子十分重要，它们应该有一个名字.

7.37 定义 等距同构（isometry）

- 算子  $  S \in \mathcal{L}(V)  $ 称为等距同构，如果对所有  $  v \in V  $ 均有  $  \|Sv\| = \|v\|  $.

· 也就是说，算子是等距同构当且仅当它保持范数.

在希腊语中，单词 isos 的意思是相等；单词 metron 的意思是度量。因此 isometry 的字面意思是度量相等。

例如，当  $ \lambda \in \mathbf{F} $ 满足  $ |\lambda| = 1 $ 时， $ \lambda I $ 是等距同构。我们马上就会看到如果  $ \mathbf{F} = \mathbf{C} $，则下面的例子包括了所有的等距同构。

7.38 例 设  $ \lambda_{1},\ldots,\lambda_{n} $ 都是绝对值为 1 的标量， $ e_{1},\ldots,e_{n} $ 是 V 的规范正交基， $ S\in\mathcal{L}(V) $ 满足  $ Se_{j}=\lambda_{j}e_{j} $ 。证明 S 是等距同构。

证明 设  $ v \in V $. 则

7.39

 $$ \nu=\langle\nu,e_{1}\rangle e_{1}+\cdots+\langle\nu,e_{n}\rangle e_{n} $$ 

且

7.40

 $$ \left\|\nu\right\|^{2}=\left|\left\langle\nu,e_{1}\right\rangle\right|^{2}+\cdots+\left|\left\langle\nu,e_{n}\right\rangle\right|^{2}, $$ 

这里我们利用了 6.30. 把 S 作用到 7.39 的两端可得

 $$ \begin{align*}S\nu&=\langle\nu,e_1\rangle S e_1+\cdots+\langle\nu,e_n\rangle S e_n\\&=\lambda_1\langle\nu,e_1\rangle e_1+\cdots+\lambda_n\langle\nu,e_n\rangle e_n.\end{align*} $$ 

由于  $ \left|\lambda_{j}\right|=1 $，上面最后的等式表明

 $$ \|S\nu\|^{2}=|\langle\nu,e_{1}\rangle|^{2}+\cdots+|\langle\nu,e_{n}\rangle|^{2}. $$ 

7.41

比较 7.40 和 7.41 可得  $ \|v\| = \|Sv\| $. 也就是说 S 是等距同构.

实内积空间上的等距同构通常称为正交算子．复内积空间上的等距同构通常称为酉算子．我们将采用等距同构这个术语，以使我们的结果对于实内积空间和复内积空间都适用．

以下定理给出了等距同构的若干等价条件.

(a) 和 (b) 的等价性表明一个算子是等距同构当且仅当它保内积. (a) 和 (c) 的等价性（或者 (a) 和 (d) 的等价性）表明，一个算子是等距同构当且仅当关于每一个（或某一个）规范正交基，其矩阵的列是规范正交的．习题 10 表明在前一句话中也可用 “行” 代替 “列”.

