3 设  $ T \in \mathcal{L}(V) $. 证明：存在等距同构  $ S \in \mathcal{L}(V) $ 使得  $ T = \sqrt{TT^*} S $.

4 设  $ T \in \mathcal{L}(V) $ 且 s 是 T 的一个奇异值．证明：存在向量  $ v \in V $ 使得  $ \|v\| = 1 $ 且  $ \|Tv\| = s $．

5 设  $ T \in \mathcal{L}(\mathbf{C}^2) $ 由  $ T(x, y) = (-4y, x) $ 定义．求 T 的奇异值．

6 求由  $ Dp = p' $ 定义的微分算子  $ D \in \mathcal{P}_2(\mathbf{R}) $ 的奇异值，这里  $ \mathcal{P}_2(\mathbf{R}) $ 上的内积由例 6.33 给出.

7 定义  $ T \in \mathcal{L}(\mathbf{F}^{3}) $ 为  $ T(z_{1}, z_{2}, z_{3}) = (z_{3}, 2z_{1}, 3z_{2}) $ 。求一个等距同构  $ S \in \mathcal{L}(\mathbf{F}^{3}) $ 使得  $ T = S\sqrt{T^{*}T} $

8 设  $ T \in \mathcal{L}(V) $,  $ S \in \mathcal{L}(V) $ 是一个等距同构， $ R \in \mathcal{L}(V) $ 是一个正算子使得 T = SR.

证明  $ R = \sqrt{T^{*}T} $.

本题表明，如果把 T 写成等距同构与一个正算子的乘积（如同在极分解 7.45 中），则此正算子必为  $ \sqrt{T^{*}T} $.

9 设  $ T \in \mathcal{L}(V) $. 证明：T 是可逆的当且仅当存在唯一的等距同构  $ S \in \mathcal{L}(V) $ 使得  $ T = S\sqrt{T^*T} $.

10 设  $ T \in \mathcal{L}(V) $ 是自伴的．证明 T 的奇异值等于 T 的本征值的绝对值（适当重复）.

11 设  $ T \in \mathcal{L}(V) $. 证明 T 和  $ T^* $ 有相同的奇异值.

12 证明或给出反例：若  $ T \in \mathcal{L}(V) $，则  $ T^2 $ 的奇异值等于  $ T $ 的奇异值的平方。

13 设  $ T \in \mathcal{L}(V) $. 证明：T 是可逆的当且仅当 0 不是 T 的奇异值.

14 设  $ T \in \mathcal{L}(V) $. 证明：dim range T 等于 T 的非零奇异值的个数.

15 设  $ S \in \mathcal{L}(V) $. 证明：S 是等距同构当且仅当 S 的所有奇异值都等于 1.

16 设  $ T_{1}, T_{2} \in \mathcal{L}(V) $. 证明： $ T_{1} $ 和  $ T_{2} $ 有相同的奇异值当且仅当存在等距同构  $ S_{1}, S_{2} \in \mathcal{L}(V) $ 使得  $ T_{1} = S_{1}T_{2}S_{2} $.

17 设  $ T \in \mathcal{L}(V) $ 有如下奇异值分解：对每个  $ \nu \in V $ 有

 $$ T\nu=s_{1}\langle\nu,e_{1}\rangle f_{1}+\cdots+s_{n}\langle\nu,e_{n}\rangle f_{n}, $$ 

其中  $ s_{1},\ldots,s_{n} $ 是 T 的奇异值， $ e_{1},\ldots,e_{n} $ 和  $ f_{1},\ldots,f_{n} $ 都是 V 的规范正交基.

(a) 证明：若  $ v \in V $，则  $ T^*v = s_1 \langle v, f_1 \rangle e_1 + \cdots + s_n \langle v, f_n \rangle e_n $.

(b) 证明：若  $ v \in V $，则  $ T^*Tv = s_1^2 \langle v, e_1 \rangle e_1 + \cdots + s_n^2 \langle v, e_n \rangle e_n $.

(c) 证明：若  $ \nu \in V $，则  $ \sqrt{T^*T}\nu = s_1\langle\nu, e_1\rangle e_1 + \cdots + s_n\langle\nu, e_n\rangle e_n $。

(d) 设 T 是可逆的．证明：若  $ \nu \in V $，则

 $$ T^{-1}\nu=\frac{\langle\nu,f_{1}\rangle e_{1}}{s_{1}}+\cdots+\frac{\langle\nu,f_{n}\rangle e_{n}}{s_{n}}. $$ 

18 设  $ T \in \mathcal{L}(V) $. 设  $ \hat{s} $ 表示 T 的最小奇异值，s 表示 T 的最大奇异值.

(a) 证明对每个  $ v \in V $ 均有  $ \hat{s} \| v \leq \| T v \| \leq s \| v \| $.

(b) 设  $ \lambda $ 是 T 的一个本征值. 证明  $ \hat{s} \leq |\lambda| \leq s $.