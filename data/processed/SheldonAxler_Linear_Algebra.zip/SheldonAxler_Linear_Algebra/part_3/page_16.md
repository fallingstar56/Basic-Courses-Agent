上两例中的  $ T^{*} $ 不只是函数而且还是线性映射．以下命题表明这是普遍成立的.

卜面两个命题的证明用到了一个共同的技巧：将  $ T^{*} $ 从内积的一个向量上移到另一个向量上就变为 T.

### 7.5 伴随是线性映射

若  $ T \in \mathcal{L}(V, W) $，则  $ T^* \in \mathcal{L}(W, V) $.

证明 设  $ T \in \mathcal{L}(V, W) $. 取定  $ w_1, w_2 \in W $. 若  $ v \in V $, 则

 $$ \begin{aligned}\langle\nu,T^{*}(w_{1}+w_{2})\rangle&=\langle T\nu,w_{1}+w_{2}\rangle\\&=\langle T\nu,w_{1}\rangle+\langle T\nu,w_{2}\rangle\\&=\langle\nu,T^{*}w_{1}\rangle+\langle\nu,T^{*}w_{2}\rangle\\&=\langle\nu,T^{*}w_{1}+T^{*}w_{2}\rangle,\end{aligned} $$ 

这表明  $ T^{*}(w_{1} + w_{2}) = T^{*}w_{1} + T^{*}w_{2} $.

取定  $ w \in W $ 和  $ \lambda \in \mathbf{F} $。若  $ \nu \in V $，则

 $$ \begin{aligned}\langle\nu,T^{*}(\lambda w)\rangle&=\langle T\nu,\lambda w\rangle\\&=\bar{\lambda}\langle T\nu,w\rangle\\&=\bar{\lambda}\langle\nu,T^{*}w\rangle\\&=\langle\nu,\lambda T^{*}w\rangle,\end{aligned} $$ 

这表明  $ T^{*}(\lambda w) = \lambda T^{*} w $ 。因此  $ T^{*} $ 是线性映射。

### 7.6 伴随的性质

(a) 对所有  $ S, T \in \mathcal{L}(V, W) $ 均有  $ (S + T)^{*} = S^{*} + T^{*} $;

(b) 对所有  $ \lambda \in \mathbf{F} $ 和  $ T \in \mathcal{L}(V, W) $ 均有  $ (\lambda T)^{*} = \bar{\lambda} T^{*} $;

(c) 对所有  $ T \in \mathcal{L}(V, W) $ 均有  $ (T^{*})^{*}=T; $

(d) $ I^{*}=I $，这里I是V上的恒等算子；

(e) 对所有  $ T \in \mathcal{L}(V, W) $ 和  $ S \in \mathcal{L}(W, U) $ 均有  $ (ST)^{*} = T^{*} S^{*} $ （这里 U 是 F 上的内积空间）.

证明

(a) 设  $ S, T \in \mathcal{L}(V, W) $. 若  $ v \in V $ 且  $ w \in W $，则

 $$ \begin{aligned}\langle\nu,(S+T)^{*}w\rangle&=\langle(S+T)\nu,w\rangle\\&=\langle S\nu,w\rangle+\langle T\nu,w\rangle\\&=\langle\nu,S^{*}w\rangle+\langle\nu,T^{*}w\rangle\\&=\langle\nu,S^{*}w+T^{*}w\rangle.\end{aligned} $$ 