其中第二个等价性由 7.16 得到（注意到算子  $ T^{*}T - TT^{*} $ 是自伴的）。第一个条件和最后一个条件的等价性给出了要证明的结果。

把下面的命题与习题 2 比较一下．那个习题是说，算子的伴随的所有本征值（作为集合）等于该算子所有本征值的复共轭．但是该习题没说本征向量的事，这是因为算子与其伴随可以有不同的本征向量．然而，由下面的命题可知，正规算子与其伴随有相同的本征向量．

### 7.21 若 T 正规，则 T 与  $ T^{*} $ 有相同的本征向量

设  $ T \in \mathcal{L}(V) $ 是正规的，且  $ v \in V $ 是  $ T $ 的相应于本征值  $ \lambda $ 的本征向量。则  $ v $ 也是  $ T^* $ 的相应于本征值  $ \bar{\lambda} $ 的本征向量。

证明 因为 T 是正规的，所以  $ T - \lambda I $ 也是正规的（请自行验证）。利用 7.20 可得

 $$ 0=\|(T-\lambda I)\nu\|=\|(T-\lambda I)^{*}\nu\|=\|(T^{*}-\bar{\lambda}I)\nu\|. $$ 

因此 v 是  $ T^{*} $ 的相应于本征值  $ \bar{\lambda} $ 的本征向量.

因为自伴算子是正规的，所以下面的命题也适用于自伴算子.

### 7.22 正规算子的正交本征向量

设  $ T \in \mathcal{L}(V) $ 是正规的．则  $ T $ 的相应于不同本征值的本征向量是正交的．

证明 设  $ \alpha, \beta $ 是 T 的不同本征值，u, v 分别是相应的本征向量，于是 Tu =  $ \alpha u $ 且 Tv =  $ \beta v $。由 7.21 有  $ T^{*}v = \bar{\beta}v $。因此

 $$ \begin{align*}(\alpha-\beta)\langle u,\nu\rangle&=\langle\alpha u,\nu\rangle-\langle u,\beta\nu\rangle\\&=\langle Tu,\nu\rangle-\langle u,T^{*}\nu\rangle\\&=0.\end{align*} $$ 

因为  $ \alpha \neq \beta $，上面的等式表明  $ \langle u, v \rangle = 0 $。因此 u 和 v 是正交的。

### 习题 7.A

1 设 n 是正整数. 定义  $ T \in \mathcal{L}(\mathbf{F}^n) $ 为

 $$ T(z_{1},\cdots,z_{n})=(0,z_{1},\cdots,z_{n-1}). $$ 

求  $ T^{*}(z_{1},\ldots,z_{n}) $.

2 设  $ T \in \mathcal{L}(V) $， $ \lambda \in \mathbf{F} $。证明： $ \lambda $ 是  $ T $ 的本征值当且仅当  $ \bar{\lambda} $ 是  $ T^* $ 的本征值。

3 设  $ T \in \mathcal{L}(V) $ 且 U 是 V 的子空间．证明：U 在 T 下不变当且仅当  $ U^\perp $ 在  $ T^* $ 下不变．