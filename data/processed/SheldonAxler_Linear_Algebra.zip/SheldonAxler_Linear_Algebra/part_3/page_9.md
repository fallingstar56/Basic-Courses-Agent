证明 设  $ v \in V $. 则

 $$ \nu=\frac{\left\langle\nu,x\right\rangle}{\left\|x\right\|^{2}}x+\Big(\nu-\frac{\left\langle\nu,x\right\rangle}{\left\|x\right\|^{2}}x\Big), $$ 

其中右端的第一项属于  $ \operatorname{span}(x) $ （从而属于 U），第二项正交于  $ x $（从而属于  $ U^{\perp} $）。因此  $ P_{UV} $ 等于右端的第一项。

### 6.55 正交投影  $ P_{U} $ 的性质

6.55 正交投影  $ P_U $ 的位置。

设  $ U $ 是  $ V $ 的有限维子空间且  $ v \in V $。则

(a)  $ P_U \in \mathcal{L}(V) $；

(b) 对每个  $ u \in U $ 均有  $ P_U u = u $；

(c) 对每个  $ w \in U^\perp $ 均有  $ P_U w = 0 $；

(d) range  $ P_U = U $；

(e) null  $ P_U = U^\perp $；

(f)  $ v - P_U v \in U^\perp $；

(g)  $ P_U^2 = P_U $；

(h)  $ \|P_U v\| \leq \|v\| $；

(i) 对  $ U $ 的每个规范正交基  $ e_1, \ldots, e_m $ 均有  $ P_U v = \langle v, e_1 \rangle e_1 + \cdots + \langle v, e_m \rangle e_m $。

## 证明

(a) 为了证明  $ P_{U} $ 是 V 上的线性映射，设  $ v_{1}, v_{2} \in V $。设

 $$ \nu_{1}=u_{1}+w_{1},\quad\nu_{2}=u_{2}+w_{2}, $$ 

其中  $ u_1, u_2 \in U $， $ w_1, w_2 \in U^\perp $。则  $ P_{U}v_1 = u_1 $ 且  $ P_{U}v_2 = u_2 $。从而

 $$ v_{1}+v_{2}=(u_{1}+u_{2})+(w_{1}+w_{2}), $$ 

其中  $ u_{1} + u_{2} \in U $ 且  $ w_{1} + w_{2} \in U^{\perp} $. 因此

 $$ P_{U}(\nu_{1}+\nu_{2})=u_{1}+u_{2}=P_{U}\nu_{1}+P_{U}\nu_{2}. $$ 

类似地，设  $ \lambda \in \mathbf{F} $。若  $ v = u + w $，其中  $ u \in U $ 且  $ w \in U^\perp $，则  $ \lambda v = \lambda u + \lambda w $，其中  $ \lambda u \in U $ 且  $ \lambda w \in U^\perp $。于是  $ P_U(\lambda v) = \lambda u = \lambda P_U v $。

因此  $ P_{U} $ 是 V 到 V 的线性映射.

(b) 设  $ u \in U $. 则  $ u = u + 0 $, 其中  $ u \in U $ 且  $ 0 \in U^{\perp} $. 于是  $ P_{U}u = u $.

(c) 设  $ w \in U^{\perp} $. 则  $ w = 0 + w $, 其中  $ 0 \in U $ 且  $ w \in U^{\perp} $. 于是  $ P_{U}w = 0 $.

(d) 由  $ P_{U} $ 的定义可知 range  $ P_{U} \subset U $. 由 (b) 可知  $ U \subset \text{range } P_{U} $. 于是 range  $ P_{U} = U $.