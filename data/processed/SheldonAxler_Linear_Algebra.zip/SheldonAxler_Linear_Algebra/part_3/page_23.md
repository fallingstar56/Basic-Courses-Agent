4 设  $ T \in \mathcal{L}(V, W) $. 证明：

(a) T 是单的当且仅当  $ T^{*} $ 是满的；

(b) T 是满的当且仅当  $ T^{*} $ 是单的.

5 证明：对每个  $ T \in \mathcal{L}(V, W) $ 均有

 $$ \dim null T^{*}=\dim null T+\dim W-\dim V $$ 

以及

 $$ \dim range T^{*}=\dim range T. $$ 

6  $ \mathcal{P}_{2}(\mathbf{R}) $ 按照内积

 $$ \left\langle p,q\right\rangle=\int_{0}^{1}p(x)q(x)\mathrm{d}x $$ 

是内积空间．定义  $ T \in \mathcal{L}(\mathcal{P}_2(\mathbf{R})) $ 使得  $ T(a_0 + a_1 x + a_2 x^2) = a_1 x $

(a) 证明 T 不是自伴的.

(b) T 关于基  $ (1, x, x^{2}) $ 的矩阵为

 $$ \left(\begin{array}{l l l}{{{0}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}\end{array}\right). $$ 

虽然 T 不是自伴的，但是上面的矩阵等于其共轭转置．解释为什么这并不矛盾．

7 设  $ S, T \in \mathcal{L}(V) $ 都是自伴的．证明 ST 是自伴的当且仅当  $ ST = TS $．

8 设 V 是实内积空间. 证明 V 上自伴算子的集合是  $ \mathcal{L}(V) $ 的子空间.

9 设 V 是复内积空间且  $ V \neq \{0\} $. 证明 V 上自伴算子的集合不是  $ \mathcal{L}(V) $ 的子空间.

10 设  $ \dim V \geq 2 $. 证明 V 上正规算子的集合不是  $ \mathcal{L}(V) $ 的子空间.

11 设  $ P \in \mathcal{L}(V) $ 使得  $ P^2 = P $。证明：V 有一个子空间 U 使得  $ P = P_U $ 当且仅当 P 是自伴的。

12 设 T 是 V 上的正规算子且 3 和 4 都是 T 的本征值．证明存在向量  $ v \in V $ 使得  $ \|v\| = \sqrt{2} $ 且  $ \|Tv\| = 5 $．

13 找出一个算子  $ T \in \mathcal{L}(\mathbf{C}^4) $ 使得  $ T $ 是正规的但不是自伴的.

14 设 T 是 V 上的正规算子，并设  $ v, w \in V $ 满足

 $$ \left\|\boldsymbol{v}\right\|=\left\|\boldsymbol{w}\right\|=2,\quad T\boldsymbol{v}=3\boldsymbol{v},\quad T\boldsymbol{w}=4\boldsymbol{w}. $$ 

证明  $ \|T(\nu + w)\| = 10. $

15 取定  $ u, x \in V $. 定义  $ T \in \mathcal{L}(V) $ 如下：对每个  $ v \in V $ 有  $ Tv = \langle v, u \rangle x $.

(a) 设 F = R. 证明：T 是自伴的当且仅当 u, x 是线性相关的.

(b) 证明：T 是正规的当且仅当 u, x 是线性相关的.