正规算子

7.18 定义 正规的（normal）

• 内积空间上的算子称为正规的，如果它和它的伴随是交换的.

• 也就是说， $ T \in \mathcal{L}(V) $ 是正规的，如果  $ TT^* = T^*T $.

自伴算子显然是正规的，这是因为若 T 是自伴的，则  $ T^{*}=T $.

7.19 例 设 T 是  $ F^{2} $ 上的算子，它（关于标准基）的矩阵为

 $$ \left(\begin{array}{cc}2&-3\\ 3&2\end{array}\right). $$ 

证明 T 不是自伴的但 T 是正规的.

证明 这个算子不是自伴的，因为第 2 行第 1 列的元素（等于 3）不是第 1 行第 2 列元素（等于 -3）的复共轭.

 $ TT^{*} $ 的矩阵是

 $$ \left(\begin{array}{cc}{{{2}}}&{{{-3}}} \\{{{3}}}&{{{2}}} \\\end{array}\right)\left(\begin{array}{cc}{{{2}}}&{{{3}}} \\{{{-3}}}&{{{2}}} \\\end{array}\right)=\left(\begin{array}{cc}{{{13}}}&{{{0}}} \\{{{0}}}&{{{13}}} \\\end{array}\right). $$ 

类似地， $ T^{*}T $ 的矩阵是

 $$ \left(\begin{array}{cc}{{{2}}}&{{{3}}} \\{{{-3}}}&{{{2}}} \\\end{array}\right)\left(\begin{array}{cc}{{{2}}}&{{{-3}}} \\{{{3}}}&{{{2}}} \\\end{array}\right)=\left(\begin{array}{cc}{{{13}}}&{{{0}}} \\{{{0}}}&{{{13}}} \\\end{array}\right). $$ 

因为  $ TT^{*} $ 和  $ T^{*}T $ 有相同的矩阵，所以  $ TT^{*}=T^{*}T $，于是 T 是正规的.

以下命题表明对每个正规算子 T 均有  $ \text{null} T = \text{null} T^{*} $.

在下一节我们会看到为什么正规算子值得特别关注.

以下命题给出了正规算子的简单刻画.



7.20 $T$ 是正规的当且仅当对所有 $\nu$ 均有 $\|T\nu\| = \|T^*\nu\|$

算子 $T \in \mathcal{L}(V)$ 是正规的当且仅当对所有 $\nu \in V$ 均有 $\|T\nu\| = \|T^*\nu\|$.

证明 设  $ T \in \mathcal{L}(V) $. 我们将同时证明这个结论的两个方面. 注意到

 $$ \begin{aligned}T 是正规的 &\Longleftrightarrow T^{*}T-TT^{*}=0\\&\Longleftrightarrow\langle(T^{*}T-TT^{*})v,v\rangle=0 对所有 v\in V 成立 \\&\Longleftrightarrow\langle T^{*}T v,v\rangle=\langle TT^{*}v,v\rangle 对所有 v\in V 成立 \\&\Longleftrightarrow\|Tv\|^{2}=\|T^{*}\|^{2} 对所有 v\in V 成立 ,\end{aligned} $$ 