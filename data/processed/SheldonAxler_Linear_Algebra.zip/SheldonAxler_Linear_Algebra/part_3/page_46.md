其中每个  $ U_{j} $ 都是 V 在 T 下的不变子空间．可能存在的、最简单的非零不变子空间是一维的．上面分解中的每个  $ U_{j} $ 都是在 T 下不变的 V 的一维子空间，当且仅当 V 有一个由 T 的本征向量组成的基（参见 5.41），当且仅当 V 有如下本征空间分解

8.8

 $$ V=E(\lambda_{1},T)\oplus\cdots\oplus E(\lambda_{m},T), $$ 

其中  $ \lambda_{1},\ldots,\lambda_{m} $ 是 T 的所有互不相同的本征值（参见 5.41）.

上一章的谱定理证明了，若 V 是内积空间，则形如 8.8 的分解在 F = C 时对每个正规算子都成立，而在 F = R 时对每个自伴算子都成立，这是因为这些形式的算子有足够的本征向量来构成 V 的一个基（参见 7.24 和 7.29）.

可惜的是，即使在复向量空间上，形如 8.8 的分解对更一般的算子也可能不成立．5.43 给出的算子就是一个例子，它没有足够多的本征向量使得 8.8 成立．我们现在要引入的广义本征向量和广义本征空间将会改善这种局面．

8.9 定义 广义本征向量（generalized eigenvector）

设  $ T \in \mathcal{L}(V) $， $ \lambda $ 是 T 的本征值。向量  $ v \in V $ 称为 T 的相应于  $ \lambda $ 的广义本征向量，如果  $ v \neq 0 $ 且存在正整数 j 使得  $ (T - \lambda I)^{j}v = 0 $。

虽然在广义本征向量定义中等式

 $$ (T-\lambda I)^{j}v=0 $$ 

中的 j 可以是任意正整数，但我们马上就要证明，当  $ j = \dim V $ 时每个广义本征向量都满足这个等式.

注意，我们没有定义广义本征值的概念，因为这样不会得到任何新东西。理由是：如果对某个正整数 j， $ (T-\lambda I)^{2} $ 不是单的，则  $ (T-\lambda I) $ 也不是单的，因此  $ \lambda $ 是 T 的本征值。



8.10 定义 广义本征空间（generalized eigenspace）， $ G(\lambda,T) $

设  $ T \in \mathcal{L}(V) $ 且  $ \lambda \in \mathbf{F} $。则 T 的相应于  $ \lambda $ 的广义本征空间（记作  $ G(\lambda, T) $）定义为 T 的相应于  $ \lambda $ 的所有广义本征向量的集合，包括 0 向量。

因为  $ T $ 的每个本征向量是  $ T $ 的广义本征向量（在广义本征向量的定义中取  $ j = 1 $），所以每个本征空间都包含在相应的广义本征空间中．也就是说，如果  $ T \in \mathcal{L}(V) $ 且  $ \lambda \in \mathbf{F} $，则

 $$ E(\lambda,T)\subset G(\lambda,T). $$ 

以下命题表明，如果  $ T \in \mathcal{L}(V) $ 且  $ \lambda \in \mathbf{F} $，则  $ G(\lambda, T) $ 是 V 的子空间（因为 V 上每个线性映射的零空间都是 V 的子空间）。

### 8.11 广义本征空间的刻画

设  $ T \in \mathcal{L}(V) $ 且  $ \lambda \in \mathbf{F} $。则  $ G(\lambda, T) = \text{null}(T - \lambda I)^{\text{dim}} V $。