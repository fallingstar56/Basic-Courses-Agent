于是 $ (S+T)^{*}w=S^{*}w+T^{*}w. $

(b) 设  $ \lambda \in \mathbf{F} $， $ T \in \mathcal{L}(V, W) $。若  $ \nu \in V $ 且  $ w \in W $，则

 $$ \langle\nu,(\lambda T)^{*}w\rangle=\langle\lambda T\nu,w\rangle=\lambda\langle T\nu,w\rangle=\lambda\langle\nu,T^{*}w\rangle=\langle\nu,\bar{\lambda}T^{*}w\rangle. $$ 

于是  $ \left(\lambda T\right)^{*}w=\bar{\lambda}T^{*}w. $

(c) 设  $ T \in \mathcal{L}(V, W) $. 若  $ v \in V $ 且  $ w \in W $，则

 $$ \langle w,(T^{*})^{*}\nu\rangle=\langle T^{*}w,\nu\rangle=\overline{{\langle v,T^{*}w\rangle}}=\overline{{\langle T\nu,w\rangle}}=\langle w,T\nu\rangle. $$ 

于是 $ (T^{*})^{*}\nu=Tv. $

(d) 若  $ v, u \in V $，则

 $$ \langle\nu,I^{*}u\rangle=\langle I\nu,u\rangle=\langle\nu,u\rangle=\langle\nu,I u\rangle. $$ 

于是  $ I^{*}u=I u. $

(e) 设  $ T \in \mathcal{L}(V, W) $ 且  $ S \in \mathcal{L}(W, U) $. 若  $ v \in V $ 且  $ u \in U $，则

 $$ \langle\nu,(S T)^{*}u\rangle=\langle S T\nu,u\rangle=\langle T\nu,S^{*}u\rangle=\langle\nu,T^{*}(S^{*}u)\rangle. $$ 

于是  $ (ST)^{*}u = T^{*}(S^{*}u) $.

以下命题描述了线性映射及其伴随的零空间和值域之间的关系．记号 $ \Longleftrightarrow $的意思是“当且仅当”，这个记号也可以理解为“等价于”．

7.7  $ T^{*} $ 的零空间与值域
设  $ T \in \mathcal{L}(V, W) $. 则
(a) null  $ T^{*} = (\text{range } T)^{\perp} $;
(b) range  $ T^{*} = (\text{null } T)^{\perp} $;
(c) null  $ T = (\text{range } T^{*})^{\perp} $;
(d) range  $ T = (\text{null } T^{*})^{\perp} $.

证明 首先证明 (a). 设  $ w \in W $. 则

 $$ \begin{aligned}w\in null T^{*}\Longleftrightarrow T^{*}w&=0\\&\Longleftrightarrow\langle\nu,T^{*}w\rangle=0 对所有 \nu\in V 成立 \\&\Longleftrightarrow\langle T\nu,w\rangle=0 对所有 \nu\in V 成立 \\&\Longleftrightarrow w\in(range T)^{\perp}.\end{aligned} $$ 

于是 null  $ T^{*} = (\text{range } T)^{\perp} $，这就证明了 (a).

对 (a) 的两端取正交补并利用 6.51 可得 (d). 在 (a) 中将 T 换成  $ T^{*} $ 并利用 7.6(c) 可得 (c). 最后，在 (d) 中将 T 换成  $ T^{*} $ 可得 (b).