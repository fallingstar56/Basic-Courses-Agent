其中符号  $ \subset $ 的意思是“包含于但不等于”。在上述链的每个严格包含关系处维数至少增加 1。因此  $ \dim\text{null}T^{n+1} \geq n+1 $，矛盾，因为 V 的子空间的维数不可能大于 n。

遗憾的是， $ V = \text{null} T \oplus \text{range} T $ 并不是对每个  $ T \in \mathcal{L}(V) $ 都成立。然而，以下命题是一个有用的替补。

8.5 V 等于 null  $ T^{\dim V} $ 和 range  $ T^{\dim V} $ 的直和
设  $ T \in \mathcal{L}(V) $. 令  $ n = \dim V $. 则  $ V = \text{null} T^n \oplus \text{range} T^n $.

证明 先证

### 8.6 

 $$ \left(null T^{n}\right)\cap\left(range T^{n}\right)=\left\{0\right\}. $$ 

设  $  v \in (\text{null} T^n) \cap (\text{range} T^n)  $. 则  $  T^n v = 0  $，存在  $  u \in V  $ 使得  $  v = T^n u  $. 将  $  T^n  $ 作用于前式两端得  $  T^n v = T^{2n} u  $. 因此  $  T^{2n} u = 0  $，从而  $  T^n u = 0  $（由于 8.4）. 于是  $  v = T^n u = 0  $，完成了 8.6 的证明.

现在由 8.6 可知 null  $ T^{n} + \text{range } T^{n} $ 是一个直和（由于 1.45）。此外

 $$ \dim(null T^{n}\oplus range T^{n})=\dim null T^{n}+\dim range T^{n}=\dim V, $$ 

上述第一个等式由 3.78 得到，第二个等式由线性映射基本定理 3.22 得到．由上式可得 null  $ T^n \oplus \text{range} T^n = V $.

8.7 例 设  $ T \in \mathcal{L}(\mathbf{F}^3) $ 定义为

 $$ T(z_{1},z_{2},z_{3})=(4z_{2},0,5z_{3}). $$ 

对于这个算子， $  \text{null} T + \text{range} T  $ 不是子空间的直和。因为  $  \text{null} T = \{(z_1, 0, 0) : z_1 \in \mathbf{F}\}  $ 且  $  \text{range} T = \{(z_1, 0, z_3) : z_1, z_3 \in \mathbf{F}\}  $，所以  $  \text{null} T \cap \text{range} T \neq \{0\}  $，因此  $  \text{null} T + \text{range} T  $ 不是直和。也请注意  $  \text{null} T + \text{range} T \neq \mathbf{F}^3  $。

然而我们有  $ T^{3}(z_{1},z_{2},z_{3})=(0,0,125z_{3}) $ 。于是  $ \mathrm{null}T^{3}=\{(z_{1},z_{2},0):z_{1},z_{2}\in\mathbf{F}\} $ 且  $ \mathrm{range}T^{3}=\{(0,0,z_{3}):z_{3}\in\mathbf{F}\} $ 。因此  $ \mathbf{F}^{3}=\mathrm{null}T^{3}\oplus\mathrm{range}T^{3} $ 。

## 广义本征向量

有些算子因为没有足够多的本征向量而没有一个好的描述．因此，本节将引入广义本征向量的概念，这一概念对算子结构的描述起着重要作用．

为了理解为什么需要更多的本征向量，我们来考察如何通过算子定义域的不变子空间分解来描述这个算子．取定  $ T \in \mathcal{L}(V) $．为了描述 T，我们想要找到一个 “好的” 直和分解

 $$ V=U_{1}\oplus\cdots\oplus U_{m}, $$ 