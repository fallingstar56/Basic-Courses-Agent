设 u 和 w 如上式．很明显  $ u \in U $．因为  $ e_1, \ldots, e_m $ 是一个规范正交组，所以对每个  $ j = 1, \ldots, m $ 均有

 $$ \left\langle w,e_{j}\right\rangle=\left\langle\nu,e_{j}\right\rangle-\left\langle\nu,e_{j}\right\rangle=0. $$ 

于是  $ w $ 正交于  $ \operatorname{span}(e_1, \ldots, e_m) $ 中的每个向量．也就是说  $ w \in U^\perp $．于是  $ v = u + w $，其中  $ u \in U $ 且  $ w \in U^\perp $，这就证明了 6.48．

由 6.46(d) 有  $ U \cap U^{\perp} = \{0\} $. 再由 6.48 有  $ V = U \oplus U^{\perp} $ (见 1.45).

现在可以看到如何利用 dim U 来计算 dim U⁻.

### 6.50 正交补的维数

设 V 是有限维的且 U 是 V 的子空间，则  $ \dim U^{\perp} = \dim V - \dim U $.

证明 由 6.47 和 3.78 立即可得  $ \dim U^{\perp} $ 的公式.

下面的命题是 6.47 的一个重要推论.

### 6.51 正交补的正交补

设 U 是 V 的有限维子空间，则  $ U = (U^{\perp})^{\perp} $.

证明 首先证明

6.52

 $$ U\subset(U^{\perp})^{\perp}. $$ 

为此，设  $ u \in U $。则对每个  $ v \in U^\perp $ 均有  $ \langle u, v \rangle = 0 $（由  $ U^\perp $ 的定义）。因为  $ u $ 正交于  $ U^\perp $ 中的每个向量，所以  $ u \in (U^\perp)^\perp $，这就证明了 6.52。

要证明另一个方向的包含关系，设  $ v \in (U^\perp)^\perp $。由 6.47 可得  $ v = u + w $，其中  $ u \in U $ 且  $ w \in U^\perp $。从而  $ v - u = w \in U^\perp $。因为  $ v \in (U^\perp)^\perp $ 且  $ u \in (U^\perp)^\perp $（由于 6.52），所以  $ v - u \in (U^\perp)^\perp $。于是  $ v - u \in U^\perp \cap (U^\perp)^\perp $，这表明  $ (v - u) $ 与自身正交，从而  $ v - u = 0 $，即  $ v = u $，于是  $ v \in U $。因此  $ (U^\perp)^\perp \subset U $，再结合 6.52 就完成了证明。

现在我们对 V 的每个有限维子空间定义一个算子  $ P_{U} $

6.53 定义 正交投影（orthogonal projection）， $ P_U $

设  $ U $ 是  $ V $ 的有限维子空间．定义  $ V $ 到  $ U $ 上的正交投影为如下算子  $ P_U \in \mathcal{L}(V) $：

对  $ v \in V $，将其写成  $ v = u + w $，其中  $ u \in U $ 且  $ w \in U^\perp $，则  $ P_U v = u $。

6.47 中给出的直和分解  $ V = U \oplus U^{\perp} $ 表明每个  $ v \in V $ 均可唯一地写成  $ v = u + w $，其中  $ u \in U $ 且  $ w \in U^{\perp} $。于是  $ P_{U}v $ 定义合理。

6.54 例 设  $ x \in V $， $ x \neq 0 $ 且  $ U = \text{span}(x) $。证明对每个  $ v \in V $ 均有

 $$ P_{U}\nu=\frac{\left\langle\nu,x\right\rangle}{\left\|x\right\|^{2}}x. $$ 