7.11 定义 自伴的（self-adjoint）

算子  $ T \in \mathcal{L}(V) $ 称为自伴的，如果  $ T = T^* $。也就是说， $ T \in \mathcal{L}(V) $ 是自伴的当且仅当对所有  $ v, w \in V $ 均有  $ \langle T v, w \rangle = \langle v, T w \rangle $。

7.12 例 设 T 是  $ F^{2} $ 上的算子，它（关于标准基）的矩阵是

 $$ \left(\begin{array}{cc}{{{2}}}&{{{b}}} \\{{{3}}}&{{{7}}}\end{array}\right). $$ 

求数 b 使得 T 是自伴的.

解 算子 T 是自伴的当且仅当  $ b = 3 $ （因为  $ \mathcal{M}(T) = \mathcal{M}(T^*) $ 当且仅当  $ b = 3 $. 回想一下  $ \mathcal{M}(T^*) $ 是  $ \mathcal{M}(T) $ 的共轭转置，参见 7.10）.

请自行验证：两个自伴算子的和是自伴的，实数和自伴算子的乘积是自伴的。

有的数学家采用术语“埃尔米特的”代替“自伴的”，以纪念法国数学家夏尔·埃尔米特，他在1873年首次证明了e不是任何整系数多项式的根。

请记住一个很好的类比（尤其是当 F = C 时）：伴随在  $ \mathcal{L}(V) $ 上所起的作用犹如复共轭在 C 上所起的作用．复数 z 是实的当且仅当  $ z = \bar{z} $，因此自伴算子  $ (T = T^{*}) $ 可与实数类比.



我们将看到，这种类比也反映在自伴算子的某些重要性质上，先来看本征值.

若 F = R，则由定义可知每个本征值都是实的，所以下面的命题仅当 F = C 时才有意思.

7.13 自伴算子的本征值是实的

自伴算子的每个本征值都是实的.

证明 设 T 是 V 上的自伴算子， $ \lambda $ 是 T 的本征值， $ \nu $ 是 V 中的非零向量使得  $ T\nu = \lambda\nu $。则

 $$ \lambda\|v\|^{2}=\langle\lambda v,v\rangle=\langle T v,v\rangle=\langle v,T v\rangle=\langle v,\lambda v\rangle=\bar{\lambda}\|v\|^{2}. $$ 

于是  $ \lambda = \bar{\lambda} $，即  $ \lambda $ 是实的.

下面的命题对实内积空间不成立．例如，考虑如下定义的算子  $ T \in \mathcal{L}(\mathbf{R}^2) $，它是绕原点的逆时针  $ 90^\circ $ 旋转，因此  $ T(x, y) = (-y, x) $．显然对每个  $ v \in \mathbf{R}^2 $ 有  $ T v $ 正交于  $ v $，即使  $ T \neq 0 $.

7.14 在 C 上，只有 0 算子才能使得  $ T_V $ 总正交于  $ v $

设  $ V $ 是复内积空间， $ T \in \mathcal{L}(V) $。假设对所有  $ v \in V $ 均有  $ \langle T_V, v \rangle = 0 $，则  $ T = 0 $。