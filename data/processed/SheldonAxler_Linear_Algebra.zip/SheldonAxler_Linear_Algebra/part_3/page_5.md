4 设 n 是正整数．证明

 $$ \frac{1}{\sqrt{2\pi}},\frac{\cos x}{\sqrt{\pi}},\frac{\cos2x}{\sqrt{\pi}},\cdots,\frac{\cos nx}{\sqrt{\pi}},\frac{\sin x}{\sqrt{\pi}},\frac{\sin2x}{\sqrt{\pi}},\cdots,\frac{\sin nx}{\sqrt{\pi}} $$ 

是  $ C[-\pi,\pi] $ 的规范正交组，这里  $ C[-\pi,\pi] $ 是  $ [-\pi,\pi] $ 上的实值连续函数构成的向量空间，其上的内积为

 $$ \langle f,g\rangle=\int_{-\pi}^{\pi}f(x)g(x)\mathrm{d}x. $$ 

上述规范正交组经常用来建立诸如潮汐等周期现象的数学模型。

5 在  $ \mathcal{P}_{2}(\mathbf{R}) $ 上考虑内积

 $$ \langle p,q\rangle=\int_{0}^{1}p(x)q(x)\mathrm{d}x. $$ 

对基 1, x,  $ x^{2} $ 应用格拉姆-施密特过程求  $ \mathcal{P}_{2}(\mathbf{R}) $ 的一个规范正交基.

6 求  $ \mathcal{P}_{2}(\mathbf{R}) $ 的一个规范正交基（采用习题 5 的内积）使得  $ \mathcal{P}_{2}(\mathbf{R}) $ 上的微分算子（即把 p 映成  $ p' $ 的算子）关于这个基具有上三角矩阵.

7 求多项式  $  q \in \mathcal{P}_2(\mathbf{R})  $ 使得对每个  $  p \in \mathcal{P}_2(\mathbf{R})  $ 均有

 $$ p\left(\frac{1}{2}\right)=\int_{0}^{1}p(x)q(x)\mathrm{d}x. $$ 

8 求多项式  $  q \in \mathcal{P}_2(\mathbf{R})  $ 使得对每个  $  p \in \mathcal{P}_2(\mathbf{R})  $ 均有

 $$ \int_{0}^{1}p(x)(\cos\pi x)\mathrm{d}x=\int_{0}^{1}p(x)q(x)\mathrm{d}x. $$ 

9 对不是线性无关的向量组应用格拉姆-施密特过程结果会怎样？

10 设 V 是实内积空间且  $ v_{1}, \ldots, v_{m} $ 是 V 中的线性无关向量组．证明 V 中恰好有  $ 2^{m} $ 个规范正交组  $ e_{1}, \ldots, e_{m} $ 使得对所有  $ j \in \{1, \ldots, m\} $ 均有  $ \operatorname{span}(v_{1}, \ldots, v_{j}) = \operatorname{span}(e_{1}, \ldots, e_{j}) $．

11 设  $ \langle\cdot,\cdot\rangle_{1} $ 和  $ \langle\cdot,\cdot\rangle_{2} $ 都是 V 上的内积使得  $ \langle v,w\rangle_{1}=0 $ 当且仅当  $ \langle v,w\rangle_{2}=0 $ 。证明存在正数 c 使得对任意  $ v,w\in V $ 均有  $ \langle v,w\rangle_{1}=c\langle v,w\rangle_{2} $ 。

12 设  $ V $ 是有限维的， $ \langle\cdot,\cdot\rangle_1 $ 和  $ \langle\cdot,\cdot\rangle_2 $ 都是  $ V $ 上的内积，对应的范数是  $ \|\cdot\|_1 $ 和  $ \|\cdot\|_2 $。证明存在正数  $ c $ 使得对每个  $ v \in V $ 均有  $ \|v\|_1 \leq c\|v\|_2 $。

13 设  $ v_{1}, \ldots, v_{m} $ 是 V 中的线性无关向量组．证明存在  $ w \in V $ 使得对所有  $ j \in \{1, \ldots, m\} $ 均有  $ \langle w, v_{j} \rangle > 0 $．

14 设  $ e_{1}, \ldots, e_{n} $ 是 V 的规范正交基，并设  $ v_{1}, \ldots, v_{n} $ 是 V 中的向量使得对每个 j 均有

 $$ \|e_{j}-\nu_{j}\|<\frac{1}{\sqrt{n}}. $$ 

证明  $ v_{1},\ldots,v_{n} $ 是 V 的基.