12 设  $ T \in \mathcal{L}(V) $ 是自伴的， $ \lambda \in \mathbf{F} $ 且  $ \epsilon > 0 $。假设存在  $ \nu \in V $ 使得  $ \|v\| = 1 $ 且

 $$ \left\|T\boldsymbol{v}-\lambda\boldsymbol{v}\right\|<\epsilon. $$ 

证明 T 有一个本征值  $ \lambda' $ 使得  $ |\lambda - \lambda'| < \epsilon $.

13 给出复谱定理的另一个证明，不要使用舒尔定理，而是按照实谱定理的证明方式.

14 设 $U$ 是有限维的实向量空间且 $T \in \mathcal{L}(U)$。证明：$U$ 有一个由 $T$ 的本征向量构成的基当且仅当存在 $U$ 上的内积使得 $T$ 是自伴算子。

15 求出下面被遮住的矩阵元素.

<div style="text-align: center;"><img src="imgs/img_in_image_box_230_436_672_684.jpg" alt="Image" width="48%" /></div>


### 7. C 正算子与等距同构

正算子

7.31 定义 正算子（positive operator）

称算子  $ T \in \mathcal{L}(V) $ 是正的，如果  $ T $ 是自伴的且对所有  $ \nu \in V $ 均有  $ \langle T\nu, \nu \rangle \geq 0 $.

若 V 是复向量空间，则 T 自伴的条件可以从上面的定义中去掉（由于 7.15）.

7.32 例 正算子

(a) 若 U 是 V 的子空间，则正交投影  $ P_{U} $ 是正算子（请自行验证）.

(b) 若  $ T \in \mathcal{L}(V) $ 是自伴的，且  $ b, c \in \mathbb{R} $ 使得  $ b^2 < 4c $，则  $ T^2 + bT + cI $ 是正算子，如 7.26 的证明所示。