 $ \sin x $ 的另一个熟知的 5 次多项式逼近是由泰勒多项式

### 6.61 

 $$ x-\frac{x^{3}}{3!}+\frac{x^{5}}{5!} $$ 

给出的．我们来看一下这个逼近的精确度如何，下图显示了  $ \sin x $ 和泰勒多项式 6.61 在区间  $ [-π, π] $ 上的图像.

<div style="text-align: center;"><img src="imgs/img_in_image_box_160_291_713_474.jpg" alt="Image" width="61%" /></div>


<div style="text-align: center;">在  $ [-π, π] $ 上  $ \sin x $ 的图像（蓝色）和泰勒多项式 6.61 的图像（红色）</div>


泰勒多项式在 0 附近对  $ \sin x $ 有极好的逼近．但上图表明对  $ |x| > 2 $ 泰勒多项式并不怎么精确，特别是与 6.60 相比较．例如，取 x = 3，我们的逼近 6.60 对  $ \sin 3 $ 估计的误差大概是 0.001，但是泰勒级数 6.61 对  $ \sin 3 $ 估计的误差大概是 0.4．因此对于 x = 3 泰勒级数的误差比 6.60 的误差大几百倍．线性代数帮助我们发现了  $ \sin x $ 的一个逼近，这个逼近改进了我们在微积分中学到的逼近！

### 习题 6.C

1 设  $ \nu_{1},\ldots,\nu_{m}\in V $．证明  $ \{\nu_{1},\ldots,\nu_{m}\}^{\perp}=\left(\operatorname{span}(\nu_{1},\ldots,\nu_{m})\right)^{\perp} $

2 设 U 是 V 的有限维子空间．证明  $ U^{\perp} = \{0\} $ 当且仅当 U = V．

习题 14(a) 表明，如果去掉 “U 是有限维的” 这一假设，则上面的结果不成立.

3 设 U 是 V 的子空间，设  $ u_{1}, \ldots, u_{m} $ 是 U 的基，且

 $$ u_{1},\cdots,u_{m},w_{1},\cdots,w_{n} $$ 

是 V 的基．证明若对 V 的上述基应用格拉姆-施密特过程得到组  $ e_{1},\ldots,e_{m} $， $ f_{1},\ldots,f_{n} $，则  $ e_{1},\ldots,e_{m} $ 是 U 的规范正交基， $ f_{1},\ldots,f_{n} $ 是  $ U^{\perp} $ 的规范正交基.

4 给定  $ R^{4} $ 的子空间

 $$ U=\operatorname{span}\left(\left(1,2,3,-4\right),\left(-5,4,3,2\right)\right). $$ 

求 U 的一个规范正交基和  $ U^{\perp} $ 的一个规范正交基.

5 设 V 是有限维的且 U 是 V 的子空间. 证明  $ P_{U^{\perp}} = I - P_{U} $，这里 I 是 V 上的恒等算子.

6 设 U 和 W 均为 V 的有限维子空间．证明  $ P_{U}P_{W}=0 $ 当且仅当对所有  $ u\in U $ 和  $ w\in W $ 均有  $ \langle u,w\rangle=0 $．