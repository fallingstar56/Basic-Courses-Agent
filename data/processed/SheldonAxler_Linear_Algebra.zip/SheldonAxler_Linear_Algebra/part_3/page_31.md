### 7.33 定义 平方根（square root）

算子 R 称为算子 T 的平方根，如果  $ R^{2}=T $.

7.34 例 设  $ T \in \mathcal{L}(\mathbf{F}^3) $ 是由  $ T(z_1, z_2, z_3) = (z_3, 0, 0) $ 定义的算子，则由  $ R(z_1, z_2, z_3) = (z_2, z_3, 0) $ 定义的算子  $ R \in \mathcal{L}(\mathbf{F}^3) $ 是 T 的平方根.

正算子对应于  $ [0,\infty) $ 中的数，因此在术语上更应该称为非负的而不是称为正的。然而算子理论学家始终称之为正算子，因此我们将沿袭这个传统。

下面的定理对正算子的刻画与 C 中非负数的刻画是相对应的．具体来说，复数 z 非负当且仅当它有非负平方根，这对应于条件 (c)．此外，z 非负当且仅当它有实的平方根，这对应于条件 (d)．最后，z 非负当且仅当有复数 w 使得  $ z = \bar{w}w $，这对应于条件 (e).



### 7.35 正算子的刻画

设  $ T \in \mathcal{L}(V) $. 则以下条件等价:

(a) T 是正的;

(b) T 是自伴的且 T 的所有本征值非负；

(c) T 有正的平方根;

(d) T 有自伴的平方根;

(e) 存在算子  $  R \in \mathcal{L}(V)  $ 使得  $  T = R^* R  $.

证明 我们将证明 (a)  $ \Rightarrow $ (b)  $ \Rightarrow $ (c)  $ \Rightarrow $ (d)  $ \Rightarrow $ (e)  $ \Rightarrow $ (a).

首先假设 (a) 成立，则 T 是正的。显然 T 是自伴的（根据正算子的定义）。为证 (b) 中的其他结果，设  $ \lambda $ 是 T 的本征值， $ \nu $ 是 T 的相应于  $ \lambda $ 的本征向量，则

 $$ 0\leq\langle T\nu,\nu\rangle=\langle\lambda\nu,\nu\rangle=\lambda\langle\nu,\nu\rangle. $$ 

于是  $ \lambda $ 是非负数. 因此 (b) 成立.

现在假设(b)成立，则T是自伴的，并且T的所有本征值都是非负的。由谱定理(7.24和7.29)，V有一个由T的本征向量组成的规范正交基 $ e_{1},\ldots,e_{n} $。设T的相应于 $ e_{1},\ldots,e_{n} $的本征值为 $ \lambda_{1},\ldots,\lambda_{n} $，则每个 $ \lambda_{j} $都是非负数。设R是从V到V的线性映射使得对 $ j=1,\ldots,n $有

 $$ Re_{j}=\sqrt{\lambda_{j}}e_{j} $$ 

（见 3.5）. 那么 R 是正算子（请自行验证）. 此外，对每个 j 都有  $ R^{2}e_{j} = \lambda_{j}e_{j} = Te_{j} $，由此可得  $ R^{2} = T $. 于是 R 是 T 的正平方根，因此 (c) 成立.

显然(c) 蕴涵(d)（因为由定义知正算子都是自伴的）.