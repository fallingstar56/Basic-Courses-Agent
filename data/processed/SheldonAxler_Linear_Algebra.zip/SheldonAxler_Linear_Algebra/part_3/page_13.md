7 设 V 是有限维的， $ P \in \mathcal{L}(V) $ 使得  $ P^{2} = P $ 且 null P 中的向量与 range P 中的向量都正交．证明有 V 的子空间 U 使得  $ P = P_{U} $．

8 设  $ V $ 是有限维的， $ P \in \mathcal{L}(V) $ 使得  $ P^2 = P $ 且对每个  $ v \in V $ 均有  $ \|P v\| \leq \|v\| $。证明存在  $ V $ 的子空间  $ U $ 使得  $ P = P_U $。

9 设  $ T \in \mathcal{L}(V) $，U 是 V 的有限维子空间．证明 U 在 T 下不变当且仅当  $ P_{U}TP_{U} = TP_{U} $．

10 设 V 是有限维的， $ T \in \mathcal{L}(V) $，U 是 V 的子空间．证明 U 和  $ U^{\perp} $ 都在 T 下不变当且仅当  $ P_{U}T = TP_{U} $．

11 在  $ R^{4} $ 中设  $ U = \text{span}((1,1,0,0),(1,1,1,2)) $。求  $ u \in U $ 使得  $ \|u - (1,2,3,4)\| $ 最小.

12 求  $ p \in \mathcal{P}_3(\mathbf{R}) $ 使得  $ p(0) = 0 $,  $ p'(0) = 0 $, 而且

 $$ \int_{0}^{1}\left|2+3x-p(x)\right|^{2}\mathrm{d}x $$ 

最小.

13 求  $ p \in \mathcal{P}_{5}(\mathbf{R}) $ 使得

 $$ \int_{-\pi}^{\pi}\left|\sin x-p(x)\right|^{2}\mathrm{d}x $$ 

最小.

多项式 6.60 是本题的一个极好的近似解，但是这里要找的是包含  $ \pi $ 的幂的精确解．可以使用能演算符号积分的计算机.

14 设  $ C_{\mathbf{R}}([-1,1]) $ 是区间  $ [-1,1] $ 上实值连续函数构成的向量空间，且其上的内积为：对  $ f, g \in C_{\mathbf{R}}([-1,1]) $

 $$ \langle f,g\rangle=\int_{-1}^{1}f(x)g(x)\mathrm{d}x. $$ 

给定  $ C_{\mathbf{R}}([-1,1]) $ 的子空间  $ U = \{f \in C_{\mathbf{R}}([-1,1]) : f(0) = 0\} $.

(a) 证明  $ U^{\perp} = \{0\} $.

(b) 证明当没有“有限维”这一假设时，6.47 和 6.51 不成立.