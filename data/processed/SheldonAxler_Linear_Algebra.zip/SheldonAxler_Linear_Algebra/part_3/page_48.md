于是

 $$ (T-\lambda_{1}I)w=(T-\lambda_{1}I)^{k+1}v_{1}=0, $$ 

因此  $ Tw = \lambda_1w $。于是对每个  $ \lambda \in \mathbf{F} $ 都有  $ (T - \lambda I)w = (\lambda_1 - \lambda)w $。因此对每个  $ \lambda \in \mathbf{F} $ 都有

8.15

 $$ \left(T-\lambda I\right)^{n}w=\left(\lambda_{1}-\lambda\right)^{n}w, $$ 

其中  $ n = \dim V $.

将算子

 $$ (T-\lambda_{1}I)^{k}(T-\lambda_{2}I)^{n}\cdots(T-\lambda_{m}I)^{n} $$ 

作用于 8.14 的两边，得到

 $$ \begin{aligned}0&=a_{1}(T-\lambda_{1}I)^{k}(T-\lambda_{2}I)^{n}\cdots(T-\lambda_{m}I)^{n}v_{1}\\&=a_{1}(T-\lambda_{2}I)^{n}\cdots(T-\lambda_{m}I)^{n}w\\&=a_{1}(\lambda_{1}-\lambda_{2})^{n}\cdots(\lambda_{1}-\lambda_{m})^{n}w,\end{aligned} $$ 

其中我们利用 8.11 得到上面第一个等式，利用 8.15 得到上面最后一个等式.

由上面的等式可得  $ a_{1}=0 $ 。通过类似的方式可得，对每个 j 都有  $ a_{j}=0 $ 。于是  $ v_{1},\ldots,v_{m} $ 线性无关。

## 幂零算子

### 8.16 定义 幂零的（nilpotent）

一个算子称为幂零的，如果它的某个幂等于0.

8.17 例 幂零算子

(a) 定义为  $ N(z_{1}, z_{2}, z_{3}, z_{4}) = (z_{3}, z_{4}, 0, 0) $ 的算子  $ N \in \mathcal{L}(\mathbf{F}^{4}) $ 是幂零的，因为  $ N^{2} = 0 $.

(b)  $ \mathcal{P}_{m}(\mathbf{R}) $ 上的微分算子是幂零的，因为每个次数不超过 m 的多项式的  $ m+1 $ 阶导数都等于 0. 注意，在这个  $ m+1 $ 维空间上，我们需要把幂零算子自乘到  $ m+1 $ 次幂才能得到 0 算子.

以下命题表明，不用考虑比空间的维数更高的幂.

拉丁词 nil 的意思是无或者零，

拉丁词 potent 的意思是幂．于是

nilpotent 的字面意思是幂零.



8.18 n 维空间上幂零算子的 n 次幂等于 0

设  $ N \in \mathcal{L}(V) $ 是幂零的，则  $ N^{\dim V} = 0 $.

证明 因为 N 是幂零的，所以  $ G(0,N)=V $．利用 8.11 即得  $ \text{null}N^{\dim V}=V $．