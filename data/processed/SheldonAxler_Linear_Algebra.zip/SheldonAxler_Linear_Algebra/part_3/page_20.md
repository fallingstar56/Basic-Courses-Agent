证明 对所有  $ u, w \in V $ 均有

 $$ \begin{aligned}\langle T u,w\rangle&=\frac{\langle T(u+w),u+w\rangle-\langle T(u-w),u-w\rangle}{4}\\&\quad+\frac{\langle T(u+\mathrm{i}w),u+\mathrm{i}w\rangle-\langle T(u-\mathrm{i}w),u-\mathrm{i}w\rangle}{4}\mathrm{i}.\end{aligned} $$ 

这个等式可通过计算右端得到．注意到右端的每一项都具有  $ \langle Tv,v\rangle $ 的形式．我们的假设表明对所有  $ u,w \in V $ 均有  $ \langle Tu,w\rangle = 0 $，从而  $ T = 0 $（取  $ w = Tu $）．

通过考虑实内积空间上的非自伴算子可知，下面的命题对实内积空间不成立.

下面的命题提供了自伴算子与实数具有相似性质的另一个例子.



7.15 在 C 上，仅自伴算子才能使  $ \langle T_v, v \rangle $ 都是实数

设 V 是复内积空间， $ T \in \mathcal{L}(V) $。则 T 是自伴的当且仅当对每个  $ v \in V $ 均有  $ \langle T_v, v \rangle \in \mathbf{R} $。

证明 设  $ \nu \in V $. 则

 $$ \langle T\nu,\nu\rangle-\overline{{\langle T\nu,\nu\rangle}}=\langle T\nu,\nu\rangle-\langle\nu,T\nu\rangle=\langle T\nu,\nu\rangle-\langle T^{*}v,\nu\rangle=\langle(T-T^{*})\nu,\nu\rangle. $$ 

若对每个  $ v \in V $ 均有  $ \langle Tv, v \rangle \in \mathbb{R} $，则上式左端等于 0，所以对每个  $ v \in V $ 均有  $ \langle(T - T^*)v, v \rangle = 0 $。这表明  $ T - T^* = 0 $（由于 7.14）。因此  $ T $ 是自伴的。

反之，若  $ T $ 是自伴的，则上式的右端等于  $ 0 $，所以对每个  $ v \in V $ 均有  $ \langle Tv, v \rangle = \underline{\langle Tv, v \rangle} $。这表明对每个  $ v \in V $ 均有  $ \langle Tv, v \rangle \in \mathbf{R} $。

在实内积空间 V 上，非零算子 T 可能使得对所有  $ v \in V $ 均有  $ \langle T v, v \rangle = 0 $ 。然而，以下命题表明对于非零自伴算子就不会出现这种情况。

7.16 若  $ T = T^* $ 且对所有 v 均有  $ \langle T_v, v \rangle = 0 $，则 T = 0

若 T 是 V 上的自伴算子使得对所有  $ v \in V $ 均有  $ \langle T_v, v \rangle = 0 $，则 T = 0.

证明 我们已经对复内积空间证明了这一结论（没有 T 自伴的假设，参见 7.14）。因此可设 V 是实内积空间。若  $ u, w \in V $，则

7.17

 $$ \langle T u,w\rangle=\frac{\langle T(u+w),u+w\rangle-\langle T(u-w),u-w\rangle}{4}. $$ 

为证明上述等式，可利用下面的等式计算上式的右端：

 $$ \langle T w,u\rangle=\langle w,T u\rangle=\langle T u,w\rangle, $$ 

其中第一个等号成立是因为 T 是自伴的，第二个等号成立是因为我们处理的是实内积空间.

7.17 右端的每一项都形如  $ \langle Tv,v\rangle $。因此对所有  $ u,w \in V $ 均有  $ \langle Tu,w\rangle = 0 $，从而 T = 0（取  $ w = Tu $）。