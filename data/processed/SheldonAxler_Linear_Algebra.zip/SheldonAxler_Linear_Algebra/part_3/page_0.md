### 6.32 

 $$ \operatorname{span}(\nu_{1},\cdots,\nu_{j-1})=\operatorname{span}(e_{1},\cdots,e_{j-1}). $$ 

注意  $ v_{j} \notin \text{span}(v_{1}, \ldots, v_{j-1}) $ （因为  $ v_{1}, \ldots, v_{m} $ 是线性无关的）。于是  $ v_{j} \notin \text{span}(e_{1}, \ldots, e_{j-1}) $。因此在 6.31 的  $ e_{j} $ 定义中的分母不为 0。用一个向量除以它的范数就得到一个范数为 1 的新向量。因此  $ \|e_{j}\| = 1 $。

设  $ 1 \leq k < j $. 则

 $$ \begin{align*}\langle e_{j},e_{k}\rangle&=\left\langle\frac{\nu_{j}-\langle\nu_{j},e_{1}\rangle e_{1}-\cdots-\langle\nu_{j},e_{j-1}\rangle e_{j-1}}{\|\nu_{j}-\langle\nu_{j},e_{1}\rangle e_{1}-\cdots-\langle\nu_{j},e_{j-1}\rangle e_{j-1}\|},e_{k}\right\rangle\\&=\frac{\langle\nu_{j},e_{k}\rangle-\langle\nu_{j},e_{k}\rangle}{\|\nu_{j}-\langle\nu_{j},e_{1}\rangle e_{1}-\cdots-\langle\nu_{j},e_{j-1}\rangle e_{j-1}\|}\\&=0.\end{align*} $$ 

因此  $ e_{1},\ldots,e_{j} $ 是规范正交组.

从 6.31 给出的  $ e_j $ 的定义我们看到  $ \nu_j \in \text{span}(e_1, \ldots, e_j) $。再结合 6.32 得

 $$ \operatorname{span}(v_{1},\ldots,v_{j})\subset\operatorname{span}(e_{1},\ldots,e_{j}). $$ 

上面的这两个组都是线性无关的（这些  $ v_{k} $ 的线性无关性是根据假设得到的，这些  $ e_{k} $ 的线性无关性是由规范正交性和 6.26 得到的）。因此上面两个子空间的维数都为 j，从而一定相等。

6.33 例 求  $ \mathcal{P}_{2}(\mathbf{R}) $ 的一个规范正交基，这里的内积为  $ \langle p,q\rangle=\int_{-1}^{1}p(x)q(x)\,\mathrm{d}x $.

解 我们将对基 1, x,  $ x^{2} $ 应用格拉姆-施密特过程 6.31.

首先，我们有

 $$ \|1\|^{2}=\int_{-1}^{1}1^{2}\mathrm{d}x=2. $$ 

于是  $ \|1\|=\sqrt{2} $，所以  $ e_{1}=\sqrt{\frac{1}{2}} $.

现在  $ e_{2} $ 的表达式中的分子为

 $$ x-\langle x,e_{1}\rangle e_{1}=x-\left(\int_{-1}^{1}x\sqrt{\frac{1}{2}}\mathrm{d}x\right)\sqrt{\frac{1}{2}}=x. $$ 

我们有

 $$ \|x\|^{2}=\int_{-1}^{1}x^{2}\mathrm{d}x=\frac{2}{3}. $$ 

于是  $ \|x\|=\sqrt{\frac{2}{3}} $，所以  $ e_{2}=\sqrt{\frac{3}{2}}x $。

而  $ e_{3} $ 表达式中的分子为

 $$ \begin{aligned}x^{2}-\langle x^{2},e_{1}\rangle&e_{1}-\langle x^{2},e_{2}\rangle e_{2}\\&=x^{2}-\left(\int_{-1}^{1}x^{2}\sqrt{\frac{1}{2}}\mathrm{d}x\right)\sqrt{\frac{1}{2}}-\left(\int_{-1}^{1}x^{2}\sqrt{\frac{3}{2}}x\mathrm{d}x\right)\sqrt{\frac{3}{2}}x=x^{2}-\frac{1}{3}.\end{aligned} $$ 