6.40 例 如下定义的函数  $ \varphi: \mathbf{F}^3 \to \mathbf{F} $

 $$ \varphi(z_{1},z_{2},z_{3})=2z_{1}-5z_{2}+z_{3} $$ 

是  $ F^3 $ 上的线性泛函．我们可以将这个线性泛函写成如下形式：对每个  $ z \in F^3 $

 $$ \varphi(z)=\langle z,u\rangle, $$ 

其中  $ u = (2, -5, 1) $.

6.41 例 如下定义的函数  $ \varphi: \mathcal{P}_2(\mathbf{R}) \to \mathbf{R} $

 $$ \varphi(p)=\int_{-1}^{1}p(t)\big(\cos(\pi t)\big)\mathrm{d}t $$ 

是  $ \mathcal{P}_2(\mathbf{R}) $ 上的线性泛函（这里  $ \mathcal{P}_2(\mathbf{R}) $ 上的内积是  $ [-1,1] $ 上的两个函数相乘后做定积分，见 6.33）。下面的事实并不显然：存在  $ u \in \mathcal{P}_2(\mathbf{R}) $ 使得对任意  $ p \in \mathcal{P}_2(\mathbf{R}) $ 均有

 $$ \varphi(p)=\langle p,u\rangle. $$ 

（我们不能取  $ u(t)=\cos(\pi t) $，因为它不是  $ \mathcal{P}_{2}(\mathbf{R}) $ 中的元素。）

为纪念匈牙利数学家弗里杰什·里斯（1880—1956），下述定理用他的名字命名，里斯在二十世纪早期证明了与下述定理类似的结果。

如果  $ u \in V $，那么把 v 映成  $ \langle v, u \rangle $ 的映射是 V 上的线性泛函。下述定理表明，V 上的每个线性泛函都是这种形式的。上面的例 6.41 显示了下述定理的威力，因为对那个例子中的线性泛函，u 的取法并不明显。



### 6.42 里斯表示定理

设 $V$ 是有限维的且 $\varphi$ 是 $V$ 上的线性泛函，则存在唯一的向量 $u \in V$ 使得对每个 $v \in V$ 均有 $\varphi(v) = \langle v, u \rangle$.

证明 先证明存在向量  $ u \in V $ 使得对每个  $ v \in V $ 均有  $ \varphi(v) = \langle v, u \rangle $。设  $ e_1, \ldots, e_n $ 是  $ V $ 的规范正交基，则对每个  $ v \in V $ 均有

 $$ \begin{align*}\varphi(\nu)&=\varphi(\langle\nu,e_{1}\rangle e_{1}+\cdots+\langle\nu,e_{n}\rangle e_{n})\\&=\langle\nu,e_{1}\rangle\varphi(e_{1})+\cdots+\langle\nu,e_{n}\rangle\varphi(e_{n})\\&=\langle\nu,\overline{\varphi(e_{1})}e_{1}+\cdots+\overline{\varphi(e_{n})}e_{n}\rangle,\end{align*} $$ 

其中第一个等式由 6.30 得到．因此，取

6.43

 $$ u=\overline{\varphi(e_{1})}e_{1}+\cdots+\overline{\varphi(e_{n})}e_{n}, $$ 

则对每个  $ \nu \in V $ 都有  $ \varphi(\nu) = \langle \nu, u \rangle $.

现在来证明只有一个向量  $ u \in V $ 满足条件．设  $ u_1, u_2 \in V $ 使得对每个  $ v \in V $ 均有

 $$ \varphi(\nu)=\langle\nu,u_{1}\rangle=\langle\nu,u_{2}\rangle. $$ 