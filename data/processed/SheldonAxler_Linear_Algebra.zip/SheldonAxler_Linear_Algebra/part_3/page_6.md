15 设  $ C_{\mathbf{R}}([-1,1]) $ 是区间  $ [-1,1] $ 上的实值连续函数构成的向量空间，其上的内积为：对于  $ f, g \in C_{\mathbf{R}}([-1,1]) $

 $$ \langle f,g\rangle=\int_{-1}^{1}f(x)g(x)\mathrm{d}x. $$ 

设  $ \varphi $ 是  $ C_{\mathbf{R}}([-1,1]) $ 上由  $ \varphi(f) = f(0) $ 定义的线性泛函．证明：不存在  $ g \in C_{\mathbf{R}}([-1,1]) $ 能使得对每个  $ f \in C_{\mathbf{R}}([-1,1]) $ 均有  $ \varphi(f) = \langle f, g \rangle $．

本题表明如果不对 V 和  $ \varphi $ 附加额外条件，那么里斯表示定理 6.42 对无限维限量空间不成立.

16 设  $ \mathbf{F} = \mathbf{C} $， $ V $ 是有限维的， $ T \in \mathcal{L}(V) $， $ T $ 的所有本征值的绝对值都小于 1， $ \epsilon > 0 $。证明存在正整数  $ m $ 使得对每个  $ \nu \in V $ 均有  $ \|T^m \nu\| \leq \epsilon \|v\| $。

17 对于  $ u \in V $ 设  $ \Phi u $ 表示  $ V $ 上如下定义的线性泛函：对  $ \nu \in V $

 $$ (\Phi u)(\nu)=\langle\nu,u\rangle. $$ 

(a) 证明：若  $ \mathbf{F} = \mathbf{R} $，则  $ \Phi $ 是从 V 到  $ V' $ 的线性映射。（回想一下，在 3.F 节中我们定义  $ V' = \mathcal{L}(V, \mathbf{F}) $， $ V' $ 称为 V 的对偶空间。）

(b) 证明：若 F = C 且  $ V \neq \{0\} $，则  $ \Phi $ 不是线性映射.

(c) 证明  $ \Phi $ 是单的.

(d) 设 F = R 且 V 是有限维的．利用 (a) 和 (c) 以及维数计算（但不用 6.42）来证明  $ \Phi $ 是从 V 到  $ V' $ 的同构.

(d) 给出了里斯表示定理 6.42 在  $ \mathbf{F} = \mathbf{R} $ 情形的另一个证明，也给出了有限维实内积空间到其对偶空间的一个自然同构（“自然”的意思是与基的选取无关）.

### 6. C 正交补与极小化问题

正交补

6.45 定义 正交补（orthogonal complement）， $ U^{\perp} $

设 U 是 V 的子集，则 U 的正交补（记作  $ U^{\perp} $）是由 V 中与 U 的每个向量都正交的那些向量组成的集合：

 $$ U^{\perp}=\left\{\nu\in V: 对每个 u\in U 均有 \langle\nu,u\rangle=0\right\}. $$ 

例如，若 U 是  $ R^{3} $ 中的直线，则  $ U^{\perp} $ 是垂直于 U 且包含原点的平面。若 U 是  $ R^{3} $ 中的平面，则  $ U^{\perp} $ 是垂直于 U 且包含原点的直线。