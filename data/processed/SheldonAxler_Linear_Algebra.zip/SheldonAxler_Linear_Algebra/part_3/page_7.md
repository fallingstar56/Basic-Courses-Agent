### 6.46 正交补的基本性质

(a) 若 U 是 V 的子集，则  $ U^{\perp} $ 是 V 的子空间.

(b)  $ \{0\}^{\perp} = V $.

(c)  $  V^{\perp} = \{0\}  $.

(d) 若 U 是 V 的子集，则  $ U \cap U^{\perp} \subset \{0\} $.

(e) 若 U 和 W 均为 V 的子集且  $ U \subset W $，则  $ W^{\perp} \subset U^{\perp} $.

## 证明

(a) 设 U 是 V 的子集．则对每个  $ u \in U $ 均有  $ \langle 0, u \rangle = 0 $，于是  $ 0 \in U^{\perp} $

设  $ \nu, w \in U^\perp $。若  $ u \in U $，则

 $$ \left\langle\boldsymbol{v}+\boldsymbol{w},\boldsymbol{u}\right\rangle=\left\langle\boldsymbol{v},\boldsymbol{u}\right\rangle+\left\langle\boldsymbol{w},\boldsymbol{u}\right\rangle=0+0=0. $$ 

于是  $ v + w \in U^{\perp} $ 。也就是说  $ U^{\perp} $ 在加法下是封闭的。

类似地，设  $ \lambda \in \mathbf{F} $ 且  $ \nu \in U^\perp $。若  $ u \in U $，则

 $$ \langle\lambda\nu,u\rangle=\lambda\langle\nu,u\rangle=\lambda\cdot0=0. $$ 

于是  $ \lambda v \in U^\perp $。也就是说  $ U^\perp $ 在标量乘法下是封闭的。因此  $ U^\perp $ 是  $ V $ 的子空间。

(b) 假定  $ v \in V $. 则  $ \langle v, 0 \rangle = 0 $, 这表明  $ v \in \{0\}^\perp $. 于是  $ \{0\}^\perp = V $.

(c) 设  $ \nu \in V^\perp $. 则  $ \langle \nu, \nu \rangle = 0 $, 这表明  $ \nu = 0 $. 于是  $ V^\perp = \{0\} $.

(d) 设 $U$ 是 $V$ 的子集且 $\nu \in U \cap U^\perp$. 则 $\langle \nu, \nu \rangle = 0$, 这表明 $\nu = 0$. 于是 $U \cap U^\perp \subset \{0\}$.

(e) 设 $U$ 和 $W$ 均为 $V$ 的子集且 $U \subset W$. 设 $\nu \in W^\perp$. 则对每个 $u \in W$ 均有 $\langle \nu, u \rangle = 0$, 这表明对每个 $u \in U$ 均有 $\langle \nu, u \rangle = 0$. 所以 $\nu \in U^\perp$. 因此 $W^\perp \subset U^\perp$.

回想一下，若 U 和 W 均为 V 的子空间，并且 V 中每个元素都可以唯一地写成 U 中的一个向量与 W 中的一个向量的和，则 V 是 U 和 W 的直和（记为  $ V = U \oplus W $）（见 1.40）.

以下定理表明，V 的每个有限维子空间都导致了 V 的一个自然的直和分解.

### 6.47 子空间与其正交补的直和

设 U 是 V 的有限维子空间，则  $ V = U \oplus U^{\perp} $.

证明 首先证明

6.48

 $$ V=U+U^{\perp}. $$ 

为此，设  $ v \in V $，并设  $ e_1, \ldots, e_m $ 是  $ U $ 的规范正交基．显然

6.49

 $$ \nu=\underbrace{\langle\nu,e_{1}\rangle e_{1}+\cdots+\langle\nu,e_{m}\rangle e_{m}}_{u}+\underbrace{\nu-\langle\nu,e_{1}\rangle e_{1}-\cdots-\langle\nu,e_{m}\rangle e_{m}}_{w}. $$ 