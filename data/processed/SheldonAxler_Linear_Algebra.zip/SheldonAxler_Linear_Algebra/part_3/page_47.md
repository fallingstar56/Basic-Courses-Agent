证明 设  $ v \in \text{null}(T - \lambda I)^{\text{dim}} V $。由定义可知  $ v \in G(\lambda, T) $。因此我们有  $ G(\lambda, T) \supset \text{null}(T - \lambda I)^{\text{dim}} V $。

反过来，设  $ v \in G(\lambda, T) $。则存在正整数  $ j $ 使得

 $$ \nu\in\mathrm{n u l l}(T-\lambda I)^{j}. $$ 

由 8.2 和 8.4（用  $  (T - \lambda I)  $ 代替  $  T  $）得到  $  v \in \text{null}(T - \lambda I)^{\text{dim}} V  $。因此  $  G(\lambda, T) \subset \text{null}(T - \lambda I)^{\text{dim}} V  $。

8.12 例 定义  $ T \in \mathcal{L}(\mathbf{C}^3) $ 为

 $$ T(z_{1},z_{2},z_{3})=(4z_{2},0,5z_{3}). $$ 

(a) 求 T 的所有本征值及相应的本征空间和相应的广义本征空间.

(b) 证明  $ C^{3} $ 等于 T 的相应于不同本征值的广义本征空间的直和.

(a) 由本征值的定义可知，$T$ 的本征值是 $0$ 和 $5$。容易看到，相应的本征空间是 $E(0,T) = \{(z_1,0,0) : z_1 \in \mathbf{C}\}$ 和 $E(5,T) = \{(0,0,z_3) : z_3 \in \mathbf{C}\}$。

注意到，这个算子 $T$ 没有足够的本征向量来张成它的定义域 $\mathbf{C}^3$。

对于所有的 $z_1,z_2,z_3 \in \mathbf{C}$ 都有 $T^3(z_1,z_2,z_3) = (0,0,125z_3)$。于是由 $8.11$ 可得 $G(0,T) = \{(z_1,z_2,0) : z_1,z_2 \in \mathbf{C}\}$。

我们有 $(T - 5I)^3(z_1,z_2,z_3) = (-125z_1 + 300z_2, -125z_2,0)$。于是由 $8.11$ 可得 $G(5,T) = \{(0,0,z_3) : z_3 \in \mathbf{C}\}$。

(b) (a) 的结果表明  $  \mathbf{C}^{3} = G(0, T) \oplus G(5, T)  $.

本章的主要目标之一是证明上面例子中(b)的结果对有限维复向量空间上的算子总是成立的．我们将在8.21中给出证明．

我们以前在 5.10 中看到相应于不同本征值的本征向量线性无关．现在我们对广义本征向量证明类似的结果．

### 8.13 线性无关的广义本征向量

设  $ T \in \mathcal{L}(V) $,  $ \lambda_1, \ldots, \lambda_m $ 是 T 的所有不同的本征值， $ v_1, \ldots, v_m $ 分别为相应的广义本征向量. 则  $ v_1, \ldots, v_m $ 线性无关.

证明 设  $ a_{1},\ldots,a_{m} $ 是复数，且满足

### 8.14 

 $$ 0=a_{1}\nu_{1}+\cdots+a_{m}\nu_{m}. $$ 

令 k 是使得  $ (T - \lambda_{1}I)^{k}v_{1} \neq 0 $ 成立的最大非负整数．令

 $$ w=(T-\lambda_{1}I)^{k}v_{1}. $$ 