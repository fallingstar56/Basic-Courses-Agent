由极分解定理 7.45 可知，有等距同构  $ S \in \mathcal{L}(V) $ 使得  $ T = S\sqrt{T^*T} $。把  $ S $ 作用到上面的等式两端，则对每个  $ v \in V $ 均有

 $$ T\nu=s_{1}\langle\nu,e_{1}\rangle S e_{1}+\cdots+s_{n}\langle\nu,e_{n}\rangle S e_{n}. $$ 

对每个 $j$ 设 $f_j = Se_j$。因为 $S$ 是等距同构，所以 $f_1, \ldots, f_n$ 是 $V$ 的规范正交基（见 7.42）。上面的等式现在变成对每个 $v \in V$ 均有

 $$ T\nu=s_{1}\langle\nu,e_{1}\rangle f_{1}+\cdots+s_{n}\langle\nu,e_{n}\rangle f_{n}. $$ 

我们在研究从一个向量空间到另一个向量空间的线性映射时，讨论了线性映射关于第一个向量空间的基和第二个向量空间的基的矩阵．在研究算子（即从一个向量空间到其自身的线性映射）时，我们几乎总是让同一个基扮演这两种角色．

奇异值分解给了我们一个难得的机会——对算子的矩阵同时用到两个不同的基。为此，设  $ T \in \mathcal{L}(V) $。设  $ s_1, \ldots, s_n $ 为  $ T $ 的所有奇异值， $ e_1, \ldots, e_n $ 和  $ f_1, \ldots, f_n $ 都是  $ V $ 的规范正交基使得奇异值分解 7.51 成立。因为对每个  $ j $ 均有  $ Te_j = s_j f_j $，所以

 $$ \mathcal{M}\big(T,(e_{1},\ldots,e_{n}),(f_{1},\ldots,f_{n})\big)=\left(\begin{array}{c c c}{s_{1}}&{}&{0}\\ {}&{\ddots}&{}\\ {}&{}&{s_{n}}\\ {0}&{}&{}\\ \end{array}\right). $$ 

也就是说，只要允许我们在处理算子时使用两个不同的基，而不是像通常那样只使用单独的一个基，那么 V 上每个算子关于 V 的某些规范正交基都有对角矩阵.

奇异值和奇异值分解有很多应用（习题中给出了一些），包括在计算线性代数中的应用．为了计算算子 T 的奇异值的数值近似值，首先计算  $ T^{*}T $，然后计算  $ T^{*}T $ 的近似本征值（计算正算子的近似本征值有很好的技术）． $ T^{*}T $ 的这些（近似）本征值的非负平方根就是 T 的（近似）奇异值．也就是说，无需计算  $ T^{*}T $ 的平方根就能得出 T 的近似奇异值．以下命题有助于解释采用  $ T^{*}T $ 而不采用  $ \sqrt{T^{*}T} $ 的合理性．

### 7.52 不对算子开平方描述其奇异值

设  $ T \in \mathcal{L}(V) $。则  $ T $ 的奇异值是  $ T^*T $ 的本征值的非负平方根，且每个本征值  $ \lambda $ 要重复  $ \dim E(\lambda, T^*T) $ 次。

证明 谱定理表明有规范正交基  $ e_1, \ldots, e_n $ 和非负数  $ \lambda_1, \ldots, \lambda_n $ 使得对  $ j = 1, \ldots, n $ 均有  $ T^*Te_j = \lambda_j e_j $。易见，对  $ j = 1, \ldots, n $ 均有  $ \sqrt{T^*T}e_j = \sqrt{\lambda_j}e_j $，这就得到了想要证明的结果。

### 习题 7.D

1 取定  $ u, x \in V $，其中  $ u \neq 0 $。定义  $ T \in \mathcal{L}(V) $ 如下：对每个  $ v \in V $ 有  $ Tv = \langle v, u \rangle x $。证明：对每个  $ v \in V $ 有  $ \sqrt{T^*Tv} = \frac{\|x\|}{\|u\|} \langle v, u \rangle u $。

2 找出一个  $ T \in \mathcal{L}(\mathbf{C}^2) $ 使得 0 是 T 仅有的本征值且 T 的奇异值是 5, 0.