证明 如前所述，可设 V 是实内积空间．设  $ n = \dim V $．取  $ v \in V $ 使得  $ v \neq 0 $．则

 $$ v,T v,T^{2}v,\ldots,T^{n}v $$ 

不可能是线性无关的，这是因为 V 是 n 维的，而这里有  $ n+1 $ 个向量。于是，有不全为 0 的实数  $ a_{0}, \ldots, a_{n} $ 使得

 $$ \begin{align*}0=a_0\nu+a_1T\nu+\cdots+a_nT^n\nu.\end{align*} $$ 

以这些 $ a_{j} $为系数作一个多项式，并将此多项式分解成（参见4.17）

 $$ \begin{align*}a_{0}+a_{1}x+\cdots+a_{n}x^{n}\\&=c(x^{2}+b_{1}x+c_{1})\cdots(x^{2}+b_{M}x+c_{M})(x-\lambda_{1})\cdots(x-\lambda_{m}),\end{align*} $$ 

其中 c 是非零实数，每个  $ b_{j}, c_{j}, \lambda_{j} $ 都是实的，每个  $ b_{j}^{2} $ 小于  $ 4c_{j}, m + M \geq 1 $，并且上面的等式对所有实的 x 都成立．那么我们有

 $$ \begin{aligned}&0=a_{0}\nu+a_{1}T\nu+\cdots+a_{n}T^{n}\nu\\&=(a_{0}I+a_{1}T+\cdots+a_{n}T^{n})\nu\\&=c(T^{2}+b_{1}T+c_{1}I)\cdots(T^{2}+b_{M}T+c_{M}I)(T-\lambda_{1}I)\cdots(T-\lambda_{m}I)\nu.\\ \end{aligned} $$ 

由 7.26，每个  $ T^{2} + b_{j}T + c_{j}I $ 都是可逆的．而  $ c \neq 0 $．所以上面的等式表明 m > 0 且

 $$ 0=(T-\lambda_{1}I)\cdots(T-\lambda_{m}I)v. $$ 

所以至少有一个 j 使得  $ T - \lambda_{j} I $ 不是单的．也就是说 T 有本征值．

下面的引理表明，若 U 是 V 的在自伴算子 T 下不变的子空间，则  $ U^{\perp} $ 也在 T 下不变．我们以后会证明 “T 是自伴的” 这一假设可以换成更弱的假设 “T 是正规的”（参见 9.30）.

### 7.28 自伴算子与不变子空间

设  $ T \in \mathcal{L}(V) $ 是自伴的，并设 U 是 V 的在 T 下不变的子空间．则

(a) $ U^{\perp} $ 在 T 下不变;

(b)  $ T|_{U} \in \mathcal{L}(U) $ 是自伴的；

(c)  $ T|_{U^\perp} \in \mathcal{L}(U^\perp) $ 是自伴的.

证明 为证明 (a)，设  $ v \in U^{\perp} $， $ u \in U $。则

 $$ \langle T\nu,u\rangle=\langle\nu,T u\rangle=0, $$ 

其中第一个等号成立是因为  $ T $ 是自伴的，第二个等号成立是因为  $ U $ 在  $ T $ 下不变（从而  $ Tu \in U $）以及  $ \nu \in U^\perp $。因为上面的等式对每个  $ u \in U $ 都成立，所以可得  $ Tv \in U^\perp $。因此  $ U^\perp $ 在  $ T $ 下不变，这就证明了 (a)。

为证明 (b)，注意到若  $ u, v \in U $ 则