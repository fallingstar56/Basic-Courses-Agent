现在假设 (d) 成立，即有 V 上的自伴算子 R 使得  $ T = R^{2} $ 。那么  $ T = R^{*} R $ （因为  $ R^{*} = R $），所以 (e) 成立。

最后，假设(e)成立. 设  $ R \in \mathcal{L}(V) $ 使得  $ T = R^* R $，则  $ T^* = (R^* R)^* = R^*(R^*)^* = R^* R = T $，所以 T 是自伴的. 为证明(a)成立，注意到对每个  $ v \in V $ 均有

 $$ \langle T\nu,\nu\rangle=\langle R^{*}R\nu,\nu\rangle=\langle R\nu,R\nu\rangle\geq0. $$ 

于是 T 是正的.

每个非负数都有唯一的非负平方根．以下命题表明正算子也具有类似的性质．

有的数学家采用半正定算子这个术语，意思与正算子相同.



### 7.36 每个正算子都有唯一的正平方根

V 上每个正算子都有唯一的正平方根.

证明 设  $ T \in \mathcal{L}(V) $ 是正的， $ v \in V $ 是  $ T $ 的一个本征向量．则有  $ \lambda \geq 0 $ 使得  $ T v = \lambda v $．

设 R 是 T 的正平方根．往证  $ R\nu = \sqrt{\lambda}\nu $ ，这将意味着 R 在 T 的本征向量上是唯一确定的．因为 V 有一个由 T 的本征向量构成的基（由谱定理），这意味着 R 是唯一确定的．

正算子可能有无穷多个平方根（尽管其中只有一个是正的）。例如，若  $ \dim V > 1 $，则 V 上的恒等算子就有无穷多个平方根。



为证明  $ Rv = \sqrt{\lambda v} $，注意谱定理是说 V 有一个由 R 的本征向量构成的规范正交基  $ e_1, \ldots, e_n $。因为 R 是正算子，所以其本征值都是非负的。因此存在非负数  $ \lambda_1, \ldots, \lambda_n $ 使得对每个  $ j = 1, \ldots, n $ 均有  $ Re_j = \sqrt{\lambda_j} e_j $。

因为  $ e_1, \ldots, e_n $ 是  $ V $ 的基，所以有  $ a_1, \ldots, a_n \in \mathbb{F}^i $ 使得

 $$ \nu=a_{1}e_{1}+\cdots+a_{n}e_{n}. $$ 

于是

 $$ R v=a_{1}\sqrt{\lambda_{1}}e_{1}+\cdots+a_{n}\sqrt{\lambda_{n}}e_{n}, $$ 

因此

 $$ R^{2}\nu=a_{1}\lambda_{1}e_{1}+\cdots+a_{n}\lambda_{n}e_{n}. $$ 

而  $ R^{2}=T $ 且  $ Tv=\lambda v $ 。所以上式表明

 $$ a_{1}\lambda e_{1}+\cdots+a_{n}\lambda e_{n}=a_{1}\lambda_{1}e_{1}+\cdots+a_{n}\lambda_{n}e_{n}. $$ 

上式意味着对  $ j=1,\ldots,n $ 有  $ a_{j}(\lambda-\lambda_{j})=0 $ 。所以

 $$ v=\sum_{\{j:\lambda_{j}=\lambda\}}a_{j}e_{j}, $$ 

于是

 $$ R v=\sum_{\{j:\lambda_{j}=\lambda\}}a_{j}\sqrt{\lambda}e_{j}=\sqrt{\lambda}v. $$ 