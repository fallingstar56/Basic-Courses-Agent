7.8 定义 共轭转置（conjugate transpose）

 $ m \times n $ 矩阵的共轭转置是先互换行和列，然后再对每个元素取复共轭得到的  $ n \times m $ 矩阵.

7.9 例 矩阵  $ \begin{pmatrix} 2 & 3 + 4i & 7 \\ 6 & 5 & 8i \end{pmatrix} $

的共轭转置是矩阵

若 F = R，则矩阵的共轭转置等于转置，即通过互换行和列所得到的矩阵.

 $$ \left(\begin{array}{cc}{2}&{6}\\ {3 - 4i}&{5}\\ {7}&{-8i} \end{array}\right). $$ 

以下命题说明了怎样通过 T 的矩阵来计算  $ T^{*} $ 的矩阵.

注意：下面的结果只能对规范正交基使用，而对于非规范正交基， $ T^{*} $ 的矩阵未必等于 T 的矩阵的共轭转置.

线性映射的伴随与基的选取无关.

这解释了为什么本书强调线性映射

的伴随而不是矩阵的共轭转置.



### 7.10 $ T^{*} $ 的矩阵

设  $ T \in \mathcal{L}(V, W) $. 假设  $ e_1, \ldots, e_n $ 是  $ V $ 的规范正交基， $ f_1, \ldots, f_m $ 是  $ W $ 的规范正交基. 则  $ \mathcal{M}(T^*, (f_1, \ldots, f_m), (e_1, \ldots, e_n)) $ 是  $ \mathcal{M}(T, (e_1, \ldots, e_n), (f_1, \ldots, f_m)) $ 的共轭转置.

证明 在本证明中，用  $ \mathcal{M}(T) $ 代替更长的记号  $ \mathcal{M}(T,(e_1,\ldots,e_n),(f_1,\ldots,f_m)) $，用  $ \mathcal{M}(T^*) $ 代替  $ \mathcal{M}(T^*,(f_1,\ldots,f_m),(e_1,\ldots,e_n)) $。

回想一下，把  $ Te_{k} $ 写成这些  $ f_{j} $ 的线性组合可得  $ \mathcal{M}(T) $ 的第 k 列，在这个线性组合中用到的标量组成了  $ \mathcal{M}(T) $ 的第 k 列．因为  $ f_{1}, \ldots, f_{m} $ 是 W 的规范正交基，所以我们知道怎样把  $ Te_{k} $ 写成这些  $ f_{j} $ 的线性组合（见 6.30）：

 $$ T e_{k}=\langle T e_{k},f_{1}\rangle f_{1}+\cdots+\langle T e_{k},f_{m}\rangle f_{m}. $$ 

于是  $ \mathcal{M}(T) $ 中第 j 行第 k 列的元素是  $ \langle Te_k, f_j \rangle $.

把 T 替换成  $ T^{*} $，再互换诸 e 和诸 f 的角色，由此可得， $ \mathcal{M}(T^{*}) $ 中第 j 行第 k 列的元素是  $ \langle T^{*}f_{k},e_{j}\rangle $，它等于  $ \langle f_{k},Te_{j}\rangle $，这等于  $ \overline{\langle Te_{j},f_{k}\rangle} $，这又等于  $ \mathcal{M}(T) $ 中第 k 行第 j 列元素的复共轭．也就是说， $ \mathcal{M}(T^{*}) $ 是  $ \mathcal{M}(T) $ 的共轭转置．

## 自伴算子

现在我们将注意力转移向内积空间上的算子．因此我们将关注 V 到 V 的线性映射（回想一下这样的线性映射称为算子），而不是 V 到 W 的线性映射．