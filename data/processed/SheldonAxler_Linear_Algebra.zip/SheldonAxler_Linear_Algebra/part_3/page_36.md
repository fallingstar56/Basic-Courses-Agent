4 设  $ T \in \mathcal{L}(V, W) $. 证明： $ T^*T $ 是  $ V $ 上的正算子， $ TT^* $ 是  $ W $ 上的正算子.

5 证明 V 上两个正算子的和是正算子.

6 设  $ T \in \mathcal{L}(V) $ 是正算子．证明：对每个正整数  $ k $， $ T^k $ 是正算子．

7 设 T 是 V 上的正算子．证明：T 是可逆的当且仅当对每个满足  $ v \neq 0 $ 的  $ v \in V $ 均有  $ \langle T v, v \rangle > 0 $．

8 设  $ T \in \mathcal{L}(V) $. 对  $ u, v \in V $ 定义  $ \langle u, v \rangle_T $ 为  $ \langle u, v \rangle_T = \langle Tu, v \rangle $. 证明： $ \langle \cdot, \cdot \rangle_T $ 是  $ V $ 上的内积当且仅当  $ T $ 是（关于原内积  $ \langle \cdot, \cdot \rangle $ 的）可逆正算子.

9 证明或反驳： $ F^{2} $ 上的恒等算子有无穷多个自伴的平方根.

10 设  $ S \in \mathcal{L}(V) $. 证明以下条件等价:

(a) S 是等距同构;

(b) 对所有  $ u, v \in V $ 均有  $ \langle S^{*} u, S^{*} v \rangle = \langle u, v \rangle $;

(c) 对 V 中的每个规范正交组  $ e_{1}, \ldots, e_{m} $ 均有  $ S^{*} e_{1}, \ldots, S^{*} e_{m} $ 是规范正交组；

(d) 对 V 中的某个规范正交基  $ e_{1}, \ldots, e_{n} $ 有  $ S^{*}e_{1}, \ldots, S^{*}e_{n} $ 是规范正交基.

11 设  $ T_{1}, T_{2} $ 均为  $ \mathcal{L}(\mathbf{F}^{3}) $ 上的正规算子且两个算子的本征值均为 2, 5, 7. 证明：存在等距同构  $ S \in \mathcal{L}(\mathbf{F}^{3}) $ 使得  $ T_{1} = S^{*}T_{2}S $.

12 找出两个自伴算子  $ T_{1}, T_{2} \in \mathcal{L}(\mathbf{F}^{4}) $ 使得它们的本征值均为 2, 5, 7，但不存在等距同构  $ S \in \mathcal{L}(\mathbf{F}^{4}) $ 使得  $ T_{1} = S^{*}T_{2}S $。一定要解释为什么不存在满足条件的等距同构。

13 证明或给出反例：若  $ S \in \mathcal{L}(V) $ 且存在  $ V $ 的规范正交基  $ e_1, \ldots, e_n $ 使得对每个  $ e_j $ 均有  $ \|Se_j\| = 1 $，则  $ S $ 是等距同构。

14 设 T 是 7.A 节习题 21 的二阶导数算子．证明 -T 是正算子.

### 7. D 极分解与奇异值分解

## 极分解

回想一下我们在 C 和  $ \mathcal{L}(V) $ 之间做的类比．按照这个类比，一个复数 z 相应于一个算子 T，而  $ \bar{z} $ 相应于  $ T^{*} $．实数  $ (z = \bar{z}) $ 相应于自伴算子  $ (T = T^{*}) $，而非负数相应于正算子（一个不太恰当的称谓）．

C 的另一个重要的子集是单位圆，它由所有满足  $ |z|=1 $ 的复数 z 组成．条件  $ |z|=1 $ 等价于  $ \bar{z}z=1 $．按照我们的类比，这相应于条件  $ T^{*}T=I $，等价于 T 是等距同构（参见 7.42）．也就是说，C 中的单位圆相应于全体等距同构．

继续我们的类比，注意到每个非零复数 z 都可以写成

 $$ z=\left(\frac{z}{|z|}\right)|z|=\left(\frac{z}{|z|}\right)\sqrt{\bar{z}z} $$ 