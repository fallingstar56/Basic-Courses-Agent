7.49 定义 奇异值（singular values）

设  $ T \in \mathcal{L}(V) $. 则 T 的奇异值就是  $ \sqrt{T^*T} $ 的本征值，而且每个本征值  $ \lambda $ 都要重复  $ \dim E(\lambda, \sqrt{T^*T}) $ 次.

因为 T 的奇异值都是正算子  $ \sqrt{T^{*}T} $ 的本征值，所以它们都非负.

7.50 例 定义  $ T \in \mathcal{L}(\mathbf{F}^4) $ 为

 $$ T(z_{1},z_{2},z_{3},z_{4})=(0,3z_{1},2z_{2},-3z_{4}). $$ 

求 T 的奇异值.

解 计算表明  $ T^{*}T(z_{1},z_{2},z_{3},z_{4})=(9z_{1},4z_{2},0,9z_{4}) $ （请自行验证）。于是

 $$ \sqrt{T^{*}T}(z_{1},z_{2},z_{3},z_{4})=(3z_{1},2z_{2},0,3z_{4}), $$ 

从而  $ \sqrt{T^{*}T} $ 的本征值为 3, 2, 0，且

 $$ \dim E(3,\sqrt{T^{*}T})=2,\dim E(2,\sqrt{T^{*}T})=1,\dim E(0,\sqrt{T^{*}T})=1. $$ 

所以 T 的奇异值为 3, 3, 2, 0.

注意 -3 和 0 是 T 仅有的本征值. 在这种情形下, 本征值并不包含 T 的定义中用到的数 2, 但是奇异值包含了 2.

把谱定理和 5.41（尤其是 5.41(e)）用于正算子（因此也是自伴算子） $ \sqrt{T^*T} $ 可知，每个  $ T \in \mathcal{L}(V) $ 都有 dim V 个奇异值．例如，在四维向量空间  $ F^4 $ 上，例 7.50 中定义的算子 T 有四个奇异值（如前所见，它们是 3,3,2,0）．

以下命题表明，利用奇异值和 V 的两个规范正交基，V 上的每个算子都有一个简洁的描述.

### 7.51 奇异值分解

设  $ T \in \mathcal{L}(V) $ 有奇异值  $ s_1, \ldots, s_n $。则  $ V $ 有两个规范正交基  $ e_1, \ldots, e_n $ 和  $ f_1, \ldots, f_n $ 使得对每个  $ v \in V $ 均有  $ Tv = s_1 \langle v, e_1 \rangle f_1 + \cdots + s_n \langle v, e_n \rangle f_n $。

证明 对  $ \sqrt{T^{*}T} $ 应用谱定理可知，有 V 的规范正交基  $ e_{1},\ldots,e_{n} $ 使得对  $ j=1,\ldots,n $ 均有  $ \sqrt{T^{*}T}e_{j}=s_{j}e_{j} $.

对每个  $ \nu \in V $ 均有

 $$ \nu=\langle\nu,e_{1}\rangle e_{1}+\cdots+\langle\nu,e_{n}\rangle e_{n} $$ 

（见 6.30）。把  $ \sqrt{T*T} $ 作用到这个等式的两端，则对每个  $ v \in V $ 均有

 $$ \begin{array}{r}{\sqrt{T^{*}T}\nu=s_{1}\langle\nu,e_{1}\rangle e_{1}+\dots+s_{n}\langle\nu,e_{n}\rangle e_{n}.}\end{array} $$ 