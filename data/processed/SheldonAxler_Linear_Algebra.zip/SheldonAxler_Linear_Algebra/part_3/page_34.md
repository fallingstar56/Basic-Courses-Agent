### 7.42 等距同构的刻画

设  $ S \in \mathcal{L}(V) $。则以下条件等价：

(a) S 是等距同构;

(b) 对所有  $ u, v \in V $ 均有  $ \langle Su, Sv \rangle = \langle u, v \rangle $;

(c) 对 V 中的任意规范正交向量组  $ e_{1}, \ldots, e_{n} $ 均有  $ Se_{1}, \ldots, Se_{n} $ 是规范正交的；

(d) V 有规范正交基  $ e_{1}, \ldots, e_{n} $ 使得  $ Se_{1}, \ldots, Se_{n} $ 是规范正交的；

(e)  $ S^{*}S = I; $

(f)  $ SS^{*}=I; $

(g)  $ S^{*} $ 是等距同构；

(h) S 是可逆的且  $ S^{-1} = S^{*} $

证明 首先假设 (a) 成立，即 S 是等距同构。6.A 节的习题 19 和习题 20 证明了内积可通过范数来计算。由于 S 保范数，所以 S 保内积，故 (b) 成立。更确切地，若 V 是实内积空间，则对任意  $ u, v \in V $ 有

 $$ \begin{align*}\langle S u,S\nu\rangle&=(\|S u+S\nu\|^{2}-\|S u-S\nu\|^{2})/4\\&=(\|S(u+\nu)\|^{2}-\|S(u-\nu)\|^{2})/4\\&=(\|u+\nu\|^{2}-\|u-\nu\|^{2})/4\\&=\langle u,\nu\rangle,\end{align*} $$ 

其中第一个等式可以由 6.A 节的习题 19 推出，第二个等式可以由 S 的线性推出，第三个等式成立是因为 S 是等距同构，而最后的等式也是由 6.A 节的习题 19 推出．若 V 是复内积空间，则由 6.A 节的习题 20 代替习题 19 可以得到同样的结论．无论哪种情况，都有 (b) 成立.

现在假设 (b) 成立，即 S 保内积．设  $ e_{1}, \ldots, e_{n} $ 是 V 中的一个规范正交向量组．则由  $ \langle S e_{j}, S e_{k} \rangle = \langle e_{j}, e_{k} \rangle $ 知组  $ S e_{1}, \ldots, S e_{n} $ 是规范正交的．因此 (c) 成立．

显然(c)蕴涵(d).

现在假设 (d) 成立. 设  $ e_{1}, \ldots, e_{n} $ 是 V 的规范正交基使得  $ Se_{1}, \ldots, Se_{n} $ 是规范正交的. 则对  $ j, k = 1, \ldots, n $ 有

 $$ \langle S^{*}S e_{j},e_{k}\rangle=\langle e_{j},e_{k}\rangle $$ 

（这是因为左端等于  $ \langle Se_j, Se_k \rangle $，而  $ (Se_1, \ldots, Se_n) $ 是规范正交的）。所有的向量  $ u, v \in V $ 都可以写成  $ e_1, \ldots, e_n $ 的线性组合，因此上式表明  $ \langle S^*Su, v \rangle = \langle u, v \rangle $。所以  $ S^*S = I $，也就是说 (e) 成立。

现在假设(e)成立，即  $ S^{*}S = I $ 。一般地，算子 S 未必与  $ S^{*} $ 交换。然而， $ S^{*}S = I $ 当且仅当  $ SS^{*} = I $ ，这是 3.D 节习题 10 的一个特殊情形。因此  $ SS^{*} = I $ ，这证明了 (f) 成立。