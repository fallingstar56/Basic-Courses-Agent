### 8. A 广义本征向量和幂零算子

## 算子幂的零空间

本章先来讨论算子幂的零空间.

### 8.2 递增的零空间序列

设  $ T \in \mathcal{L}(V) $. 则

 $$ \left\{0\right\}=\mathrm{n u l l}T^{0}\subset\mathrm{n u l l}T^{1}\subset\cdots\subset\mathrm{n u l l}T^{k}\subset\mathrm{n u l l}T^{k+1}\subset\cdots. $$ 

证明 设 $k$ 是非负整数，$v \in \text{null} T^k$。则 $T^k v = 0$，因此 $T^{k+1} v = T(T^k v) = T(0) = 0$。于是 $v \in \text{null} T^{k+1}$。因此 $\text{null} T^k \subset \text{null} T^{k+1}$。

下面的命题是说，如果在这个子空间序列中有相邻的两项相等，那么此后的所有项都相等.

### 8.3 零空间序列中的等式

设  $ T \in \mathcal{L}(V) $，设  $ m $ 是非负整数使得  $ \text{null} T^m = \text{null} T^{m+1} $。则

 $$ \mathrm{n u l l}T^{m}=\mathrm{n u l l}T^{m+1}=\mathrm{n u l l}T^{m+2}=\mathrm{n u l l}T^{m+3}=\cdots. $$ 

证明 设 k 是正整数. 往证

 $$ \mathrm{n u l l}T^{m+k}=\mathrm{n u l l}T^{m+k+1}. $$ 

由 8.2 我们已经知道 null  $ T^{m+k} \subset \text{null} T^{m+k+1} $.

要证明另一个方向的包含关系，设  $ v \in \text{null} T^{m+k+1} $，则

 $$ T^{m+1}(T^{k}v)=T^{m+k+1}v=0. $$ 

因此

 $$ T^{k}\nu\in\mathrm{n u l l}T^{m+1}=\mathrm{n u l l}T^{m}. $$ 

于是  $ T^{m+k}v = T^m(T^kv) = 0 $，从而  $ v \in \text{null}T^{m+k} $。这意味着  $ \text{null}T^{m+k+1} \subset \text{null}T^{m+k} $。

上面的命题引出一个问题：是否有非负整数 m 使得  $ null T^m = null T^{m+1} $？以下命题表明，这个等式至少在 m 等于 T 的定义域的维数时成立。

### 8.4 零空间停止增长

设  $ T \in \mathcal{L}(V) $。令  $ n = \dim V $。则

 $$ \mathrm{n u l l}T^{n}=\mathrm{n u l l}T^{n+1}=\mathrm{n u l l}T^{n+2}=\cdots. $$ 

证明 因为 8.3，我们只需证明 null  $ T^{n} = \text{null} T^{n+1} $．假设不然，则由 8.2 和 8.3 得

 $$ \left\{0\right\}=\mathrm{n u l l}T^{0}\subsetneq\mathrm{n u l l}T^{1}\subsetneq\cdots\subsetneq\mathrm{n u l l}T^{n}\subsetneq\mathrm{n u l l}T^{n+1}, $$ 