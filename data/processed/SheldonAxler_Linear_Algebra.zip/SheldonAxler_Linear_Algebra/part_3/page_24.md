16 设  $ T \in \mathcal{L}(V) $ 是正规的．证明 range  $ T = \text{range} T^{*} $

17 设  $ T \in \mathcal{L}(V) $ 是正规的．证明：对每个正整数 k 均有

 $$  null T^{k}=null T\quad 且 \quad range T^{k}=range T. $$ 

18 证明或给出反例：若  $ T \in \mathcal{L}(V) $ 且  $ V $ 有规范正交基  $ e_1, \ldots, e_n $ 使得对每个  $ j $ 均有  $ \|Te_j\| = \|T^* e_j\| $，那么  $ T $ 是正规的。

19 设  $ T \in \mathcal{L}(\mathbf{C}^{3}) $ 是正规的且  $ T(1,1,1) = (2,2,2) $. 设  $ (z_{1}, z_{2}, z_{3}) \in \text{null} T $. 证明  $ z_{1} + z_{2} + z_{3} = 0 $.

20 设  $ T \in \mathcal{L}(V, W) $ 且  $ \mathbf{F} = \mathbf{R} $。设  $ \Phi_V $ 是 6.B 节习题 17 中给出的从  $ V $ 到对偶空间  $ V' $ 的那个同构，并设  $ \Phi_W $ 是从  $ W $ 到  $ W' $ 的类似的同构。证明：如果我们通过  $ \Phi_V $ 和  $ \Phi_W $ 将  $ V $ 和  $ W $ 等同于  $ V' $ 和  $ W' $，那么  $ T^* $ 等同于对偶映射  $ T' $。更确切地，证明  $ \Phi_V \circ T^* = T' \circ \Phi_W $。

21 取定正整数 n.  $ [-\pi, \pi] $ 上的实值连续函数按内积

 $$ \langle f,g\rangle=\int_{-\pi}^{\pi}f(x)g(x)\mathrm{d}x $$ 

构成内积空间，在这个内积空间中设

 $$ V=\operatorname{span}(1,\cos x,\cos2x,\cdots,\cos nx,\sin x,\sin2x,\cdots,\sin nx). $$ 

(a) 定义  $ D \in \mathcal{L}(V) $ 为  $ Df = f' $. 证明  $ D^{*} = -D $. 由此得出如下结论：D 是正规的但不是自伴的.

(b) 定义  $ T \in \mathcal{L}(V) $ 为  $ Tf = f'' $. 证明 T 是自伴的.

### 7. B 谱定理

回想一下，对角矩阵是对角线之外的元素都是 0 的方阵；V 上的算子关于某个基有对角矩阵当且仅当这个基是由该算子的本征向量组成的（参见 5.41）.

关于 V 的某个规范正交基具有对角矩阵的算子是 V 上最好的算子，它们恰好是具有如下性质的算子  $ T \in \mathcal{L}(V) $：V 有一个由 T 的本征向量组成的规范正交基。本节的目的是证明谱定理。谱定理表明：具有上述性质的算子当  $ \mathbf{F} = \mathbf{C} $ 时恰为正规算子，当  $ \mathbf{F} = \mathbf{R} $ 时恰为自伴算子。谱定理可能是研究内积空间上算子的最有用的工具。

因为谱定理的结论依赖于 F，所以我们把谱定理分成两部分，分别叫做复谱定理和实谱定理．同线性代数中的大多数情形一样，处理复向量空间要比处理实向量空间容易，因此我们先给出复谱定理.

## 复谱定理

复谱定理 7.24 主要是说，若  $ \mathbf{F} = \mathbf{C} $ 且  $ T \in \mathcal{L}(V) $ 是正规的，则 T 关于 V 的某个规范正交基具有对角矩阵．下面的例子解释了这个结论．