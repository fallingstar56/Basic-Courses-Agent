(e) 由 (c) 可知  $ U^\perp \subset \text{null} P_U $。为了证明另一个方向的包含关系，注意若  $ v \in \text{null} P_U $ 则 6.47 中给出的分解一定是  $ v = 0 + v $，其中  $ 0 \in U $ 且  $ v \in U^\perp $。因此  $ \text{null} P_U \subset U^\perp $。

(f) 若  $ v = u + w $，其中  $ u \in U $ 且  $ w \in U^{\perp} $，则

 $$ \nu-P_{U}\nu=\nu-u=w\in U^{\perp}. $$ 

(g) 若  $ v = u + w $，其中  $ u \in U $ 且  $ w \in U^{\perp} $，则

 $$ (P_{U}{}^{2})\nu=P_{U}(P_{U}\nu)=P_{U}u=u=P_{U}\nu. $$ 

(h) 若  $ \nu = u + w $，其中  $ u \in U $ 且  $ w \in U^\perp $，则

 $$ \|P_{U}\nu\|^{2}=\|u\|^{2}\leq\|u\|^{2}+\|w\|^{2}=\|\nu\|^{2}, $$ 

这里最后一个等号是根据勾股定理.

(i) 利用定理 6.47 证明中的等式 6.49 可得  $ P_{U}v $ 的公式.

## 极小化问题

经常会遇到这样的问题：给定 V 的子空间 U 和点  $ v \in V $，求点  $ u \in U $ 使得  $ \|v - u\| $ 最小。下面的命题表明，通过取  $ u = P_{UV} $ 就可以解决这个极小化问题。

极小化问题的求解非常简单，这导致了内积空间在纯数学之外的很多重要应用。



### 6.56 到子空间的最小距离

设 U 是 V 的有限维子空间， $ v \in V $ 且  $ u \in U $。则

 $$ \left\|\nu-P_{U}\nu\right\|\leq\left\|\nu-u\right\|. $$ 

进一步，等号成立当且仅当  $ u = P_{U}v $.

证明 我们有

6.57

 $$ \begin{align*}\|\nu-P_{U}\nu\|^{2}&\leq\|\nu-P_{U}\nu\|^{2}+\|P_{U}\nu-u\|^{2}\\&=\|(\nu-P_{U}\nu)+(P_{U}\nu-u)\|^{2}\\&=\|\nu-u\|^{2},\end{align*} $$ 

其中第一行成立是由于  $ 0 \leq \|P_{U}v - u\|^2 $，第二行是利用勾股定理（可以这样用是因为由 6.55(f) 知  $ v - P_{U}v \in U^\perp $，而且我们还有  $ P_{U}v - u \in U $），第三行成立是简单的计算。再开方即得要证的不等式。

等号成立当且仅当 6.57 是等式，当且仅当  $ \|P_{U}v-u\|=0 $，当且仅当  $ u=P_{U}v $。

<div style="text-align: center;"><img src="imgs/img_in_image_box_561_979_818_1284.jpg" alt="Image" width="28%" /></div>


<div style="text-align: center;"> $ P_{UV} $ 是 U 中距离 v 最近的点</div>
