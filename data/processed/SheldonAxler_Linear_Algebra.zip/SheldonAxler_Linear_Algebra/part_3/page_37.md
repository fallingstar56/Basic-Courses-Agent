的形式，其中第一个因子（即  $ z/|z| $）是单位圆中的元素。这种的类比使我们猜到，任何算子  $ T \in \mathcal{L}(V) $ 都可以写成等距同构乘以  $ \sqrt{T \cdot T} $ 的形式。我们现在就来证明这个猜测确实是对的，在此之前先定义一个显然的记号，其合理性由 7.36 保证。

7.44 记号  $ \sqrt{T} $

若 T 是正算子，则用  $ \sqrt{T} $ 表示 T 的唯一的正平方根.

现在我们来陈述和证明极分解定理，它给出  $ V $ 上任意算子的一个漂亮的描述。注意对每个  $ T \in \mathcal{L}(V) $， $ T^*T $ 都是正算子，所以  $ \sqrt{T^*T} $ 定义合理。

### 7.45 极分解

设  $ T \in \mathcal{L}(V) $. 则有一个等距同构  $ S \in \mathcal{L}(V) $ 使得  $ T = S\sqrt{T^*T} $.

证明 若  $ v \in V $，则

 $$ \begin{align*}\|T\nu\|^{2}=\langle T\nu,T\nu\rangle&=\langle T^{*}T\nu,\nu\rangle\\&=\langle\sqrt{T^{*}T}\sqrt{T^{*}T}\nu,\nu\rangle\\&=\langle\sqrt{T^{*}T}\nu,\sqrt{T^{*}T}\nu\rangle\\&=\|\sqrt{T^{*}T}\nu\|^{2}.\end{align*} $$ 

于是对所有  $ \nu \in V $ 均有

### 7.46 

 $$ \|T\nu\|=\|\sqrt{T^{*}T}\nu\|. $$ 

定义线性映射  $ S_1 $：range  $ \sqrt{T^*T} \rightarrow $ range  $ T $ 为

7.47

 $$ S_{1}(\sqrt{T^{*}T}\nu)=T\nu. $$ 

证明的思路是把  $ S_1 $ 扩张成一个等距同构  $ S \in \mathcal{L}(V) $ 使得  $ T = S\sqrt{T^*T} $。现在来看具体证明。

首先必须验证  $ S_{1} $ 的定义是合理的。为此，假设  $ v_{1}, v_{2} \in V $ 使得  $ \sqrt{T^{*}T}v_{1} = \sqrt{T^{*}T}v_{2} $。为使 7.47 给出的定义有意义，我们必须证明  $ Tv_{1} = Tv_{2} $。注意

 $$ \begin{aligned}\|T\nu_{1}-T\nu_{2}\|&=\|T(\nu_{1}-\nu_{2})\|\\&=\|\sqrt{T^{*}\boldsymbol{T}}(\nu_{1}-\nu_{2})\|\\&=\|\sqrt{T^{*}\boldsymbol{T}}\nu_{1}-\sqrt{T^{*}\boldsymbol{T}}\nu_{2}\|\\&=0,\end{aligned} $$ 

其中第二个等式成立是由于 7.46. 上式证明了  $ Tv_{1}=Tv_{2} $，所以  $ S_{1} $ 的确是定义合理的. 请自行验证  $ S_{1} $ 是线性映射.

由 7.47 可知  $ S_1 $ 把 range  $ \sqrt{T^*T} $ 映到 range  $ T $ 上．显然，由 7.46 和 7.47 可知，对所有  $ u \in \text{range} \sqrt{T^*T} $ 都有  $ \|S_1u\| = \|u\| $．