分配性质，distributive property, 3, 11, 14, 44, 62

符号函数，signum, 236

复共轭，complex conjugate, 92

复化，complexification

算子的，of an operator, 210

向量空间的，of a vector space, 209

复谱定理，Complex Spectral Theorem, 164

复数，complex number, 2

复数的除法，division of complex numbers, 4

复数的减法，subtraction of complex numbers, 4

复向量空间，complex vector space, 11

高斯，卡尔·弗里德里希，Gauss, Carl

Friedrich, 40

格拉姆-施密特过程，Gram-Schmidt

Procedure, 138

格拉姆，约根，Gram, Jørgen, 138

共轭对称性，conjugate symmetry, 126

勾股定理，Pythagorean Theorem, 129

广义本征空间，generalized eigenspace, 185

广义本征向量，generalized eigenvector, 185

规范正交的，orthonormal

组，list, 136

基，basis, 137

哈尔莫斯，保罗，Halmos, Paul, 23

哈密顿，威廉，Hamilton, William, 197

海亚姆，欧玛尔，Khayyám, Omar, 91

行列式，determinant

矩阵的，of a matrix, 237

算子的，of an operator, 232

核，kernel, 47

和，sum，见加法

恒等映射，identity map, 41, 44

基，basis, 32

本征向量的，of eigenvectors, 119, 169, 202

广义本征向量的，of generalized eigenvectors, 191

基变更，change of basis, 226

积，product

F $ ^{n} $中标量与向量的，of scalar and vector in F $ ^{n} $, 9

复数的，of complex numbers, 2

标量与线性映射的，of scalar and linear map, 43

标量与向量的，of scalar and vector, 10

多项式的，of polynomials, 110

矩阵的，of matrices, 59

线性映射的，of linear maps, 44

向量空间的，of vector spaces, 71

积分，integral, 247

积分中的变量替换，change of variables in integral, 248

迹，trace

矩阵的，of a matrix, 227

算子的，of an operator, 226

极分解，Polar Decomposition, 176

极小多项式，minimal polynomial, 199, 211

极小化距离，minimizing distance, 149

极坐标，polar coordinates, 248

几何重数，geometric multiplicity, 192

加法，addition

F $ ^{n} $中向量的，of vectors in F $ ^{n} $, 6

复数的，of complex numbers, 2

函数的，of functions, 12

矩阵的，of matrices, 57

商空间中的，in quotient space, 75

线性映射的，of linear maps, 43

向量的，of vectors, 10

子空间的，of subspaces, 17

加法封闭，closed under addition, 16

加法逆元，additive inverse

C中的，in C, 3, 4