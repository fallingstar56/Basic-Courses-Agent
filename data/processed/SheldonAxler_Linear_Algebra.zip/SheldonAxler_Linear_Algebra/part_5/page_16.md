 $ F^{n} $ 中的，in  $ F^{n} $，8

向量空间中的，in vector space, 11, 13

加性，additivity, 41

交换性，commutativity, 3, 6, 11, 21, 45, 59, 62, 110, 160

结合性，associativity, 3, 11, 44

矩阵，matrix, 55

T' 的，of T', 85

T* 的，of T*, 157

幂零算子的，of nilpotent operator, 188

算子的，of operator, 111

线性映射的，of linear map, 55

线性映射之积的，of product of linear maps, 59, 225

向量的，of vector, 66

矩阵的乘法，multiplication of matrices, 59

矩阵的共轭转置，conjugate transpose of a matrix, 157

矩阵的列秩，column rank of a matrix, 86

矩阵的行秩，row rank of a matrix, 86

矩阵的秩，rank of a matrix, 87

矩阵的转置，transpose of a matrix, 84, 157

绝对值，absolute value, 92

凯莱-哈密顿定理，Cayley-Hamilton Theorem

实向量空间上的，on real vector space,

215

复向量空间上的，on complex vector space), 197

凯莱，阿瑟，Cayley, Arthur, 197

柯西-施瓦茨不等式，Cauchy-Schwarz Inequality, 130

柯西，奥古斯丁-路易，Cauchy, Augustin-Louis, 130, 239

可对角化，diagonalizable, 119

可逆的，invertible, 224

可逆矩阵，invertible matrix, 224

可逆线性映射，invertible linear map, 63

可微，differentiable, 247

克里斯蒂娜，瑞典女王，Christina, Queen of Sweden, 1



拉普拉斯算子，Laplacian, 135

拉斐尔，Raphael, 208

里斯，弗里杰什，Riesz, Frigyes, 142

里斯表示定理，Riesz Representation

Theorem, 142

列奥纳多（比萨的），Leonardo of Pisa, 101

零空间，null space, 47

 $ T' $ 的，of  $ T' $, 83

 $ T^{*} $ 的，of  $ T^{*} $, 156

算子幂的，of powers of an operator, 183

洛夫莱斯，艾达，Lovelace, Ada, 223

满的，surjective, 49

幂零算子，nilpotent operator, 187, 204

内积，inner product, 126

内积空间，inner product space, 127

逆，inverse

矩阵的，of a matrix, 224

线性映射的，of a linear map, 63

牛顿，艾萨克，Newton, Isaac, 153

欧几里得，Euclid, 208

欧几里得内积，Euclidean inner product, 127

排列，permutation, 235

排列的符号，sign of a permutation, 236

平面国，Flatland, 6

平行的仿射子集，parallel affine subsets, 73

平行四边形恒等式，Parallelogram Equality,

## 132 

谱定理，Spectral Theorem, 164, 167

奇异矩阵，singular matrix, 224

奇异值，singular values, 178

奇异值分解，Singular Value Decomposition,