齐次线性方程组，homogeneous system of linear equations, 52, 70

齐性，homogeneity, 41

球坐标，spherical coordinates, 249

若尔当，卡米耶，Jordan, Camille, 205

若尔当基，Jordan basis, 206

若尔当形，Jordan Form, 206

三次求根公式，cubic formula, 96

三角不等式，Triangle Inequality, 131

商空间，quotient space, 74

商算子，quotient operator, 106

商映射，quotient map, 75

上三角矩阵，upper-triangular matrix, 112, 193

施密特，埃哈德，Schmidt, Erhard, 138

施瓦茨，赫尔曼，Schwarz, Hermann, 130

实部，real part, 92

实谱定理，Real Spectral Theorem, 167

实向量空间，real vector space, 11

首一多项式，monic polynomial, 198

舒尔，逸斋，Schur, Issai, 141

舒尔定理，Schur's Theorem, 141

算子，operator, 68

算子的本征值，eigenvalue of an operator, 103

算子的立方根，cube root of an operator, 168

算子的平方根，square root of an operator, 168, 170, 176, 195

特征多项式，characteristic polynomial  

实向量空间的，on real vector space, 214  

复向量空间上的，on complex vector space, 197  

特征值，characteristic value, 103  

体积，volume, 245  

调和函数，harmonic function, 135

同构，isomorphism, 64

同构的向量空间，isomorphic vector spaces,

64

图片来源，photo credits, 251

微分线性映射，differentiation linear map, 41, 45, 47, 49, 54, 56, 62, 110, 144, 187, 222

维数，dimension, 36

和空间的，of a sum of subspaces, 37

无限维向量空间，infinite-dimensional vector

帕蒂娅，Hypatia, 182

限制算子，restriction operator, 106

线性变换，linear transformation, 41

线性泛函，linear functional, 78, 141

线性无关，linearly independent, 28

线性相关，linearly dependent, 28

线性相关性引理，Linear Dependence Lemma,

## 29 

线性映射，linear map, 41

线性映射的伴随，adjoint of a linear map, 154

线性映射的图，graph of a linear map, 77

线性映射基本定理，Fundamental Theorem of

## Linear Maps, 50

线性张成空间，linear span, 25

线性子空间，linear subspace, 15

线性组合，linear combination, 24

像，image, 49

向后移位，backward shift, 42, 47, 64, 68, 108

向量，vector, 7, 11

向量空间，vector space, 11

向量组，list of vectors, 24

虚部，imaginary part, 92

雅典学院，School of Athens, 208

一对一的，one-to-one, 48

映上，onto, 49

西算子，unitary operator, 172