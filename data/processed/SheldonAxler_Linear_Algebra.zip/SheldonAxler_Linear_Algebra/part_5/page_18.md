有限维向量空间，lim-dimensional vector space, 26

元组，tuple, 5

张成，spans, 25

张成空间，span, 25

正规算子，normal operator, 160, 217

正交补，orthogonal complement, 145

正交算子，orthogonal operator, 172

正交投影，orthogonal projection, 147

正交向量，orthogonal vectors, 129

正算子，positive operator, 169

直和，direct sum, 18, 34, 73

null  $ T^{n} $ 与 range  $ T^{n} $ 的，of null  $ T^{n} $ and range  $ T^{n} $, 184

子空间与其正交补的，of a subspace and its orthogonal complement, 146

值域，range, 48

 $ T' $ 的，of  $ T' $, 83

 $ T^{*} $ 的，of  $ T^{*} $, 156

算子幂的，of powers of an operator, 189

子空间，subspace, 15

子空间的零化子，annihilator of a subspace, 81

自伴算子，self-adjoint operator, 158

组，list, 5

最高法院，Supreme Court, 133

坐标，coordinate, 6