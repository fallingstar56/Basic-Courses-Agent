## 版权声明

Translation from the English language edition:

Linear Algebra Done Right,  $ 3^{rd} $ by Sheldon Axler.

Copyright © Springer International Publishing 2015.

Springer is a part of Springer Science+Business Media.

All Right Reserved.

本书简体中文版由 Springer-Verlag 授权人民邮电出版社独家出版．未经出版者书面许可，不得以任何方式复制或抄袭本书的任何部分．

版权所有，侵权必究。