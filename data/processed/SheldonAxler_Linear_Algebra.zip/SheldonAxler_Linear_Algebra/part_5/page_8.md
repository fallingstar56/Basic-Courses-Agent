以下定义旨在表达积分的思想，而不是要作为一个严格的定义。

### 10.55 定义 积分（integral）， $ \int_{\Omega} f $

设  $ \Omega \subset \mathbb{R}^n $， $ f $ 是  $ \Omega $ 上的实值函数。 $ f $ 在  $ \Omega $ 上的积分（记作  $ \int_{\Omega} f $ 或  $ \int_{\Omega} f(x) \, dx $）定义如下：将  $ \Omega $ 分成足够小的小块使得  $ f $ 在每个小块上几乎是常值函数，在每个小块上用  $ f $ 的值（几乎是常数）乘以这个小块的体积，然后再对所有的小块求和，就得到了积分的一个近似。对  $ \Omega $ 的分块越细，这个近似就越精确。

实际上，上面定义中的  $ \Omega $ 应该是一个适当的集合（例如，开集或可测集），并且 f 也应该是一个适当的函数（例如，连续的或可测的），但我们不必担心这些技术问题．注意  $ \int_{\Omega} f(x) \, dx $ 中的 x 是哑变量，可以换成任何其他符号．

现在我们定义可微和导数的概念．注意，在这个语境下，导数是一个算子，而不像在一元微积分中那样是一个数．以下定义中的T的唯一性留作习题9.

10.56 定义 可微（differentiable）、导数（derivative）， $ \sigma'(x) $

设  $ \Omega $ 是  $ \mathbf{R}^n $ 的开子集， $ \sigma $ 是从  $ \Omega $ 到  $ \mathbf{R}^n $ 的函数。对于  $ x \in \Omega $，称函数  $ \sigma $ 在  $ x $ 点可微，如果存在算子  $ T \in \mathcal{L}(\mathbf{R}^n) $ 使得

 $$ \lim_{y\to0}\frac{\|\sigma(x+y)-\sigma(x)-T y\|}{\|y\|}=0. $$ 

若  $ \sigma $ 在 x 点可微，则称满足上式的唯一的算子  $ T \in \mathcal{L}(\mathbf{R}^n) $ 为  $ \sigma $ 在 x 点的导数，记作  $ \sigma'(x) $.

导数的思想是，对固定的 x 和很小的  $ \|y\| $

 $$ \begin{align*}\sigma(x+y)\approx\sigma(x)+\left(\sigma^{\prime}(x)\right)(y),\end{align*} $$ 

若 n = 1，则上面定义的导数就是一元微积分中通常意义下的导数所诱导的 R 上的算子.

因为  $ \sigma'(x) \in \mathcal{L}(\mathbf{R}^n) $，所以这是有意义的。

设  $ \Omega $ 是  $ R^{n} $ 的开子集， $ \sigma $ 是从  $ \Omega $ 到  $ R^{n} $ 的函数，我们可以写

 $$ \sigma(x)=\left(\sigma_{1}(x),\ldots,\sigma_{n}(x)\right), $$ 

其中每个  $ \sigma_j $ 都是从  $ \Omega $ 到  $ \mathbf{R} $ 的函数.  $ \sigma_j $ 对第  $ k $ 个坐标的偏导数记为  $ D_k \sigma_j $. 求这个偏导数在点  $ x \in \Omega $ 的值得  $ D_k \sigma_j(x) $. 如果  $ \sigma $ 在  $ x $ 点可微, 则  $ \sigma'(x) $ 关于  $ \mathbf{R}^n $ 的标准基的矩阵的第  $ j $ 行第  $ k $ 列元素是  $ D_k \sigma_j(x) $ (留作习题). 也就是说

10.57

 $$ \mathcal{M}\big(\sigma^{\prime}(x)\big)=\left(\begin{array}{c c c}D_{1}\sigma_{1}(x)&\cdots&D_{n}\sigma_{1}(x)\\ \vdots&&\vdots\\ D_{1}\sigma_{n}(x)&\cdots&D_{n}\sigma_{n}(x)\end{array}\right). $$ 

现在可以给出变量替换积分公式. f 和  $ \sigma' $ 还需要一点点额外的假设（如连续性或可测性）. 但我们并不担心这些，因为下面的证明实际上是一个伪证明，意在传递结果正确的原因.