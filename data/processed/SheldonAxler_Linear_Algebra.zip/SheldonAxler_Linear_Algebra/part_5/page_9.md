以下定理称为变量替换公式，因为可以把  $ y = \sigma(x) $ 看成一个变量替换，就像证明后面那两个例子所阐述的那样.

### 10.58 积分中的变量替换

设  $ \Omega $ 是  $ R^n $ 的开子集， $ \sigma: \Omega \to R^n $ 在  $ \Omega $ 的每一点可微， $ f $ 是定义在  $ \sigma(\Omega) $ 上的实值函数。则

 $$ \int_{\sigma(\Omega)}f(y)\mathrm{d}y=\int_{\Omega}f\big(\sigma(x)\big)\big|\det\sigma^{\prime}(x)\big|\mathrm{d}x. $$ 

证明 设  $ x \in \Omega $， $ \Gamma $ 是  $ \Omega $ 的一个包含 x 的小子集，使得在集合  $ \sigma(\Gamma) $ 上 f 约等于常数  $ f(\sigma(x)) $.

把一个集合中的每个向量都加上一个固定的向量（例如  $ \sigma(x) $）可得另一个具有相同体积的集合．利用导数可以给出  $ \sigma $ 在 x 点附近的近似，由此可得

 $$ \mathrm{v o l u m e}\sigma(\Gamma)\approx\mathrm{v o l u m e}\big[\big(\sigma^{\prime}(x)\big)(\Gamma)\big]. $$ 

对算子  $ \sigma'(x) $ 应用 10.54，上式变成

 $$ \mathrm{v o l u m e}\sigma(\Gamma)\approx|\mathrm{d e t}\sigma^{\prime}(x)|(\mathrm{v o l u m e}\Gamma). $$ 

设  $ y = \sigma(x) $ 。上式左端乘以  $ f(y) $，右端乘以  $ f(\sigma(x)) $ （因为  $ y = \sigma(x) $，所以这两个量相等），得到

 $$ f(y)\mathrm{v o l u m e}\sigma(\Gamma)\approx f\big(\sigma(x)\big)\big|\operatorname*{d e t}\sigma^{\prime}(x)\big|(\mathrm{v o l u m e}\Gamma). $$ 

现在把  $ \Omega $ 分成许多小块，并且把上式对应于各小块的那些等式加起来，即得所求.

做变量替换的要点是，在做替换  $ y = f(x) $ 时，一定会包含因子  $ |\det \sigma'(x)| $，就像 10.58 右端那样．最后，通过两个重要的例子来说明这一点.

### 10.59 例 极坐标

定义  $ \sigma: \mathbf{R}^2 \to \mathbf{R}^2 $ 为

 $$ \sigma(r,\theta)=(r\cos\theta,r\sin\theta), $$ 

这里使用  $ r, \theta $ 而不是  $ x_{1}, x_{2} $ 作为坐标，对熟悉极坐标的每个人来说都很显然（而对其他人来说却很神秘）。请自行验证，对于这个  $ \sigma $，相应于 10.57 的偏导数的矩阵是

 $$ \left(\begin{array}{c c}\cos\theta&-r\sin\theta\\ \sin\theta&r\cos\theta\end{array}\right), $$ 

上面这个矩阵的行列式等于 r，这解释了在利用极坐标计算积分时为什么会有一个因子 r.

例如，下式是函数 f 在  $ R^{2} $ 的一个圆盘上的积分，注意那个额外的因子 r:

 $$ \int_{-1}^{1}\int_{-\sqrt{1-x^{2}}}^{\sqrt{1-x^{2}}}f(x,y)\mathrm{d}y\mathrm{d}x=\int_{0}^{2\pi}\int_{0}^{1}f(r\cos\theta,r\sin\theta)r\mathrm{d}r\mathrm{d}\theta. $$ 