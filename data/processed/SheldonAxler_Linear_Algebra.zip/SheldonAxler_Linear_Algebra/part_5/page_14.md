## 索引

 $ R^{n} $ 中的长方体，box in  $ R^{n} $, 244

阿波罗尼奥斯恒等式，Apollonius's Identity, 136

埃尔米特的，Hermitian, 158

半正定算子，positive semidefinite operator,

## 171 

本征空间，eigenspace, 118

本征向量，eigenvector, 104

本征值的重数，multiplicity of an eigenvalue, 191

比内，雅克，Binet, Jacques, 239

标量，scalar, 4

标量乘法，scalar multiplication, 9, 10

矩阵的，of matrices, 57

商空间中的，in quotient space, 75

线性映射的，of linear maps, 43

标量乘法封闭，closed under scalar multiplication, 16

标准基，standard basis, 32

不变子空间，invariant subspace, 102

布莱克，威廉，Blake William, 153

长度，length, 5

乘法，multiplication，见积

乘法逆元，multiplicative inverse

C 中的，in C, 3

代数学基本定理，Fundamental Theorem of Algebra, 96

代数重数，algebraic multiplicity, 192



单的，injective, 48

单位矩阵，identity matrix, 224

导数，derivative, 247

等距同构，isometry, 172, 220, 242

笛卡儿，勒内，Descartes, René, 1

点，point, 11

点积，dot product, 125

对偶，dual

基的，of a basis, 79

线性映射的，of a linear map, 80

向量空间的，of a vector space, 79

多项式，polynomial, 26

多项式的次数，degree of a polynomial, 26

多项式的带余除法，Division Algorithm for

polynomias, 94

多项式的零点，zero of a polynomial, 95

多项式的因式，factor of a polynomial, 95

二次对偶空间，double dual space, 89

范数，norm, 125, 128

方阵的对角线，diagonal of a square matrix, 112

仿射子集，affine subset, 73

斐波那契，Fibonacci, 101

斐波那契序列，Fibonacci sequence, 122

非齐次线性方程组，inhomogeneous system of linear equations, 52, 70

分块对角矩阵，block diagonal matrix, 192