10.50 定义 体积（volume）

设  $ \Omega \subset \mathbb{R}^n $。则  $ \Omega $ 的体积（记作 volume  $ \Omega $）定义为

 $$ \mathrm{volume}B_{1}+\mathrm{volume}B_{2}+\cdots $$ 

的下确界，其中  $ B_{1}, B_{2}, \ldots $ 是长方体序列，其并集包含  $ \Omega $，取遍所有这样的长方体序列.

我们将仅使用直观的体积概念．我们的目的是理解线性代数，而体积的概念属于分析学（不过很快就会看到体积与行列式的紧密联系）．因此，本节其余部分将依赖直观的体积概念，而不依赖其严格的发展，但在接下来的线性代数部分我们还是要保持一贯的严密．如果适当解释，这里关于体积所说的一切都是正确的：这里使用的直观方法都可以运用分析学的手段转化成恰当的正确定义、正确陈述和正确证明．

10.51 记号  $ T(\Omega) $
对定义在集合  $ \Omega $ 上的函数 T，定义  $ T(\Omega) $ 为  $ T(\Omega) = \{T x : x \in \Omega\} $.

对于  $ T \in \mathcal{L}(\mathbf{R}^n) $ 和  $ \Omega \subset \mathbf{R}^n $，我们要利用  $ T $ 和 volume  $ \Omega $ 给出 volume  $ T(\Omega) $ 的公式。先来看看正算子。

10.52 正算子 T 使体积改变了  $ \det T $ 倍

 $$ T\in\mathcal{L}(\mathbf{R}^{n}) $$ 

 $$ \Omega\subset\mathbf{R}^{n} $$ 

 $$ \mathrm{v o l u m e}T(\Omega)=(\mathrm{d e t}T)(\mathrm{v o l u m e}\Omega). $$ 

证明 为了理解这个结果为什么是对的，首先考虑一种特殊情况： $ \lambda_1, \ldots, \lambda_n $ 是正整数， $ T \in \mathcal{L}(\mathbf{R}^n) $ 定义为

 $$ T(x_{1},\cdots,x_{n})=(\lambda_{1}x_{1},\cdots,\lambda_{n}x_{n}). $$ 

这个算子把第 $j$ 个标准基向量拉伸了 $\lambda_j$ 倍．如果 $B$ 是 $\mathbf{R}^n$ 中边长为 $r_1, \ldots, r_n$ 的长方体，则 $T(B)$ 就是 $\mathbf{R}^n$ 中边长为 $\lambda_1 r, \ldots, \lambda_n r$ 的长方体．长方体 $T(B)$ 的体积是 $\lambda_1 \cdots \lambda_n r_1 \cdots r_n$，而长方体 $\Omega$ 的体积是 $r_1 \cdots r_n$．注意到 $\det T = \lambda_1 \cdots \lambda_n$．因此对 $\mathbf{R}^n$ 中的每个长方体 $B$ 都有

 $$ \mathrm{volume}T(B)=(\det T)(\mathrm{volume}B). $$ 

由于  $ \Omega $ 的体积是用长方体体积和来逼近的，从而有

 $$ \mathrm{v o l u m e}T(\Omega)=(\mathrm{d e t}T)(\mathrm{v o l u m e}\Omega). $$ 

现在考虑任意正算子  $ T \in \mathcal{L}(\mathbf{R}^n) $。由实谱定理 7.29， $ \mathbf{R}^n $ 有规范正交基  $ e_1, \ldots, e_n $，并且有非负整数  $ \lambda_1, \ldots, \lambda_n $ 使得对  $ j = 1, \ldots, n $ 有  $ Te_j = \lambda_j e_j $。在  $ e_1, \ldots, e_n $ 是  $ \mathbf{R}^n $ 的标准基的特殊情况下，这个算子与上一段定义的算子是一样的。对任意的规范正交基  $ e_1, \ldots, e_n $，这个算子与上一段那个算子有相同的性质：把规范正交基的第  $ j $ 个基向量拉伸  $ \lambda_j $ 倍。对体积的直觉使我们相信，体积关于每个规范正交基的性质都是一