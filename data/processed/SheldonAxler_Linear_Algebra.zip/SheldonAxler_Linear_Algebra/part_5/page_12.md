## 图片来源

• page 1: Pierre Louis Dumesnil; 1884 copy by Nils Forsberg/Public domain image from Wikimedia.

• page 23: George M. Bergman/Archives of the Mathematisches Forschungsinstitut Oberwolfach.

• page 40: Gottlieb Biermann; photo by A. Wittmann/Public domain image from Wikimedia.

• page 91: Mostafa Azizi/Public domain image from Wikimedia.

• page 101: Hans-Peter Postel/Public domain image from Wikimedia.

• page 124: Public domain image from Wikimedia.

• page 153: Public domain image from Wikimedia. Original painting is in Tate Britain.

• page 169: Spiked Math.

• page 182: Public domain image from Wikimedia.

• page 208: Public domain image from Wikimedia. Original fresco is in the Vatican.

• page 223: Public domain image from Wikimedia.