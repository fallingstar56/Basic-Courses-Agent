 $$ \begin{align*}A_{\cdot,k}=\left(\begin{array}{c}A_{1,k}\\\vdots\\A_{n,k}\end{array}\right).\end{align*} $$ 

要注意，具有两个下标的  $ A_{j,k} $ 表示 A 的一个元素，而具有一个圆点占位符和一个下标的  $ A_{,k} $ 表示 A 的一个列。这个记号使我们可将 A 写成

 $$ \begin{array}{l}(A_{,1}\quad\cdots\quad A_{,n}),\end{array} $$ 

有些教材把行列式定义为方阵的函数，这个函数对每个列都是线性的，并且满足 10.38 和  $ \det I = 1 $。要证明这样的函数存在且唯一需要做大量的工作。

这是非常有用的.

以下定理说明，把矩阵 A 的列重新排列，行列式就变成了 A 的行列式乘以这个排列的符号.

### 10.38 重排矩阵的列

设  $ A = \left( \begin{array}{ccc} A_{,1} & \cdots & A_{,n} \end{array} \right) $ 是  $ n \times n $ 矩阵， $ (m_{1}, \ldots, m_{n}) $ 是一个排列．则

 $$ \det(\boldsymbol{A}_{,m_{1}}\quad\cdots\quad\boldsymbol{A}_{,m_{n}})=\left(\operatorname{sign}(m_{1},\ldots,m_{n})\right)\det\boldsymbol{A}. $$ 

证明 我们可以通过一系列步骤把矩阵 $ (A_{,m_1} \ldots A_{,m_n}) $ 变成 A. 每一步交换两列，根据 10.36，得到的行列式等于前一个行列式乘以 -1. 需要的步骤数等于把排列  $ (m_1, \ldots, m_n) $ 变成排列  $ (1, \ldots, n) $ 需要交换元素的次数. 为完成证明，只需注意到如果  $ (m_1, \ldots, m_n) $ 的符号是 1，则这个次数是偶数；如果  $ (m_1, \ldots, m_n) $ 的符号是 -1，则是这个次数是奇数（根据 10.32，并注意到排列  $ (1, \ldots, n) $ 的符号是 1）.

关于行列式的以下定理也是有用的.

### 10.39 行列式是每一列的线性函数

设 k, n 是满足  $ 1 \leq k \leq n $ 的正整数. 固定除  $ A_{,k} $ 之外的那些  $ n \times 1 $ 矩阵  $ A_{,1}, \ldots, A_{,n} $. 则把  $ n \times 1 $ 列向量  $ A_{,k} $ 映为

 $$ \det(\begin{array}{ccc}A,&1&\end{array}\quad\cdots\quad A_{\cdot,k}\quad\cdots\quad A_{\cdot,n}) $$ 

的函数，是从 F 上的  $ n \times 1 $ 矩阵构成的向量空间到 F 的线性映射.

证明 线性由 10.33 易得，因为 10.33 中的每个和项都恰好包含 A 的第 k 列中的一个元素.

我们现在可以证明方阵的行列式的一个重要性质．这个性质使我们能够把算子的行列式和它的矩阵的行列式联系起来．注意，这个证明比关于迹的相应结果的证明复杂得多（参见10.14）.

1812 年法国数学家雅克·比内和奥古斯丁-路易·柯西最早证明了以下定理.

