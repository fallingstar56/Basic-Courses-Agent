7 设  $ A $ 是  $ n \times n $ 实矩阵， $ S \in \mathcal{L}(\mathbf{C}^n) $ 是  $ \mathbf{C}^n $ 上的算子，其矩阵等于  $ A $， $ T \in \mathcal{L}(\mathbf{R}^n) $ 是  $ \mathbf{R}^n $ 上的算子，其矩阵也等于  $ A $。证明：trace  $ S = \text{trace} T $ 且  $ \det S = \det T $。

8 设 V 是内积空间， $ T \in \mathcal{L}(V) $。证明

 $$ \det T^{*}=\overline{\det T}. $$ 

由此证明  $ |\det T| = \det \sqrt{T^*T} $，这给出 10.47 一个不同的证明。

9 设 Ω 是  $ R^n $ 的开子集，σ 是从 Ω 到  $ R^n $ 的函数， $ x \in \Omega $ 且 σ 在  $ x $ 点可微．证明：满足 10.56 中等式的算子  $ T \in \mathcal{L}(R^n) $ 是唯一的．

本题表明记号  $ \sigma'(x) $ 是合理的.

10 设  $ T \in \mathcal{L}(\mathbf{R}^n) $， $ x \in \mathbf{R}^n $。证明：T 在 x 点可微且  $ T'(x) = T $。

11 找出  $ \sigma $ 的一个适当的假设，然后证明 10.57.

12 设  $ a, b, c $ 是正数．找出一个已知体积的集合  $ \Omega \subset \mathbb{R}^3 $ 和一个算子  $ T \in \mathcal{L}(\mathbb{R}^3) $ 使得  $ T(\Omega) $ 等于椭球

 $$ \left\{(x,y,z)\in\mathbf{R}^{3}:\frac{x^{2}}{a^{2}}+\frac{y^{2}}{b^{2}}+\frac{z^{2}}{c^{2}}<1\right\}, $$ 

并求上述椭球的体积.