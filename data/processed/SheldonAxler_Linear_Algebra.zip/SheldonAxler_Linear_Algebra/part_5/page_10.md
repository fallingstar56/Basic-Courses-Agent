10.60 例 球坐标

定义  $ \sigma: \mathbf{R}^3 \to \mathbf{R}^3 $ 为

 $$ \sigma(\rho,\varphi,\theta)=(\rho\sin\varphi\cos\theta,\rho\sin\varphi\sin\theta,\rho\cos\varphi), $$ 

这里使用  $ \rho,\theta,\varphi $ 而不是  $ x_{1},x_{2},x_{3} $ 作为坐标，对熟悉极坐标的每个人来说都很显然（而对其他人来说却很神秘）。请自行验证，对于这个  $ \sigma $，相应于 10.57 的偏导数的矩阵是

 $$ \begin{pmatrix}\sin\varphi\cos\theta&\rho\cos\varphi\cos\theta&-\rho\sin\varphi\sin\theta\\\sin\varphi\sin\theta&\rho\cos\varphi\sin\theta&\rho\sin\varphi\cos\theta\\\cos\varphi&-\rho\sin\varphi&0\end{pmatrix}, $$ 

上面这个矩阵的行列式等于  $ \rho^{2}\sin\varphi $，这解释了在利用球坐标计算积分时为什么会有一个因子  $ \rho^{2}\sin\varphi $。

例如，下式是函数  $ f $ 在  $ \mathbb{R}^3 $ 的一个球上的积分，注意那个额外的因子  $ \rho^2 \sin \varphi $：

 $$ \begin{aligned}&\int_{-1}^{1}\int_{-\sqrt{1-x^{2}}}^{\sqrt{1-x^{2}}}\int_{-\sqrt{1-x^{2}-y^{2}}}^{\sqrt{1-x^{2}-y^{2}}}f(x,y,z)\mathrm{d}z\mathrm{d}y\mathrm{d}x\\ &=\int_{0}^{2\pi}\int_{0}^{\pi}\int_{0}^{1}f(\rho\sin\varphi\cos\theta,\rho\sin\varphi\sin\theta,\rho\cos\varphi)\rho^{2}\sin\varphi\mathrm{d}\rho\mathrm{d}\varphi\mathrm{d}\theta.\\ \end{aligned} $$ 

### 习题 10.B

1 设 V 是实向量空间， $ T \in \mathcal{L}(V) $ 没有本征值．证明  $ \det T > 0 $．

2 设  $ V $ 是偶数维的实向量空间， $ T \in \mathcal{L}(V) $， $ \det T < 0 $。证明  $ T $ 至少有两个不同的本征值。

3 设  $ T \in \mathcal{L}(V) $， $ n = \dim V > 2 $。令  $ \lambda_1, \ldots, \lambda_n $ 是  $ T $ 的（或  $ T_C $ 的，如果  $ V $ 是实向量空间）按重数重复的全体本征值。

(a) 求 T 的特征多项式中  $ z^{n-2} $ 的系数关于  $ \lambda_{1}, \ldots, \lambda_{n} $ 的公式.

(b) 求 T 的特征多项式中 z 的系数关于  $ \lambda_{1}, \ldots, \lambda_{n} $ 的公式.

4 设  $ T \in \mathcal{L}(V) $， $ c \in \mathbf{F} $。证明  $ \det(cT) = c^{\dim V} \det T $。

5 证明或给出反例：若  $ S, T \in \mathcal{L}(V) $ 则  $ \det(S + T) = \det S + \det T $.

6 设 A 是分块上三角矩阵

 $$ \boldsymbol{A}=\left(\begin{array}{ccc}A_{1}&&*\\&\ddots&\\&&A_{m}\\\end{array}\right), $$ 

对角线上的每个  $ A_{j} $ 都是方阵．证明  $ \det A = (\det A_{1}) \cdots (\det A_{m}) $