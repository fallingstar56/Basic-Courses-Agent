### 10.40 行列式是可乘的

若 A 和 B 是大小相同的方阵，则  $ \det(AB) = \det(BA) = (\det A)(\det B) $.

证明 令  $ A = \left( \begin{array}{ccc} A_{,1} & \cdots & A_{,n} \end{array} \right) $，其中每个  $ A_{,k} $ 都是 A 的一个  $ n \times 1 $ 的列。令

 $$ \boldsymbol{B}=\left(\begin{array}{ccc}B_{1,1}&\cdots&B_{1,n}\\\vdots&&\vdots\\B_{n,1}&\cdots&B_{n,n}\\\end{array}\right)=\left(\begin{array}{ccc}B_{\cdot,1}&\cdots&B_{\cdot,n}\\\end{array}\right), $$ 

其中每个  $ B_{,k} $ 是 B 的一个  $ n \times 1 $ 的列．令  $ e_{k} $ 表示第 k 行的元素等于 1 其余元素都等于 0 的  $ n \times 1 $ 矩阵．注意到  $ Ae_{k} = A_{,k} $， $ Be_{k} = B_{,k} $．进而有  $ B_{,k} = \sum_{m=1}^{n} B_{m,k} e_{m} $．

首先证明  $ \det(AB)=(\det A)(\det B) $. 容易看到（参见 3.49），由矩阵乘法的定义可得  $ AB=(AB_{.1}\quad\ldots\quad AB_{.n}) $. 因此

 $$ \begin{aligned}\det(AB)&=\det(\begin{array}{cccc}A&B&1&\cdots&A B_{-,n}\end{array})\\&=\det(\begin{array}{cccc}A(\sum_{m_{1}=1}^{n}B_{m_{1},1}e_{m_{1}})&\cdots&A(\sum_{m_{n}=1}^{n}B_{m_{n},n}e_{m_{n}})\end{array})\\&=\det(\begin{array}{cccc}\sum_{m_{1}=1}^{n}B_{m_{1},1}A e_{m_{1}}&\cdots&\sum_{m_{n}=1}^{n}B_{m_{n},n}A e_{m_{n}}\end{array})\\&=\sum_{m_{1}=1}^{n}\cdots\sum_{m_{n}=1}^{n}B_{m_{1},1}\cdots B_{m_{n},n}\det(\begin{array}{cccc}A e_{m_{1}}&\cdots&A e_{m_{n}}\end{array}),\end{aligned} $$ 

其中最后一个等式是反复利用了  $ \det $ 作为每一列的函数的线性（10.39）。在上面的最后一个求和式中，存在某个  $ j \neq k $ 使得  $ m_j = m_k $ 的所有项都可以忽略，因为具有两个相同列的矩阵的行列式等于 0（由于 10.37）。因此我们不需要对  $ m_1, \ldots, m_n $ 的所有取值求和，只需对使得这些  $ m_j $ 具有不同值的排列求和，其中每个  $ m_j $ 都取值于  $ 1, \ldots, n $。也就是说

 $$ \begin{aligned}\det(AB)&=\sum_{(m_{1},\ldots,m_{n})\in\mathrm{perm}n}B_{m_{1},1}\cdots B_{m_{n},n}\det(\begin{array}{ccc}A e_{m_{1}}&\cdots&A e_{m_{n}}\end{array})\\&=\sum_{(m_{1},\ldots,m_{n})\in\mathrm{perm}n}B_{m_{1},1}\cdots B_{m_{n},n}\left(\mathrm{sign}(m_{1},\ldots,m_{n})\right)\det A\\&=(\det A)\sum_{(m_{1},\ldots,m_{n})\in\mathrm{perm}n}\left(\mathrm{sign}(m_{1},\ldots,m_{n})\right)B_{m_{1},1}\cdots B_{m_{n},n}\\&=(\det A)(\det B),\end{aligned} $$ 

其中第二个等式由 10.38 得到.

上一段证明了  $ \det(AB) = (\det A)(\det B) $. 交换 A 和 B 的角色得  $ \det(BA) = (\det B)(\det A) $，即  $ \det(BA) = (\det A)(\det B) $.