样的．这种直觉连同上一段的特殊情形告诉我们，T 把体积改变了  $ \lambda_{1} \cdots \lambda_{n} $ 倍，即  $ \det T $ 倍．

下一个工具是以下定理，它说的是等距同构不改变体积.

10.53 等距同构不改变体积
设  $ S \in \mathcal{L}(\mathbf{R}^n) $ 是等距同构， $ \Omega \subset \mathbf{R}^n $。则 volume  $ S(\Omega) = \text{volume} \Omega $。

证明 对  $ x, y \in \mathbb{R}^n $ 有

 $$ \left\| \mathbf{S} \mathbf{x}-\mathbf{S} \mathbf{y} \right\|= \left\| \mathbf{S}(x-y) \right\|= \left\| \mathbf{x}-\mathbf{y} \right\|. $$ 

也就是说 S 不改变两点之间的距离．仅这个性质就足以使我们确信 S 不改变体积.

但是，如果需要更强的说服力，考虑9.36给出的实内积空间上等距同构的完整描述．按照9.36，S可被分解成一些片段，每个片段或者是某个子空间上的恒等映射（它显然不改变体积），或者是某个子空间上的乘以-1映射（它显然也不改变体积），或者是二维子空间上的一个旋转（它还是不改变体积）．也可以用9.36连同9.B节的习题7将S写成算子之积，其中每一个算子都不改变体积．不论哪种方式都能使我们确信S不改变体积．

现在可以证明算子  $ T \in \mathcal{L}(\mathbf{R}^n) $ 使体积改变了  $ |\det T| $ 倍．注意，极分解定理对证明极为重要．

10.54 $T$ 使体积改变 $|det T|$ 倍

设 $T \in \mathcal{L}(\mathbf{R}^n)$, $\Omega \subset \mathbf{R}^n$. 则 volume $T(\Omega) = |det T|(\text{volume } \Omega)$.

证明 由极分解定理 7.45，存在等距同构  $ S \in \mathcal{L}(V) $ 使得

 $$ T=S\sqrt{T^{*}T}. $$ 

若  $ \Omega \subset \mathbb{R}^n $，则  $ T(\Omega) = S\left(\sqrt{T^*T}(\Omega)\right) $。因此

 $$ \begin{aligned}volume T(\Omega)&=volume S\big(\sqrt{T^{*}}T(\Omega)\big)\\&=volume\sqrt{T^{*}}T(\Omega)\\&=(det\sqrt{T^{*}}T)(volume\Omega)\\&=|det T|(volume\Omega),\end{aligned} $$ 

第二个等式成立是因为等距同构 S 不改变体积（参见 10.53），第三个等式成立是根据 10.52（应用于正算子  $ \sqrt{T*T} $），第四个等式成立是根据 10.47.

上述定理导致了行列式出现在重积分的变量替换公式中．我们仍将含糊而直观地描述一下．

本书中我们遇到的几乎所有的函数都是线性的．请注意在下面的材料中并未假设函数 f 和  $ \sigma $ 是线性的.