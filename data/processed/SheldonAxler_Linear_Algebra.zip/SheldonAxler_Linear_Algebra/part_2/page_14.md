虽然 nullT 和 rangeT 都在 T 下不变，但是这并未为是否存在异于  $ \{0\} $ 和 V 的不变子空间这一问题提供简单答案，这是因为，nullT 可能等于  $ \{0\} $，而 rangeT 可能等于 V（当 T 可逆时，就是这样）.

5.4 例 设  $ T \in \mathcal{L}(\mathcal{P}(\mathbf{R})) $ 定义为  $ Tp = p' $。则  $ \mathcal{P}(\mathbf{R}) $ 的子空间  $ \mathcal{P}_4(\mathbf{R}) $ 在  $ T $ 下不变，因为若  $ p \in \mathcal{P}(\mathbf{R}) $ 的次数不超过 4 则  $ p' $ 的次数也不超过 4。

## 本征值与本征向量

我们以后还会回过头来更深入地研究不变子空间．现在先来研究最简单的非平凡不变子空间——一维不变子空间.

任取  $ v \in V $， $ v \neq 0 $，并设  $ U $ 是  $ v $ 的标量倍构成的集合：

 $$ U=\left\{\lambda\nu:\lambda\in\mathbf{F}\right\}=\operatorname{s p a n}(\nu). $$ 

则 $U$ 是 $V$ 的一维子空间（而且 $V$ 的每个一维子空间都具有这种形式）。若 $U$ 在算子 $T \in \mathcal{L}(V)$ 下不变，则 $T v \in U$，因此必有标量 $\lambda \in \mathbf{F}$ 使得 $T v = \lambda v$。

反之，若有某个  $ \lambda \in \mathbb{F} $ 使得  $ T\nu = \lambda\nu $，则  $ \text{span}(\nu) $ 是  $ V $ 的在  $ T $ 下不变的一维子空间。

我们刚才见过的那个方程

 $$ T\nu=\lambda\nu $$ 

与一维不变子空间密切相关，十分重要．满足此方程的向量 v 和标量  $ \lambda $ 都有一个特殊的名字．

### 5.5 定义 本征值（eigenvalue）

设  $ T \in \mathcal{L}(V) $。称数  $ \lambda \in \mathbf{F} $ 为  $ T $ 的本征值，若存在  $ \nu \in V $ 使得  $ \nu \neq 0 $ 且  $ Tv = \lambda v $。

上面这些解释表明，T 有一维不变子空间当且仅当 T 有本征值.

在上面的定义中，我们要求  $ v \neq 0 $，这是因为每个标量  $ \lambda \in \mathbf{F} $ 都满足  $ T_0 = \lambda_0 $。

eigenvalue 这个词一半是德文，一半是英文。德文形容词 eigen 的意思是“特有的”。有些数学家使用术语特征值而不是本征值。

