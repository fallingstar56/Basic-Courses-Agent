 $$ v,T v,T^{2}v,\ldots,T^{n}v $$ 

线性相关．于是有不全为0的复数 $ a_{0},\ldots,a_{n} $使得

 $$ 0=a_{0}\nu+a_{1}T\nu+\cdots+a_{n}T^{n}\nu. $$ 

注意  $ a_{1},\ldots,a_{n} $ 不全为 0，否则上面等式将变成  $ 0=a_{0}v $，这将使  $ a_{0} $ 也必须是 0.

以这些  $ a_{j} $ 为系数作一个多项式，利用代数学基本定理 4.14 可将此多项式分解成

 $$ a_{0}+a_{1}z+\cdots+a_{n}z^{n}=c(z-\lambda_{1})\cdots(z-\lambda_{m}), $$ 

其中 $c$ 是非零复数，每个 $\lambda_j$ 属于 $\mathbf{C}$，且上面等式对所有 $z \in \mathbf{C}$ 均成立（这里 $m$ 未必等于 $n$，因为 $a_n$ 可能等于 0）。则

 $$ \begin{aligned}0&=a_{0}\nu+a_{1}T\nu+\cdots+a_{n}T^{n}\nu\\&=(a_{0}I+a_{1}T+\cdots+a_{n}T^{n})\nu\\&=c(T-\lambda_{1}I)\cdots(T-\lambda_{m}I)\nu.\end{aligned} $$ 

于是至少有一个 j 使得  $ (T - \lambda_{j}I) $ 不是单的．也就是说，T 有本征值．

上面的证明依赖于代数学基本定理，这是该结果一个典型的证明．此结果的其他证明见习题 16 和习题 17，思路与上面的证明稍有不同.

## 上三角矩阵

在第 3 章我们讨论了从一个向量空间到另一个向量空间的线性映射的矩阵．该矩阵依赖于这两个向量空间的基的选取．既然我们要研究将向量空间映到其自身的算子，要强调的就是现在只使用一个基．

### 5.22 定义 算子的矩阵（matrix of an operator）， $ M(T) $

设  $ T \in \mathcal{L}(V) $，并设  $ v_1, \ldots, v_n $ 是  $ V $ 的基。 $ T $ 关于该基的矩阵定义为  $ n \times n $ 矩阵

 $$ \mathcal{M}(T)=\left(\begin{array}{ccc}A_{1,1}&\cdots&A_{1,n}\\\vdots&&\vdots\\A_{n,1}&\cdots&A_{n,n}\\\end{array}\right), $$ 

其元素  $ A_{j,k} $ 定义为

 $$ T\nu_{k}=A_{1,k}\nu_{1}+\cdots+A_{n,k}\nu_{n}. $$ 

如果基在上下文中不是自明的，则使用记号  $ \mathcal{M}(T, (v_1, \ldots, v_n)) $.

注意算子的矩阵是正方形阵列，而早先考虑的线性映射的矩阵是更一般的长方形阵列.