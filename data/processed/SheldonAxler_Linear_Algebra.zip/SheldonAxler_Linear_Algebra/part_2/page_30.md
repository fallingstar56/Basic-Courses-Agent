证明 为了证明  $ E(\lambda_{1},T)+\cdots+E(\lambda_{m},T) $ 是直和，假设

 $$ u_{1}+\cdots+u_{m}=0, $$ 

其中每个  $ u_{j} $ 含于  $ E(\lambda_{j}, T) $ 。因为相应于不同本征值的本征向量是线性无关的（参见 5.10），所以每个  $ u_{j} $ 均等于 0 。这表明  $ E(\lambda_{1}, T) + \cdots + E(\lambda_{m}, T) $ 是直和（由于 1.44）。现在有

 $$ \dim E(\lambda_{1},T)+\cdots+\dim E(\lambda_{m},T)=\dim\big(E(\lambda_{1},T)\oplus\cdots\oplus E(\lambda_{m},T)\big)\leq\dim V, $$ 

其中的等号由 2.C 节的习题 16 得到.

### 5.39 定义 可对角化（diagonalizable）

算子  $ T \in \mathcal{L}(V) $ 称为可对角化的，如果该算子关于  $ V $ 的某个基有对角矩阵。

5.40 例 定义  $ T \in \mathcal{L}(\mathbf{R}^2) $ 为  $ T(x,y) = (41x + 7y, -20x + 74y) $. T 关于  $ R^2 $ 的标准基的矩阵为

 $$ \left(\begin{array}{cc}{41}&{7}\\ {-20}&{74} \end{array}\right), $$ 

这不是一个对角矩阵．但 T 可对角化，请验证 T 关于基  $ (1,4) $， $ (7,5) $ 的矩阵为

 $$ \left(\begin{array}{cc}{69}&{0}\\ {0}&{46} \end{array}\right). $$ 

### 5.41 可对角化的等价条件

设  $ V $ 是有限维的， $ T \in \mathcal{L}(V) $。用  $ \lambda_1, \ldots, \lambda_m $ 表示  $ T $ 的所有互异的本征值。则下列条件等价：

(a) T 可对角化;

(b) V 有由 T 的本征向量构成的基；

(c) V 有在 T 下不变的一维子空间  $ U_{1}, \ldots, U_{n} $ 使得  $ V = U_{1} \oplus \cdots \oplus U_{n} $;

(d)  $  V = E(\lambda_1, T) \oplus \cdots \oplus E(\lambda_m, T)  $;

(e)  $ \dim V = \dim E(\lambda_1, T) + \cdots + \dim E(\lambda_m, T) $.

证明 算子  $ T \in \mathcal{L}(V) $ 关于  $ V $ 的基  $ v_1, \ldots, v_n $ 有对角矩阵

 $$ \left(\begin{array}{ccc}{{{\lambda_{1}}}}&{{{0}}} \\{{{\ddots}}} \\{{{0}}}&{{{\lambda_{n}}}} \\\end{array}\right) $$ 

当且仅当对每个 j 均有  $ T\nu_{j}=\lambda_{j}\nu_{j} $ 。于是 (a) 和 (b) 等价。