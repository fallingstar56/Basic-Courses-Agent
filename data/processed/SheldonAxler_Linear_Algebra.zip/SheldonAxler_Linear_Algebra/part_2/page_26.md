如何通过观察一个算子的矩阵来确定该算子是否可逆呢？如果我们很幸运地有一个基使得该算子关于这个基的矩阵是上三角的，那么问题就会变得很简单，如下面的命题所示.

### 5.30 由上三角矩阵确定可逆性

设  $ T \in \mathcal{L}(V) $ 关于 V 的某个基有上三角矩阵．则 T 是可逆的当且仅当这个上三角矩阵对角线上的元素都不是 0.

证明 设  $ v_{1},\ldots,v_{n} $ 是 V 的基使得 T 关于这个基具有上三角矩阵

5.31

 $$ \mathcal{M}(T)=\left(\begin{array}{c c c c}\lambda_{1}&&&*\\ &\lambda_{2}&&\\ &&\ddots&\\ 0&&&\lambda_{n}\end{array}\right). $$ 

我们需要证明：T 是可逆的当且仅当所有  $ \lambda_{i} $ 均不为 0.

首先设对角线元素  $ \lambda_1, \ldots, \lambda_n $ 均不为 0. 5.31 中的上三角阵表明  $ T\nu_1 = \lambda_1\nu_1 $. 因为  $ \lambda_1 \neq 0 $，所以  $ T(\nu_1/\lambda_1) = \nu_1 $. 于是  $ \nu_1 \in \text{range} T $.

现在对某个  $ a \in \mathbf{F} $ 有

 $$ T(v_{2}/\lambda_{2})=a v_{1}+v_{2}. $$ 

上式左端以及  $ av_{1} $ 均含于 range T. 于是  $ v_{2} \in \text{range } T $.

类似地，对某个  $ b, c \in \mathbf{F} $ 有

 $$ T(\nu_{3}/\lambda_{3})=b\nu_{1}+c\nu_{2}+\nu_{3}. $$ 

上式左端以及  $ bv_1 $ 和  $ cv_2 $ 均含于 range T. 于是  $ v_3 \in \text{range} T $.

依此类推，可知  $ v_{1}, \ldots, v_{n} \in \text{range} T $。因为  $ v_{1}, \ldots, v_{n} $ 是 V 的基，所以  $ \text{range} T = V $。也就是说 T 是满的。于是 T 是可逆的（由于 3.69）。

现在证明另一个方向，设 T 是可逆的。这表明  $ \lambda_{1} \neq 0 $，否则有  $ Tv_{1} = 0 $。设  $ 1 < j \leq n $， $ \lambda_{j} = 0 $。则 5.31 表明 T 将  $ \operatorname{span}(v_{1}, \ldots, v_{j}) $ 映入  $ \operatorname{span}(v_{1}, \ldots, v_{j-1}) $。由于

 $$ \dim\operatorname{span}(v_{1},\cdots,v_{j})=j\quad 且 \quad\dim\operatorname{span}(v_{1},\cdots,v_{j-1})=j-1, $$ 

这表明 $T$ 限制在 $\operatorname{span}(v_1, \ldots, v_j)$ 上不是单的（由于 3.23）。因此有 $v \in \operatorname{span}(v_1, \ldots, v_j)$ 使得 $v \neq 0$ 且 $Tv = 0$。于是 $T$ 不是单的，这与 $T$ 是可逆的假设相矛盾。这个矛盾表明 $\lambda_j = 0$ 一定不成立。于是 $\lambda_j \neq 0$。

作为上述命题的一个应用，我们看到例 5.23 中的算子是可逆的.

令人遗憾的是，现在还无法利用算子的矩阵来精确计算算子的本征值．但是，如果我们有幸找到一个基使得算子关于这个基的矩阵是利用算子的矩阵，有强大的数值技术来近似计算算子的本征值.



上三角形的，则本征值的计算问题就变得平凡了，如下面的定理所示.