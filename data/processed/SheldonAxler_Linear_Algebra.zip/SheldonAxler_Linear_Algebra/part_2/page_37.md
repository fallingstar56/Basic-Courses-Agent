对于  $  z = (z_1, \ldots, z_n) \in \mathbf{C}^n  $，定义  $  z  $ 的范数为

 $$ \|z\|=\sqrt{|z_{1}|^{2}+\cdots+|z_{n}|^{2}}. $$ 

因为我们希望  $ \|z\| $ 是非负数，所以上式中的绝对值是必要的．注意

 $$ \|z\|^{2}=z_{1}\overline{{z_{1}}}+\cdots+z_{n}\overline{{z_{n}}}. $$ 

我们想把  $ \|z\|^2 $ 看作  $ z $ 与自身的内积，就像在  $ \mathbf{R}^n $ 中一样．因此，上面的等式提示我们， $ w = (w_1, \ldots, w_n) \in \mathbf{C}^n $ 与  $ z $ 的内积应该等于

 $$ w_{1}\overline{z_{1}}+\cdots+w_{n}\overline{z_{n}}. $$ 

要是互换 w 和 z 的角色，上面的表达式就要用它的复共轭来代替．也就是说，w 和 z 的内积应该等于 z 和 w 的内积的复共轭．有了这样的启示，我们现在就可以定义 V 上的内积了，这里 V 可以是实向量空间或者复向量空间.

关于下面定义中记号的两点说明：

- 若  $ \lambda $ 是复数，则记号  $ \lambda \geq 0 $ 表示  $ \lambda $ 是实数并且是非负的.

- 我们使用通用的记号（尖括号） $ \langle u,v\rangle $ 表示内积．有些人使用圆括号，但  $ (u,v) $ 这个记号比较含糊，它既可以表示有序对，又可以表示内积．

6.3 定义 内积（inner product）

V 上的内积就是一个函数，它把 V 中元素的每个有序对  $ (u, v) $ 都映成一个数  $ \langle u, v \rangle \in \mathbf{F} $，并且具有下列性质：

正性（positivity）

对所有  $ v \in V $ 均有  $ \langle v, v \rangle \geq 0 $；

定性（definiteness）

 $ \langle v, v \rangle = 0 $ 当且仅当  $ v = 0 $；

第一个位置的加性（additivity in first slot）

对所有  $ u, v, w \in V $ 均有  $ \langle u + v, w \rangle = \langle u, w \rangle + \langle v, w \rangle $；

第一个位置的齐性（homogeneity in first slot）

对所有  $ \lambda \in \mathbf{F} $ 和所有  $ u, v \in V $ 均有  $ \langle \lambda u, v \rangle = \lambda \langle u, v \rangle $；

共轭对称性（conjugate symmetry）

对所有  $ u, v \in V $ 均有  $ \langle u, v \rangle = \overline{\langle v, u \rangle} $。

虽然大多数数学家按上面的方式定义内积，但是很多物理学家在定义内积时要求的是第二个位置的齐性，而不是第一个位置。

每个实数都等于它的复共轭．因此在处理实向量空间时，可以忽略上面最后一个条件中的复共轭而直接说：对所有  $ u, v \in V $ 均有  $ \langle u, v \rangle = \langle v, u \rangle $．

