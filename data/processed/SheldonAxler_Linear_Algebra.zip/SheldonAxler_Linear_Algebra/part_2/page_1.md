34 定义 V 的二次对偶空间（记为  $ V'' $）为  $ V' $ 的对偶空间．也就是说， $ V'' = (V')' $．

定义  $ \Lambda: V \to V'' $ 如下：对于  $ v \in V $ 和  $ \varphi \in V' $，

 $$ (\Lambda\nu)(\varphi)=\varphi(\nu). $$ 

(a) 证明  $ \Lambda $ 是从 V 到  $ V'' $ 的线性映射.

(b) 证明：若  $ T \in \mathcal{L}(V) $，则  $ T'' \circ \Lambda = \Lambda \circ T $，这里  $ T'' = (T')' $.

(c) 证明：若 V 是有限维的，则  $ \Lambda $ 是 V 到  $ V'' $ 的同构.

设 V 是有限维的．则 V 和  $ V' $ 同构，但是找 V 到  $ V' $ 的同构一般来说需要选择 V 的一个基．相比之下，从 V 到  $ V'' $ 的同构  $ \Lambda $ 并不依赖于基的选取，因此更加自然.

35 证明  $ \left(\mathcal{P}(\mathbf{R})\right)^{\prime} $ 和  $ R^{\infty} $ 是同构的.

36 设 U 是 V 的子空间. 设  $ i: U \to V $ 是由  $ i(u) = u $ 定义的包含映射. 那么  $ i' \in \mathcal{L}(V', U') $.

(a) 证明 null  $ i' = U^{0} $

(b) 证明若 V 是有限维的，则  $ \text{range } i' = U' $.

(c) 证明若 V 是有限维的，则  $ \widetilde{i}' $ 是  $ V' / U^0 $ 到  $ U' $ 的同构.

注意(c) 中的同构并不依赖于其中任何一个向量空间的基的选取，因而是自然的.

37 设 U 是 V 的子空间， $ \pi: V \to V/U $ 是通常的商映射，则  $ \pi' \in \mathcal{L}((V/U)', V') $.

(a) 证明  $ \pi' $ 是单的.

(b) 证明 range  $ \pi' = U^{0} $.

(c)  $ \pi' $ 是  $ (V/U)' $ 到  $ U^{0} $ 的同构.

注意(c) 中的同构并不依赖于其中任何一个向量空间的基的选取，因而是自然的.

事实上，这里并没有假定这些向量空间是有限维的.