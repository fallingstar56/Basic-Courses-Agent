(d) 设  $ u, v, w \in V $. 则

 $$ \begin{aligned}\langle u,\nu+w\rangle&=\overline{\langle\nu+w,u\rangle}\\&=\overline{\langle\nu,u\rangle+\langle w,u\rangle}\\&=\overline{\langle\nu,u\rangle}+\overline{\langle w,u\rangle}\\&=\langle u,\nu\rangle+\langle u,w\rangle.\end{aligned} $$ 

(e) 设  $ \lambda \in \mathbf{F} $， $ u, v \in V $。则

 $$ \begin{aligned}\langle u,\lambda\nu\rangle&=\overline{\langle\lambda\nu,u\rangle}\\&=\overline{\lambda\langle\nu,u\rangle}\\&=\bar{\lambda}\overline{\langle\nu,u\rangle}\\&=\bar{\lambda}\langle u,\nu\rangle.\end{aligned} $$ 

证毕.

范数

我们定义内积的动机最初来自于  $ R^{2} $ 和  $ R^{3} $ 中向量的范数．下面我们会看到每个内积都确定了一种范数．

对于  $ v \in V $， $ v $ 的范数（记作  $ \|v\| $）定义为  $ \|v\| = \sqrt{\langle v, v \rangle} $.

6.9 例 范数

(a) 若  $ (z_{1},\ldots,z_{n})\in\mathbf{F}^{n} $ （取欧几里得内积），则

 $$ \left\|\left(z_{1},\cdots,z_{n}\right)\right\|=\sqrt{\left|z_{1}\right|^{2}+\cdots+\left|z_{n}\right|^{2}}. $$ 

(b) 在  $ [-1,1] $ 上的实值连续函数构成的向量空间中（取例 6.4(c) 中定义的内积）有

 $$ \|f\|=\sqrt{\int_{-1}^{1}\left(f(x)\right)^{2}\mathrm{d}x}. $$ 

### 6.10 范数的基本性质

设  $ \nu \in V $.

(a)  $ \|\nu\| = 0 $ 当且仅当  $ \nu = 0 $.

(b) 对所有  $ \lambda \in \mathbf{F} $ 均有  $ \|\lambda v\| = |\lambda| \|v\| $.

证明

(a) 由于  $ \langle v, v \rangle = 0 $ 当且仅当 v = 0，故结论成立.