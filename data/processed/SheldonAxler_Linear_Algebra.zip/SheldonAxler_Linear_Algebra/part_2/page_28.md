4 设  $ P \in \mathcal{L}(V) $， $ P^{2} = P $。证明  $ V = \text{null} P \oplus \text{range} P $。

5 设  $ S, T \in \mathcal{L}(V) $ 且  $ S $ 是可逆的．设  $ p \in \mathcal{P}(\mathbf{F}) $ 是多项式．证明  $ p(STS^{-1}) = Sp(T)S^{-1} $．

6 设  $ T \in \mathcal{L}(V) $ 且 U 是 V 的在 T 下不变的子空间．证明：对每个多项式  $ p \in \mathcal{P}(\mathbf{F}) $ 都有 U 在  $ p(T) $ 下不变．

7 设  $ T \in \mathcal{L}(V) $. 证明 9 是  $ T^2 $ 的本征值当且仅当 3 或 -3 是  $ T $ 的本征值.

8 找出一个  $ T \in \mathcal{L}(\mathbf{R}^2) $ 使得  $ T^4 = -I $.

9 设 V 是有限维的， $ T \in \mathcal{L}(V) $， $ v \in V $ 且  $ v \neq 0 $。设 p 是使得  $ p(T)v = 0 $ 的次数最小的非零多项式。证明 p 的每个零点都是 T 的本征值。

10 设  $ T \in \mathcal{L}(V) $， $ \nu $ 是 T 的相应于本征值  $ \lambda $ 的本征向量。设  $ p \in \mathcal{P}(\mathbf{F}) $。证明  $ p(T)\nu = p(\lambda)\nu $。

11 设  $ \mathbf{F} = \mathbf{C}, T \in \mathcal{L}(V), p \in \mathcal{P}(\mathbf{C}) $ 是多项式， $ \alpha \in \mathbf{C} $。证明： $ \alpha $ 是  $ p(T) $ 的本征值。当且仅当 T 有一个本征值  $ \lambda $ 使得  $ \alpha = p(\lambda) $。

12 证明：若将 C 换成 R，则上题的结论不再成立.

13 设  $ W $ 是复向量空间，并设  $ T \in \mathcal{L}(W) $ 没有本征值．证明： $ W $ 的在  $ T $ 下不变的子空间是  $ \{0\} $ 或者是无限维的．

14 给出一个算子，它关于某个基的矩阵的对角线上只有 0，但这个算子是可逆的。本题和下题表明，要是去掉“上三角矩阵”这一假设，5.30 就不再成立。

15 给出一个算子，它关于某个基的矩阵的对角线上全是非零数，但这个算子是不可逆的.

16 利用将  $ p \in \mathcal{P}_n(\mathbf{C}) $ 变为  $ (p(T))v \in V $ 的线性映射（并利用 3.23）改写 5.21 的证明.

17 利用将  $ p \in \mathcal{P}_{n^2}(\mathbf{C}) $ 变为  $ p(T) \in \mathcal{L}(V) $ 的线性映射（并利用 3.23）改写 5.21 的证明.

18 设 V 是有限维的复向量空间， $ T \in \mathcal{L}(V) $。定义函数  $ f: \mathbf{C} \to \mathbf{R} $ 为

 $$ f(\lambda)=\dim range(T-\lambda I). $$ 

证明 f 不是连续函数.

19 设 V 是有限维的， $ \dim V > 1 $， $ T \in \mathcal{L}(V) $。证明  $ \{p(T) : p \in \mathcal{P}(\mathbf{F})\} \neq \mathcal{L}(V) $。

20 设 V 是有限维的复向量空间， $ T \in \mathcal{L}(V) $。证明：对每个  $ k = 1, \ldots, \dim V $，T 都有 k 维的不变子空间。