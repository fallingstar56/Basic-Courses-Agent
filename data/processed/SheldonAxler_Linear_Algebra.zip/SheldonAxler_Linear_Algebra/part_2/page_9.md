证明 设

 $$ p(z)=a_{0}+a_{1}z+\cdots+a_{m}z^{m}, $$ 

其中  $ a_{0}, \ldots, a_{m} $ 均为实数．设  $ \lambda \in \mathbb{C} $ 是 p 的零点．则

 $$ a_{0}+a_{1}\lambda+\cdots+a_{m}\lambda^{m}=0. $$ 

等式两端取复共轭得

 $$ a_{0}+a_{1}\bar{\lambda}+\cdots+a_{m}\bar{\lambda}^{m}=0, $$ 

此处我们使用了复共轭的一些基本性质（见 4.5）。上式表明  $ \bar{\lambda} $ 是 p 的零点。

考虑一下二次求根公式与 4.16 之间的联系.

我们想要得到实系数多项式的分解定理.为此，需要先来描述可以写成两个一次实系数多项式之积的二次实系数多项式.



4.16 二次多项式的分解

设  $ b, c \in \mathbb{R} $. 则存在  $ \lambda_1, \lambda_2 \in \mathbb{R} $ 使得分解式

 $$ x^{2}+bx+c=(x-\lambda_{1})(x-\lambda_{2}) $$ 

成立当且仅当  $ b^{2} \geq 4c. $

证明 注意到

 $$ x^{2}+bx+c=\left(x+\frac{b}{2}\right)^{2}+\left(c-\frac{b^{2}}{4}\right). $$ 

上述等式是一个基本技巧，即所谓

配方法.

首先假设  $ b^{2} < 4c $．则对每个  $ x \in \mathbf{R} $ 上式右端显然都是正的，因此多项式  $ x^{2} + bx + c $ 没有实根．于是不能分解为  $ (x - \lambda_{1})(x - \lambda_{2}) $ 的形式，其中  $ \lambda_{1}, \lambda_{2} \in \mathbf{R} $．



反之，设  $ b^{2} \geq 4c $ 。则存在实数 d 使得  $ d^{2} = \frac{b^{2}}{4} - c $ 。由本证明第二行的等式得

 $$ \begin{align*}x^2+bx+c=\left(x+{b\over2}\right)^2-d^2=\left(x+{b\over2}+d\right)\left(x+{b\over2}-d\right),\end{align*} $$ 

这就是我们要的分解.

下面的定理给出了 R 上多项式的分解．证明的思路是把 p 看作复系数多项式来使用分解 4.14．p 的非实数的复根是成对出现的，见 4.15．于是，如果 p 作为 P(C) 中的元素，其分解包含形如  $ (x - \lambda) $ 的项，其中  $ \lambda $ 是非实数的复数，那么  $ (x - \bar{\lambda}) $ 也是该分解中的一项．将这两项相乘就得到

 $$ \left(x^{2}-2(\mathrm{Re}\lambda)x+|\lambda|^{2}\right), $$ 

即所需的二次项.

上一段简要描述的思路基本上给出了分解存在性的证明．但是，有一点需要注意，假设  $ \lambda $ 是一个非实数的复根，并且  $ (x - \lambda) $ 是 p 作为  $ \mathcal{P}(\mathbf{C}) $ 中元素的分解中的一