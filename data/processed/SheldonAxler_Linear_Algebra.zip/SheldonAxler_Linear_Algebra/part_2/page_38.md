6.4 例 内积

(a)  $ F^{n} $ 上的欧几里得内积定义为

 $$ \langle(w_{1},\ldots,w_{n}),(z_{1},\ldots,z_{n})\rangle=w_{1}\overline{{z_{1}}}+\cdots+w_{n}\overline{{z_{n}}}. $$ 

(b) 若  $ c_{1},\ldots,c_{n} $ 均为正数，则可以定义  $ F^{n} $ 上的内积如下：

 $$ \left\langle\left(w_{1},\cdots,w_{n}\right),\left(z_{1},\cdots,z_{n}\right)\right\rangle=c_{1}w_{1}\overline{{z_{1}}}+\cdots+c_{n}w_{n}\overline{{z_{n}}}. $$ 

(c) 在定义在区间  $ [-1,1] $ 上的实值连续函数构成的向量空间上可定义内积如下：

 $$ \langle f,g\rangle=\int_{-1}^{1}f(x)g(x)\mathrm{d}x. $$ 

(d) 在  $ \mathcal{P}(\mathbf{R}) $ 上可定义内积如下：

 $$ \langle p,q\rangle=\int_{0}^{\infty}p(x)q(x)e^{-x}\mathrm{d}x. $$ 

### 6.5 定义 内积空间（inner product space）

内积空间就是带有内积的向量空间 V.

内积空间最重要的例子是  $ F^{n} $，带有上面例子中 (a) 所定义的欧几里得内积．当我们说  $ F^{n} $ 是内积空间时，除非特别指明，总假设采用的是欧几里得内积.

为避免不断重复 V 是内积空间这一假设，在本章余下部分我们做如下假设：

### 6.6 记号 V

在本章的余下部分，V 表示 F 上的内积空间.

注意这里稍稍有点滥用术语．内积空间是带有内积的向量空间．当我们说向量空间 V 是一个内积空间时，我们也隐含假定了 V 上的内积，或者从上下文中可以看出采用的是哪个内积（如果向量空间是  $ F^{n} $，总是采用欧几里得内积）.

### 6.7 内积的基本性质

(a) 对每个取定的  $ u \in V $，将  $ \nu $ 变为  $ \langle v, u \rangle $ 的函数是 V 到 F 的线性映射.

(b) 对每个  $ u \in V $ 均有  $ \langle 0, u \rangle = 0 $.

(c) 对每个  $ u \in V $ 均有  $ \langle u, 0 \rangle = 0 $.

(d) 对所有  $ u, v, w \in V $ 均有  $ \langle u, v + w \rangle = \langle u, v \rangle + \langle u, w \rangle $.

(e) 对所有  $ \lambda \in \mathbf{F} $ 和所有  $ u, v \in V $ 均有  $ \langle u, \lambda v \rangle = \bar{\lambda} \langle u, v \rangle $.

## 证明

(a) 由内积定义中关于第一个位置的加性和齐性可知 (a) 成立.

(b) 由 (a) 及线性映射将 0 变为 0 知 (b) 成立.

(c) 由 (a) 及内积定义中的共轭对称性知 (c) 成立.