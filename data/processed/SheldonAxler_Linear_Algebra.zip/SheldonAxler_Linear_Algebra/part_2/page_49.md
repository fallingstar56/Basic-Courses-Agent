 $$ \nu=a_{1}e_{1}+\cdots+a_{n}e_{n}. $$ 

规范正交基的重要性主要缘于下面

的命题.

对 V 的任意基求满足上述方程的  $ a_{1},\ldots,a_{n} $

可能是困难的．然而，以下命题表明对于规范正交基这很容易：取  $ a_{j}=\langle v,e_{j}\rangle $ 即可.



### 6.30 将向量写成规范正交基的线性组合

设  $ e_1, \ldots, e_n $ 是  $ V $ 的规范正交基且  $ \nu \in V $。则

 $$ \nu=\langle\nu,e_{1}\rangle e_{1}+\cdots+\langle\nu,e_{n}\rangle e_{n} $$ 

且

 $$ \left\|\nu\right\|^{2}=\left|\left\langle\nu,e_{1}\right\rangle\right|^{2}+\cdots+\left|\left\langle\nu,e_{n}\right\rangle\right|^{2}. $$ 

证明 因为  $ e_{1},\ldots,e_{n} $ 是 V 的基，所以存在标量  $ a_{1},\ldots,a_{n} $ 使得

 $$ \nu=a_{1}e_{1}+\cdots+a_{n}e_{n}. $$ 

由于  $ e_1, \ldots, e_n $ 是规范正交的，等式两端都和  $ e_j $ 做内积得到  $ \langle v, e_j \rangle = a_j $。于是 6.30 的第一个等式成立。

由 6.30 的第一个等式和 6.25 立即可得 6.30 的第二个等式.

既然我们了解了规范正交基的用处，那么如何找到它们呢？例如，对于由区间  $ [-1,1] $ 上的定积分所定义的内积（见 6.4(c)）， $ \mathcal{P}_{m}(\mathbf{R}) $ 有规范正交基吗？下面的命题将会给出这些问题的答案.

丹麦数学家约根·格拉姆（1850—1916）和德国数学家埃哈德·施密特（1876—1959）普及了这种构造规范正交基的算法.

下面证明中用到的算法称为格拉姆-施密特过程．这种方法可以把一个线性无关组转化成与原来的组有相同张成空间的规范正交组.



### 6.31 格拉姆-施密特过程

设  $ v_{1},\ldots,v_{m} $ 是 V 中的线性无关向量组. 设  $ e_{1}=v_{1}/\|v_{1}\| $. 对于  $ j=2,\ldots,m $, 定义  $ e_{j} $ 如下:

 $$ e_{j}=\frac{\nu_{j}-\langle\nu_{j},e_{1}\rangle e_{1}-\cdots-\langle\nu_{j},e_{j-1}\rangle e_{j-1}}{\|\nu_{j}-\langle\nu_{j},e_{1}\rangle e_{1}-\cdots-\langle\nu_{j},e_{j-1}\rangle e_{j-1}\|}. $$ 

则  $ e_{1},\ldots,e_{m} $ 是 V 中的规范正交组，使得对  $ j=1,\ldots,m $ 有

 $$ \operatorname{span}(\nu_{1},\cdots,\nu_{j})=\operatorname{span}(e_{1},\cdots,e_{j}). $$ 

证明 我们将对  $ j $ 用归纳法来证明结论成立．首先  $ j = 1 $ 时，由  $ v_1 $ 是  $ e_1 $ 的正数倍知  $ \operatorname{span}(v_1) = \operatorname{span}(e_1) $．

设 1 < j < m 并假设已经有