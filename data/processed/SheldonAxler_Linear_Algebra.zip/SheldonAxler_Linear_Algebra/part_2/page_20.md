31 设 V 是有限维的且  $ v_{1}, \ldots, v_{m} $ 是 V 中的一组向量．证明  $ v_{1}, \ldots, v_{m} $ 线性无关当且仅当存在  $ T \in \mathcal{L}(V) $ 使得  $ v_{1}, \ldots, v_{m} $ 是 T 的相应于不同本征值的本征向量．

32 设  $ \lambda_{1},\ldots,\lambda_{n} $ 是一组互异实数．证明在由 R 上的实值函数构成的向量空间中，组  $ e^{\lambda_{1}x},\ldots,e^{\lambda_{n}x} $ 线性无关.

提示：设  $ V = \text{span}(e^{\lambda_1 x}, \ldots, e^{\lambda_n x}) $，定义算子  $ T \in \mathcal{L}(V) $ 为  $ T f = f' $。求 T 的本征值和本征向量。

33 设  $ T \in \mathcal{L}(V) $. 证明  $ T / (\text{range } T) = 0 $.

34 设  $ T \in \mathcal{L}(V) $. 证明  $ T/(\text{null } T) $ 是单的当且仅当  $ (\text{null } T) \cap (\text{range } T) = \{0\} $.

35 设  $ V $ 是有限维的， $ T \in \mathcal{L}(V) $， $ U $ 在  $ T $ 下不变．证明  $ T/U $ 的每个本征值均为  $ T $ 的本征值．

下题是让你验证本习题中“V 是有限维的”这一假设是必需的。

36 找出一个向量空间 V 和一个算子  $ T \in \mathcal{L}(V) $，以及 V 的在 T 下不变的子空间 U，使得 T/U 的某个本征值不是 T 的本征值.

### 5. B 本征向量与上三角矩阵

## 多项式作用于算子

算子（它把一个向量空间映到自身）理论要比线性映射理论更丰富，主要原因是算子能自乘为幂．我们从算子的幂以及多项式作用于算子这一关键概念的定义开始.

若  $ T \in \mathcal{L}(V) $，则 TT 有意义，并且也含于  $ \mathcal{L}(V) $。通常用  $ T^2 $ 代替 TT。更一般地，我们有下面的定义。

5.16 定义  $ T^{m} $

设  $ T \in \mathcal{L}(V) $， $ m $ 是正整数。

• 定义  $ T^{m} $ 为  $ T^{m}=\underbrace{T\cdots T}_{m 个} $

• 定义  $ T^{0} $ 为 V 上的恒等算子 I.

• 若 T 是可逆的且其逆为  $ T^{-1} $，则定义  $ T^{-m} $ 为  $ T^{-m} = (T^{-1})^{m} $.

请自行验证，若 T 是算子，则有

 $$ T^{m}T^{n}=T^{m+n}\quad 和 \quad(T^{m})^{n}=T^{mn}, $$ 

当 T 可逆时 m 和 n 是任意整数，当 T 不可逆时 m 和 n 是非负整数.

5.17 定义  $ p(T) $

设  $ T \in \mathcal{L}(V) $， $ p \in \mathcal{P}(\mathbf{F}) $，对  $ z \in \mathbf{F} $ 有  $ p(z) = a_0 + a_1 z + a_2 z^2 + \cdots + a_m z^m $。则  $ p(T) $ 是定义为  $ p(T) = a_0 I + a_1 T + a_2 T^2 + \cdots + a_m T^m $ 的算子。