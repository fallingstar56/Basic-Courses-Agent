(b) 设  $ \lambda \in \mathbf{F} $. 则

 $$ \begin{align*}\|\lambda\nu\|^2&=\langle\lambda\nu,\lambda\nu\rangle\\&=\lambda\langle\nu,\lambda\nu\rangle\\&=\lambda\bar{\lambda}\langle\nu,\nu\rangle\\&=|\lambda|^2\|\nu\|^2.\end{align*} $$ 

开平方即得要证的等式.

上面 (b) 的这个证明阐明了一个普遍原理：处理范数的平方通常比直接处理范数更容易.

现在给出一个关键的定义.

### 6.11 定义 正交（orthogonal）

两个向量  $ u, v \in V $ 称为是正交的，如果  $ \langle u, v \rangle = 0 $.

在上述定义中向量的次序无关紧要，因为  $ \langle u, v \rangle = 0 $ 当且仅当  $ \langle v, u \rangle = 0 $ 。有时候我们说 u 正交于 v ，而不说 u 和 v 是正交的。

习题 13 表明，若 u, v 是  $ R^{2} $ 中的非零向量，则

 $$ \langle u,v\rangle=||u||||v||\cos\theta, $$ 

其中  $ \theta $ 是 u 和 v 间的夹角（把 u 和 v 看成始于原点的箭头）。于是  $ R^{2} $ 中的两个向量是正交的（按照通常的欧几里得内积）当且仅当它们之间夹角的余弦是 0，当且仅当这两个向量在平面几何通常的意义下是垂直的。因此正交是一个很酷的词，意思就是垂直（perpendicular）。

我们从下面的简单结果开始研究正交性.

6.12 正交性与 0

(a) 0 正交于 V 中的任意向量.

(b) 0 是 V 中唯一一个与自身正交的向量.

证明

(a) 6.7(b) 表明对每个  $ u \in V $ 均有  $ \langle 0, u \rangle = 0 $.

(b) 若  $ v \in V $ 且  $ \langle v, v \rangle = 0 $，则  $ v = 0 $（由内积的定义）.

下面的定理是对于  $ V = R^{2} $ 的特殊情况，已经有 2500 多年历史了．当然，这里给出的证明并不是原始的证明．

正交一词来源自希腊语的 orthogonios，后者的意思是直角的.



### 6.13 勾股定理（又称毕达哥拉斯定理）

设 u 和 v 是 V 中的正交向量，则  $ \|u + v\|^2 = \|u\|^2 + \|v\|^2 $.