 $$ \left(\begin{array}{c c c c}\lambda_{1}&&*\\ &\ddots&\\ &&\lambda_{n}\\\end{array}\right). $$ 

上面矩阵中的那个 0 表示在这个  $ n \times n $ 矩阵中位于对角线下方的元素全等于 0。可以认为上三角矩阵是相当简单的——因为当 n 比较大时， $ n \times n $ 上三角矩阵有几乎一半的元素等于 0。

我们经常用 * 表示矩阵的未知元素

或其取值对所讨论的问题无关紧要的元素.



下面的命题揭示了上三角矩阵与不变子空间之间的一个很有用的联系.

### 5.26 上三角矩阵的条件

设  $ T \in \mathcal{L}(V) $，且  $ v_1, \ldots, v_n $ 是  $ V $ 的基。则以下条件等价：

(a) T 关于  $ v_{1}, \ldots, v_{n} $ 的矩阵是上三角的；

(b) 对每个  $ j = 1, \ldots, n $ 有  $ T v_j \in \text{span}(v_1, \ldots, v_j) $;

(c) 对每个  $ j = 1, \ldots, n $ 有  $ \operatorname{span}(v_{1}, \ldots, v_{j}) $ 在 T 下不变.

证明 根据定义，稍加思考即可得 (a) 和 (b) 的等价性．显然 (c) 蕴涵 (b)．因此，为了完成证明，只需证明 (b) 蕴涵 (c)．

假设 (b) 成立．取定  $ j \in \{1, \ldots, n\} $．由 (b) 可知

 $$ \begin{aligned}&T\nu_{1}\in\operatorname{span}(\nu_{1})\subset\operatorname{span}(\nu_{1},\cdots,\nu_{j}),\\&T\nu_{2}\in\operatorname{span}(\nu_{1},\nu_{2})\subset\operatorname{span}(\nu_{1},\cdots,\nu_{j}),\\&\quad\vdots\\ \end{aligned} $$ 

 $$ T\nu_{j}\in\operatorname{s p a n}(\nu_{1},\dots,\nu_{j}). $$ 

因此，若 v 是  $ v_{1}, \ldots, v_{j} $ 的线性组合，则

 $$ T\nu\in\operatorname{s p a n}(\nu_{1},\dots,\nu_{j}). $$ 

也就是说  $ \operatorname{span}(v_{1},\ldots,v_{j}) $ 在 T 下不变.

现在我们可以证明：对于复向量空间上的每个算子，都有一个基使得该算子关于这个基的矩阵的对角线下方只有0。在第8章我们将改进这个结果。

深刻的见解往往源于一个定理的多种证明。因此我们对下面的定理给出两个证明。你可以采用其中更合你心意的那一个。

下面的定理对实向量空间不成立，这是因为，若算子关于一个基有上三角矩阵，则这个基的第一个向量必定是该算子的本征向量。因此，若实向量空间上的一个算子没有本征值（例如，见5.8(a)），则该算子关于任何基都不会有上三角矩阵。

