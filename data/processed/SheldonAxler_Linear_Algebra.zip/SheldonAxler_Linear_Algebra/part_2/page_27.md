### 5.32 从上三角矩阵确定本征值

设  $ T \in \mathcal{L}(V) $ 关于  $ V $ 的某个基有上三角矩阵．则  $ T $ 的本征值恰为这个上三角矩阵对角线上的元素．

证明 设  $ v_{1},\ldots,v_{n} $ 是 V 的基，并且 T 关于这个基有上三角矩阵

 $$ \mathcal{M}(T)=\left(\begin{array}{c c c c}\lambda_{1}&&&*\\ &\lambda_{2}&&\\ &&\ddots&\\ 0&&&\lambda_{n}\end{array}\right). $$ 

设  $ \lambda \in \mathbf{F} $. 则

 $$ \mathcal{M}(T-\lambda I)=\left(\begin{array}{cccc}\lambda_{1}-\lambda&&&*\\&\lambda_{2}-\lambda&&\\&&\ddots&\\&&&\lambda_{n}-\lambda\end{array}\right). $$ 

因此， $ (T - \lambda I) $ 不可逆当且仅当  $ \lambda $ 等于  $ \lambda_1, \ldots, \lambda_n $ 中的某一个（由于 5.30）。于是  $ \lambda $ 是  $ T $ 的本征值当且仅当  $ \lambda $ 等于  $ \lambda_1, \ldots, \lambda_n $ 中的某一个。

5.33 例 定义  $ T \in \mathcal{L}(\mathbf{F}^3) $ 为  $ T(x,y,z) = (2x + y, 5y + 3z, 8z) $. 求 T 的本征值.

解 T 关于标准基的矩阵为

 $$ \mathcal{M}(T)=\left(\begin{array}{c c c}{2}&{1}&{0}\\ {0}&{5}&{3}\\ {0}&{0}&{8}\\ \end{array}\right). $$ 

 $ M(T) $ 是上三角矩阵. 5.32 表明 T 的本征值是 2, 5, 8.

一旦知道  $ F^{n} $ 上一个算子的本征值，就很容易利用高斯消元法求出本征向量.

### 习题 5.B

1 设  $ T \in \mathcal{L}(V) $ 且存在正整数 n 使得  $ T^n = 0 $.

(a) 证明  $ (I - T) $ 是可逆的且  $ (I - T)^{-1} = I + T + \cdots + T^{n-1} $.

(b) 解释一下如何想到上面的公式.

2 设  $ T \in \mathcal{L}(V) $ 且  $ (T - 2I)(T - 3I)(T - 4I) = 0 $ 。设  $ \lambda $ 是 T 的本征值。证明  $ \lambda = 2 $ 或  $ \lambda = 3 $ 或  $ \lambda = 4 $ 。

3 设  $ T \in \mathcal{L}(V) $， $ T^2 = I $ 且 -1 不是 T 的本征值．证明 T = I．