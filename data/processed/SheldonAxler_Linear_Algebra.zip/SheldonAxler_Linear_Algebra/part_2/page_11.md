3 集合  $ \{0\} \cup \{p \in \mathcal{P}(\mathbf{F}) : \deg p $ 是偶数} 是  $ \mathcal{P}(\mathbf{F}) $ 的子空间吗？

4 设 m 和 n 均为正整数， $ m \leq n $，并设  $ \lambda_1, \ldots, \lambda_m \in \mathbf{F} $。证明存在多项式  $ p \in \mathcal{P}(\mathbf{F}) $ 满足  $ \deg p = n $ 和  $ 0 = p(\lambda_1) = \cdots = p(\lambda_m) $，且 p 没有其他的零点。

5 设 $m$ 是非负整数，$z_1, \ldots, z_{m+1}$ 是 $\mathbf{F}$ 中的一些不同的元素，且 $w_1, \ldots, w_{m+1} \in \mathbf{F}$。证明存在唯一一个多项式 $p \in \mathcal{P}_m(\mathbf{F})$ 使得 $p(z_j) = w_j$，其中 $j = 1, \ldots, m + 1$。这个结果可以不用线性代数来证明。试用线性代数的知识给出一个简短的证明。

6 设  $ p \in \mathcal{P}(\mathbf{C}) $ 的次数为 m. 证明 p 有 m 个不同的零点当且仅当 p 与其导式  $ p' $ 没有公共零点.

7 证明每个奇数次的实系数多项式都有实的零点.

8 定义  $ T: \mathcal{P}(\mathbf{R}) \to \mathbf{R}^{\mathbf{R}} $ 为

 $$ Tp=\left\{\begin{aligned}&\frac{p-p(3)}{x-3},& 若 x\neq3,\\ &p^{\prime}(3),& 若 x=3.\end{aligned}\right. $$ 

证明对每个多项式  $ p \in \mathcal{P}(\mathbf{R}) $ 均有  $ T_p \in \mathcal{P}(\mathbf{R}) $，且  $ T $ 是线性映射。

9 设  $ p \in \mathcal{P}(\mathbf{C}) $。定义  $ q: \mathbf{C} \to \mathbf{C} $ 为  $ q(z) = p(z) \overline{p(\bar{z})} $。证明  $ q $ 是实系数多项式。

10 设  $ m $ 是非负整数， $ p \in \mathcal{P}_m(\mathbf{C}) $，且存在不同的实数  $ x_0, x_1, \ldots, x_m $ 使得  $ p(x_j) \in \mathbf{R} $，其中  $ j = 0, 1, \ldots, m $。证明  $ p $ 的系数均为实数。

11 设  $ p \in \mathcal{P}(\mathbf{F}) $， $ p \neq 0 $。令  $ U = \{pq : q \in \mathcal{P}(\mathbf{F})\} $。

(a) 证明  $ \dim\mathcal{P}(\mathbf{F})/U = \deg p. $

(b) 求  $ \mathcal{P}(\mathbf{F})/U $ 的一个基.