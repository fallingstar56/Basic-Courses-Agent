11 证明对所有正数 a, b, c, d 均有  $ 16 \leq (a + b + c + d)\left(\frac{1}{a} + \frac{1}{b} + \frac{1}{c} + \frac{1}{d}\right) $.

12 证明对所有正整数 n 和实数  $ x_{1}, \ldots, x_{n} $ 均有  $ (x_{1}+\cdots+x_{n})^{2} \leq n(x_{1}^{2}+\cdots+x_{n}^{2}) $.

13 设  $ u, v $ 是  $ R^2 $ 中的非零向量．证明  $ \langle u, v \rangle = \|u\|\|v\|\cos\theta $，其中  $ \theta $ 是  $ u $ 和  $ v $ 的夹角（将  $ u $ 和  $ v $ 看作始于原点的箭头）．

提示：画出 u、v 和 u - v 形成的三角形，然后利用余弦定理.

14  $ R^2 $ 或  $ R^3 $ 中两个向量（视为始于原点的箭头）的夹角可以用几何的方法来定义。但是对  $ n > 3 $， $ R^n $ 中的几何是不明确的。所以两个非零向量  $ x, y \in \mathbb{R}^n $ 的夹角定义为  $ \arccos \frac{\langle x, y \rangle}{\|x\|\|y\|} $，此定义的动机来自于上题。解释一下为什么证明上述定义有意义需要用到柯西-施瓦茨不等式。

15 证明对所有实数  $ a_{1}, \ldots, a_{n} $ 和  $ b_{1}, \ldots, b_{n} $ 均有

 $$ \Big(\sum_{j=1}^{n}a_{j}b_{j}\Big)^{2}\leq\Big(\sum_{j=1}^{n}j a_{j}{}^{2}\Big)\Big(\sum_{j=1}^{n}\frac{b_{j}{}^{2}}{j}\Big). $$ 

16 设  $ u, v \in V $ 使得  $ \|u\| = 3 $,  $ \|u + v\| = 4 $,  $ \|u - v\| = 6 $.  $ \|v\| $ 等于多少?

17 证明或反驳： $  \mathbf{R}^2  $ 上有一个内积使得该内积确定的范数为：对所有  $  (x, y) \in \mathbf{R}^2  $ 有  $  \|(x, y)\| = \max\{|x|, |y|\}  $.

>0. 证明  $ R^{2} $ 上有一个内积使得该内积确定的范数为

 $$  对所有 (x,y)\in\mathbf{R}^{2} 有 \left\|(x,y)\right\|=\left(|x|^{p}+|y|^{p}\right)^{1/p} $$ 

当且仅当p=2.

19 设 V 是实内积空间．证明对所有  $ u, v \in V $ 均有

 $$ \langle u,v\rangle=\frac{\left\|u+v\right\|^{2}-\left\|u-v\right\|^{2}}{4}. $$ 

20 设 V 是复内积空间．证明对所有  $ u, v \in V $ 均有

 $$ \langle u,\nu\rangle=\frac{\|u+\nu\|^{2}-\|u-\nu\|^{2}+\|u+\mathrm{i}\nu\|^{2}\mathrm{i}-\|u-\mathrm{i}\nu\|^{2}\mathrm{i}}{4}. $$ 

21 向量空间 U 上的范数是满足以下条件的函数  $ \|\cdot\|:U \to [0,\infty) $:  $ \|u\| = 0 $ 当且仅当  $ u = 0 $，对所有  $ \alpha \in \mathbf{F} $ 和  $ u \in U $ 均有  $ \|\alpha u\| = |\alpha|\|u\| $，对所有  $ u, v \in U $ 均有  $ \|u + v\| \leq \|u\| + \|v\| $。证明满足平行四边形恒等式的范数均来自于内积（也就是说：若  $ \|\cdot\| $ 是 U 上的满足平行四边形恒等式的范数，则有 U 上的内积  $ \langle,\cdot\rangle $ 使得对所有  $ u \in U $ 均有  $ \|u\| = \langle u, u\rangle^{1/2} $。

22 证明平均数的平方小于等于平方的平均数．更确切地说，若  $ a_{1},\ldots,a_{n}\in\mathbf{R} $，则  $ a_{1},\ldots,a_{n} $ 的平均数的平方小于等于  $ a_{1}^{2},\ldots,a_{n}^{2} $ 的平均数．

23 设  $ V_{1}, \ldots, V_{m} $ 均为内积空间．证明等式

 $$ \left\langle(u_{1},\cdots,u_{m}),(\nu_{1},\cdots,\nu_{m})\right\rangle=\left\langle u_{1},\nu_{1}\right\rangle+\cdots+\left\langle u_{m},\nu_{m}\right\rangle $$ 

定义了  $ V_{1} \times \cdots \times V_{m} $ 上的内积.

在上面表达式的右端， $ \langle u_1, v_1 \rangle $ 表示  $ V_1 $ 上的内积， $ \ldots $， $ \langle u_m, v_m \rangle $ 表示  $ V_m $ 上的内积。虽然这里使用了相同的记号，但各个空间  $ V_1, \ldots, V_m $ 可以有不同的内积。