15 设  $ T \in \mathcal{L}(V) $. 设  $ S \in \mathcal{L}(V) $ 是可逆的.

(a) 证明 T 和  $ S^{-1}TS $ 有相同的本征值.

(b) T 的本征向量与  $ S^{-1}TS $ 的本征向量之间有什么关系？

16 设  $ V $ 是复向量空间， $ T \in \mathcal{L}(V) $， $ T $ 关于  $ V $ 的某个基的矩阵的元素均为实数．证明：若  $ \lambda $ 是  $ T $ 的本征值，则  $ \bar{\lambda} $ 也是  $ T $ 的本征值．

17 给出一个没有（实）本征值的算子  $ T \in \mathcal{L}(\mathbf{R}^4) $.

18 定义  $ T \in \mathcal{L}(\mathbf{C}^\infty) $ 为  $ T(z_1, z_2, \ldots) = (0, z_1, z_2, \ldots) $. 证明 T 没有本征值.

19 设 n 是正整数，定义  $ T \in \mathcal{L}(\mathbf{F}^n) $ 为  $ T(x_1, \ldots, x_n) = (x_1 + \cdots + x_n, \ldots, x_1 + \cdots + x_n) $，也就是说算子  $ T $（对于标准基）的矩阵的元素全是 1. 求  $ T $ 的所有本征值和本征向量.

20 定义向后移位算子  $ T \in \mathcal{L}(\mathbf{F}^{\infty}) $ 为  $ T(z_{1}, z_{2}, z_{3}, \ldots) = (z_{2}, z_{3}, \ldots) $. 求 T 的所有本征值和本征向量.

21 设  $ T \in \mathcal{L}(V) $ 是可逆的.

(a) 设  $ \lambda \in \mathbf{F} $， $ \lambda \neq 0 $。证明  $ \lambda $ 是  $ T $ 的本征值当且仅当  $ \frac{1}{\lambda} $ 是  $ T^{-1} $ 的本征值。

(b) 证明 T 和  $ T^{-1} $ 有相同的本征向量.

22 设  $ T \in \mathcal{L}(V) $ 且存在 V 中的非零向量 v 和 w 使得 Tv = 3w 且 Tw = 3v. 证明 3 或者 -3 是 T 的本征值.

23 设 V 是有限维的且  $ S, T \in \mathcal{L}(V) $. 证明 ST 和 TS 有相同的本征值.

24 设 A 是元素属于 F 的  $ n \times n $ 矩阵. 定义  $ T \in \mathcal{L}(\mathbf{F}^n) $ 为 Tx = Ax，这里  $ F^n $ 中的元素视为  $ n \times 1 $ 的列向量.

(a) 设 A 的每行的元素之和都等于 1. 证明 1 是 T 的本征值.

(b) 设 A 的每列的元素之和都等于 1. 证明 1 是 T 的本征值.

25 设  $ T \in \mathcal{L}(V) $ 且 u 和 v 均为 T 的本征向量使得  $ u + v $ 也是 T 的本征向量。证明 u 和 v 是 T 的相应于同一本征值的本征向量。

26 设  $ T \in \mathcal{L}(V) $ 使得 V 中的每个非零向量都是 T 的本征向量．证明 T 是恒等算子的标量倍．

27 设  $ V $ 是有限维的， $ T \in \mathcal{L}(V) $ 使得  $ V $ 的每个  $ \dim V - 1 $ 维子空间都在  $ T $ 下不变。证明  $ T $ 是恒等算子的标量倍。

28 设 V 是有限维的， $ \dim V \geq 3 $ 且  $ T \in \mathcal{L}(V) $ 使得 V 的每个二维子空间在 T 下不变．证明 T 是恒等算子的标量倍．

29 设  $ T \in \mathcal{L}(V) $ 且  $ \dim \text{range } T = k $。证明  $ T $ 至多有  $ k + 1 $ 个不同的本征值。

30 设  $ T \in \mathcal{L}(\mathbb{R}^3) $ 且 -4, 5,  $ \sqrt{7} $ 均为 T 的本征值．证明存在  $ x \in \mathbb{R}^3 $ 使得 Tx - 9x =  $ (-4, 5, \sqrt{7}) $．