6.19

 $$ \begin{aligned}&=\|u\|^{2}+\|\nu\|^{2}+2\operatorname{Re}\langle u,\nu\rangle\\&\leq\|u\|^{2}+\|\nu\|^{2}+2|\langle u,\nu\rangle|\\&\leq\|u\|^{2}+\|\nu\|^{2}+2\|u\|\|\nu\|\\&=\left(\|u\|+\|\nu\|\right)^{2},\end{aligned} $$ 

6.20

其中 6.20 是利用柯西-施瓦茨不等式 6.15. 上面的不等式两端开平方即得所要证的不等式.

上面的证明表明，三角不等式是等式当且仅当 6.19 和 6.20 均为等式．因此，三角不等式是等式当且仅当

6.21

 $$ \langle u,\nu\rangle=||u|||\nu||. $$ 

请自行验证，如果 u, v 之一是另一个的非负标量倍，那么 6.21 成立．反之，设 6.21 成立，则由柯西-施瓦茨不等式 6.15 为等式的条件可知，u, v 之一必定是另一个的标量倍，再由 6.21 知这个标量显然是非负的．

下面的命题称为平行四边形恒等式，因为它的几何解释为：在任意平行四边形中，对角线长度的平方和等于四条边长度的平方和．



<div style="text-align: center;"><img src="imgs/img_in_image_box_82_581_476_785.jpg" alt="Image" width="43%" /></div>


<div style="text-align: center;">平行四边形恒等式</div>


### 6.22 平行四边形恒等式

设  $ u, v \in V $. 则  $ \|u + v\|^2 + \|u - v\|^2 = 2(\|u\|^2 + \|v\|^2) $.

证明

 $$ \begin{align*}\left\|u+\nu\right\|^{2}+\left\|u-\nu\right\|^{2}&=\left\langle u+\nu,u+\nu\right\rangle+\left\langle u-\nu,u-\nu\right\rangle\\&=\left\|u\right\|^{2}+\left\|\nu\right\|^{2}+\left\langle u,\nu\right\rangle+\left\langle\nu,u\right\rangle\\&\quad+\left\|u\right\|^{2}+\left\|\nu\right\|^{2}-\left\langle u,\nu\right\rangle-\left\langle\nu,u\right\rangle\\&=2(\left\|u\right\|^{2}+\left\|\nu\right\|^{2}).\end{align*} $$ 