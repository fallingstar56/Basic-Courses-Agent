### 5.6 本征值的等价条件

设  $ V $ 是有限维的， $ T \in \mathcal{L}(V) $ 且  $ \lambda \in F $。则以下条件等价：

(a)  $ \lambda $ 是 T 的本征值;

(b)  $ T - \lambda I $ 不是单的；

回想一下  $ I \in \mathcal{L}(V) $ 是恒等算子，

即对所有  $ v \in V $ 均有  $ I_V = v $.

(c)  $ T - \lambda I $ 不是满的；

(d)  $ T - \lambda I $ 不是可逆的.

证明 条件 (a) 和 (b) 等价，因为等式  $ Tv = \lambda v $ 等价于等式  $ (T - \lambda I)v = 0 $ 。由 3.69 可知条件 (b)、(c)、(d) 等价。

### 5.7 定义 本征向量（eigenvector）

设  $ T \in \mathcal{L}(V) $，并设  $ \lambda \in \mathbf{F} $ 是  $ T $ 的本征值。称向量  $ v \in V $ 为  $ T $ 的相应于  $ \lambda $ 的本征向量，如果  $ v \neq 0 $ 且  $ T v = \lambda v $。

因为  $ Tv = \lambdav $ 当且仅当  $ (T - \lambdaI)v = 0 $，所以非零向量  $ v \in V $ 是  $ T $ 的相应于  $ \lambda $ 的本征向量当且仅当  $ v \in \text{null}(T - \lambdaI) $。

5.8 例 设  $ T \in \mathcal{L}(\mathbf{F}^2) $ 定义为  $ T(w, z) = (-z, w) $.

(a) 当 F = R 时，求 T 的本征值和本征向量.

(b) 当 F = C 时，求 T 的本征值和本征向量.

## 解

(a) 若  $ \mathbf{F} = \mathbf{R} $，则  $ T $ 是  $ \mathbf{R}^2 $ 中绕原点的逆时针  $ 90^\circ $ 旋转．一个算子有本征值当且仅当在定义域中存在非零向量能被该算子映成此向量的标量倍． $ \mathbf{R}^2 $ 中非零向量的逆时针  $ 90^\circ $ 旋转显然不能等于此向量的标量倍．结论：若  $ \mathbf{F} = \mathbf{R} $，则  $ T $ 没有本征值（因此也没有本征向量）．

(b) 为了求 T 的本征值，我们必须求标量  $ \lambda $ 使得

 $$ T(w,z)=\lambda(w,z) $$ 

除 w = z = 0 外还有其他解．上面的方程等价于联立方程

### 5.9 

 $$ -z=\lambda w,\quad w=\lambda z. $$ 

把第二个方程中 w 的表达式代入第一个方程可得

 $$ -z=\lambda^{2}z. $$ 

现在 z 不能等于 0（否则，由 5.9 可知 w = 0，而我们要找的 5.9 的解应使  $ (w, z) $ 不是零向量），故由上面的方程可得

 $$ -1=\lambda^{2}. $$ 