### 5.27 在 C 上，每个算子均有上三角矩阵

设 V 是有限维复向量空间， $ T \in \mathcal{L}(V) $。则 T 关于 V 的某个基有上三角矩阵。

证明 1 对 V 的维数用归纳法．若  $ \dim V = 1 $，则结论显然成立.

现在假设  $ \dim V > 1 $，并设对于所有维数比 V 小的复向量空间结论都成立。设  $ \lambda $ 是 T 的任意本征值（5.21 保证了 T 有本征值）。设

 $$ U=\mathrm{range}(T-\lambda I). $$ 

因为 $ (T - \lambda I) $不是满的（参见3.69），所以 $ \dim U < \dim V $。进一步，U在T下不变。为了证明这点，设 $ u \in U $。则

 $$ T u=(T-\lambda I)u+\lambda u. $$ 

显然， $ (T - \lambda I)u \in U $（因为  $ U $ 等于  $ (T - \lambda I) $ 的值域），并且  $ \lambda u \in U $．因此上式表明  $ Tu \in U $．所以  $ U $ 在  $ T $ 下不变．

因此  $ T|_{U} $ 是 U 上的算子．由归纳法假设，U 有基  $ u_{1},\ldots,u_{m} $ 使得  $ T|_{U} $ 关于这个基有上三角矩阵．因此，对每个 j 都有（利用 5.26）

### 5.28 

 $$ T u_{j}=(T|_{U})(u_{j})\in\operatorname{s p a n}(u_{1},\ldots,u_{j}). $$ 

把  $ u_{1},\ldots,u_{m} $ 扩充成 V 的基  $ u_{1},\ldots,u_{m},v_{1},\ldots,v_{n} $. 对每个 k 都有

 $$ T\nu_{k}=(T-\lambda I)\nu_{k}+\lambda\nu_{k}. $$ 

U 的定义表明  $ (T - \lambda I)v_k \in U = \text{span}(u_1, \ldots, u_m) $。因此由上式可得

### 5.29 

 $$ T\nu_{k}\in\operatorname{s p a n}(u_{1},\ldots,u_{m},\nu_{1},\ldots,\nu_{k}). $$ 

利用 5.26，由 5.28 和 5.29 可知 T 关于基  $ u_{1}, \ldots, u_{m}, v_{1}, \ldots, v_{n} $ 有上三角矩阵. 证明 2 对 V 的维数用归纳法. 若  $ \dim V = 1 $，则结论显然成立.

现在假设  $ \dim V = n > 1 $，并设对于所有 n - 1 维的复向量空间结果均成立。设  $ v_{1} $ 是 T 的任意一个本征向量（5.21 保证了 T 有本征向量）。设  $ U = \operatorname{span}(v_{1}) $。则 U 是 T 的不变子空间且  $ \dim U = 1 $。

由于  $ \dim V/U = n - 1 $（见 3.89），我们可以对  $ T/U \in \mathcal{L}(V/U) $ 用归纳法假设。于是  $ V/U $ 有一个基  $ v_{2} + U, \ldots, v_{n} + U $ 使得 T/U 关于该基有上三角矩阵。由 5.26，对每个  $ j = 2, \ldots, n $ 有

 $$ (T/U)(\nu_{j}+U)\in\operatorname{s p a n}(\nu_{2}+U,\ldots,\nu_{j}+U). $$ 

通过解释上面这个包含关系的含义可知，对每个  $ j=1,\ldots,n $ 有

 $$ T\nu_{j}\in\operatorname{s p a n}(\nu_{1},\dots,\nu_{j}). $$ 

于是由 5.26，T 关于 V 的基  $ v_{1},\ldots,v_{n} $ 具有上三角矩阵（容易验证  $ v_{1},\ldots,v_{n} $ 是 V 的基．更一般的结论，请参见 3.E 节的习题 13）.