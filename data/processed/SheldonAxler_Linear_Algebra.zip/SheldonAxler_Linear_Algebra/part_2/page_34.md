(a) 证明对每个正整数 n 均有  $ T^{n}(0,1)=(F_{n},F_{n+1}) $.

(b) 求 T 的本征值.

(c) 求  $ R^{2} $ 的一个由 T 的本征向量构成的基.

(d) 利用 (c) 的解计算  $ T^{n}(0,1) $. 由此证明：对每个正整数 n 有

 $$ F_{n}=\frac{1}{\sqrt{5}}\left[\left(\frac{1+\sqrt{5}}{2}\right)^{n}-\left(\frac{1-\sqrt{5}}{2}\right)^{n}\right] $$ 

(e) 利用 (d) 证明：对每个正整数 n，斐波那契数  $ F_{n} $ 是最接近于

 $$ \frac{1}{\sqrt{5}}\left(\frac{1+\sqrt{5}}{2}\right)^{n} $$ 

的整数.