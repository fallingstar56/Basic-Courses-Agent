### 6. A 内积与范数

## 内积

为了说明引入内积概念的动机，我们把  $ R^{2} $ 和  $ R^{3} $ 中的向量看作始于原点的箭头。 $ R^{2} $ 或  $ R^{3} $ 中向量 x 的长度称为 x 的范数（norm），记为  $ \|x\| $。因此对于  $ x = (x_{1}, x_{2}) \in R^{2} $ 有  $ \|x\| = \sqrt{x_{1}^{2} + x_{2}^{2}} $。

<div style="text-align: center;"><img src="imgs/img_in_image_box_496_226_816_376.jpg" alt="Image" width="35%" /></div>


类似地，若  $ x = (x_{1}, x_{2}, x_{3}) \in \mathbb{R}^{3} $，则  $ \|x\| = \sqrt{x_{1}^{2} + x_{2}^{2} + x_{3}^{2}} $.

向量 x 的长度是  $ \sqrt{x_{1}^{2}+x_{2}^{2}} $

虽然我们画不出高维的图形，但是范数在  $ R^n $ 上的推广是显然的：定义  $ x = (x_1, \ldots, x_n) \in \mathbb{R}^n $ 的范数为

 $$ \|x\|=\sqrt{x_{1}{}^{2}+\cdots+x_{n}{}^{2}}. $$ 

范数在  $ R^{n} $ 上不是线性的．为了把线性引入讨论，我们引入点积．

### 6.2 定义 点积（dot product）

对于  $ x, y \in \mathbb{R}^n $， $ x $ 和  $ y $ 的点积（记作  $ x \cdot y $）定义为

 $$ x\cdot y=x_{1}y_{1}+\cdots+x_{n}y_{n}, $$ 

其中  $ x=(x_{1},\ldots,x_{n}),y=(y_{1},\ldots,y_{n}). $

注意， $ R^n $ 中两个向量的点积是一个数，而不是一个向量。显然对所有  $ x \in R^n $ 有  $ x \cdot x = \|x\|^2 $。 $ R^n $ 上的点积具有以下性质：

如果我们把向量看作点，而不是箭头，那么  $ \|x\| $ 应该解释成从原点到点  $ x $ 的距离。



• 对所有  $ x \in \mathbb{R}^n $ 均有  $ x \cdot x \geq 0 $;

•  $ x \cdot x = 0 $ 当且仅当 x = 0;

• 对于固定的  $ y \in \mathbb{R}^n $， $ \mathbb{R}^n $ 到  $ \mathbb{R} $ 的将  $ x \in \mathbb{R}^n $ 变为  $ x \cdot y $ 的映射是线性的；

- 对所有  $ x, y \in \mathbb{R}^n $ 均有  $ x \cdot y = y \cdot x $.

内积是点积的推广．现在你可能会猜到，定义内积就是把上一段所讨论的点积的性质抽象化．这种猜测对实向量空间是正确的．为了使定义对实向量空间和复向量空间都可用，在给出定义之前，我们需要考察复数的情形．

回想一下，若  $ \lambda = a + bi $，其中  $ a, b \in \mathbb{R} $，则

•  $ \lambda $ 的绝对值（记作  $ |\lambda| $）定义为  $ |\lambda| = \sqrt{a^{2} + b^{2}} $;

·  $ \lambda $ 的复共轭（记作  $ \bar{\lambda} $）定义为  $ \bar{\lambda} = a - bi $;

 $$ \bullet \quad |\lambda|^{2}=\lambda\bar{\lambda}. $$ 

关于绝对值和复共轭的定义和基本性质，见第4章.