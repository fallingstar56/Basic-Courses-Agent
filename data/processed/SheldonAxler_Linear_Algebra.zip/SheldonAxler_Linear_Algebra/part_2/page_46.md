24 设  $ S \in \mathcal{L}(V) $ 是 V 上的一个单的算子．定义  $ \langle\cdot,\cdot\rangle_{1} $ 如下：对  $ u,v \in V $ 有  $ \langle u,v\rangle_{1} = \langle Su,Sv\rangle $．证明  $ \langle\cdot,\cdot\rangle_{1} $ 是 V 上的内积．

25 设  $ S \in \mathcal{L}(V) $ 不是单的．如上题那样定义  $ \langle\cdot,\cdot\rangle_{1} $．说明为什么  $ \langle\cdot,\cdot\rangle_{1} $ 不是 V 上的内积．

26 设 f, g 是 R 到  $ R^{n} $ 的可微函数.

(a) 证明  $ \langle f(t), g(t)\rangle' = \langle f'(t), g(t)\rangle + \langle f(t), g'(t)\rangle. $

(b) 设 c > 0 且对每个  $ t \in \mathbb{R} $ 均有  $ \|f(t)\| = c $. 证明对每个  $ t \in \mathbb{R} $ 均有  $ \langle f'(t), f(t) \rangle = 0 $.

(c) 利用  $ R^{n} $ 中以原点为中心的球面上的曲线的切向量给出 (b) 中结论的几何解释.

在本题中，函数  $ f: \mathbf{R} \to \mathbf{R}^n $ 称为是可微的是指存在  $ \mathbf{R} $ 到  $ \mathbf{R} $ 的可微函数  $ f_1, \ldots, f_n $ 使得对每个  $ t \in \mathbf{R} $ 均有  $ f(t) = (f_1(t), \ldots, f_n(t)) $。另外，对每个  $ t \in \mathbf{R} $，导数  $ f'(t) \in \mathbf{R}^n $ 定义为  $ f'(t) = (f_1'(t), \ldots, f_n'(t)) $。

27 设  $ u, v, w \in V $. 证明

 $$ \|w-\frac{1}{2}(u+\nu)\|^{2}=\frac{\|w-u\|^{2}+\|w-\nu\|^{2}}{2}-\frac{\|u-\nu\|^{2}}{4}. $$ 

28 设 $C$ 是 $V$ 的子集使得 $u, v \in C$ 蕴涵 $\frac{1}{2}(u + v) \in C$. 设 $w \in V$. 证明 $C$ 中距离 $w$ 最近的点至多有一个. 也就是说至多有一个点 $u \in C$ 使得对所有 $v \in C$ 均有 $\|w - u\| \leq \|w - v\|$.

提示：利用上题.

29 对于  $ u, v \in V $ 定义  $ d(u, v) = \|u - v\| $.

(a) 证明 d 是 V 上的一个度量.

(b) 证明若 V 是有限维的，则 d 是 V 上的完备度量（意思是每个柯西序列均收敛）.

(c) 证明 V 的每个有限维子空间都是 V 的（关于度量 d 的）闭子集.

30 固定正整数 n.  $ R^{n} $ 上二次可微函数 p 的拉普拉斯算子  $ \Delta p $ 是  $ R^{n} $ 上的函数，定义如下：

 $$ \Delta p=\frac{\partial^{2}p}{\partial x_{1}^{2}}+\cdots+\frac{\partial^{2}p}{\partial x_{n}^{2}}. $$ 

如果  $ \Delta p = 0 $，则称函数 p 是调和的.

 $ R^{n} $ 上的多项式是形如  $ x_{1}^{m_{1}}\cdots x_{n}^{m_{n}} $ 的函数的线性组合，其中  $ m_{1},\ldots,m_{n} $ 均为非负整数.

设  $ q $ 是  $ \mathbb{R}^n $ 上的多项式．证明：存在  $ \mathbb{R}^n $ 上的调和多项式  $ p $ 使得对每个满足  $ \|x\| = 1 $ 的  $ x \in \mathbb{R}^n $ 均有  $ p(x) = q(x) $．

对于这道习题，需要用到的关于调和函数的唯一一个事实是：若  $ p $ 是  $ \mathbb{R}^n $ 上的调和函数且对所有满足  $ \|x\| = 1 $ 的  $ x \in \mathbb{R}^n $ 均有  $ p(x) = 0 $，则  $ p = 0 $。