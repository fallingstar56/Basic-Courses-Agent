21 设 V 是有限维的，U 和 W 均为 V 的子空间且  $ W^0 \subset U^0 $。证明  $ U \subset W $。

22 设 U, W 均为 V 的子空间. 证明  $ (U + W)^{0} = U^{0} \cap W^{0} $.

23 设 V 是有限维的，且 U 和 W 均为 V 的子空间．证明  $ (U \cap W)^{0} = U^{0} + W^{0} $

24 使用 3.106 之前描述的想法证明 3.106.

25 设 V 是有限维的，且 U 是 V 的子空间．证明

 $$ U=\left\{\nu\in V: 对任意 \varphi\in U^{0} 均有 \varphi(\nu)=0\right\}. $$ 

26 设 V 是有限维的且  $ \Gamma $ 是  $ V' $ 的子空间. 证明

 $$ \Gamma=\{\nu\in V: 对任意 \varphi\in\Gamma 均有 \varphi(\nu)=0\}^{0}. $$ 

27 设  $ T \in \mathcal{L}(\mathcal{P}_{5}(\mathbf{R}), \mathcal{P}_{5}(\mathbf{R})) $ 且  $ null T' = \operatorname{span}(\varphi) $，这里  $ \varphi $ 是  $ \mathcal{P}_{5}(\mathbf{R}) $ 上的由  $ \varphi(p) = p(8) $ 定义的线性泛函．证明  $ range T = \{p \in \mathcal{P}_{5}(\mathbf{R}) : p(8) = 0\} $．

28 设  $ V $ 和  $ W $ 都是有限维的， $ T \in \mathcal{L}(V, W) $，且存在  $ \varphi \in W' $ 使得 null  $ T' = \text{span}(\varphi) $。证明 range  $ T = \text{null} \varphi $。

29 设 V 和 W 都是有限维的， $ T \in \mathcal{L}(V, W) $，且存在  $ \varphi \in V' $ 使得  $ \text{range } T' = \text{span}(\varphi) $。证明  $ \text{null } T = \text{null } \varphi $。

30 设 V 是有限维的， $ \varphi_{1},\ldots,\varphi_{m} $ 是  $ V' $ 中的一个线性无关组．证明

 $$ \dim\left(\left(\operatorname{n u l l}\varphi_{1}\right)\cap\cdots\cap\left(\operatorname{n u l l}\varphi_{m}\right)\right)=\left(\dim V\right)-m. $$ 

31 设 V 是有限维的， $ \varphi_{1},\ldots,\varphi_{n} $ 是  $ V' $ 的基．证明存在 V 的基使得其对偶基是  $ \varphi_{1},\ldots,\varphi_{n} $

32 设  $ T \in \mathcal{L}(V) $，并设  $ u_1, \ldots, u_n $ 和  $ v_1, \ldots, v_n $ 均为 V 的基．证明以下命题等价：

(a) T 是可逆的.

(b)  $ \mathcal{M}(T) $ 的诸列在  $ F^{n,1} $ 中是线性无关的.

(c)  $ \mathcal{M}(T) $ 的诸列张成  $ F^{n,1} $

(d)  $ \mathcal{M}(T) $ 的诸行在  $ F^{1,n} $ 中是线性无关的.

(e)  $ \mathcal{M}(T) $ 的诸行张成  $ F^{1,n} $

这里  $ \mathcal{M}(T) $ 表示  $ \mathcal{M}(T,(u_{1},\ldots,u_{n}),(v_{1},\ldots,u_{n})) $.

33 设 m 和 n 均为正整数．证明将 A 变为  $ A^{t} $ 的函数是从  $ F^{m,n} $ 到  $ F^{n,m} $ 的线性映射．进一步，证明这个线性映射是可逆的．