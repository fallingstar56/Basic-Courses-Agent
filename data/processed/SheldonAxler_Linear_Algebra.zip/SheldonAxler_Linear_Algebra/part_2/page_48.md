证明 因为每个  $ e_{j} $ 的范数都是 1，通过反复使用勾股定理 6.13 容易证得.

上述命题有如下重要推论.

### 6.26 规范正交组是线性无关的

每个规范正交向量组都是线性无关的.

证明 设  $ e_1, \ldots, e_m $ 是  $ V $ 中的规范正交向量组，并设  $ a_1, \ldots, a_m \in \mathbf{F} $ 使得

 $$ a_{1}e_{1}+\cdots+a_{m}e_{m}=0. $$ 

则  $ |a_1|^2 + \cdots + |a_m|^2 = 0 $（根据 6.25），这表明所有的  $ a_j $ 均为 0。因此  $ e_1, \ldots, e_m $ 是线性无关的。

6.27 定义 规范正交基（orthonormal basis）

V 的规范正交基是 V 中的规范正交向量组构成的基.

例如， $ F^{n} $ 的标准基是规范正交基.

### 6.28 适当长度的规范正交组是规范正交基

V 中每个长度为 dim V 的规范正交向量组都是 V 的规范正交基.

证明 由 6.26，任何这样的组都一定是线性无关的．又因为它具有适当的长度，所以它一定是基（见 2.39）．

6.29 例 证明

 $$ \left(\frac{1}{2},\frac{1}{2},\frac{1}{2},\frac{1}{2}\right),\left(\frac{1}{2},\frac{1}{2},-\frac{1}{2},-\frac{1}{2}\right),\left(\frac{1}{2},-\frac{1}{2},-\frac{1}{2},\frac{1}{2}\right),\left(-\frac{1}{2},\frac{1}{2},-\frac{1}{2},\frac{1}{2}\right) $$ 

是  $ F^{4} $ 的规范正交基.

证明 我们有

 $$ \left\|\left(\frac{1}{2},\frac{1}{2},\frac{1}{2},\frac{1}{2}\right)\right\|=\sqrt{\left(\frac{1}{2}\right)^{2}+\left(\frac{1}{2}\right)^{2}+\left(\frac{1}{2}\right)^{2}+\left(\frac{1}{2}\right)^{2}}=1. $$ 

类似地，上面的组中其余三个向量的范数也都是 1.

我们还有

 $$ \left\langle\left(\frac{1}{2},\frac{1}{2},\frac{1}{2},\frac{1}{2}\right),\left(\frac{1}{2},\frac{1}{2},-\frac{1}{2},-\frac{1}{2}\right)\right\rangle=\frac{1}{2}\cdot\frac{1}{2}+\frac{1}{2}\cdot\frac{1}{2}+\frac{1}{2}\cdot\left(-\frac{1}{2}\right)+\frac{1}{2}\cdot\left(-\frac{1}{2}\right)=0. $$ 

类似地，上面的组中任意两个不同的向量的内积都等于 0.

因此上面的组是规范正交的．由于这是四维向量空间  $ F^{4} $ 的一个长度为 4 的规范正交组，所以它是  $ F^{4} $ 的规范正交基（由于 6.28）.

一般地，给定  $ V $ 的基  $ e_1, \ldots, e_n $ 和向量  $ v \in V $，我们知道有标量  $ a_1, \ldots, a_n \in \mathbb{F} $ 使得