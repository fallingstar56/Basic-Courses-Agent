证明

 $$ \begin{align*}\left\|u+\nu\right\|^{2}&=\left\langle u+\nu,u+\nu\right\rangle\\&=\left\langle u,u\right\rangle+\left\langle u,\nu\right\rangle+\left\langle\nu,u\right\rangle+\left\langle\nu,\nu\right\rangle\\&=\left\|u\right\|^{2}+\left\|\nu\right\|^{2}.\end{align*} $$ 

上面给出的勾股定理证明表明，结论成立当且仅当  $ \langle u, v \rangle + \langle v, u \rangle = 0 $，即  $ 2 \operatorname{Re} \langle u, v \rangle = 0 $。因此勾股定理的逆命题在实内积空间中成立。

设  $ u, v \in V $ 且  $ v \neq 0 $ 。我们想把 u 写成 v 的标量倍加上一个正交于 v 的向量 w ，如左下图所示。



<div style="text-align: center;"><img src="imgs/img_in_image_box_77_428_285_771.jpg" alt="Image" width="22%" /></div>


为了揭示如何将 u 写成 v 的标量倍加上一个正交于 v 的向量，令  $ c \in \mathbf{F} $ 表示一个标量，则

 $$ \begin{align*}u=cv+(u-cv).\end{align*} $$ 

因此需要选取 c 使得 v 正交于  $ (u - cv) $. 也就是说，我们希望

正交分解

 $$ 0=\langle u-c\nu,\nu\rangle=\langle u,\nu\rangle-c\|\nu\|^{2}. $$ 

上式表明 c 应取成  $ \langle u, v \rangle / \|v\|^2 $。从而

 $$ u=\frac{\langle u,\nu\rangle}{\|\nu\|^{2}}\nu+\left(u-\frac{\langle u,\nu\rangle}{\|\nu\|^{2}}\nu\right). $$ 

上式把 u 写成了 v 的标量倍加上一个正交于 v 的向量（请自行验证）。也就是说，我们证明了以下命题。

6.14 正交分解

设  $ u, v \in V $ 且  $ v \neq 0 $。令  $ c = \frac{\langle u, v \rangle}{\|v\|^2} $， $ w = u - \frac{\langle u, v \rangle}{\|v\|^2}v $。则  $ \langle w, v \rangle = 0 $ 且  $ u = cv + w $。

1821 年，法国数学家奥古斯丁·路易·柯西（1789—1857）证明了6.17(a). 1886 年，德国数学家赫尔曼·施瓦茨（1843—1921）证明了6.17(b).

正交分解 6.14 将被用于证明下面的定理（柯西-施瓦茨不等式），它是数学中最重要的不等式之一.



### 6.15 柯西-施瓦茨不等式

设  $ u, v \in V $。则  $ |\langle u, v \rangle| \leq \|u\|\|v\| $。等号成立当且仅当  $ u, v $ 之一是另一个的标量倍。

证明 若 v = 0，则不等式的两端都等于 0. 因此可以假设  $ v \neq 0 $. 考虑 6.14 中给出的正交分解