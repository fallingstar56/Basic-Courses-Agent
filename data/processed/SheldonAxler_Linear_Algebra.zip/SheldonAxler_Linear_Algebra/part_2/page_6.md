## 多项式的零点

求解方程  $ p(z) = 0 $ 在多项式  $ p \in \mathcal{P}(\mathbf{F}) $ 的研究中起着至关重要的作用。因此这些解有一个特别的名字。

### 4.9 定义 多项式的零点（zero of a polynomial）

称数  $ \lambda \in \mathbf{F} $ 为多项式  $ p \in \mathcal{P}(\mathbf{F}) $ 的零点（或根），如果  $ p(\lambda) = 0 $.

### 4.10 定义 因式（factor）

称多项式  $  s \in \mathcal{P}(\mathbf{F})  $ 为多项式  $  p \in \mathcal{P}(\mathbf{F})  $ 的因式，如果存在多项式  $  q \in \mathcal{P}(\mathbf{F})  $ 使得  $  p = sq  $.

我们首先证明  $ \lambda $ 是多项式  $ p \in \mathcal{P}(\mathbf{F}) $ 的零点当且仅当  $ (z - \lambda) $ 是  $ p $ 的因式.

### 4.11 多项式的每个零点对应一个一次因式

设  $ p \in \mathcal{P}(\mathbf{F}) $， $ \lambda \in \mathbf{F} $。则  $ p(\lambda) = 0 $ 当且仅当存在多项式  $ q \in \mathcal{P}(\mathbf{F}) $ 使得对每个  $ z \in \mathbf{F} $ 均有  $ p(z) = (z - \lambda)q(z) $。

证明 证明的一个方面是显然的．即，假设存在多项式  $ q \in \mathcal{P}(\mathbf{F}) $ 使得对所有  $ z \in \mathbf{F} $ 均有  $ p(z) = (z - \lambda)q(z) $．则  $ p(\lambda) = (\lambda - \lambda)q(\lambda) = 0 $．

要证明另一个方面，设  $ p(\lambda) = 0 $。则多项式  $ z - \lambda $ 的次数为 1。由于次数小于 1 的多项式是常函数，所以多项式的带余除法 4.8 表明存在多项式  $ q \in \mathcal{P}(\mathbf{F}) $ 和数  $ r \in \mathbf{F} $ 使得对每个  $ z \in \mathbf{F} $ 均有

 $$ p(z)=(z-\lambda)q(z)+r. $$ 

上述等式以及  $ p(\lambda) = 0 $ 表明 r = 0. 于是对每个  $ z \in \mathbf{F} $ 均有  $ p(z) = (z - \lambda)q(z) $. 现在我们可以证明多项式不会有太多的零点.

### 4.12 多项式零点的个数不超过它的次数

设  $ p \in \mathcal{P}(\mathbf{F}) $ 是 m 次多项式， $ m \geq 0 $。则 p 在  $ \mathbf{F} $ 中最多有 m 个互不相同的零点。

证明 若 m = 0，则  $ p(z) = a_{0} \neq 0 $，因此 p 没有零点.

若 m=1，则  $ p(z)=a_{0}+a_{1}z $，其中  $ a_{1}\neq0 $，因此 p 恰有一个零点，即  $ -a_{0}/a_{1} $

现在设  $ m > 1 $。对  $ m $ 用归纳法，假设每个  $ m - 1 $ 次多项式最多有  $ m - 1 $ 个不同的零点。如果  $ p $ 在  $ \mathbf{F} $ 中没有零点，则结论成立。如果  $ p $ 有一个零点  $ \lambda \in \mathbf{F} $，则由 4.11 可知，存在一个多项式  $ q $ 使得对所有  $ z \in \mathbf{F} $ 均有

 $$ p(z)=(z-\lambda)q(z). $$ 