证明 除了最后一条，其余性质的验证留给读者．为了验证最后一条，我们有

 $$ \begin{aligned}|w+z|^{2}&=(w+z)(\bar{w}+\bar{z})\\&=w\bar{w}+z\bar{z}+w\bar{z}+z\bar{w}\\&=|w|^{2}+|z|^{2}+w\bar{z}+\overline{w\bar{z}}\\&=|w|^{2}+|z|^{2}+2\operatorname{Re}(w\bar{z})\\&\leq|w|^{2}+|z|^{2}+2|w\bar{z}|\\&=|w|^{2}+|z|^{2}+2|w||z|\\&=(|w|+|z|)^{2}.\end{aligned} $$ 

在不等式  $ |w + z|^2 \leq (|w| + |z|)^2 $ 两端取平方根，即得到所要证明的不等式.

## 多项式系数的唯一性

回忆一下，对于函数  $ p: \mathbf{F} \to \mathbf{F} $，若存在  $ a_0, \ldots, a_m \in \mathbf{F} $ 使得对所有  $ z \in \mathbf{F} $ 都有

4.6

 $$ p(z)=a_{0}+a_{1}z+a_{2}z^{2}+\cdots+a_{m}z^{m}, $$ 

则称函数 p 为系数在 F 中的多项式.

### 4.7 若一个多项式是零函数，则其所有系数均为 0

设  $ a_0, \ldots, a_m \in \mathbf{F} $. 若对任意  $ z \in \mathbf{F} $ 均有

 $$ \begin{align*}a_0+a_1z+\cdots+a_mz^m=0,\end{align*} $$ 

则  $ a_{0}=\cdots=a_{m}=0. $

证明 我们将证明逆否命题．如果并非所有系数均为 0，则通过改变 m 我们可以假定  $ a_{m} \neq 0 $．设

 $$ z=\frac{\left|a_{0}\right|+\left|a_{1}\right|+\cdots+\left|a_{m-1}\right|}{\left|a_{m}\right|}+1. $$ 

注意  $ z \geq 1 $，于是对  $ j = 0, 1, \ldots, m - 1 $ 有  $ z^j \leq z^{m-1} $。使用三角不等式，我们有

 $$ |a_{0}+a_{1}z+\cdots+a_{m-1}z^{m-1}|\leq(|a_{0}|+|a_{1}|+\cdots+|a_{m-1}|)z^{m-1}<|a_{m}z^{m}|. $$ 

于是  $ a_{0} + a_{1}z + \cdots + a_{m-1}z^{m-1} \neq -a_{m}z^{m} $ 。所以  $ a_{0} + a_{1}z + \cdots + a_{m-1}z^{m-1} + a_{m}z^{m} \neq 0 $ 。

上述结果表明多项式的系数是唯一确定的（因为若一个多项式有两组不同的系数，则该多项式的这两个表达式相减即与上述结果矛盾）.

回忆一下，若多项式 p 可以写成 4.6 的形式，其中  $ a_{m} \neq 0 $，则说 p 是 m 次的，记为  $ \deg p = m $.