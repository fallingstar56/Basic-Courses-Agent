项．根据 4.15， $ (x-\bar{\lambda}) $ 也是这个分解中的一项，但是 4.15 并没说这两个因子出现的次数相同，而这正是使上面的思路可行所必需的．不过，我们将证明这一点的确是成立的.

在下面的定理中，m 或 M 都可能等于 0. 数  $ \lambda_{1}, \ldots, \lambda_{m} $ 恰为 p 的实零点，因为它们是使得下面的等式右端等于 0 的唯一一组实数.

### 4.17 R 上多项式的分解

设  $ p \in \mathcal{P}(\mathbf{R}) $ 是非常数多项式．则  $ p $ 可以唯一分解（不计因子的次序）为

 $$ p(x)=c(x-\lambda_{1})\cdots(x-\lambda_{m})(x^{2}+b_{1}x+c_{1})\cdots(x^{2}+b_{M}x+c_{M}), $$ 

其中  $ c, \lambda_1, \ldots, \lambda_m, b_1, \ldots, b_M, c_1, \ldots, c_M \in \mathbb{R} $，并且对每个  $ j $ 均有  $ b_j^2 < 4c_j $。

证明 将 $p$ 视为 $\mathcal{P}(\mathbf{C})$ 中的元素．如果 $p$ 的所有（复）零点均为实数，则由 4.14 知结论成立．故设 $p$ 有一个零点 $\lambda \in \mathbf{C}$ 使得 $\lambda \notin \mathbf{R}$．由 4.15，$\bar{\lambda}$ 也是 $p$ 的零点．则有某个次数比 $p$ 低 2 次的多项式 $q \in \mathcal{P}(\mathbf{C})$ 使得

 $$ p(x)=(x-\lambda)(x-\bar{\lambda})q(x)=\left(x^{2}-2(\mathrm{Re}\lambda)x+|\lambda|^{2}\right)q(x). $$ 

如果我们能证明 q 是实系数的，那么通过对 p 的次数用归纳法就可以断定： $ (x - \lambda) $ 与  $ (x - \bar{\lambda}) $ 在 p 的分解中出现的次数一样多.

要证明  $ q $ 是实系数的，从上面的方程解出  $ q $ 可得，对所有  $ x \in \mathbb{R} $ 有

 $$ q(x)=\frac{p(x)}{x^{2}-2(\mathrm{Re}\lambda)x+|\lambda|^{2}}. $$ 

这表明对所有  $ x \in \mathbb{R} $ 均有  $ q(x) \in \mathbb{R} $。把 q 写成

 $$ q(x)=a_{0}+a_{1}x+\cdots+a_{n-2}x^{n-2}, $$ 

其中  $ n = \deg p $ 且  $ a_{0}, \ldots, a_{n-2} \in \mathbf{C} $，则对所有  $ x \in \mathbf{R} $ 有

 $$ 0=\mathrm{Im}q(x)=(\mathrm{Im}a_{0})+(\mathrm{Im}a_{1})x+\cdots+(\mathrm{Im}a_{n-2})x^{n-2}. $$ 

由此可得  $ \mathrm{Im}a_{0},\ldots,\mathrm{Im}a_{n-2} $ 均等于 0（由于 4.7）。因此 q 的所有系数都是实数，这就证明了分解的存在性。

现在考虑分解的唯一性问题．当  $ b_{j}^{2} < 4c_{j} $ 时，p 的形如  $ x^{2} + b_{j}x + c_{j} $ 的因式可以唯一地写成  $ (x - \lambda_{j})(x - \overline{\lambda_{j}}) $，其中  $ \lambda_{j} \in \mathbf{C} $．稍加思索便知，如果 p 作为  $ \mathcal{P}(\mathbf{R}) $ 中元素有两个不同的分解，那么 p 作为  $ \mathcal{P}(\mathbf{C}) $ 中元素也有两个不同的分解，与 4.14 矛盾．

## 习题 4

1 证明 4.5 中除最后一条之外的所有结论.

2 设  $ m $ 是正整数．集合  $ \{0\} \cup \{p \in \mathcal{P}(\mathbf{F}) : \deg p = m\} $ 是  $ \mathcal{P}(\mathbf{F}) $ 的子空间吗？