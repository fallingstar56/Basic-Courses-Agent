### 习题 5.C

1 设  $ T \in \mathcal{L}(V) $ 可对角化．证明  $ V = \text{null} T \oplus \text{range} T $．

2 证明上题的逆命题或给出反例.

3 设 $V$ 是有限维的且 $T \in \mathcal{L}(V)$．证明下列条件等价：
(a) $V = \text{null} T \oplus \text{range} T$；
(b) $V = \text{null} T + \text{range} T$；
(c) $\text{null} T \cap \text{range} T = \{0\}$．

4 举例说明如果去掉 “V 是有限维的” 这个假设，则上题的结论不再成立.

5 设 $V$ 是有限维的复向量空间且 $T \in \mathcal{L}(V)$。证明：$T$ 可对角化当且仅当对每个 $\lambda \in \mathbf{C}$ 有 $V = \text{null}(T - \lambda I) \oplus \text{range}(T - \lambda I)$。

6 设 V 是有限维的， $ T \in \mathcal{L}(V) $ 有  $ \dim V $ 个互异的本征值， $ S \in \mathcal{L}(V) $ 与 T 有相同的本征向量（未必相应于同一本征值）。证明 ST = TS。

7 设  $ T \in \mathcal{L}(V) $ 关于  $ V $ 的某个基有对角矩阵  $ A $， $ \lambda \in \mathbb{F} $。证明  $ \lambda $ 在  $ A $ 的对角线上恰好出现  $ \dim E(\lambda, T) $ 次。

8 设  $ T \in \mathcal{L}(\mathbf{F}^5) $ 且  $ \dim E(8, T) = 4 $。证明  $ (T - 2I) $ 或  $ (T - 6I) $ 是可逆的。

9 设  $ T \in \mathcal{L}(V) $ 是可逆的．证明对每个非零的  $ \lambda \in \mathbf{F} $ 均有  $ E(\lambda, T) = E\left(\frac{1}{\lambda}, T^{-1}\right) $

10 设 V 是有限维的且  $ T \in \mathcal{L}(V) $. 设  $ \lambda_1, \ldots, \lambda_m $ 是 T 的互异的非零本征值. 证明

 $$ \dim E(\lambda_{1},T)+\cdots+\dim E(\lambda_{m},T)\leq\dim range T. $$ 

11 证明例 5.40 中的结论.

12 设  $ R, T \in \mathcal{L}(\mathbf{F}^3) $，本征值均为 2, 6, 7。证明存在可逆算子  $ S \in \mathcal{L}(\mathbf{F}^3) $ 使得  $ R = S^{-1}TS $。

13 求  $ R, T \in \mathcal{L}(\mathbf{F}^4) $ 使得  $ R $ 和  $ T $ 均有本征值 2, 6, 7，均没有其他本征值，且不存在可逆算子  $ S \in \mathcal{L}(\mathbf{F}^4) $ 使得  $ R = S^{-1}TS $.

14 求  $ T \in \mathcal{L}(\mathbf{C}^3) $ 使得 6 和 7 是 T 的本征值，且 T 关于  $ C^3 $ 的任意基的矩阵都不是对角矩阵.

15 设  $ T \in \mathcal{L}(\mathbf{C}^3) $ 使得 6 和 7 是 T 的本征值，且 T 关于  $ C^3 $ 的任意基的矩阵都不是对角矩阵．证明存在  $ (x, y, z) \in \mathbf{C}^3 $ 使得  $ T(x, y, z) = (17 + 8x, \sqrt{5} + 8y, 2\pi + 8z) $．

16 斐波那契序列  $ F_{1}, F_{2}, \ldots $ 定义为

 $$ F_{1}=1,\quad F_{2}=1,\quad F_{n}=F_{n-2}+F_{n-1}\left(n\geq3\right). $$ 

定义  $ T \in \mathcal{L}(\mathbf{R}^2) $ 为  $ T(x, y) = (y, x + y) $.