提示：一个合理的推测是，要找的调和多项式  $  p  $ 形如  $  q + (1 - \|x\|^2) r  $，其中  $  r  $ 是多项式。在适当向量空间上定义算子  $  T  $：

 $$ T r=\Delta\big((1-\|x\|^{2})r\big), $$ 

再证  $ T $ 是单的，因此是满的，由此证明存在  $ \mathbf{R}^n $ 上的多项式  $ r $ 使得  $ q + (1 - \|x\|^2)r $ 是调和的.

31 使用内积证明阿波罗尼奥斯恒等式：在边长为 a, b, c 的三角形中，设 d 是长度为 c 的边的中点到对顶点的线段的长度．则

 $$ \begin{align*}a^2+b^2={1\over2}c^2+2d^2.\end{align*} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_573_285_868_638.jpg" alt="Image" width="32%" /></div>


### 6. B 规范正交基

### 6.23 定义 规范正交的（orthonormal）

• 如果一个向量组中每个向量的范数都是 1 且与其他向量正交，则称这个向量组是规范正交的.

· 也就是说，V 上的向量组  $ e_{1}, \ldots, e_{n} $ 是规范正交的，如果

 $$ \left\langle e_{j},e_{k}\right\rangle=\begin{cases}1,& 若 \;j=k,\\0,& 若 \;j\neq k.\end{cases} $$ 

6.24 例 规范正交组

(a)  $ F^{n} $ 的标准基是规范正交组.

(b) $ \left(\frac{1}{\sqrt{3}},\frac{1}{\sqrt{3}},\frac{1}{\sqrt{3}}\right),\left(-\frac{1}{\sqrt{2}},\frac{1}{\sqrt{2}},0\right) $是 $ F^{3} $中的规范正交组.

(c)  $ \left(\frac{1}{\sqrt{3}},\frac{1}{\sqrt{3}},\frac{1}{\sqrt{3}}\right),\left(-\frac{1}{\sqrt{2}},\frac{1}{\sqrt{2}},0\right),\left(\frac{1}{\sqrt{6}},\frac{1}{\sqrt{6}},-\frac{2}{\sqrt{6}}\right) $ 是  $ F^{3} $ 中的规范正交组.

下面的命题表明规范正交组特别容易处理.

### 6.25 规范正交线性组合的范数

若  $ e_1, \ldots, e_m $ 是  $ V $ 中的规范正交向量组，则对所有  $ a_1, \ldots, a_m \in \mathbf{F} $ 均有

 $$ \|a_{1}e_{1}+\cdots+a_{m}e_{m}\|^{2}=|a_{1}|^{2}+\cdots+|a_{m}|^{2}. $$ 