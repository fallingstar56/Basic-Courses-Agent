规定多项式 0 的次数为  $ -\infty $，很多结果就不再有例外。例如，即使 p = 0 也有  $ \deg(pq) = \deg p + \deg q $。

多项式 0 的次数规定为  $ -\infty $。必要时可以使用关于  $ -\infty $ 的显然算术。例如，对任意整数 m 有  $ -\infty < m $ 和  $ -\infty + m = -\infty $。



## 多项式的带余除法

若 p 和 s 是非负整数且  $ s \neq 0 $，则存在非负整数 q 和 r 使得

 $$ p=s q+r $$ 

且 r < s．上式可解释为 p 除以 s，得到了商 q 及余数 r．下面的任务是对多项式证明类似结果．

可将多项式的带余除法理解为多项式p除以s得到了余式r.

下面的结果通常称为带余除法，尽管这里的表述并不是一个真正的算法，而只是一个有用的命题。



回忆一下， $ \mathcal{P}(\mathbf{F}) $ 表示系数在 F 中的所有多项式构成的向量空间， $ \mathcal{P}_{m}(\mathbf{F}) $ 表示系数在 F 中的次数不超过 m 的所有多项式构成的  $ \mathcal{P}(\mathbf{F}) $ 的子空间.

下面的结果可以不使用线性代数的知识来证明，但这里给出的使用线性代数的证明对于一本线性代数教材是合适的。

### 4.8 多项式的带余除法

设  $ p, s \in \mathcal{P}(\mathbf{F}) $ 且  $ s \neq 0 $。则存在唯一的多项式  $ q, r \in \mathcal{P}(\mathbf{F}) $ 使得

 $$ p=sq+r $$ 

且  $ \deg r < \deg s. $

证明 设  $ n = \deg p $,  $ m = \deg s $. 若 n < m, 取 q = 0, r = p 即可. 于是我们可以假定  $ n \geq m $.

定义  $ T: \mathcal{P}_{n-m}(\mathbf{F}) \times \mathcal{P}_{m-1}(\mathbf{F}) \to \mathcal{P}_{n}(\mathbf{F}) $ 为

 $$ T(q,r)=s q+r. $$ 

容易验证 T 是线性映射．若  $ (q, r) \in \text{null} T $，则  $ sq + r = 0 $，这表明 q = 0 且 r = 0 （因为，否则  $ \deg sq \geq m $，sq 也就不可能等于 -r）．于是  $ \dim \text{null} T = 0 $ （这就证明了命题中的“唯一”性）．

由 3.76 我们有

 $$ \dim\left(P_{n-m}(\mathbf{F})\times\mathcal{P}_{m-1}(\mathbf{F})\right)=(n-m+1)+(m-1+1)=n+1. $$ 

线性映射基本定理 3.22 和上面的等式表明 dim range  $ T = n + 1 $，从而等于 dim  $ \mathcal{P}_n(\mathbf{F}) $。于是 range  $ T = \mathcal{P}_n(\mathbf{F}) $，因此存在  $ q \in \mathcal{P}_{n-m}(\mathbf{F}) $ 和  $ r \in \mathcal{P}_{m-1}(\mathbf{F}) $ 使得  $ p = T(q, r) = sq + r $。