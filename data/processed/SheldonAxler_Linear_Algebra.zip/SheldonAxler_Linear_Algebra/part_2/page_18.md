而，很容易看出 0 是 T 的唯一本征值，且 T 的所有本征向量都在 U 中．于是 W 并非在 T 下不变．
(c) 对于  $ (x, y) \in \mathbf{F}^2 $，我们有
 $$ 
(T/U)((x, y) + U) = T(x, y) + U = (y, 0) + U = 0 + U,
 $$ 
这里最后一个等号成立是因为  $ (y, 0) \in U $．上面的等式表明 T/U 是 0 算子．

### 习题 5.A

1 设  $ T \in \mathcal{L}(V) $，并设 U 是 V 的子空间.
(a) 证明：若  $ U \subset \text{null} T $ 则 U 在 T 下不变.
(b) 证明：若 range  $ T \subset U $ 则 U 在 T 下不变.
2 设  $ S, T \in \mathcal{L}(V) $ 使得 ST = TS. 证明 null S 在 T 下不变.
3 设  $ S, T \in \mathcal{L}(V) $ 使得 ST = TS. 证明 range S 在 T 下不变.
4 设  $ T \in \mathcal{L}(V) $ 且  $ U_1, \ldots, U_m $ 是 V 的在 T 下不变的子空间. 证明  $ U_1 + \cdots + U_m $ 在 T 下不变.
5 设  $ T \in \mathcal{L}(V) $. 证明 V 的任意一组在 T 下不变的子空间的交仍在 T 下不变.
6 证明或给出反例：若 V 是有限维的，U 是 V 的子空间且在 V 的每个算子下不变，则  $ U = \{0\} $ 或 U = V.
7 定义  $ T \in \mathcal{L}(\mathbf{R}^2) $ 为  $ T(x, y) = (-3y, x) $. 求 T 的本征值.
8 定义  $ T \in \mathcal{L}(\mathbf{F}^2) $ 为  $ T(w, z) = (z, w) $. 求 T 的所有本征值和本征向量.
9 定义  $ T \in \mathcal{L}(\mathbf{F}^3) $ 为  $ T(z_1, z_2, z_3) = (2z_2, 0, 5z_3) $. 求 T 的所有本征值和本征向量.
10 定义  $ T \in \mathcal{L}(\mathbf{F}^n) $ 为  $ T(x_1, x_2, x_3, \ldots, x_n) = (x_1, 2x_2, 3x_3, \ldots, nx_n) $.
(a) 求 T 的所有本征值和本征向量.
(b) 求 T 的所有不变子空间.
11 定义  $ T: \mathcal{P}(\mathbf{R}) \to \mathcal{P}(\mathbf{R}) $ 为  $ Tp = p' $. 求 T 的所有本征值和本征向量.
12 定义  $ T \in \mathcal{L}(\mathcal{P}_4(\mathbf{R})) $ 如下：对所有  $ x \in \mathbf{R} $ 有  $ (Tp)(x) = xp'(x) $. 求 T 的所有本征值和本征向量.
13 设 V 是有限维的， $ T \in \mathcal{L}(V) $ 且  $ \lambda \in \mathbf{F} $. 证明存在  $ \alpha \in \mathbf{F} $ 使得  $ |\alpha - \lambda| < \frac{1}{1000} $ 且  $ (T - \alpha I) $ 是可逆的.
14 设  $ V = U \oplus W $, 其中 U 和 W 均为 V 的非零子空间. 定义  $ P \in \mathcal{L}(V) $ 如下：对  $ u \in U $ 和  $ w \in W $ 有  $ P(u + w) = u $. 求 P 的所有本征值和本征向量.