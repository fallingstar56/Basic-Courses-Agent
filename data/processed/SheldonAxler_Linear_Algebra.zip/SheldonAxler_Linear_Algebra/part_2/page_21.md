这是符号 p 的新用法，因为我们把它作用于算子，而不仅仅作用于 F 的元素.

5.18 例 设  $ D \in \mathcal{L}(\mathcal{P}(\mathbf{R})) $ 是由  $ Dq = q' $ 定义的微分算子，p 是多项式  $ p(x) = 7 - 3x + 5x^2 $。则  $ p(D) = 7I - 3D + 5D^2 $。于是对每个  $ q \in \mathcal{P}(\mathbf{R}) $ 有  $ (p(D))q = 7q - 3q' + 5q'' $。

请自行验证，如果固定一个算子  $ T \in \mathcal{L}(V) $，则由  $ p \mapsto p(T) $ 所定义的从  $ \mathcal{P}(\mathbf{F}) $ 到  $ \mathcal{L}(V) $ 的函数是线性的。

5.19 定义 多项式的积（product of polynomials）

若  $ p, q \in \mathcal{P}(\mathbf{F}) $，则  $ pq \in \mathcal{P}(\mathbf{F}) $ 是如下定义的多项式：对  $ z \in \mathbf{F} $ 有  $ (pq)(z) = p(z)q(z) $.

下面我们将要证明：一个算子的任意两个多项式是交换的.

### 5.20 乘积性质

设  $ p, q \in \mathcal{P}(\mathbf{F}) $， $ T \in \mathcal{L}(V) $。则

(a)  $ (pq)(T) = p(T)q(T); $

(a) 成立是因为在用分配性质把多项式的乘积展开时，其中的符号是 z 还是 T 没有什么影响.

(b)  $  p(T) q(T) = q(T) p(T)  $.

证明

(a) 设  $ p(z)=\sum_{j=0}^{m}a_{j}z^{j} $， $ q(z)=\sum_{k=0}^{n}b_{k}z^{k} $，其中  $ z\in\mathbf{F} $。则

 $$ \begin{align*}(pq)(z)=\sum_{j=0}^m\sum_{k=0}^n a_j b_k z^{j+k}.\end{align*} $$ 

于是

 $$ (pq)(T)=\sum_{j=0}^{m}\sum_{k=0}^{n}a_{j}b_{k}T^{j+k}=\left(\sum_{j=0}^{m}a_{j}T^{j}\right)\left(\sum_{k=0}^{n}b_{k}T^{k}\right)=p(T)q(T). $$ 

(b) 因为 (a)，我们有  $ p(T)q(T) = (pq)(T) = (qp)(T) = q(T)p(T) $.

## 本征值的存在性

现在给出复向量空间上算子的中心结果之一.

### 5.21 复向量空间上的算子都有本征值

有限维非零复向量空间上的每个算子都有本征值.

证明 设 V 是 n 维复向量空间，n > 0，并设  $ T \in \mathcal{L}(V) $。取  $ v \in V $ 且  $ v \neq 0 $。因为 V 是 n 维的，所以  $ n + 1 $ 个向量