## 复共轭与绝对值

在讨论复系数或实系数多项式之前，我们需要多学一点复数知识。

4.2 定义 实部（real part），Re z、虚部（imaginary part），Im z
设  $ z = a + bi $，其中 a 和 b 均为实数.
• z 的实部（记作 Re z）定义为 Re z = a.
• z 的虚部（记作 Im z）定义为 Im z = b.

于是对每个复数 z 都有  $ z = \mathrm{Re}z + (\mathrm{Im}z)\mathrm{i} $.

4.3 定义 复共轭（complex conjugate），$\bar{z}$、绝对值（absolute value），$|z|$ 设 $z \in \mathbf{C}$.

- $z \in \mathbf{C}$ 的复共轭（记作 $\bar{z}$）定义为 $\bar{z} = \mathrm{Re} z - (\mathrm{Im} z) \mathrm{i}$.
- 复数 $z$ 的绝对值（记作 $|z|$）定义为 $|z| = \sqrt{(\mathrm{Re} z)^2 + (\mathrm{Im} z)^2}$.

4.4 例 设  $ z = 3 + 2i $. 则
• Re z = 3 且 Im z = 2;
•  $ \bar{z}=3-2i; $
•  $ |z|=\sqrt{3^{2}+2^{2}}=\sqrt{13}. $

请验证  $ z = \bar{z} $ 当且仅当 z 是实数.

注意：对于每个  $ z \in \mathbb{C} $， $ |z| $ 都是非负实数。

实部、虚部、复共轭和绝对值具有以下性质。

4.5 复数的性质

设  $ w, z \in \mathbf{C} $. 则

 $ z $ 与  $ \bar{z} $ 的和：  $ z + \bar{z} = 2 \text{Re} z $;

 $ z $ 与  $ \bar{z} $ 的差：  $ z - \bar{z} = 2 (\text{Im} z)i $;

 $ z $ 与  $ \bar{z} $ 的积：  $ z\bar{z} = |z|^2 $;

复共轭的可加性与可乘性：  $ \overline{w + z} = \bar{w} + \bar{z} $ 且  $ \overline{w}\bar{z} = \bar{w}\bar{z} $;

共轭的共轭：  $ \overline{\bar{z}} = z $;

实部与虚部有界于  $ |z| $：  $ |\text{Re} z| \leq |z| $ 且  $ |\text{Im} z| \leq |z| $;

复共轭的绝对值：  $ |z| = |z| $;

绝对值的可乘性：  $ |wz| = |w| |z| $;

三角不等式：  $ |w + z| \leq |w| + |z| $.

<div style="text-align: center;"><img src="imgs/img_in_image_box_546_1164_818_1320.jpg" alt="Image" width="30%" /></div>
