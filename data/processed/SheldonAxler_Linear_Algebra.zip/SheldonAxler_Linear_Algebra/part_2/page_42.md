 $$ u=\frac{\left\langle u,\nu\right\rangle}{\left\|\nu\right\|^{2}}\nu+w, $$ 

其中 w 正交于 v. 由勾股定理我们有

 $$ \begin{align*}\|u\|^{2}&=\left\|\frac{\langle u,\nu\rangle}{\|\nu\|^{2}}\nu\right\|^{2}+\|w\|^{2}\\&=\frac{|\langle u,\nu\rangle|^{2}}{\|\nu\|^{2}}+\|w\|^{2}\\&\geq\frac{|\langle u,\nu\rangle|^{2}}{\|\nu\|^{2}}.\end{align*} $$ 

6.16

在这个不等式两端都乘以  $ \|v\|^2 $，再开平方即得所要证的不等式.

从上一段的证明可以看出柯西-施瓦茨不等式成为等式当且仅当 6.16 是等式．显然，这成立当且仅当 w = 0．而 w = 0 当且仅当 u 是 v 的标量倍（参见 6.14）．因此，柯西-施瓦茨不等式是等式当且仅当 u 是 v 的标量倍或 v 是 u 的标量倍（或二者都成立．这样措辞是为了涵盖 u 或 v 等于 0 的情况）．

### 6.17 例 柯西-施瓦茨不等式的例子

(a) 若  $ x_1, \ldots, x_n, y_1, \ldots, y_n \in \mathbb{R} $，则

 $$ |x_{1}y_{1}+\cdots+x_{n}y_{n}|^{2}\leq(x_{1}{}^{2}+\cdots+x_{n}{}^{2})(y_{1}{}^{2}+\cdots+y_{n}{}^{2}). $$ 

(b) 若 f, g 均为  $ [-1,1] $ 上的实值连续函数，则

 $$ \left|\int_{-1}^{1}f(x)g(x)\mathrm{d}x\right|^{2}\leq\left(\int_{-1}^{1}\left(f(x)\right)^{2}\mathrm{d}x\right)\left(\int_{-1}^{1}\left(g(x)\right)^{2}\mathrm{d}x\right). $$ 

下面的命题称为三角不等式，它有如下的几何解释：三角形任意一边的长度小于另外两边的长度之和.

三角不等式表明两点之间的最短路线是直线.

<div style="text-align: center;"><img src="imgs/img_in_image_box_495_862_815_1045.jpg" alt="Image" width="35%" /></div>


### 6.18 三角不等式

设  $ u, v \in V $。则  $ \|u + v\| \leq \|u\| + \|v\| $。等号成立当且仅当  $ u, v $ 之一是另一个的非负标量倍。

证明 我们有

 $$ \begin{aligned}\left\|\boldsymbol{u}+\boldsymbol{\nu}\right\|^{2}&=\left\langle\boldsymbol{u}+\boldsymbol{\nu},\boldsymbol{u}+\boldsymbol{\nu}\right\rangle\\&=\left\langle\boldsymbol{u},\boldsymbol{u}\right\rangle+\left\langle\boldsymbol{\nu},\boldsymbol{\nu}\right\rangle+\left\langle\boldsymbol{u},\boldsymbol{\nu}\right\rangle+\left\langle\boldsymbol{\nu},\boldsymbol{u}\right\rangle\\&=\left\langle\boldsymbol{u},\boldsymbol{u}\right\rangle+\left\langle\boldsymbol{\nu},\boldsymbol{\nu}\right\rangle+\left\langle\boldsymbol{u},\boldsymbol{\nu}\right\rangle+\overline{\left\langle\boldsymbol{u},\boldsymbol{\nu}\right\rangle}\end{aligned} $$ 