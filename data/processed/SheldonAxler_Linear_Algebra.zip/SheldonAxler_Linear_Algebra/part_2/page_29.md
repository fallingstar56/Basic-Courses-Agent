### 5. C 本征空间与对角矩阵

5.34 定义 对角矩阵（diagonal matrix）
对角矩阵是对角线以外的元素全是0的方阵.

5.35 例

 $$ \left(\begin{array}{ccc}{{{8}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{5}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{5}}} \\\end{array}\right) $$ 

是对角矩阵.

显然每个对角矩阵都是上三角的，但是对角矩阵一般要比上三角矩阵有更多的0.

若一个算子关于某个基有对角矩阵，则对角线上的元素恰为该算子的本征值．这可由 5.32 得到（或直接给出一个对于对角矩阵的简单证明）．

5.36 定义 本征空间（eigenspace）， $ E(\lambda,T) $

设  $ T \in \mathcal{L}(V) $ 且  $ \lambda \in \mathbf{F} $。 $ T $ 的相应于  $ \lambda $ 的本征空间（记作  $ E(\lambda,T) $）定义为

 $ E(\lambda,T) = \text{null}(T - \lambda I) $.

也就是说， $ E(\lambda,T) $ 是  $ T $ 的相应于  $ \lambda $ 的全体本征向量加上 0 向量构成的集合。

对于  $ T \in \mathcal{L}(V) $ 和  $ \lambda \in \mathbf{F} $，本征空间  $ E(\lambda, T) $ 是 V 的子空间（因为 V 上每个线性映射的零空间都是 V 的子空间）。由定义可知  $ \lambda $ 是 T 的本征值当且仅当  $ E(\lambda, T) \neq \{0\} $。

5.37 例 设算子  $ T \in (V) $ 关于 V 的基  $ v_{1}, v_{2}, v_{3} $ 的矩阵是上面例 5.35 中的矩阵．则  $ E(8, T) = \operatorname{span}(v_{1}), \quad E(5, T) = \operatorname{span}(v_{2}, v_{3}). $

若  $ \lambda $ 是  $ T \in \mathcal{L}(V) $ 的本征值，则 T 限制到  $ E(\lambda, T) $ 上恰为  $ \lambda $ 确定的标量乘算子.

### 5.38 本征空间之和是直和

设 V 是有限维的， $ T \in \mathcal{L}(V) $。设  $ \lambda_1, \ldots, \lambda_m $ 是 T 的互异的本征值。则

 $$ E(\lambda_{1},T)+\cdots+E(\lambda_{m},T) $$ 

是直和。此外，

 $$ \dim E(\lambda_{1},T)+\cdots+\dim E(\lambda_{m},T)\leq\dim V. $$ 