常微分方程解的结构，只需要再求得方程(2)所对应的非齐次方程(1)的一个特解，便可以得到方程(1)的通解.

一般情况下，可以应用常数变易法根据齐次方程(2)的通解求得方程(1)的一个特解。但是这种方法在计算上常常会较烦琐。这里我们介绍另一种方法：比较系数法。如果方程(1)的非齐次项具有下列形式：

 $$ f(x)=P_{m}(x)e^{kx}, $$ 

其中  $ \lambda $ 是（实或复）常数， $ P_{m}(x) $ 是 m 阶多项式，则可以用比较系数的方法求得方程(1)的一个特解。下面就二阶方程的情形说明这种方法。

考虑右端为(5)式中函数的二阶常系数线性方程：

 $$ y^{\prime \prime}+a y^{\prime}+b y=P_{m}(x)\mathrm{e}^{\lambda x}, $$ 

注意到(5)式中函数为一个多项式与  $ e^{ix} $ 的乘积，这样形状的函数经过求有限阶导数后仍然是一个多项式与  $ e^{ix} $ 的乘积。因此我们猜想方程(6)应该有这样形状的解。假定

 $$ Y(x)=Q(x)\mathrm{e}^{\lambda x} $$ 

是方程(6)的解，其中 $ Q(x) $是待定多项式.我们需要确定 $ Q(x) $的阶数与系数.

 $$ \begin{align*}Y^{\prime}(x)&=Q^{\prime}(x)\mathrm{e}^{\lambda x}+\lambda Q(x)\mathrm{e}^{\lambda x},\\Y^{\prime \prime}(x)&=Q^{\prime \prime}(x)\mathrm{e}^{\lambda x}+2\lambda Q^{\prime}(x)\mathrm{e}^{\lambda x}+\lambda^{2}Q(x)\mathrm{e}^{\lambda x}.\end{align*} $$ 

将  $ Y(x) $,  $ Y'(x) $,  $ Y''(x) $ 代入方程 (6) 并整理得

 $$ Q^{\prime \prime}(x)+(2\lambda+a)Q^{\prime}(x)+(\lambda^{2}+a\lambda+b)Q(x)=P_{m}(x), $$ 

显然， $ Y(x)=Q(x)e^{kx} $ 是方程（6）的解当且仅当（7）式成立，因此，（7）式左端的多项式应为 m 阶.

## 情形 1

 $ \lambda $ 不是特征方程  $ \lambda^{2} + a\lambda + b = 0 $ 的根，此时  $ \lambda^{2} + a\lambda + b \neq 0 $。如果取  $ Q(x) = Q_{m} $ (x) 为 m 阶多项式，则 (7) 式左端亦是一个 m 阶多项式。

## 情形 2

λ 是特征方程  $ \lambda^{2} + a\lambda + b = 0 $ 的单根，此时  $ \lambda^{2} + a\lambda + b = 0 $，但是  $ 2\lambda + a \neq 0 $。为使(7)式左端是一个 m 阶多项式，只需取  $ Q(x) = xQ_{m}(x) $ 为  $ m + 1 $ 阶多项式（常数项为零）。

## 情形 3

λ 是特征方程  $ \lambda^{2} + a\lambda + b = 0 $ 的二重根，此时  $ \lambda^{2} + a\lambda + b = 0 $，并且  $ 2\lambda + a = 0 $。为使(7)式左端是一个 m 阶多项式，只需取  $ Q(x) = x^{2}Q_{m}(x) $ 为  $ m + 2 $ 阶多项式。

在上述三种情形下， $ Q_{m}(x) $ 都是一个具有  $ m+1 $ 个待定系数的 m 阶多项式。通过比较等式（7）两端多项式的系数，即可确定  $ Q_{m}(x) $ 的  $ m+1 $ 个系数，从而得到方程（6）的一个特解  $ Y(x)=Q(x)\mathrm{e}^{kx} $.

对于右端为(5)式中函数  $ f(x)=P_{m}(x)\mathrm{e}^{\lambda x} $ 的 n 阶常系数非齐次线性方程