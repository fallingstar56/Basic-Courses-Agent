是复系数多项式. 如果  $ P_{m}(x)=S(x)-\mathrm{i}T(x) $，其中  $ S(x) $ 与  $ T(x) $ 是不超过 m 阶的实系数多项式，并且  $ \lambda=\alpha+\mathrm{i}\beta $ 为方程（1）的  $ k(0\leqslant k\leqslant n) $ 重特征根，那么方程（1）有形如  $ Y(x)=x^{k}Q_{m}(x)\mathrm{e}^{ix} $ 的特解，其中  $ Q_{m}(x)=U(x)-\mathrm{i}V(x) $ 也是复系数多项式， $ U(x) $ 与  $ V(x) $ 是不超过 m 阶的实系数多项式. 注意到

 $$ \mathrm{R e}f(x)=\mathrm{R e}\big[P_{m}(x)\mathrm{e}^{\lambda x}\big]=\mathrm{e}^{\alpha x}\big[S(x)\cos\beta x+T(x)\sin\beta x\big], $$ 

根据命题 7.5.1,  $ Y(x) $ 的实部

 $$ \bar{y}(x)=\mathrm{Re}Y(x)=x^{k}\mathrm{e}^{ax}\left[U(x)\cos\beta x+V(x)\sin\beta x\right] $$ 

就是下列方程的解：

 $$ y^{(n)}+a_{1}y^{(n-1)}+\cdots+a_{n-1}y^{\prime}+a_{n}y=\mathrm{e}^{\alpha x}\left[S(x)\cos\beta x+T(x)\sin\beta x\right]. $$ 

也就是说，在上述条件下，方程(11)具有形如(10)式中函数的特解。

求解方程  $ y'' - y = 2x\cos x - 2(x - 2)\sin x. $

解 原方程的特征根为  $ \lambda=\pm1 $。由于 i 不是方程的特征根，故可设原方程有形如  $ Y(x)=(Ax+B)\cos x+(Cx+D)\sin x $ 的特解。将它代入原方程得到

 $ -2(C-B-Ax)\cos x-2(A+D+Cx)\sin x=2x\cos x-2(x-2)\sin x. $

比较两端系数得 A=D=-1, B=C=1, 于是  $ Y(x)=(1-x)\cos x+(x-1)\sin x. $

所以原方程的通解为  $ y(x)=C_{1}e^{x}+C_{2}e^{-x}+(1-x)\cos x+(x-1)\sin x. $

#### ▶ 例 7.5.8

长 19.6m 的均匀链条悬挂在高处一个无摩擦的小滑轮上。运动开始时一端长 10.8m，另一端长 8.8m。问链条滑过滑轮需要多长时间？

解 设经过时刻 x，链条下滑了 y 米。记重力加速度为 g，链条的线密度为  $ \rho $，则在 x 时刻链条受到的向下的力为

 $$ F=(10,8+y)\rho g-(8,8-y)\rho g=(2+2y)\rho g. $$ 

另一方面， $ F=ma=19.6\rho y^{\prime\prime} $，所以  $ y=y(x) $ 满足下列方程：

 $$ 19.6\rho y^{\prime \prime}=(2+2y)\rho g, $$ 

即 $ g=9.8\,m/s^{2} $

 $$ y^{\prime \prime}-y=1. $$ 

显然， $ y(x)\equiv-1 $ 是此方程的一个特解。方程的特征根是  $ \lambda=\pm1 $，从而方程的通解为  $ y(x)=C_{1}\mathrm{e}^{x}+C_{2}\mathrm{e}^{-x}-1 $。注意到  $ y(0)=y^{\prime}(0)=0 $，即  $ C_{1}+C_{2}=1 $， $ C_{1}-C_{2}=0 $，于是  $ C_{1}=C_{2}=1/2 $，所以  $ y(x)=\frac{1}{2}\mathrm{e}^{x}+\frac{1}{2}\mathrm{e}^{-x}-1 $。

当链条滑过滑轮时，y=8.8m，所用时间x满足

 $$ \frac{1}{2}\mathrm{e}^{x}+\frac{1}{2}\mathrm{e}^{-x}-1=8.8, $$ 

解之得  $ x=\ln(9.8+\sqrt{(9.8)^{2}-1})\approx2.97 $ 。所以链条滑过滑轮所用时间为2.97s。