4. 判断下列积分的敛散性.

(1) $ \int_{1}^{+\infty}\frac{\arctan x}{x^{2}}dx; $

(2) $ \int_{1}^{+\infty}\frac{\arctan\frac{1}{x}}{x^{2}}dx; $

(3) $ \int_{2}^{+\infty}\frac{\sin x}{x\sqrt{x^{2}+1}}dx; $

(4) $ \int_{1}^{+\infty}\frac{\cos x^{2}}{x}dx; $

(5) $ \int_{1}^{+\infty}\frac{\sqrt{1+x^{-1}}-1}{x^{p}\ln(1+x^{-2})}\mathrm{d}x; $

(6) $ \int_{0}^{1}\frac{1}{\sqrt{x-x^{3}}}dx; $

(7) $ \int_{-2}^{0}\frac{1}{x-\sin x}dx; $

(8)  $ \int_{0}^{\frac{\pi}{2}}\ln\cos x\,dx $;

(9) $ \int_{0}^{\frac{\pi}{2}}\frac{1-\cos x}{x^{n}}dx; $

(10) $ \int_{0}^{1}\frac{\sqrt{x}}{\mathrm{e}^{\sin x}-1}\mathrm{d}x; $

11)  $ \int_{1}^{2}\frac{1}{\ln x}dx; $

(12) $ \int_{0}^{1}\frac{\ln x}{1-x}dx. $

5. 讨论下列积分的敛散性（其中  $ p > 0, q > 0 $）.

(1) $ \int_{0}^{+\infty}\frac{\ln x}{x^{2}}dx; $

(2) $ \int_{0}^{+\infty}\frac{\ln(1+x^{2})}{x^{p}}dx; $

(3) $ \int_{0}^{+\infty}\frac{1}{x^{p_{0}}(x-1)^{p_{1}}(x-2)^{p_{2}}}\mathrm{d}x; $

 $$ \int_{0}^{+\infty}\frac{\sin x}{\sqrt{x^{3}}}\mathrm{d}x; $$ 

(5) $ \int_{0}^{+\infty}\frac{x^{p}\arctan x}{1+x^{q}}dx; $

(6)  $ \int_{3}^{+\infty}\frac{1}{x^{p}(\ln x)^{q}(\ln\ln x)^{r}}dx; $

(7)  $ \int_{0}^{\frac{\pi}{2}} |\ln\sin x|^{\frac{1}{p}}dx $;

(8) $ \int_{1}^{+\infty}\frac{1}{x^{p}+(\ln x)^{q}}dx; $

(9) $ \int_{1}^{+\infty}\frac{1-\cos\sqrt{2x}-\sin x}{x^{p}}dx; $

(10) $ \int_{1}^{+\infty}\frac{\mathrm{d}x}{x^{p}\sqrt{\ln x}}; $



(11) $ \int_{0}^{\frac{\pi}{2}}\frac{1}{\sin^{p}x\cos^{q}x}dx; $

(12) $ \int_{1}^{+\infty}\left[\ln\left(1+\frac{1}{x}\right)-\frac{1}{x+1}\right]\mathrm{d}x; $

(13) $ \int_{0}^{+\infty}\frac{dx}{x^{p}+x^{q}}; $

(14) $ \int_{1}^{+\infty}\ln\left(\sin\frac{1}{x}+\cos\frac{1}{x}\right)dx; $

(15) $ \int_{0}^{1}x^{p-1}(1-x)^{q-1}\ln x\,dx. $

6.  $ f(x) $,  $ g(x) $ 在任意  $ [a, A] $ ( $ A > a $) 上可积， $ \int_{a}^{+\infty} f^{2}(x) \, dx $， $ \int_{a}^{+\infty} g^{2}(x) \, dx $ 都收敛，证明：

(1) $ \int_{a}^{+\infty}f(x)g(x)dx $ 绝对收敛； (2) $ \int_{a}^{+\infty}(f(x)+g(x))^{2}dx $ 收敛.

7. 设  $ f(x) $ 在任意闭区间  $ [a, A] $ ( $ A > a $) 上可积，且  $ g(x) \leqslant f(x) \leqslant h(x) (x \geqslant a) $. 求证：若广义积分  $ \int_{a}^{+\infty} g(x) \, dx $ 与  $ \int_{a}^{+\infty} h(x) \, dx $ 都收敛，则广义积分  $ \int_{a}^{+\infty} f(x) \, dx $