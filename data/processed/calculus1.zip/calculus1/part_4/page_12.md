 $$ \int_{a}^{+\infty}f(x)g(x)\mathrm{d}x=\int_{a}^{+\infty}f(x)\big[g(x)-b\big]\mathrm{d}x+b\int_{a}^{+\infty}f(x)\mathrm{d}x $$ 

收敛.

#### ▶ 例 6.2.4

判别下列广义积分的收敛性.

(1) $ \int_{1}^{+\infty}\frac{(-1)^{[x]}}{x-\ln x}dx $; (2) $ \int_{2}^{+\infty}\frac{\sin x}{\ln x}dx $; (3) $ \int_{2}^{+\infty}\frac{\sin x}{\ln x}\arctan x dx $.

解 (1)  $ x - \ln x $ 在  $ [1, +\infty) $ 上单调且  $ \lim_{x \to +\infty} \frac{1}{x - \ln x} = 0 $. 另一方面，

 $$ \left|\int_{1}^{A}(-1)^{[x]}\mathrm{d}x\right|\leqslant\left|\sum_{k=1}^{[A]-1}(-1)^{k}\right|+\left|A-\left[A\right]\right|\leqslant2. $$ 

应用狄利克雷判别法即得广义积分 $ \int_{1}^{+\infty}\frac{(-1)^{[x]}}{x-\ln x}dx $收敛.

(2) $ \ln x $ 在 $ [2,+\infty) $ 上单调且 $ \lim_{x\to+\infty}\frac{1}{\ln x}=0 $. 另一方面，

 $$ \left|\int_{2}^{A}\sin x\mathrm{d}x\right|=\left|\cos2-\cos A\right|\leqslant2. $$ 

应用狄利克雷判别法，广义积分 $ \int_{2}^{+\infty}\frac{\sin x}{\ln x}dx $收敛.

(3) 由(2)，广义积分  $ \int_{2}^{+\infty}\frac{\sin x}{\ln x}dx $ 收敛，而  $ \arctan x $ 在  $ [2,+\infty) $ 单调有界，应用阿贝尔判别法，广义积分  $ \int_{2}^{+\infty}\frac{\sin x}{\ln x}\arctan xdx $ 收敛.

#### 6.2.2 瑕积分收敛性的判定

对瑕积分的情形，其收敛性的判别与无穷限广义积分的情形有完全相应的结果，并且这些判别法的证明也是类似的。因此下面只列出关于瑕积分收敛性的主要概念与判别法，读者可以完全仿照无穷限广义积分的情形给出证明。此外，为叙述方便，我们只讨论右端点b为瑕点的情形，对于左端点a为瑕点的情形也是完全类似的。

#### 定理 6.2.7（柯西收敛原理）

设  $ f $ 在  $ [a, b) $ 上定义，在  $ b $ 点附近无界，并且  $ \forall \delta \in (0, b-a) $，有  $ f \in R[a, b-\delta] $，则取积分  $ \int_a^b f(x) \, dx $ 收敛的充分必要条件是： $ \forall \varepsilon > 0 $，存在  $ \delta \in (0, b-a) $，只要  $ \delta > \delta_1 > \delta_2 > 0 $，就有

 $$ \left|\int_{b-\delta_{1}}^{b-\delta_{2}}f(x)\mathrm{d}x\right|<\varepsilon. $$ 