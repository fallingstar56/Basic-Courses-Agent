同理，当  $ \beta>0 $ 时，取积分  $ \int_{\frac{1}{2}}^{1}x^{\alpha-1}(1-x)^{\beta-1}dx $ 收敛，否则发散。所以，当  $ \alpha>0 $ 且  $ \beta>0 $ 时取积分  $ \int_{0}^{1}x^{\alpha-1}(1-x)^{\beta-1}dx $ 收敛，否则发散。

由上述广义积分所定义的函数

 $$ \mathrm{B}(\alpha,\beta)=\int_{0}^{1}x^{\alpha-1}\left(1-x\right)^{\beta-1}\mathrm{d}x\quad(\alpha>0,\beta>0) $$ 

是以  $ \alpha,\beta $ 为自变量的二元函数，称为 B 函数（读作 Beta 函数），或称为第一类欧拉积分.

讨论广义积分  $ \Gamma(\alpha)=\int_{0}^{+\infty}x^{a-1}\mathrm{e}^{-x}\mathrm{d}x $ 的收敛性.

解 由于取积分  $ \int_{0}^{1}x^{a-1}dx $ 当  $ \alpha>0 $ 时收敛， $ \alpha\leqslant0 $ 时发散，并且

 $$ \lim_{x\to0^{+}}\frac{x^{a-1}\mathrm{e}^{-x}}{x^{a-1}}=1 $$ 

根据定理 6.2.9 便知，当  $ \alpha > 0 $ 时，取积分  $ \int_{0}^{1} x^{a-1} e^{-x} dx $ 收敛，否则发散.

另一方面，无穷限积分 $ \int_{1}^{+\infty}x^{-2}dx $收敛，并且

 $$ \lim_{x\to+\infty}\frac{x^{\alpha-1}\mathrm{e}^{-x}}{x^{-2}}=\lim_{x\to+\infty}\frac{x^{\alpha+1}}{\mathrm{e}^{x}}=0. $$ 

由定理 6.2.3 便知  $ \int_{1}^{+\infty}x^{a-1}e^{-x}dx $ 收敛. 所以当 a>0 时, 广义积分  $ \int_{0}^{+\infty}x^{a-1}e^{-x}dx $ 收敛.

由上述广义积分定义的函数  $ \Gamma(\alpha) $ 称为  $ \Gamma $ 函数（读作 Gamma 函数）或第二类欧拉积分.

以后我们还将进一步研究第一类与第二类欧拉积分的性质.

### 习题 6.2

1. 证明定理 6.2.3 的(2)式，并考虑  $ C = +\infty $ 时会有什么结论.

2. 证明：定理 6.2.7，定理 6.2.8，定理 6.2.9.

3. 设  $ \forall a, A \in \mathbb{R} $ 且  $ a < A, f \in R[a, A] $. 下列命题是否成立？为什么？

(1) 若极限  $ \lim_{A\to+\infty}\int_{-A}^{A}f(x)dx $ 存在，则广义积分  $ \int_{-\infty}^{+\infty}f(x)dx $ 收敛.

(2) 若极限  $ \lim_{A\to+\infty}\int_{-A}^{A}\left|f(x)\right|\mathrm{d}x $ 存在，则广义积分  $ \int_{-\infty}^{+\infty}f(x)\mathrm{d}x $ 收敛.