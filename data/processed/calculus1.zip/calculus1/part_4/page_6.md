5. 设  $ F(x) $ 是  $ f(x) $ 在  $ [a, +\infty) $ 的一个原函数，极限  $ \lim_{x \to +\infty} F(x) = F(+\infty) $ 存在，则积分  $ \int_{a}^{+\infty} f(x) \, dx $ 收敛，并且有  $ \int_{a}^{+\infty} f(x) \, dx = F(+\infty) - F(a) $ (N-L 公式) 成立.

6. 设  $ u(x) $,  $ v(x) $ 在任何区间  $ [a, A] $ ( $ A > a $) 可积， $ \int_{a}^{+\infty} v(x) \, \mathrm{d}u(x) $ 收敛， $ \lim_{x \to +\infty} u(x)v(x) $ 存在，则  $ \int_{a}^{+\infty} u(x) \, \mathrm{d}v(x) $ 也收敛，并且  $ \int_{a}^{+\infty} v(x) \, \mathrm{d}u(x) = u(x)v(x)\bigg|_{a}^{+\infty} - \int_{a}^{+\infty} u(x) \, \mathrm{d}v(x) $ (分部积分).

7. 求曲线  $ y=\frac{1}{\sqrt{x}}(0<x\leqslant1) $， $ y=\frac{1}{x^{2}}(x\geqslant1) $，x 轴和 y 轴围成的图形面积.

### 6.2 广义积分收敛性的判定

在很多情况下，按定义通过计算广义积分的值来判定它的收敛性会很困难，因此寻找其他方法来判定一个广义积分的收敛性是一个重要问题。

#### 6.2.1 无穷限广义积分收敛性的判定

定理 6.2.1（柯西收敛原理）

设  $ f $ 在  $ [a, +\infty) $ 上定义，并且对任意  $ A > a, f \in R[a, A] $，则广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 收敛的充分必要条件是： $ \forall \varepsilon > 0 $，存在实数  $ M > a $，只要  $ A_2 > A_1 > M $，就有

 $$ \left|\int_{A_{1}}^{A_{2}}f(x)\mathrm{d}x\right|<\varepsilon. $$ 

证明 令  $  F(t) = \int_{a}^{t} f(x) \, dx, t \geqslant a  $，则广义积分  $  \int_{a}^{+\infty} f(x) \, dx  $ 收敛即为极限  $  \lim_{t \to +\infty} F(t)  $ 存在。再由函数极限存在的柯西收敛原则（定理 2.3.4）可得，广义积分  $  \int_{a}^{+\infty} f(x) \, dx  $ 收敛，即极限  $  \lim_{t \to +\infty} F(t)  $ 存在的充分必要条件是： $  \forall \varepsilon > 0  $，存在实数 M > a，只要  $  A_{2} > A_{1} > M  $，就有

 $$ \left|\int_{A_{1}}^{A_{2}}f(x)\mathrm{d}x\right|=\left|F(A_{2})-F(A_{1})\right|<\varepsilon. $$ 

应用定理 6.2.1 立即可得下列命题：