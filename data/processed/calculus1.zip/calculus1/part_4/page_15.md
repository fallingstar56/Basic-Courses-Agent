根据定理 6.2.9 可知取积分  $ \int_{0}^{1}-x^{-p}\ln x dx $ 收敛，从而原取积分收敛.

（3）由例6.2.5中已知，取积分 $ \int_{0}^{1}\frac{1}{x}\sin\frac{1}{x}dx $收敛.而函数 $ \cos x $在区间 $ (0,1) $上单调有界，根据阿贝尔判别法（定理6.2.11）即得原取积分收敛.

设 p>0. 讨论广义积分  $ \int_{0}^{+\infty}\frac{\ln(1+x)}{x^{p}}dx $ 的收敛性.

解 原积分收敛，当且仅当下面两个积分同时收敛：

 $$ \int_{0}^{1}\frac{\ln(1+x)}{x^{p}}\mathrm{d}x,\quad\int_{1}^{+\infty}\frac{\ln(1+x)}{x^{p}}\mathrm{d}x. $$ 

对于前者，注意到

 $$ \lim_{x\to0^{+}}x^{p-1}\frac{\ln(1+x)}{x^{p}}=1, $$ 

以及取积分 $ \int_{0}^{1}\frac{dx}{x^{p-1}} $当p-1<1时收敛， $ p-1\geqslant1 $时发散.根据定理6.2.9，取积分 $ \int_{0}^{1}\frac{\ln(1+x)}{x^{p}}dx $当p<2时收敛， $ p\geqslant2 $时发散.

对于无穷限积分 $ \int_{1}^{+\infty}\frac{\ln(1+x)}{x^{p}}dx $，显然当 $ 0<p\leqslant1 $时发散，而当p>1时，取 $ q\in(1,p) $.注意到 $ \int_{1}^{+\infty}\frac{dx}{x^{q}} $收敛并且

 $$ \lim_{x\to+\infty}x^{q}\cdot\frac{\ln(1+x)}{x^{p}}=0, $$ 

根据定理 6.2.3 便知积分  $ \int_{1}^{+\infty}\frac{\ln(1+x)}{x^{p}}dx $ 当 p>1 时收敛.

综上所述，当1<p<2时，原广义积分收敛，否则发散。

考察积分  $ \mathrm{B}(\alpha,\beta)=\int_{0}^{1}x^{\alpha-1}(1-x)^{\beta-1}\mathrm{d}x $ 的收敛性.

解 由于取积分  $ \int_{0}^{1}x^{a-1}dx $ 当且仅当  $ \alpha>0 $ 时收敛，并且

 $$ \lim_{x\to0^{+}}\frac{x^{a-1}(1-x)^{\beta-1}}{x^{a-1}}=1. $$ 

根据定理 6.2.9 便知，当  $ \alpha > 0 $ 时，取积分  $ \int_{0}^{\frac{1}{2}} x^{\alpha-1} (1 - x)^{\beta-1} dx $ 收敛，否则发散.