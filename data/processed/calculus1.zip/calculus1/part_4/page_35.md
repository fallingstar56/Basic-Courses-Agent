所以 $ \frac{p(x)}{x}-x=C $，即 $ y'(x)=p(x)=x^{2}+Cx $。进而知原方程的通解为

 $$ y=\frac{1}{3}x^{3}+C_{1}x^{2}+C_{2}. $$ 

#### 7.3.2 不显含自变量 x 的方程

为简单起见，这里只讨论二阶方程的情形。对于形如

 $$ y^{\prime \prime}=F(y,y^{\prime}) $$ 

的二阶常微分方程，可以令  $ y'(x)=p(y(x)) $，此时 p 是 y 的函数，从而

 $$ y^{\prime \prime}(x)=\frac{\mathrm{d}}{\mathrm{d}x}p(y)=\frac{\mathrm{d}p}{\mathrm{d}y}\bullet\frac{\mathrm{d}y}{\mathrm{d}x}=p\frac{\mathrm{d}p}{\mathrm{d}y}. $$ 

代入方程(4)可得 p 满足下列方程：

 $$ p\frac{\mathrm{d}p}{\mathrm{d}y}=F(y,p). $$ 

这是一个关于未知函数 p 与自变量 y 的一阶常微分方程。如果  $ p = p(y) $ 为方程（5）的解，则由  $ y'(x) = p(y(x)) $ 便可得到方程（4）的解。

▶ 例 7.3.4 ……

求解方程  $ yy''=2(y')^{2} $

解 令  $ y' = p $，并将 p 看作 y 的函数： $ p = p(y) $，则  $ y''(x) = p \frac{\mathrm{d}p}{\mathrm{d}y} $，从而原方程化为

 $$ y\frac{\mathrm{d}p}{\mathrm{d}y}=2p. $$ 

解之得  $ p=-C_{1}y^{2} $，因而  $ y'=-C_{1}y^{2} $，即  $ -y^{-2}dy=C_{1}dx. $ 积分之，得到  $ \frac{1}{y}=C_{1}x+ $

 $ C_{2} $. 所以原方程的通解为  $ y=\frac{1}{C_{1}x+C_{2}} $

习题 7.3

求解下列微分方程.

(1) $ y''=2x-\cos x,y(0)=1,y'(0)=-1; $

(2)

 $$ x y^{\prime\prime}+(y^{\prime})^{2}-y^{\prime}=0,y(1)=1-\ln2,y^{\prime}(1)=\frac{1}{2}; $$ 

(3) $ y''=3\sqrt{y},y(0)=1,y'(0)=2; $

(4)

 $$ (1+x^{2})y^{\prime \prime}-2xy^{\prime}=0 $$ 

(5)

 $$ y^{\prime \prime}+\frac{2}{1-y}(y^{\prime})^{2}=0; $$ 