收敛.

8. 广义积分 $ \int_{a}^{+\infty}f(x)dx $收敛，若 $ \lim_{x\to+\infty}f(x)=0 $存在，证明： $ \lim_{x\to+\infty}f(x)=0. $

9. 考察下列积分的绝对收敛性与条件收敛性.

(1)  $ \int_{0}^{+\infty}\sin x^{2}dx $; (2)  $ \int_{0}^{+\infty}x\cos x^{3}dx $;

(3) $ \int_{1}^{+\infty}x\left(\arctan\frac{2}{x}-\arctan\frac{1}{x}\right)dx; $ (4) $ \int_{0}^{+\infty}\frac{\sqrt{x}\sin x}{x+1}dx; $

(5) $ \int_{0}^{+\infty}x^{p}\sin x^{q}dx. $

## 第 6 章 总复习题

1.  $ f(x) $ 在任何有界区间内可积，若极限  $ \lim_{A\to+\infty}\int_{-A}^{A}f(t)dt $ 存在，则称广义积分  $ \int_{-\infty}^{+\infty}f(x)dx $ 在柯西主值意义下收敛，记为 P. V.  $ \int_{-\infty}^{+\infty}f(x)dx=\lim_{A\to+\infty}\int_{-A}^{A}f(t)dt $.

(1) 考察  $ \int_{-\infty}^{+\infty} f(x) \, dx $ 收敛与 P. V.  $ \int_{-\infty}^{+\infty} f(x) \, dx $ 收敛的关系；

(2) 计算 P, V.  $ \int_{-\infty}^{+\infty}\frac{2x+1}{x^{2}+1}dx $.

(3) 设 f 仅有一个瑕点  $ c \in (a, b) $，试写出积分  $ \int_{a}^{b} f(x) \, dx $ 在柯西主值意义下收敛的定义.

2. 判断下列积分的敛散性.

(1) $ \int_{0}^{+\infty}\frac{\sin^{2}x}{x^{p}}dx; $ (2) $ \int_{0}^{\frac{\pi}{2}}\cos x\ln(\tan x)dx. $

3. 判断广义积分  $ \int_{1}^{+\infty}\sin x\sin\frac{1}{x}dx $ 的绝对收敛性与条件收敛性.

4. 设  $ f(x)=0 $

5. 设  $ f(x) $ 在  $ [a, +\infty) $ 一致连续，广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 收敛，证明： $ \lim_{x \to +\infty} f(x) = 0. $

6. 利用广义积分收敛的柯西收敛准则证明： $ f(x) $ 单调， $ \int_{a}^{+\infty}f(x)dx $ 收敛，则

 $$ f(x)=o(1/x)(x\rightarrow+\infty) $$ 

7. 混合型广义积分  $ \int_{0}^{+\infty}\frac{x\ln x}{(1+x^{2})^{2}}dx $ 的计算过程中，能否利用分部积分公式？通过本题，可以得出计算混合型广义积分时，使用分部积分公式需要满足什