#### 命题 6.2.1

设  $ f $ 在  $ [a, +\infty) $ 上定义，并且对任意  $ A > a, f \in R[a, A] $。如果广义积分  $ \int_{a}^{+\infty} |f(x)| \, dx $ 收敛，则广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 收敛。

证明  $ \forall\varepsilon>0 $ ，由于  $ \int_{a}^{+\infty}\left|f(x)\right|\mathrm{d}x $ 收敛，根据定理 6.2.1，存在 M>a ，只要  $ A_{2}>A_{1}>M $ ，就有

 $$ \int_{A_{1}}^{A_{2}}\left|f(x)\right|\mathrm{d}x<\varepsilon. $$ 

由此得到

 $$ \left|\int_{A_{1}}^{A_{2}}f(x)\mathrm{d}x\right|\leqslant\int_{A_{1}}^{A_{2}}\mid f(x)\mid\mathrm{d}x<\varepsilon. $$ 

再次应用定理 6.2.1 便知广义积分  $ \int_{a}^{+\infty}f(x)dx $ 收敛.

设  $ f $ 在  $ [a, +\infty) $ 上定义，对任意  $ A > a $， $ f \in R[a, A] $。

(1) 如果广义积分  $ \int_{a}^{+\infty}\left|f(x)\right|dx $ 收敛，则称广义积分  $ \int_{a}^{+\infty}f(x)dx $ 绝对收敛.

(2) 如果  $ \int_{a}^{+\infty} f(x) \, dx $ 收敛，但是  $ \int_{a}^{+\infty} |f(x)| \, dx $ 发散，则称广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 条件收敛.

根据命题 6.2.1，如果广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 绝对收敛，则必收敛.

▶ 例 6.2.1

设  $ \alpha > 0 $. 讨论广义积分  $ \int_{1}^{+\infty} \frac{\sin x}{x^{a}} dx $ 与  $ \int_{1}^{+\infty} \frac{\cos x}{x^{a}} dx $ 的收敛性与绝对收敛性.

解 任取  $ A_{2} > A_{1} > 1 $，应用分部积分法，

 $$ \begin{aligned}\left|\int_{A_{1}}^{A_{2}}\frac{\sin x}{x^{\alpha}}\mathrm{d}x\right|&=\left|-\frac{\cos x}{x^{\alpha}}\right|_{A_{1}}^{A_{2}}-\alpha\int_{A_{1}}^{A_{2}}\frac{\cos x}{x^{\alpha+1}}\mathrm{d}x\Big|\\&\leqslant\frac{1}{A_{1}^{\alpha}}+\frac{1}{A_{2}^{\alpha}}+\alpha\int_{A_{1}}^{A_{2}}\frac{\mathrm{d}x}{x^{\alpha+1}}=\frac{2}{A_{1}^{\alpha}}.\end{aligned} $$ 

于是， $ \forall\varepsilon>0 $（不妨设 $ \varepsilon<2 $），若取 $ M=\left(\frac{2}{\varepsilon}\right)^{1/\alpha} $，只要 $ A_{2}>A_{1}>M $就有

 $$ \left|\int_{A_{1}}^{A_{2}}\frac{\sin x}{x^{a}}\mathrm{d}x\right|\leqslant\frac{2}{A_{1}^{a}}<\epsilon. $$ 

根据定理 6.2.1 便知广义积分  $ \int_{1}^{+\infty}\frac{\sin x}{x^{a}}dx $ 收敛.