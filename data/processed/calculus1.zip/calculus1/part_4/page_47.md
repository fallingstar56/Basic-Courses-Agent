(1)，上述方法依然有效. 我们不加证明地给出下面结论：

如果  $ \lambda $ 是特征方程  $ \lambda^{n} + a_{1}\lambda^{n-1} + \cdots + a_{n-1}\lambda + a_{n} = 0 $ 的  $ k (0 \leqslant k \leqslant n) $ 重根，则方程(1)具有形如  $ Y(x) = x^{k}Q_{m}(x)e^{kx} $ 的特解，其中  $ Q_{m}(x) $ 是一个（具有  $ m+1 $ 个待定系数的）m 阶多项式.

将  $ Y(x)=x^{k}Q_{m}(x)e^{kx} $ 代入方程(1)，整理并约去公因子  $ e^{kx} $ 后，通过比较等式两端多项式的系数，即可确定  $ Q_{m}(x) $ 的  $ m+1 $ 个系数.

求方程  $ y'' - 2y' + y = 6(x + 1)e^{x} $ 的通解.

解 此方程的特征方程为  $ \lambda^{2}-2\lambda+1=0 $，它有二重根  $ \lambda=1 $，故可设原方程有形如  $ Y(x)=x^{2}(Ax+B)e^{x} $ 的特解，将它代入原方程得到： $ (6Ax+2B)e^{x}=6(x+1)e^{x} $。比较两端系数可得 A=1, B=3，于是原方程有特解  $ Y(x)=x^{2}(x+3)e^{x} $。所以原方程的通解为  $ y(x)=\left[C_{1}+C_{2}x+x^{2}(x+3)\right]e^{x} $。

求解方程  $ y'' - y'' - y' + y = 4(x + 1)\cos x. $

解 根据欧拉公式, $ 4(x+1)e^{ix}=4(x+1)\cos x+i4(x+1)\sin x. $ 考虑方程

 $$ y^{\prime \prime \prime}-y^{\prime \prime}-y^{\prime}+y=4(x+1)\mathrm{e}^{ix}. $$ 

方程(8)的特征根为  $ \lambda_{1}=\lambda_{2}=1,\lambda_{3}=-1 $ ，由于 i 不是方程(8)的特征根，故可设方程(8)有形如  $ Y(x)=(Ax+B)e^{ix} $ 的特解. 将它代入方程(8)得到

 $$ \left[2(1-\mathrm{i})(A x+B)-2A(2+\mathrm{i})\right]\mathrm{e}^{\mathrm{i}x}=4(x+1)\mathrm{e}^{\mathrm{i}x}. $$ 

比较两端系数得  $ A=1+\mathrm{i}, B=3\mathrm{i} $. 于是方程(8)有特解  $ Y(x)=\left[(1+\mathrm{i})x+3\mathrm{i}\right]\mathrm{e}^{\mathrm{i}x} $. 根据命题 7.5.1,  $ Y(x) $ 的实部  $ \mathrm{Re}Y(x)=x\cos x-(x+3)\sin x $ 为原方程的解. 所以原方程的通解为  $ y(x)=C_{1}\mathrm{e}^{x}+C_{2}x\mathrm{e}^{x}+C_{3}\mathrm{e}^{-x}+x\cos x-(x+3)\sin x $.

求解方程  $ y^{(4)} + y'' = 10e^{x} \sin x. $

解 考虑方程

 $$ y^{(4)}+y^{\prime \prime}=10\mathbf{e}^{(1+\mathrm{i})x}. $$ 

它的特征根为  $ \lambda_{1}=\lambda_{2}=0,\lambda_{3}=i,\lambda_{4}=-i $ 。由于  $ 1+i $ 不是方程（9）的特征根，故可设方程（9）有形如  $ Y(x)=Ae^{(1+i)x} $ 的解。将它代入方程（9）得到  $ \left[(1+i)^{4}+(1+i)^{2}\right]Ae^{(1+i)x}=10e^{(1+i)x} $ 。比较两端系数得 A=-2-i 。于是方程（9）有特解

 $$ Y(x)=-\left(2+\mathrm{i}\right)\mathrm{e}^{(1+\mathrm{i})x}=\mathrm{e}^{x}\big[(\sin x-2\cos x)-\mathrm{i}(\cos x+2\sin x)\big]. $$ 

根据命题 7.5.1,  $ Y(x) $ 的虚部  $ \mathrm{Im}Y(x) = -\mathrm{e}^{x}(\cos x + 2\sin x) $ 为原方程的解. 所以原方程的通解为： $ y(x) = C_{1} + C_{2}x + C_{3}\sin x + C_{4}\cos x - \mathrm{e}^{x}(\cos x + 2\sin x) $.

由以上讨论可以看到，上述方法允许方程右端  $ f(x)=P_{m}(x)\mathrm{e}^{kx} $ 中的  $ P_{m}(x) $