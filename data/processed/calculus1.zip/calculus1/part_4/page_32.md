 $$ \frac{1}{1-\alpha}z^{\prime}+p(x)z=q(x). $$ 

这是一个一阶线性常微分方程，求得此方程的解  $ z = z(x) $ 之后，便得到方程（7）的解  $ y(x) = z(x)^{\frac{1}{1-x}} $.

#### ▶ 例 7.2.12

求解方程  $ y' - y + 2\frac{x}{y} = 0. $

解 这是一个伯努利方程, $ \alpha=-1 $. 令 $ z=y^{2} $，则 $ z^{\prime}=2yy^{\prime} $. 于是原方程可化为

 $ z^{\prime}-2z+4x=0. $

(8)

它对应的齐次方程为  $ z' = 2z $. 解之得  $ z = C e^{2x} $.

设方程(8)有解  $ z=C(x)e^{2x} $，将其代入方程(8)，可得  $ C'(x)=-4xe^{-2x} $，于是  $ C(x)=(2x+1)e^{-2x}+C. $ 从而方程(8)的通解为  $ z=Ce^{2x}+2x+1 $.

所以原方程的通解为

 $$ y^{2}=C\mathrm{e}^{2x}+2x+1. $$ 

### 习题 7.2

1. 求解下列微分方程.

(1)  $ (1-x)dy = (1+y)dx $; (2)  $ x(1-y) + (y+xy)y = 0 $;

(3)  $ (x^{2}-x^{2}y)dy+(y^{2}+xy^{2})dx=0 $;

(4)  $ 3x dy - y(2 - x \cos x)dx = 0 $;

(5)  $ \cos x \cos y dy - \sin x \sin y dx = 0 $; (6)  $ (e^{x+y} - e^{x})dx + (e^{x+y} + e^{y})dy = 0 $;

(7) $ \frac{dy}{dx}=\sqrt{xy} $; (8) $ (x+1)\frac{dy}{dx}=x(y^{2}+1) $;

(9) $ \frac{dy}{dx}=\sqrt{y}\cos^{2}\sqrt{y} $; (10) $ (1+e^{x})y y' = e^{x}, y(1) = 1 $;

(11)  $ 2\cos ydx=(x^{2}-1)\sin ydy,y\left(\frac{1}{2}\right)=\frac{\pi}{3}. $

2. 求解下列微分方程.

(1)  $ \frac{dy}{dx}-2y=\cos x $; (2)  $ \frac{dy}{dx}+5y=e^{x} $;

 $$ x\mathrm{d}y+y\mathrm{d}x=\sin x\mathrm{d}x； $$ 

 $$ y^{\prime}+xy=x^{3},y(0)=0 $$ 

 $$ xy^{\prime}+3y=\frac{1}{x^{2}}\sin x; $$ 

 $$ \sin\theta\frac{\mathrm{d}r}{\mathrm{d}\theta}+r\cos\theta=\tan\theta,-\frac{\pi}{2}<\theta<\frac{\pi}{2} $$ 

(7) $ \begin{cases}(x+1)y'-2(x^{2}+x)y=\frac{e^{x^{2}}}{x+1},(x>-1),\\y(0)=5.\end{cases} $