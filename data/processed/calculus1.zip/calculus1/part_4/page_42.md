 $$ Y^{(k)}=c_{1}y_{1}^{(k)}+\cdots+c_{n}y_{n}^{(k)}\quad(k=0,1,\cdots,n-1), $$ 

 $$ \begin{array}{r}{Y^{(n)}=c_{1}y_{1}^{(n)}+\cdots+c_{n}y_{n}^{(n)}+c_{1}^{\prime}y_{1}^{(n-1)}+\cdots+c_{n}^{\prime}y_{n}^{(n-1)}.}\end{array} $$ 

将  $ Y, Y^{\prime}, \cdots, Y^{(n)} $ 代入方程(1)，并注意到  $ y_{1}(x), \cdots, y_{n}(x) $ 为方程(2)的解，整理后可得

 $$ c_{1}^{\prime}y_{1}^{(n-1)}+\cdots+c_{n}^{\prime}y_{n}^{(n-1)}=f(x). $$ 

考虑方程(17)与方程(18)联立所成的方程组，其系数行列式恰为  $ W[y_{1}, y_{2}, \cdots, y_{n}] $。由于  $ y_{1}(x), \cdots, y_{n}(x) $ 线性无关，故  $ W(x) = W[y_{1}, y_{2}, \cdots, y_{n}](x) \neq 0 $，从而由上述方程组可以解出  $ c_{1}^{\prime}(x) \cdots, c_{n}^{\prime}(x) $。再积分即得  $ c_{1}(x), \cdots, c_{n}(x) $，从而得到方程(1)的特解  $ Y(x) $。

### 习题 7.4

1. 设  $ y_{1}(x) $,  $ y_{2}(x) $ 分别是线性微分方程

 $$ \begin{aligned}&y^{(n)}+a_{n-1}(x)y^{(n-1)}+\cdots+a_{1}(x)y^{\prime}+a_{0}(x)y=f(x),\\&y^{(n)}+a_{n-1}(x)y^{(n-1)}+\cdots+a_{1}(x)y^{\prime}+a_{0}(x)y=g(x)\\ \end{aligned} $$ 

的解，证明： $ k_{1}y_{1}(x)+k_{2}y_{2}(x) $为下列方程的解：

 $$ y^{(n)}+a_{n-1}(x)y^{(n-1)}+\cdots+a_{1}(x)y^{\prime}+a_{0}(x)y=k_{1}f(x)+k_{2}g(x). $$ 

2. 设  $ f(x) $ 是以 T 为周期的连续函数， $ y = \varphi(x) $ 是方程  $ \frac{dy}{dx} + y = f(x) $ 的解，且满足  $ \varphi(T) = \varphi(0) $，求证： $ \varphi(x) $ 是以 T 为周期的周期函数.

3. 证明：非齐次微分方程

 $$ y^{(n)}+a_{1}(x)y^{(n-1)}+\cdots+a_{n-1}(x)y^{\prime}+a_{n}(x)y=f(x) $$ 

存在且最多存在 $ (n+1) $个线性无关的解.

4. 设  $ y_{1}(x) $,  $ y_{2}(x) $,  $ y_{3}(x) $ 为线性非齐次微分方程  $ y'' + a_{1}(x)y' + a_{2}(x)y = f(x) $ 的三个特解，在什么条件下，由这三个特解可以写出非齐次微分方程的通解？通解的表达式又是什么？

5. 求解下列微分方程. $ (n $ 阶线性齐次微分方程的  $ n $ 个线性无关的解也称为基本解. $ ) $

(1) 验证  $ e^{x} $ 为  $ \frac{d^{2}y}{dx^{2}}-2\frac{dy}{dx}+y=0 $ 的解，并求方程  $ \frac{d^{2}y}{dx^{2}}-2\frac{dy}{dx}+y=\frac{e^{x}}{x} $ 的通解.

(2) 验证 x 为  $ \frac{1}{2}x^{2}\frac{d^{2}y}{dx^{2}}-x\frac{dy}{dx}+y=0 $ 的解，并求方程  $ \frac{1}{2}x^{2}\frac{d^{2}y}{dx^{2}}-x\frac{dy}{dx}+y=x^{3} $ 的通解.

(3) 验证  $ e^{x}, e^{-x} $ 为  $ \frac{d^{2}y}{dx^{2}} - y = 0 $ 的基本解，并求方程  $ \frac{d^{2}y}{dx^{2}} - y = \cos x $ 的通解.