解（1）令  $ f(x)=\frac{x^{2}}{e^{x}+x} $， $ g(x)=\frac{1}{x^{2}} $，则

 $$ \lim_{x\to+\infty}\frac{f(x)}{g(x)}=\lim_{x\to+\infty}\frac{x^{4}}{e^{x}+x}=0. $$ 

由于 $ \int_{1}^{+\infty}\frac{dx}{x^{2}} $收敛，再由定理6.2.3即知广义积分 $ \int_{1}^{+\infty}\frac{x^{2}dx}{e^{x}+x} $收敛.

(2) 令  $ f(x)=\frac{\ln x}{\sqrt{x^{3}+2x+1}} $,  $ g(x)=\frac{1}{\sqrt[4]{x^{5}}} $. 则应用洛必达法则可得

 $$ \lim_{x\to+\infty}\frac{f(x)}{g(x)}=\lim_{x\to+\infty}\frac{\sqrt[4]{x^{5}}\ln x}{\sqrt{x^{3}+2x+1}}\leqslant\lim_{x\to+\infty}\frac{\ln x}{\sqrt[4]{x}}=\lim_{x\to+\infty}\frac{4}{\sqrt[4]{x}}=0. $$ 

由于 $ \int_{1}^{+\infty}\frac{dx}{\sqrt[4]{x^{5}}} $收敛，再由定理6.2.3即知广义积分 $ \int_{1}^{+\infty}\frac{\ln x}{\sqrt{x^{3}+2x+1}}dx $收敛.

(3) 令  $ f(x)=\frac{1}{x(\ln x+9)} $,  $ g(x)=\frac{1}{x\ln x} $, 则

 $$ \lim_{x\to+\infty}\frac{f(x)}{g(x)}=\lim_{x\to+\infty}\frac{\ln x}{(\ln x+9)}=1. $$ 

由于 $ \int_{2}^{+\infty}\frac{dx}{x\ln x} $发散（例6.1.4），再由定理6.2.3即知广义积分 $ \int_{2}^{+\infty}\frac{dx}{x(\ln x+9)} $发散.

从上面讨论不难看到，比较判别法只适用于判定一个广义积分是否绝对收敛，而对于条件收敛的情形则失效。下面我们将建立两个适用于判定广义积分条件收敛性的判别法——狄利克雷判别法与阿贝尔判别法。为此，我们首先需要下述定理：

定理 6.2.4（积分第二中值定理）

设  $ f \in R[a, b] $， $ g $ 在  $ [a, b] $ 上单调，则存在  $ \xi \in [a, b] $ 使得

 $$ \int_{a}^{b}f(x)g(x)\mathrm{d}x=g(a)\int_{a}^{\xi}f(x)\mathrm{d}x+g(b)\int_{\xi}^{b}f(x)\mathrm{d}x. $$ 

这个定理的严格证明已经超出了本课程的要求，这里只对  $ f \in C[a, b] $， $ g' \in C[a, b] $ 的特殊情形给予证明。

证明 令  $  F(x) = \int_{a}^{x} f(t) \, dt  $，应用分部积分法可得

 $$ \int_{a}^{b}f(x)g(x)\mathrm{d}x=F(x)g(x)\mid_{a}^{b}-\int_{a}^{b}F(x)g^{\prime}(x)\mathrm{d}x. $$ 

由于 g 在  $ [a, b] $ 上单调，故  $ g'(x) $ 不变号。根据积分第一中值定理，存在  $ \xi \in [a, b] $，使得

 $$ \int_{a}^{b}F(x)g^{\prime}(x)\mathrm{d}x=F(\xi)\int_{a}^{b}g^{\prime}(x)\mathrm{d}x. $$ 