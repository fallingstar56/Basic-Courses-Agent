#### ▶ 例 6.1.5

计算广义积分 $ \int_{-\infty}^{+\infty}\frac{dx}{e^{x}+e^{2-x}} $

解

 $$ \begin{aligned}\int_{1}^{+\infty}\frac{\mathrm{d}x}{\mathrm{e}^{x}+\mathrm{e}^{2-x}}&=\lim_{A\rightarrow+\infty}\int_{1}^{A}\frac{\mathrm{d}x}{\mathrm{e}^{2-x}\left[\mathrm{e}^{2x-2}+1\right]}=\frac{1}{\mathrm{e}}\lim_{A\rightarrow+\infty}\int_{1}^{A}\frac{\mathrm{e}^{x-1}\mathrm{d}x}{(\mathrm{e}^{x-1})^{2}+1}\\&=\frac{1}{\mathrm{e}}\lim_{A\rightarrow+\infty}\arctan\mathrm{e}^{x-1}\bigg|_{1}^{A}=\frac{\pi}{4\mathrm{e}},\end{aligned} $$ 

 $$ \int_{-\infty}^{1}\frac{\mathrm{d}x}{\mathrm{e}^{x}+\mathrm{e}^{2-x}}=\frac{1}{\mathrm{e}}\lim_{A\to-\infty}\int_{A}^{1}\frac{\mathrm{e}^{x-1}\mathrm{d}x}{(\mathrm{e}^{x-1})^{2}+1}=\left.\frac{1}{\mathrm{e}}\lim_{A\to-\infty}\arctan\mathrm{e}^{x-1}\right|_{A}^{1}=\frac{\pi}{4}\mathrm{e}, $$ 

所以

 $$ \int_{-\infty}^{+\infty}\frac{\mathrm{d}x}{\mathrm{e}^{x}+\mathrm{e}^{2-x}}=\frac{\pi}{2\mathrm{e}}. $$ 

#### 6.1.2 瑕积分

无界函数在有界区间上的广义积分称为瑕积分.

定义 6.1.2

设函数 f 在  $ [a, b) $ 上定义，在 b 点附近无界（这时称 x = b 是 f 的一个瑕点），并且对任意的  $ \delta \in (0, b - a) $， $ f \in R[a, b - \delta] $。如果当  $ \delta \to 0^{+} $ 时，下列极限存在：

 $$ \lim_{a\to0^{+}}\int_{a}^{b-a}f(x)dx=I, $$ 

则称 f 在  $ [a,b) $ 上的瑕积分收敛，称极限值 I 为 f 在  $ [a,b) $ 上的瑕积分（值），记作

 $$ \int_{a}^{b}f(x)\mathrm{d}x=\lim_{\delta\to0^{+}}\int_{a}^{b-\delta}f(x)\mathrm{d}x. $$ 

如果极限  $ \lim_{\delta\to0^{+}}\int_{a}^{b-\delta}f(x)dx $ 不存在，则称瑕积分  $ \int_{a}^{b}f(x)dx $ 发散.

如果 f 在点 a 附近无界，并且  $ \forall \delta \in (0, b-a) $ 有  $ f \in R[a+\delta, b] $，则可以类似地定义 f 在  $ (a, b] $ 上的瑕积分  $ \int_{a}^{b} f(x) \, dx $ 的收敛与发散。此时 x=a 为瑕点。

▶ 例 6.1.6

计算  $ \int_{0}^{1}\ln x \, dx $.

解 x=0 为瑕点，依定义，

 $$ \int_{0}^{1}\ln x\mathrm{d}x=\lim_{\delta\to0^{+}}\int_{\delta}^{1}\ln x\mathrm{d}x=\lim_{\delta\to0^{+}}(x\ln x-x)\mid_{\delta}^{1}=-1. $$ 