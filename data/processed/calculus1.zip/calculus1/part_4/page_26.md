解 将方程改写为

 $$ \mathrm{e}^{y}\mathrm{d}y=\mathrm{e}^{x}\mathrm{d}x, $$ 

两端积分可得原方程的通解为  $ e^{y}=e^{x}+C $ 或  $ y=\ln(e^{x}+C) $.

▶ 例 7.2.2 ……

求解初值问题  $ \left\{\begin{aligned}y^{\prime}&=y^{2}\cos x,\\ y(0)&=1.\end{aligned}\right. $

解 将方程  $ y' = y^{2} \cos x $ 改写为

 $$ y^{-2}\mathrm{d}y=\cos x\mathrm{d}x, $$ 

两端积分可得它的通解为

 $$ -1/y=\sin x+C. $$ 

代入初值条件  $ y(0)=1 $，得到 C=-1。于是所求特解为

 $$ y=\frac{1}{1-\sin x}. $$ 

#### ▶ 例 7.2.3

求方程  $ y'=\frac{-xy}{x+1} $ 的通解.

解 将方程改写为

 $$ \frac{\mathrm{d}y}{y}=\frac{-x}{x+1}\mathrm{d}x, $$ 

两端积分可得原方程的通解为

 $$ \ln\mid y\mid=\ln\mid x+1\mid-x+C_{1}, $$ 

两边去对数得到

 $$ \mid y\mid=\mathrm{e}^{c_{1}}\mid x+1\mid\mathrm{e}^{-x}. $$ 

两边再去绝对值，注意到  $ y \equiv 0 $ 也是原方程的解，即得原方程的通解为

 $$ y=C(x+1)\mathrm{e}^{-x}. $$ 

#### 7.2.2 可化为变量分离型的常微分方程

有些方程虽然本身不是变量分离型方程，但是可以通过适当的变量代换化为变量分离型方程。下面将通过一些例子来说明这种方法。

▶ 例 7.2.4

求解初值问题 $ \left\{\begin{aligned}y^{\prime}=\frac{y}{x}+\tan\frac{y}{x},\\ y(1)=\frac{\pi}{2}.\end{aligned}\right. $

解 作变量代换  $ u=\frac{y}{x} $，则  $ y=xu, y'=u+xu' $，代入方程  $ y'=\frac{y}{x}+\tan\frac{y}{x} $