么条件？

8. 在广义积分  $ \int_{a}^{+\infty}f(x)dx $ 中，作变量代换  $ x=\varphi(u) $. 其中  $ a=\varphi(a^{*}) $， $ \varphi $ 在  $ [a^{*},+\infty) $ 有连续导函数，且  $ \varphi'(u)>0 $.  $ \lim_{u\to+\infty}\varphi(u)=+\infty $. 试证：若  $ \int_{a}^{+\infty}f(\varphi(u))\varphi'(u)du $ 收敛，则  $ \int_{a}^{+\infty}f(x)dx $ 收敛，并且  $ \int_{a}^{+\infty}f(x)dx=\int_{a}^{+\infty}f(\varphi(u))\varphi'(u)du $.

9. 求广义积分  $ \int_{0}^{\frac{\pi}{2}}\ln(\cos x)dx $ 的值.

10. 设  $ f(x) $ 在  $ (0,1] $ 内单调，在 x=0 的邻域内无界，证明： $ \int_{0}^{1}f(x)dx $ 收敛时，有

 $$ \int_{0}^{1}f(x)\mathrm{d}x=\lim_{n\to\infty}\frac{1}{n}\sum_{i=1}^{n}f\Big(\frac{i}{n}\Big). $$ 

对于一般的  $ f(x) $，瑕积分  $ \int_{a}^{b}f(x)dx $ 是否可以看成相应黎曼和  $ \sum_{i=1}^{n}f(\xi_{i})\Delta x_{i} $ 的极限？