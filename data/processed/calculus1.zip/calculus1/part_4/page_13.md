#### 定义 6.2.2

设  $ f $ 在  $ [a, b) $ 上定义，在  $ b $ 点附近无界，并且  $ \forall \delta \in (0, b-a) $，有  $ f \in R[a, b-\delta] $.

(1) 如果取积分  $ \int_{a}^{b} |f(x)| \, dx $ 收敛，则称取积分  $ \int_{a}^{b} f(x) \, dx $ 绝对收敛.

(2) 如果  $ \int_{a}^{b} f(x) \, dx $ 收敛，但  $ \int_{a}^{b} |f(x)| \, dx $ 发散，则称取积分  $ \int_{a}^{b} f(x) \, dx $ 条件收敛.

设 f 在  $ [a, b) $ 上定义，在 b 点附近无界，并且  $ \forall \delta \in (0, b-a) $，有  $ f \in R[a, b-\delta] $。如果取积分  $ \int_{a}^{b} f(x) \, dx $ 绝对收敛，则  $ \int_{a}^{b} f(x) \, dx $ 收敛。

定理 6.2.8（比较判别法）

设 f, g 在  $ [a, b) $ 上定义，在 b 点附近无界，并且  $ \forall \delta \in (0, b - a) $，有  $ f, g \in R[a, b - \delta] $。又设存在正数 C 与  $ d \in (0, b - a) $，使得

 $$ \left|f(x)\right|\leqslant Cg(x),\quad x\in(b-d,b). $$ 

(1) 若  $ \int_{a}^{b} g(x) \, dx $ 收敛，则取积分  $ \int_{a}^{b} f(x) \, dx $ 绝对收敛.

(2) 若  $ \int_{a}^{b}|f(x)|\,\mathrm{d}x $ 发散，则取积分  $ \int_{a}^{b}g(x)\,\mathrm{d}x $ 发散.

定理 6.2.9（比较判别法的极限形式）

设非负函数  $ f, g $ 在  $ [a, b) $ 上定义，在  $ b $ 点附近无界，并且  $ \forall \delta \in (0, b - a) $，有  $ f, g \in R[a, b - \delta] $。又设

 $$ \lim_{x\to b^{-}}\frac{f(x)}{g(x)}=C. $$ 

(1) 如果 C > 0，则取积分  $ \int_{a}^{b} f(x) \, dx $ 与  $ \int_{a}^{b} g(x) \, dx $ 同收敛同发散；

(2) 如果 C=0，且取积分  $ \int_{a}^{b}g(x)dx $ 收敛，则取积分  $ \int_{a}^{b}f(x)dx $ 收敛.

定理 6.2.10（狄利克雷判别法）

设 f 在  $ [a, b) $ 上定义，在 b 点附近无界。如果  $ F(t) = \int_{a}^{t} f(x) \, dx $ 在  $ [a, b) $ 上有界， $ g(x) $ 在  $ [a, b) $ 上单调且  $ \lim_{x \to b} g(x) = 0 $，则瑕积分  $ \int_{a}^{b} f(x) g(x) \, dx $ 收敛。