 $$ \int_{0}^{1}\frac{\mathrm{d}x}{\sqrt{x}\left(1+x\right)}=\lim_{\delta\rightarrow0^{+}}\int_{\delta}^{1}\frac{\mathrm{d}x}{\sqrt{x}\left(1+x\right)}=2\lim_{\delta\rightarrow0^{+}}\arctan\sqrt{x}\mid_{\delta}^{1}=\frac{\pi}{2}. $$ 

同时，

 $$ \int_{1}^{+\infty}\frac{\mathrm{d}x}{\sqrt{x}\left(1+x\right)}=\lim_{A\rightarrow+\infty}\int_{1}^{A}\frac{\mathrm{d}x}{\sqrt{x}\left(1+x\right)}=2\lim_{A\rightarrow+\infty}\arctan\sqrt{x}\bigg|_{1}^{A}=\frac{\pi}{2}. $$ 

即上面两积分皆收敛，从而原广义积分收敛，并且 $ \int_{0}^{+\infty}\frac{dx}{\sqrt{x}(1+x)}=\pi $

### 习题 6.1

1. 广义积分与黎曼积分有什么不同？

2. 利用定义计算下列广义积分.

(1)  $ \int_{0}^{+\infty}\frac{1}{x(x+1)}dx; $ (2)  $ \int_{0}^{+\infty}xe^{-x}dx; $

(3)  $ \int_{0}^{+\infty}e^{-x}\sin xdx; $ (4)  $ \int_{-\infty}^{+\infty}\frac{1}{x^{2}+2x+5}dx; $

(5)  $ \int_{x}^{+\infty}\frac{1}{x(1+x^{2})}dx; $ (6)  $ \int_{-\infty}^{0}xe^{x}\sin xdx; $

(7)  $ \int_{0}^{1}\frac{e^{\frac{-x}{x^{2}}}dx; $ (8)  $ \int_{1}^{0}\frac{dx}{x\sqrt{1-(\ln x)^{2}}}; $

(9)  $ \int_{-1}^{0}\frac{x}{\sqrt{1-x^{2}}}dx. $

3. 计算下列广义积分.

(1) $ \int_{1}^{+\infty}\frac{1}{x^{2}\sqrt{1+x^{2}}}dx; $ (2) $ \int_{0}^{+\infty}\frac{\arctan x}{(1+x^{2})^{\frac{3}{2}}}dx; $

(3) $ \int_{-\infty}^{-2}\frac{1}{x\sqrt{x^{2}-1}}dx; $ (4) $ \int_{0}^{1}(\ln x)^{2}dx; $

(5) $ \int_{-1}^{1}\sqrt{\frac{1-x}{1+x}}dx; $ (6) $ \int_{0}^{1}\frac{1}{(2+x)\sqrt{1-x}}dx. $

4. 考察下列广义积分的类型（属于无穷限积分、瑕积分，还是两类积分的混合），并利用定义考察其敛散性，收敛的求出值，发散的说明理由。

(1)  $ \int_{-2}^{2}\frac{2x}{x^{2}-4}dx; $

(2)  $ \int_{0}^{+\infty}\frac{x\ln x}{(1+x^{2})^{2}}dx; $

(3)  $ \int_{1}^{+\infty}\frac{1}{x\sqrt{x^{2}-1}}dx; $

(4)  $ \int_{2}^{+\infty}\frac{dx}{x^{2}-4x+3}; $

(5)  $ \int_{0}^{+\infty}e^{-\sqrt{x}}dx; $

(6)  $ \int_{0}^{+\infty}\frac{\ln x}{x^{2}}dx. $