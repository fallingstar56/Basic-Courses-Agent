计算广义积分 $ \int_{1}^{+\infty}\frac{\ln x}{x^{2}}dx $.

解  $ \int_{1}^{+\infty}\frac{\ln x}{x^{2}}dx=\lim_{A\to+\infty}\int_{1}^{A}\frac{\ln x}{x^{2}}dx=\lim_{A\to+\infty}\left[-\frac{\ln x}{x}\bigg|_{1}^{A}+\int_{1}^{A}\frac{dx}{x^{2}}\right] $

 $ \lim_{A\to+\infty}\left[-\frac{\ln x}{x}\bigg|_{1}^{A}-\frac{1}{x}\bigg|_{1}^{A}\right]=1. $

▶ 例 6.1.3 ……

设 p>0，讨论广义积分  $ \int_{1}^{+\infty}\frac{dx}{x^{p}} $ 的收敛性.

解  $ \int_{1}^{A}\frac{\mathrm{d}x}{x^{p}}=\left\{\begin{aligned}&\ln A,&p=1,\\&\frac{A^{1-p}-1}{1-p},&p\neq1.\end{aligned}\right. $

于是当 p>1 时， $ \lim_{A\to+\infty}\int_{1}^{A}\frac{\mathrm{d}x}{x^{p}}=\frac{1}{p-1} $; 当  $ 0<p\leqslant1 $ 时， $ \int_{1}^{A}\frac{\mathrm{d}x}{x^{p}}\rightarrow+\infty(A\rightarrow+\infty) $. 所以，广义积分  $ \int_{1}^{+\infty}\frac{\mathrm{d}x}{x^{p}} $ 当  $ 0<p\leqslant1 $ 时发散；当 p>1 时收敛.

设 p>0. 讨论广义积分  $ \int_{e}^{+\infty}\frac{dx}{x(\ln x)^{p}} $ 的收敛性.

解  $ \int_{e}^{A}\frac{\mathrm{d}x}{x(\ln x)^{p}}=\left\{\begin{aligned}&\ln(\ln A),&p=1,\\&\frac{(\ln A)^{1-p}-1}{1-p},&p\neq1.\end{aligned}\right. $

于是当 p>1 时， $ \lim_{A\to+\infty}\int_{e}^{A}\frac{\mathrm{d}x}{x(\ln x)^{p}}=\frac{1}{p-1} $; 当  $ 0<p\leqslant1 $ 时， $ \int_{e}^{A}\frac{\mathrm{d}x}{x(\ln x)^{p}}\rightarrow+\infty(A\rightarrow+\infty) $. 所以，广义积分  $ \int_{e}^{A}\frac{\mathrm{d}x}{x(\ln x)^{p}} $ 当  $ 0<p\leqslant1 $ 时发散；当 p>1 时收敛.

最后，对于形如  $ \int_{-\infty}^{+\infty}f(x)dx $ 的广义积分，如果存在实数 a，使得广义积分  $ \int_{a}^{+\infty}f(x)dx $ 与  $ \int_{-\infty}^{a}f(x)dx $ 都收敛，则称广义积分  $ \int_{-\infty}^{+\infty}f(x)dx $ 收敛，并且

 $$ \int_{-\infty}^{+\infty}f(x)\mathrm{d}x=\int_{-\infty}^{a}f(x)\mathrm{d}x+\int_{a}^{+\infty}f(x)\mathrm{d}x. $$ 

此时，对于任何实数 b，不难看到，广义积分  $ \int_{b}^{+\infty}f(x)dx $ 与  $ \int_{-\infty}^{b}f(x)dx $ 也都收敛，因而广义积分  $ \int_{-\infty}^{+\infty}f(x)dx $ 的收敛性与 a 的选取无关.