#### 7.5.3 欧拉方程

形如

 $$ x^{n}y^{(n)}+a_{1}x^{n-1}y^{(n-1)}+\cdots+a_{n-1}x y^{\prime}+a_{n}y=f(x) $$ 

的线性常微分方程称为欧拉方程.

欧拉方程是变系数线性方程.一般情况下变系数高阶线性常微分方程的求解是比较困难的.然而,根据欧拉方程的特殊形状,可以通过适当的变量替换将其化为常系数线性常微分方程,从而使其求解变得相对简单易行.

当x>0时，令 $ t=\ln x $（当x<0时，令 $ t=\ln|x| $，即 $ x=e^{t} $，则有

 $$ \frac{\mathrm{d}y}{\mathrm{d}x}=\frac{\mathrm{d}y}{\mathrm{d}t}\bullet\frac{\mathrm{d}t}{\mathrm{d}x}=\frac{1}{x}\frac{\mathrm{d}y}{\mathrm{d}t}, $$ 

 $$ \frac{\mathrm{d}^{2}y}{\mathrm{d}x^{2}}=\frac{-1}{x^{2}}\frac{\mathrm{d}y}{\mathrm{d}t}+\frac{1}{x^{2}}\frac{\mathrm{d}^{2}y}{\mathrm{d}t^{2}}=\frac{1}{x^{2}}\Big(\frac{\mathrm{d}^{2}y}{\mathrm{d}t^{2}}-\frac{\mathrm{d}y}{\mathrm{d}t}\Big). $$ 

用数学归纳法不难证明，对于每个正整数k，

 $$ x^{k}\frac{\mathrm{d}^{k}y}{\mathrm{d}x^{k}}=\alpha_{1}\frac{\mathrm{d}^{k}y}{\mathrm{d}t^{k}}+\alpha_{2}\frac{\mathrm{d}^{k-1}y}{\mathrm{d}t^{k-1}}+\cdots+\alpha_{k}\frac{\mathrm{d}y}{\mathrm{d}t}, $$ 

其中  $ \alpha_{1},\alpha_{2},\cdots,\alpha_{k} $ 为常数。把它们代入方程(12)，整理后可得一个以 t 为自变量的常系数 n 阶线性常微分方程，若此方程有解  $ y=\varphi(t) $，则  $ y=\varphi(\ln x) $ 即为方程(12)的解。

#### ▶ 例 7.5.9

求方程  $ x^{2}y'' + xy' + y = 2x $ 的通解.

解 令  $ t=\ln|x| $，则有

 $$ \frac{\mathrm{d}y}{\mathrm{d}x}=\frac{1}{x}\frac{\mathrm{d}y}{\mathrm{d}t},\quad\frac{\mathrm{d}^{2}y}{\mathrm{d}x^{2}}=\frac{1}{x^{2}}\Big(\frac{\mathrm{d}^{2}y}{\mathrm{d}t^{2}}-\frac{\mathrm{d}y}{\mathrm{d}t}\Big). $$ 

当 x>0 时，原方程可化为

 $$ \frac{\mathrm{d}^{2}y}{\mathrm{d}t^{2}}+y=2\mathrm{e}^{\prime}. $$ 

它的特征根为  $ \lambda = \pm i $。可设此方程有形如  $ Y(x) = A e^{x} $ 的特解。代入方程得到 A = 1。于是方程  $ \frac{d^{2}y}{dt^{2}} + y = 2e^{t} $ 的通解为  $ y = C_{1} \cos t + C_{2} \sin t + e^{t} $。

当 x<0 时， $ x=-\mathrm{e}^{t} $，原方程可化为  $ \frac{\mathrm{d}^{2}y}{\mathrm{d}t^{2}}+y=-2\mathrm{e}^{t} $。类似地，此方程的通解为  $ y=C_{1}\cos t+C_{2}\sin t-\mathrm{e}^{t} $。所以原欧拉方程通解为

 $$ y(x)=C_{1}\cos\ln\mid x\mid+C_{2}\sin\ln\mid x\mid+x. $$ 