可得新变量 u 应满足的方程：

 $$ u+x u^{\prime}=u+\tan u, $$ 

即

 $$ \frac{\mathrm{d}u}{\tan u}=\frac{\mathrm{d}x}{x}. $$ 

两端积分可得

 $$ \ln|\sin u|=\ln|x|+C_{1}, $$ 

或

 $$ \sin u=\pm\mathrm{e}^{c_{1}}x. $$ 

注意到  $ u \equiv 0 $ 也是方程  $ xu' = \tan u $ 的解，即得方程  $ xu' = \tan u $ 的通解为  $ \sin u = Cx $，所以方程  $ y' = \frac{y}{x} + \tan \frac{y}{x} $ 的通解为

 $$ y=x\arcsin(C x), $$ 

代入初值条件  $ y(1)=\pi/2 $ , 得到 C=1 ，于是所求初值问题的解为

 $$ y=x\arcsin x, $$ 

像上例中这样形如

 $$ \frac{\mathrm{d}y}{\mathrm{d}x}=f\left(\frac{y}{x}\right) $$ 

的一阶方程称为(零次)齐次方程.从上例中看到,作变量代换 $ u=\frac{y}{x} $,则这类方程可以化为关于新变量u的变量分离型方程:

 $$ \frac{\mathrm{d}u}{\mathrm{d}x}=\frac{f(u)-u}{x}. $$ 

求得它的解  $ u(x) $ 后，便得到原方程的解  $ y = xu(x) $.

求解方程  $ y' = -\frac{6x^{3} + 3xy^{2}}{2y^{3} + 3yx^{2}}. $

解 这是一个齐次方程. 令  $ u=\frac{y}{x} $，则原方程可化为

 $$ x u^{\prime}+u=-\frac{6+3u^{2}}{2u^{3}+3u}. $$ 

整理得

 $$ \frac{1}{2}\cdot\frac{2u^{3}+3u}{u^{4}+3u^{2}+3}\mathrm{d}u=-\frac{\mathrm{d}x}{x}. $$ 

两端积分得

 $$ \frac{1}{4}\ln(u^{4}+3u^{2}+3)=-\ln|x|+C_{1}, $$ 

即