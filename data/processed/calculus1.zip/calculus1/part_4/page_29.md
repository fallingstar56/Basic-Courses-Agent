#### 7.2.3 一阶线性常微分方程

一阶线性常微分方程的规范形式为

 $$ y^{\prime}+p(x)y=q(x), $$ 

其中  $ p(x) $ 与  $ q(x) $ 为区间 I 上的连续函数.  $ q(x) $ 称为方程(2)的自由项或非齐次项. 当  $ q(x) \equiv 0 $ 时，方程(2)变为与其对应的齐次线性方程：

 $$ y^{\prime}+p(x)y=0. $$ 

方程(3)是一个变量分离型方程，将其改写为

 $$ \frac{\mathrm{d}y}{y}=-p(x)\mathrm{d}x, $$ 

两端积分可得

 $$ \ln\mid y\mid=-\int p(x)\mathrm{d}x+C_{1}. $$ 

去对数再去绝对值即得齐次方程(3)的通解为

 $$ y=C\mathrm{e}^{-\int p(x)\mathrm{d}x}, $$ 

其中 C 为任意常数（由于  $ y(x) \equiv 0 $ 也是方程（3）的解，C 也可以取 0）， $ \int p(x)dx $ 表示  $ p(x) $ 的（任意）一个原函数.

为了求非齐次线性方程(2)的解，我们假设方程(2)有形如

 $$ y=C(x)\mathrm{e}^{-\int p(x)\mathrm{d}x} $$ 

的解，其中  $ C(x) $ 为待定函数。把解（4）代入方程（2），可得

 $$ C^{\prime}(x)\mathrm{e}^{-\int p(x)\mathrm{d}x}-p(x)C(x)\mathrm{e}^{-\int p(x)\mathrm{d}x}+p(x)C(x)\mathrm{e}^{-\int p(x)\mathrm{d}x}=q(x), $$ 

即

 $$ C^{\prime}(x)=q(x)\mathrm{e}^{\int p(x)\mathrm{d}x}. $$ 

于是

 $$ C(x)=\int q(x)\mathrm{e}^{\int p(x)\mathrm{d}x}\mathrm{d}x+C. $$ 

代入(4)式，便得到

 $$ y=\mathrm{e}^{-\int p(x)\mathrm{d}x}\left(\int q(x)\mathrm{e}^{\int p(x)\mathrm{d}x}\mathrm{d}x+C\right), $$ 

其中  $ \int p(x)dx $ 表示  $ p(x) $ 的（任意）一个原函数， $ \int q(x)e^{\int p(x)dx}dx $ 表示  $ q(x)e^{\int p(x)dx} $ 的（任意）一个原函数，C 为任意常数。所以（5）式即为方程（2）的通解。

上述求解非齐次线性方程(2)的方法称为常数变易法.

▶ 例 7.2.8

求方程  $ y'-2xy=2xe^{x^{2}} $ 满足  $ y(0)=1 $ 的特解.