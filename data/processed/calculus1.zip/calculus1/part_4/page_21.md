另一方面，镭的衰变速度与其质量  $ m(t) $ 成正比，记比例系数为 k，于是  $ m = m(t) $ 应满足下列常微分方程：

 $$ m^{\prime}=-km. $$ 

不难验证，此微分方程有解

 $$ m(t)=C\mathrm{e}^{-kt}, $$ 

其中 C 为任意常数。注意到当 t=0 时，镭的质量为  $ m(0)=1 $，于是 C=1。所以经过 t 年时间后剩下的镭的质量是  $ m(t)=\mathrm{e}^{-kt} $。

再由镭的半衰期是1600年可确定比例系数为k:

 $$ m(1600)=\mathrm{e}^{-k1600}=\frac{1}{2}, $$ 

 $$ k=\frac{\ln2}{1600}\approx0.000433. $$ 

#### ▶ 例 7.1.2

设有高为 H、半径为 R 的圆柱形水塔装满水，塔底部有半径为 r 的圆形出水孔。设水流出的速度为  $ v = \mu \sqrt{2gh} $，其中  $ \mu $ 为小于 1 的正常数，g 为重力加速度，h 为水面高度。若从某个时刻开启出水孔，问水从出水孔全部流出需要多长时间？

解 设出水孔开启后经过时间 t，水塔水面高度为  $ h = h(t) $，则在 t 到  $ t + \Delta t $ 这段时间内，流出的水总量近似地为  $ \pi r^{2} \mu \sqrt{2gh(t)} \Delta t $。另一方面，水塔水面高度由  $ h(t) $ 变到  $ h(t + \Delta t) $，从而在 t 到  $ t + \Delta t $ 这段时间流出的水总量应为  $ -\pi R^{2} \left[h(t + \Delta t) - h(t)\right] $。由此可得

 $$ \pi r^{2}\mu\;\sqrt{2g h\left(t\right)}\;\Delta t\approx-\;\pi R^{2}\big[h(t+\Delta t)-h(t)\big]. $$ 

于是 $ h=h(t) $应满足下列常微分方程：

 $$ h^{\prime}=-\frac{r^{2}}{R^{2}}\mu\sqrt{2gh}. $$ 

不难验证，此微分方程有解

 $$ h(t)=\left(C-\frac{r^{2}\mu\sqrt{g}}{\sqrt{2}R^{2}}t\right)^{2}, $$ 

其中 C 为任意常数。注意到当 t=0 时，水塔水面高度为  $ h(0)=H $，于是  $ C=\sqrt{H} $。

设经过时间 T 水从出水孔全部流出，则应有

 $$ h(T)=\left(\sqrt{H}-\frac{r^{2}\mu\sqrt{g}}{\sqrt{2}R^{2}}T\right)^{2}=0. $$ 

所以经过时间  $ T=\frac{\sqrt{2}R^{2}\sqrt{H}}{r^{2}\mu\sqrt{g}} $，水从出水孔全部流出。