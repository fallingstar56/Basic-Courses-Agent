分为

 $$ \int_{a}^{b}f(x)\mathrm{d}x=\int_{a}^{b}u(x)\mathrm{d}x+\mathrm{i}\int_{a}^{b}v(x)\mathrm{d}x. $$ 

实际上，对于复值函数，只需要把虚数单位 i 看作常数，其他方面像实值函数一样处理即可。读者不难验证下列结果：

定理 7.5.1 ……

(1) 如果  $ y(x)=u(x)+\mathrm{i}v(x) $ 是方程(2)的复值解，则  $ u(x) $ 与  $ v(x) $ 都是方程(2). 的实值解.

(2) 如果  $  y(x) = u(x) + iv(x)  $ 是下列方程的复值解：

 $$ y^{(n)}+a_{1}y^{(n-1)}+\cdots+a_{n-1}y^{\prime}+a_{n}y=f_{1}(x)+i f_{2}(x), $$ 

其中  $ f_{1}(x) $ 与  $ f_{2}(x) $ 为实值函数，则  $ u(x) $ 是方程

 $$ y^{(n)}+a_{1}y^{(n-1)}+\cdots+a_{n-1}y^{\prime}+a_{n}y=f_{1}(x) $$ 

的实值解； $ v(x) $ 是方程

 $$ y^{(n)}+a_{1}y^{(n-1)}+\cdots+a_{n-1}y^{\prime}+a_{n}y=f_{2}(x) $$ 

的实值解.

下列公式称为欧拉公式：

 $$ \mathrm{e}^{\mathrm{i}x}=\cos x+\mathrm{i}\sin x. $$ 

它可以看作是  $ e^{ix} $ 的定义式，进而定义  $ e^{x+iy}=e^{x}\cdot e^{iy} $ 。照此定义，不难验证下列等式：

 $$ \mathrm{e}^{\mathrm{i}(x+y)}=\mathrm{e}^{\mathrm{i}x}\cdot\mathrm{e}^{\mathrm{i}y}, $$ 

 $$ \begin{array}{r}{(\mathrm{e}^{(\alpha+\mathrm{i}\beta)x})^{\prime}=(\mathrm{e}^{\alpha x}\cos\beta x)^{\prime}+\mathrm{i}(\mathrm{e}^{\alpha x}\sin\beta x)^{\prime}=(\alpha+\mathrm{i}\beta)\mathrm{e}^{(\alpha+\mathrm{i}\beta)x}.}\end{array} $$ 

下面考虑方程(2)的求解问题. 设方程(2)有形如  $ y(x)=\mathrm{e}^{\lambda x} $ 的解，其中  $ \lambda $ 待定. 将  $ y(x)=\mathrm{e}^{\lambda x} $ 代入方程(2)可得

 $$ (\lambda^{n}+a_{1}\lambda^{n-1}+\cdots+a_{n-1}\lambda+a_{n})\mathrm{e}^{\lambda x}=0. $$ 

n 阶多项式  $  F(\lambda) = \lambda^{n} + a_{1}\lambda^{n-1} + \cdots + a_{n-1}\lambda + a_{n}  $ 称为方程（2）（与方程（1））的特征多项式，n 次代数方程

 $$ F(\lambda)=0 $$ 

称为方程(2)(与方程(1))的特征方程，特征方程的根称为特征根.

## 情形 1

λ 是方程(2)的单特征根，显然  $ y(x)=\mathrm{e}^{kx} $ 为方程(2)的解。因此，若方程(2)有 n 个单特征根，则可以得到方程(2)的 n 个解。可以验证，这些解是线性无关的。

## 情形 2

λ 是方程(2)的 k 重特征根，此时  $ e^{kx}, x e^{kx}, \cdots, x^{k-1} e^{kx} $ 为方程(2)的 k 个线性无关解.

这里对于一般情形的证明比较复杂，我们只对二阶方程的情形加以验证。