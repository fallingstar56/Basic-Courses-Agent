同理可证广义积分  $ \int_{1}^{+\infty}\frac{\cos x}{x^{a}}dx $ 收敛.

另一方面，当 $ \alpha>1 $时，

 $$ \int_{A_{1}}^{A_{2}}\frac{\left|\sin x\right|}{x^{a}}\mathrm{d}x\leqslant\int_{A_{1}}^{A_{2}}\frac{\mathrm{d}x}{x^{a}}\leqslant\frac{1}{\alpha-1}\cdot\frac{1}{A_{1}^{a-1}}\rightarrow0(A_{1}\rightarrow+\infty). $$ 

由此知广义积分 $ \int_{1}^{+\infty}\frac{\sin x}{x^{a}}dx $绝对收敛.同理，当 $ \alpha>1 $时， $ \int_{1}^{+\infty}\frac{\cos x}{x^{a}}dx $亦绝对收敛.

当  $ 0 < a \leqslant 1 $ 时，

 $$ \int_{1}^{A}\frac{\mid\sin x\mid}{x^{\alpha}}\mathrm{d}x\geqslant\int_{1}^{A}\frac{\sin^{2}x}{x}\mathrm{d}x=\frac{1}{2}\left(\int_{1}^{A}\frac{1}{x}\mathrm{d}x-\int_{1}^{A}\frac{\cos2x}{x}\mathrm{d}x\right). $$ 

由于

 $$ \int_{1}^{A}\frac{1}{x}\mathrm{d}x=\ln A\rightarrow+\infty(A\rightarrow+\infty), $$ 

再由上面讨论， $ \int_{2}^{+\infty}\frac{\cos x}{x}dx $ 收敛，于是当  $ A\rightarrow+\infty $ 时，

 $$ \int_{1}^{A}\frac{\cos2x}{x}\mathrm{d}x=\int_{2}^{2A}\frac{\cos x}{x}\mathrm{d}x\rightarrow\int_{2}^{+\infty}\frac{\cos x}{x}\mathrm{d}x. $$ 

从而当  $ A \rightarrow +\infty $ 时，

 $$ \int_{1}^{A}\frac{\mid\sin x\mid}{x^{\alpha}}\mathrm{d}x\rightarrow+\infty, $$ 

即当  $ 0 < \alpha \leqslant 1 $ 时，广义积分  $ \int_{1}^{+\infty} \frac{\sin x}{x^{a}} dx $ 条件收敛。同理， $ \int_{1}^{+\infty} \frac{\cos x}{x^{a}} dx $ 亦条件收敛。

定理 6.2.2（比较判别法）

设  $ f, g $ 在  $ [a, +\infty) $ 上定义，并且  $ \forall A > a, f, g \in R[a, A] $。又设存在正数  $ K $ 与  $ C $，使得当  $ x > K $ 时有

 $$ \left|f(x)\right|\leqslant C_{g}(x). $$ 

(1) 若广义积分  $ \int_{a}^{+\infty} g(x) dx $ 收敛，则广义积分  $ \int_{a}^{+\infty} f(x) dx $ 绝对收敛.

(2) 若广义积分  $ \int_{a}^{+\infty}\left|f(x)\right|dx $ 发散，则广义积分  $ \int_{a}^{+\infty}g(x)dx $ 发散.

证明 （1）设  $ \int_{a}^{+\infty} g(x) \, dx $ 收敛，则  $ \forall \varepsilon > 0, \exists M_{1} > 0, $ 只要  $ A_{2} > A_{1} > M_{1} $，就有

 $$ \int_{A_{1}}^{A_{2}}g(x)\mathrm{d}x<\frac{\varepsilon}{C}. $$ 