 $ S(a)=\frac{a^{2}}{2}+\frac{a}{2}\sin a+\frac{\pi}{2}\cos a $，求 $ f\left(\frac{\pi}{2}\right) $.

11. 设  $ f(x) \in C(\mathbb{R}) $，定义  $ F(x) = \frac{1}{2} \int_{x-1}^{x+1} f(t) \, dt. $

(1) 证明： $ F(x) $ 在  $ \mathbb{R} $ 上可导，并求导函数；

(2) 当  $ f(x)=|x| $ 时，求  $ F(x) $，并画出图形；

(3) 证明：若  $ \lim_{x\to+\infty}f(x)=a $，则  $ \lim_{x\to+\infty}F(x)=a $.

12. 已知  $  f(x)  $ 连续且  $ \lim_{x\to0}\frac{f(x)}{x}=a $，定义  $ \varphi(x)=\int_{0}^{1}f(xt)dt $，求  $ \varphi'(x) $ 并讨论  $ \varphi'(x) $ 在 x=0 的连续性.

13. 求  $ I_{n}=\int\frac{x^{n}}{\sqrt{1-x^{2}}}dx $ 的递推计算公式.

14. 设常数  $ a \neq 0 $，计算不定积分  $ \int \frac{1}{x(x^{n} + a)} \, dx $.

15. 证明： $ \int_{0}^{\frac{\pi}{2}}\sin^{n}x\cos^{n}x\,dx=\frac{1}{2^{n}}\int_{0}^{\frac{\pi}{2}}\sin^{n}x\,dx. $

16. 证明： $ \forall x \geqslant 0, \int_{0}^{x} \frac{\sin x}{1+x} \, \mathrm{d}x \geqslant 0 $（提示：只需证  $ \forall k, \int_{2k\pi}^{(2k+1)\pi} \frac{\sin x}{1+x} \, \mathrm{d}x \geqslant \int_{(2k+1)\pi}^{(2k+2)\pi} \frac{|\sin x|}{1+x} \, \mathrm{d}x $）.

17. 已知  $ f(x) $ 在  $ [a, b] $ 上连续且单调递增，证明： $ \int_{a}^{b} x f(x) \, dx \geqslant \frac{a + b}{2} \int_{a}^{b} f(x) \, dx. $

18. 设  $ f(x) \in C[0, \pi] $ 满足：

 $$ \int_{0}^{\pi}f(x)\cos x\mathrm{d}x=\int_{0}^{\pi}f(x)\sin x\mathrm{d}x=0, $$ 

证明： $ f(x) $ 在  $ (0,\pi) $ 内至少有两个零点.

19. 设  $ f(x) \in R[a, b] $，求证： $ \forall \varepsilon > 0 $，存在  $ g(x) \in C[a, b] $，使得

 $$ \int_{a}^{b}\mid f(x)-g(x)\mid\mathrm{d}x<\varepsilon. $$ 

20. 已知  $  f(x) \in R[0, \pi]  $，求证： $ \lim_{n \to \infty} \int_{0}^{\pi} f(x) \mid \sin nx \mid \mathrm{d}x = \frac{2}{\pi} \int_{0}^{\pi} f(x) \mathrm{d}x. $

21. 设  $ f(x) $,  $ g(x) $ 均为周期为 T 的连续函数，称函数  $ (f \ast g)(x) = \frac{1}{T} \int_{0}^{T} f(t) g(x - t) dt $ 是  $ f(x) $ 与  $ g(x) $ 的卷积，证明：

(1) $ f \ast g $也是周期为T的周期函数；

(2) $ (f*g)(x)=\frac{1}{T}\int_{a}^{a+T}f(t)g(x-t)\mathrm{d}t; $

(3)  $ f \star g = g \star f. $