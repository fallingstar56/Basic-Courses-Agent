## 第 6 章 广义黎曼积分

### 6.1 广义黎曼积分的概念

对于黎曼积分，积分区间是一个有限的闭区间，并且被积函数必须有界。但是，许多来自于各类学科的实际问题中，经常需要处理无穷区间和无界函数的积分问题，因此，有必要把黎曼积分的概念推广到无穷区间的情形以及无界函数的情形。这就产生了广义黎曼积分。

#### 6.1.1 无穷限积分

定义 6.1.1 ……

设函数  $ f $ 在  $ [a, +\infty) $ 上定义，并且对任意的  $ A > a $， $ f \in R[a, A] $。如果当  $ A \to +\infty $ 时，下列极限存在：

 $$ \lim_{A\to+\infty}\int_{a}^{A}f(x)\mathrm{d}x=I, $$ 

则称 f 在  $ [a, +\infty) $ 上的广义积分收敛，称极限值 I 为 f 在  $ [a, +\infty) $ 上的广义积分（值），记作

 $$ \int_{a}^{+\infty}f(x)\mathrm{d}x=\lim_{A\to+\infty}\int_{a}^{A}f(x)\mathrm{d}x. $$ 

若极限  $ \lim_{A\to+\infty}\int_{a}^{A}f(x)dx $ 不存在，则称广义积分  $ \int_{a}^{+\infty}f(x)dx $ 发散.

类似地，可以定义  $ f(\text{在}(-∞, a] $ 上的广义积分  $ \int_{-\infty}^{a} f(x) \, dx $ 的收敛与发散.

计算广义积分  $ \int_{0}^{+\infty}\frac{dx}{1+x^{2}} $

解  $ \int_{0}^{+\infty}\frac{\mathrm{d}x}{1+x^{2}}=\lim_{A\to+\infty}\int_{0}^{A}\frac{\mathrm{d}x}{1+x^{2}}=\lim_{A\to+\infty}\arctan x\bigg|_{0}^{A}=\frac{\pi}{2} $