则根据定理 7.4.2,  $ y(x) $ 为方程(2)的解，且由(4)，

 $$ y(x_{0})=y^{\prime}(x_{0})=\cdots=y^{(n-1)}(x_{0})=0. $$ 

另一方面， $ Y(x)\equiv0 $ 也是方程(2)的解，并且与  $ y(x) $ 满足相同的一组定解条件，根据方程(2)的解的存在唯一性定理（定理 7.4.1）， $ y(x) $ 应与  $ Y(x)\equiv0 $ 为方程(2)的同一个解，即

 $$ y(x)=c_{1}y_{1}(x)+c_{2}y_{2}(x)+\cdots+c_{n}y_{n}(x)\equiv0,\quad x\in I. $$ 

这与  $ y_{1}, y_{2}, \cdots, y_{n} $ 在 I 上线性无关相矛盾. 所以  $ \forall x \in I, W[y_{1}, y_{2}, \cdots, y_{n}](x) \neq 0. $

需要注意的是，在一般情况下，朗斯基行列式  $ W[y_{1},y_{2},\cdots,y_{n}](x)\equiv0,x\in I $ 并不能保证函数组  $ y_{1},y_{2},\cdots,y_{n} $ 在 I 上线性相关。例如：

#### ▶ 例 7.4.2

函数

 $$ f(x)=\left\{\begin{aligned}&x^{2},&x\geqslant0,\\ &0,&x<0,\end{aligned}\right.\quad g(x)=\left\{\begin{aligned}&0,&x\geqslant0,\\ &x^{2},&x<0.\end{aligned}\right. $$ 

在区间 $ (-a,a) $  $ (a>0) $上线性无关，但是在 $ (-a,a) $上 $ W[f,g](x)\equiv0 $.

定理 7.4.4

设函数  $ a_{1}(x),\cdots,a_{n}(x) $ 在区间 I 上连续，则方程(2)的解空间为一个 n 维线性空间.

证明 为证明定理, 只需要找到方程(2)的 n 个线性无关解, 并证明方程(2)的每个解都可以用它们线性表出.

记  $ e_{k}(k=1,2,\cdots,n) $ 是第 k 个分量为 1、其他分量为 0 的 n 维列向量， $ x_{0} \in I $。根据定理 7.4.1，方程(2)存在唯一的解  $ y_{k}(x) $ 满足定解条件

 $$ (y_{k}(x_{0}),y_{k}^{\prime}(x_{0}),\cdots,y_{k}^{(n-1)}(x_{0}))^{\mathrm{T}}=\boldsymbol{e}_{k}\quad(k=1,2,\cdots,n). $$ 

由此知

 $$ W[y_{1},y_{2},\cdots,y_{n}](x_{0})=\det(e_{1}\quad e_{2}\quad\cdots\quad e_{n})=1\neq0. $$ 

再应用定理 7.4.3(2) 便得到  $ y_{1}, y_{2}, \cdots, y_{n} $ 在 I 上线性无关.

其次，任取方程(2)的解  $ y(x) $，记  $ c_{k}=y^{(k-1)}(x_{0}) $ ( $ k=1,2,\cdots,n $)，则函数

 $$ Y(x)=c_{1}y_{1}(x)+c_{2}y_{2}(x)+\cdots+c_{n}y_{n}(x) $$ 

为方程(2)的解，并且与  $ y(x) $ 满足同一组定解条件：

 $$ \begin{align*}Y^{(k)}\left(x_{0}\right)&=c_{1}y_{1}^{(k)}\left(x_{0}\right)+c_{2}y_{2}^{(k)}\left(x_{0}\right)+\cdots+c_{n}y_{n}^{(k)}\left(x_{0}\right)\\&=c_{k+1}=y^{(k)}\left(x_{0}\right),\quad k=0,1,\cdots,n-1.\end{align*} $$ 

再次应用解的存在唯一性定理(定理 7.4.1)可得

 $$ y(x)\equiv Y(x)=c_{1}y_{1}(x)+c_{2}y_{2}(x)+\cdots+c_{n}y_{n}(x)\quad(x\in I), $$ 

即  $ y(x) $ 可以用  $ y_{1}, y_{2}, \cdots, y_{n} $ 线性表出.