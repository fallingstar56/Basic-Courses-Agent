 $$ c_{1}^{\prime}y_{1}^{\prime}+c_{2}^{\prime}y_{2}^{\prime}=f(x). $$ 

考虑方程(12)与方程(13)联立所成的代数方程组，其系数行列式恰为  $ W[y_{1}, y_{2}](x) $. 由定理 7.4.3(2) 知  $ W(x) = W[y_{1}, y_{2}](x) \neq 0 $，从而可以解得

 $$ c_{1}^{\prime}(x)=-\frac{y_{2}(x)f(x)}{W(x)},\quad c_{2}^{\prime}(x)=\frac{y_{1}(x)f(x)}{W(x)}, $$ 

再积分即得方程(8)的特解：

 $$ \begin{align*}Y(x)&=y_{1}(x)\int_{x_{0}}^{x}c_{1}^{\prime}(t)\mathrm{d}t+y_{2}(x)\int_{x_{0}}^{x}c_{2}^{\prime}(t)\mathrm{d}t\\&=\int_{x_{0}}^{x}\frac{y_{2}(x)y_{1}(t)-y_{1}(x)y_{2}(t)}{W(t)}f(t)\mathrm{d}t.\end{align*} $$ 

上述方法也称为常数变易法.

#### ▶ 例 7.4.4

已知齐次方程  $ xy''-(x+1)y'+y=0 $ 的两个线性无关解  $ x+1 $ 与  $ e^{x} $，求非齐次方程  $ xy''-(x+1)y'+y=x^{2}e^{x} $ 的通解.

解 使用常数变易法，设此方程有形如  $ Y(x)=(x+1)c_{1}(x)+\mathrm{e}^{x}c_{2}(x) $ 的特解，其中  $ c_{1}(x) $ 与  $ c_{2}(x) $ 为待定函数。为确定  $ c_{1}(x) $ 与  $ c_{2}(x) $，增加条件

 $$ (x+1)c_{1}^{\prime}+\mathrm{e}^{x}c_{2}^{\prime}=0, $$ 

于是

 $$ Y^{\prime}=c_{1}+\mathrm{e}^{x}c_{2},\quad Y^{\prime \prime}=\mathrm{e}^{x}c_{2}+c_{1}^{\prime}+\mathrm{e}^{x}c_{2}^{\prime}. $$ 

将  $ Y, Y' $,  $ Y'' $ 代入原非齐次方程，并整理后得

 $$ c_{1}^{\prime}+\mathrm{e}^{x}c_{2}^{\prime}=x\mathrm{e}^{x}. $$ 

联立(15)式与(16)式所成的方程组，可以解得  $ c_{1}^{\prime}=-e^{x}, c_{2}^{\prime}=x+1 $ 。于是可取  $ c_{1}=-e^{x}, c_{2}=\frac{1}{2}x^{2}+x $ ，因此  $ Y(x)=\left(\frac{x^{2}}{2}-1\right)e^{x} $ 。所以所求非齐次方程的通解为

 $$ y(x)=\left(\frac{x^{2}}{2}-1\right)\mathrm{e}^{x}+C_{1}(x+1)+C_{2}\mathrm{e}^{x}. $$ 

最后指出，情形 2 中所使用的方法对于 n 阶方程(1)与(2)同样适用.

设  $ y_{1}(x),\cdots,y_{n}(x) $ 为 n 阶齐次方程(2) 的 n 个线性无关解，求相应的非齐次方程(1) 的一个特解.

设方程(1)有形如  $ Y(x)=c_{1}(x)y_{1}(x)+\cdots+c_{n}(x)y_{n}(x) $ 的特解，其中  $ c_{1}(x),\cdots,c_{n}(x) $ 为 n 个待定函数。为确定  $ c_{1}(x),\cdots,c_{n}(x) $，我们只有  $ Y(x) $ 满足方程(1)这一个条件，还需要增加 n-1 个条件。类似于二阶的情形，可以增加条件

 $$ c_{1}^{\prime}y_{1}^{(k)}+\cdots+c_{n}^{\prime}y_{n}^{(k)}=0\quad(k=0,1,\cdots,n-2), $$ 

此时有