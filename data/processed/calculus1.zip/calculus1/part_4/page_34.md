 $$ p^{(n-k)}=F(x,p,p^{\prime},\cdots,p^{(n-k-1)}). $$ 

如果  $ p(x) $ 为方程(2)的解，则对  $ p(x) $ 积分 k 次便得到方程(1)的解.

求解方程  $ y'' = e^{x} + x. $

解 对方程两端积分两次可得

 $$ \begin{aligned}&y^{\prime \prime}=\int(\mathrm{e}^{x}+x)\mathrm{d}x=\mathrm{e}^{x}+\frac{1}{2}x^{2}+C_{1},\\&y^{\prime}=\int\left(\mathrm{e}^{x}+\frac{1}{2}x^{2}+C_{1}\right)\mathrm{d}x=\mathrm{e}^{x}+\frac{1}{3!}x^{3}+C_{1}x+C_{2}.\\ \end{aligned} $$ 

再积分一次即得原方程的通解：

 $$ y=\mathrm{e}^{x}+\frac{1}{4!}x^{4}+\frac{1}{2}C_{1}x^{2}+C_{2}x+C_{3}. $$ 

▶ 例 7.3.2 ……

求解方程  $ xy'' - 3y'' = 2x - 3. $

解  $ p(x)=y''(x) $，则原方程可化为

 $$ p^{\prime}-3\frac{p}{x}=2-\frac{3}{x}, $$ 

这是一阶线性方程，它对应的齐次方程为  $ p^{\prime}-3\frac{p}{x}=0 $。解之得  $ p=Cx^{3} $。

设方程(3)有解  $ p=C(x)x^{3} $，将其代入方程(3)，可得  $ C'(x)=\frac{2}{x^{3}}-\frac{3}{x^{4}} $，于是

 $$ C(x)=x^{-3}-x^{-2}+C_{1}. $$ 

所以方程(3)的通解为  $ p=1-x+C_{1}x^{3} $. 再由  $ p(x)=y''(x) $ 可得

 $$ y^{^{\prime}}=x-\frac{1}{2}x^{2}+C_{1}x^{4}+C_{2}, $$ 

于是原方程的通解为

 $$ y=\frac{1}{2}x^{2}-\frac{1}{6}x^{3}+C_{1}x^{5}+C_{2}x+C_{3}. $$ 

▶ 例 7.3.3 ……

求解方程  $ xy'' - y' = x^{2} $

解  $ p(x)=y'(x) $，则原方程可化为

 $$ xp^{^{\prime}}-p=x^{2}, $$ 

从而

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\Big(\frac{p(x)}{x}-x\Big)=\frac{x p^{\prime}(x)-p(x)}{x^{2}}-1=0, $$ 