设  $ \lambda = r $ 为方程  $ y'' + ay' + by = 0 $ 的二重特征根，此时  $ a = -2r, b = r^{2} $. 由于

 $$ (x\mathrm{e}^{rx})^{\prime}=(rx+1)\mathrm{e}^{rx},\quad(x\mathrm{e}^{rx})^{\prime \prime}=(r^{2}x+2r)\mathrm{e}^{rx}. $$ 

于是，

 $$ (x\mathrm{e}^{rx})^{\prime \prime}-2r(x\mathrm{e}^{rx})^{\prime}+r^{2}x\mathrm{e}^{rx}=0. $$ 

即  $ e^{rx} $ 与  $ xe^{rx} $ 都是方程  $ y'' + ay' + by = 0 $ 的解.

由于特征方程(4)有 n 个根(重根按重数计)，根据上述结论，也可以得到方程(2)的 n 个线性无关解.

需要注意的是，方程(2)的特征根  $ \lambda $ 可能是复值的。当  $ \lambda = \alpha + i\beta $ 是方程(2)的复特征根时，相应的解  $ e^{ix} $ 或  $ x^j e^{ix} $ 就是复值解。由于特征多项式是实系数的，因而  $ \lambda = \alpha - i\beta $ 也是方程(2)的复特征根，并且根的重数也与  $ \lambda $ 相同。所以，对于方程(2)的  $ k(k \geqslant 1) $ 重特征根  $ \lambda = \alpha + i\beta $ 与  $ \lambda = \alpha - i\beta $，相应地有方程(2)的  $ 2k $ 个复值解  $ e^{ix} $， $ x e^{ix} $， $ \cdots $， $ x^{k-1} e^{ix} $ 与  $ e^{\tilde{\lambda} x} $， $ x e^{\tilde{\lambda} x} $， $ \cdots $， $ x^{k-1} e^{\tilde{\lambda} x} $。根据命题 7.5.1，将它们的实部与虚部分别取出，便可以得到方程(2)的  $ 2k $ 个线性无关的实值解：

 $$ \begin{aligned}&\mathrm{e}^{ax}\cos\beta x,x\mathrm{e}^{ax}\cos\beta x,\cdots,x^{k-1}\mathrm{e}^{ax}\cos\beta x,\\&\mathrm{e}^{ax}\sin\beta x,x\mathrm{e}^{ax}\sin\beta x,\cdots,x^{k-1}\mathrm{e}^{ax}\sin\beta x.\\ \end{aligned} $$ 

求方程  $ y'' + 2y' + 2y = 0 $ 的通解.

解 此方程的特征方程为  $ \lambda^{2}+2\lambda+2=0 $，它的特征根为  $ \lambda=-1\pm i $，因而此方程有两个线性无关解  $ e^{-x}\cos x $ 与  $ e^{-x}\sin x $，所以它的通解为： $ y(x)=e^{-x}(C_{1}\cos x+C_{2}\sin x) $.

求解方程  $ y'' - 5y'' + 8y' - 4y = 0 $.

解 此方程的特征方程为  $ \lambda^{3}-5\lambda^{2}+8\lambda-4=0 $，它的特征根为  $ \lambda_{1}=\lambda_{2}=2 $， $ \lambda_{3}=1 $。因而此方程有三个线性无关解  $ e^{2x}, x e^{2x} $ 与  $ e^{x} $。所以它的通解为

 $$ y(x)=C_{1}\mathrm{e}^{2x}+C_{2}x\mathrm{e}^{2x}+C_{3}\mathrm{e}^{x}. $$ 

求解方程  $ y^{(4)}+2y''+y=0. $

解 特征方程为  $ \lambda^{4}+2\lambda^{2}+1=0 $，它有一对二重共轭复根  $ \pm i $，因而此方程有四个线性无关解  $ \cos x, \sin x, x \cos x, x \sin x $。所以它的通解为

 $$ y(x)=C_{1}\cos x+C_{2}\sin x+C_{3}x\cos x+C_{4}x\sin x. $$ 

#### 7.5.2 常系数非齐次线性方程

在 7.5.1 节中，我们已经知道如何求解常系数齐次线性方程(2). 根据线性