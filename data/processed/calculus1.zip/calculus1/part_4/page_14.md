#### 定理 6.2.11（阿贝尔判别法）

设 f 在  $ [a, b) $ 上定义，在 b 点附近无界，并且  $ \forall \delta \in (0, b-a) $，有  $ f \in R[a, b-\delta] $。如果取积分  $ \int_{a}^{b} f(x) \, dx $ 收敛， $ g(x) $ 在  $ [a, b) $ 上单调有界，则取积分  $ \int_{a}^{b} f(x) g(x) \, dx $ 收敛。

#### ▶ 例 6.2.5

讨论取积分 $ \int_{0}^{1}\frac{1}{x}\sin\frac{1}{x}dx $的收敛性与绝对收敛性.

解 x=0 为取点. 作变换  $ t=\frac{1}{x} $， $ \forall \delta \in (0,1) $，可得

 $$ \int_{a}^{1}\frac{1}{x}\sin\frac{1}{x}\mathrm{d}x=\int_{1}^{a^{-1}}\frac{\sin t}{t}\mathrm{d}t, $$ 

 $$ \int_{\delta}^{1}\left|\frac{1}{x}\sin\frac{1}{x}\right|\mathrm{d}x=\int_{1}^{\delta^{-1}}\left|\frac{\sin t}{t}\right|\mathrm{d}t. $$ 

由于 $ \int_{1}^{+\infty}\frac{\sin t}{t}dt $条件收敛，根据上面两等式便知积分 $ \int_{0}^{1}\frac{1}{x}\sin\frac{1}{x}dx $条件收敛.

判别下列取积分的收敛性.

 $$ \int_{0}^{1}\sqrt{\cot x}\mathrm{d}x\;;\;(2)\int_{0}^{1}\frac{\ln x}{x^{p}}\mathrm{d}x\;;\;(3)\int_{0}^{1}\frac{\cos x}{x}\bullet\sin\frac{1}{x}\mathrm{d}x. $$ 

解（1）x=0 为瑕点。由于

 $$ \lim_{x\to0^{+}}\frac{\sqrt{\cot x}}{\frac{1}{\sqrt{x}}}=\lim_{x\to0^{+}}\sqrt{\cos x}\cdot\sqrt{\frac{x}{\sin x}}=1, $$ 

且取积分 $ \int_{0}^{1}\frac{dx}{\sqrt{x}} $收敛，根据定理6.2.9可知取积分 $ \int_{0}^{1}\sqrt{\cot x}dx $收敛.

(2) 当  $ p \geqslant 1 $ 时，

 $$ \frac{-x^{-p}\ln x}{x^{-p}}=-\ln x\geqslant1,\quad x\in\left(0,\frac{1}{\mathrm{e}}\right). $$ 

而取积分 $ \int_{0}^{1}x^{-p}dx $发散，根据定理6.2.8可知取积分 $ \int_{0}^{1}-x^{-p}\ln xdx $发散 $ (-lnx\geqslant0) $，从而取积分 $ \int_{0}^{1}x^{-p}\ln xdx $发散.

当 p<1 时，取  $ q\in(p,1) $，于是取积分  $ \int_{0}^{1}x^{-q}dx $ 收敛。注意到

 $$ \lim_{x\to0^{+}}\frac{-x^{-p}\ln x}{x^{-q}}=-\lim_{x\to0^{+}}x^{q-p}\ln x=0, $$ 