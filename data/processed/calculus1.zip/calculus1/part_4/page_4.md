设 p>0. 讨论取积分  $ \int_{0}^{1}\frac{dx}{x^{p}} $ 的收敛性.

解 x=0 为取点.

 $$ \int_{\delta}^{1}\frac{\mathrm{d}x}{x^{p}}=\left\{\begin{aligned}&\ln\delta,&p=1,\\&\frac{1-\delta^{1-p}}{1-p},&p\neq1.\end{aligned}\right. $$ 

于是当 0 < p < 1 时， $ \lim_{\delta \to 0^{+}} \int_{\delta}^{1} \frac{dx}{x^{\beta}} = \frac{1}{1 - p} $；当  $ p \geqslant 1 $ 时， $ \int_{\delta}^{1} \frac{dx}{x^{\beta}} \to +\infty (\delta \to 0^{+}) $。所以，取积分  $ \int_{0}^{1} \frac{dx}{x^{\beta}} $ 当 0 < p < 1 时收敛；当  $ p \geqslant 1 $ 时发散。

设函数 f 在点 a 与点 b 附近都无界．如果存在数  $ c \in (a, b) $，使得瑕积分  $ \int_{a}^{c} f(x) \, dx $ 与  $ \int_{c}^{b} f(x) \, dx $ 都收敛，则称瑕积分  $ \int_{a}^{b} f(x) \, dx $ 收敛.

类似地，设函数 f 在点 a 附近无界．如果存在 c > a，使得瑕积分  $ \int_{a}^{c} f(x) \, dx $ 与无穷限积分  $ \int_{c}^{+\infty} f(x) \, dx $ 都收敛，则称广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 收敛.

不难看到，上述瑕积分 $ \int_{a}^{b}f(x)dx $及广义积分 $ \int_{a}^{+\infty}f(x)dx $的收敛性与c的选取无关.

例6.19

计算 $ \int_{-1}^{1}\frac{dx}{\sqrt{1-x^{2}}} $

解  $ x=\pm1 $ 为取点，依定义，

 $$ \int_{0}^{1}\frac{\mathrm{d}x}{\sqrt{1-x^{2}}}=\lim_{\delta\rightarrow0^{+}}\int_{0}^{1-\delta}\frac{\mathrm{d}x}{\sqrt{1-x^{2}}}=\lim_{\delta\rightarrow0^{+}}\arcsin(1-\delta)=\frac{\pi}{2}. $$ 

同理，

 $$ \int_{-1}^{0}\frac{\mathrm{d}x}{\sqrt{1-x^{2}}}=\lim_{x\to0^{+}}\int_{-1+x}^{0}\frac{\mathrm{d}x}{\sqrt{1-x^{2}}}=\frac{\pi}{2}. $$ 

所以 $ \int_{-1}^{1}\frac{dx}{\sqrt{1-x^{2}}}=\pi. $

#### ▶ 例 6.1.9

计算 $ \int_{0}^{+\infty}\frac{dx}{\sqrt{x}(1+x)} $

解 x=0 为瑕点，