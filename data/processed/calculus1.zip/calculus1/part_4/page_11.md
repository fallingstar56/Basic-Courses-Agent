从而

 $$ \begin{align*}\int_{a}^{b}f(x)g(x)\mathrm{d}x&=F(x)g(x)\mid_{a}^{b}-F(\xi)\int_{a}^{b}g^{\prime}(x)\mathrm{d}x\\&=F(b)g(b)-F(\xi)\big[g(b)-g(a)\big]\\&=g(a)\int_{a}^{\xi}f(x)\mathrm{d}x+g(b)\int_{\xi}^{b}f(x)\mathrm{d}x.\end{align*} $$ 

定理 6.2.5（狄利克雷判别法）

设  $ F(t)=\int_{a}^{t}f(x)dx $ 在  $ [a,+\infty) $ 上有界， $ g(x) $ 在  $ [a,+\infty) $ 上单调且  $ \lim_{x\to+\infty}g(x)=0 $，则广义积分  $ \int_{a}^{+\infty}f(x)g(x)dx $ 收敛.

证明 任取  $ A_{2} > A_{1} \geqslant a $，对  $ f(x) $ 与  $ g(x) $ 在区间  $ [A_{1}, A_{2}] $ 上应用积分第二中值定理可得， $ \exists \xi \in [A_{1}, A_{2}] $ 使得

 $$ \int_{A_{1}}^{A_{2}}f(x)g(x)\mathrm{d}x=g(A_{1})\int_{A_{1}}^{\xi}f(x)\mathrm{d}x+g(A_{2})\int_{\xi}^{A_{2}}f(x)\mathrm{d}x. $$ 

由于  $ F(t)=\int_{a}^{t}f(x)dx $ 在  $ [a,+\infty) $ 上有界： $ |F(t)|\leqslant C,t\geqslant a $ ，因此，任取  $ t_{2}>t_{1}\geqslant a $

 $$ \left|\int_{t_{1}}^{t_{2}}f(x)\mathrm{d}x\right|=\mid F(t_{2})-F(t_{1})\mid\leqslant2C. $$ 

另一方面， $ \lim_{x\to+\infty}g(x)=0 $，从而 $ \forall\varepsilon>0,\exists M $使得当x>M时，有

 $$ \mid g(x)\mid<\frac{\varepsilon}{4C}. $$ 

结合(3)，(4)，(5)式即知当 $ A_{2}>A_{1}>M $时，有

 $$ \left|\int_{A_{1}}^{A_{2}}f(x)g(x)\mathrm{d}x\right|<\varepsilon. $$ 

根据定理 6.2.1 便知广义积分  $ \int_{a}^{+\infty}f(x)g(x)dx $ 收敛.

定理 6.2.6（阿贝尔判别法）

设广义积分  $ \int_{a}^{+\infty}f(x)dx $ 收敛， $ g(x) $ 在  $ [a,+\infty) $ 上单调有界，则广义积分  $ \int_{a}^{+\infty}f(x)g(x)dx $ 收敛.

证明 由于  $ g(x) $ 在  $ [a, +\infty) $ 上单调有界，极限  $ \lim_{x \to +\infty} g(x) = b $ 存在，于是  $ g_{1}(x) = g(x) - b $ 在  $ [a, +\infty) $ 上单调且  $ \lim_{x \to +\infty} g_{1}(x) = 0 $。由此知  $ f(x) $ 与  $ g_{1}(x) $ 满足定理 6.2.5 的条件，从而  $ \int_{a}^{+\infty} f(x) [g(x) - b] \, dx $ 收敛。又因为  $ \int_{a}^{+\infty} f(x) \, dx $ 收敛，所以