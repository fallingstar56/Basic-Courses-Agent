解 原方程对应的齐次线性方程为  $ y' - 2xy = 0 $. 解之得： $ y = C e^{x^2} $

设原方程有解  $ y=C(x)e^{x^{2}} $，其中  $ C(x) $ 为待定函数。将其代入原方程，可得  $ C'(x)=2x $，于是  $ C(x)=x^{2}+C $。所以原方程的通解为  $ y=(x^{2}+C)e^{x^{2}} $。

求解方程  $ \frac{dy}{dx}+\frac{1}{x}y=\frac{\sin x}{x} $.

解法一 原方程对应的线性齐次方程为  $ y'+\frac{y}{x}=0 $. 解之得： $ y=\frac{C}{x} $

设原方程有解  $ y=\frac{C(x)}{x} $，其中  $ C(x) $ 为待定函数。将其代入原方程，可得  $ C'(x)=\sin x $，于是  $ C(x)=-\cos x+C $。所以原方程的通解为  $ y=\frac{1}{x}(C-\cos x) $。

解法二 应用公式(5)，原方程的通解为

 $$ y(x)=\mathrm{e}^{-\int\frac{1}{x}\mathrm{d}x}\left(C+\int\frac{\sin x}{x}\mathrm{e}^{\int\frac{1}{x}\mathrm{d}x}\mathrm{d}x\right) $$ 

解法三 原方程两边同乘 x，得

 $$ xy^{\prime}+y=\sin x, $$ 

即

 $$ (xy)^{\prime}=\sin x. $$ 

两边积分便得到

 $$ xy=\int\sin x\mathrm{d}x+C=-\cos x+C. $$ 

所以原方程的通解为  $ y=\frac{1}{x}(-\cos x+C) $.

求解方程  $ y^{2}dx+(x-2xy-y^{2})dy=0. $

解 原方程可化为

 $$ \frac{\mathrm{d}x}{\mathrm{d}y}+\frac{1-2y}{y^{2}}x=1. $$ 

将 y 看作自变量，x 看作因变量，此方程为线性方程。它对应的齐次方程为

 $$ \frac{\mathrm{d}x}{\mathrm{d}y}=-\frac{1-2y}{y^{2}}x. $$ 

解之得, $ x=Cy^{2}e^{\frac{1}{y}} $.设方程(6)有形如 $ x=C(y)y^{2}e^{\frac{1}{y}} $的解，代入方程(6)可得

 $$ C^{\prime}(y)y^{2}\mathrm{e}^{\frac{1}{y}}=1, $$ 