式. 要使得此多项式在区间 I 上恒等于零, 只能有  $ c_{1}, c_{2}, \cdots, c_{m} $ 全为零. 所以结论成立.

下面引入的朗斯基行列式的概念对于研究线性微分方程解的线性相关性具有重要作用.

设  $ y_{1}, y_{2}, \cdots, y_{m} \in C^{m-1}(I) $. 定义  $ y_{1}, y_{2}, \cdots, y_{m} $ 的朗斯基行列式为

 $$ W(x)=W[y_{1},y_{2},\cdots,y_{m}](x)=\left|\begin{array}{cccc}y_{1}(x)&y_{2}(x)&\cdots&y_{m}(x)\\y_{1}^{\prime}(x)&y_{2}^{\prime}(x)&\cdots&y_{m}^{\prime}(x)\\\vdots&\ddots&\vdots&\vdots\\y_{1}^{(m-1)}(x)&y_{2}^{(m-1)}(x)&\cdots&y_{m}^{(m-1)}(x)\end{array}\right|. $$ 

定理 7.4.3

设  $ y_{1}, y_{2}, \cdots, y_{n} \in C^{n-1}(I) $.

(1) 若  $ y_{1}, y_{2}, \cdots, y_{n} $ 在区间 I 上线性相关，则

 $$ W[y_{1},y_{2},\cdots,y_{n}](x)\equiv0,\quad x\in I. $$ 

(2) 若  $ y_1, y_2, \cdots, y_n $ 为方程(2)的  $ n $ 个解，且在区间  $ I $ 上线性无关，则  $ \forall x \in I $，

 $$ W[y_{1},y_{2},\cdots,y_{n}](x)\neq0. $$ 

也就是说，如果  $ y_{1}, y_{2}, \cdots, y_{n} $ 为方程(2)的 n 个解，则  $ W[y_{1}, y_{2}, \cdots, y_{n}] $ 或恒为零，或在每一点都不为零.

证明 （1）设  $ y_{1}, y_{2}, \cdots, y_{n} $ 在区间 I 上线性相关，则存在一组不全为零的实数  $ c_{1}, c_{2}, \cdots, c_{n} $，使得  $ \forall x \in I $，有

 $$ c_{1}y_{1}(x)+c_{2}y_{2}(x)+\cdots+c_{n}y_{n}(x)=0. $$ 

对此式逐次求导，可得

 $$ c_{1}y_{1}^{(k)}(x)+c_{2}y_{2}^{(k)}(x)+\cdots+c_{n}y_{n}^{(k)}(x)=0,\quad k=0,1,\cdots,n-1. $$ 

将(3)式看作关于未知数  $ c_{1}, c_{2}, \cdots, c_{n} $ 的 n 阶线性代数方程组，则此方程组有非零解  $ c_{1}, c_{2}, \cdots, c_{n} $，从而它的系数行列式  $ W[y_{1}, y_{2}, \cdots, y_{n}](x) = 0, \forall x \in I. $

(2) 设  $ y_{1}, y_{2}, \cdots, y_{n} $ 为方程(2)的解，且在 I 上线性无关。假设  $ \exists x_{0} \in I $，使得

 $$ W\left[y_{1},y_{2},\cdots,y_{n}\right](x_{0})=0. $$ 

考虑关于未知数  $ c_{1}, c_{2}, \cdots, c_{n} $ 的 n 阶线性代数方程组

 $ c_{1}y_{1}^{(k)}(x_{0})+c_{2}y_{2}^{(k)}(x_{0})+\cdots+c_{n}y_{n}^{(k)}(x_{0})=0,\quad k=0,1,\cdots,n-1,\quad(\cdot $ 它的系数行列式  $ W\left[y_{1},y_{2},\cdots,y_{n}\right](x_{0})=0 $ ，因此它有非零解，仍记为  $ c_{1},c_{2},\cdots,c_{n} $ 。令

 $$ y(x)=c_{1}y_{1}(x)+c_{2}y_{2}(x)+\cdots+c_{n}y_{n}(x),\quad x\in I, $$ 