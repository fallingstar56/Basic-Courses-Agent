再由条件式(1)，只要  $ A_{2}>A_{1}>M=\max\{K,M_{1}\} $，就有

 $$ \int_{A_{1}}^{A_{2}}\mid f(x)\mid\mathrm{d}x\leqslant\int_{A_{1}}^{A_{2}}C g(x)\mathrm{d}x<\varepsilon. $$ 

根据定理 6.2.1 便知， $ \int_{a}^{+\infty}|f(x)|\,dx $ 收敛，即  $ \int_{a}^{+\infty}f(x)\,\mathrm{d}x $ 绝对收敛.

(2) 假设  $ \int_{a}^{+\infty} g(x) \, dx $ 收敛，则由(1)， $ \int_{a}^{+\infty} f(x) \, dx $ 绝对收敛。这与定理条件相矛盾。所以  $ \int_{a}^{+\infty} g(x) \, dx $ 发散。

判别广义积分 $ \int_{0}^{+\infty}\frac{\sin x}{1+x^{2}}dx $的收敛性.

解  $ \left|\frac{\sin x}{1+x^{2}}\right|\leqslant\frac{1}{x^{2}+1}\quad(x\geqslant0) $

而广义积分  $ \int_{0}^{+\infty}\frac{dx}{1+x^{2}} $ 收敛. 由比较判别法可得  $ \int_{0}^{+\infty}\frac{\left|\sin x\right|}{1+x^{2}}dx $ 收敛，即  $ \int_{0}^{+\infty}\frac{\sin x}{1+x^{2}}dx $ 绝对收敛从而也收敛.

比较判别法具有下列极限形式，在许多情况下这种形式在应用上更为便捷。

设非负函数  $ f, g $ 在  $ [a, +\infty) $ 上定义， $ \forall A > a, f, g \in R[a, A] $，并且

 $$ \lim_{x\to+\infty}\frac{f(x)}{g(x)}=C. $$ 

(1) 如果 C > 0，则广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 与  $ \int_{a}^{+\infty} g(x) \, dx $ 同收敛同发散；

(2) 如果 C=0，且广义积分  $ \int_{a}^{+\infty} g(x) \, dx $ 收敛，则广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 收敛.

证明（1）由式(2)，存在正数  $ K \geqslant a $，使得当  $ x \geqslant K $ 时，

 $$ \frac{C}{2}g(x)\leqslant f(x)\leqslant2Cg(x). $$ 

应用定理 6.2.2(1) 即知广义积分  $ \int_{a}^{+\infty} f(x) \, dx $ 与  $ \int_{a}^{+\infty} g(x) \, dx $ 同时敛散.

(2) 的证明留给读者来完成.

判别下列广义积分的收敛性.

(1)

 $$ \int_{1}^{+\infty}\frac{x^{2}\mathrm{d}x}{\mathrm{e}^{x}+x}\text{；}(2)\int_{1}^{+\infty}\frac{\ln x}{\sqrt{x^{3}+2x+1}}\mathrm{d}x\text{；}(3)\int_{2}^{+\infty}\frac{\mathrm{d}x}{x(\ln x+9)}. $$ 