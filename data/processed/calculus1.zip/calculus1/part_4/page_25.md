(5)

 $$ \begin{cases}\frac{\mathrm{d}y}{\mathrm{d}x}=1-\frac{y}{x},\\y(2)=\frac{3}{2},\\y=\frac{1}{x}+\frac{x}{2};\end{cases} $$ 

(6) $ (x-y+1)y'=1,\quad y-x=Ce^{y} $ (C为任意常数);

(7) $ y''=y(y')^{2},\quad\int_{0}^{y}e^{-\frac{t^{2}}{2}}dt+x=1. $

4. 确定常数 k 的值，使下列方程具有相应的特解.

(1) $ y^{\prime}+2y=0,\quad y=e^{kx} $;

(2) $ y''-3y'-4y=0,\quad y=e^{kx} $;

(3) $ x^{2}y''+4xy'-10y=0,\quad y=x^{k} $;

(4) $ x^{2}y^{\prime\prime}-4xy^{\prime}+4y=0,\quad y=x^{k}. $

5. 验证  $ y = Cx^{3} $ 是微分方程  $ 3y - xy' = 0 $ 的一般解，并分别求过  $ A(1,1) $ 与  $ B\left(1, -\frac{1}{3}\right) $ 的两条积分曲线.

### 7.2 一阶常微分方程的初等解法

对于一些简单类型的一阶常微分方程，可以用不定积分的方法求其通解。这样的方法称为初等积分法。本节主要介绍几类常见的可以用初等积分法求解的一阶常微分方程。

#### 7.2.1 变量分离型常微分方程

形如

 $$ \frac{\mathrm{d}y}{\mathrm{d}x}=f(x)g(y) $$ 

或

 $$ p(x)\mathrm{d}x=q(y)\mathrm{d}y $$ 

的常微分方程称为变量分离型方程.

如果  $ y = y(x) $ 是方程(1)的解，则应有

 $$ p(x)\mathrm{d}x\equiv q(y(x))y^{\prime}(x)\mathrm{d}x. $$ 

两端积分可得

 $$ \int p(x)\mathrm{d}x=\int q(y(x))y^{\prime}(x)\mathrm{d}x=\int q(y)\mathrm{d}y. $$ 

从而得到方程(1)的隐式解.

#### ▶ 例 7.2.1

求方程  $ y' = e^{x-y} $ 的通解.