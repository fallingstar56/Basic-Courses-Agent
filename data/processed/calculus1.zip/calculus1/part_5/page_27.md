(9) $ y=\frac{1}{12}(x+C_{1})^{3}+C_{2}. $

### 习题 7.4

2. 提示：利用解的存在唯一性定理.

5. (1)  $  y = (x \ln x - x + C_{1} x + C_{2}) e^{x}  $;

(2) $ y=x(x^{2}+C_{1}x+C_{2}); $

(3)  $ y = -\frac{1}{2} \cos x + C_{1} e^{-x} + C_{2} e^{x} $;

(4) $ y=x^{3}+C_{1}x^{2}+\frac{C_{2}}{x}; $

(5)  $ y = C_{1}x + C_{2}e^{x} - 1 $;

(6)  $ -\frac{x^{2}}{8}\cos2x+\frac{x}{16}\sin2x+C_{1}\cos2x+C_{2}\sin2x. $

6.  $ y=\frac{a+b}{2}e^{x}+\frac{a-b}{2}e^{-x} $

7. (1)  $ y'' + 2y' + y = 0 $; (2)  $ y''' + y = 0 $.

8.  $ C_{1}+C_{2}x+C_{3}(x-x^{3})+x+x^{2} $

### 习题 7.5

2. (1)  $ y = \frac{e^x - e^{-x}}{2} $;

(2)  $  y = (1 - 2x) e^{3x}  $;

(3) $ y=\frac{3}{2}-\frac{3}{5}e^{-x}+\frac{1}{10}e^{4x}. $

3. (1)  $ y = C_{1} e^{-2x} + C_{2} e^{6x} - \frac{1}{12} x^{2} + \frac{1}{18} x - \frac{7}{216} $;

(2)  $ y = C_{1} e^{-2x} + C_{2} e^{6x} - \frac{1}{20} e^{-4x} $;

 $$ y=C_{1}\mathrm{e}^{2x}+C_{2}x\mathrm{e}^{2x}+\frac{1}{6}x^{3}\mathrm{e}^{2x} $$ 

(4)  $  y = (C_1 + C_2 x) e^{-x} - \frac{1}{2} \cos x  $;

 $$ y=C_{1}\mathrm{e}^{-x}+C_{2}x\mathrm{e}^{-x}+\frac{3}{25}\mathrm{e}^{x}\cos x+\frac{4}{25}\mathrm{e}^{x}\sin x; $$ 

 $$ y=C_{1}\mathrm{e}^{-x}+C_{2}\mathrm{e}^{-2x}+\left(\frac{1}{2}x^{2}-\frac{3}{2}x+\frac{7}{4}\right)\left(\frac{1}{10}\sin x-\frac{3}{10}\cos x\right); $$ 

(7)  $ y = C_{1} e^{-2x} \cos x + C_{2} e^{-2x} \sin x - \frac{1}{2} x e^{-2x} \cos x; $

 $$ y=\left(C_{1}+C_{2}x+\frac{1}{6}x^{3}\right)\mathrm{e}^{2x}+\frac{1}{4}-\frac{3}{25}\sin x+\frac{4}{25}\cos x； $$ 