可解得 A 的属于  $ \lambda_{1}=2 $ 的特征向量  $ \boldsymbol{U}_{1}=(2,-1)^{\mathrm{T}} $ 与属于  $ \lambda_{2}=3 $ 的特征向量  $ \boldsymbol{U}_{2}=(-1,1)^{\mathrm{T}} $ 。从而原方程组有基本解矩阵  $ \boldsymbol{\Phi}(x)=(\mathrm{e}^{2x}\boldsymbol{U}_{1},\mathrm{e}^{3x}\boldsymbol{U}_{2})=\begin{pmatrix}2\mathrm{e}^{2x}&-\mathrm{e}^{3x}\\-\mathrm{e}^{2x}&\mathrm{e}^{3x}\end{pmatrix} $，它的通解为

 $$ \boldsymbol{Y}(x)=\boldsymbol{\varPhi}\left(x\right)\binom{c_{1}}{c_{2}}=c_{1}\mathrm{e}^{2x}\binom{2}{-1}+c_{2}\mathrm{e}^{3x}\binom{-1}{1}. $$ 

▶ 例 7.6.4

求方程组 $ Y^{\prime}=AY $的满足定解条件 $ \boldsymbol{Y}(0)=(-1,3,1)^{\mathrm{T}} $的特解.其中

 $$ \begin{aligned}\boldsymbol{A}&=\begin{pmatrix}{{{1}}}&{{{2}}}&{{{2}}} \\{{{2}}}&{{{1}}}&{{{2}}} \\{{{2}}}&{{{2}}}&{{{1}}}\end{pmatrix}.\end{aligned} $$ 

解  $ \det(\lambda\boldsymbol{I}-\boldsymbol{A})=(\lambda-5)(\lambda+1)^{2} $

所以 A 的特征根为  $ \lambda_{1}=5,\lambda_{2}=\lambda_{3}=-1 $。分别求解特征方程  $ (5\boldsymbol{I}-\boldsymbol{A})\boldsymbol{U}=\boldsymbol{0} $ 与  $ (-1-\boldsymbol{A})\boldsymbol{U}=0 $ 可解得 A 的属于  $ \lambda_{1}=5 $ 的特征向量  $ \boldsymbol{U}_{1}=(1,1,1)^{\mathrm{T}} $ 与属于  $ \lambda_{2}=\lambda_{3}=-1 $ 的线性无关的特征向量  $ \boldsymbol{U}_{2}=(1,0,-1)^{\mathrm{T}} $ 与  $ \boldsymbol{U}_{3}=(0,1,-1)^{\mathrm{T}} $。从而原方程组有基本解矩阵  $ \boldsymbol{\Phi}(x)=(\mathrm{e}^{5x}\boldsymbol{U}_{1}\mathrm{e}^{-x}\boldsymbol{U}_{2}\mathrm{e}^{-x}\boldsymbol{U}_{3}) $，它的通解为  $ \boldsymbol{Y}(x)=\boldsymbol{\Phi}(x)(c_{1},c_{2},c_{3})^{\mathrm{T}} $。代入定解条件：

 $$ \left(\boldsymbol{U}_{1}\quad\boldsymbol{U}_{2}\quad\boldsymbol{U}_{3}\right)\left(c_{1},c_{2},c_{3}\right)^{\mathrm{T}}=\boldsymbol{\varPhi}\left(0\right)\left(c_{1},c_{2},c_{3}\right)^{\mathrm{T}}=\bar{\boldsymbol{Y}}\left(0\right)=\left(-1,3,1\right)^{\mathrm{T}} $$ 

可解得  $ c_{1}=1, c_{2}=-2, c_{3}=2 $ 。于是所求特解为

 $$ \widetilde{\mathbf{Y}}(x)=\mathrm{e}^{5x}\mathbf{U}_{1}-2\mathrm{e}^{-x}\mathbf{U}_{2}+2\mathrm{e}^{-x}\mathbf{U}_{3}=\begin{pmatrix}\mathrm{e}^{5x}-2\mathrm{e}^{-x}\\ \mathrm{e}^{5x}+2\mathrm{e}^{-x}\\ \mathrm{e}^{5x}\end{pmatrix}. $$ 

情形二 矩阵 A 的线性无关的特征向量个数小于 n. 在这种情况下，为求得方程组(18)的 n 个线性无关解，我们不加证明地引用来自线性代数的下列命题：

命题 7.6.1

设 n 阶矩阵 A 有 m 个不同的特征根  $ \lambda_{1}, \lambda_{2}, \cdots, \lambda_{m} $，其重数分别为  $ k_{1}, k_{2}, \cdots, k_{m} (k_{1} + k_{2} + \cdots + k_{m} = n) $。记  $ V_{i} $ 为代数方程组

 $$ (\lambda_{j}\mathbf{I}-\mathbf{A})^{k_{j}}\mathbf{U}=\mathbf{0} $$ 

的解空间 $ (j=1,2,\cdots,m) $，则 $ V_{j} $是 $ k_{j} $维线性空间，并且 $ \mathbb{R}^{n}=V_{1}\oplus V_{2}\oplus\cdots\oplus V_{m} $

现在设  $ \lambda $ 为 A 的 k 重特征根，U 为方程组  $ (\lambda I - A)^{k}U = 0 $ 的一个非零解。令

 $$ \mathbf{Y}(x)=\mathrm{e}^{\lambda x}\Big[\mathbf{I}+x(\mathbf{A}-\lambda\mathbf{I})+\cdots+\frac{x^{k-1}}{(k-1)!}(\mathbf{A}-\lambda\mathbf{I})^{k-1}\Big]\mathbf{U}. $$ 

直接计算可得