证明（1）通过简单验证即可得到(1)的结论，留给读者作为练习.

(2) 对于方程组(1)的任一解  $ \mathbf{Y}(x) $，由定理 7.6.5(1)， $ \mathbf{Y}(x)-\overline{\mathbf{Y}}(x) $ 为方程组(2)的解，从而可以表示为  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 的线性组合：

 $$ \mathbf{Y}(x)-\mathbf{\bar{Y}}(x)=c_{1}\mathbf{Y}_{1}(x)+c_{2}\mathbf{Y}_{2}(x)+\cdots+c_{n}\mathbf{Y}_{n}(x). $$ 

即存在一组常数  $ c_{1}, c_{2}, \cdots, c_{n} $，使得(8)式成立.

反之，对于任一组常数  $ c_{1}, c_{2}, \cdots, c_{n} $，(8)式都是方程组(1)的解。所以(8)式就是非齐次方程组(1)的通解表达式。

设已知 $ \Phi(x)=(\mathbf{Y}_{1}(x)\quad\mathbf{Y}_{2}(x)\quad\cdots\quad\mathbf{Y}_{n}(x)) $为齐次方程组(2)的一个基本解矩阵.为了求解非齐次方程组(1)，由定理7.6.5，我们还需要找到方程组(1)的一个特解.类似于高阶线性常微分方程的情形，可以使用常数变易法.

假定方程组(1)有形如 $ \boldsymbol{Y}(x)=\boldsymbol{\Phi}(x)\boldsymbol{C}(x) $的解，其中

 $$ \boldsymbol{C}(x)=(c_{1}(x),c_{2}(x),\cdots,c_{n}(x))^{\mathrm{T}} $$ 

待定.将其代入方程组(1)得

 $$ \left[\boldsymbol{\Phi}(x)\boldsymbol{C}(x)\right]^{\prime}=\boldsymbol{A}(x)\boldsymbol{\Phi}(x)\boldsymbol{C}(x)+\boldsymbol{F}(x). $$ 

注意到

 $$ \begin{aligned}\boldsymbol{\Phi}^{\prime}(x)&=(\boldsymbol{Y}_{1}^{\prime}(x)\quad\boldsymbol{Y}_{2}^{\prime}(x)\quad\cdots\quad\boldsymbol{Y}_{n}^{\prime}(x))\\&=(\boldsymbol{A}(x)\boldsymbol{Y}_{1}(x)\quad\boldsymbol{A}(x)\boldsymbol{Y}_{2}(x)\quad\cdots\quad\boldsymbol{A}(x)\boldsymbol{Y}_{n}(x))\\&=\boldsymbol{A}(x)\boldsymbol{\Phi}(x),\end{aligned} $$ 

从而得

 $$ \begin{align*}\left[\boldsymbol{\varPhi}\left(x\right)\boldsymbol{C}(x)\right]^{\prime}&=\boldsymbol{\varPhi}^{\prime}(x)\boldsymbol{C}(x)+\boldsymbol{\varPhi}\left(x\right)\boldsymbol{C}^{\prime}(x)\\&=\boldsymbol{A}(x)\boldsymbol{\varPhi}\left(x\right)\boldsymbol{C}(x)+\boldsymbol{\varPhi}\left(x\right)\boldsymbol{C}^{\prime}(x),\end{align*} $$ 

比较(9)，(10)两式便得到 $ \Phi(x)C'(x)=F(x) $，即 $ C'(x)=\Phi^{-1}(x)F(x) $。两边积分得

 $$ \boldsymbol{C}(x)=\int_{x_{0}}^{x}\boldsymbol{\Phi}^{-1}(t)\boldsymbol{F}(t)\mathrm{d}t, $$ 

其中  $ x_{0} $ 是任取的一点，对向量值函数  $ \Phi^{-1}(t)F(t) $ 积分就是对它的各个分量函数分别积分。所以

 $$ \widetilde{\mathbf{Y}}(x)=\bar{\Phi}\left(x\right)\int_{x_{0}}^{x}\bar{\Phi}^{-1}(t)\mathbf{F}(t)\mathrm{d}t. $$ 

进而知方程组(1)的通解为

 $$ \mathbf{Y}(x)=\boldsymbol{\Phi}(x)\mathbf{C}+\boldsymbol{\Phi}(x)\int_{x_{0}}^{x}\boldsymbol{\Phi}^{-1}(t)\mathbf{F}(t)\mathrm{d}t, $$ 

满足定解条件 $ \boldsymbol{Y}(x_{0})=\boldsymbol{\xi} $（ $ \xi $为n维向量）的特解为

 $$ \widetilde{\mathbf{Y}}(x)=\boldsymbol{\Phi}(x)\boldsymbol{\Phi}^{-1}(x_{0})\boldsymbol{\xi}+\boldsymbol{\Phi}(x)\int_{x_{0}}^{x}\boldsymbol{\Phi}^{-1}(t)\mathbf{F}(t)\mathrm{d}t. $$ 