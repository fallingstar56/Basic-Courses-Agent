#### ▶ 例 7.6.2

求解方程组  $ \mathbf{Y}'=\begin{pmatrix}0&1\\ 2&1\end{pmatrix}\mathbf{Y}+\begin{pmatrix}\mathbf{e}^{-x}\\ -\mathbf{e}^{-x}\end{pmatrix} $ 的满足定解条件  $ \widetilde{\mathbf{Y}}(0)=(1,2)^{\mathrm{T}} $ 的特解  $ \widetilde{\mathbf{Y}}(x) $.

解 在例 7.6.1 中已知，原方程组对应的齐次方程组  $ \mathbf{Y}' = \begin{pmatrix} 0 & 1 \\ 2 & 1 \end{pmatrix} \mathbf{Y} $. 有基本解矩阵  $ \boldsymbol{\Phi}(x) = \begin{pmatrix} \mathbf{e}^{2x} & \mathbf{e}^{-x} \\ 2\mathbf{e}^{2x} & -\mathbf{e}^{-x} \end{pmatrix} $，它的逆矩阵为  $ \boldsymbol{\Phi}^{-1}(x) = \frac{1}{3} \begin{pmatrix} \mathbf{e}^{-2x} & \mathbf{e}^{-2x} \\ 2\mathbf{e}^{x} & -\mathbf{e}^{x} \end{pmatrix} $。由公式 (13) 取得所求特解为

 $$ \begin{align*}\widetilde{\mathbf{Y}}(x)&=\boldsymbol{\varPhi}\left(x\right)\boldsymbol{\varPhi}^{-1}(0)\binom{1}{2}+\boldsymbol{\varPhi}\left(x\right)\int_{0}^{x}\boldsymbol{\varPhi}^{-1}(t)\binom{\mathbf{e}^{-t}}{-\mathbf{e}^{-t}}\mathrm{d}t\\&=\boldsymbol{\varPhi}\left(x\right)\binom{1}{0}+\boldsymbol{\varPhi}\left(x\right)\int_{0}^{x}\binom{0}{1}\mathrm{d}t=\left(\begin{matrix}{\mathbf{e}^{2x}+x\mathbf{e}^{-x}}\\ {2\mathbf{e}^{2x}-x\mathbf{e}^{-x}}\\ \end{matrix}\right).\end{align*} $$ 

最后我们指出，一阶线性常微分方程组与高阶线性常微分方程的解的存在唯一性（定理7.6.1与定理7.4.1）对于求解这类方程（组）有着基本的重要性。而关于高阶线性常微分方程的解的存在唯一性定理（定理7.4.1）则可以利用关于一阶线性常微分方程组的存在唯一性定理（定理7.6.1）证得。证明如下：

设函数  $ a_{1}(x),\cdots,a_{n}(x) $ 与  $ f(x) $ 在区间 I 上连续， $ x_{0}\in I $。要证：对于任一组实数  $ \xi_{0},\xi_{1},\cdots,\xi_{n-1},n $ 阶线性常微分方程

 $$ y^{(n)}+a_{1}(x)y^{(n-1)}+\cdots+a_{n-1}(x)y^{\prime}+a_{n}(x)y=f(x) $$ 

在区间 I 上存在唯一解  $ y = y(x) $ 满足初值条件

 $$ y^{(k)}(x_{0})=\xi_{k}\quad(k=0,1,\cdots,n-1). $$ 

令  $ y_{1}=y, y_{2}=y^{\prime}, \cdots, y_{n}=y^{(n-1)} $ 。考虑一阶线性常微分方程组

 $$ \begin{cases}y_{1}^{\prime}=y_{2},\\\vdots\\y_{n-1}^{\prime}=y_{n},\\y_{n}^{\prime}=-a_{n}(x)y_{1}-a_{n-1}(x)y_{2}-\cdots-a_{1}(x)y_{n}+f(x).\end{cases} $$ 

不难看到，若  $ y=y(x) $ 是方程(14)的满足初值条件(15)的解，则  $ (y_{1}(x), y_{2}(x), \cdots, y_{n}(x)) = (y(x), y'(x), \cdots, y^{(n-1)}(x)) $ 是方程组(16)的满足下列初值条件的解：

 $$ (y_{1}(x_{0}),y_{2}(x_{0}),\cdots,y_{n}(x_{0}))=(\xi_{0},\xi_{1},\cdots,\xi_{n-1}). $$ 

反之，若 $ (y_{1}(x),y_{2}(x),\cdots,y_{n}(x)) $是方程组(16)的满足初值条件(17)的解，则 $ y(x)=y_{1}(x) $是方程(14)的满足初值条件(15)的解.

根据定理 7.6.1，方程组（16）的满足初值条件（17）的解唯一存在，从而方