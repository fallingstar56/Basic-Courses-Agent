(3)  $ \frac{1}{x} + \frac{1}{y} + \ln\left|\frac{y}{x}\right| = C;\quad(4)y^{3} = Cx^{2}e^{-\sin x}; $ (5) $ \sin y\cos x = C; $

(6) $ (e^{x}+1)(e^{y}-1)=C;\quad(7)3\sqrt{y}=x^{\frac{3}{2}}+C; $

(8)  $ \arctan y = x - \ln |x + 1| + C; $

(9) y=0 或  $ \sqrt{y}=k\pi+\frac{\pi}{2}, k\in\mathbb{Z} $ 或  $ \tan\sqrt{y}=\frac{1}{2}x+C; $

(10)  $ y^{2}-1=2\ln\frac{1+\mathrm{e}^{x}}{1-\mathrm{e}^{x}};\quad(11) $  $ y=-\frac{1}{4}x^{2}+1. $

2. (1)  $ y = -\frac{2}{5} \cos x + \frac{1}{5} \sin x $; (2)  $ y = e^{-5x} \left( \frac{1}{6} e^{6x} + C \right) $;

(3) $ xy=-\cos x+C;\quad(4)y=x^{2}-2+2e^{-\frac{x^{2}}{2}}; $

(5)  $  y = \frac{1}{x^2} (C - \cos x)  $; (6)  $  r \sin \theta = -\ln \cos \theta  $;

(7) $ y=\mathrm{e}^{x^{2}}\left(6-\frac{1}{x+1}\right) $

3.（1） $ \frac{1-x+y}{3-x+y}=Ce^{2x} $；（2） $ y+\ln x+1=Cx $；（3） $ xy=C $

(4) $ \sin(x^{2}+y^{2})=x^{2}+C;\quad(5)xy=e^{x} $

(6) $ \frac{y}{x}+\arctan\frac{y}{x}=C $或y=Cx；(7) $ y=x\left(1-\frac{2}{\ln|x|+C}\right) $;

(8)  $ \sqrt{x^{2}+y^{2}}=y+Cx^{2}(C>0,x\neq0) $; (9)  $ \sin\frac{y}{x}=Cx^{2} $;

(10)  $  e^{-\frac{x}{x}} + \ln C x = 0  $; (11)  $  -\left[\arctan u + \frac{1}{2} \ln(u^2 + 1)\right] = \ln |x| + C  $;

(12)  $ 3xy^2 = C - x^3 $; (13)  $ 4y + 5 = (2x - 3)\ln(C(2x - 3)) $;

(14) $ y=\frac{1}{x^{2}+1+Ce^{x^{2}}} $

4.  $ y = -x^{3} $. 5.  $ y = x + Cx^{2} $,  $ C = -\frac{75}{124} $.

6. 0.1782I_{0}. 7. 80v^{\prime}=800-0.178v^{2},v(0)=60.

### 习题 7.3

1. (1)  $ y = \frac{x^{3}}{3} + \cos x - x $; (2)  $ y = x - \ln(1 + x) $; (3)  $ y = \left(\frac{1}{2}x + 1\right)^{4} $;

(4) $ y=C_{1}\left(x+\frac{x^{3}}{3}\right)+C_{2} $; (5) $ y=\frac{1}{C_{1}x+C_{2}}+1 $;

(6) $ y=\cos(x-C_{1})+C_{2}x+C_{3} $或者 $ y=\pm\frac{x^{2}}{2}+C_{1}x+C_{2} $;

(7)  $  y = \frac{1}{C_1} e^{1 + C_1 x} + C_2  $; (8)  $  y = \frac{1 + C_1^2}{C_1} \ln |1 + C_1 x| - \frac{x}{C_1} + C_2  $;