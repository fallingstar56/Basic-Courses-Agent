为叙述方便简洁，此方程组可以改写为向量与矩阵的形式：

 $$ \mathbf{Y}^{\prime}=\mathbf{A}(x)\mathbf{Y}+\mathbf{F}(x), $$ 

其中  $ \boldsymbol{Y}=(y_{1},y_{2},\cdots,y_{n})^{\mathrm{T}} $ 与  $ \boldsymbol{Y}^{\prime}=(y_{1}^{\prime},y_{2}^{\prime},\cdots,y_{n}^{\prime})^{\mathrm{T}} $ 是未知函数及其导数， $ F(x)=(f_{1}(x),f_{2}(x),\cdots,f_{n}(x))^{\mathrm{T}} $ 为方程组(1)的自由项或非齐次项。 $ A(x) $ 为方程组(1)的系数矩阵：

 $$ \boldsymbol{A}(x)=\begin{bmatrix}a_{11}(x)&a_{12}(x)&\cdots&a_{1n}(x)\\ a_{21}(x)&a_{22}(x)&\cdots&a_{2n}(x)\\ \vdots&\vdots&&\vdots\\ a_{n1}(x)&a_{n2}(x)&\cdots&a_{m}(x)\end{bmatrix}. $$ 

这样的矩阵称为函数矩阵. 常微分方程组的通解、特解等概念类似于常微分方程的情形.

#### 7.6.1 一阶线性常微分方程组解的结构

对于一阶线性常微分方程组(1)，我们有下列解的存在唯一性定理：

定理 7.6.1

设函数  $ f_{i}(x) $ 与  $ a_{ij}(x)(i,j=1,2,\cdots,n) $ 在区间 I 上连续， $ x_{0}\in I $，则对于任意的 n 维向量  $ \boldsymbol{\xi}=(\boldsymbol{\xi}_{1},\boldsymbol{\xi}_{2},\cdots,\boldsymbol{\xi}_{n})^{\mathrm{T}} $，方程组（1）在区间 I 上存在唯一解  $ \mathbf{Y}=\mathbf{Y}(x)=(y_{1}(x),y_{2}(x),\cdots,y_{n}(x))^{\mathrm{T}} $ 满足定解条件  $ \mathbf{Y}(x_{0})=\boldsymbol{\xi} $.

这个定理的证明类似于高阶线性常微分方程的情形，需要关于函数列一致收敛的相关知识，我们将在本教材的下册中(定理6.2.4)给出。

如果方程组(1)中的非齐次项  $ F(x) \equiv 0 $，则方程组(1)化为与其对应的一阶齐次线性常微分方程组：

 $$ \mathbf{Y}^{\prime}=\mathbf{A}(x)\mathbf{Y}, $$ 

定理 7.6.2

设  $ Y_{1}, Y_{2} $ 是齐次方程组(2)的任意两个解， $ c_{1}, c_{2} $ 是任意常数，则  $ c_{1}Y_{1} + c_{2}Y_{2} $ 也是方程组(2)的解，即方程组(2)的解集合构成一个线性空间。

它的证明完全类似于高阶线性常微分方程的情形.

定义 7.6.1

设  $ Y_{1}, Y_{2}, \cdots, Y_{m} $ 为区间 I 上定义的 n 维向量值函数。若存在一组不全为零的实数  $ c_{1}, c_{2}, \cdots, c_{m} $，使得在区间 I 上

 $$ c_{1}\mathbf{Y}_{1}(x)+c_{2}\mathbf{Y}_{2}(x)+\cdots+c_{m}\mathbf{Y}_{m}(x)\equiv\mathbf{0}, $$ 

则称向量值函数 $ Y_{1},Y_{2},\cdots,Y_{m} $ 在区间 I 上线性相关。否则称它们在 I 上线性无关。