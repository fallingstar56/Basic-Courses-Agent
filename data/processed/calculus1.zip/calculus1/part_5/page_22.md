2. (1)  $ \frac{1}{2}\sin^{2}x + \frac{3}{2}\sin x - \frac{3}{4}\ln\frac{1+\sin x}{1-\sin x} + C; $

(2)  $ \sec x + \frac{1}{3}\sec^{3}x + \ln\tan\frac{x}{2} + C; $

(3)  $ x - \frac{\sqrt{2}}{2}\arctan(\sqrt{2}\tan x) + C; $

(4)  $ \frac{1}{2}(\tan x + \ln|\tan x|) + C; $

(5)  $ \ln|\sin x + \cos x| + C; $

(6)  $ \frac{1}{6}\ln\frac{(1-\cos x)(2+\cos x)^{2}}{(1+\cos x)^{3}} + C; $

(7)  $ -\frac{1}{2}|\ln\sin x + \cos x| + \frac{1}{2}x + C; $

(8)  $ \frac{2}{3}\arctan\left(\frac{5\tan\frac{x}{2}+4}{3}\right) + C; $

(9)  $ \frac{1}{2}|\ln|\sin x + \cos x| + \frac{1}{2}x + C; $

(10)  $ \frac{1}{2}|\ln(1+\cos^{2}x)-\cos^{2}x + C. $

3. (1)  $ 6\ln(1+\sqrt[3]{x})+C; $

(2)  $ \frac{x^2}{2}-\frac{1}{2}(x\sqrt{x^2-1}-\ln(x+\sqrt{x^2-1}))+C; $

(3)  $ \frac{2}{5}(x+2)^{\frac{3}{2}}-\frac{4}{3}(x+2)^{\frac{3}{2}}+C; $

(4)  $ \frac{1}{8}\arcsin x+\frac{1}{8}x(2x^2-1)\sqrt{1-x^2}+C; $

(5)  $ \frac{1}{4}(x^2+1)\sqrt{x^4+2x^2-1}-\frac{1}{2}\ln(x^2+1+\sqrt{x^4+2x^2-1})+C; $

(6)  $ \arcsin x-\ln(1+\sqrt{1-x^2})+\ln|x|+C; $

(7)  $ \sqrt{(a-x)(x-b)}-(a-b)\arctan\sqrt{\frac{a-x}{x-b}}+C; $

(8)  $ \frac{11}{8}\arcsin\frac{2x-1}{\sqrt{5}}+\frac{2x-1}{4}\sqrt{1+x-x^2}+C; $

(9)  $ \frac{x}{a^2\sqrt{a^2-x^2}}+C. $

4. (1)  $ \sqrt{2}\ln\left|\tan\frac{x}{4}\right|+C; $

(2)  $ 2\arcsin\sqrt{\sin x}+C; $

(3)  $ -x\cot\frac{x}{2}+2\ln|\sin\frac{x}{2}|+C; $

(4)  $ \left(\arctan\sqrt{x}\right)^2+C; $

(5)  $ -\frac{x}{\ln x}+C; $

(6)  $ e^x\tan\frac{x}{2}+C; $

(7)  $ \frac{1}{2\sqrt{2}}\ln\frac{x^2-\sqrt{2}x+1}{x^2+\sqrt{2}x+1}+C; $

(8)  $ \frac{1}{4}\ln\frac{x^2}{x^2+1}-\frac{\ln x}{2(x^2+1)}+C; $

 $$ -\frac{\arctan x}{x}-\frac{(\arctan x)^{2}}{2}+\ln x-\frac{\ln(x^{2}+1)}{2}+C. $$ 