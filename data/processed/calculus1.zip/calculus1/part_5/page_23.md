### 习题 5.6

1. (1) 4; (2)  $ 2\sqrt{2} $; (3) 1; (4)  $ \frac{1}{2}\ln\frac{3}{2} $; (5)  $ -\frac{1}{4}\ln3 $; (6)  $ \frac{1}{4} $;

(7)  $ 64\ln2 - 32\ln3 - 9 $; (8)  $ \frac{1 - \ln 2}{2} $; (9)  $ \frac{16 - 11\sqrt{2}}{3} $; (10)  $ 1 - \frac{\pi}{4} $;

(11)  $ \frac{1}{2\sqrt{2}}\ln\frac{2+\sqrt{2}}{2-\sqrt{2}} $; (12)  $ \frac{\sqrt{3}-\sqrt{2}}{2} $; (13)  $ \frac{1}{\sqrt{2}}\arctan\frac{1}{\sqrt{2}} $;

(14)  $ 2\left(\sqrt{3}-\sqrt{2}\right)+\ln\frac{\sqrt{3}-1}{\sqrt{3}+1}-2\ln\left(\sqrt{2}-1\right) $; (15)  $ \sqrt{3}-\frac{1}{2}\ln\left(2+\sqrt{3}\right) $.

2. (1)  $ 2 - 2\pi $; (2)  $ \frac{1}{4}\left(1 - \frac{5}{e^2}\right) $; (3)  $ \frac{\pi^2}{16} - \frac{1}{4} $; (4)  $ \frac{2\pi}{3} - \frac{\sqrt{3}}{2} $;

(5)  $ \frac{2}{5} - \frac{1}{5} e^{-\frac{\pi}{4}} $; (6)  $ \frac{1}{2} \left(1 - \frac{1}{e}\right) $; (7)  $ \tan 1 + \ln \cos 1 - \frac{1}{2} $;

(8)  $ \frac{3e^{\pi} - 1}{8} $.

3. (1)  $ \frac{3\pi}{16} $; (2)  $ \frac{16}{15} $; (3)  $ \frac{5\pi}{16} $; (4) 0; (5)  $ \frac{\pi}{16} $; (6)  $ \frac{3\pi}{16} $;

(7) $ \left(\frac{a^{2}}{2}+\frac{a^{4}}{8}\right)\pi;\quad(8)\frac{a^{2}}{2}\pi;\quad(9)\frac{a^{3}}{2}\pi. $

8.  $ \frac{1-e}{4e} $

11. $ \frac{\pi}{4}. $

### 习题 5.7

2. (1)  $ 4\sqrt{3} $; (2)  $ 4\sqrt{2} $; (3) 10.42; (4)  $ \frac{3}{8}\pi a^{2} $; (5)  $ \frac{1}{2}\pi a^{2} $;

(6) $ \frac{5}{4}\pi-2;\quad(7)-2. $

3. (1) 4; (2)  $ \ln\left(1+\sqrt{2}\right) $; (3) 6a; (4) 8a;

(5)  $ \pi a \sqrt{1 + 4\pi^{2}} + \frac{a}{2} \ln\left(2\pi + \sqrt{1 + 4\pi^{2}}\right) $; (6)  $ a \sinh \frac{l}{a} $.

4. (1)  $ 6|x|(1+9x^{4})^{-\frac{3}{2}} $; (2)  $ \frac{1}{2\sqrt{2}a\sqrt{1-\cos t}} $;

(3)  $ \mathrm{e}^{x}(1+\mathrm{e}^{2x})^{-\frac{3}{2}} $; (4)  $ \frac{t^{2}+2\sin^{2}t}{a^{2}\left[t^{2}+4\sin^{2}t+4t\sin t\cos t\right]^{\frac{3}{2}}} $.

5. (1)  $ \frac{3(1+\cos\theta)}{a(2+\cos\theta)^{\frac{3}{2}}} $; (2)  $ \frac{3}{a}\sqrt{\frac{\cos2\theta}{2}} $.