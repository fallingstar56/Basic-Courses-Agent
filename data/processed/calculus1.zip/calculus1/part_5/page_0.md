### 习题 7.5

1. 证明命题 7.5.1.

2. 求解下列微分方程.

(1) $ y''-y=0,\quad y(0)=0,y'(0)=1; $

(2) $ y''-6y'+9y=0,\quad y(0)=1,y'(0)=1; $

(3)  $ y''' - 3y'' - 4y' = 0 $,  $ y(0) = y'(0) = y''(0) = 1 $.

3. 求解下列微分方程.

 $$ y^{\prime \prime}-4y^{\prime}-12y=x^{2} $$ 

 $$ y^{\prime \prime}-4y^{\prime}-12y=e^{-4x} $$ 

 $$ y^{\prime \prime}-4y^{\prime}+4y=x\mathrm{e}^{2x} $$ 

 $$ y^{\prime \prime}+2y^{\prime}+y=\sin x $$ 

 $$ y^{\prime \prime}+2y^{\prime}+y=e^{x}\cos x; $$ 

 $$ y^{\prime \prime}+3y^{\prime}+2y=\sin x+x^{2} $$ 

(7) $ y''+4y'+5y=e^{-2x}\sin x; $ (8) $ y''-4y'+4y=1+\sin x+xe^{2x}; $

(9) $ y''+4y=\cos2x,\quad y(0)=0,y'(0)=2; $

(10) $ y''-2y'+y=xe^{x}+4,\quad y(0)=1,y'(0)=1; $

(11) $ y^{(4)}+2y^{\prime\prime}+y=3x+4,\quad y(0)=y^{\prime}(0)=0,y^{\prime\prime}(0)=y^{\prime\prime\prime}(0)=1. $

4. 求解下列微分方程.

(1)  $ x^2 y'' + 2xy' - n(n+1)y = 0 $; (2)  $ x^3 y''' + 3x^2 y'' + xy' - 8y = 7x + 4 $;

(3)  $ xy'' + 2y' = 12 \ln x $; (4)  $ (2x - 1)^2 y'' + 4(2x - 1) y' + 8y = 8x $.

5. 设曲线  $ y = y(x) $ 满足  $ 4x^{2}y'' + 4xy' - y = 0 $，过点  $ (1, 4) $，且在点  $ (1, 4) $ 处与 x 轴夹角为  $ \frac{\pi}{4} $，求  $ y = y(x) $.

6. 设  $ y=e^{2x}+(1+x)e^{x} $ 为微分方程  $ y''+ay'+by=ce^{x} $ 的一个解，求常系数 a,b,c 及微分方程的通解.

7. 已知连续函数  $ y = f(x) $ 满足

 $$ f(x)=\sin x+\int_{0}^{x}(t-x)f(t)\mathrm{d}t, $$ 

求  $ y = f(x) $.

### 7.6 一阶线性常微分方程组

关于 n 个未知函数的一阶线性常微分方程组的规范形式为

 $$ \begin{cases}y_{1}^{\prime}=a_{11}(x)y_{1}+a_{12}(x)y_{2}+\cdots+a_{1n}(x)y_{n}+f_{1}(x),\\y_{2}^{\prime}=a_{21}(x)y_{1}+a_{22}(x)y_{2}+\cdots+a_{2n}(x)y_{n}+f_{2}(x),\\\quad\vdots\\y_{n}^{\prime}=a_{n1}(x)y_{1}+a_{n2}(x)y_{2}+\cdots+a_{m}(x)y_{n}+f_{n}(x),\end{cases} $$ 

其中函数  $ f_{i}(x) $ 与  $ a_{ij}(x)(i,j=1,2,\cdots,n) $ 在区间 I 上连续.