4. (1)  $ \ln(x^{2}+x+1)+C; $

(2) $ -\sqrt{4-x^{2}}+C; $

(3)  $ \ln|\arctan x| + C; $

(4) $ -\cosh\frac{1}{x}+C; $

(5)  $ \ln \cosh x + C $;

(6)  $ -\frac{1}{2}\tan(1-x^{2})+C; $

(7) $ \frac{1}{3}\arctan(x^{3})+C; $

(8) $ -\cos\sqrt{x^{2}+1}+C; $

(9)  $ 2\sqrt{1+\tan x} + C; $

(10) $ \arctan e^{x}+C; $

(11)  $ \arctan e^x + C $;

(12)  $ \ln|\ln(\ln x)|+C; $

(13)  $ -\frac{2}{3}(1-\ln x)^{\frac{3}{2}}+C; $

(14)  $ \frac{1}{2\ln2}\arcsin2^{x}+C; $



(15) $ \frac{2}{3}(\arcsin x)^{\frac{3}{2}}+C. $

5. (1)  $ \frac{1}{2\sqrt{3}}\ln\left|\frac{x+\sqrt{3}}{x-\sqrt{3}}\right|+C; $ (2)  $ -\frac{1}{2}\ln\left|3-x^{2}\right|+C; $

(3) $ \frac{3}{5}\ln|x+3|+\frac{2}{5}\ln|x-2|+C; $

(4)  $ \frac{1}{2}\ln(x^{2}-4x+8)+\frac{1}{2}\arctan\frac{x-2}{2}+C; $

(5)  $ -2\sqrt{4x-x^{2}}+5\arcsin\frac{x-2}{2}+C; $

(6)  $ -\sqrt{-x^{2}+2x+3}+2\arcsin\frac{x-1}{2}+C; $

(7) $ \frac{x}{2}+\frac{1}{8}\sin2(2x-1)+C; $

(8)  $ -\frac{1}{3}\sin^{3}x + \sin x + C $;

(9) $ -\frac{1}{2}\left(\frac{1}{\alpha-\beta}\cos(\alpha-\beta)x+\frac{1}{\alpha+\beta}\cos(\alpha+\beta)x\right)+C; $

(10) $ \frac{1}{3}\tan^{3}x-\tan x+x+C; $

(11) $ \begin{cases}2\sqrt{2}\sin\frac{x}{2}+C_{1},&x\in(-\pi+4k\pi,\pi+4k\pi],\\-2\sqrt{2}\sin\frac{x}{2}+C_{2},&x\in(\pi+4k\pi,3\pi+4k\pi];\end{cases} $

(12)  $ \arctan(\sin^2 x) + C. $

6. (1)  $ \frac{x}{2}\sqrt{a^{2}+x^{2}}-\frac{a^{2}}{2}\ln\left(x+\sqrt{a^{2}+x^{2}}\right)+C; $