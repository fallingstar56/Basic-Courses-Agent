所以 A 的特征根为  $ \lambda = 1 \pm 2i $. A 的属于特征根  $ 1 + 2i $ 与  $ 1 - 2i $ 的特征向量分别为  $ \boldsymbol{U}_{1} = (1, \mathrm{i})^{\mathrm{T}} $ 与  $ \boldsymbol{U}_{2} = (1, -\mathrm{i})^{\mathrm{T}} $. 从而原方程组有复值解  $ \boldsymbol{Y} = \mathrm{e}^{(1 + 2\mathrm{i})x}(1, \mathrm{i})^{\mathrm{T}} $ 与  $ \overline{Y} = \mathrm{e}^{(1 - 2\mathrm{i})x}(1, -\mathrm{i})^{\mathrm{T}} $. 进而原方程组的两个无关实值解  $ \boldsymbol{Y}_{1} = \mathrm{e}^{x}(\cos 2x, -\sin 2x)^{\mathrm{T}} $ 与  $ \boldsymbol{Y}_{2} = \mathrm{e}^{x}(\sin 2x, \cos 2x)^{\mathrm{T}} $. 所以原方程组的通解为

 $$ \mathbf{Y}(x)=c_{1}\mathrm{e}^{x}\binom{\cos2x}{-\sin2x}+c_{2}\mathrm{e}^{x}\binom{\sin2x}{\cos2x}. $$ 

下面再介绍一种利用消元法求解线性常微分方程组的常用方法。这种方法类似于求解线性代数方程组的消元法。这里通过两个具体例子来说明这种方法。

#### ▶ 例 7.6.8

求解方程组 $ \left\{\begin{aligned}y^{\prime}&=y+2z,\\ z^{\prime}&=3y+2z.\end{aligned}\right. $

解 将第二个方程两边关于 x 求导得  $ z'' = 3y' + 2z' $，再将  $ y' = y + 2z $ 与  $ 3y = z' - 2z $ 分别代入得

 $$ z^{\prime \prime}=3(y+2z)+2z^{\prime}=z^{\prime}-2z+6z+2z^{\prime}=3z^{\prime}+4z, $$ 

即

 $$ z^{\prime \prime}-3z^{\prime}-4z=0. $$ 

这是一个二阶常系数齐次线性方程，解之得

 $$ z=c_{1}\mathrm{e}^{4x}+c_{2}\mathrm{e}^{-x}, $$ 

再由第二个方程得

 $$ y=\frac{1}{3}(z^{^{\prime}}-2z)=\frac{2}{3}c_{1}\mathrm{e}^{4x}-c_{2}\mathrm{e}^{-x}. $$ 

所以原方程组的通解为

 $$ \begin{cases}y=\frac{2}{3}c_{1}\mathrm{e}^{4x}-c_{2}\mathrm{e}^{-x},\\z=c_{1}\mathrm{e}^{4x}+c_{2}\mathrm{e}^{-x}.\end{cases} $$ 

▶ 例 7.6.9

求方程组 $ \left\{\begin{aligned}x^{\prime}&=y-z,\\ y^{\prime}&=z+1,\\ z^{\prime}&=y+2t\end{aligned}\right. $，满足定解条件 $ \left\{\begin{aligned}x(0)&=1,\\ y(0)&=0,\\ z(0)&=-1\end{aligned}\right. $，的特解.

解 由后两个方程得  $ z'' = y' + 2 = z + 3 $，即  $ z'' - z = 3 $，解之得  $ z = c_{1} e^{t} + c_{2} e^{-t} - 3 $，于是又有  $ y = z' - 2t = c_{1} e^{t} - c_{2} e^{-t} - 2t $。代入定解条件  $ y(0) = 0 $， $ z(0) = -1 $，可得  $ c_{1} = c_{2} = 1 $。进而得  $ x' = y - z = -2e^{-t} - 2t + 3 $，从而  $ x = 2e^{-t} - t^{2} + 3t + c_{3} $。代入  $ x(0) = 1 $ 得  $ c_{3} = -1 $。于是所求特解为

 $$ \begin{cases}x=2\mathrm{e}^{-t}-t^{2}+3t-1,\\y=\mathrm{e}^{t}-\mathrm{e}^{-t}-2t,\\z=\mathrm{e}^{t}+\mathrm{e}^{-t}-3.\end{cases} $$ 