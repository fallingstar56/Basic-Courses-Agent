(2) $ \sqrt{x^{2}-4}-2\arccos\frac{2}{x}+C; $

 $$ \frac{1}{a}\ln\left|\frac{a-\sqrt{a^{2}-x^{2}}}{x}\right|+C;\qquad(4)\frac{\sqrt{x^{2}-1}}{x}+C; $$ 

 $$ \frac{1}{2}\sqrt{4x^{2}+4x+5}-\ln\left(\sqrt{4x^{2}+4x+5}+2x+1\right)+C; $$ 

(6)  $ 3\arcsin\frac{x-1}{2}-\frac{(x+3)\sqrt{3+2x-x^{2}}}{2}+C. $

 $$ \frac{1}{2}\dot{x}\sin2x+\frac{1}{4}\cos2x+C; $$ 

 $$ -\frac{1}{9}(3x+1)e^{-3x}+C; $$ 

 $$ \left(\frac{1}{4}-\frac{x^{2}}{2}\right)\cos2x+\frac{1}{2}x\sin2x+C; $$ 

 $$ -\frac{x}{2}+\frac{x^{2}+1}{2}\arctan x+C; $$ 

(5) $ \frac{1}{2}(x^{2}-1)\ln(x-1)-\frac{x^{2}}{4}-\frac{x}{2}+C; $

(6) $ x\ln\left(x+\sqrt{1+x^{2}}\right)-\sqrt{1+x^{2}}+C; $

(7)  $  x(\arccos x)^2 - 2\sqrt{1 - x^2} \arccos x - 2x + C  $;

(8)  $  x \tan x + \ln | \cos x | - \frac{x^2}{2} + C  $;

 $$ -x\cot x+\ln|\sin x|+C; $$ 

 $$ \frac{1}{8}\mathrm{e}^{x}(2-\sin2x-\cos2x)+C; $$ 

(11)  $ \frac{\arcsin e^x}{e^x} - \sqrt{e^{-2x} + 1} + C; $ (12)  $ \frac{x}{2}(\sin(\ln x) - \cos(\ln x)) + C. $

### 习题 5.5

(1)  $ \ln\left|\frac{x+1}{x+2}\right|+\frac{1}{x+2}+C; $ (2)  $ \ln|x|-\frac{1}{2}\ln(1+x^{2})+C; $

(3)  $ x+\frac{1}{6}\ln|x|-\frac{9}{2}\ln|x-2|+\frac{28}{3}\ln|x-3|+C; $

(4)  $ \frac{1}{4}\ln\left|\frac{x-1}{x+1}\right|-\frac{1}{2}\arctan x+C; $

(5)  $ x+\frac{\arctan x}{3}-\frac{8}{3}\arctan\frac{x}{2}+C; $

(6)  $ \frac{1}{3}\ln\frac{|x+1|}{\sqrt{x^{2}-x+1}}+\frac{1}{\sqrt{3}}\arctan\frac{2x-1}{\sqrt{3}}+C; $

(7)  $ -\frac{1}{2(1-x^{2})}+\frac{3}{4(1-x^{2})^{2}}-\frac{1}{2(1-x^{2})^{3}}+\frac{1}{8(1-x^{2})^{4}}+C; $

(8)  $ \sqrt{2}\ln\left|\frac{\sqrt{2}x-1}{\sqrt{2}}\right|+\frac{6x^{2}+1}{2-3}+C. $