定义 7.6.2

设 $ Y_{1},Y_{2},\cdots,Y_{n} $为区间I上定义的n个n维向量值函数：

 $$ \mathbf{Y}_{k}(x)=(y_{1k}(x),y_{2k}(x),\cdots,y_{nk}(x))^{\mathrm{T}},\quad k=1,2,\cdots,n. $$ 

定义 $ Y_{1},Y_{2},\cdots,Y_{n} $的朗斯基行列式为

 $$ \boldsymbol{W}(x)=\boldsymbol{W}[\boldsymbol{Y}_{1},\boldsymbol{Y}_{2},\cdots,\boldsymbol{Y}_{n}](x)=\begin{vmatrix}y_{11}(x)&y_{12}(x)&\cdots&y_{1n}(x)\\ y_{21}(x)&y_{22}(x)&\cdots&y_{2n}(x)\\ \vdots&\vdots&&\vdots\\ y_{n1}(x)&y_{n2}(x)&\cdots&y_{m}(x)\end{vmatrix}. $$ 

定理 7.6.3

(1) 如果 n 维向量值函数  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 在区间 I 上线性相关，则

 $$ W[Y_{1},Y_{2},\cdots,Y_{n}](x)\equiv0,\quad x\in I. $$ 

(2) 若  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 为方程组(2)的 n 个解，且在区间 I 上线性无关，则

 $$ W[Y_{1},Y_{2},\cdots,Y_{n}](x)\neq0,\quad\forall x\in I. $$ 

也就是说，如果  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 为方程组(2)的 n 个解，则  $ W[Y_{1}, Y_{2}, \cdots, Y_{n}] $ 在区间 I 上或恒为零，或每一点都不为零.

证明 （1）设  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 在区间 I 上线性相关，则存在一组不全为零的实数  $ c_{1}, c_{2}, \cdots, c_{n} $，使得  $ \forall x \in I $，有

 $$ c_{1}\mathbf{Y}_{1}(x)+c_{2}\mathbf{Y}_{2}(x)+\cdots+c_{n}\mathbf{Y}_{n}(x)\equiv\mathbf{0}. $$ 

将(3)式看作关于未知数  $ c_{1}, c_{2}, \cdots, c_{n} $ 的 n 阶线性代数方程组，则此方程组有非零解  $ c_{1}, c_{2}, \cdots, c_{n} $，从而它的系数行列式  $ W[Y_{1}, Y_{2}, \cdots, Y_{n}](x) = 0, \forall x \in I. $

(2) 设  $ Y_1, Y_2, \cdots, Y_n $ 为方程组 (2) 的解，且在  $ I $ 上线性无关。假设  $ \exists x_0 \in I $，使得

 $$ W[\mathbf{Y}_{1},\mathbf{Y}_{2},\cdots,\mathbf{Y}_{n}](x_{0})=0, $$ 

考虑关于未知数  $ c_{1}, c_{2}, \cdots, c_{n} $ 的 n 阶线性代数方程组

 $$ c_{1}\mathbf{Y}_{1}(x_{0})+c_{2}\mathbf{Y}_{2}(x_{0})+\cdots+c_{n}\mathbf{Y}_{n}(x_{0})=\mathbf{0}, $$ 

它的系数行列式  $ W[Y_{1},Y_{2},\cdots,Y_{n}](x_{0})=0 $，因此它有非零解，仍记为  $ c_{1},c_{2},\cdots,c_{n} $。令

 $$ \mathbf{Y}(x)=c_{1}\mathbf{Y}_{1}(x)+c_{2}\mathbf{Y}_{2}(x)+\cdots+c_{n}\mathbf{Y}_{n}(x),\quad x\in I. $$ 

则根据定理 7.6.2,  $ Y(x) $ 为方程组 (2) 的解，且由 (4) 式， $ Y(x_{0})=0 $.

另一方面， $ \widetilde{Y}(x)\equiv0 $ 也是方程组(2)的解，并且与 $ Y(x) $满足相同的一组定解条件，根据方程组(2)的解的存在唯一性定理（定理7.6.1）， $ Y(x) $应与 $ \widetilde{Y}(x)\equiv0 $ 为方程组(2)的同一个解，即

 $$ \mathbf{Y}(x)=c_{1}\mathbf{Y}_{1}(x)+c_{2}\mathbf{Y}_{2}(x)+\cdots+c_{n}\mathbf{Y}_{n}(x)\equiv\mathbf{0},\quad x\in I. $$ 