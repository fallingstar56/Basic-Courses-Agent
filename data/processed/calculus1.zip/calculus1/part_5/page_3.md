这与 $ Y_{1},Y_{2},\cdots,Y_{n} $在I上线性无关相矛盾.所以 $ \forall x\in I,W[Y_{1},Y_{2},\cdots,Y_{n}](x)\neq0. $

设函数  $ a_{ij}(x)(i,j=1,2,\cdots,n) $ 在区间 I 上连续，则方程组（2）的解空间为一个 n 维线性空间.

证明 为证明定理, 只需要找到方程组(2)的 n 个线性无关解, 并证明方程组(2)的每个解都可以用它们线性表出.

记  $ e_{k}(k=1,2,\cdots,n) $ 是第 k 个分量为 1、其他分量为 0 的 n 维列向量， $ x_{0} \in I $。根据定理 7.6.1，方程组（2）存在唯一的解  $ \mathbf{Y}_{k}(x) $ 满足定解条件

 $$ \mathbf{Y}_{k}(x_{0})=\mathbf{e}_{k}(k=1,2,\cdots,n). $$ 

由此知

 $$ W[Y_{1},Y_{2},\cdots,Y_{n}](x_{0})=\det(e_{1}\quad e_{2}\quad\cdots\quad e_{n})=1\neq0. $$ 

再应用定理 7.6.3(2) 便得到  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 在 I 上线性无关.

其次，任取方程组(2)的解  $ Y(x) $，向量  $ Y(x_{0}) $ 可以由  $ e_{1}, e_{2}, \cdots, e_{n} $ 线性表出：

 $$ \mathbf{Y}(x_{0})=c_{1}\mathbf{e}_{1}+c_{2}\mathbf{e}_{2}+\cdots+c_{n}\mathbf{e}_{n}. $$ 

使用这组表出系数  $ c_{1}, c_{2}, \cdots, c_{n} $，构造方程组(2)的解：

 $$ \widetilde{Y}(x)=c_{1}Y_{1}(x)+c_{2}Y_{2}(x)+\cdots+c_{n}Y_{n}(x). $$ 

则根据(5)式，并且

 $$ \begin{aligned}\widetilde{\mathbf{Y}}(x_{0})&=c_{1}\mathbf{Y}_{1}(x_{0})+c_{2}\mathbf{Y}_{2}(x_{0})+\cdots+c_{n}\mathbf{Y}_{n}(x_{0})\\&=c_{1}\mathbf{e}_{1}+c_{2}\mathbf{e}_{2}+\cdots+c_{n}\mathbf{e}_{n}=\mathbf{Y}(x_{0}),\end{aligned} $$ 

再次应用解的存在唯一性定理(定理 7.6.1)可得

 $$ \mathbf{Y}(x)\equiv\widetilde{\mathbf{Y}}(x)=c_{1}\mathbf{Y}_{1}(x)+c_{2}\mathbf{Y}_{2}(x)+\cdots+c_{n}\mathbf{Y}_{n}(x)\quad(x\in I). $$ 

即  $ Y(x) $ 可以用  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 线性表出.

定义 7.6.3 ……

齐次方程组(2)的任意n个线性无关解 $ Y_{1},Y_{2},\cdots,Y_{n} $称为方程组(2)的一个基本解组.记

 $$ \mathbf{Y}_{k}(x)=(y_{1k}(x),y_{2k}(x),\cdots,y_{nk}(x))^{\mathrm{T}},\quad k=1,2,\cdots,n. $$ 

以这 n 个线性无关解为列向量的矩阵

 $$ \boldsymbol{\Phi}\left(x\right)=\left(\mathbf{Y}_{1}\quad\mathbf{Y}_{2}\quad\cdots\quad\mathbf{Y}_{n}\right)=\begin{pmatrix}y_{11}\left(x\right)&y_{12}\left(x\right)&\cdots&y_{1n}\left(x\right)\\ y_{21}\left(x\right)&y_{22}\left(x\right)&\cdots&y_{2n}\left(x\right)\\ \vdots&\vdots&&\vdots\\ y_{n1}\left(x\right)&y_{n2}\left(x\right)&\cdots&y_{m}\left(x\right)\end{pmatrix} $$ 

称为方程组(2)的一个基本解矩阵. 此时, 方程组(2)的通解就可以表示为