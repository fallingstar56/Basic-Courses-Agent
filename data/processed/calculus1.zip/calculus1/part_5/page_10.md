▶ 例 7.6.6

求方程组  $ Y' = AY $ 的满足定解条件  $ \widetilde{Y}(0) = (0, 3, -1)^{\mathrm{T}} $ 的特解，其中

 $$ \begin{aligned}\boldsymbol{A}&=\begin{pmatrix}{{{2}}}&{{{1}}}&{{{3}}} \\{{{0}}}&{{{2}}}&{{{-1}}} \\{{{0}}}&{{{0}}}&{{{2}}}\end{pmatrix}.\end{aligned} $$ 

解  $ \det(\lambda\boldsymbol{I}-\boldsymbol{A})=(\lambda-2)^{3} $，故  $ \lambda=2 $ 为 A 的三重特征根。根据命题 7.6.1，代数方程组有  $ (2\boldsymbol{I}-\boldsymbol{A})^{3}\boldsymbol{U}=\boldsymbol{0} $ 的解空间为  $ \mathbb{R}^{3} $（即  $ (2\boldsymbol{I}-\boldsymbol{A})^{3}=\boldsymbol{0} $）。所以可取  $ U_{1}=(1,0,0)^{\mathrm{T}},U_{2}=(0,1,0)^{\mathrm{T}},U_{3}=(0,0,1)^{\mathrm{T}} $。于是原方程组有基本解矩阵

 $$ \begin{aligned}\Phi\left(x\right)&=\mathrm{e}^{2x}\Biggl[\boldsymbol{I}+x(\boldsymbol{A}-2\boldsymbol{I})+\frac{x^{2}}{2!}(\boldsymbol{A}-2\boldsymbol{I})^{2}\Biggr](\boldsymbol{U}_{1},\boldsymbol{U}_{2},\boldsymbol{U}_{3})\\&=\mathrm{e}^{2x}\begin{vmatrix}1&x&3x-\frac{1}{2}x^{2}\\0&1&-x\\0&0&1\end{vmatrix}.\end{aligned} $$ 

所以它的通解为  $ \boldsymbol{Y}(x)=\boldsymbol{\varPhi}(x)(c_{1},c_{2},c_{3})^{\mathrm{T}} $ 。代入定解条件：

 $$ \boldsymbol{\Phi}(0)(c_{1},c_{2},c_{3})^{\mathrm{T}}=\widetilde{\mathbf{Y}}(0)=(0,3,-1)^{\mathrm{T}}, $$ 

可得 $ (c_{1},c_{2},c_{3})^{\mathrm{T}}=(0,3,-1)^{\mathrm{T}} $.于是所求特解为

 $$ \widetilde{\mathbf{Y}}(x)=\mathbf{e}^{2x}\begin{bmatrix}1&x&3x-\frac{1}{2}x^{2}\\ 0&1&-x\\ 0&0&1\end{bmatrix}\begin{bmatrix}0\\ 3\\ -1\end{bmatrix}=\mathbf{e}^{2x}\begin{bmatrix}\frac{1}{2}x^{2}\\ x+3\\ -1\end{bmatrix}. $$ 

还需要注意，如果  $ \lambda = \alpha + i\beta $ 是方程组（18）的系数矩阵 A 的复特征根，由于  $ \det(\lambda I - A) $ 是实系数多项式，因而  $ \bar{\lambda} = \alpha - i\beta $ 也是 A 的复特征根。若  $ U = U_1 + iU_2 $ 是 A 的属于  $ \lambda $ 的特征向量，容易验证  $ \bar{U} = U_1 - iU_2 $ 就是 A 的属于  $ \bar{\lambda} $ 的特征向量，于是  $ Y = e^{i\lambda}U $ 与  $ \bar{Y} = e^{\bar{\lambda}x}\bar{U} $ 是方程组（18）的一对互为共轭的复值解。将这两个复值解的实部与虚部分别取出，便可得到方程组（18）的两个线性无关的实值解：

 $$ \begin{aligned}\boldsymbol{Y}_{1}&=\mathrm{e}^{ax}\left(\boldsymbol{U}_{1}\cos\beta x-\boldsymbol{U}_{2}\sin\beta x\right),\\\boldsymbol{Y}_{2}&=\mathrm{e}^{ax}\left(\boldsymbol{U}_{2}\cos\beta x+\boldsymbol{U}_{1}\sin\beta x\right).\end{aligned} $$ 

当系数矩阵 A 有复值重特征根时可类似地得到，方程组(18)的复值解是互为共轭成对出现的，因而同样可以得到方程组(18)的 n 个线性无关的实值解。

▶ 例 7.6.7

求解方程组  $ Y' = A Y $，其中  $ A = \begin{pmatrix} 1 & 2 \\ -2 & 1 \end{pmatrix} $.

解  $ \det(\lambda\boldsymbol{I}-\boldsymbol{A})=(\lambda-1)^{2}+4=(\lambda-1-2\mathrm{i})(\lambda-1+2\mathrm{i}) $