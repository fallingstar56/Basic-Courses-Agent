(9)

 $$ y=\left(1+\frac{1}{4}x\right)\sin2x; $$ 

(10) $ y=\left(\frac{1}{6}x^{3}+4x-3\right)e^{2x}+4; $

(11)  $  y = \left( -4 - \frac{1}{3}x \right) \cos x + \left( -\frac{8}{3} - 2x \right) \sin x + 3x + 4.  $

4. (1)  $ y = C_{1}x^{n} + C_{2}x^{-1-n} $;

(2)  $ y = C_{1} + C_{2}x^{-1} + 3x(2\ln x - 3) $;

(3)  $  y = 6 \left( x \ln x - \frac{3}{2} x \right) + C_{1} \frac{1}{x} + C_{2}  $;

(4)

 $$ y=\frac{1}{2}+\frac{1}{4}(2x-1)+C_{1}(2x-1)^{2}+C_{2}(2x-1)^{-1}. $$ 

5.  $ y=3\sqrt{x}+\frac{1}{\sqrt{x}}. $

6. a = -3, b = 2, c = -1;

 $$ y=C_{1}\mathrm{e}^{x}+C_{2}\mathrm{e}^{2x}+x\mathrm{e}^{x}. $$ 

 $$ y=C_{1}\sin x+\frac{1}{2}x\cos x. $$ 

### 习题 7.6

1. (1)  $ \mathbf{Y} = \begin{bmatrix} \frac{1}{4} & \frac{3}{4} \\ -\frac{1}{2} & \frac{3}{2} \end{bmatrix} \begin{bmatrix} \mathbf{e}^{-3x} \\ \mathbf{e}^{5x} \end{bmatrix}; $ (2)  $ \mathbf{Y} = \begin{bmatrix} \frac{1}{2} & 0 \\ 0 & -1 \end{bmatrix} \begin{bmatrix} \mathbf{e}^{-x} \sin 4x \\ \mathbf{e}^{-x} \cos 4x \end{bmatrix}; $

(3)

 $$ \begin{aligned}&\text{Ⅸ }\mathbf{Y}=\begin{bmatrix}{{{\mathbf{e}^{2x}}}} \\{{{1-2\mathbf{e}^{2x}}}} \\{{{1-\mathbf{e}^{2x}}}}\end{bmatrix};\quad(4)\mathbf{Y}=\begin{bmatrix}{{{-1}}}&{{{1}}}&{{{1}}} \\{{{-1}}}&{{{0}}}&{{{1}}} \\{{{1}}}&{{{1}}}&{{{0}}}\end{bmatrix}\begin{bmatrix}{{{1}}} \\{{{0}}} \\{{{2\mathbf{e}^{-x}}}}\end{bmatrix};\end{aligned} $$ 

(5)

 $$ \mathbf{Y}=\mathbf{e}^{2x}\begin{bmatrix}{{{1}}}&{{{0}}}&{{{0}}} \\{{{x}}}&{{{1}}}&{{{0}}} \\{{{\frac{1}{2}x^{2}}}}&{{{x}}}&{{{1}}}\end{bmatrix}\begin{bmatrix}{{{C_{1}}}} \\{{{C_{2}}}} \\{{{C_{3}}}}\end{bmatrix}； $$ 

 $$ \begin{aligned}(6)\mathbf{Y}&=\begin{bmatrix}0&3\cos4x-4\sin4x&4\cos4x-3\sin4x\\0&5\cos4x&5\sin4x\\e^{x}&0&0\end{bmatrix}\begin{bmatrix}C_{1}\\C_{2}\\C_{3}\end{bmatrix}.\end{aligned} $$ 

2. (1)  $  \mathbf{Y} = \begin{bmatrix} 3 & 1 \\ -1 & 2 \end{bmatrix}  $

 $  C_1 \mathbf{e}^{-3x} + \frac{1}{14} \mathbf{e}^x - \frac{1}{35} \mathbf{e}^{2x}  $

 $  C_2 \mathbf{e}^{4x} - \frac{1}{21} \mathbf{e}^x - \frac{3}{14} \mathbf{e}^{2x}  $