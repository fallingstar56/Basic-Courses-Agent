 $$ \begin{align*}\boldsymbol{A}\boldsymbol{Y}(x)=&\mathrm{e}^{\lambda x}\Biggl[\left(\boldsymbol{A}-\lambda\boldsymbol{I}\right)+x(\boldsymbol{A}-\lambda\boldsymbol{I})^{2}+\cdots+\frac{x^{k-2}}{(k-2)!}(\boldsymbol{A}-\lambda\boldsymbol{I})^{k-1}\Biggr]\boldsymbol{U}\\&+\lambda\mathrm{e}^{\lambda x}\Biggl[\boldsymbol{I}+x(\boldsymbol{A}-\lambda\boldsymbol{I})+\cdots+\frac{x^{k-1}}{(k-1)!}(\boldsymbol{A}-\lambda\boldsymbol{I})^{k-1}\Biggr]\boldsymbol{U}=\boldsymbol{Y}^{\prime}(x).\end{align*} $$ 

于是  $ Y(x) $ 为微分方程组 (18) 的解.

根据命题 7.6.1，如果  $ \lambda_{1}, \lambda_{2}, \cdots, \lambda_{m} $ 分别是矩阵 A 的  $ k_{1}, k_{2}, \cdots, k_{m} $ 重特征根，且  $ k_{1} + k_{2} + \cdots + k_{m} = n $，则代数方程组  $ (\lambda_{j} I - A)^{k_{j}} U = 0 $ 有  $ k_{j} $ 个线性无关解。按照上述做法，相应于  $ \lambda_{j} $ 可得到微分方程组（18）的  $ k_{j} $ 个线性无关解（j = 1, 2,  $ \cdots $, m），并且对于不同的特征根  $ \lambda_{i} $ 与  $ \lambda_{j} $，相应于  $ \lambda_{i} $ 的解与相应于  $ \lambda_{j} $ 的解线性无关。因此可以得到微分方程组（18）的 n 个线性无关解。

#### ▶ 例 7.6.5

求解方程组  $ Y' = AY $，其中  $ A = \begin{pmatrix} 3 & 1 & -1 \\ 2 & 2 & -1 \\ 2 & 2 & 0 \end{pmatrix} $.

解  $ \det(\lambda\boldsymbol{I}-\boldsymbol{A})=(\lambda-1)(\lambda-2)^{2} $

所以 A 的特征根为  $ \lambda_{1}=1,\lambda_{2}=\lambda_{3}=2 $。求解特征方程  $ (I-A)U=0 $ 可解得 A 的属于  $ \lambda_{1}=1 $ 的特征向量  $ \boldsymbol{U}_{1}=(1,0,2)^{\mathrm{T}}.\lambda=2 $ 为 A 的二重特征根，且不难验证 2I-A 的秩为 2，从而不存在属于  $ \lambda=2 $ 的两个线性无关的特征向量。由于

 $$ \left(2\boldsymbol{I}-\boldsymbol{A}\right)^{2}=\begin{aligned}\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}} \\{{{2}}}&{{{-2}}}&{{{0}}}\end{bmatrix},\end{aligned} $$ 

容易解得代数方程组有 $ (2\boldsymbol{I}-\boldsymbol{A})^{2}\boldsymbol{U}=\boldsymbol{0} $ 有两个线性无关解 $ \boldsymbol{U}_{2}=(1,1,2)^{\mathrm{T}} $ 与 $ \boldsymbol{U}_{3}=(0,0,-1)^{\mathrm{T}} $. 相应地可得原微分方程组的解

 $$ \begin{aligned}\mathbf{Y}_{2}(x)&=\mathrm{e}^{2x}[\mathbf{I}+x(\mathbf{A}-2\mathbf{I})]\mathbf{U}_{2}\\&=\mathrm{e}^{2x}\begin{bmatrix}1+x&x&-x\\ 2x&1&-x\\ 2x&2x&1-2x\end{bmatrix}\begin{pmatrix}1\\ 1\\ 2\end{pmatrix}=\mathrm{e}^{2x}\begin{pmatrix}1\\ 1\\ 2\end{pmatrix},\end{aligned} $$ 

 $$ \begin{aligned}\mathbf{Y}_{3}(x)&=\mathrm{e}^{2x}[\mathbf{I}+x(\mathbf{A}-2\mathbf{I})]\mathbf{U}_{3}\\&=\mathrm{e}^{2x}\begin{pmatrix}1+x&x&-x\\2x&1&-x\\2x&2x&1-2x\end{pmatrix}\begin{pmatrix}0\\0\\-1\end{pmatrix}=\mathrm{e}^{2x}\begin{pmatrix}x\\x\\2x-1\end{pmatrix},\end{aligned} $$ 

所以原方程组的通解为

 $$ \mathbf{Y}(x)=c_{1}\mathbf{e}^{x}\begin{pmatrix}1\\ 0\\ 2\end{pmatrix}+c_{2}\mathbf{e}^{2x}\begin{pmatrix}1\\ 1\\ 2\end{pmatrix}+c_{3}\mathbf{e}^{2x}\begin{pmatrix}x\\ x\\ 2x-1\end{pmatrix}. $$ 