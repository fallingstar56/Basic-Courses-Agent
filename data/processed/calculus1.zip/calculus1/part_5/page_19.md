### 习题 4.5

3.  $  f(x) = \frac{x^{6}}{6} - \frac{x^{4}}{2} + \frac{x^{2}}{2}  $.

### 习题 4.6

1. (1)  $ y = x + \frac{1}{2} $;  $ y = -x - \frac{1}{2} $; x = 1. (3) y = -x - 1.

## 第 4 章 总复习题

16.（1）-3；（2） $ \frac{1}{8} $. 17. $ f(0)=f'(0)=0,f''(0)=2 $,极限为e.

### 习题 5.3

1. (6)  $  F'(x) = \begin{cases} 2x, & 0 < x < 1, \\ 1, & 1 < x < 2. \end{cases}  $  $  F'_{+}(0) = 0  $,  $  F_{-}(2) = 1  $.

8.（1）1；（2）4；（3） $ \frac{\pi}{2} $；（4） $ \frac{1}{6} $

12. (1) 1; (2) 13; (3)  $ 2\sqrt{2}-1 $; (4)  $ 2-\frac{\sqrt{2}}{2} $; (5)  $ \frac{4}{3} $;

(6)  $ \frac{1}{2}(\ln8)^{2} $

13. (1)  $ \frac{2}{\pi} $; (2)  $ \frac{\pi}{4} $; (3)  $ \frac{4\sqrt{2}}{3}-\frac{2}{3} $.

14.  $ \frac{4}{e} $

### 习题 5.4

3. (1)  $ \frac{4}{11}x^{\frac{3}{4}} + 4x^{-\frac{1}{4}} + C $;

(2)  $ 2\arctan x - x + C $;

(3)  $ \begin{cases} x + C, & a = \frac{1}{e} \\ (a e)^x \frac{1}{\ln a e} + C, & a \neq \frac{1}{e} \end{cases} $

(4)  $ x^3 - \frac{5}{2}x^2 + 2x + C $;

 $ (5)x^{3}-\frac{5}{2}x^{2}+2x+C; $

(6)  $ 2\sinh x - 3\cosh x + C; $

(7)  $ 3x + 2\cot x + C $;

(8)  $ -\ln|\cos x| + C; $

(9) $ \begin{cases}x^{3}-\frac{5}{2}x^{2}+2x-1+C,&x\geqslant1,\\-x^{3}+\frac{5}{2}x^{2}-2x+C,&\frac{2}{3}<x<1,\\x^{3}-\frac{5}{2}x^{2}+2x-\frac{28}{27}+C,&x\leqslant\frac{2}{3}.\end{cases} $