(2)  $  \mathbf{Y} = \begin{bmatrix} \cos x & \sin x \\ -\sin x & \cos x \end{bmatrix} \begin{bmatrix} C_1 \\ C_2 \end{bmatrix} + \begin{bmatrix} 3 \\ 0 \end{bmatrix}  $;

(3)  $  \mathbf{Y} = \begin{bmatrix} 1 & 1 \\ 1 & 3 \end{bmatrix} \begin{bmatrix} C_1 \mathbf{e}^{-x} \\ C_2 \mathbf{e}^{-3x} \end{bmatrix} + \begin{bmatrix} 0 \\ \cos x \end{bmatrix}  $;

(4)  $ \mathbf{Y} = \begin{bmatrix} 1 & 1 & 1 \\ 1 & 0 & 1 \\ -1 & -1 & 2 \end{bmatrix} \begin{bmatrix} 5 \\ e^{x} \\ -3e^{-x} \end{bmatrix} + \begin{bmatrix} -2 \\ -1 \\ 1 \end{bmatrix} $.

## 第 7 章 总复习题

1. (1)  $ \frac{Cx}{\sqrt{1+x^{2}}} $;

(2)  $ x = y^{2}(1 + C\mathrm{e}^{\frac{1}{y}}) $;

(3)  $  y = \arcsin(x + C\sqrt{x^2 - 1})  $; (4)  $  y = e^{(x - C)\sec x}  $;

(5) $ y=-\frac{2(1+x)}{2x+x^{2}-2C}; $

(6)  $  y = \frac{1}{9} [x^2 - 1 + 3C(x^2 - 1)^{\frac{1}{4}}]^2  $;

(7) $ y=\frac{1}{2}\left(C\pm\sqrt{4x^{4}+C^{2}}\right); $ (8) $ y=\frac{1}{x(C-\ln x)}; $

(9) $ y+\ln\frac{2+x-y}{2-x+y}=C; $

(10)  $  y = \pm \frac{\sqrt{16 \ln x + C}}{x}  $; (11)  $  y = \arcsin(x + \sqrt{x^2 + 1})  $.

2. (1)  $ y = C_{1} \arctan x + C_{2} $; (2)  $ y^{2} = C_{1} x^{2} + C_{2} $

(3)  $ y = C e^{-\varphi(x)} + (\omega(x) - 1). $

6. 齐次方程的通解为  $ y = C_{1} + C_{2}(x^{2} + 1) $，非其次方程特解为  $ y = C_{1} + C_{2}(x^{2} + 1) + \frac{x^{2}}{6}(x^{2} - 3) $.

8.  $ -\frac{\pi}{5}\sqrt{\frac{2}{g}}\left(h^{\frac{5}{2}}-10^{\frac{5}{2}}\right)=0.9t $，约100s后水流完.

9.  $ v(t)=\frac{P}{k}(1-\mathrm{e}^{-kt}) $

10. y=1-x.

11.  $ y^{2k-1}=Cx. $