(5) 1; (6)  $ \frac{m-n}{2} $; (7)  $ \frac{n}{m} $; (8)  $ e^{\frac{x}{1-x}} $.

9.  $  f(x) = \begin{cases} e, & x = 1, \\ 0, & x < 1. \end{cases}  $

11. (1)  $ a=2, b=-3; $ (2)  $ c=\frac{1}{3},\quad\frac{1}{3}. $

12. x=0 为第一类间断点（跳跃），x=-2 为第一类间断点（可去），x=1 为第二类间断点， $ x=k(k<0,k\in\mathbb{Z},k\neq-2) $ 为第二类间断点.

13.  $ f(g(x)), g(f(x)), (g(x))^{2} $ 有可能连续，有可能间断， $ \frac{g(x)}{f(x)} $ 不连续.

23. 提示： $ \forall\varepsilon>0 $，在 $ U(x_{0},1) $内使得 $ \frac{1}{n}\geqslant\varepsilon $的有理数 $ x=\frac{m}{n}(m,n $互质)只有有限个.

### 习题 3.1

4.(2),(4).

5. (1)  $ (\alpha + \beta)f'(x_0) $; (2)  $ 2f'(x_0) $; (3)  $ -f'(x_0) $; (4)  $ e^{f'(x_0)} $.

8.  $  V'(r) = 4\pi r^2  $.

9.  $ a=\frac{1}{2e} $,  $ y-\frac{1}{2}=\frac{1}{\sqrt{e}}(x-\sqrt{e}) $.

10. (2,4),  $ \left(-\frac{3}{2},\frac{9}{4}\right) $,  $ \left(\frac{1}{4},\frac{1}{16}\right) $ 和  $ (-1,1) $.

13.0.05.

14.(1)0.48; (2) $ -0.87 $; (3)1.01.

15. 2.23cm.

### 习题 3.2

9. (1)  $ x + 2y - 3 = 0 $; (2)  $ 4\sqrt{3}x + 5y - 90 = 0 $; (3)  $ y = x + 1 $. 10.

(5)  $  y'(x) = \frac{\sin\theta + \theta\cos\theta}{\cos\theta - \theta\sin\theta}  $; (6)  $  y'(x) = \frac{m\sin\theta + \cos\theta}{m\cos\theta - \sin\theta}  $.

### 习题 3.3

3. (3)  $ y^{(5)}=\frac{-120\ln x+274}{x^{6}} $; (6)  $ y^{(20)}=\frac{20!}{3}\left(\frac{1}{(x+2)^{21}}-\frac{1}{(x-1)^{21}}\right) $;

(7)

 $$ \begin{aligned}y^{(n)}&=(a^{n}-C_{n}^{2}a^{n-2}b^{2}+C_{n}^{4}a^{n-4}b^{4}+\cdots)e^{ax}\cos bx\\&\quad-(C_{n}^{1}a^{n-1}b^{1}-C_{n}^{3}a^{n-3}b^{3}+C_{n}^{5}a^{n-5}b^{5}+\cdots)e^{ax}\sin bx;\end{aligned} $$ 

(8)

 $$ \begin{aligned}y^{(n)}&=(a^{n}-C_{n}^{2}a^{n-2}b^{2}+C_{n}^{4}a^{n-4}b^{4}+\cdots)e^{ax}\sin bx\\&+(C_{n}^{1}a^{n-1}b^{1}-C_{n}^{3}a^{n-3}b^{3}+C_{n}^{5}a^{n-5}b^{5}+\cdots)e^{ax}\cos bx\end{aligned} $$ 