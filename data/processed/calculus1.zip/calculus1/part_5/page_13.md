(3) $ (1-x^{2})y'\cos y+x\sin y=1 $;  $ (4)y^{-1}y'-\tan x\ln y=\sec x $;

(5) $ y'-\frac{y}{1+x}=y^{2} $;

(6) $ y'+\frac{xy}{1-x^{2}}=x\sqrt{y}; $

(7) $ y'=\frac{4x^{3}y}{x^{4}+y^{2}} $;

 $$ x\mathrm{d}y=y(xy-1)\mathrm{d}x; $$ 

(9) $ (x-y)^{2}y^{\prime}=4; $

(10) $ x^{2}y(xy^{\prime}+y)=8; $

(11) $ (x-\sin y)\mathrm{d}y+\tan y\mathrm{d}x=0,\quad y(0)=\frac{\pi}{2}. $

2. 求解下列微分方程.

(1) $ (1+x^{2})y''+2xy'=0; $ (2) $ xyy''+x(y')^{2}-yy'=0; $

(3) 已知  $ \varphi(x) $ 为可微函数，且  $ \frac{dy}{dx} + \frac{d\varphi}{dx}y = \varphi(x) \frac{d\varphi}{dx} $，求  $ y = y(x) $.

3. 设  $ y_{i}(x) $ ( $ 1 \leqslant i \leqslant n $) 为方程  $ y^{(n)} + a_{1}(x)y^{(n-1)} + \cdots + a_{n-1}(x)y' + a_{n}(x)y = 0 $ 的任意 n 个解，它们构成的朗斯基行列式为  $ W(x) $，证明： $ W(x) $ 满足一阶线性方程

 $$ W^{\prime}+a_{1}(x)W=0 $$ 

(从而可以解得  $ W(x)=W(x_{0})\exp\left(-\int_{x_{0}}^{x}a_{1}(s)ds\right) $.)

4. 设  $ y_{1}(x) \neq 0 $ 为二阶齐次线性方程  $ y'' + a_{1}(x)y' + a_{2}(x)y = 0 $ 的解，其中  $ a_{1}(x), a_{2}(x) \in C[a, b] $，证明：

(1) $ y_{2}(x) $为方程的解的充要条件为 $ \frac{\mathrm{d}W\left[y_{1},y_{2}\right]}{\mathrm{d}x}+a_{1}(x)W\left[y_{1},y_{2}\right]=0; $

(2) 方程的通解可以表示为  $ y = y_{1}\left[C_{1}\int\frac{1}{y_{1}^{2}}\exp\left(-\int_{x_{0}}^{x}a_{1}(s)\mathrm{d}s\right)\mathrm{d}x+C_{2}\right] $，其中  $ C_{1}, C_{2} $ 为任意常数， $ x_{0}, x \in [a, b] $.

5. 设  $ y = \varphi(x) $ 是方程  $ y'' + a_{1}(x)y' + a_{2}(x)y = 0 $ 的非零解，其中  $ a_{1}(x) $， $ a_{2}(x) \in C[a, b] $，求证： $ \forall x_{0} \in (a, b) $， $ \varphi(x_{0}) $， $ \varphi'(x_{0}) $ 至多有一个为零.

6. 已知齐次方程 $ (1-x^{2})y''+2xy'-2y=0 $ 的一个解为 y=x，求解下列非齐次方程：

 $$ (1-x^{2})y^{\prime \prime}+2xy^{\prime}-2y=-(1-x^{2})^{2}. $$ 

7. 已知二阶线性常系数齐次微分方程  $ y'' + py' + qy = 0 $，当 p, q 满足什么条件时，对方程的

任意解  $ y=y(x) $，均有  $ \lim_{x\to+\infty}y(x)=0. $

8. 有一盛满了水的圆锥形漏斗，高为 10m，顶角  $ \alpha = \frac{\pi}{3} $，漏斗顶端处有一面积为  $ 0.5 \, cm^2 $ 的小孔，打开小孔阀门，让水流出漏斗，求漏斗内水面高度的变化