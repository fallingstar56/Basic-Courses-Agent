程(14)的满足初值条件(15)的解唯一存在.

#### 7.6.2 常系数一阶齐次线性常微分方程组的解法

关于 n 个未知函数的常系数一阶齐次线性常微分方程组的规范形式为

 $$ Y^{\prime}=A Y. $$ 

其中 A 为方程组(18)的(数值)系数矩阵：

 $$ \begin{aligned}\boldsymbol{A}&=\begin{bmatrix}a_{11}&a_{12}&\cdots&a_{1n}\\a_{21}&a_{22}&\cdots&a_{2n}\\\vdots&\vdots&&\vdots\\a_{n1}&a_{n2}&\cdots&a_{nn}\end{bmatrix}.\end{aligned} $$ 

对于齐次线性方程组(18)的求解问题，可以用类似于求解常系数高阶线性常微分方程的方法。假设方程组(18)有形如  $ Y = e^{kx}U $ 的解，其中  $ \lambda $ 是待定常数，U 是待定的非零 n 维向量。将其代入方程组(18)得

 $$ \lambda\mathrm{e}^{\lambda x}\boldsymbol{U}=\boldsymbol{A}\mathrm{e}^{\lambda x}\boldsymbol{U}=\mathrm{e}^{\lambda x}\boldsymbol{A}\boldsymbol{U}. $$ 

两端消去  $ e^{kx} $ 得

 $$ (\mathbf{A}-\lambda\mathbf{I})\mathbf{U}=\mathbf{0}, $$ 

其中 I 是 n 阶单位矩阵。将 (20) 式看作以  $ \boldsymbol{U} = (u_{1}, u_{2}, \cdots, u_{n})^{\mathrm{T}} $ 为未知向量的 n 阶代数方程组，它有非零解的充分必要条件是它的系数行列式为零：

 $$ \operatorname*{d e t}(\lambda\boldsymbol{I}-\boldsymbol{A})=0. $$ 

以  $ \lambda $ 为未知量的代数方程(21)称为方程组(18)的特征方程，它的根称为方程组的特征根。如果  $ \lambda $ 为方程(21)的一个特征根，U 为方程组(20)的对应于  $ \lambda $ 的非零解，则  $ Y = e^{\lambda x} U $ 就是方程组(18)的解。

根据矩阵理论, $ \det(\lambda I-A) $称为矩阵A的特征多项式,方程(21)的根 $ \lambda $也称为矩阵A的特征根,方程(20)的非零解U称为矩阵A的属于特征根 $ \lambda $的特征向量.

情形一 矩阵 A 有 n 个线性无关的特征向量  $ U_{1}, U_{2}, \cdots, U_{n} $，分别属于 A 的特征根  $ \lambda_{1}, \lambda_{2}, \cdots, \lambda_{n} $。此时， $ Y_{1} = e^{\lambda_{1}x} U_{1}, Y_{2} = e^{\lambda_{2}x} U_{2}, \cdots, Y_{n} = e^{\lambda_{n}x} U_{n} $ 就是方程组（18）的 n 个解，并且

 $$ W[\mathbf{Y}_{1},\mathbf{Y}_{2},\cdots,\mathbf{Y}_{n}](0)=\det(\mathbf{U}_{1},\mathbf{U}_{2},\cdots,\mathbf{U}_{n})\neq0. $$ 

从而  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 是方程组（18）的 n 个线性无关解.

▶ 例 7.6.3

求解方程组  $ Y' = A Y $，其中  $ A = \begin{pmatrix} 1 & -2 \\ 1 & 4 \end{pmatrix} $.

解  $ \det(\lambda I - A) = (\lambda - 1)(\lambda - 4) + 2 = (\lambda - 2)(\lambda - 3). $

所以 A 的特征根为  $ \lambda_{1}=2,\lambda_{2}=3 $。分别求解特征方程  $ (2\boldsymbol{I}-\boldsymbol{A})\boldsymbol{U}=0 $ 与  $ (3\boldsymbol{I}-\boldsymbol{A})\boldsymbol{U}=0 $