### 习题 7.6

1. 求解下列微分方程组 $ \frac{dY}{dx}=AY. $

(1)  $ A = \begin{pmatrix} 1 & 2 \\ 8 & 1 \end{pmatrix} $,  $ Y(0) = \begin{pmatrix} 1 \\ 1 \end{pmatrix} $;

(2) $ A=\begin{pmatrix}-1&-2\\8&-1\end{pmatrix},\quad Y(0)=\begin{pmatrix}0\\-1\end{pmatrix}; $

(3)

 $$ \begin{aligned}\boldsymbol{A}&=\begin{bmatrix}{{{1}}}&{{{-1}}}&{{{1}}} \\{{{-2}}}&{{{2}}}&{{{-2}}} \\{{{-1}}}&{{{1}}}&{{{-1}}}\end{bmatrix},\quad\boldsymbol{Y}(0)=\begin{bmatrix}{{{1}}} \\{{{-1}}} \\{{{0}}}\end{bmatrix};\end{aligned} $$ 

(4)

 $$ \begin{aligned}\boldsymbol{A}&=\begin{pmatrix}0&-2&-2\\2&-4&-2\\-2&2&0\end{pmatrix},\quad\boldsymbol{Y}(0)=\begin{pmatrix}1\\1\\1\end{pmatrix};\end{aligned} $$ 

(5)

 $$ \boldsymbol{A}=\begin{pmatrix}{{{2}}}&{{{0}}}&{{{0}}} \\{{{1}}}&{{{2}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{2}}}\end{pmatrix}; $$ 

(6)

 $$ \begin{aligned}\boldsymbol{A}&=\begin{pmatrix}{{{3}}}&{{{-5}}}&{{{0}}} \\{{{5}}}&{{{-3}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{1}}}\end{pmatrix}.\end{aligned} $$ 

2. 求解下列非齐次微分方程组.

(1)

 $$ \begin{cases}\frac{\mathrm{d}y_{1}}{\mathrm{d}x}+2y_{1}-3y_{2}=\mathrm{e}^{x},\\\frac{\mathrm{d}y_{2}}{\mathrm{d}x}-2y_{1}-3y_{2}=\mathrm{e}^{2x};\end{cases} $$ 

(2)

 $$ \begin{cases}\frac{\mathrm{d}y_{1}}{\mathrm{d}x}+\frac{\mathrm{d}y_{2}}{\mathrm{d}x}=-y_{1}+y_{2}+3,\\\frac{\mathrm{d}y_{1}}{\mathrm{d}x}-\frac{\mathrm{d}y_{2}}{\mathrm{d}x}=y_{1}+y_{2}-3;\end{cases} $$ 

(3)

 $$ \begin{cases}4\ \frac{\mathrm{d}y_{1}}{\mathrm{d}x}-\frac{\mathrm{d}y_{2}}{\mathrm{d}x}=-3y_{1}+\sin x,\\\frac{\mathrm{d}y_{1}}{\mathrm{d}x}=-y_{2}+\cos x;\end{cases} $$ 

(4)

 $$ \begin{cases}\frac{\mathrm{d}y_{1}}{\mathrm{d}x}=2y_{1}-y_{2}+y_{3}+2,\\\frac{\mathrm{d}y_{2}}{\mathrm{d}x}=y_{1}+y_{3}+1,\\\frac{\mathrm{d}y_{3}}{\mathrm{d}x}=-3y_{1}+y_{2}-2y_{3}-3,\\y_{1}\left(0\right)=y_{2}\left(0\right)=y_{3}\left(0\right)=1.\end{cases} $$ 

## 第 7 章总复习题

1. 解下列微分方程.

(1)

 $$ (x+x^{3})y^{\prime}=y; $$ 

(2)

 $$ (x^{2}-2xy-y^{2})y^{\prime}+y^{2}=0; $$ 