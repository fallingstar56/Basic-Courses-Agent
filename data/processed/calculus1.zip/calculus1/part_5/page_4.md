 $$ \begin{aligned}\mathbf{Y}(x)&=\boldsymbol{\varPhi}\left(x\right)\mathbf{C}=c_{1}\mathbf{Y}_{1}(x)+c_{2}\mathbf{Y}_{2}(x)+\cdots+c_{n}\mathbf{Y}_{n}(x)\\&=\begin{cases}c_{1}y_{11}(x)+c_{2}y_{12}(x)+\cdots+c_{n}y_{1n}(x)\\c_{1}y_{21}(x)+c_{2}y_{22}(x)+\cdots+c_{n}y_{2n}(x)\\\vdots\\c_{1}y_{n1}(x)+c_{2}y_{n2}(x)+\cdots+c_{n}y_{nn}(x)\end{cases},\end{aligned} $$ 

其中  $ \boldsymbol{C}=(c_{1},c_{2},\cdots,c_{n})^{\mathrm{T}} $ 为任意的 n 维列向量.

注意基本解矩阵  $ \Phi(x) $ 的行列式  $ \det\Phi(x)=W\left[Y_{1},Y_{2},\cdots,Y_{n}\right](x) $ 在每一点 x 处都不为零，从而  $ \Phi(x) $ 为可逆矩阵，因此对于任意的 n 维向量  $ \boldsymbol{\xi}=(\boldsymbol{\xi}_{1}\quad\boldsymbol{\xi}_{2}\quad\cdots\quad\boldsymbol{\xi}_{n})^{\mathrm{T}} $，可以根据表达式(6)求得方程组(2)的满足定解条件  $ \mathbf{Y}(x_{0})=\xi $ 的特解  $ \mathbf{Y}(x) $ 如下：

设  $ Y(x)=\Phi(x)C $，于是  $ \Phi(x_{0})C=Y(x_{0})=\xi,C=\Phi^{-1}(x_{0})\xi $，所以

 $$ \mathbf{Y}(x)=\mathbf{\Phi}\left(x\right)\mathbf{\Phi}^{-1}(x_{0})\mathbf{\xi}. $$ 

▶ 例 7.6.1

验证 $ \Phi(x)=\begin{bmatrix}e^{2x}&e^{-x}\\ 2e^{2x}&-e^{-x}\end{bmatrix} $为方程组 $ Y'=\begin{pmatrix}0&1\\ 2&1\end{pmatrix}Y $的基本解矩阵，并求此方程组满足定解条件 $ Y(0)=(1,5)^{\mathrm{T}} $的特解 $ Y(x) $.

解 记  $ \boldsymbol{Y}_{1}=(\mathrm{e}^{2x},2\mathrm{e}^{2x})^{\mathrm{T}},\boldsymbol{Y}_{2}=(\mathrm{e}^{-x},-\mathrm{e}^{-x})^{\mathrm{T}} $ ，则

 $$ \begin{pmatrix}{{{0}}}&{{{1}}} \\{{{2}}}&{{{1}}}\end{pmatrix}\mathbf{Y}_{1}=\begin{pmatrix}{{{2\mathrm{e}^{2x}}}} \\{{{4\mathrm{e}^{2x}}}}\end{pmatrix}=\mathbf{Y}_{1}^{\prime},\quad\begin{pmatrix}{{{0}}}&{{{1}}} \\{{{2}}}&{{{1}}}\end{pmatrix}\mathbf{Y}_{2}=\begin{pmatrix}{{{-\mathrm{e}^{-x}}}} \\{{{\mathrm{e}^{-x}}}}\end{pmatrix}=\mathbf{Y}_{2}^{\prime}, $$ 

即  $ Y_{1}, Y_{2} $ 是原方程组的解，从而  $ \Phi(x) = (Y_{1}Y_{2}) $ 是基本解矩阵.

设  $ \boldsymbol{Y}(x)=\boldsymbol{\varPhi}(x)\boldsymbol{C} $，则  $ \boldsymbol{\varPhi}(0)(c_{1},c_{2})^{\mathrm{T}}=(1,5)^{\mathrm{T}} $，即  $ 2c_{1}-c_{2}=5,c_{1}+c_{2}=1 $。解之得， $ c_{1}=2,c_{2}=-1 $。于是所求特解  $ \boldsymbol{Y}(x)=\boldsymbol{\varPhi}(x)(2,-1)^{\mathrm{T}}=\begin{pmatrix}2\mathrm{e}^{2x}-\mathrm{e}^{-x}\\ A\mathrm{e}^{2x}+\mathrm{e}^{-x}\end{pmatrix} $。

下面考虑非齐次方程组(1)的解的结构问题.

定理 7.6.5

(1) 非齐次方程组(1)的任意两个解  $ Y_{0}, Y_{1} $ 之差  $ Y_{0}-Y_{1} $ 是方程组(2)的解. 又设 Y 是齐次方程组(2)的解，则  $ Y_{0}+Y $ 是方程组(1)的解.

(2) 设 Y 是方程组 (1) 的解,  $ Y_{1}, Y_{2}, \cdots, Y_{n} $ 是方程组 (2) 的 n 个线性无关解, 则方程组 (1) 的通解可表达为

 $$ \mathbf{Y}(x)=\widetilde{\mathbf{Y}}+c_{1}\mathbf{Y}_{1}(x)+c_{2}\mathbf{Y}_{2}(x)+\cdots+c_{n}\mathbf{Y}_{n}(x), $$ 

其中  $ c_{1}, c_{2}, \cdots, c_{n} $ 是 n 个任意常数.