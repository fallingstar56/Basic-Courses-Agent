10. 设  $ f(x) $ 的定义域关于原点对称. 证明： $ f(x) $ 可以表示为一个奇函数与一个偶函数的和.

11. 设  $ f(x) $ 为  $ \mathbb{R} $ 上的奇函数，当 x > 0 时， $ f(x) = x - x^{2} + 1 $，求  $ f(x) $ 在  $ (-\infty, 0] $ 上的表达式.

12. 证明：奇函数在对称区间上单调性相同，偶函数在对称区间上单调性相反.

13. 下列哪些函数是周期函数？如果是，则求出其最小正周期.

(1)  $ y = \cos\left(2x - \frac{\pi}{3}\right) $;

(2)  $ y = |\tan x| $;

(3)  $ y = x \sin x $;

(4)  $ y = \left|\ln \frac{1 - \tan x}{1 + \cot x}\right| $.

14. 设  $ f(x) $ 为  $ \mathbb{R} $ 上以 2 为周期的周期函数，当  $ x \in [0, 2) $ 时， $ f(x) = x^{2} $，求  $ f(x) $ 在  $ [4, 6) $ 上的表达式，并画出  $ x \in [0, 6) $ 时  $ f(x) $ 的图像.

15. 设  $ f(x) $ 为  $ \mathbb{R} $ 上以 2 为周期的奇函数，当  $ x \in [0, 1] $ 时， $ f(x) = x(1 - x) $，求  $ f(x) $ 的表达式，并画出  $ f(x) $ 的图像.

16. 设  $ a \neq b $，函数  $ y = f(x) $ 关于直线 x = a 与 x = b 对称，证明：f 是周期函数.

17. 证明： $ \sin|x|,\sin x^{2} $ 不是周期函数.

18. 求下列函数的反函数，并求出反函数的定义域.

 $$ y=\ln(x-1)+2 $$ 

 $$ y=\arcsin\frac{x-1}{4}; $$ 

(3)  $ y=1+\cos^{3}x, x\in[0,\pi] $; (4)  $ y=\sin x, x\in\left[\frac{\pi}{2},\frac{3\pi}{2}\right] $;

(5) $ y=\left\{\begin{aligned}&1-2x^{2},&x<-1,\\&x^{3},&-1\leqslant x\leqslant2,\\&12x-16,&x>2.\end{aligned}\right. $

19. 求分式线性函数  $ y=\frac{ax+b}{cx+d} $ ( $ ad\neq bc,c\neq0 $) 的反函数，并讨论何时它的反函数与它相同.

20. 设奇函数 f 存在反函数，证明：它的反函数  $ f^{-1} $ 也为奇函数.

21. 设函数 f 在定义域内严格递增，证明：它的反函数  $ f^{-1} $ 也严格递增.

22. 证明： $ y=\frac{1}{x^{2}} $ 在定义域内无界； $ \forall\delta>0,y=\frac{1}{x^{2}} $ 在 $ (-∞,\delta]∪[\delta,+∞) $ 上有界.

23. 双曲函数是一类常用的函数，定义如下：

双曲正弦  $ \sin h x = \frac{e^{x} - e^{-x}}{2} $; 双曲余弦  $ \cosh x = \frac{e^{x} + e^{-x}}{2} $;

双曲正切  $ \tanh x = \frac{\sinh x}{\cosh x} = \frac{e^{x} - e^{-x}}{e^{x} + e^{-x}} $；双曲余切  $ \coth x = \frac{\cosh x}{\sinh x} = \frac{e^{x} + e^{-x}}{e^{x} - e^{-x}} $