(9)  $ \int \frac{\arctan x}{x^{2}(1 + x^{2})} \, dx. $

### 5.6 定积分的计算

掌握了牛顿-莱布尼茨公式与原函数的求法，就可以进一步讨论定积分的计算问题.

▶ 例 5.6.1

计算 $ \int_{-1}^{1}x\sqrt{x+1}dx. $

解

 $$ \begin{aligned}\int_{-1}^{1}x\sqrt{x+1}\mathrm{d}x&=\int_{-1}^{1}(x+1)\sqrt{x+1}\mathrm{d}x-\int_{-1}^{1}\sqrt{x+1}\mathrm{d}x\\&=\frac{2}{5}(x+1)^{2/5}\bigg|_{-1}^{1}-\frac{2}{3}(x+1)^{2/3}\bigg|_{-1}^{1}\\&=\frac{2}{5}\times2^{2/5}-\frac{2}{3}\times2^{2/3}=\frac{4}{15}\sqrt{2}.\end{aligned} $$ 

▶ 例 5.6.2

计算半径为 a 的圆  $ x^{2} + y^{2} \leqslant a^{2} $ 的面积 S.

解 根据圆的对称性与积分的几何意义，

 $$ S=4\int_{0}^{a}\sqrt{a^{2}-x^{2}}\mathrm{d}x. $$ 

由例 5.4.10，被积函数  $ \sqrt{a^{2}-x^{2}} $ 有原函数  $ \frac{a^{2}}{2}\arcsin\frac{x}{a}+\frac{x}{2}\sqrt{a^{2}-x^{2}} $，于是

 $$ S=4\int_{0}^{a}\sqrt{a^{2}-x^{2}}\mathrm{d}x=4\left(\frac{a^{2}}{2}\arcsin\frac{x}{a}+\frac{x}{2}\sqrt{a^{2}-x^{2}}\right)\bigg|_{0}^{a}=\pi a^{2}. $$ 

这就是我们熟知的圆的面积公式。

类似于不定积分的情形，对于定积分，也有如下换元法：

定理 5.6.1(定积分换元法)

设函数  $ f \in C[a, b] $， $ \varphi $ 在  $ [a, \beta] $ 上有连续导数。又设函数  $ x = \varphi(t) $ 在  $ [a, \beta] $ 上的值域包含于  $ [a, b] $ 中，且  $ \varphi(a) = a, \varphi(\beta) = b $，则有

 $$ \int_{a}^{b}f(x)\mathrm{d}x=\int_{a}^{\beta}f(\varphi(t))\varphi^{\prime}(t)\mathrm{d}t. $$ 

证明  $ f \in C[a, b] $，故 f 在  $ [a, b] $ 上有原函数  $ F(x) $，此时  $ F(\varphi(t)) $ 是  $ f(\varphi(t)) \varphi'(t) $ 的一个原函数，因此

 $$ \int_{a}^{\beta}f(\varphi(t))\varphi^{\prime}(t)\mathrm{d}t=F(\varphi(t))\left|_{\frac{\beta}{a}}=F(b)-F(a)\right.=\int_{a}^{b}f(x)\mathrm{d}x. $$ 