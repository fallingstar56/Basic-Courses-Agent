利用定理 5.6.1，例 5.6.2 中的定积分  $ \int_{0}^{a}\sqrt{a^{2}-x^{2}}dx $ 也可以如下计算：

令  $ x = a \sin t $，则  $ t \in [0, \pi/2] $ 对应  $ x \in [0, a] $，t = 0 对应  $ x = 0 $， $ t = \pi/2 $ 对应  $ x = a $， $ \sqrt{a^2 - x^2} \, dx = a^2 \cos^2 t \, dt $。所以由定理 5.6.1，

 $$ \int_{0}^{a}\sqrt{a^{2}-x^{2}}\mathrm{d}x=\int_{0}^{\pi/2}a^{2}\cos^{2}t\mathrm{d}t=\frac{a^{2}}{2}\Big(t-\frac{\sin2t}{2}\Big)\Big|_{0}^{\pi/2}=\frac{\pi}{4}a^{2}. $$ 

比较上述对于定积分 $ \int_{0}^{a}\sqrt{a^{2}-x^{2}}dx $的两种计算方法可以看到，二者对于变换函数 $ (x=a\sin t) $的选取是同样的。定积分的换元法需要把新旧变量t与x的变化区间以及区间端点之间的对应关系弄清楚，直接把原定积分变换为关于t的定积分，因而不再需要将关于变量t的原函数还原为x的函数。这在很多情况下会使计算变得简单。

#### ▶ 例 5.6.3

设  $ f \in R[-a, a](a > 0) $，求证：

 $$ \int_{-a}^{a}f(x)\mathrm{d}x=\left\{\begin{aligned}&2\int_{0}^{a}f(x)\mathrm{d}x,&f 为偶函数 ,\\ &0,&f 为奇函数 .\end{aligned}\right. $$ 

证明 对于积分 $ \int_{-a}^{0}f(x)dx $，令x=-t，则有

 $$ \int_{-a}^{0}f(x)\mathrm{d}x=-\int_{a}^{0}f(-t)\mathrm{d}t=\int_{0}^{a}f(-t)\mathrm{d}t=\int_{0}^{a}f(-x)\mathrm{d}x, $$ 

所以

 $$ \begin{aligned}\int_{-a}^{a}f(x)\mathrm{d}x&=\int_{0}^{a}f(x)\mathrm{d}t+\int_{-a}^{0}f(x)\mathrm{d}x\\&=\int_{0}^{a}f(x)\mathrm{d}x+\int_{0}^{a}f(-x)\mathrm{d}x\\&=\int_{0}^{a}\left[f(x)+f(-x)\right]\mathrm{d}x\\&=\begin{cases}2\int_{0}^{a}f(x)\mathrm{d}x,&f 为偶函数 ,\\0,&f 为奇函数 .\end{cases}\end{aligned} $$ 

设 f 是以 T 为周期的连续函数，则  $ \forall a \in \mathbb{R} $，有

 $$ \int_{a}^{a+T}f(x)\mathrm{d}x=\int_{0}^{T}f(x)\mathrm{d}x. $$ 

证明

 $$ \int_{a}^{a+T}f(x)\mathrm{d}x=\int_{a}^{0}f(x)\mathrm{d}x+\int_{0}^{T}f(x)\mathrm{d}x+\int_{T}^{a+T}f(x)\mathrm{d}x. $$ 