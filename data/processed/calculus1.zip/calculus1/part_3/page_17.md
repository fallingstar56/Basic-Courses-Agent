▶ 例 5.4.19

计算  $ I=\int e^{ax}\cos bx\,dx $ 与  $ J=\int e^{ax}\sin bx\,dx $ ( $ ab \neq 0 $).

解 应用分部积分法得到

 $$ \int\mathrm{e}^{ax}\cos bx\mathrm{d}x=\int\mathrm{e}^{ax}\mathrm{d}\left(\frac{1}{b}\sin bx\right)=\frac{1}{b}\mathrm{e}^{ax}\sin bx-\frac{a}{b}\int\mathrm{e}^{ax}\sin bx\mathrm{d}x; $$ 

 $$ \int\mathrm{e}^{ax}\sin bx\mathrm{d}x=\int\mathrm{e}^{ax}\mathrm{d}\left(-\frac{1}{b}\cos bx\right)=-\frac{1}{b}\mathrm{e}^{ax}\cos bx+\frac{a}{b}\int\mathrm{e}^{ax}\cos bx\mathrm{d}x. $$ 

将 $ \int e^{ax}\sin bx\,dx $ 和 $ \int e^{ax}\cos bx\,dx $ 作为未知量，解上面的方程组，便得到

 $$ \int\mathrm{e}^{ax}\cos bx\mathrm{d}x=\frac{1}{a^{2}+b^{2}}\mathrm{e}^{ax}\left(b\sin bx+a\cos bx\right)+C; $$ 

 $$ \int\mathrm{e}^{ax}\sin bx\mathrm{d}x=\frac{1}{a^{2}+b^{2}}\mathrm{e}^{ax}\left(a\sin bx-b\cos bx\right)+C. $$ 

▶ 例 5.4.20 ……

计算积分  $ I_{n}=\int\left(x^{2}+b^{2}\right)^{-n}dx\quad(n\geqslant1) $

解 应用分部积分法，对任何自然数  $ k \geqslant 1 $，有

 $$ \begin{aligned}I_{k}&=\int\frac{\mathrm{d}x}{(x^{2}+b^{2})^{k}}=\frac{x}{(x^{2}+b^{2})^{k}}+2k\int\frac{x^{2}}{(x^{2}+b^{2})^{k+1}}\mathrm{d}x\\&=\frac{x}{(x^{2}+b^{2})^{k}}+2k\int\Big(\frac{1}{(x^{2}+b^{2})^{k}}-\frac{b^{2}}{(x^{2}+b^{2})^{k+1}}\Big)\mathrm{d}x\\&=x\left(x^{2}+b^{2}\right)^{-k}+2k I_{k}-2k b^{2}I_{k+1}.\\ \end{aligned} $$ 

从而得到关于 $ I_{k} $的递推公式：

 $$ I_{k+1}=\frac{1}{2k b^{2}}\big[x(x^{2}+b^{2})^{-k}+(2k-1)I_{k}\big]. $$ 

当 k=1 时，直接计算可得

 $$ I_{1}=\int\frac{\mathrm{d}x}{x^{2}+b^{2}}=\frac{1}{b}\int\frac{\mathrm{d}\left(\frac{x}{b}\right)}{1+\left(\frac{x}{b}\right)^{2}}=\frac{1}{b}\arctan\left(\frac{x}{b}\right)+C. $$ 

再由递推公式(1)便可逐次得到 $ I_{2}, I_{3}, \cdots, I_{n} $ 的表达式.

### 习题 5.4

1. 思考下列问题，如果答案是肯定的，请简要证明；如果答案是否定的，请举出反例.