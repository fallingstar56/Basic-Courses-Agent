#### 5.5.3 一些简单无理式的不定积分

对于无理函数积分的基本方法就是通过适当的变量代换将其化为有理函数的积分.

(1) 形如  $ \int R\left(x,\sqrt[n]{\frac{ax+b}{cx+d}}\right)dx $ 的积分，其中  $ ad-bc \neq 0, R(u,v) $ 是由 u,v 与常数经过有限次四则运算所得到的有理式.

作变量代换  $ t^{n}=\frac{ax+b}{cx+d} $，则  $ x=\frac{dt^{n}-b}{a-ct^{n}} $， $ \mathrm{d}x=\frac{ad-bc}{(a-ct^{n})^{2}}nt^{n-1}\mathrm{d}t $，从而把原积分变换为一个有理函数的积分：

 $$ \int R\left(x,\sqrt[n]{a x+b\over c x+d}\right)\mathrm{d}x=\int R\left(\frac{d t^{n}-b}{a-e t^{n}},t\right)\cdot\frac{a d-b c}{(a-c t^{n})^{2}}n t^{n-1}\mathrm{d}t. $$ 

计算  $ I=\int\frac{\mathrm{d}x}{\sqrt[3]{(x-1)(x+1)^{2}}} $

解 令  $ t=\sqrt[3]{\frac{x+1}{x-1}} $，则  $ x=\frac{t^{3}+1}{t^{3}-1} $， $ \mathrm{d}x=\frac{-6t^{2}}{(t^{3}-1)^{2}}\mathrm{d}t $，于是

 $$ \begin{aligned}I=&\int\sqrt[3]{\frac{x+1}{x-1}}\ \frac{\mathrm{d}x}{x+1}=\int\frac{-3}{t^{3}-1}\mathrm{d}t=\int\left(\frac{-1}{t-1}+\frac{t+2}{t^{2}+t+1}\right)\mathrm{d}t\\=&-\ln\mid t-1\mid+\frac{1}{2}\ln\mid t^{2}+t+1\mid+\sqrt{3}\arctan\frac{2t+1}{\sqrt{3}}+C\\=&\frac{1}{2}\ln\frac{t^{3}-1}{(t-1)^{3}}+\sqrt{3}\arctan\frac{2t+1}{\sqrt{3}}+C\\=&\left.\frac{1}{2}\ln\mid x-1\mid-\frac{3}{2}\ln\left|\sqrt[3]{\frac{x+1}{x-1}}-1\right|\right.\\&\left.+\sqrt{3}\arctan\left[\frac{2}{\sqrt{3}}\left(\sqrt[3]{\frac{x+1}{x-1}}-\frac{1}{2}\right)\right]+C.\right.\end{aligned} $$ 

(2) 形如  $ \int R\left(x^{2}, \sqrt{ax^{2} + bx + c}\right) \, dx $ 的积分  $ (a \neq 0) $

这里主要考虑无理式积分，故可设  $ ax^{2} + bx + c $ 没有重零点。从而这个积分总可以化为下列三种情形之一：

①  $ \int R(x, \sqrt{(x+p)^2 + q^2}) \, dx; $

②  $ \int R(x, \sqrt{(x + p)^{2} - q^{2}}) \, dx; $

③  $ \int R(x, \sqrt{q^{2} - (x + p)^{2}}) \, dx. $