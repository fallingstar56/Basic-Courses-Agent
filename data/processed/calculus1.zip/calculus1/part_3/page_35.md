▶ 例 5.7.1

设平面区域 D 由曲线  $ y = x^{2} $ 及  $ x = y^{2} $ 围成，试求 D 的面积 S.

解 两曲线的交点为原点 $ (0,0) $与点 $ (1,1) $，所以

 $$ \begin{aligned}&\boldsymbol{S}=\int_{0}^{1}\sqrt{x}\mathrm{d}x-\int_{0}^{1}x^{2}\mathrm{d}x\\ &\quad=\int_{0}^{1}\left(\sqrt{x}-x^{2}\right)\mathrm{d}x=\frac{1}{3}.\\ \end{aligned} $$ 

如果平面区域 D 是由极坐标形式给出（见图 5.7.1）：

 $$ D=\left\{(\rho,\theta)\mid0\leqslant\rho\leqslant\rho(\theta),\alpha\leqslant\theta\leqslant\beta\right\} $$ 

其中  $ \rho(\theta) \in C[\alpha, \beta] $.  $ \forall \theta \in [\alpha, \beta] $，记  $ S(\theta) $ 为 D 中极角介于  $ \alpha $ 与  $ \theta $ 之间部分的面积，我们来计算  $ S(\theta) $ 的微分 ds.

<div style="text-align: center;"><img src="imgs/img_in_image_box_438_255_625_370.jpg" alt="Image" width="26%" /></div>


<div style="text-align: center;">图 5.7.1</div>


任取  $ \theta $ 的增量  $ \Delta\theta $ 充分小， $ \rho(\theta) $ 在区间  $ [\theta, \theta + $

$\Delta\theta]$ 上的上、下确界分别记为 $\tilde{M}$ 与 $\tilde{m}$，则 $\Delta S = S(\theta + \Delta\theta) - S(\theta)$ 应介于分别以 $\tilde{M}$ 与 $\tilde{m}$ 为半径、以 $\Delta\theta$ 为圆心角的两个扇形的面积之间。由于 $\rho(\theta) \in C[\alpha, \beta]$，这两个扇形的面积之差为

 $$ \frac{1}{2}(\widetilde{M}^{2}-\tilde{m}^{2})\Delta\theta=o(\Delta\theta)(\Delta\theta\rightarrow0). $$ 

从而 dS 可以表示为(将  $ \Delta\theta $ 记为  $ d\theta $):

 $$ \mathrm{d}S=S^{\prime}(\theta)\mathrm{d}\theta=\frac{1}{2}\rho(\theta)^{2}\mathrm{d}\theta. $$ 

由(1)式便可得到 D 的面积：

 $$ S=S(\beta)-S(\alpha)=\int_{a}^{\beta}S^{\prime}(\theta)\mathrm{d}\theta=\int_{a}^{\beta}\frac{1}{2}\rho(\theta)^{2}\mathrm{d}\theta. $$ 

这种方法通常称为“微元法”。

▶ 例 5.7.2 ……

求双纽线  $ \rho^{2}=2a^{2}\cos2\theta $ 所围成的区域 D（见图 5.7.2）的面积 S.

<div style="text-align: center;"><img src="imgs/img_in_image_box_243_757_480_886.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">图 5.7.2</div>
