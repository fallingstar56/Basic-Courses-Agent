解 显然 D 关于 x 轴与 y 轴都是对称的，并且 D 在第一象限中的部分为

 $$ D_{1}=\left\{(\rho,\theta)\mid0\leqslant\rho\leqslant\sqrt{2}a\sqrt{\cos2\theta},0\leqslant\theta\leqslant\frac{\pi}{2}\right\}. $$ 

所以所求面积为

 $$ S=4\int_{0}^{\frac{\pi}{4}}a^{2}\cos2\theta\mathrm{d}\theta=2a^{2}. $$ 

求心脏线  $ \rho = a(1 + \cos\theta) $ 所围成的区域 D（见图 5.7.3）的面积 S.

<div style="text-align: center;"><img src="imgs/img_in_image_box_294_288_438_421.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;">图 5.7.3</div>


解 显然 D 关于 x 轴对称，因此

 $$ \begin{aligned}&S=2\int_{0}^{\pi}\frac{1}{2}a^{2}(1+\cos\theta)^{2}\mathrm{d}\theta=a^{2}\int_{0}^{\pi}(1+2\cos\theta+\cos^{2}\theta)\mathrm{d}\theta\\&=\frac{1}{2}a^{2}\int_{0}^{\pi}(3+4\cos\theta+\cos2\theta)\mathrm{d}\theta=\frac{3}{2}\pi a^{2}.\\ \end{aligned} $$ 

#### 5.7.2 曲线的弧长问题

设 C 是由参数方程

 $$ x=x(t),\quad y=y(t)(a\leqslant t\leqslant b) $$ 

所确定的一条平面曲线（见图 5.7.4）。如果  $ x(t) $， $ y(t) $ 都是  $ [a,b] $ 上的连续函数，则称 C 是一条连续曲线。

如果  $ x(t), y(t) \in C^{1}[a, b] $，并且  $ x'(t)^{2} + y'(t)^{2} \neq 0 (t \in [a, b]) $，则称 C 是一条正则曲线或光滑曲线。在此条件下，我们应用“微元法”来计算 C 的弧长 L。

<div style="text-align: center;"><img src="imgs/img_in_image_box_465_697_632_795.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;">图 5.7.4</div>


 $ \forall t\in[a,b] $，令 $ l(t) $为曲线C对应于参数区间

[a,t]部分的弧长.任取t的增量 $ \Delta t>0 $，对应于参数区间 $ [a,b] $中点t与 $ t+\Delta t $，在曲线C上有对应点 $ M(x(t),y(t)) $与 $ M_{1}(x(t+\Delta t),y(t+\Delta t)) $.不难看出，当