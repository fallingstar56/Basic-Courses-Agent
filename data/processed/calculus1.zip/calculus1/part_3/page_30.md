▶ 例 5.6.8

计算  $ I=\int_{\frac{1}{e}}^{e}\left|\ln x\right|\mathrm{d}x. $

解 令  $ t=\ln x $，则  $ x=e^{t} $ 且  $ t\in[-1,1] $ 对应  $ x\in[1/e,e] $。因此

 $$ I=\int_{\frac{1}{e}}^{e}\mid\ln x\mid\mathrm{d}x=\int_{-1}^{1}\mid t\mid\mathrm{e}^{t}\mathrm{d}t=\int_{0}^{1}t\mathrm{e}^{t}\mathrm{d}t-\int_{-1}^{0}t\mathrm{e}^{t}\mathrm{d}t. $$ 

而

 $$ \int_{0}^{1}t\mathrm{e}^{t}\mathrm{d}t=t\mathrm{e}^{t}\left|_{0}^{1}\right.-\int_{0}^{1}\mathrm{e}^{t}\mathrm{d}t=t\mathrm{e}^{t}\left|_{0}^{1}\right.-\mathrm{e}^{t}\left|_{0}^{1}\right.=1; $$ 

 $$ \int_{-1}^{0}t\mathrm{e}^{\prime}\mathrm{d}t=t\mathrm{e}^{\prime}\mid_{-1}^{0}-\int_{-1}^{0}t\mathrm{e}^{\prime}\mathrm{d}t=t\mathrm{e}^{\prime}\mid_{-1}^{0}-\mathrm{e}^{\prime}\mid_{-1}^{0}=-1+\frac{\mathrm{e}}{2}. $$ 

所以  $ I=2-\frac{2}{e} $

▶ 例 5.6.9 ……

计算  $ I=\int_{0}^{\frac{1}{2}}\arcsin x dx. $

解法一 用分部积分法，

 $$ \begin{aligned}&I=x\arcsin x\left|_{0}^{\frac{1}{2}}\right.-\int_{0}^{\frac{1}{2}}\frac{x\mathrm{d}x}{\sqrt{1-x^{2}}}\\&=\frac{\pi}{12}+\sqrt{1-x^{2}}\left|_{0}^{\frac{1}{2}}\right.\\&=\frac{\pi}{12}+\frac{\sqrt{3}}{2}-1.\\ \end{aligned} $$ 

解法二 令  $ t=\arcsin x $，则  $ \mathrm{d}x=\cos t\mathrm{d}t,t\in\left[0,\frac{\pi}{6}\right] $ 对应  $ x\in\left[0,\frac{1}{2}\right] $. 所以

 $$ I=\int_{0}^{\pi/6}t\mathrm{c o s t}\mathrm{d}t=t\mathrm{s i n t}\mid_{0}^{\pi/6}-\int_{0}^{\pi/6}\mathrm{s i n t}\mathrm{d}t=\frac{\pi}{12}+\frac{\sqrt{3}}{2}-1. $$ 

▶ 例 5.6.10 ……

求证：

 $$ \int_{0}^{\frac{\pi}{2}}\sin^{n}x\mathrm{d}x=\int_{0}^{\frac{\pi}{2}}\cos^{n}x\mathrm{d}x\quad(n\in\mathbb{N}); $$ 

并求其值 $ I_{n} $

证明 令  $ x=\frac{\pi}{2}-t $，则有

 $$ \int_{0}^{\frac{\pi}{2}}\sin^{n}x\mathrm{d}x=-\int_{\frac{\pi}{2}}^{0}\sin^{n}\left(\frac{\pi}{2}-t\right)\mathrm{d}t=-\int_{\frac{\pi}{2}}^{0}\cos^{n}t\mathrm{d}t=\int_{0}^{\frac{\pi}{2}}\cos^{n}t\mathrm{d}t. $$ 

为计算  $ I_{n}=\int_{0}^{\frac{\pi}{2}}\sin^{n}x\,dx $ 的值，使用分部积分法，