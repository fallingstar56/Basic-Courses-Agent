### 5.5 有理函数与三角有理函数的不定积分

#### 5.5.1 有理函数的不定积分

设  $ p(x) $ 与  $ q(x) $ 是两个多项式，形如  $ R(x)=\frac{p(x)}{q(x)} $ 的函数称为有理函数。当  $ p(x) $ 的次数小于  $ q(x) $ 的次数时，称  $ R(x) $ 为真分式，否则称  $ R(x) $ 为假分式。我们知道，通过多项式除法可以将任一个有理函数表示为一个多项式与一个真分式之和。所以求一个有理函数的不定积分可以归结为求一个真分式的不定积分问题。

又由代数理论知道，任一个真分式都可以分解为下列四种基本分式之和：

 $$ \frac{A}{x-a},\frac{A}{(x-a)^{k}},\frac{Ax+B}{(x+a)^{2}+b^{2}},\frac{Ax+B}{((x+a)^{2}+b^{2})^{k}}(k\geqslant2). $$ 

具体地讲，设  $ R(x)=\frac{p(x)}{q(x)} $ 是一个真分式，其中  $ p(x) $ 与  $ q(x) $ 没有共同的零点，且分母  $ q(x) $ 可以分解为

 $$ q(x)=\prod_{i=1}^{m}\left(x-\alpha_{i}\right)^{l_{i}}\bullet\prod_{j=1}^{n}\left[(x+a_{j})^{2}+b_{j}^{2}\right]^{k_{j}}, $$ 

则  $ R(x) $ 可以分解为

 $$ \begin{aligned}R(x)=&\sum_{i=1}^{m}\Big[\frac{\lambda_{i l}}{x-\alpha_{i}}+\frac{\lambda_{i2}}{(x-\alpha_{i})^{2}}+\cdots+\frac{\lambda_{i i}}{(x-\alpha_{i})^{l_{i}}}\Big]\\&+\sum_{j=1}^{n}\Big[\frac{A_{j1}x+B_{j1}}{(x+a_{j})^{2}+b_{j}^{2}}+\frac{A_{j2}x+B_{j2}}{((x+a_{j})^{2}+b_{j}^{2})^{2}}+\cdots\\&+\frac{A_{j k_{j}}x+B_{j k_{j}}}{(((x+a_{j})^{2}+b_{j}^{2})^{k_{j}}}\Big].\end{aligned} $$ 

在实际计算中，通常先假设  $ R(x) $ 具有形如（3）式的分解式，其中每个  $ \lambda_{ij} $ 与  $ A_{ij} $， $ B_{ij} $ 都是待定常数。将（3）式的右端通分，其分母即为  $ q(x) $，从而两端的分子相等。再比较系数便可求出这些待定常数。

根据(3)式，欲求真分式  $ R(x)=\frac{p(x)}{q(x)} $ 的不定积分，只需求(1)式中的四种基本分式的不定积分即可。它们可以分别计算如下：

 $$ \begin{aligned}&\int\frac{\mathrm{d}x}{x-a}=\ln|x-a|+C;\\ &\int\frac{\mathrm{d}x}{(x-a)^{k}}=-\frac{1}{k-1}\frac{1}{(x-a)^{k-1}}+C(k\geqslant2);\\ &\int\frac{x+a}{\left\lbrack(x+a)^{2}+b^{2}\right\rbrack^{k}}\mathrm{d}x=\frac{-1}{2(k-1)\left\lbrack(x+a)^{2}+b^{2}\right\rbrack^{k-1}}+C(k\geqslant1).\\ \end{aligned} $$ 