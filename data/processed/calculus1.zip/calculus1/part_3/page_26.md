(3) $ \int\frac{x^{3}+1}{x^{3}-5x^{2}+6x}dx. $

(4) $ \int\frac{1}{x^{4}-1}dx; $

(5) $ \int\frac{x^{4}}{x^{4}+5x^{2}+4}dx; $

(6) $ \int\frac{1}{1+x^{3}}\mathrm{d}x; $

(7) $ \int\frac{x^{7}}{(1-x^{2})^{5}}\mathrm{d}x; $

(8) $ \int\frac{1}{x^{4}(2x^{2}-1)}\mathrm{d}x. $

2. 求下列不定积分.

(1)  $ \int \frac{\sin^{4}x}{\cos^{3}x} dx $;

(2) $ \int\frac{1}{\sin x\cos^{4}x}dx; $

(3) $ \int\frac{\sin^{2}x}{1+\sin^{2}x}dx. $

(4)  $ \int \frac{1 + \tan x}{\sin 2x} dx $;

(5)  $ \int \frac{1 - \tan x}{1 + \tan x} \, dx $;

(6)  $ \int \frac{1}{(2 + \cos x) \sin x} \, dx $;

(7)  $ \int \frac{\sin x}{\sin x + \cos x} \, dx $;

(8)  $ \int \frac{1}{5 + 4 \sin x} \, dx $;

(9)  $ \int \frac{\cos x}{\sin x + \cos x} \, dx $;

(10)  $ \int \frac{\sin x \cos^3 x}{1 + \cos^2 x} \, dx. $

3. 求下列不定积分.

(1) $ \int\frac{1}{\sqrt{x}\left(\sqrt{x}+\sqrt[3]{x}\right)}\mathrm{d}x; $

(2) $ \int\frac{\sqrt{x+1}-\sqrt{x-1}}{\sqrt{x+1}+\sqrt{x-1}}\mathrm{d}x; $

(3) $ \int x\sqrt{x+2}dx; $

(4) $ \int x^{2}\sqrt{1-x^{2}}dx; $

(5) $ \int x\sqrt{x^{4}+2x^{2}-1}dx; $

(6) $ \int x\sqrt{\frac{1+x}{1-x}}dx; $

(7)  $ \int \sqrt{\frac{a - x}{x - b}} \, dx $;

(8) $ \int\frac{1-x+x^{2}}{\sqrt{1+x-x^{2}}}dx; $

(9) $ \int\frac{1}{\sqrt{(a^{2}-x^{2})^{3}}}\mathrm{d}x. $

4. 求下列不定积分.

(1)  $ \int \frac{\sqrt{1 + \cos x}}{\sin x} \, dx $;

(2) $ \int\sqrt{1+\csc x}dx; $

(3) $ \int\frac{x}{1-\cos x}dx; $

(4)  $ \int \frac{\arctan \sqrt{x}}{\sqrt{x}(1 + x)} \, dx $;

(5)  $ \int \frac{1 - \ln x}{\ln^2 x} dx $;

(6)  $ \int \frac{1 + \sin x}{1 + \cos x} e^x \, dx $;

(7) $ \int\frac{x^{2}-1}{x^{4}+1}dx; $

(8)  $ \int \frac{x \ln x}{(x^{2} + 1)^{2}} \mathrm{d}x; $