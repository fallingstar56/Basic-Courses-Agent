计算 $ \int\frac{\mathrm{d}x}{\mathrm{e}^{x}+1} $

解  $ u=e^{x}+1 $，则  $ x=\ln(u-1) $， $ dx=\frac{du}{u-1} $。于是

 $$ \begin{aligned}\int\frac{\mathrm{d}x}{\mathrm{e}^{x}+1}&=\int\frac{\mathrm{d}u}{u\left(u-1\right)}=\int\Big(\frac{1}{u-1}-\frac{1}{u}\Big)\mathrm{d}u\\&=\ln\mid u-1\mid-\ln\mid u\mid+C=x-\ln(\mathrm{e}^{x}+1)+C.\end{aligned} $$ 

注 本题也可以用凑微分法：

 $$ \int\frac{\mathrm{d}x}{\mathrm{e}^{x}+1}=\int\frac{\mathrm{e}^{-x}\mathrm{d}x}{1+\mathrm{e}^{-x}}=-\int\frac{(1+\mathrm{e}^{-x})^{\prime}\mathrm{d}x}{1+\mathrm{e}^{-x}}=-\ln(1+\mathrm{e}^{-x})+C. $$ 

#### 5.4.3 分部积分法

设  $ u(x) $ 与  $ v(x) $ 在区间 I 上有连续的导数，则根据函数乘积求导公式，有

 $$ \left[u(x)v(x)\right]^{\prime}=u(x)v^{\prime}(x)+v(x)u^{\prime}(x), $$ 

于是

 $$ \int u(x)v^{\prime}(x)\mathrm{d}x+\int v(x)u^{\prime}(x)\mathrm{d}x=\int\left[u(x)v(x)\right]^{\prime}\mathrm{d}x, $$ 

也就是

 $$ \int u(x)v^{^{\prime}}(x)\mathrm{d}x=u(x)v(x)-\int v(x)u^{^{\prime}}(x)\mathrm{d}x. $$ 

这种方法称为分部积分法，是一种简便且很有用的积分方法，在很多积分问题中都需要应用这种方法。

▶ 例 5.4.14

计算 $ \int x\cos xdx. $

解 令  $ u(x)=x, v(x)=\sin x $，则  $ v'(x)=\cos x $。应用分部积分法可得

 $$ \int x\cos x\mathrm{d}x=x\sin x-\int\sin x\mathrm{d}x=x\sin x+\cos x+C. $$ 

#### ▶ 例 5.4.15

计算 $ \int\ln x dx. $

解 令  $ u(x)=\ln x, v(x)=x $，则  $ v'(x)=1 $。于是

 $$ \int\ln x\mathrm{d}x=x\ln x-\int x\cdot\frac{1}{x}\mathrm{d}x=x\ln x-x+C. $$ 