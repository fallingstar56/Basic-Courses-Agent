 $$ \begin{aligned}\int_{a}^{a+2\pi}\sin kx\cdot\sin nx\mathrm{d}x&=\int_{a}^{a+2\pi}\frac{1}{2}\big[\cos(k-n)x-\cos(k+n)x\big]\mathrm{d}x\\&=\frac{1}{2(k-n)}\sin(k-n)x\bigg|_{a}^{a+2\pi}-\frac{1}{2(k+n)}\sin(k-n)x\bigg|_{a}^{a+2\pi}\\&=0.\end{aligned} $$ 

同理可得(5)成立.

▶ 例 5.3.5 .....

令  $ \sigma_{n}=\frac{1}{n+1}+\frac{1}{n+2}+\cdots+\frac{1}{n+n} $，求极限  $ \lim_{n\to\infty}\sigma_{n} $

解  $ \sigma_{n}=\frac{1}{n}\left(\frac{1}{1+\frac{1}{n}}+\frac{1}{1+\frac{2}{n}}+\cdots+\frac{1}{1+\frac{n}{n}}\right) $

 $ \sigma_{n} $ 可看作函数  $ \frac{1}{1+x} $ 在区间  $ [0,1] $ 上关于 n 等分分割的一个黎曼和. 而积分  $ \int_{0}^{1}\frac{dx}{1+x} $ 存在，且  $ \ln(1+x) $ 是  $ \frac{1}{1+x} $ 的一个原函数，所以

 $$ \lim_{n\to\infty}\sigma_{n}=\int_{0}^{1}\frac{\mathrm{d}x}{1+x}=\ln(1+x)\mid_{0}^{1}=\ln2. $$ 

### 习题 5.3

1. 求下列函数的导函数.

 $$ (1)F(x)=\int_{0}^{x}\sqrt{1-t}\mathrm{d}t(x\leqslant1);\qquad\quad(2)F(x)=\int_{x}^{1}\sqrt{1+t^{2}}\mathrm{d}t; $$ 

 $$ (3)F(x)=\int_{0}^{x^{2}}\ln(2+t)\mathrm{d}t;\quad(4)F(x)=\int_{\sqrt{x}}^{x^{2}}\mathrm{e}^{-t^{2}}\mathrm{d}t; $$ 

(5)  $  F(x) = \int_{0}^{\arctan x} \tan t \, dt  $;

(6) $ F(x)=\int_{0}^{x}f(t)dt(0\leqslant x\leqslant2) $，其中 $ f(x)=\left\{\begin{aligned}&2x,&x\in[0,1),\\ &1,&x\in[1,2].\end{aligned}\right. $

2. 函数  $ y = y(x) $ 由方程  $ \int_{0}^{y} e^{-t^{2}} dt + \int_{0}^{x} \cos t^{2} dt = 0 $ 确定，求  $ y'(x) $.

3. 曲线  $ y = y(x) $ 由方程  $ x = \int_{1}^{t} \frac{\cos u}{u} \, du, y = \int_{1}^{t} \frac{\sin u}{u} \, du $ 确定，求该曲线当  $ t = \frac{\pi}{4} $ 时的斜率.

4. 设  $  f(x) \in C[0, +\infty)  $，已知  $ \int_{0}^{\sqrt{x}} f(t) dt = x + \sin x $，求  $  f(x)  $.