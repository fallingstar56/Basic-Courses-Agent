 $$ \int f^{\prime}(\varphi(x))\varphi^{\prime}(x)\mathrm{d}x=\int f^{\prime}(u)\mathrm{d}u=f(u)+C=f(\varphi(x))+C. $$ 

这种方法称为第一换元法，或“凑微分法”。

反之，欲求 $ \int f'(u)du $，也可以作变换 $ u=\varphi(x) $，将 $ \int f'(u)du $变换为 $ \int f'(\varphi(x))\varphi'(x)dx $，求出结果后再把 $ x=\varphi^{-1}(u) $代入（这里要求 $ \varphi(x) $严格单调且有连续导数）：

 $$ \int f^{\prime}(u)\mathrm{d}u=\int f^{\prime}(\varphi(x))\varphi^{\prime}(x)\mathrm{d}x=g(x)+C=g(\varphi^{-1}(u))+C. $$ 

这种方法称为第二换元法.

换元积分法的关键是选取适当的变换  $ u=\varphi(x) $. 下面分别举例说明这两种换元法.

▶ 例 5.4.5

计算 $ \int2xe^{x^{2}}dx. $

解 令  $ u = x^{2} $，则 du = 2xdx，于是

 $$ \int2x\mathrm{e}^{x^{2}}\mathrm{d}x=\int\mathrm{e}^{u}\mathrm{d}u=\mathrm{e}^{u}+c=\mathrm{e}^{x^{2}}+C. $$ 

▶ 例 5.4.6

计算 $ \int\cot xdx. $

解 令  $ u = \sin x, du = \cos x dx $，应用凑微分法，

 $$ \int\cot x\mathrm{d}x=\int\frac{\cos x}{\sin x}\mathrm{d}x=\int\frac{\mathrm{d}u}{u}=\ln|u|+C=\ln|\sin x|+C. $$ 

同理可得

 $$ \int\tan x\mathrm{d}x=-\ln|\cos x|+C. $$ 

▶ 例 5.4.7

计算 $ \int\frac{\mathrm{d}x}{\sqrt{a^{2}-x^{2}}} $

解  $ \int\frac{\mathrm{d}x}{\sqrt{a^{2}-x^{2}}}=\int\frac{\mathrm{d}\left(\frac{x}{a}\right)}{\sqrt{1-\left(\frac{x}{a}\right)^{2}}}=\arcsin\frac{x}{a}+C. $

#### ▶ 例 5.4.8

计算 $ \int\sec xdx. $