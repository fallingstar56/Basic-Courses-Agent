 $$ \bar{y}=\frac{1}{m}\int_{a}^{b}y(t)\rho(t)\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}}\mathrm{d}t. $$ 

这种方法也常称为“微元法”。

#### ▶ 例 5.7.16

设 f 是  $ [-a, a] $ 上非负连续的偶函数， $ D = \{(x, y) \mid |x| \leqslant a, 0 \leqslant y \leqslant f(x)\} $。求 D 的形心坐标（即面密度  $ \rho \equiv 1 $ 时的重心坐标） $ (\bar{x}, \bar{y}) $。

解 由 D 的对称性知道, $ \bar{x}=0 $. D 的面积为  $ \sigma=\int_{-a}^{a}f(x)\mathrm{d}x $. 为求  $ \bar{y} $, 任取

 $ x \in [-a, a] $，及“很小的”增量  $ \Delta x, D $ 中对应的细长形区域  $ \{(t, y) \mid x \leqslant t \leqslant x + \Delta x, 0 \leqslant y \leqslant f(x)\} $ 可看作质量集中在  $ \left(x, \frac{1}{2}f(x)\right) $ 点，质量为  $ f(x) \cdot \Delta x $ 的质点（见图 5.7.9）。于是

<div style="text-align: center;"><img src="imgs/img_in_image_box_451_280_627_387.jpg" alt="Image" width="24%" /></div>


 $$ \bar{y}=\frac{1}{\sigma}\int_{-a}^{a}\frac{1}{2}f(x)\cdot f(x)\mathrm{d}x=\frac{1}{2\sigma}\int_{-a}^{a}f\left(x\right)^{2}\mathrm{d}x $$ 

<div style="text-align: center;">图 5.7.9</div>


所以，D的形心坐标 $ \left(\bar{x},\bar{y}\right)=\left(0,\frac{1}{2\sigma}\int_{-a}^{a}f\left(x\right)^{2}\mathrm{d}x\right) $，其中

 $$ \sigma=\int_{-a}^{a}f(x)\mathrm{d}x. $$ 

#### ▶ 例 5.7.17

设有长度为 l 的细杆一端有转轴垂直于细杆。细杆的线密度为  $ \rho $。求细杆绕转轴转动的转动惯量（不计转轴直径）。

解 由物理学中知道, 质量为 m 的质点绕一转轴转动的转动惯量为  $ J = mr^{2} $, 其中 r 为质点到转轴的距离.

取细杆与转轴的交点为原点，细杆所在直线为 x 轴，则细杆所在的区间为  $ [0, l] $. 细杆的线密度可表示为  $ \rho(x) $（可以是变密度）. 任取  $ x \in [0, l] $ 及 x 的增量  $ \Delta x $，位于  $ [x, x + \Delta x] $ 上的一小段细杆可以看作一个质点，其质量为  $ \rho(x) \Delta x $，且与转轴的距离为 x. 于是这一小段细杆绕转轴的转动惯量为

 $$ \Delta J\approx x^{2}\rho(x)\Delta x, $$ 

从而细杆绕转轴的转动惯量为

 $$ J=\int_{_{0}}^{l}\mathrm{d}J=\int_{_{0}}^{l}x^{2}\rho(x)\mathrm{d}x, $$ 

#### ▶ 例 5.7.18

设有质量均匀分布的细杆，长度为 l，质量为 M。在细杆的延长线上，与细杆距离为 a 处有一质量为 m 的质点 P。求细杆对质点 P 的引力。

解 将坐标原点取在质点 P 处，细杆所在直线为 x 轴，则细杆所在区间为