(13) $ \int_{0}^{\frac{\pi}{4}}\frac{1}{1+\cos^{2}x}dx; $

(14) $ \int_{0}^{\ln2}\sqrt{1+e^{x}}dx; $

(15) $ \int_{0}^{1}\sqrt{2x+x^{2}}dx. $

2. 求下列定积分.

(1) $ \int_{0}^{\pi}(1-2x)\sin x\,dx $;

(2) $ \int_{0}^{1}x^{2}e^{-2x}dx; $

(3) $ \int_{0}^{\frac{\pi}{2}}x\cos^{2}x\,dx $;

(4) $ \int_{0}^{\sqrt{3}}x\arctan x\,dx $;

(5) $ \int_{0}^{\frac{\pi}{4}}e^{-x}\sin2x\,dx $;

(6) $ \int_{e^{-1}}^{e}\left|\ln x\right|dx; $

(7) $ \int_{0}^{1}x\tan^{2}x\mathrm{d}x; $

(8) $ \int_{0}^{\frac{\pi}{2}}e^{2x}\sin^{2}xdx. $

3. 求下列定积分.

(1) $ \int_{0}^{\frac{\pi}{2}}\sin^{4}x\,dx $;

(2) $ \int_{0}^{\pi}\sin^{5}x\,dx; $

(3) $ \int_{0}^{\pi}\cos^{6}x\,dx $;

(4) $ \int_{0}^{\pi}\cos^{7}x\,dx $;

(5) $ \int_{0}^{\pi}\sin^{2}x\cos^{4}xdx; $

(6) $ \int_{-\frac{\pi}{4}}^{\frac{\pi}{4}}\sin^{4}2x\mathrm{d}x; $

(7) $ \int_{-a}^{a}(1-x)^{2}\sqrt{a^{2}-x^{2}}dx; $

(8) $ \int_{-a}^{a}(1-x)\sqrt{a^{2}-x^{2}}dx; $

(9) $ \int_{0}^{2a}x\sqrt{a^{2}-(x-a)^{2}}dx. $

4. 设  $ f(x) $ 为连续函数，证明：

(1) 若  $ f(x) $ 为奇函数，则  $ \int_{0}^{x} f(x) \, dx $ 为偶函数；

(2) 若  $ f(x) $ 为偶函数，则  $ \int_{0}^{x} f(x) \, dx $ 为奇函数；

(3) 奇函数所有的原函数均为偶函数；偶函数的原函数中只有一个是奇函数.

5. 设  $ f(x) $ 为连续函数，证明： $ \int_{0}^{\pi}xf(\sin x)dx=\frac{\pi}{2}\int_{0}^{\pi}f(\sin x)dx. $

6. 设  $ f(x) $ 为连续函数，且关于直线  $ x=l(a<l<b) $ 对称，证明：

 $$ \int_{a}^{b}f(x)\mathrm{d}x=2\int_{l}^{b}f(x)\mathrm{d}x+\int_{a}^{2l-b}f(x)\mathrm{d}x. $$ 

7. 设  $ f(x) $ 为连续函数，证明： $ \int_{0}^{x}(x-t)f(t)dt=\int_{0}^{x}\left[\int_{0}^{t}f(s)ds\right]dt. $

8. 计算积分： $ \int_{0}^{1}xf(x)dx $，其中  $ f(x)=\int_{1}^{x^{2}}e^{-t^{2}}dt. $