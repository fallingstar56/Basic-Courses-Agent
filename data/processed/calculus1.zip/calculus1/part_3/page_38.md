如果曲线 C 由方程

 $$ y=f(x)(a\leqslant x\leqslant b) $$ 

给出，其中  $ f \in C^{1}[a, b] $，可取 x 作为参数，C 的方程变为

 $$ x=x,\quad y=f(x)(a\leqslant x\leqslant b). $$ 

根据公式(4)，曲线 C 的弧长为

 $$ L=\int_{a}^{b}\sqrt{1+f^{^{\prime}}(x)^{2}}\mathrm{d}x. $$ 

如果曲线 C 由极坐标形给出：

 $$ \rho=\rho(\theta)(\alpha\leqslant\theta\leqslant\beta), $$ 

其中  $ \rho(\theta) \in C^{1}[\alpha, \beta] $，此时 C 的方程可写作

 $$ x=\rho(\theta)\cos\theta,\quad y=\rho(\theta)\sin\theta(\alpha\leqslant\theta\leqslant\beta), $$ 

因此曲线 C 的弧微分为

 $$ \mathrm{d}l=\sqrt{(\rho(\theta))^{2}+(\rho^{\prime}(\theta))^{2}}\mathrm{d}\theta. $$ 

进而知曲线 C 的弧长为

 $$ L=\int_{a}^{\beta}\sqrt{\rho^{2}(\theta)+\rho^{^{\prime}}(\theta)^{2}}\mathrm{d}\theta. $$ 

▶ 例 5.7.6 ……

求心脏线  $ \rho=a(1+\cos\theta),-\pi\leqslant\theta\leqslant\pi,(a>0) $ 的弧长 L.

解 由公式 $  (6)  $,

 $$ L=\int_{0}^{2\pi}\sqrt{\rho(\theta)^{2}+\rho^{^{\prime}}(\theta)^{2}}\mathrm{d}\theta=2a\int_{-\pi}^{\pi}\cos\frac{\theta}{2}\mathrm{d}\theta=8a. $$ 

如果 C 是一条光滑的空间曲线：

 $$ x=x(t),\quad y=y(t),\quad z=z(t)(a\leqslant t\leqslant b), $$ 

其中  $ x(t), y(t), z(t) \in C^{1}[a, b] $ 且  $ x'(t)^{2} + y'(t)^{2} + z'(t)^{2} \neq 0 (t \in [a, b]) $. 与平面曲线的情形类似地可得，C 的弧微分为

 $$ \mathrm{d}l=\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}+z^{\prime}(t)^{2}}\mathrm{d}t, $$ 

C 的弧长为

 $$ L=\int_{a}^{b}\sqrt{x^{^{\prime}}(t)^{2}+y^{^{\prime}}(t)^{2}+z^{^{\prime}}(t)^{2}}\mathrm{d}t. $$ 

求空间螺线  $ x = a \cos t $,  $ y = a \sin t $,  $ z = c t (a > 0, c > 0) $ 第一圈  $ (0 \leqslant t \leqslant 2\pi) $ 的弧长.

解 由公式 $  (8)  $

 $$ S=\int_{0}^{2\pi}\sqrt{x^{^{\prime}}(t)^{2}+y^{^{\prime}}(t)^{2}+z^{^{\prime}}(t)^{2}}\mathrm{d}t=2\pi\sqrt{a^{2}+c^{2}}. $$ 