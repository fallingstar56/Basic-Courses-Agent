4. 设  $ f(x) \in C[a, b] $，若  $ \forall g(x) \in C[a, b] $，均有  $ \int_{a}^{b} f(x) g(x) \, dx = 0 $，则  $ f(x) $ 恒为零.

5. 比较下列积分的大小.

(1) $ \int_{0}^{1}e^{-x}dx $ 和  $ \int_{0}^{1}e^{-x^{2}}dx $;

(2) $ \int_{0}^{1}\frac{\sin x}{2+x}dx $ 和  $ \int_{0}^{1}\frac{\sin x}{2+x^{2}}dx $;

(3) $ \int_{0}^{1}x\,dx $ 和  $ \int_{0}^{1}x^{2}\,dx $;

(4) $ \int_{0}^{\frac{\pi}{2}}x\,dx $ 和  $ \int_{0}^{\frac{\pi}{2}}\sin x\,dx $.

6. 证明下列不等式.

(1)  $ \frac{1}{2} \leqslant \int_{\frac{\pi}{4}}^{\frac{\pi}{2}} \frac{\sin x}{x} dx \leqslant \frac{\pi}{4} $;

(2)  $ \frac{2}{5} \leqslant \int_{1}^{2} \frac{x}{1 + x^{2}} dx \leqslant \frac{1}{2} $;

(3)  $ \int_{0}^{2\pi} | a \cos x + b \sin x | dx \leqslant 2\pi \sqrt{a^{2} + b^{2}} $.

7. 证明下列极限.

(1)  $ \lim_{n\to\infty}\int_{0}^{1}\frac{x^{n}}{1+x}dx=0;\quad(2)\lim_{n\to\infty}\int_{0}^{1}\frac{dx}{1+x^{n}}=1;\quad(3)\lim_{n\to\infty}\int_{0}^{\frac{\pi}{2}}\sin^{n}x dx=0. $

（提示：不可以直接对被积函数利用积分中值定理，请思考其中的原因。）

8. 证明：若  $ f(x), g(x) \in R[a, b] $，则  $ \min\{f(x), g(x)\}, \max\{f(x), g(x)\} \in R[a, b] $.

9. 如果  $ f(x) $ 在  $ [a,b] $ 上连续且  $ f(x)>0 $，证明： $ \left(\int_{a}^{b}f(x)dx\right)\left(\int_{a}^{b}\frac{1}{f(x)}dx\right)\geqslant $  $ (b-a)^{2} $.

10. 设  $ f(x) $ 在  $ [a,b] $ 上严格单增，且  $ f''(x)>0 $，证明：

 $$ (b-a)f(a)<\int_{a}^{b}f(x)\mathrm{d}x<(b-a)\frac{f(a)+f(b)}{2}. $$ 

### 5.3 微积分基本定理

在微积分发展的早期，导数与积分是作为相互独立的对象被加以研究的。牛顿和莱布尼茨通过对于变上限积分的研究发现了这两者之间可以通过“牛顿-莱布尼茨公式”作为桥梁建立起紧密的联系。同时，牛顿-莱布尼茨公式还给出了定积分的计算方法。鉴于这个公式在微积分学中的重要地位，通常被称为微积分基本定理。下面首先引入原函数的概念。

设函数 f 在区间 I 上定义，称函数 F 是 f 在区间 I 上的一个原函数，如果  $ \forall x \in I $，有