从而  $ V(t) $ 的微分

 $$ \mathrm{d}V(t)=2\pi t f(t)\mathrm{d}t. $$ 

由此知

 $$ V=V(a)-V(0)=\int_{0}^{a}2\pi x f(x)\mathrm{d}x $$ 

#### 5.7.5 旋转曲面的面积

设  $ C: x = x(t), y = y(t), a \leqslant t \leqslant b $ 是一条光滑的参数曲线，将曲线 C 绕 x 轴旋转一周得到一个旋转曲面  $ \Sigma $（参见图 5.7.8），下面计算  $ \Sigma $ 的面积.

任取  $ t \in [a, b] $，令  $ S(t) $ 为曲线 C 上对应于参数区间  $ [a, t] $ 的部分绕 x 轴旋转一周所得到的旋转面面积。任给 t 的增量  $ \Delta t > 0 $，记曲线 C 上对应于参数区间  $ [t, t + \Delta t] $ 的小弧段为  $ \sigma $，则  $ \Delta S = S(t + \Delta t) - S(t) $ 是  $ \sigma $ 绕 x 轴旋转一周所得到的曲面面积。根据弧长公式 (4)， $ \sigma $ 的弧长为

 $$ \begin{align*}\mid\sigma\mid&=\int_{t}^{t+\Delta t}\sqrt{x^{^{\prime}}(u)^{2}+y^{^{\prime}}(u)^{2}}\mathrm{d}u\\&=\Delta t\sqrt{x^{^{\prime}}(t)^{2}+y^{^{\prime}}(t)^{2}}+o(\Delta t)(\Delta t\rightarrow0).\end{align*} $$ 

若记  $ |y(t)| $ 在区间  $ [t, t + \Delta t] $ 上的上、下确界分别为  $ \widetilde{M} $ 与  $ \widetilde{m} $，则  $ \Delta S $ 应介于  $ 2\pi \widetilde{m} |\sigma| $ 与  $ 2\pi \widetilde{M} |\sigma| $ 之间。由 (12) 式以及  $ x(t), y(t) \in C^{1}[a, b] $ 可得当  $ \Delta t \to 0 $ 时，

 $$ \begin{align*}2\pi\widetilde{M}\mid\sigma\mid&=2\pi\mid y(t)\mid\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}}\Delta t+o(\Delta t),\\2\pi\widetilde{m}\mid\sigma\mid&=2\pi\mid y(t)\mid\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}}\Delta t+o(\Delta t).\end{align*} $$ 

从而  $ S(t) $ 的微分

 $$ \mathrm{d}s(t)=2\pi\mid y(t)\mid\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}}\mathrm{d}t. $$ 

由此知  $ \Sigma $ 的面积为

 $$ S=2\pi\int_{a}^{b}\mid y(t)\mid\mathrm{d}l=2\pi\int_{a}^{b}\mid y(t)\mid\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}}\mathrm{d}t. $$ 

▶ 例 5.7.13 ……

求心脏线  $ r=a(1+\cos\theta)(a>0,0\leqslant\theta\leqslant2\pi) $ 绕 x 轴旋转一周所得到旋转面面积.

解 由心脏线的对称性，只需考虑  $ 0 \leqslant \theta \leqslant \pi $.

 $$ y=r\sin\theta=a(1+\cos\theta)\sin\theta. $$ 

再由公式(5)，弧微分为

 $$ \mathrm{d}l=\sqrt{r(\theta)^{2}+r^{\prime}(\theta)^{2}}\mathrm{d}\theta=2a\cos\frac{\theta}{2}\mathrm{d}\theta. $$ 

于是由公式 $  (13)  $即得所求旋转面面积为