 $$ F^{\prime}(x)=f(x). $$ 

例如， $ f(x)=x $ 在  $ \mathbb{R} $ 上的一个原函数是  $ F(x)=x^{2}/2,\cos x $ 在  $ \mathbb{R} $ 上的一个原函数是  $ \sin x,\frac{1}{x} $ 在  $ (0,+\infty) $ 与  $ (-∞,0) $ 上一个原函数是  $ \ln|x| $. 显然，求原函数是求导数的逆运算.

#### 定理 5.3.1（微积分基本定理）

设  $ f \in R[a, b] $，令

 $$ F(x)=\int_{a}^{x}f(t)\mathrm{d}t(a\leqslant x\leqslant b), $$ 

则(1) $ F\in C[a,b] $;

(2) 若  $ f $ 在点  $ x_0 \in [a, b] $ 处连续，则  $ F $ 在点  $ x_0 $ 处可导，并且  $ F'(x_0) = f(x_0) $;

(3) 若  $ f \in C[a, b] $，则 F 是 f 在  $ [a, b] $ 上的一个原函数。如果 G 是 f 的任一个原函数，则有

 $$ \int_{a}^{b}f(x)\mathrm{d}x=G(b)-G(a). $$ 

公式(1)通常被称为牛顿-莱布尼茨公式.它给出了利用被积函数的原函数来计算定积分的基本方法.

证明 (1) $ f\in R[a,b] $，故 f 在  $ [a,b] $ 上有界： $ \left|f(x)\right|\leqslant M(a\leqslant x\leqslant b) $。任取  $ x_{0}\in[a,b] $，当  $ x\in[a,b] $ 时，

 $$ \begin{aligned}\mid F(x)-F(x_{0})\mid&=\left|\int_{a}^{x}f(t)\mathrm{d}t-\int_{a}^{x_{0}}f(t)\mathrm{d}t\right|\\&=\left|\int_{x_{0}}^{x}f(t)\mathrm{d}t\right|\leqslant M\left|\int_{x_{0}}^{x}\mathrm{d}x\right|\\&=M\mid x-x_{0}\mid.\end{aligned} $$ 

由此不难看到 F 在点  $ x_{0} $ 处连续，由  $ x_{0} $ 的任意性便知  $ F \in C[a, b] $.

(2) 现设  $ x_{0} $ 是 f 的连续点，则  $ \forall \varepsilon > 0, \exists \delta > 0 $，只要  $ t \in [a, b] $ 且  $ |t - x_{0}| < \delta $，就有

 $$ \mid f(t)-f(x_{0})\mid<\varepsilon. $$ 

于是，当  $ x \in [a, b] $ 且  $ |x - x_{0}| < \delta $ 时，

 $$ \begin{aligned}\left|\frac{F(x)-F(x_{0})}{x-x_{0}}-f(x_{0})\right|&=\left|\frac{1}{x-x_{0}}\int_{x_{0}}^{x}\left[f(t)-f(x_{0})\right]\mathrm{d}t\right|\\&<\left|\frac{1}{x-x_{0}}\int_{x_{0}}^{x}\varepsilon\mathrm{d}t\right|=\varepsilon,\end{aligned} $$ 

即

 $$ F^{\prime}(x_{0})=\lim_{x\to x_{0}}\frac{F(x)-F(x_{0})}{x-x_{0}}=f(x_{0}). $$ 