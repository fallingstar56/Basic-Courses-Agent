 $$ \begin{aligned}&S=2\pi\int_{_{0}}^{\pi}y\mathrm{d}l=4a^{2}\pi\int_{_{0}}^{\pi}(1+\cos\theta)\sin\theta\cos\frac{\theta}{2}\mathrm{d}\theta\\ &\quad=16a^{2}\pi\int_{_{0}}^{\pi}\cos^{4}\frac{\theta}{2}\sin\frac{\theta}{2}\mathrm{d}\theta=\frac{32}{5}\pi a^{2}.\\ \end{aligned} $$ 

求曲线  $ y=\frac{1}{3}x^{3}(0\leqslant x\leqslant1) $ 绕 x 轴旋转一周所得到旋转面面积 S.

解 把 x 看作参变量, 应用公式(13)可得

 $$ \begin{aligned}&S=2\pi\int_{0}^{1}y\mathrm{d}l=2\pi\int_{0}^{1}\frac{1}{3}x^{3}\sqrt{1+(x^{2})^{2}}\mathrm{d}x\\ &\quad=\frac{\pi}{6}\int_{0}^{1}\sqrt{1+x^{4}}\mathrm{d}(1+x^{4})=\frac{\pi}{9}(2^{3/2}-1).\\ \end{aligned} $$ 

#### 5.7.6 积分在物理中的应用

积分在物理学中有非常广泛的应用。在 5.1 节中我们已经看到。如果一质点在变力 F 的作用下由点 a 沿直线移动到点 b，力的方向不变，大小是 x 的函数  $ F(x), x \in [a, b] $，则力 F 所做的功为

 $$ W=\int_{a}^{b}F(x)\mathrm{d}x. $$ 

下面将通过几个例子来说明积分在一些物理问题上的具体应用.着重说明如何把一个具体的物理问题化为定积分.

设  $ C: x = x(t), y = y(t), a \leqslant t \leqslant b $ 是一条光滑的平面曲线，C 上点  $ M(x(t), y(t)) $ 处的线密度为  $ \rho(t) $，其中  $ \rho(t) \in C[a, b] $。求 C 的质量 m 与重心坐标  $ (\bar{x}, \bar{y}) $。

解 由物理学中知道，若平面质点系 $ (x_{1},y_{1}),(x_{2},y_{2}),\cdots,(x_{n},y_{n}) $ 的质量分别为  $ m_{1},m_{2},\cdots,m_{n} $，则此质点系的重心坐标  $ (\bar{x},\bar{y}) $ 是

 $$ \bar{x}=\frac{\sum_{i=1}^{n}x_{i}m_{i}}{\sum_{i=1}^{n}m_{i}},\quad\bar{y}=\frac{\sum_{i=1}^{n}y_{i}m_{i}}{\sum_{i=1}^{n}m_{i}}. $$ 

任给参数区间 $ [a,b] $的分割 $ T:a=t_{0}<t_{1}<\cdots<t_{n}=b $，相应地可得曲线C的分割

 $$ \widetilde{T}:A=M_{0}(x(a),y(a)),M_{1}(x(t_{1}),y(t_{1})),\cdots,M_{n}(x(t_{n}),y(t_{n}))=B. $$ 

当分割 T 的长度  $ \left|T\right| $ 充分小时，可以把小弧段  $ \widehat{M_{i-1}M_{i}} $ 看作质量集中在点  $ M_{i}(x(t_{i}), y(t_{i})) $ 处的一个质点， $ \widehat{M_{i-1}M_{i}} $ 的线密度可以近似地看作常密度  $ \rho(t_{i}) $，