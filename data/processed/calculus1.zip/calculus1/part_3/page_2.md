特别地，当  $ g(x) \equiv 1 $ 时，(6)式成为

 $$ \int_{a}^{b}f(x)\mathrm{d}x=f(\xi)(b-a). $$ 

证明 不妨设  $ g(x) \geqslant 0 $ (否则，用 -g 代替 g 即可). 记 M 与 m 为 f 在  $ [a, b] $ 上的最大与最小值，则由性质 3，

 $$ m\int_{a}^{b}g\left(x\right)\mathrm{d}x\leqslant\int_{a}^{b}f\left(x\right)g\left(x\right)\mathrm{d}x\leqslant M\int_{a}^{b}g\left(x\right)\mathrm{d}x. $$ 

若 $ \int_{a}^{b}g(x)\mathrm{d}x=0 $，则由（7）式知 $ \int_{a}^{b}f(x)g(x)\mathrm{d}x=0 $，此时（6）式对任何 $ \xi\in[a,b] $成立。若 $ \int_{a}^{b}g(x)\mathrm{d}x>0 $，则

 $$ m\leqslant\frac{\int_{a}^{b}f(x)g(x)\mathrm{d}x}{\int_{a}^{b}g(x)\mathrm{d}x}\leqslant M. $$ 

根据连续函数的介值定理，存在  $ \xi \in [a, b] $，使得

 $$ f(\xi)=\frac{\int_{a}^{b}f(x)g(x)\mathrm{d}x}{\int_{a}^{b}g(x)\mathrm{d}x}. $$ 

由此即得(6)式.

#### ▶ 例 5.2.4

求证  $ \lim_{n\to+\infty}\int_{n}^{n+x}\frac{\sin x}{x}dx=0 $

证明 由定理 5.2.2 可知，存在  $ \xi_{n} \in [n, n + \pi] $，使

 $$ \left|\int_{n}^{n+\pi}\frac{\sin x}{x}\mathrm{d}x\right|=\left|\pi\left(\frac{\sin\xi_{n}}{\xi_{n}}\right)\right|\leqslant\frac{\pi}{n}\rightarrow0(n\rightarrow\infty). $$ 

### 习题 5.2

1. 若  $ |f(x)| \in R[a,b] $，是否有  $ f(x) \in R[a,b] $?

2. 已知  $ f(x) $,  $ g(x) $ 分别是  $ [-a, a] $ 上的奇函数与偶函数，用积分的定义证明：

 $$ \int_{-a}^{a}f(x)\mathrm{d}x=0,\quad\int_{-a}^{a}g(x)\mathrm{d}x=2\int_{0}^{a}g(x)\mathrm{d}x. $$ 

3. 如果  $ f(x) $ 在  $ [a,b] $ 上连续、非负，但不恒等于零，证明： $ \int_{a}^{b}f(x)dx>0 $（也就是说，若  $ f(x) $ 在  $ [a,b] $ 上连续、非负，且  $ \int_{a}^{b}f(x)dx=0 $，则  $ f(x) $ 恒为零）.