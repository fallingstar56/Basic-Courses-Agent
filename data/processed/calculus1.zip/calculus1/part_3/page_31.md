 $$ \begin{aligned}I_{n}&=-\int_{0}^{\frac{\pi}{2}}\sin^{n-1}x\cdot(\cos x)^{\prime}\mathrm{d}x\\&=-\cos x\sin^{n-1}x\bigg|_{0}^{\frac{\pi}{2}}+(n-1)\int_{0}^{\frac{\pi}{2}}\sin^{n-2}x\cdot\cos^{2}x\mathrm{d}x\\&=(n-1)\int_{0}^{\frac{\pi}{2}}\sin^{n-2}x(1-\sin^{2}x)\mathrm{d}x=(n-1)I_{n-2}-(n-1)I_{n}.\end{aligned} $$ 

由此得到

 $$ I_{n}=\frac{n-1}{n}I_{n-2}. $$ 

这是一个关于 $ I_{n} $的递推公式。反复利用这个递推公式，并注意到

 $$ I_{0}=\int_{0}^{\frac{\pi}{2}}\mathrm{d}x=\frac{\pi}{2},\quad I_{1}=\int_{0}^{\frac{\pi}{2}}\sin x\mathrm{d}x=1, $$ 

可得

 $$ I_{2n}=\frac{2n-1}{2n}*\frac{2n-3}{2n-2}*\cdots*\frac{1}{2}*\frac{\pi}{2}. $$ 

 $$ I_{2n-1}=\frac{2n-2}{2n-1}\bullet\frac{2n-4}{2n-3}\bullet\cdots\bullet\frac{2}{3}. $$ 

记

 $$ (2n)!!=2n\cdot(2n-2)\cdots2, $$ 

 $$ (2n-1)!!=(2n-1)\cdot(2n-3)\cdots3\cdot1 $$ 

(称为双阶乘)，则有

 $$ I_{2n}=\frac{(2n-1)!!}{(2n)!!}\cdot\frac{\pi}{2},\quad I_{2n-1}=\frac{(2n-2)!!}{(2n-1)!!}. $$ 

作为本节结束，我们给出 f 在点  $ x_{0} $ 的 n 阶泰勒公式的积分余项形式.

定理 5.6.2

设 f 在  $ [a,b] $ 上有  $ n+1 $ 阶连续导数， $ x_{0}\in[a,b] $，则  $ \forall x\in[a,b] $，本

 $$ f(x)=\sum_{k=0}^{n}\frac{f^{(k)}(x_{0})}{k!}(x-x_{0})^{k}+R_{n}(x), $$ 

其中

 $$ R_{n}(x)=\frac{1}{n!}\int_{x_{0}}^{x}(x-u)^{n}f^{(n+1)}(u)\mathrm{d}u. $$ 

证明 当 n=0 时，根据牛顿-莱布尼茨公式，

 $$ f(x)=f(x_{0})+\int_{x_{0}}^{x}f^{\prime}(u)\mathrm{d}u. $$ 

定理结论成立. 假定当 n=m-1 时, 定理结论成立, 即