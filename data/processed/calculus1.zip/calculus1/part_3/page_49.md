多少?

(2) 如果旋转的角速度为常数  $ \omega $，问它们旋转时的动能各为多少？

19. 设轮胎形体由 $ (x-b)^{2}+y^{2}=a^{2}(b>a>0) $绕y轴旋转而成. 求该旋转体以等角速度 $ \omega $绕y轴旋转时, 其旋转的动能和转动惯量各为多少(体密度 $ \rho $为常数)?

## 第 5 章 总复习题

1. 若  $ f(x) \in R[a, b] $，则存在连续函数序列  $ \{\varphi_{n}(x)\} $，使得  $ \lim_{n \to \infty} \int_{a}^{b} \varphi_{n}(x) \, dx = \int_{a}^{b} f(x) \, dx. $

2. 证明： $ |f(x)| \in R[a,b] \Leftrightarrow f^2(x) \in R[a,b]. $

3. 证明：黎曼函数  $ R(x)=\left\{\begin{aligned}&\frac{1}{n},&x=\frac{m}{n},m,n\text{互质},n>0,\\&0,&x\in\mathbb{R}\setminus\mathbb{Q}\end{aligned}\right. $ 在  $ [0,1] $ 上可积.

4. 设函数  $  f(x)  $ 在区间  $ [a, b] $ 上可积， $  f([a, b]) \subseteq [A, B]  $， $  g(u)  $ 在区间  $ [A, B] $ 上可积。能否断定函数  $  g(f(x))  $ 在区间  $ [a, b] $ 上可积？试研究函数

 $ f(x)=\left\{\begin{aligned}&0,&x\text{是无理数},\\ &\frac{1}{n},&x=\frac{m}{n}(m,n\text{为互素的整数},n>0).\end{aligned}\right.\quad g(u)=\left\{\begin{aligned}&0,&u=0,\\ &1,&u\neq0.\end{aligned}\right. $

5. 证明：对于正整数 n,  $ f(x) = x^{\frac{1}{n}} $ 在  $ [0, +\infty) $ 一致连续.

6. 设  $ f(x) $ 在区间 I 上一致连续，且  $ \forall x \in I $，有  $ f(x) \in (a, b) $。又  $ g(u) $ 在  $ (a, b) $ 上一致连续，证明： $ F(x) = g(f(x)) $ 在区间 I 上一致连续。

7.（1）已知  $ f(x)\in C[0,+\infty) $， $ \lim_{x\to+\infty}(f(x)-x)=0 $，证明： $ f(x) $ 在  $ [0,+\infty) $ 一致连续；

(2) 已知  $ f(x) \in C[0, +\infty) $， $ \lim_{x \to +\infty} (f(x) - x^2) = 0 $，证明： $ f(x) $ 在  $ [0, +\infty) $ 不一致连续.

8. 设非负函数  $ f(x) \in C[a, b] $，记  $ M = \max_{x \in [a, b]} f(x) $. 证明：

 $$ \lim_{n\to\infty}\left(\int_{a}^{b}f^{n}(x)\mathrm{d}x\right)^{\frac{1}{n}}=M. $$ 

9. 已知  $  f(x) \in C^{1}(-1,1)  $，求极限  $ \lim_{x\to0+}\frac{1}{4x^{2}}\int_{-x}^{x}\left[f(t+x)-f(t-x)\right]dt. $

10. 设  $ f(x) $ 非负、连续，常数 a>0，已知  $ y=f(x) $ 的曲线与 x=0, x=a 围成的面积为