▶ 例 5.4.2

计算 $ \int\frac{\mathrm{d}x}{\cos^{2}x\cdot\sin^{2}x} $

解  $ \int\frac{\mathrm{d}x}{\cos^{2}x\sin^{2}x}=\int\frac{\sin^{2}x+\cos^{2}x}{\cos^{2}x\sin^{2}x}\mathrm{d}x=\int\left(\frac{1}{\cos^{2}x}+\frac{1}{\sin^{2}x}\right)\mathrm{d}x $

 $ =\tan x-\cot x+C. $

▶ 例 5.4.3

计算 $ \int\frac{\mathrm{d}x}{a^{2}-x^{2}}(a>0) $

解

 $$ \begin{aligned}\int\frac{\mathrm{d}x}{a^{2}-x^{2}}&=\int\frac{1}{2a}\Big(\frac{1}{a+x}+\frac{1}{a-x}\Big)\mathrm{d}x\\&=\frac{1}{2a}(\ln\mid a+x\mid+\ln\mid a-x\mid)+C=\frac{1}{2a}\ln\left|\frac{a+x}{a-x}\right|+C.\end{aligned} $$ 

▶ 例 5.4.4

计算 $ \int e^{|x|}dx. $

解 首先找到  $ e^{|x|} $ 在 R 上的一个原函数  $ F(x) $. 当  $ x \geqslant 0 $ 时，取  $ F(x) = e^{x} $. 为保证  $ F(x) $ 在连接点 x = 0 处连续，当 x < 0 时，应取  $ F(x) = -e^{-x} + 2 $. 从而

 $$ \int\mathbf{e}^{|x|}\mathrm{d}x=F(x)+C. $$ 

#### 5.4.2 换元积分法

设  $ u=\varphi(x) $ 在 I 区间上可导，且  $ \varphi(x) $ 的值域包含于区间 J 内。又设  $ f(u) $ 在区间 J 上可导，则根据复合函数的求导法则，

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\big[f(\varphi(x))\big]=f^{\prime}(\varphi(x))\varphi^{\prime}(x), $$ 

于是

 $$ \int f^{\prime}(\varphi(x))\varphi^{\prime}(x)\mathrm{d}x=f(\varphi(x))+C. $$ 

另一方面，

 $$ \int f^{\prime}(u)\mathrm{d}u=f(u)+C. $$ 

比较上面两等式不难发现，欲求 $ \int f'(\varphi(x))\varphi'(x)dx $，可以作变换 $ u=\varphi(x) $，将 $ \int f'(\varphi(x))\varphi'(x)dx $变换为 $ \int f'(u)du $，求出结果 $ f(u)+C $后再把 $ u=\varphi(x) $代入：