 $$ \begin{aligned}&\sup\{\mid f(x)\mid\mid x_{i-1}\leqslant x\leqslant x_{i}\}-\inf\{\mid f(x)\mid\mid x_{i-1}\leqslant x\leqslant x_{i}\}\\&\leqslant\sup\{f(x)\mid x_{i-1}\leqslant x\leqslant x_{i}\}-\inf\{f(x)\mid x_{i-1}\leqslant x\leqslant x_{i}\}(1\leqslant i\leqslant n),\\ \end{aligned} $$ 

于是

 $$ U(\mid f\mid,T)-L(\mid f\mid,T)\leqslant U(f,T)-L(f,T). $$ 

由此知，若  $ f \in R[a, b] $，则  $ |f| \in R[a, b] $.

性质 5 ……

设  $ f, g \in R[a, b] $，则  $ fg \in R[a, b] $.

证明 （1）先设 f 与 g 在  $ [a,b] $ 上非负. 对于  $ [a,b] $ 的任何分割 T:  $ a = x_{0} < x_{1} < \cdots < x_{n} = b $，记  $ M_{i}, N_{i} $ 与  $ m_{i}, n_{i} $ 分别为 f, g 在  $ [x_{i-1}, x_{i}] $ 中的上确界与下确界  $ (i=1,2,\cdots,n) $，M, N 分别为 f, g 在  $ [a,b] $ 中的上确界，则

 $$ \begin{align*}U(fg,T)-L(fg,T)&\leqslant\sum_{i=1}^{n}(M_{i} N_{i}-m_{i} n_{i})(x_{i}-x_{i-1})\\&=\sum_{i=1}^{n} M_{i}(N_{i}-n_{i})(x_{i}-x_{i-1})\\&\quad+\sum_{i=1}^{n} n_{i}(M_{i}-m_{i})(x_{i}-x_{i-1})\\&\leqslant M[U(g,T)-L(g,T)]+N[U(f,T)-L(f,T)].\end{align*} $$ 

由此不等式，再利用定理 5.1.1 可得，当  $ f, g \in R[a, b] $ 时， $ f g \in R[a, b] $.

(2) 在一般情况下，记

 $$ f^{\pm}\left(x\right)=\frac{1}{2}\big[\mid f(x)\mid\pm f(x)\big], $$ 

称  $ f^{+} $ 与  $ f^{-} $ 分别为 f 的正部与负部. 显然  $ f^{\pm}(x) \geqslant 0 $, 且

 $$ f=f^{+}-f^{-},\quad\mid f\mid=f^{+}+f^{-}. $$ 

根据性质 1 与性质 4， $ f^{+} $与  $ f^{-} $， $ g^{+} $与  $ g^{-} $都是  $ [a,b] $ 上的非负可积函数，从而

 $$ f g=f^{+}g^{+}-f^{+}g^{-}-f^{-}g^{+}+f^{-}g^{-}\in R[a,b]. $$ 

定理 5.2.1（柯西不等式）

设  $ f, g \in R[a, b] $，则

 $$ \left(\int_{a}^{b}f(x)g(x)\mathrm{d}x\right)^{2}\leqslant\int_{a}^{b}f\left(x\right)^{2}\mathrm{d}x\cdot\int_{a}^{b}g\left(x\right)^{2}\mathrm{d}x. $$ 

证明 记

 $$ A=\int_{a}^{b}f\left(x\right)^{2}\mathrm{d}x,\quad B=\int_{a}^{b}f(x)g(x)\mathrm{d}x,\quad C=\int_{a}^{b}g\left(x\right)^{2}\mathrm{d}x. $$ 

注意到  $ \forall t \in \mathbb{R} $，函数  $ [tf(x) + g(x)]^2 $ 在  $ [a, b] $ 上非负可积，即

 $$ A t^{2}+2B t+C=\int_{a}^{b}\left[t f(x)+g(x)\right]^{2}\mathrm{d}x\geqslant0,\quad\forall t\in\mathbb{R}, $$ 