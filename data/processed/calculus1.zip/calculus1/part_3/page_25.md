对这三种情形，可以分别作下列变换将它们化为三角有理式的积分：

 $$ x+p=qtant,x+p=qsect,x+p=qsint. $$ 

计算  $ I=\int\frac{\sqrt{x^{2}-2x+2}}{x-1}dx. $

解 令  $ x - 1 = \tan t \left(|t| < \frac{\pi}{2}\right) $，则  $ \sqrt{x^{2} - 2x + 2} = \sqrt{\tan^{2}t + 1} = \frac{1}{\cos t} $， $ dx = \frac{dt}{\cos^{2}t} $，所以

 $$ \begin{aligned}&I=\int\frac{1}{\sin t}\bullet\frac{\mathrm{d}t}{\cos^{2}t}=\int\frac{-\sin t\mathrm{d}t}{(\cos^{2}t-1)\cos^{2}t}\\ &=\int\Big(\frac{1}{\cos^{2}t-1}-\frac{1}{\cos^{2}t}\Big)(-\sin t)\mathrm{d}t=\frac{1}{\cos t}+\frac{1}{2}\ln\Big|\frac{\cos t-1}{\cos t+1}\Big|+C\\ &=\sqrt{x^{2}-2x+2}+\ln\Big|\frac{\sqrt{x^{2}-2x+2}-1}{x-1}\Big|+C.\\ \end{aligned} $$ 

注 本题也可采用下面更为简便的解法：

令  $ u=\sqrt{x^{2}-2x+2} $，则  $ u^{2}-1=(x-1)^{2} $， $ u\mathrm{d}u=(x-1)\mathrm{d}x $。因此

 $$ \begin{aligned}&I=\int\frac{u^{2}}{u^{2}-1}\mathrm{d}u=u+\frac{1}{2}\ln\left|\frac{u-1}{u+1}\right|+C\\&=\sqrt{x^{2}-2x+2}+\ln\left|\frac{\sqrt{x^{2}-2x+2}-1}{x-1}\right|+C.\\ \end{aligned} $$ 

在本节与上节中我们介绍了求一个函数的不定积分的一些基本方法。由于求一个给定函数的不定积分，常常没有固定的法则和步骤可循，这就需要读者多加练习，逐步做到熟能生巧。此外，查阅积分表与使用功能强大的数学软件如MATLAB，Mathematica等，也是求不定积分的有效途径。

最后还需要指出，虽然区间上的每个连续函数必有原函数，但是有许多连续的初等函数，它们的原函数却不再是初等函数。因而不能用本节所介绍的方法来求其原函数。例如下列初等函数：

 $$ \mathrm{e}^{-x^{2}},\sin x^{2},\cos x^{2},\frac{\sin x}{x},\frac{\cos x}{x},\frac{1}{\ln x},\sqrt{1-k^{2}\sin^{2}x}\quad(0<k<1) $$ 

它们的原函数就不再是初等函数.

### 习题 5.5

1. 求下列不定积分.

(1)

 $$ \int\frac{1}{\left(x+1\right)\left(x+2\right)^{2}}\mathrm{d}x; $$ 

(2)

 $$ \int\frac{1}{x(1+x^{2})}\mathrm{d}x; $$ 