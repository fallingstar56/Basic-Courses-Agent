显然，求不定积分与求导数互为逆运算：

 $$ \frac{\mathrm{d}}{\mathrm{d}x}\Big(\int f(x)\mathrm{d}x\Big)=f(x),\quad\int f^{\prime}(x)\mathrm{d}x=\overline{f(x)}+C. $$ 

所以由常用函数的导数表可得常用函数的不定积分表：

(1) $ \int\cos x\,dx=\sin x+C; $

(2) $ \int\sin x\,dx=-\cos x+C; $

(3) $ \int\sec^{2}x\mathrm{d}x=\tan x+C; $

(4)  $ \int \csc^2 x \, dx = -\cot x + C; $

(5)  $ \int \sec x \tan x \, dx = \sec x + C; $

(6)  $ \int \csc x \cot x \, dx = -\csc x + C; $

(7) $ \int x^{a}dx=\frac{x^{a+1}}{a+1}+C(a\neq-1) $;

(8) $ \int\frac{dx}{x}=\ln|x|+C; $

(9) $ \int a^{x}dx=\frac{a^{x}}{\ln a}+C(a>0,a\neq1) $;

(10) $ \int\frac{\mathrm{d}x}{\sqrt{1-x^{2}}}=\arcsin x+C=-\arccos x+C; $

(11)  $ \int \frac{dx}{1 + x^2} = \arctan x + C = -\arccot x + C; $

(12) $ \int\frac{\mathrm{d}x}{\sqrt{x^{2}\pm a^{2}}}=\ln\left|x+\sqrt{x^{2}\pm a^{2}}\right|+C. $

上面每个公式都是在某个区间上成立，例如 $ \int\frac{dx}{x}=\ln|x|+C $在 $ (-∞,0) $和 $ (0,+∞) $分别成立； $ \int\csc^{2}x\mathrm{d}x=-\cot x+C $在每个区间 $ (nπ,(n+1)π)(n∈Z) $上成立.

计算不定积分 $ \int\frac{2x^{2}}{1+x^{2}}dx. $

解  $ \int\frac{2x^{2}}{1+x^{2}}\mathrm{d}x=2\int\left(1-\frac{1}{1+x^{2}}\right)\mathrm{d}x=2\int\mathrm{d}x-2\int\frac{\mathrm{d}x}{1+x^{2}}=2x-2\arctan x+C. $