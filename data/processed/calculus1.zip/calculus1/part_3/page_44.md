 $$ \widehat{M_{i-1}M_{i}}\  的弧长 \approx\ \sqrt{x^{^{\prime}}\left(t_{i}\right)^{2}+y^{^{\prime}}\left(t_{i}\right)^{2}}\left(t_{i}-t_{i-1}\right). $$ 

从而 $ M_{i-1}M_{i} $可近似地看作点 $ M_{i}(x(t_{i}),y(t_{i})) $处质量为

 $$ m_{i}=\rho(t_{i})\sqrt{x^{\prime}(t_{i})^{2}+y^{\prime}(t_{i})^{2}}(t_{i}-t_{i-1}) $$ 

的一个质点。所以质点系  $ M_{1}(x(t_{1}),y(t_{1})),\cdots,M_{n}(x(t_{n}),y(t_{n})) $ 的质量与重心坐标的横坐标分别为

 $$ \sum_{i=1}^{n}\rho(t_{i})\ \sqrt{x^{^{\prime}}(t_{i})^{2}+y^{^{\prime}}(t_{i})^{2}}(t_{i}-t_{i-1}) $$ 

与

 $$ \frac{\sum_{i=1}^{n}x(t_{i})\rho(t_{i})\sqrt{x^{^{\prime}}(t_{i})^{2}+y^{^{\prime}}(t_{i})^{2}}(t_{i}-t_{i-1})}{\sum_{i=1}^{n}\rho(t_{i})\sqrt{x^{^{\prime}}(t_{i})^{2}+y^{^{\prime}}(t_{i})^{2}}(t_{i}-t_{i-1})}. $$ 

注意到上面两个和式分别为函数

 $$ \rho(t)\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}} 与 x(t)\rho(t)\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}} $$ 

关于分割 T 的一个黎曼和，令  $ |T|\rightarrow0 $ 即得

 $$ m=\int_{a}^{b}\rho(t)\ \sqrt{x^{^{\prime}}(t)^{2}+y^{^{\prime}}(t)^{2}}\mathrm{d}t, $$ 

 $$ \bar{x}=\frac{1}{m}\int_{a}^{b}x(t)\rho(t)\sqrt{x^{^{\prime}}(t)^{2}+y^{^{\prime}}(t)^{2}}\mathrm{d}t. $$ 

同理，

 $$ \bar{y}=\frac{1}{m}\int_{a}^{b}y(t)\rho(t)\sqrt{x^{^{\prime}}(t)^{2}+y^{^{\prime}}(t)^{2}}\mathrm{d}t. $$ 

上述问题也可以用下面逻辑上虽不够严密，然而却更加简明快捷、更切中问题实质的方法来求解。

任取  $ t \in [a, b] $ 及其 t 的增量  $ \Delta t $，参数区间  $ [t, t + \Delta t] $ 在 C 上对应的微小弧段  $ \sigma $ 的弧长为  $ \sqrt{x'(t)^2 + y'(t)^2} \Delta t $，其线密度可以近似地看作常密度  $ \rho(t) $，且  $ \sigma $ 可以近似地看作质量集中在点  $ M(x(t), y(t)) $ 处的一个质点，其质量为

 $$ \Delta m\approx\rho(t)\ \sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}}\Delta t. $$ 

将这些质量微元“相加”（即在 $ [a,b] $上积分），便得到C的质量为

 $$ m=\int_{a}^{b}\rho(t)\ \sqrt{x^{^{\prime}}(t)^{2}+y^{^{\prime}}(t)^{2}}\mathrm{d}t, $$ 

同时，C 可以看作由这样的微小弧段  $ \sigma $ 所组成的“质点”系，从而 C 的重心坐标应为

 $$ \bar{x}=\frac{1}{m}\int_{a}^{b}x(t)\rho(t)\sqrt{x^{^{\prime}}(t)^{2}+y^{^{\prime}}(t)^{2}}\mathrm{d}t, $$ 