(2) $ \lim_{n\to\infty}\left(\frac{n}{n^{2}+1^{2}}+\frac{n}{n^{2}+2^{2}}+\cdots+\frac{n}{n^{2}+n^{2}}\right) $;

(3)  $ \lim_{n\to\infty}n^{-3/2}\left(\sqrt{n+1}+\sqrt{n+2}+\cdots+\sqrt{n+n}\right) $

14. 求  $ f(x)=(x+1)\ln(x+1)-x $ 的导数，并计算  $ \lim_{n\to\infty}\frac{\sqrt[n]{(n+1)(n+2)\cdots(n+n)}}{n} $.

15. 证明： $ \int_{0}^{\frac{\pi}{2}}e^{-R\sin x}dx\left\{\begin{aligned}<\frac{\pi}{2R}(1-e^{-R}),&R>0,\\>\frac{\pi}{2R}(1-e^{-R}),&R<0.\end{aligned}\right. $

### 5.4 不定积分的概念与积分法

#### 5.4.1 不定积分的概念与基本性质

根据微积分基本定理，一个区间上的连续函数 f 必有原函数，而且只要找到了 f 的一个原函数，就可以计算出 f 在相应闭区间上定积分的值。

设  $ F(x) $ 是  $ f(x) $ 在区间 I 上的一个原函数，则对于任意的常数  $ C, F(x) + C $ 也是  $ f(x) $ 在区间 I 上的原函数。另一方面，如果  $ G(x) $ 也是  $ f(x) $ 在区间 I 上的任一个原函数，则

 $$ \left(G(x)-F(x)\right)^{\prime}=G^{\prime}(x)-F^{\prime}(x)\equiv0, $$ 

从而存在常数 C，使得  $ G(x) \equiv F(x) + C. $ 这就是说，如果  $ f(x) $ 在区间 I 上有一个原函数  $ F(x) $，则  $ f(x) $ 在区间 I 上的所有原函数可以表示为

 $$ F(x)+C,C\in\mathbb{R}. $$ 

定义 5.4.1

设  $ f(x) $ 在区间 I 上有原函数，称  $ f(x) $ 在区间 I 上的原函数全体为  $ f(x) $ 在区间 I 上的不定积分，记为  $ \int f(x)dx $.

根据(1)式，若  $ F(x) $ 是  $ f(x) $ 在区间 I 上的一个原函数，则

 $$ \int f(x)\mathrm{d}x=F(x)+C, $$ 

其中 C 表示任意常数.

根据导数的性质容易得到不定积分具有下列性质：

(1)  $ \int[\alpha f(x)]\,dx = \alpha\int f(x)\,dx $;

(2)

 $$ \int[f(x)+g(x)]\mathrm{d}x=\int f(x)\mathrm{d}x+\int g(x)\mathrm{d}x. $$ 