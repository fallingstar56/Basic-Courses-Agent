解 令  $ t=\tan\frac{x}{2} $，则有

 $$ 1+\sin x=1+\frac{2t}{1+t^{2}}=\frac{(1+t)^{2}}{1+t^{2}}, $$ 

 $$ 1+\cos x=1+\frac{1-t^{2}}{1+t^{2}}=\frac{2}{1+t^{2}}. $$ 

于是

 $$ \begin{aligned}\int\frac{1+\sin x}{1+\cos x}\mathrm{d}x&=\int\frac{1}{2}\left(1+t\right)^{2}\frac{2}{1+t^{2}}\mathrm{d}t=\int\left(1+\frac{2t}{1+t^{2}}\right)\mathrm{d}t\\&=t+\ln(1+t^{2})+C=\tan\frac{x}{2}-2\ln\left|\cos\frac{x}{2}\right|+C.\end{aligned} $$ 

但是，在很多情况下，采用万能变换将积分化为有理式的方法计算过程比较烦琐，因此，常需要寻求其他更简便的积分方法。例如，例5.5.3也可如下求解：

 $$ \begin{aligned}\int\frac{1+\sin x}{1+\cos x}\mathrm{d}x&=\int\frac{1}{2\cos^{2}\frac{x}{2}}\mathrm{d}x+\int\frac{\sin x}{1+\cos x}\mathrm{d}x\\&=\tan\frac{x}{2}-\ln(1+\cos x)+C.\end{aligned} $$ 

▶ 例 5.5.4

计算  $ I=\int\frac{\tan x}{a^{2}\cos^{2}x+b^{2}\sin^{2}x}dx. $

解 令  $ t = \tan x $，则

 $$ I=\int\frac{\tan x}{a^{2}+b^{2}\tan^{2}x}\cdot\frac{1}{\cos^{2}x}\mathrm{d}x=\frac{1}{2b^{2}}\ln(a^{2}+b^{2}\tan^{2}x)+C. $$ 

计算  $ I=\int\frac{\sin2x}{\cos^{2}x+2\sin x}dx. $

解 令  $ t=\sin x $，则  $ \cos^{2}x+2\sin x=1+2t-t^{2} $， $ dt=\cos x\,dx $，于是

 $$ \begin{aligned}I&=\int\frac{\sin2x}{\cos^{2}x+2\sin x}\mathrm{d}x=\int\frac{2t\mathrm{d}t}{1+2t-t^{2}}\\&=\int\frac{2t-2}{1+2t-t^{2}}\mathrm{d}t+\int\frac{2\mathrm{d}t}{2-(t-1)^{2}}\\&=-\ln|1+2t-t^{2}|+\frac{1}{\sqrt{2}}\ln\left|\frac{\sqrt{2}-1+t}{\sqrt{2}+1-t}\right|+C\\&=-\ln|\cos^{2}x+2\sin x|+\frac{1}{\sqrt{2}}\ln\left|\frac{\sqrt{2}-1+\sin x}{\sqrt{2}+1-\sin x}\right|+C.\end{aligned} $$ 