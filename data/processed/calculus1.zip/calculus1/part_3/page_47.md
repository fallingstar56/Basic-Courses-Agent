在(14)式中令  $ H \rightarrow +\infty $，可得  $ v_{0} = \sqrt{2gR} $。这就是使得物体脱离地球引力的最低速度，称为第二宇宙速度。

### 习题 5.7

1. 求下列函数在  $ [-a, a] $ 上的平均值.

(1)  $  f(x) = \sqrt{a^{2} - x^{2}}  $; (2)  $  f(x) = x^{3}  $; (3)  $  f(x) = \cos x  $.

2. 求下列曲线围成的面积.

(1) 抛物线  $ x=y^{2}-2y $ 与  $ x=2y^{2}-8y+6 $ 围成的图形的面积；

(2) $ y=\sin x,y=\cos x $ 在 $ \left[\frac{\pi}{4},\frac{9\pi}{4}\right] $ 内所围图形的面积；

（3）抛物线  $ y=x^{2}-5x+4 $ 与其在点 x=0, x=5 处两条切线所围成图形的面积；

(4) 星形线  $ x = a \cos^{3} t $,  $ y = a \sin^{3} t $ 所围图形的面积；

(5) 三叶线  $ \rho = a \sin 3\theta (a > 0) $ 所围图形的面积；

(6) 圆  $ \rho=1 $ 与心脏线  $ \rho=1+\sin\theta $ 所围图形的面积；

(7) 确定的值，使  $ y = x - x^{2} $ 与 y = kx 所围图形的面积为  $ \frac{9}{2} $.

3. 求下列弧长.

(1) 曲线  $ y = \int_{-\frac{\pi}{2}}^{x} \sqrt{\cos t} \, dt \left(-\frac{\pi}{2} \leqslant x \leqslant \frac{\pi}{2}\right) $ 的弧长；

(2) 曲线  $ x = \arctan t $,  $ y = \ln \sqrt{1 + t^{2}} $ ( $ 0 \leqslant t \leqslant 1 $) 的弧长；

(3) 星形线  $ x = a \cos^{3} t $,  $ y = a \sin^{3} t $ 的弧长；

(4) 求旋轮线  $ x = a(t - \sin t) $,  $ y = a(1 - \cos t) $ 第一拱的弧长；

(5) 阿基米德螺线  $ \rho=a\theta(0\leqslant\theta\leqslant2\pi) $ 的弧长；

(6) 悬链线  $ y = a \cosh \frac{x}{a}, x \in [0, l], a > 0. $

4. 求下列曲线的曲率：

1)  $ y = x^{3} $; (2)  $ x = a(t - \sin t) $,  $ y = a(1 - \cos t) $;

(3)  $ y = e^x $; (4)  $ x = a(\cos t - t \sin t) $,  $ y = a(\sin t - t \cos t) $.

5. 求下列用极坐标表示的曲线的曲率：

(1)  $ \rho = a(1 + \cos\theta)(a > 0) $; (2)  $ \rho^{2} = 2a^{2}\cos2\theta(a > 0) $.

6. 求曲线  $ y = \ln x $ 曲率最大的点以及在点  $ (1, 0) $ 处的曲率圆方程.

7. 求下列旋转体的体积.

(1) 由  $ y = x^{2} $， $ y = x^{3} $ 围成的图形绕 x 轴旋转生成的旋转体；

(2) 由  $ y=\sqrt{x} $ 与 x 轴以及直线 x=4 围成的图形绕 x=4 以及 y 轴旋转生成