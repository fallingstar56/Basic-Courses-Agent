 $$ [a,a+l].任取 $ x\in[a,a+l] $及x的增量 $ \Delta x $，位于 $ [x,x+\Delta x] $上的一小段细杆可以看作一个质点，其质量为 $ \frac{l}{M}\Delta x $，于是这一小段细杆对质点P的引力为

 $$ \Delta F\approx k\frac{m\left(\frac{M}{l}\Delta x\right)}{x^{2}}(k 为引力常数 ). $$ 

于是整条细杆对质点 P 的引力为

 $$ F=\int_{a}^{a+l}\mathrm{d}F=\int_{a}^{a+l}\frac{kMm}{l}\cdot\frac{\mathrm{d}x}{x^{2}}=\frac{kMm}{a\left(l+a\right)}. $$ 

▶ 例 5.7.19

从地面垂直向上发射质量为 m 的物体，欲使物体达到距地面为 H 的高度，在忽略空气阻力的情况下，物体的初速度  $ v_{0} $ 至少应为多少？

解 这个问题可以换一种提法，即如果将物体放到 H 高度，使其自由下落。为了使物体到地面时具有速度  $ v_{0} $，H 应为多少？

取地心为坐标原点，地心与物体连线为 x 轴。当物体位于高度 x 时，地球对物体的引力为

 $$ F(x)=-k\frac{Mm}{x^{2}}, $$ 

其中 M 是地球质量, k 为比例常数. 记地球半径为 R. 当物体位于地面时, 地球引力为

 $$ -k\frac{Mm}{R^{2}}=-mg, $$ 

于是  $ k=\frac{R^{2}g}{M} $，所以

 $$ F(x)=-mgR^{2}x^{-2}. $$ 

由此知物体从高度 H 落至地面，地球引力所做的功为

 $$ \int_{R+H}^{R}F(x)\mathrm{d}x=\int_{R+H}^{R}-mg\frac{R^{2}}{x^{2}}\mathrm{d}x=mg^{2}\Big(\frac{1}{R}-\frac{1}{R+H}\Big). $$ 

这个功应等于物体所获得的动能，即

 $$ \frac{1}{2}m v_{0}^{2}=m g R^{2}\left(\frac{1}{R}-\frac{1}{R+H}\right), $$ 

于是

 $$ v_{0}=\sqrt{2gR^{2}\left(\frac{1}{R}-\frac{1}{R+H}\right)}. $$ 

所以将物体自地面垂直发射到高度 H，初速度  $ v_{0} $ 至少要等于上述值。

若要使物体克服地球引力，升高至无穷远处，那么至少需要多大的初速度？