最后，记  $ J_{k}=\int\left[(x+a)^{2}+b^{2}\right]^{-k}dx $，在 5.4 节(2) 式中用  $ x+a $ 代替 x 可得，

 $$ J_{1}=\int\frac{\mathrm{d}x}{(x+a)^{2}+b^{2}}=\frac{1}{b}\arctan\left(\frac{x+a}{b}\right)+C; $$ 

 $$ J_{k+1}=\frac{1}{2kb^{2}}\big[(x+a)\left((x+a)^{2}+b^{2}\right)^{-k}+(2k-1)J_{k}\big]\quad(k\geqslant2). $$ 

▶ 例 5.5.1 ……

计算  $ I=\int\frac{2x^{2}+2x+13}{(x-2)(x^{2}+1)^{2}}\mathrm{d}x. $

解 设被积函数有分解式

 $$ \frac{2x^{2}+2x+13}{(x-2)(x^{2}+1)^{2}}=\frac{A}{x-2}+\frac{Bx+C}{x^{2}+1}+\frac{dx+E}{(x^{2}+1)^{2}} $$ 

其中 A, B, C, D, E 是待定常数。将上式右端通分合并，等式两端分子应相等：

 $$ \begin{aligned}2x^{2}+2x+13&=(A+B)x^{4}+(C-2B)x^{3}+(2A+B-2C+D)x^{2}\\&+(C-2B+E-2D)x+(A-2C-2E),\end{aligned} $$ 

比较两端同幂次的系数，得

 $$ \begin{cases}A+B=0,\\C-2B=0,\\2A+B-2C+D=2,\\C-2B+E-2D=2,\\A-2C-2E=13,\end{cases} $$ 

解此方程组，得到

 $$ A=1,B=-1,C=-2,D=-3,E=-4. $$ 

于是

 $$ \frac{2x^{2}+2x+13}{(x-2)(x^{2}+1)^{2}}=\frac{1}{x-2}-\frac{x+2}{x^{2}+1}-\frac{3x+4}{(x^{2}+1)^{2}} $$ 

所以

 $$ \begin{aligned}&I=\int\frac{\mathrm{d}x}{x-2}-\int\frac{x+2}{x^{2}+1}\mathrm{d}x-\int\frac{3x+4}{(x^{2}+1)^{2}}\mathrm{d}x\\&=\frac{1}{2}\frac{3-4x}{x^{2}+1}+\frac{1}{2}\ln\frac{(x-2)^{2}}{x^{2}+1}-4\arctan x+C.\\ \end{aligned} $$ 

▶ 例 5.5.2 ……

计算  $ I=\int\frac{x^{3}+1}{x^{4}-3x^{3}+3x^{2}-x}dx. $

解 将被积函数的分母作因式分解：

 $$ x^{4}-3x^{3}+3x^{2}-x=x\left(x-1\right)^{3}, $$ 