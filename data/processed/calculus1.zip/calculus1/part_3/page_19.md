(13)  $ \int \frac{\sqrt{1 - \ln x}}{x} \, dx $;

(14) $ \int\frac{2^{x}}{\sqrt{4-4^{x+1}}}dx; $

(15)  $ \int \sqrt{\frac{\arcsin x}{1 - x^{2}}} \, dx. $

5. 求下列不定积分.

(1) $ \int\frac{1}{(3-x^{2})}\mathrm{d}x; $

(2) $ \int\frac{x}{3-x^{2}}\mathrm{d}x; $

(3) $ \int\frac{x}{x^{2}+x-6}dx; $

(4) $ \int\frac{x-1}{x^{2}-4x+8}dx; $

(5) $ \int\frac{2x+1}{\sqrt{4x-x^{2}}}dx; $

(6) $ \int\frac{x+1}{\sqrt{-x^{2}+2x+3}}dx; $

(7)  $ \int \cos^2(1 - 2x) \, dx $;

(8)  $ \int \cos^3 x \, dx $;

(9)  $ \int \sin \alpha x \cos \beta x \, dx $;

(10)  $ \int \tan^4 x \, dx $;

(11)  $ \int \sqrt{1 + \cos x} \, dx $;

(12)  $ \int \frac{\sin 2x}{1 + \sin^4 x} \, dx. $

6. 求下列不定积分.

(1) $ \int\frac{x^{2}}{\sqrt{a^{2}+x^{2}}}dx; $

(2) $ \int\frac{\sqrt{x^{2}-4}}{x}dx; $

(3) $ \int\frac{1}{x\sqrt{a^{2}-x^{2}}}dx; $

(4) $ \int\frac{1}{x^{2}\sqrt{x^{2}-1}}dx; $

(5) $ \int\frac{2x-1}{\sqrt{4x^{2}+4x+5}}dx; $

(6) $ \int\frac{x^{2}}{\sqrt{3+2x-x^{2}}}dx. $

7. 求下列不定积分.

(1) $ \int x\cos2xdx $;

(2) $ \int x\mathrm{e}^{-3x}\mathrm{d}x; $

(3) $ \int x^{2}\sin2xdx; $

(4)  $ \int x\arctan x\,dx $;

(5) $ \int x\ln(x-1)dx; $

(6)  $ \int \ln(x + \sqrt{1 + x^{2}}) \, dx $;

(7)  $ \int (\arccos x)^{2} dx $;

(8)  $ \int x \tan^2 x \, dx $;

(9)  $ \int \frac{x}{\sin^2 x} \, dx $;

(10)  $ \int e^{x} \sin^{2} x \, dx $;

(11)  $ \int \frac{\arcsin e^x}{e^x} dx $;

(12)  $ \int \sin(\ln x) \, dx. $