所以被积函数应有分解式：

 $$ \frac{x^{3}+1}{x^{4}-3x^{3}+3x^{2}-x}=\frac{A}{x}+\frac{B}{x-1}+\frac{C}{(x-1)^{2}}+\frac{D}{(x-1)^{3}}, $$ 

右端通分相加，可得

 $$ x^{3}+1=(A+B)x^{3}+(-3A-2B+C)x^{2}+(3A+B-C+D)x-A. $$ 

再比较等式两端同幂次的系数，有

 $$ A=-1,B=2,C=1,D=2, $$ 

于是

 $$ \begin{aligned}I=&-\int\frac{\mathrm{d}x}{x}+2\int\frac{\mathrm{d}x}{x-1}+\int\frac{\mathrm{d}x}{(x-1)^{2}}+2\int\frac{\mathrm{d}x}{(x-1)^{3}}\\=&-\ln|x|+2\ln|x-1|-\frac{1}{x-1}-\frac{1}{(x-1)^{2}}+C.\end{aligned} $$ 

#### 5.5.2 三角有理式的不定积分

由  $ \sin x, \cos x $ 与常数经过有限次四则运算所得到的表达式称为三角有理式，记作  $ R(\sin x, \cos x) $。对它的不定积分  $ \int R(\sin x, \cos x) \, dx $，作半角代换： $ t = \tan \frac{x}{2} $，则有

 $$ x=2\mathrm{arctant},\quad\mathrm{d}x=\frac{2\mathrm{d}t}{1+t^{2}}, $$ 

 $$ \sin x=\frac{2\sin\frac{x}{2}\cos\frac{x}{2}}{\cos^{2}\frac{x}{2}+\sin^{2}\frac{x}{2}}=\frac{2\tan\frac{x}{2}}{1+\tan^{2}\frac{x}{2}}=\frac{2t}{1+t^{2}}, $$ 

 $$ \cos x=\frac{\cos^{2}\frac{x}{2}-\sin^{2}\frac{x}{2}}{\cos^{2}\frac{x}{2}+\sin^{2}\frac{x}{2}}=\frac{1-\tan^{2}\frac{x}{2}}{1+\tan^{2}\frac{x}{2}}=\frac{1-t^{2}}{1+t^{2}}. $$ 

于是

 $$ \int R(\sin x,\cos x)dx=\int R\left(\frac{2t}{1+t^{2}},\frac{1-t^{2}}{1+t^{2}}\right)\frac{2}{1+t^{2}}dt. $$ 

这个等式的右端是一个有理函数的积分。由 5.4.4 小节中的讨论知，有理函数有初等的原函数。于是任何三角有理函数都可以通过代换  $ t=\tan\frac{x}{2} $ 找到初等的原函数。因此，半角代换  $ t=\tan\frac{x}{2} $ 也常称为“万能代换”。

▶ 例 5.5.3

求 $ \int\frac{1+\sin x}{1+\cos x}dx. $