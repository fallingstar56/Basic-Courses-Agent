解 应用凑微分法结合例 5.4.3 的结果可以得到

 $$ \int\sec x\mathrm{d}x=\int\frac{\cos x}{\cos^{2}x}\mathrm{d}x=\int\frac{\mathrm{d}(\sin x)}{1-\sin^{2}x}=\frac{1}{2}\ln\left|\frac{1+\sin x}{1-\sin x}\right|+C. $$ 

注意到

 $$ \frac{1+\sin x}{1-\sin x}=\frac{(1+\sin x)^{2}}{1-\sin^{2}x}=\left(\frac{1+\sin x}{\cos x}\right)^{2}=\left(\sec x+\tan x\right)^{2}, $$ 

所以又有

 $$ \int\sec x\mathrm{d}x=\ln|\sec x+\tan x|+C. $$ 

同理可得

 $$ \int\csc x\mathrm{d}x=\frac{1}{2}\ln\left|\frac{1-\cos x}{1+\cos x}\right|+C=\ln|\csc x-\cot x|+C. $$ 

▶ 例 5.4.9

计算 $ \int\frac{\mathrm{d}x}{x(1+x^{5})} $

解法一  $ \int\frac{\mathrm{d}x}{x(1+x^{5})}=\int\left[\frac{1}{x}-\frac{x^{4}}{1+x^{5}}\right]\mathrm{d}x=\ln|x|-\frac{1}{5}\ln|1+x^{5}|+C. $

 $$ \begin{aligned} 解法二 \quad\int\frac{\mathrm{d}x}{x\left(1+x^{5}\right)}&=\int\frac{\mathrm{d}x}{x^{6}\left(x^{-5}+1\right)}=-\frac{1}{5}\int\frac{\left(x^{-5}+1\right)^{\prime}}{\left(x^{-5}+1\right)}\mathrm{d}x\\&=-\frac{1}{5}\ln\mid x^{-5}+1\mid+C.\end{aligned} $$ 

▶ 例 5.4.10 ……

计算 $ \int\sqrt{a^{2}-x^{2}}dx\left(a>0\right) $

解 设法做变换将被积函数中的根号去掉.为此采用第二换元法，令  $ x = a \sin t $，则  $ \left|t\right| \leqslant \frac{\pi}{2} $ 对应  $ \left|x\right| \leqslant a $，并且  $ \mathrm{d}x = a \cos t \mathrm{d}t, \sqrt{a^{2} - x^{2}} = a \sqrt{1 - \sin^{2} t} = a \cos t. $ 于是

 $$ \begin{aligned}\int\sqrt{a^{2}-x^{2}}\mathrm{d}x&=a^{2}\int\cos^{2}t\mathrm{d}t=\frac{1}{2}a^{2}\int(1+\cos2t)\mathrm{d}t\\&=\frac{1}{2}a^{2}\left(t+\frac{1}{2}\sin2t\right)+C.\end{aligned} $$ 

注意到  $ t \in [-\pi/2, \pi/2] $ 时， $ t = \arcsin \frac{x}{a} $，且

 $$ \frac{1}{2}\sin2t=\sin t\cos t=\sin t\sqrt{1-\sin^{2}t}=\frac{x}{a}\sqrt{1-\frac{x^{2}}{a^{2}}}=\frac{x}{a^{2}}\sqrt{a^{2}-x^{2}}, $$ 

所以