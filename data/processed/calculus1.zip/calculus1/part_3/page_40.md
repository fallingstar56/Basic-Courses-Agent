如果光滑曲线 C 在点 M 处的曲率为 k，则称  $ R=\frac{1}{k} $ 为 C 在点 M 处的曲率半

径. 过点 M 作 C 的法线 l，并在 l 上 C 凹的一侧取点 O 使得  $ \left|OM\right|=R $（见图 5.7.7）。以点 O 为圆心，以 R 为半径的圆称为曲线 C 在点 M 处的曲率圆（或密切圆），点 O 称为曲率中心。

<div style="text-align: center;"><img src="imgs/img_in_image_box_455_133_628_215.jpg" alt="Image" width="24%" /></div>


不难验证，曲线 C 在点 M 处的曲率圆与 C 在点 M 处有相同的切线、相同的曲率，以及相同的二阶导数.

<div style="text-align: center;">图 5.7.7</div>


#### ▶ 例 5.7.9

求抛物线  $ y=x^{2} $ 上任一点处的曲率、曲率半径与曲率中心.

解 抛物线上任一点  $ M(x, x^{2}) $ 处的曲率为

 $$ k=\frac{\left|y^{\prime \prime}(x)\right|}{(1+(y^{\prime}(x))^{2})^{3/2}}=\frac{2}{(1+4x^{2})^{3/2}}, $$ 

曲率半径为

 $$ R=\frac{1}{k}=\frac{1}{2}\left(1+4x^{2}\right)^{3/2}. $$ 

抛物线在点  $ M(x, x^{2}) $ 处的法线方程为

 $$ Y-x^{2}=-\frac{1}{2x}(X-x), $$ 

曲率中心  $ O(X,Y) $ 应满足等式

 $$ (X-x)^{2}+(Y-x^{2})^{2}=R^{2}, $$ 

还在点  $ M(x,x^{2}) $ 处的法线上，且当 x>0 时 X<x；当 x<0 时 X>x，所以

 $$ \left(X-x\right)^{2}+\frac{1}{4x^{2}}\left(X-x\right)^{2}=\frac{1}{4}\left(1+4x^{2}\right)^{3}, $$ 

 $$ X=-4x^{3},\quad Y=\frac{1}{2}+3x^{2}. $$ 

即抛物线在点  $ M(x, x^{2}) $ 处的曲率中心是  $ O\left(-4x^{3}, \frac{1}{2} + 3x^{2}\right) $.

#### 5.7.4 旋转体体积

设平面区域 D 是由直线 x=a, x=b, x 轴及连续曲线  $ y=f(x) $ 围成。将 D 绕 x 轴旋转一周，得到一个旋转体  $ \Omega $（图 5.7.8）。我们来计算  $ \Omega $ 的体积。

任取  $ x \in [a, b] $，令  $ V(x) $ 为  $ \Omega $ 中横坐标介于 a 与 x 之间部分的体积。任给 x 的增量  $ \Delta x > 0, \Delta V = V(x + \Delta x) - V(x) $ 为一个厚度为  $ \Delta x $ 的“曲边”薄圆片的体积。记  $ f(x) $ 在区间  $ [x, x + \Delta x] $ 上的上、下确界分别为  $ \widetilde{M} $ 与  $ \widetilde{m} $，则  $ \Delta V $ 应介于