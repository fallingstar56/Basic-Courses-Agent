对于积分 $ \int_{T}^{a+T}f(x)dx $，令 $ x=t+T $，注意到f的周期性，可得

 $$ \begin{aligned}\int_{T}^{a+T}f(x)\mathrm{d}x&=\int_{0}^{a}f(t+T)\mathrm{d}t=\int_{0}^{a}f(t)\mathrm{d}t\\&=-\int_{a}^{0}f(x)\mathrm{d}x.\end{aligned} $$ 

结合(2)式与(3)式便得到(1)式.

计算  $ I=\int_{0}^{\pi}\frac{x\sin x}{1+\cos^{2}x}dx. $

解 令  $ x = \pi - t $，则

 $$ I=\int_{\pi}^{0}\frac{(\pi-t)\sin(\pi-t)}{1+\cos^{2}(\pi-t)}(-\mathrm{d}t)=\int_{0}^{\pi}\frac{(\pi-t)\sin t}{1+\cos^{2}t}\mathrm{d}t=\int_{0}^{\pi}\frac{\pi\sin t}{1+\cos^{2}t}\mathrm{d}t-I, $$ 

于是

 $$ I=\frac{\pi}{2}\int_{0}^{\pi}\frac{\sin t}{1+\cos^{2}t}\mathrm{d}t=-\frac{\pi}{2}\arctan(\cos t)\mid_{0}^{\pi}=\frac{\pi^{2}}{4}. $$ 

定积分计算的另一重要方法是分部积分法. 设  $ u(x) $ 与  $ v(x) $ 在区间 I 上有连续的导数, 则

 $$ \left[u(x)v(x)\right]^{\prime}=u(x)v^{\prime}(x)+v(x)u^{\prime}(x). $$ 

于是由牛顿-莱布尼茨公式可得

 $$ \int_{a}^{b}u(x)v^{\prime}(x)\mathrm{d}x=u(x)v(x)\mid_{a}^{b}-\int_{a}^{b}u^{\prime}(x)v(x)\mathrm{d}x. $$ 

这就是定积分的分部积分公式. 在很多积分问题中都需要应用这种积分方法.

▶ 例 5.6.6

计算 $ \int_{0}^{1}x\ln^{2}x\mathrm{d}x. $

解

 $$ \begin{aligned}\int_{0}^{1}x\ln^{2}x\mathrm{d}x&=\frac{1}{2}x^{2}\ln^{2}x\mid_{0}^{1}-\int_{0}^{1}x\ln x\mathrm{d}x\\&=\frac{-1}{2}x^{2}\ln x\mid_{0}^{1}+\frac{1}{2}\int_{0}^{1}x\mathrm{d}x=\frac{1}{4}.\end{aligned} $$ 

▶ 例 5.6.7

计算 $ \int_{0}^{1}e^{\sqrt{x}}dx. $

解 令  $ t=\sqrt{x} $，则  $ \mathrm{d}x=2t\mathrm{d}t,t\in[0,1] $ 对应  $ x\in[0,1],t=0,1 $ 分别对应 x=0,1，所以

 $$ \int_{0}^{1}\mathrm{e}^{\sqrt{x}}\mathrm{d}x=\int_{0}^{1}\mathrm{e}^{t}2t\mathrm{d}t=\left.\mathrm{e}^{t}2t\right|_{0}^{1}-2\int_{0}^{1}\mathrm{e}^{t}\mathrm{d}t=2\mathrm{e}-2\mathrm{e}^{t}\left|_{0}^{1}\right.=2. $$ 