 $$ f(x)=\sum_{k=0}^{m-1}\frac{f^{(k)}(x_{0})}{k!}(x-x_{0})^{k}+\frac{1}{(m-1)!}\int_{x_{0}}^{x}(x-u)^{m-1}f^{(m)}(u)\mathrm{d}u. $$ 

应用分部积分法，

 $$ \begin{aligned}&\frac{1}{(m-1)!}\int_{x_{0}}^{x}\left(x-u\right)^{m-1}f^{(m)}(u)\mathrm{d}u\\=&\frac{-1}{m!}\left(x-u\right)^{m}f^{(m)}(u)\bigg|_{x_{0}}^{x}+\frac{1}{m!}\int_{x_{0}}^{x}\left(x-u\right)^{m}f^{(m+1)}(u)\mathrm{d}u\\=&\frac{1}{m!}\left(x-x_{0}\right)^{m}f^{(m)}(x_{0})+\frac{1}{m!}\int_{x_{0}}^{x}\left(x-u\right)^{m}f^{(m+1)}(u)\mathrm{d}u.\end{aligned} $$ 

代入(6)式即得

 $$ f(x)=\sum_{k=0}^{m}\frac{f^{(k)}(x_{0})}{k!}(x-x_{0})^{k}+\frac{1}{m!}\int_{x_{0}}^{x}(x-u)^{m}f^{(m+1)}(u)\mathrm{d}u. $$ 

所以当 n=m 时，定理结论成立。根据数学归纳法，定理结论对任何自然数 n 成立。

若令  $ u = x_{0} + t(x - x_{0}) $，则  $ x - u = (x - x_{0})(1 - t) $，因而积分余项形式（5）也可以写为

 $$ R_{n}(x)=\frac{(x-x_{0})^{n+1}}{n!}\int_{0}^{1}\left(1-t\right)^{n}f^{(n+1)}(x_{0}+t(x-x_{0}))\mathrm{d}t. $$ 

由于函数 $ (1-t)^{n} $与 $ f^{(n+1)}(x_{0}+t(x-x_{0})) $都在 $ t\in[0,1] $上连续，应用积分第一中值定理便得到f在点 $ x_{0} $的n阶泰勒公式的柯西余项形式：

 $$ R_{n}(x)=\frac{(x-x_{0})^{n+1}}{n!}\left(1-\theta\right)^{n}f^{(n+1)}(x_{0}+\theta(x-x_{0}))\quad(0\leqslant\theta\leqslant1). $$ 

### 习题 5.6

1. 求下列定积分.

(1) $ \int_{0}^{2\pi}\left|\sin x\right|dx; $

(2) $ \int_{0}^{\pi}\sqrt{1-\sin2x}dx; $

(3) $ \int_{0}^{2}\left|(x-1)(x-2)\right|dx; $

(4) $ \int_{1}^{\sqrt{3}}\frac{1}{x+x^{3}}dx; $

(5) $ \int_{1}^{2}\frac{1}{x^{2}-2x-3}dx; $

(6) $ \int_{0}^{1}\frac{1}{\left(x^{2}-2\right)^{2}}dx; $

(7) $ \int_{0}^{1}\frac{\sqrt{x}}{4-\sqrt{x}}dx; $

(8) $ \int_{0}^{\frac{\pi}{4}}\tan^{3}x\,dx $;

(9) $ \int_{0}^{1}\frac{x^{2}}{(1+x)^{\frac{3}{2}}}dx; $

(10) $ \int_{\frac{1}{f^{2}}}^{1}\frac{\sqrt{1-x^{2}}}{x^{2}}dx; $

(11) $ \int_{0}^{1}\frac{1}{(x+1)\sqrt{1+x^{2}}}dx; $

(12) $ \int_{-2}^{\sqrt{2}}\frac{1}{x^{2}\sqrt{x^{2}-1}}dx; $