 $ \Delta t \rightarrow 0 $ 时，弧段  $ MM_{1} $ 的弧长可以用弦长  $ \left|\overline{MM_{1}}\right| $ 代替，并且

 $$ \begin{align*}\left|\overline{MM_{1}}\right|&=\sqrt{(x(t+\Delta t)-x(t))^{2}+(y(t+\Delta t)-y(t))^{2}}\\&=\sqrt{(x^{^{\prime}}(t))^{2}+(y^{^{\prime}}(t))^{2}}\Delta t+o(\Delta t).\end{align*} $$ 

由此知当  $ \Delta t \rightarrow 0 $ 时，

 $$ l(t+\Delta t)-l(t)=\sqrt{(x^{\prime}(t))^{2}+(y^{\prime}(t))^{2}}\Delta t+o(\Delta t). $$ 

于是  $ l(t) $ 的微分为

 $$ \mathrm{d}l=\sqrt{(x^{\prime}(t))^{2}+(y^{\prime}(t))^{2}}\mathrm{d}t. $$ 

通常称它为曲线 C 的弧微分. 进而知曲线 C 的弧长为

 $$ L=\int_{a}^{b}\mathrm{d}l=\int_{a}^{b}\sqrt{(x^{\prime}(t))^{2}+(y^{\prime}(t))^{2}}\mathrm{d}t. $$ 

微元法是把一个应用问题转化为积分问题的基本方法。从上面讨论可以看到，微元法的要点在于：对于参数区间中任取的点 t 及其增量  $ \Delta t $，如何把我们所考虑的对象（5.7.1 小节中的面积与本小节中的弧长）对应于参数区间  $ [t, t + \Delta t] $ 的量表示为  $ \Delta t $ 的线性主要部分与  $ \Delta t $ 的高阶无穷小之和。一旦得到了  $ \Delta t $ 的线性主要部分，只需对其在参数区间上积分（将  $ \Delta t $ 写为 dt）即可。

#### ▶ 例 5.7.4

求圆  $ x = R \cos \theta, y = R \sin \theta, 0 \leqslant \theta \leqslant 2\pi $ 的弧长 L.

解 由弧长公式 $  (4)  $，

 $$ L=\int_{0}^{2\pi}\sqrt{x^{\prime}(\theta)^{2}+y^{\prime}(\theta)^{2}}\mathrm{d}\theta=\int_{0}^{2\pi}R\mathrm{d}\theta=2\pi R. $$ 

#### ▶ 例 5.7.5

求旋转线的一拱  $ x=a(t-\sin t) $， $ y=a(1-\cos t) $， $ 0 \leqslant t \leqslant 2\pi $（如图 5.7.5 所示）的弧长 L.

<div style="text-align: center;"><img src="imgs/img_in_image_box_250_646_477_737.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">图 5.7.5</div>


解 由弧长公式 $  (4)  $，

 $$ \begin{aligned}L&=\int_{0}^{2\pi}\sqrt{x^{\prime}(t)^{2}+y^{\prime}(t)^{2}}\mathrm{d}t=\sqrt{2}a\int_{0}^{2\pi}\sqrt{1-\cos t}\mathrm{d}t\\&=2a\int_{0}^{2\pi}\sin\frac{t}{2}\mathrm{d}t=8a.\end{aligned} $$ 