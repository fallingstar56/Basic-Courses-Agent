▶ 例 5.3.3

求极限  $ \lim_{x\to+\infty}\frac{\left(\int_{0}^{x}e^{t^{2}}dt\right)^{2}}{\int_{0}^{x}e^{2t^{2}}dt} $

解 应用洛必达法则，

 $$  原极限 =\lim_{x\to+\infty}\frac{2\mathrm{e}^{x^{2}}\int_{0}^{x}\mathrm{e}^{t^{2}}\mathrm{d}t}{\mathrm{e}^{2x^{2}}}=\lim_{x\to+\infty}\frac{2\int_{0}^{x}\mathrm{e}^{t^{2}}\mathrm{d}t}{\mathrm{e}^{x^{2}}}=\lim_{x\to+\infty}\frac{2\mathrm{e}^{x^{2}}}{2x\mathrm{e}^{x^{2}}}=0. $$ 

求证： $ \forall k,n\in\mathbb{N}^* $ 与  $ a\in\mathbb{R} $

(1)

 $$ \int_{a}^{a+2\pi}\mathrm{s i n k}x\mathrm{d}x=0; $$ 

(2)

 $$ \int_{a}^{a+2\pi}\cos k x\mathrm{d}x=0; $$ 

(3)

 $$ \int_{a}^{a+2\pi}\mathrm{s i n k}x\cdot\cos n x\mathrm{d}x=0; $$ 

(4)

 $$ \int_{a}^{a+2\pi}\mathrm{s i n k}x\cdot\mathrm{s i n n}x\mathrm{d}x=\left\{\begin{aligned}&0,&n\neq k,\\&\pi,&n=k;\end{aligned}\right. $$ 

(5)

 $$ \int_{a}^{a+2\pi}\cos k x\cdot\cos n x\mathrm{d}x=\left\{\begin{aligned}0,\quad&n\neq k,\\ \pi,\quad&n=k.\end{aligned}\right. $$ 

证明 sinkx 与  $ \cos kx $ 分别有原函数  $ \frac{-1}{k}\cos kx $ 与  $ \frac{1}{k}\sin kx $，根据牛顿-莱布尼茨公式，有

 $$ \begin{aligned}&\int_{a}^{+2\pi}\sin kx\mathrm{d}x=\frac{-1}{k}\cos kx\left|_{a}^{a+2\pi}=0,\right.\\&\int_{a}^{a+2\pi}\cos kx\mathrm{d}x=\frac{1}{k}\sin kx\left|_{a}^{a+2\pi}=0,\right.\\&\int_{a}^{a+2\pi}\sin kx\cdot\cos kx\mathrm{d}x=\frac{1}{2k}\left(\sin kx\right)^{2}\left|_{a}^{a+2\pi}=0,\right.\\&\int_{a}^{a+2\pi}\sin^{2}k x\mathrm{d}x=\int_{a}^{a+2\pi}\frac{1}{2}\left[1-\cos2k x\right]\mathrm{d}x=\left.\left[\frac{x}{2}-\frac{1}{4k}\sin2k x\right]\right|_{a}^{a+2\pi}=\pi.\end{aligned} $$ 

当  $ n \neq k $ 时，

 $$ \begin{aligned}\int_{a}^{a+2\pi}\sin kx\cdot\cos nx\mathrm{d}x&=\int_{a}^{a+2\pi}\frac{1}{2}\big[\sin(k+n)x-\sin(k-n)x\big]\mathrm{d}x\\&=\frac{-1}{2(k+n)}\cos(k+n)x\bigg|_{a}^{a+2\pi}+\frac{1}{2(k-n)}\cos(k-n)x\bigg|_{a}^{a+2\pi}\\&=0,\end{aligned} $$ 