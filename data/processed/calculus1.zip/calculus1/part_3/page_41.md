 $ \pi\tilde{m}^{2}\Delta x $ 与  $ \pi\tilde{m}^{2}\Delta x $ 之间. 注意到  $ f(x) $ 在  $ [a,b] $ 上连续, 于是当  $ \Delta x\to0 $ 时,

 $$ \pi\tilde{m}^{2}\Delta x=\pi f\left(x\right)^{2}\Delta x+o\left(\Delta x\right), $$ 

 $$ \pi\widetilde{M}^{2}\Delta x=\pi f\left(x\right)^{2}\Delta x+o\left(\Delta x\right), $$ 

于是  $ V(x) $ 的微分

<div style="text-align: center;"><img src="imgs/img_in_image_box_437_95_622_239.jpg" alt="Image" width="25%" /></div>


 $$ \mathrm{d}V(x)=\pi f\left(x\right)^{2}\mathrm{d}x. $$ 

由此知  $ \Omega $ 的体积为

<div style="text-align: center;">图 5.7.8</div>


 $$ V=V(b)-V(a)=\pi\int_{a}^{b}f\left(x\right)^{2}\mathrm{d}x. $$ 

求曲线  $ y=\sin x(0 \leqslant x \leqslant \pi) $ 绕 x 轴旋转所得到的旋转体的体积 V.

解 根据公式 $  (11)  $,

 $$ V=\pi\int_{0}^{\pi}\sin^{2}x\mathrm{d}x=\frac{\pi^{2}}{2}. $$ 

▶ 例 5.7.11 ……

求旋轮线

 $$ x=a(t-\sin t),\quad y=a(1-\cos t)\quad(0\leqslant t\leqslant2\pi) $$ 

绕 x 轴旋转所得到的旋转体体积.

解  $ t \in [0, 2\pi] $ 对应于  $ x \in [0, 2a\pi] $，且  $ x'(t) = a(1 - \cos t) \geqslant 0 $。再由公式(11)可得

 $$ \begin{aligned}V&=\pi\int_{0}^{2a\pi}y^{2}\mathrm{d}x=\pi\int_{0}^{2\pi}y(t)^{2}x^{\prime}(t)\mathrm{d}t\\&=\pi\int_{0}^{2\pi}a^{3}(1-\cos t)^{3}\mathrm{d}t=5\pi^{2}a^{3},\end{aligned} $$ 

▶ 例 5.7.12

设  $ f(x) $ 在  $ [0,a] $ 上连续，单调递减，且  $ f(a)=0 $。求由区域  $ D=\{(x,y)\mid0\leqslant x\leqslant a,0\leqslant y\leqslant f(x)\} $ 绕 y 轴旋转一周所得到的旋转体体积 V。

解  $ \forall t\in[0,a] $，令  $ V(t) $ 为区域  $ D_{t}=\{(x,y)\mid0\leqslant x\leqslant t,0\leqslant y\leqslant f(x)\} $ 绕 y 轴旋转一周所得到的旋转体体积。任给 t 的增量  $ \Delta t>0,\Delta V=V(t+\Delta t)-V(t) $ 为一个壁厚为  $ \Delta t $ 的圆筒。记  $ f(x) $ 在区间  $ [t,t+\Delta t] $ 上的上、下确界分别为  $ \widetilde{M} $ 与  $ \widetilde{m} $，则  $ \Delta V $ 应介于  $ 2\pi t\widetilde{m}\Delta t $ 与  $ 2\pi(t+\Delta t)\widetilde{M}\Delta t $。注意到  $ f(x) $ 在  $ [0,a] $ 上连续，于是当  $ \Delta t\to0 $ 时，

 $$ 2\pi t\bar{m}\Delta t=2\pi t f(t)\Delta t+o(\Delta t)\quad; $$ 

 $$ 2\pi(t+\Delta t)\;\vec{M}\Delta t=2\pi t f(t)\Delta t+o(\Delta t). $$ 