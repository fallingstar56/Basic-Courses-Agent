计算 $ \int\arcsin x dx $.

解 令  $ u(x)=\arctan x, v(x)=x. $ 我们有

 $$ \int\arcsin x\mathrm{d}x=x\arcsin x-\int\frac{x\mathrm{d}x}{\sqrt{1-x^{2}}}=x\arcsin x+\sqrt{1-x^{2}}+C. $$ 

……

计算 $ \int3x^{2}\arctan x\,dx $.

解 令  $ u(x)=\arctan x, v(x)=x^{3} $ 则有

 $$ \begin{aligned}\int3x^{2}\arctan x\mathrm{d}x&=x^{3}\arctan x-\int\frac{x^{3}}{1+x^{2}}\mathrm{d}x\\&=x^{3}\arctan x-\int\left(x-\frac{x}{1+x^{2}}\right)\mathrm{d}x\\&=x^{3}\arctan x-\frac{1}{2}x^{2}+\frac{1}{2}\ln(1+x^{2})+C.\end{aligned} $$ 

▶ 例 5.4.18 ……

计算 $ \int\sqrt{a^{2}+x^{2}}dx. $

解 应用分部积分法，

 $$ \begin{aligned}\int\sqrt{x^{2}+a^{2}}\mathrm{d}x&=x\sqrt{x^{2}+a^{2}}-\int\frac{x^{2}\mathrm{d}x}{\sqrt{x^{2}+a^{2}}}\\&=x\sqrt{x^{2}+a^{2}}-\int\sqrt{x^{2}+a^{2}}\mathrm{d}x+\int\frac{a^{2}\mathrm{d}x}{\sqrt{x^{2}+a^{2}}}.\end{aligned} $$ 

移项得

 $$ \int\sqrt{x}\overline{+a}\mathrm{d}x=\frac{x}{2}\sqrt{x^{2}+a^{2}}+\frac{a^{2}}{2}\int\frac{\mathrm{d}x}{\sqrt{x^{2}+a^{2}}}, $$ 

从常用不定积分表知道

 $$ \int\frac{\mathrm{d}x}{\sqrt{x^{2}+a^{2}}}=\ln\left|x+\sqrt{x^{2}+a^{2}}\right|+C, $$ 

所以

 $$ \int\sqrt{x^{2}+a^{2}}\mathrm{d}x=\frac{x}{2}\sqrt{x^{2}+a^{2}}+\frac{a^{2}}{2}\ln\left|x+\sqrt{x^{2}+a^{2}}\right|+C. $$ 

同理可得

 $$ \int\sqrt{x^{2}-a^{2}}\mathrm{d}x=\frac{x}{2}\sqrt{x^{2}-a^{2}}-\frac{a^{2}}{2}\ln\left|x+\sqrt{x^{2}-a^{2}}\right|+C. $$ 