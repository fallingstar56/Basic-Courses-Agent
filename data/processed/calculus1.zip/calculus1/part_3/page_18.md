(1) 若  $ f(x) $ 在区间 I 上可积，则  $ f(x) $ 在区间 I 上是否存在原函数？

(2) 若  $ f(x) $ 在区间 I 上仅有第一类间断点，那么  $ f(x) $ 在区间 I 上是否存在原函数？

(3) 若  $ f(x) $ 在区间 I 有原函数，则  $ f(x) $ 在区间 I 上是否可积？

2. 考察下列函数在 $ (-∞,+∞) $是否有原函数，若有，请求出原函数；若没有，请说明理由.

(1)  $  f(x) = \begin{cases} x^2 + 1, & x \leqslant 0, \\ \cos x, & x > 0; \end{cases}  $

(2)  $  f(x) = \begin{cases} x^2 + 1, & x \leqslant 0, \\ \cos x + \frac{\pi}{4}, & x > 0; \end{cases}  $

(3) $ f(x)=\begin{cases}-\sin x,&x\leqslant0,\\\frac{1}{\sqrt{x}},&x>0;\end{cases} $

(4) $ f(x)=\begin{cases}1,&x\leqslant0,\\x,&x>0.\end{cases} $



3. 求下列不定积分.

(1) $ \int(x-x^{-2})\sqrt{x\sqrt{x}}dx; $

(2) $ \int\frac{1-x^{2}}{1+x^{2}}dx; $

(3) $ \int a^{x}e^{x}dx; $

(4) $ \int(x-1)(3x-2)dx; $

(5)  $ \int(2\cosh x - 3\sinh x)dx $;

(6)  $ \int(1 - 2\cot^{2}x)dx; $



(7)  $ \int\left(\frac{4}{\sqrt{1-x^{2}}}+\sin x\right)dx; $

(8) $ \int\tan x\,dx; $



(9) $ \int\left|(x-1)(3x-2)\right|dx. $

4. 求下列不定积分.

(1) $ \int\frac{2x+1}{x^{2}+x+1}dx; $

(2) $ \int\frac{x}{\sqrt{4-x^{2}}}dx; $

(3)  $ \int \frac{1}{(1 + x^2) \arctan x} \, dx $;

(4)  $ \int \frac{1}{x^2} \sinh \frac{1}{x} \, dx $;

(5) $ \int\tanh x dx $;

(6)  $ \int x \sec^2(1 - x^2) \, dx $;

(7) $ \int\frac{x^{2}}{1+x^{6}}\mathrm{d}x; $

(8)  $ \int \frac{\sec^{2}x}{\sqrt{1+\tan x}} \, dx $;

(9) $ \int\frac{x}{\sqrt{1+x^{2}}}\sin\sqrt{1+x^{2}}dx; $

(10) $ \int\frac{e^{x}}{1+e^{2x}}dx; $



(11) $ \int\frac{1}{\mathrm{e}^{x}+\mathrm{e}^{-x}}\mathrm{d}x; $

(12) $ \int\frac{1}{(x\ln x)\ln(\ln x)}\mathrm{d}x; $