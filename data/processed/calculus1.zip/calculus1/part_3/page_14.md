 $$ \int\sqrt{a^{2}-x^{2}}\mathrm{d}x=\frac{a^{2}}{2}(t+\frac{1}{2}\sin2t)+C=\frac{a^{2}}{2}\arcsin\frac{x}{a}+\frac{x}{2}\sqrt{a^{2}-x^{2}}+C. $$ 

#### ▶ 例 5.4.11

计算 $ \int\frac{\mathrm{d}x}{1+\sqrt[3]{1+x}} $

解 令  $ u=\sqrt[3]{1+x} $，则  $ x=u^{3}-1 $， $ dx=3u^{2}du $，于是

 $$ \begin{aligned}\int\frac{\mathrm{d}x}{1+\sqrt[3]{1+x}}&=\int\frac{3u^{2}\mathrm{d}u}{1+u}=3\int\left(u-1+\frac{1}{1+u}\right)\mathrm{d}u\\&=3\big[\frac{1}{2}u^{2}-u+\ln(u+1)\big]+C\\&=3\Big[\frac{1}{2}\left(1+x\right)^{\frac{2}{3}}-\sqrt[3]{1+x}+\ln\big(1+\sqrt[3]{1+x}\big)\Big]+C.\end{aligned} $$ 

▶ 例 5.4.12 ……

计算 $ \int\frac{\mathrm{d}x}{x^{2}\sqrt{1+x^{2}}} $

解法一 令  $ x=\tan t\left(|t|<\pi/2\right) $，则  $ \mathrm{d}x=\frac{\mathrm{d}t}{\cos^{2}t} $，因此

 $$ \int\frac{\mathrm{d}x}{x^{2}\sqrt{1+x^{2}}}=\int\frac{\cos t}{\tan^{2}t}\cdot\frac{\mathrm{d}t}{\cos^{2}t}=\int\frac{\cos t}{\sin^{2}t}\mathrm{d}t=\frac{-1}{\sin t}+C. $$ 

由于

 $$ \frac{1}{\sin^{2}t}=\frac{\sin^{2}t+\cos^{2}t}{\sin^{2}t}=1+\frac{1}{\tan^{2}t}=1+\frac{1}{x^{2}}=\frac{1+x^{2}}{x^{2}}, $$ 

注意到 t>0 对应 x>0, t<0 对应 x<0, 于是

 $$ \int\frac{\mathrm{d}x}{x^{2}\sqrt{1+x^{2}}}=\frac{-1}{\sin t}+C=-\frac{\sqrt{x^{2}+1}}{x}+C. $$ 

解法二 令  $ x=\frac{1}{t} $， $ dx=-\frac{dt}{t^{2}} $，于是当 t>0，亦即 x>0 时，

 $$ \int\frac{\mathrm{d}x}{x^{2}\sqrt{1+x^{2}}}=\int\frac{-|t|}{\sqrt{1+t^{2}}}\mathrm{d}t=-\sqrt{1+t^{2}}+C=-\frac{\sqrt{x^{2}+1}}{x}+C. $$ 

当 t<0，亦即 x<0 时，

 $$ \int\frac{\mathrm{d}x}{x^{2}\sqrt{1+x^{2}}}=\int\frac{-|t|}{\sqrt{1+t^{2}}}\mathrm{d}t=\sqrt{1+t^{2}}+C=-\frac{\sqrt{x^{2}+1}}{x}+C, $$ 

所以

 $$ \int\frac{\mathrm{d}x}{x^{2}\sqrt{1+x^{2}}}=-\frac{\sqrt{x^{2}+1}}{x}+C. $$ 