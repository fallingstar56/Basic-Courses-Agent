5. 求函数  $  F(x) = \int_{0}^{x} t e^{-t^{2}} \, dt  $ 的极值点与拐点.

6. 已知  $  F(x) = 3 + \int_{0}^{x} \frac{1 + \sin t}{2 + t^{2}} dt  $，求二次多项式  $  p(x)  $，使得

 $$ p(0)=F(0);p^{\prime}(0)=F^{\prime}(0);p^{\prime \prime}(0)=F^{\prime \prime}(0) $$ 

7. 已知  $ f(x)=\left\{\begin{aligned}&x+1,&x\in\left[-1,0\right),\\ &x,&x\in\left[0,1\right],\end{aligned}\right. $ 讨论函数  $ F(x)=\int_{-1}^{x}f(t)dt(-1\leqslant x\leqslant1) $ 的连续性与可导性.

8. 求下列极限.

(1)  $ \lim_{x \to 0} \frac{\int_{0}^{x} \cos t^2 dt}{x} $;

(2)  $ \lim_{x \to 0} \frac{\int_{0}^{2x} \ln(1 + t^2) dt}{x^2} $;

(3)  $ \lim_{x \to +\infty} \frac{\int_{0}^{x} \arctan t^2 dt}{x^2} $;

(4)  $ \lim_{x \to 0} \frac{\int_{\sin x}^{x} \sqrt{1 - t^2} dt}{x^3} $.

9. 设  $ f(x) $ 连续，解答下列问题.

(1) 若  $ f(x) = x + \int_{0}^{2} f(x) \, dx $，求  $ f(x) $;

(2) 证明  $ \int_{0}^{a} t^{3} f(t^{2}) dt = \frac{1}{2} \int_{0}^{a^{2}} t f(t) dt; $

(3) 若  $  f(x)  $ 在  $ [a, b] $ 无零点，证明  $  F(x) = \int_{a}^{x} f(x) \, \mathrm{d}x + \int_{b}^{x} \frac{1}{f(x)} \, \mathrm{d}x  $ 在  $ [a, b] $ 上仅有一个零点.

10. 设  $ f(x) \in C[a, b] $ 且单调递增，令  $ F(x) = \int_{a}^{x} f(t) \, dt. $  $ \forall x_{1}, x_{2} \in [a, b], x_{1} < x_{2} $，证明： $ F(x) $ 是  $ [a, b] $ 上的下凸函数

11. 已知  $ f(x) \in C^{2}[a,b] $，证明： $ \exists \xi \in [a,b] $，使得

 $$ \int_{a}^{b}f(x)\mathrm{d}x=f\Big(\frac{a+b}{2}\Big)(b-a)+\Big(\frac{(b-a)^{3}}{24}\Big)f^{\prime \prime}(\xi). $$ 

12. 用牛顿-莱布尼茨公式求下列积分.

12. 用牛顿-莱布尼茨公式求下列积分.

(1) $ \int_{0}^{2}|1-x|\,\mathrm{d}x; $ (2) $ \int_{-2}^{3}|x^{2}-2x-3|\,\mathrm{d}x; $

(3) $ \int_{0}^{\frac{3\pi}{4}}\sqrt{1+\cos2x}\,dx; $ (4) $ \int_{-\frac{\pi}{4}}^{\frac{\pi}{2}}\sqrt{1-\cos^{2}x}\,dx; $

(5) $ \int_{0}^{\pi}\sqrt{\sin x-\sin^{3}x}\,dx; $ (6) $ \int_{1}^{8}\frac{\ln x}{x}\,dx. $

13. 求下列极限.

(1)  $ \lim_{n\to\infty}\frac{1}{n}\left(\sin\frac{\pi}{n}+\sin\frac{2\pi}{n}+\cdots+\sin\frac{n\pi}{n}\right) $;