(3) 设  $ f \in C[a, b] $，则由(2)知， $ F(x) $ 是 f 在  $ [a, b] $ 上的一个原函数。现设 G 是 f 在  $ [a, b] $ 上的任一原函数，则

 $ [G(x)-F(x)]' = G'(x) - F'(x) = f(x) - f(x) \equiv 0, x \in [a, b] $

从而存在常数 C，使得  $ G(x)=F(x)+C. $ 由此可得  $ \forall x\in[a,b] $，有

 $$ G(a). $$ 

特别地，有

 $$ \int_{a}^{b}f(t)\mathrm{d}t=G(b)-G(a). $$ 

习惯上，将  $ G(b)-G(a) $ 写作  $ G(x) $，所以公式(1)又可以改写为

 $$ \int_{a}^{b}f(x)\mathrm{d}x=G(x)\bigg|_{a}^{b}. $$ 

注 从定理 5.3.1（2）的证明中不难看到，若  $ f \in R[a, b] $ 且在点  $ x_{0} \in [a, b] $ 处右（左）连续，则  $ F(x) = \int_{a}^{x} f(t) dt $ 在点  $ x_{0} $ 处存在右（左）导数.

设  $ f \in C[a, b] $， $ u(x) $ 与  $ v(x) $ 在  $ [a, b] $ 上可导，且  $ u(x) $ 与  $ v(x) $ 的值域包含于  $ [a, b] $。求下列函数的导数：

 $$ G(x)=\int_{v(x)}^{u(x)}f(t)\mathrm{d}t. $$ 

解 令  $  F(u) = \int_{a}^{u} f(t) dt  $，则由定理 5.3.1， $  F'(u) = f(u)  $， $  u \in [a, b]  $. 而

 $$ \begin{aligned}G(x)&=\int_{a}^{u(x)}f(t)\mathrm{d}t-\int_{a}^{v(x)}f(t)\mathrm{d}t\\&=F(u(x))-F(v(x)),\end{aligned} $$ 

于是由复合函数微分法得到

 $$ \begin{aligned}G^{\prime}(x)&=F^{\prime}(u(x))u^{\prime}(x)-F^{\prime}(v(x))v^{\prime}(x)\\&=f(u(x))u^{\prime}(x)-f(v(x))v^{\prime}(x).\end{aligned} $$ 

▶ 例 5.3.2 ……

 $ f \in C[a, b], F(x) = \int_{a}^{x} (x - t) f(t) \, dt $，求  $ F''(x) $.

解

 $$ F(x)=x\int_{a}^{x}f(t)\mathrm{d}t-\int_{a}^{x}t f(t)\mathrm{d}t. $$ 

故

 $ F'(x)=\int_{a}^{x}f(t)dt+xf(x)-xf(x)=\int_{a}^{x}f(t)dt, $



于是  $  F''(x) = f(x)  $.