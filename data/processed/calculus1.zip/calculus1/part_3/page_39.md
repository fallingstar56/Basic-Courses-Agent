#### 5.7.3 平面曲线的曲率

为了描述曲线的弯曲程度，我们引入曲率的概念。设 C 是一条光滑的平面

曲线(见图 5.7.6)，点 M 与  $ M_{1} $ 为 C 上任取的两点，记  $ \sigma $ 为弧段  $ \widehat{MM_{1}} $ 的弧长，曲线 C 在点 M 与  $ M_{1} $ 处的切线之间的夹角记为  $ \theta $，称  $ \theta $ 为 C 在弧段  $ \widehat{MM_{1}} $ 的切线转角。我们称比值  $ \frac{|\theta|}{\sigma} $ 为 C 在弧段  $ \widehat{MM_{1}} $ 的平均曲率。如果当  $ M_{1} $ 沿曲线 C 趋向于 M 时，极限

<div style="text-align: center;"><img src="imgs/img_in_image_box_458_164_631_312.jpg" alt="Image" width="24%" /></div>


 $$ k=\lim_{M_{1}\rightarrow M}|\frac{\theta}{\sigma}| $$ 

<div style="text-align: center;">图 5.7.6</div>


存在，则称此极限为曲线 C 在点 M 处的曲率.

现设 C 由参数方程  $ x = x(t) $,  $ y = y(t) $ ( $ a \leqslant t \leqslant b $) 确定,  $ M = M(x(t), y(t)) $,  $ M_{1} = M_{1}(x(t + \Delta t), y(t + \Delta t)) $, 则

 $$ \sigma=\int_{t}^{t+\Delta t}\sqrt{x^{^{\prime}}(u)^{2}+y^{^{\prime}}(u)^{2}}\mathrm{d}u, $$ 

 $$ \theta=\arctan\frac{y^{\prime}(t+\Delta t)}{x^{\prime}(t+\Delta t)}-\arctan\frac{y^{\prime}(t)}{x^{\prime}(t)}, $$ 

于是

 $$ k=\lim_{M_{1}\rightarrow M}\left|\frac{\theta}{\sigma}\right|=\lim_{\Delta t\rightarrow0}\left|\frac{\theta}{\Delta t}\right|\left|\frac{\frac{\mathrm{d}}{\mathrm{d}t}\left(\arctan\frac{y^{\prime}(t)}{x^{\prime}(t)}\right)}{\sqrt{\left(x^{\prime}(t)\right)^{2}+\left(y^{\prime}(t)\right)^{2}}}\right|, $$ 

即

 $$ k=\frac{\left|x^{\prime}(t)y^{\prime \prime}(t)-x^{\prime \prime}(t)y^{\prime}(t)\right|}{\left((x^{\prime}(t))^{2}+(y^{\prime}(t))^{2}\right)^{\frac{3}{2}}}. $$ 

这就是曲线 C 在点  $ M(x(t), y(t)) $ 处的曲率计算公式. 当 C 的方程为  $ y = f(x) $ 时，(9)式简化为

 $$ k=\frac{\left|f^{\prime \prime}(x)\right|}{(1+(f^{\prime}(x))^{2})^{\frac{3}{2}}}. $$ 

▶ 例 5.7.8

求圆  $ x = R \cos t $,  $ y = R \sin t $,  $ 0 \leqslant t \leqslant 2\pi $ 的曲率.

解 由曲率公式 $  (9)  $,

 $$ k=\frac{\left|x^{\prime}(t)y^{\prime \prime}(t)-x^{\prime \prime}(t)y^{\prime}(t)\right|}{\left((x^{\prime}(t))^{2}+(y^{\prime}(t))^{2}\right)^{\frac{3}{2}}}=\frac{1}{R}. $$ 