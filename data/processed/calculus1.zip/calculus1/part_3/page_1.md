根据二次多项式根与系数的关系可得  $ B^{2} \leqslant AC $. 即不等式(2)成立.

求证：

 $$ \frac{2}{\mathrm{e}}\leqslant\int_{-1}^{1}\mathrm{e}^{-x^{2}}\mathrm{d}x\leqslant2. $$ 

证明 易见， $ e^{-x^{2}} $ 在  $ [-1,1] $ 上的最小值是 1/e；最大值是  $ e^{0}=1 $。再应用性质 3 即得 (3) 式。

#### ▶ 例 5.2.2

设  $ f \in C[a-1, b+1] $，求证：

 $$ \lim_{t\to0}\int_{a}^{b}\mid f(x+t)-f(x)\mid\mathrm{d}x=0 $$ 

证明  $ f \in C[a-1, b+1] $，由定理 5.1.2 知 f 在  $ [a-1, b+1] $ 上一致连续。因此， $ \forall \varepsilon > 0, \exists \delta \in (0, 1) $，使得当  $ x, y \in [a-1, b+1] $ 且  $ |x - y| < \delta $ 时有

 $$ \mid f(x)-f(y)\mid<\varepsilon/(b-a). $$ 

从而当  $ x \in [a, b] $ 且  $ |t| < \delta $ 时

 $$ \int_{a}^{b}\mid f(x+t)-f(x)\mid\mathrm{d}x<\int_{a}^{b}\frac{\varepsilon}{(b-a)}\mathrm{d}x=\varepsilon. $$ 

即(4)式成立.

#### ▶ 例 5.2.3

设  $ f \in C[a, b] $，求证：

 $$ \left(\int_{a}^{b}f(x)\cos x\mathrm{d}x\right)^{2}+\left(\int_{a}^{b}f(x)\sin x\mathrm{d}x\right)^{2}\leqslant\left(\int_{a}^{b}\left|f(x)\right|\mathrm{d}x\right)^{2}. $$ 

证明 应用柯西不等式，

 $$ \begin{align*}\left(\int_{a}^{b}f(x)\cos x\mathrm{d}x\right)^{2}&\leqslant\left[\int_{a}^{b}\sqrt{\mid f(x)\mid}\bullet\left(\sqrt{\mid f(x)\mid}\cos x\right)\mathrm{d}x\right]^{2}\\&\leqslant\int_{a}^{b}\mid f(x)\mid\mathrm{d}x\bullet\int_{a}^{b}\mid f(x)\mid\cos^{2}x\mathrm{d}x.\end{align*} $$ 

同理，

 $$ \left(\int_{a}^{b}f(x)\sin x\mathrm{d}x\right)^{2}\leqslant\int_{a}^{b}\left|f(x)\right|\mathrm{d}x\bullet\int_{a}^{b}\left|f(x)\right|\sin^{2}x\mathrm{d}x. $$ 

二式相加，即得不等式(5).

定理 5.2.2（积分第一中值定理）

设  $ f \in C[a, b], g \in R[a, b] $ 且  $ g(x) $ 在  $ [a, b] $ 上不变号，则存在  $ \xi \in [a, b] $ 使

 $$ \int_{a}^{b}f(x)g(x)\mathrm{d}x=f(\xi)\int_{a}^{b}g(x)\mathrm{d}x. $$ 