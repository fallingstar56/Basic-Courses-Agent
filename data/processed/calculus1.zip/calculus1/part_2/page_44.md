证明  $ f(x)=\sin\frac{1}{x} $ 在  $ (0,1) $ 上不一致连续.

证明  $ \forall n\in\mathbb{N}^{*} $，取  $ x_{n}=\frac{1}{2n\pi+\frac{\pi}{2}} $， $ y_{n}=\frac{1}{2n\pi} $，则  $ x_{n},y_{n}\in(0,1) $，并且

 $$ y_{n}-x_{n}=\frac{1}{2n\pi}-\frac{1}{2n\pi+\frac{\pi}{2}}<\frac{1}{n^{2}}, $$ 

 $$ f(x_{n})-f(y_{n})=\sin\frac{1}{x_{n}}-\sin\frac{1}{y_{n}}=\sin\left(2n\pi+\frac{\pi}{2}\right)=1. $$ 

所以，若取  $ 0 < \varepsilon < 1 $，则  $ \forall \delta > 0 $，只要  $ 1/n^{2} < \delta $，便有  $ |x_{n} - y_{n}| < \delta $，并且

 $$ f(x_{n})-f(y_{n})=1>\epsilon. $$ 

所以  $ f(x)=\sin\frac{1}{x} $ 在  $ (0,1) $ 上不一致连续.

设 f 在闭区间  $ [a, b] $ 上连续，则 f 在  $ [a, b] $ 上一致连续.

证明 假定 f 在  $ [a, b] $ 上不是一致连续的，即存在  $ \varepsilon_0 > 0 $，使得  $ \forall \delta > 0 $，都可以找到  $ x_\delta, y_\delta \in [a, b] $ 满足  $ |x_\delta - y_\delta| < \delta $，并且

 $$ \mid f(x_{\delta})-f(y_{\delta})\mid\geqslant\varepsilon_{0}. $$ 

分别取  $ \delta=1,\frac{1}{2},\cdots,\frac{1}{n},\cdots $ ,则得  $ [a,b] $ 中两个点列  $ x_{1},x_{2},\cdots,x_{n},\cdots $ 与  $ y_{1},y_{2},\cdots,y_{n},\cdots $ ，满足  $ \left|x_{n}-y_{n}\right|<\frac{1}{n} $ 并且

 $$ f(x_{n})-f(y_{n})\mid\geqslant\varepsilon_{0}(n=1,2,\cdots). $$ 

由于 $ \{x_{n}\} $有界，故存在收敛子列（定理1.5.1） $ \{x_{n_{k}}\}:x_{n_{k}}\to x_{0}\in[a,b] $.再由 $ |x_{n}-y_{n}|<\frac{1}{n} $知 $ y_{n_{k}}\to x_{0} $.而f在点 $ x_{0} $连续，于是

 $$ \lim_{k\to\infty}(f(x_{n_{k}})-f(y_{n_{k}}))\to f(x_{0})-f(x_{0})=0, $$ 

这与(11)式相矛盾. 所以 f 在  $ [a,b] $ 上一致连续.

设  $ f \in C[a, +\infty) $，且  $ \lim_{x \to +\infty} f(x) = A $。试证明  $ f(x) $ 在  $ [a, +\infty) $ 上一致连续。

证明  $ \forall \varepsilon > 0 $ ，由于  $ \lim_{x \to +\infty} f(x) = A, \exists M \geqslant a $ ，使得当  $ x \geqslant M $ 时，有

 $$ \mid f(x)-A\mid<\frac{\varepsilon}{4}, $$ 