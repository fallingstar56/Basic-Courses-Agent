性质 2(积分区间的可加性)

设  $ a < c < b $，则  $ f \in R[a, b] $ 当且仅当  $ f \in R[a, c] $ 和  $ f \in R[c, d] $ 同时成立。此时有

 $$ \int_{a}^{b}f(x)\mathrm{d}x=\int_{a}^{c}f(x)\mathrm{d}x+\int_{c}^{b}f(x)\mathrm{d}x. $$ 

证明 若  $ f \in R[a, c] $ 且  $ f \in R[c, b] $，根据定理 5.1.1， $ \forall \varepsilon > 0 $，存在  $ [a, c] $ 的分割  $ T_{1} $ 与  $ [c, b] $ 的分割  $ T_{2} $ 使得

 $$ U(f,T_{1})-L(f,T_{1})<\frac{\varepsilon}{2}\quad 且 \quad U(f,T_{2})-L(f,T_{2})<\frac{\varepsilon}{2}, $$ 

将  $ T_{1} $ 与  $ T_{2} $ 的分点合并即得  $ [a,b] $ 的分割 T，此时

 $ U(f,T)-L(f,T)=\left[U(f,T_{1})-L(f,T_{1})\right]+\left[U(f,T_{2})-L(f,T_{2})\right]<\varepsilon. $

再由定理 5.1.1 便知  $ f \in R[a, b] $.

反之，若  $ f \in R[a, b] $，则由定理 5.1.1， $ \forall \varepsilon > 0 $，存在  $ [a, b] $ 的分割 T 使得

 $$ U(f,T)-L(f,T)<\epsilon. $$ 

记 T 在  $ [a, c] $ 部分的限制为  $ T_{1} $，记 T 在  $ [c, b] $ 部分的限制为  $ T_{2} $，则

 $$ U(f,T_{1})-L(f,T_{1})<\varepsilon\quad 且 \quad U(f,T_{2})-L(f,T_{2})<\varepsilon, $$ 

从而  $ f \in R[a, c] $ 且  $ f \in R[c, b] $. 此时， $ |T| \to 0 $ 当且仅当  $ |T_1| \to 0 $ 且  $ |T_2| \to 0 $，故有

 $$ \begin{aligned}\int_{a}^{b}f(x)\mathrm{d}x&=\lim_{|T|\to0}\sigma(f,T)\\&=\lim_{|T_{1}|\to0}\sigma(f,T_{1})+\lim_{|T_{2}|\to0}\sigma(g,T_{2})\\&=\int_{a}^{c}f(x)\mathrm{d}x+\int_{v}^{b}f(x)\mathrm{d}x.\end{aligned} $$ 

性质 3(单调性)

设  $ f, g \in R[a, b] $. 如果在  $ [a, b] $ 上  $ f(x) \leqslant g(x) $，则有

 $$ \int_{a}^{b}f(x)\mathrm{d}x\leqslant\int_{a}^{b}g(x)\mathrm{d}x. $$ 

特别地，如果存在常数 m, M，使得  $ m \leqslant f(x) \leqslant M (a \leqslant x \leqslant b) $，则有

 $$ m(b-a)\leqslant\int_{a}^{b}f(x)\mathrm{d}x\leqslant M(b-a). $$ 

证明 在 $ [a,b] $上  $ g(x)-f(x)\geqslant0 $，于是由性质1，

 $$ \int_{a}^{b}g(x)\mathrm{d}x-\int_{a}^{b}f(x)\mathrm{d}x=\int_{a}^{b}(g(x)-f(x))\mathrm{d}x=\lim_{|T|\to0}\sigma(g-f,T)\geqslant0. $$ 

性质4

设  $ f \in R[a, b] $，则  $ |f| \in R[a, b] $，并且  $ \left|\int_{a}^{b} f(x) \, dx\right| \leqslant \int_{a}^{b} |f(x)| \, dx. $

证明 根据性质 3，只需证  $ |f| \in R[a, b] $ 即可。注意到对于  $ [a, b] $ 的任何分割 T:  $ a = x_0 < x_1 < \cdots < x_n = b $，