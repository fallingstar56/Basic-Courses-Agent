(3) $ \lim_{x\to\frac{\pi}{2}}\frac{\sqrt{1+2\cos x}-1}{x-\frac{\pi}{2}}; $

(4)  $ \lim_{x \to +\infty} \frac{\ln(1 + e^x)}{x^2} $;

(5)  $ \lim_{x \to \frac{1}{\sqrt{2}}} \frac{(\arcsin x)^2 - \frac{\pi^2}{16}}{2x^2 - 1} $;

(6) $ \lim_{x\to0}\frac{x-\sin x}{x^{3}} $;

(7)  $ \lim_{x\to0}\frac{\cos\alpha x-\cos\beta x}{\ln(1+x^2)} $;

(8)  $ \lim_{x\to0}\frac{e^x-x-1}{x(e^x-1)} $;

(9)  $ \lim_{x \to +\infty} (x - \sqrt{x^2 + x}) $;

(10) $ \lim_{x\to+\infty}\frac{\ln(1+x)}{x^{2}} $;

(11)  $ \lim_{x \to 0} \left( \cot x - \frac{1}{x} \right) $;

(12)  $ \lim_{x \to \frac{\pi}{2}} (\sec x - \tan x) $;

(13)  $ \lim_{x\to1}(x-1)\tan\frac{\pi x}{2} $;

(14)  $ \lim_{x\to0^{+}}x\ln x $;

(15)  $ \lim_{x \to +\infty} (\pi - 2 \arctan x) \ln x $;

(16)  $ \lim_{x \to \infty} x \ln \frac{1 + x}{x} $;

(17)  $ \lim_{x \to \frac{\pi}{2}} \left( \frac{\pi}{x} - 1 \right)^{\tan x} $;

(18)  $ \lim_{x \to 1^-}(1 - x)^{\ln x} $;

(19)  $ \lim_{x \to \infty} \left( \cos \frac{1}{x} \right)^{x^2} $;

(20)  $ \lim_{n \to \infty} n \left[ \left( 1 + \frac{1}{n} \right)^n - e \right] $.

3. 设  $ f(x) $ 二阶可导，求极限： $ \lim_{h\to0}\frac{f(a+h)-2f(a)+f(a-h)}{h^{2}} $

4. 设  $ f(x) $ 可导，且  $ f(0)=f'(0)=1 $，求极限： $ \lim_{x\to0}\frac{f(\sin x)-1}{\ln f(x)} $

### 4.3 泰勒公式

在第 3 章讨论微分时我们看到，如果  $ f'(x_{0}) $ 存在，则当  $ x \to x_{0} $ 时，有

 $$ f(x)=f(x_{0})+f^{\prime}(x_{0})(x-x_{0})+o(x-x_{0}). $$ 

这表明在  $ x_{0} $ 点附近  $ f(x) $ 可以用一个较为简单的一阶多项式

 $$ P_{1}(x)=f(x_{0})+f^{\prime}(x_{0})(x-x_{0}) $$ 

来逼近，其误差为  $ o(x-x_{0}) $。从几何上看，就是用曲线  $ y=f(x) $ 过点  $ (x_{0}, f(x_{0})) $ 的切线来逼近曲线。然而这样的逼近在精度上对许多理论与应用问题是不够的。为了提高逼近精度，人们希望用一个高阶多项式在  $ x_{0} $ 点附近来逼近  $ f(x) $，这就是本节所要讨论的泰勒公式。

#### 4.3.1 函数在一点处的泰勒公式

设函数 f 在点  $ x_{0} $ 处有 n 阶导数，称