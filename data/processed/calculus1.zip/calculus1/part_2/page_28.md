<div style="text-align: center;"><img src="imgs/img_in_image_box_286_97_456_216.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;">图 4.5.1</div>


凸函数的概念也可以用解析表达式描述如下.

定义 4.5.1

设函数 f 在区间 I 上定义. 如果对任意的  $ x_{1}, x_{2} \in I $，以及任意正数  $ \lambda \in (0,1) $，都有

 $$ f(\lambda x_{1}+(1-\lambda)x_{2})\leqslant\lambda f(x_{1})+(1-\lambda)f(x_{2}), $$ 

则称 f 是区间 I 上的下凸函数.

若将(1)式中的不等号“ $ \leqslant $”换为“ $ \geqslant $”，则称 f 是区间 I 上的上凸函数.

不等式(1)可以推广为下列形式.

定理 4.5.1

f 为区间 I 上的下凸函数当且仅当对于 I 中的任意 n 个点  $ x_{1}, x_{2}, \cdots, x_{n} $，以及任意满足  $ \lambda_{1} + \lambda_{2} + \cdots + \lambda_{n} = 1 $ 的 n 个正数  $ \lambda_{1}, \lambda_{2}, \cdots, \lambda_{n} $，都有

 $$ f(\lambda_{1}x_{1}+\lambda_{2}x_{2}+\cdots+\lambda_{n}x_{n})\leqslant\lambda_{1}f(x_{1})+\lambda_{2}f(x_{2})+\cdots+\lambda_{n}f(x_{n}). $$ 

证明 充分性显然，下面证明必要性. 对 n=1,2,(2) 式显然成立. 假设 (2) 式对于 n=k 成立，则对于  $ n=k+1 $，根据 f 的下凸性质，

 $$ \begin{align*}f(\lambda_{1}x_{1}+\cdots+\lambda_{k+1}x_{k+1})&=f\Big(\lambda_{k+1}x_{k+1}+(1-\lambda_{k+1})\frac{\lambda_{1}x_{1}+\cdots+\lambda_{k}x_{k}}{1-\lambda_{k+1}}\Big)\\&\leqslant\lambda_{k+1}f(x_{k+1})+(1-\lambda_{k+1})f\Big(\frac{\lambda_{1}x_{1}+\cdots+\lambda_{k}x_{k}}{1-\lambda_{k+1}}\Big).\end{align*} $$ 

由于 $ \frac{\lambda_{1}}{1-\lambda_{k+1}}+\cdots+\frac{\lambda_{k}}{1-\lambda_{k+1}}=1 $，根据归纳假设，

 $$ f\Big(\frac{\lambda_{1}x_{1}+\cdots+\lambda_{k}x_{k}}{1-\lambda_{k+1}}\Big)\leqslant\frac{\lambda_{1}}{1-\lambda_{k+1}}f(x_{1})+\cdots+\frac{\lambda_{k}}{1-\lambda_{k+1}}f(x_{k}). $$ 

代入3式，即得

 $$ f(\lambda_{1}x_{1}+\cdots+\lambda_{k+1}x_{k+1})\leqslant\lambda_{1}f(x_{1})+\cdots+\lambda_{k+1}f(x_{k+1}), $$ 

所以，(2)式对于 $ n=k+1 $也成立。根据数学归纳法，(2)式对于每个正整数n皆成立。