 $$ y=\ln\frac{1+x}{1-x}; $$ 

(4)  $ y = x + \arctan x $;

(5) $ y=\sqrt{x^{4}-3x^{2}+4} $;

(6)  $ y = x^{2} e^{-x} $;

(7) $ y=\frac{(x-1)^{3}}{2(x+1)^{2}} $;

(8)  $ y = \sin^4 x + \cos^4 x. $

## 第 4 章 总复习题

1. 设函数  $ f(x) $ 在  $ (a, +\infty) $ 内可导，证明：

(1) 若  $ \lim_{x\to+\infty}f'(x)=0 $，则  $ \lim_{x\to+\infty}\frac{f(x)}{x}=0 $;

(1) 若  $ \lim_{x\to+\infty}\frac{f(x)}{x}=0 $，则  $ \exists\{x_{n}\},\lim_{n\to\infty}x_{n}=+\infty $，使得  $ \lim_{n\to\infty}f'(x_{n})=0 $.

2. 设函数  $  f(x)  $ 在  $ [0, +\infty) $ 上有二阶连续导数，且  $  f''(x) \geqslant a > 0  $， $  f(0) = 0  $， $  f'(0) < 0  $，问： $  f(x)  $ 在  $  (0, +\infty)  $ 内有多少个零点？

3. 证明：n 阶拉盖尔多项式  $ \mathrm{L}_{n}(x)=\mathrm{e}^{x}\frac{\mathrm{d}^{n}}{\mathrm{d}x^{n}}(x^{n}\mathrm{e}^{-x})(n=1,2,\cdots) $ 在  $ \mathbb{R} $ 内恰有 n 个不同的实根.

4. 设函数  $ f(x) $ 在  $ [0, +\infty) $ 上可导， $ 0 \leqslant f(x) \leqslant \frac{x}{1 + x^{2}} $，证明： $ \exists \xi > 0 $，使得

 $$ f^{\prime}(\xi)=\frac{1-\xi^{2}}{(1+\xi^{2})^{2}}. $$ 

5.（广义柯西中值定理）设函数  $ f(x) $， $ g(x) $ 在  $ \mathbb{R} $ 上可导，它们在  $ -\infty, +\infty $ 处分别存在有限的极限。又设当  $ x \in \mathbb{R} $ 时， $ g'(x) \neq 0 $。证明： $ \exists \xi \in \mathbb{R} $，使得

 $$ \frac{f(+\infty)-f(-\infty)}{g(+\infty)-g(-\infty)}=\frac{f^{\prime}(\xi)}{g^{\prime}(\xi)}. $$ 

6. 设  $ f(x) $,  $ g(x) $ 在  $ [a, b] $ 上可导，且  $ g(x) \neq 0 $,  $ g'(x) \neq 0 $，证明： $ \exists \xi \in (a, b) $，使得

 $$ g^{^{\prime}}(\xi)\left|\begin{matrix}f(a)&f(b)\\ g(a)&g(b)\end{matrix}\right|=(g(b)-g(a))\left|\begin{matrix}f(\xi)&g(\xi)\\ f^{\prime}(\xi)&g^{\prime}(\xi)\end{matrix}\right|. $$ 

7. 设  $ 0 < a < b $,  $ f(x) $ 在  $ [a, b] $ 上连续,  $ (a, b) $ 内可导, 证明  $ \exists \xi \in (a, b) $, 使得

 $$ \frac{1}{b-a}\left|\begin{matrix}{{{a}}}&{{{b}}} \\{{{f(a)}}}&{{{f(b)}}}\end{matrix}\right|=\xi f^{\prime}(\xi)-f(\xi). $$ 

8. 已知  $ f(x) $ 在  $ [a, b] $ 上可导， $ a^{2} \neq b^{2} $，求证：存在  $ \xi, \eta \in (a, b) $，使得  $ f'(\xi) = \frac{a + b}{2\eta} f'(\eta) $.

9. 设函数  $ y = f(x) $ 在  $ [0, 1] $ 上二阶可导， $ f(0) = f(1) $，且  $ \left|f''(x)\right| \leqslant M $， $ \forall x \in [0, 1] $. 求证： $ \left|f'(x)\right| \leqslant \frac{M}{2} $.