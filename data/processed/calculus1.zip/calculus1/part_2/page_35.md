下凸.

在 $ (-∞,-1) $与 $ (1,+∞) $内， $ f'(x)>0 $，因此f在 $ (-∞,-1) $与 $ (1,+∞) $内严格单调递增；在 $ (-1,0) $与 $ (0,1) $内， $ f'(x)<0 $，因此f在 $ (-1,0) $与 $ (0,1) $内严格单调递减。此外，

 $$ \lim_{x\to0}f(x)=\infty,\lim_{x\to\infty}\frac{f(x)}{x}=1,\quad\lim_{x\to\infty}\left[f(x)-x\right]=2, $$ 

所以直线 x=0 是  $ f(x) $ 的竖直渐近线，直线  $ y=x+2 $ 为  $ f(x) $ 的斜渐近线。


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>x</td><td style='text-align: center; word-wrap: break-word;'>(-∞,-1)</td><td style='text-align: center; word-wrap: break-word;'>-1</td><td style='text-align: center; word-wrap: break-word;'>(-1,0)</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>(0,1)</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>(1,+∞)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f(x)</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>+</td><td style='text-align: center; word-wrap: break-word;'>+</td><td style='text-align: center; word-wrap: break-word;'>+</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f&#x27;(x)</td><td style='text-align: center; word-wrap: break-word;'>+</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>+</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f(x)</td><td style='text-align: center; word-wrap: break-word;'>上凸↗</td><td style='text-align: center; word-wrap: break-word;'>零点,极大值</td><td style='text-align: center; word-wrap: break-word;'>上凸↘</td><td style='text-align: center; word-wrap: break-word;'>无定义</td><td style='text-align: center; word-wrap: break-word;'>下凸↘</td><td style='text-align: center; word-wrap: break-word;'>极小值</td><td style='text-align: center; word-wrap: break-word;'>下凸↗</td></tr></table>

 $ f(x) $ 的简图如下(图 4.6.2):

<div style="text-align: center;"><img src="imgs/img_in_image_box_234_422_502_638.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;">图 4.6.2</div>


### 习题 4.6

1. 求下列函数的渐近线.

 $$ (1)y=\sqrt{\frac{x^{3}}{x-1}};\quad(2)y=\sqrt{x^{2}+1}-x-1;\quad(3)\left\{\begin{aligned}x&=\frac{3t}{1+t^{3}},\\ y&=\frac{3t^{2}}{1+t^{3}}.\end{aligned}\right. $$ 

2. 作出下列函数的图形.

(1)

 $$ y=x^{3}+6x^{2}-15x-20； $$ 

(2)

 $$ y=\frac{3x}{1+x^{2}}; $$ 