 $$ L(f,T)=\sum_{i=1}^{n}m_{i}(x_{i}-x_{i-1}); $$ 

 $$ \sigma(f,T)=\sum_{i=1}^{n}f(\xi_{i})(x_{i}-x_{i-1}). $$ 

分别称  $ U(f,T) $、 $ L(f,T) $ 与  $ \sigma(f,T) $ 为函数 f（在  $ [a,b] $ 上）关于分割 T 的大和、小和与黎曼和. 显然，

 $$ m(b-a)\leqslant L(f,T)\leqslant\sigma(f,T)\leqslant U(f,T)\leqslant M(b-a). $$ 

命题 5.1.1

设 f 在  $ [a, b] $ 上有界，且分别以 M、m 为上、下确界，T 为  $ [a, b] $ 的任一分割， $ T_{k} $ 是在 T 的分点组中再加入 k 个新分点所得到的  $ [a, b] $ 的分割，则有

 $$ 0\leqslant U(f,T)-U(f,T_{k})\leqslant k\mid T\mid(M-m); $$ 

 $$ 0\leqslant L(f,T_{k})-L(f,T)\leqslant k\mid T\mid(M-m). $$ 

证明 对于 k=1，即  $ T_{1} $ 的分点组是在 T 的分点组  $ \{x_{0}, x_{1}, \cdots, x_{n}\} $ 中加入一个新分点 t:  $ x_{i-1} < t < x_{i} $，于是

 $$ \begin{align*}0\leqslant U(f,T)-U(f,T_{1})&=M_{i}(x_{i}-x_{i-1})-\sup_{x_{i-1}\leqslant x\leqslant t}f(x)(t-x_{i-1})\\&-\sup_{t\leqslant x\leqslant x_{i}}f(x)(x_{i}-t)\leqslant M_{i}(x_{i}-x_{i-1})-m_{i}(x_{i}-x_{i-1})\\&=(x_{i}-x_{i-1})(M_{i}-m_{i})\leqslant\mid T\mid(M-m),\quad(4)\end{align*} $$ 

对于 k > 1 的情形，将 T 加入一个新分点记为  $ T_{1}, T_{1} $ 加入一个新分点记为  $ T_{2}, \cdots, T_{k-1} $ 加入一个新分点记为  $ T_{k} $. 注意到  $ \left|T_{i}\right| \leqslant \left|T\right| $ ( $ 1 \leqslant i \leqslant k-1 $), 再由 (4) 式即得

 $$ \begin{aligned}&0\leqslant U(f,T)-U(f,T_{k})=\left[U(f,T)-U(f,T_{1})\right]+\left[U(f,T_{1})-U(f,T_{2})\right]\\ &+\cdots+\left[U(f,T_{k-1})-U(f,T_{k})\right]\leqslant k\mid T\mid(M-m).\\ \end{aligned} $$ 

即(2)式成立.同理可证(3)式.

命题 5.1.2

设 f 在  $ [a,b] $ 上有界， $ T_{1}, T_{2} $ 为  $ [a,b] $ 的任意两个分割，则有

 $$ L(f,T_{1})\leqslant U(f,T_{2}). $$ 

证明 将  $ T_{1} $ 与  $ T_{2} $ 的分点合并得到一个新分割 T，则由命题 5.1.1，

 $$ L(f,T_{1})\leqslant L(f,T)\leqslant U(f,T)\leqslant U(f,T_{2}). $$ 

定义 5.1.2

设 f 是  $ [a, b] $ 上的有界函数，分别称

 $$ \begin{aligned}\overline{\int}_{a}^{b}f(x)\mathrm{d}x&=\inf\{U(f,T)\mid T 为 [a,b] 的分割 \},\\\underline{\int}_{a}^{b}f(x)\mathrm{d}x&=\sup\{L(f,T)\mid T 为 [a,b] 的分割 \}\end{aligned} $$ 

为 f 在  $ [a,b] $ 上的上积分与下积分.