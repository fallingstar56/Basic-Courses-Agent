<div style="text-align: center;"><img src="imgs/img_in_image_box_229_93_507_263.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">图 4.3.1</div>


▶ 例 4.3.3 ……

写出  $ f(x)=\ln(1+x) $ 带皮亚诺余项的 n 阶麦克劳林公式.

解

 $$ f^{(k)}(x)=(-1)^{k-1}(k-1)!(1+x)^{-k}\quad(k=1,2,\cdots), $$ 

所以

 $$ \ln(1+x)=x-\frac{x^{2}}{2}+\frac{x^{3}}{3}-\cdots+(-1)^{n-1}\frac{x^{n}}{n}+o(x^{n}). $$ 

▶ 例 4.3.4

写出  $ f(x)=(1+x)^{a}(a\neq0) $ 带皮亚诺余项的 n 阶麦克劳林公式.

解

 $$ f^{(k)}(x)=a(a-1)\cdots(a-k+1)(1+x)^{a-k}\quad(k=1,2,\cdots), $$ 

所以

 $$ (1+x)^{a}=1+ax+\frac{a(a-1)}{2!}x^{2}+\cdots+\frac{a(a-1)\cdots(a-n+1)}{n!}x^{n}+o(x^{n}). $$ 

下面的定理表明，f 在点  $ x_{0} $ 的 n 阶泰勒多项式是唯一的。

定理 4.3.3

设 f 在点  $ x_{0} $ 有 n 阶导数，并且存在 n 阶多项式  $ Q_{n}(x) $，使得

 $$ f(x)=Q_{n}(x)+o((x-x_{0})^{n})(x\rightarrow x_{0}), $$ 

则  $ Q_{n}(x) $ 即为 f 在点  $ x_{0} $ 的 n 阶泰勒多项式  $ P_{n}(x) $.

证明 根据定理 4.3.1, f 在点  $ x_{0} $ 带皮亚诺余项的 n 阶泰勒公式为

 $$ f(x)=P_{n}(x)+o((x-x_{0})^{n})(x\rightarrow x_{0}). $$ 

比较(5)式与(6)式可得

 $$ P_{n}(x)-Q_{n}(x)=o((x-x_{0})^{n})(x\rightarrow x_{0}). $$ 

由于  $ P_{n}(x)-Q_{n}(x)=a_{0}+a_{1}(x-x_{0})+\cdots+a_{n}(x-x_{0})^{n} $ 是关于  $ x-x_{0} $ 的 n 阶