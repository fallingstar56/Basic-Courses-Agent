#### ▶ 例 4.2.2

计算 $ \lim_{x\to0}\frac{e^{x}-e^{-x}-2x}{x-\sin x} $

解 逐次应用洛必达法则可得

 $$ \begin{aligned}\lim_{x\to0}\frac{\mathrm{e}^{x}-\mathrm{e}^{-x}-2x}{x-\sin x}&=\lim_{x\to0}\frac{\mathrm{e}^{x}+\mathrm{e}^{-x}-2}{1-\cos x}\\&=\lim_{x\to0}\frac{\mathrm{e}^{x}-\mathrm{e}^{-x}}{\sin x}=\lim_{x\to0}\frac{\mathrm{e}^{x}+\mathrm{e}^{-x}}{\cos x}=2.\end{aligned} $$ 

定理 4.2.2 ……

设函数  $ f, g $ 在  $ (x_{0}, x_{0} + \rho) $ 上可导， $ g'(x) \neq 0 $，且当  $ x \to x_{0}^{+} $ 时， $ g(x) \to \infty $。如果

 $$ \lim_{x\to x_{0}^{+}}\frac{f^{\prime}(x)}{g^{\prime}(x)}=A, $$ 

则

 $$ \lim_{x\to x_{0}^{+}}\frac{f(x)}{g(x)}=A. $$ 

证明 由于  $ \lim_{x\to x_{0}^{+}}\frac{f'(x)}{g'(x)}=A,\forall\varepsilon>0,\exists\delta>0, $ 只要  $ t\in(x_{0},x_{0}+\delta) $，便有

 $$ \left|\frac{f^{^{\prime}}(t)}{g^{^{\prime}}(t)}-A\right|<\frac{\varepsilon}{4}. $$ 

 $ \forall x\in(x_{0},x_{0}+\delta) $，对 f 与 g 在闭区间  $ [x,x_{0}+\delta] $ 上应用柯西中值定理得

 $$ \frac{f(x)-f(x_{0}+\delta)}{g(x)-g(x_{0}+\hat{\delta})}=\frac{f^{\prime}(\xi_{x})}{g^{\prime}(\xi_{x})}\quad(x<\xi_{x}<x_{0}+\hat{\delta}). $$ 

另一方面，

 $$ \begin{align*}\frac{f(x)}{g(x)}-A&=\frac{f(x)-f(x_{0}+\delta)}{g(x)-g(x_{0}+\delta)}\bullet\frac{g(x)-g(x_{0}+\delta)}{g(x)}+\frac{f(x_{0}+\delta)}{g(x)}-A\\&=\left(\frac{f^{\prime}(\xi_{x})}{g^{\prime}(\xi_{x})}-A\right)\bullet\left(1-\frac{g(x_{0}+\delta)}{g(x)}\right)\\&\quad+\frac{f(x_{0}+\delta)-A g(x_{0}+\delta)}{g(x)}.\end{align*} $$ 

由于  $  g(x) \to \infty (x \to x_{0}^{+})  $，故  $ \exists \delta_{1} \in (0, \delta] $，只要  $  x \in (x_{0}, x_{0} + \delta_{1})  $，便有

 $$ \left|\frac{f(x_{0}+\delta)-A g(x_{0}+\delta)}{g(x)}\right|<\frac{\varepsilon}{2},\left|\frac{g(x_{0}+\delta)}{g(x)}\right|<1. $$ 

结合(1)、(2)与(3)式可得，当 $ x\in(x_{0},x_{0}+\delta_{1}) $时，

 $$ \left|\frac{f(x)}{g(x)}-A\right|<\varepsilon, $$ 