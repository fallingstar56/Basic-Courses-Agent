### 4.2 洛必达法则

在第2章我们已经看到，在某个极限过程中（例如 $ x\to x_{0} $时），如果 $ f(x)\to0 $， $ g(x)\to0 $，这时 $ \frac{f(x)}{g(x)} $的极限非常复杂，我们通常称之为 $ \frac{0}{0} $型的不定型。类似地，如果 $ f(x)\to\infty $， $ g(x)\to\infty $，则称 $ \frac{f(x)}{g(x)} $的极限为 $ \infty $。型的不定型。本节中我们介绍求不定型极限的一种重要方法——洛必达法则。

设函数  $  f, g  $ 在  $ (x_{0}, x_{0} + \rho) $ 上可导， $  g'(x) \neq 0  $，且  $ \lim_{x \to x_{0}^{+}} f(x) = \lim_{x \to x_{0}^{+}} g(x) = 0. $

如果

 $$ \lim_{x\to x_{0}^{+}}\frac{f^{\prime}(x)}{g^{\prime}(x)}=A, $$ 

则

 $$ \lim_{x\to x_{0}^{+}}\frac{f(x)}{g(x)}=A. $$ 

证明 不妨设  $ f(x_{0})=g(x_{0})=0 $，则  $ \forall x\in(x_{0},x_{0}+\rho) $，f 和 g 在闭区间  $ [x_{0},x] $ 上连续。根据柯西中值定理，存在  $ \xi_{x}\in(x_{0},x) $，使得

 $$ \frac{f(x)}{g(x)}=\frac{f(x)-f(x_{0})}{g(x)-g(x_{0})}=\frac{f^{\prime}(\xi_{x})}{g^{\prime}(\xi_{x})}. $$ 

注意到当  $ x \rightarrow x_{0}^{+} $ 时， $ \xi_{x} \rightarrow x_{0}^{+} $，于是由定理条件得到

 $$ \lim_{x\to x_{0}^{+}}\frac{f(x)}{g(x)}=\lim_{x\to x_{0}^{+}}\frac{f^{\prime}(\xi_{x})}{g^{\prime}(\xi_{x})}=A. $$ 

注 (1)从定理 4.2.1 的证明中不难发现, 如果将其中的区间  $ (x_{0}, x_{0} + \rho) $ 换成  $ (x_{0} - \rho, x_{0}) $, 右极限  $ \lim $ 换成左极限  $ \lim $ , 则相应的结论仍然成立.

 $$ x\rightarrow x_{0}^{+} $$ 

 $$ x-x_{0} $$ 

(2) 进而知，将定理 4.2.1 中的区间  $ (x_{0}, x_{0} + \rho) $ 换成空心邻域  $ U(x_{0}, \rho) $，右极限  $ \lim_{x \to x_{0}^{+}} $ 换成双边极限  $ \lim_{x \to x_{0}} $，则相应的结论也成立.

计算 $ \lim_{x\to0}\frac{x\cos x-\sin x}{x^{3}} $

解  $ \lim_{x\to0}\frac{x\cos x-\sin x}{x^{3}}=\lim_{x\to0}\frac{(x\cos x-\sin x)^{\prime}}{(x^{3})^{\prime}}=\lim_{x\to0}\frac{-x\sin x}{3x^{2}}=-\frac{1}{3}. $