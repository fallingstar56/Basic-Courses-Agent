4. 讨论由参数方程给出的函数 $ \left\{\begin{aligned}x=3\cos^{3}t,\\ y=3\sin^{3}t\end{aligned}\right. $  $ (0\leqslant t\leqslant\pi) $ 的凸性.

5. 证明下列不等式.

(1)  $ a > 0, x_{1}, x_{2} \in \mathbb{R} $，有  $ a^{\frac{x_{1} + x_{2}}{2}} \leqslant \frac{1}{2}(a^{x_{1}} + a^{x_{2}}) $;

(2) $ x_{1},x_{2},\cdots,x_{n}\geqslant0,p\geqslant1 $，有 $ \left(\frac{x_{1}+x_{2}+\cdots+x_{n}}{n}\right)^{p}\leqslant\frac{x_{1}^{p}+x_{2}^{p}+\cdots+x_{n}^{p}}{n} $;

(3)  $ x_{1}^{a_{1}}x_{2}^{a_{2}}\cdots x_{n}^{a_{n}}\leqslant a_{1}x_{1}+a_{2}x_{2}+\cdots+a_{n}x_{n}, $

其中  $ x_{1}, x_{2}, \cdots, x_{n} \geqslant 0, a_{1}, a_{2}, \cdots, a_{n} \geqslant 0, \sum_{i=1}^{n} a_{i} = 1. $

6. 设 f, g 是  $ [a, b] $ 上的下凸函数，f 单调增加。证明：复合函数  $ f \circ g $ 是  $ [a, b] $ 上的下凸函数。

7. 设 f 是  $ [a, b] $ 上的下凸函数，证明： $ \max f(x) = \max\{f(a), f(b)\} $

8. 设 f 在  $ [a, b] $ 上是可微的下凸函数， $ f'(x_0) = 0, x_0 \in (a, b) $. 证明： $ x_0 $ 是 f 的最小值点.

9. 设 f 在  $ (a, b) $ 上可微，则 f 在  $ [a, b] $ 上下凸的充要条件是： $ \forall x_{0}, x \in (a, b) $，有

 $$ f(x)\geqslant f(x_{0})+f^{\prime}(x_{0})(x-x_{0}), $$ 

即曲线  $ y = f(x) $ 上的每一点的切线在曲线下方.

### 4.6 函数作图

这一节所讨论的函数作图，是指手工绘出函数较为精细的草图。这对于从总体上把握函数的动态性质是很有帮助的。

#### 4.6.1 渐近线

在讨论作图问题之前，首先引入渐近线的概念。

(1) 如果  $ \lim_{x\to x_0^{+}}f(x)=\infty $ 或  $ \lim_{x\to x_0^{-}}f(x)=\infty $，则称直线  $ x=x_0 $ 为  $ y=f(x) $ 的一条竖直渐近线；

(2) 如果  $ \lim_{x\to+\infty}f(x)=a $ 或  $ \lim_{x\to-\infty}f(x)=a $，则称直线 y=a 为  $ y=f(x) $ 的一条水平渐近线；

(3) 如果存在  $ a \neq 0 $ 与 b 使得  $ \lim_{x \to +\infty} [f(x) - (ax + b)] = 0 $ 或  $ \lim_{x \to -\infty} [f(x) - (ax + b)] = 0 $，则称直线  $ y = ax + b $ 为  $ y = f(x) $ 的一条斜渐近线.