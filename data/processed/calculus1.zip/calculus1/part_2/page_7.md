9. 证明下列不等式：

(1)  $ \left|\sin x - \sin y\right| \leqslant |x - y| $;

(2)  $ \left|\arctan x - \arctan y\right| \leqslant |x - y| $;

(3) $ \frac{a-b}{a}<\ln\frac{a}{b}<\frac{a-b}{b},0<b<a; $

(4) $ py^{p-1}(x-y)\leqslant x^{p}-y^{p}\leqslant px^{p-1}(x-y) $，其中0<y<x,p>1.

10. 设函数  $  f(x)  $ 在  $ [0,1] $ 上可导， $  f(x) \neq x  $， $  f(0) = 0  $， $  f(1) = 1  $。证明： $ \exists \xi \in (0,1) $，使得  $  f'(\xi) > 1  $。

11. 广义罗尔定理.

(1) 设函数  $  f(x)  $ 在  $ (a, b) $ 内可导， $ \lim_{x \to a^{+}} f(x) = \lim_{x \to b^{-}} f(x) $，求证： $ \exists \xi \in (a, b) $， $ f'(\xi) = 0 $.

(2) 设函数  $  f(x)  $ 在  $  (a, +\infty)  $ 可导， $  \lim_{x \to a^{+}} f(x) = \lim_{x \to +\infty} f(x)  $，求证： $  \exists \xi \in (a, +\infty)  $， $  f'(\xi) = 0  $.

问：将 $ (a,+\infty) $改为 $ (-∞,a) $或 $ (-∞,+∞) $后，是否有相应的结论成立？

12. 设  $ f(x) $ 在  $ \mathbb{R} $ 上可导，且满足  $ \lim_{x\to\infty}\frac{f(x)}{|x|}=+\infty $，证明： $ \forall a\in\mathbb{R},\exists\xi\in\mathbb{R} $， $ f'(\xi)=a $。

13. 设函数  $ f(x) $,  $ g(x) $,  $ h(x) $ 在  $ [a, b] $ 上连续，在  $ (a, b) $ 内可导，试证存在  $ \xi \in (a, b) $，使得

 $$ \begin{array}{l}\left|\begin{array}{l l l}f(a)&g(a)&h(a)\\f(b)&g(b)&h(b)\\f^{\prime}(\xi)&g^{\prime}(\xi)&h^{\prime}(\xi)\end{array}\right|=0.\end{array} $$ 

14. 设  $ f(x) $ 在  $ [a, b] $ 上一阶可导，在  $ (a, b) $ 内二阶可导， $ f(a) = f(b) = 0 $， $ f_{+}^{\prime}(a)f_{-}^{\prime}(b) > 0 $，证明下列结论：

(1) 存在  $ \xi \in (a, b) $，使  $ f''(\xi) + 2f'(\xi) + f(\xi) = 0 $;

(2) 存在  $ \theta \in (a, b) $，使  $ f''(\theta) - 2f'(\theta) + f(\theta) = 0 $;

(3) 存在  $ \eta \in (a, b) $，使  $ f''(\eta) = f'(\eta) $;

(4) 存在  $ \zeta \in (a, b) $，使得  $ f''(\zeta) = f(\zeta) $.

15.（1）证明：若  $ f(x) $ 在点  $ x_{0} $ 连续，在  $ x_{0} $ 的某个空心邻域  $ U(x_{0},\delta) $ 内可导，且  $ \lim_{x\to x_{0}}f'(x)=A $，则  $ f(x) $ 在点  $ x_{0} $ 可导，且  $ f'(x_{0})=A $.

(2) 证明：若  $ f(x) $ 在区间 I 内可导，则  $ f'(x) $ 在区间 I 内不存在第一类间断点.

16. 已知  $ f(x) $ 在  $ (-∞,0) $ 上可导， $ \lim_{x\to-\infty}f'(x)=A>0 $，证明： $ \lim_{x\to-\infty}f(x)=-\infty $.