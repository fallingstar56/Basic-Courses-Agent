 $$ \begin{aligned}\frac{R_{n}(x)}{(x-x_{0})^{n+1}}&=\frac{R_{n}(x)-R_{n}(x_{0})}{(x-x_{0})^{n+1}}=\frac{R_{n}^{\prime}(\xi_{1})}{(n+1)(\xi_{1}-x_{0})^{n}}\\&=\frac{R_{n}^{\prime \prime}(\xi_{2})}{(n+1)n(\xi_{2}-x_{0})^{n-1}}=\cdots=\frac{R_{n}^{(n)}(\xi_{n})}{(n+1)!(\xi_{n}-x_{0})}\\&=\frac{f^{(n)}(\xi_{n})-f^{(n)}(x_{0})}{(n+1)!(\xi_{n}-x_{0})}=\frac{f^{(n+1)}(\xi)}{(n+1)!},\end{aligned} $$ 

其中  $ x_{0}<\xi<\xi_{n}<\cdots<\xi_{2}<\xi_{1}<x $ （或  $ x<\xi_{1}<\xi_{2}<\cdots<\xi_{n}<\xi<x_{0} $）。所以（4）式成立。

表达式(4)称为拉格朗日余项形式. 相应的泰勒公式称为  $ f(x) $ 在  $ x_{0} $ 点带拉格朗日余项的 n 阶泰勒公式.

拉格朗日余项形式(4)也可以改写为

 $$ R_{n}(x)=\frac{f^{(n+1)}(x_{0}+\theta(x-x_{0}))}{(n+1)!}\left(x-x_{0}\right)^{n+1}\quad(0<\theta<1). $$ 

由于历史原因，当 $ x_{0}=0 $时，f在 $ x_{0}=0 $点的n阶泰勒公式也称为f的n阶麦克劳林公式.

▶ 例 4.3.1

求  $ e^{x} $ 带拉格朗日余项的 n 阶麦克劳林公式.

解  $ \forall n\in\mathbb{N},(\mathrm{e}^{x})^{(n)}=\mathrm{e}^{x} $，故  $ \mathrm{e}^{x} $ 在 0 点的各阶导数都等于 1，于是  $ \mathrm{e}^{x} $ 带拉格朗日余项的 n 阶麦克劳林公式为

 $$ \mathrm{e}^{x}=1+x+\frac{x^{2}}{2!}+\cdots+\frac{x^{n}}{n!}+\frac{\mathrm{e}^{\xi}}{(n+1)!}x^{n+1}\quad(\xi\in(0,x)). $$ 

写出  $ \sin x $ 与  $ \cos x $ 带拉格朗日余项的 n 阶麦克劳林公式.

解 记  $ f(x)=\sin x $，由于  $ (\sin x)^{(n)}=\sin\left(x+\frac{n\pi}{2}\right) $，

 $$ f^{(2n)}(0)=0,\quad f^{(2n+1)}(0)=(-1)^{n}\quad(n=0,1,2,\cdots), $$ 

所以

 $$ \sin x=x-\frac{x^{3}}{3!}+\frac{x^{5}}{5!}+\cdots+(-1)^{n-1}\frac{x^{2n-1}}{(2n-1)!}+\frac{x^{2n}}{(2n)!}\sin(\xi+n\pi). $$ 

同理可得

 $$ \cos x=1-\frac{x^{2}}{2!}+\frac{x^{4}}{4!}-\cdots+(-1)^{k}\frac{x^{2n}}{(2n)!}+\frac{x^{2n+1}}{(2n+1)!}\cos\Big(\xi+\frac{2n+1}{2}\pi\Big). $$ 

图 4.3.1 画出了函数  $ \sin x $ 在  $ x_{0}=0 $ 处的 1 次、3 次、5 次、7 次和 9 次泰勒近似多项式对于  $ \sin x $ 的近似程度.