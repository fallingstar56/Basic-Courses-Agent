4. 设  $ f(a) > 0, f'(a) $ 存在，求  $ \lim_{n \to \infty} \left( \frac{f\left(a + \frac{1}{n}\right)}{f(a)} \right)^n $.

5. 设曲线  $ y = f(x) $ 在原点与  $ y = \sin x $ 相切，求极限  $ \lim_{n \to \infty} \sqrt{n} \cdot \sqrt{f\left(\frac{2}{n}\right)} $

6. 求函数  $ y = x(1 - 2x)^{2}(x - 3)^{3} $ 的 7 阶导数.

7. 求曲线  $ y=\frac{1}{x} $ 与  $ y=\sqrt{x} $ 的交角（即交点处两条切线的夹角）.

8. 证明曲线  $ x^{\frac{2}{3}} + y^{\frac{2}{3}} = a^{\frac{2}{3}} $ 上任意一点的切线介于两根坐标轴之间的线段长度等于 a.

9. 证明椭圆的声学性质：从一个焦点发出的声音经过椭圆反射后必到达另一个焦点.

10. 证明双曲线  $ xy = a^{2} $ 上任意一点处的切线与两坐标轴构成的三角形的面积都等于常数，且切点是三角形斜边的中点.

11. 已知函数  $ f(x)=\left\{\begin{aligned}&x^{2}+x,&x\leqslant0,\\ &ax^{3}+bx^{2}+cx+d,&0<x<1,\\ &x^{2}-x,&x\geqslant1,\end{aligned}\right. $ 在  $ \mathbb{R} $ 上连续可微，求

a,b,c,d.

12. 设参数方程  $ \left\{\begin{aligned} x &= 5t + 4 |t| \\ y &= 2t^{2} + t |t| \end{aligned}\right. $ 确定了函数  $ y = y(x) $，讨论此函数在 x = 0 处的可导性.

13. 设  $ \varphi(x) $ 在  $ x=x_{0} $ 的某个邻域内一阶可导，且  $ \varphi'(x) $ 在该邻域内有界，证明： $ f(x)=(x-x_{0})^{2}\varphi(x) $ 在  $ x=x_{0} $ 处二阶可导.

14. 设  $ f(x)=\left\{\begin{aligned}&g(x)\sin\frac{1}{x},&x\neq0,\\ &0,&x=0,\end{aligned}\right. $ 且  $ g(x) $ 在 x=0 可导. 问： $ g(0),g'(0) $

取何值时， $ f(x) $ 在 x=0 可导？并求  $ f^{\prime}(0) $.

15. 设  $ y = f(x) $ 在  $ x = x_{0} $ 三阶可导，且  $ f'(x_{0}) \neq 0 $。若  $ f(x) $ 存在反函数  $ x = g(y) $， $ y_{0} = f(x_{0}) $。试用  $ f'(x_{0}) $， $ f''(x_{0}) $， $ f'''(x_{0}) $ 表示  $ g'''(y_{0}) $。