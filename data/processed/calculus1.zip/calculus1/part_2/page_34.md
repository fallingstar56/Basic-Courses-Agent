故  $ f(x) $ 下凸.

在 $ (-∞,-1) $与 $ \left(\frac{1}{3},+∞\right) $内， $ f'(x)>0 $，因此f在 $ (-∞,-1) $与 $ \left(\frac{1}{3},+∞\right) $内严格单调递增；在 $ \left(-1,\frac{1}{3}\right) $内， $ f'(x)<0 $，因此f在 $ \left(-1,\frac{1}{3}\right) $内严格单调递减.

此外， $ f(x) $ 无渐近线。


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>x</td><td style='text-align: center; word-wrap: break-word;'>$ (-\infty,-1) $</td><td style='text-align: center; word-wrap: break-word;'>-1</td><td style='text-align: center; word-wrap: break-word;'>$ (-1,-\frac{1}{3}) $</td><td style='text-align: center; word-wrap: break-word;'>$ -\frac{1}{3} $</td><td style='text-align: center; word-wrap: break-word;'>$ (-\frac{1}{3},-\frac{1}{3}) $</td><td style='text-align: center; word-wrap: break-word;'>$ \frac{1}{3} $</td><td style='text-align: center; word-wrap: break-word;'>$ (\frac{1}{3},+\infty) $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f&#x27;(x)</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>+</td><td style='text-align: center; word-wrap: break-word;'>+</td><td style='text-align: center; word-wrap: break-word;'>+</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f&#x27;(x)</td><td style='text-align: center; word-wrap: break-word;'>+</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>+</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>f(x)</td><td style='text-align: center; word-wrap: break-word;'>上凸↗</td><td style='text-align: center; word-wrap: break-word;'>零点,极大值</td><td style='text-align: center; word-wrap: break-word;'>上凸↘</td><td style='text-align: center; word-wrap: break-word;'>零点</td><td style='text-align: center; word-wrap: break-word;'>下凸↘</td><td style='text-align: center; word-wrap: break-word;'>极小值</td><td style='text-align: center; word-wrap: break-word;'>下凸↗</td></tr></table>

 $ f(x) $ 的简图如下(图 4.6.1):

<div style="text-align: center;"><img src="imgs/img_in_image_box_189_399_530_661.jpg" alt="Image" width="47%" /></div>


<div style="text-align: center;">图 4.6.1</div>


▶ 例 4.6.3 ……

作函数  $ f(x)=\frac{(x+1)^{2}}{x} $ 的图形.

解 f 的定义域是  $ (-∞,0)∪(0,+∞) $， $ f(-1)=0 $，

 $$ f^{\prime}(x)=\frac{(x-1)(x+1)}{x^{2}},\quad f^{\prime \prime}(x)=\frac{2}{x^{3}}. $$ 

f 有驻点 x = -1 与 x = 1 。由于  $ f''(-1) < 0, f''(1) > 0 $ ，因此 x = -1 是 f 的极大值点，x = 1 是 f 的极小值点。

在 $ (-∞,0) $内， $ f''(x)<0 $，故 $ f(x) $上凸，在 $ (0,+∞) $内， $ f''(x)>0 $，故 $ f(x) $