因此  $ \lim_{x\to x_{0}^{+}}\frac{f(x)}{g(x)}=A. $

完全类似于定理 4.2.1 的情形，定理 4.2.2 对于极限过程  $ x \rightarrow x_{0}^{-} $，进而对于双边极限过程  $ x \rightarrow x_{0} $，相应的结论也成立.

#### ▶ 例 4.2.3

计算  $ \lim_{x\to0^{+}}\frac{\ln\cot x}{\ln x} $

解 逐次应用洛必达法则可得

 $$ \lim_{x\to0^{+}}\frac{\ln\cot x}{\ln x}=\lim_{x\to0^{+}}\frac{\frac{1}{\cot x}\cdot\frac{x-1}{\sin^{2}x}}{\frac{1}{x}}=-\lim_{x\to0^{+}}\frac{x}{\sin x\cos x}=-1. $$ 

对于极限过程  $ x \to \infty $ 与  $ x \to \pm \infty $，相应的洛必达法则如下：

#### 定理 4.2.3

设函数  $  f, g  $ 在  $  (a, +\infty)  $ 内可导， $  g'(x) \neq 0  $，且  $  \lim_{x \to +\infty} f(x) = \lim_{x \to +\infty} g(x) = 0  $

(或者  $ g(x) \to \infty (x \to +\infty) $). 如果

 $$ \lim_{x\to+\infty}\frac{f^{\prime}(x)}{g^{\prime}(x)}=A, $$ 

則

 $$ \lim_{x\to+\infty}\frac{f(x)}{g(x)}=A. $$ 

证明 不妨设 a>0 。令  $ \varphi(u)=f(u^{-1}),\psi(u)=g(u^{-1}),u\in(0,a^{-1}) $ ，则函数  $ \varphi,\psi $ 在  $ (0,a^{-1}) $ 内可导， $ \psi^{\prime}(u)=g^{\prime}\left(\frac{1}{u}\right)\frac{-1}{u^{2}}\neq0,\lim_{u\to0^{+}}\varphi(u)=\lim_{x\to+\infty}f(x),\lim_{u\to0^{+}}\psi(u)=\lim_{x\to+\infty}g(x) $，并且

 $$ \lim_{u\to0^{+}}\frac{\varphi^{^{\prime}}(u)}{\psi^{^{\prime}}(u)}=\lim_{u\to0^{+}}\frac{f^{^{\prime}}\left(\frac{1}{u}\right)\frac{-1}{u^{2}}}{g^{^{\prime}}\left(\frac{1}{u}\right)\frac{-1}{u^{2}}}=\lim_{x\to+\infty}\frac{f^{^{\prime}}(x)}{g^{^{\prime}}(x)}=A. $$ 

于是对函数  $ \varphi $ 与  $ \phi $ 在  $ (0, a^{-1}) $ 上应用定理 4.2.1（或定理 4.2.2）便得到

 $$ \lim_{x\to+\infty}\frac{f(x)}{g(x)}=\lim_{u\to0^{+}}\frac{f(u^{-1})}{g(u^{-1})}=\lim_{u\to0^{+}}\frac{\varphi(u)}{\psi(u)}=\lim_{u\to0^{+}}\frac{\varphi^{\prime}(u)}{\psi^{\prime}(u)}=A. $$ 

不难看出，定理 4.2.3 对于极限过程  $ x \to -\infty $，进而对于极限过程  $ x \to \infty $，相应的结论也成立。