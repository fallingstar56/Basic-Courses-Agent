间断点.为了较精确描述这里的“不太多”,我们引入零测度集的概念.

设数集  $ E \subseteq \mathbb{R} $，若  $ \forall \delta > 0 $，存在一列开区间  $ (\alpha_k, \beta_k) (k = 1, 2, \cdots) $ 使得  $ E \subseteq \bigcup_{k=1}^{\infty} (\alpha_k, \beta_k) $ 并且  $ \forall n \in \mathbb{N}^* $，有  $ \sum_{k=1}^{n} (\beta_k - \alpha_k) < \delta $，则称数集 E 为零测度集。

若数集 E 中点可以排成一个点列： $ E = \{x_n: n = 1, 2, \cdots\} $，则 E 为零测度集.

证明  $ \forall\delta>0, $ 取  $ \alpha_{k}=x_{k}-\frac{\delta}{2^{k+1}},\beta_{k}=x_{k}+\frac{\delta}{2^{k+1}},\quad x_{k}\in(\alpha_{k},\beta_{k}),k=1, $

2,…. 于是  $ E \subseteq \bigcup_{k=1}^{\infty} (\alpha_{k}, \beta_{k}) $，并且  $ \forall n \in \mathbb{N}^{*} $，有  $ \sum_{k=1}^{n} (\beta_{k} - \alpha_{k}) = \sum_{k=1}^{n} \frac{\delta}{2^{k}} < \delta $，所以 E 为零测度集.

更深入的研究可以证明（它的证明已经超出本课程的要求）：

有界函数 f 在  $ [a,b] $ 上黎曼可积的充分必要条件是：f 在  $ [a,b] $ 上的间断点所构成的点集 E 是零测度集.

### 习题 5.1

1. 利用定积分的几何意义求积分值.

(1) $ \int_{-1}^{1}\sqrt{1-x^{2}}dx; $ (2) $ \int_{-\frac{1}{2}}^{1}\sqrt{1-x^{2}}dx; $

(3) $ \int_{-1}^{1}(3+4x)dx; $ (4) $ \int_{0}^{1}\left(\sqrt{2x-x^{2}}-x\right)dx. $

2. 设  $ f, g \in R[a, b] $，且  $ \forall x \in [a, b], f(x) \leqslant g(x) $，证明： $ \int_{a}^{b} f(x) \, \mathrm{d}x \leqslant \int_{a}^{b} g(x) \, \mathrm{d}x $。又问：若  $ \int_{a}^{b} f(x) \, \mathrm{d}x \leqslant \int_{a}^{b} g(x) \, \mathrm{d}x $，是否有  $ f(x) \leqslant g(x) $ 恒成立？

3. 利用命题 5.1.2 证明：对于  $ [a, b] $ 的任一分割 T，

 $$ L(f,T)\leqslant\int_{-a}^{b}f(x)\mathrm{d}x\leqslant\int_{a}^{-b}f(x)\mathrm{d}x\leqslant U(f,T). $$ 

4. 设  $ f \in R[a, b] $，且  $ f(x) \geqslant d > 0 $， $ x \in [a, b] $。求证： $ \frac{1}{f(x)} \in R[a, b] $。

5. 已知： $ f(x) \in R[a, b] $，证明： $ \cos(f(x)) \in R[a, b] $.

6. 设  $ f(x) \in R[a, b] $,  $ F(x) = \sup_{t \in [a, x]} f(t) $, 问： $ F(x) \in R[a, b] $ 吗？