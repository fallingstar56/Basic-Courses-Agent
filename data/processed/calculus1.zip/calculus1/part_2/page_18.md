根据定理 4.3.3 即知  $ f(x)=\mathrm{e}^{\sin^{2}x} $ 带皮亚诺余项的 4 阶麦克劳林公式为

 $$ \mathrm{e}^{\sin^{2}x}=1+x^{2}+\frac{1}{6}x^{4}+o(x^{4})\quad(x\rightarrow0). $$ 

#### 4.3.2 泰勒公式的应用

上面我们已经看到，函数 f 在一点处的泰勒多项式可以在这一点附近很好地逼近 f，因此泰勒公式是研究函数在一点近旁性状的一个有力工具。在下面几个例题中，我们将看到泰勒公式在求近似值、无穷小量阶的确定与求不定型极限以及有关函数及其导数的等式与不等式证明等问题中的应用。

#### ▶ 例 4.3.7

求 e 的近似值，使得误差不大于  $ 10^{-5} $

解  $ e^{x} $ 带拉格朗日余项的 n 阶麦克劳林公式为

 $$ \mathrm{e}^{x}=1+x+\frac{x^{2}}{2!}+\cdots+\frac{x^{n}}{n!}+\frac{\mathrm{e}^{\xi}}{(n+1)!}x^{n+1}\quad(\xi\in(0,x)). $$ 

取 x=1 即得

 $$ \mathrm{e}=1+1+\frac{1}{2!}+\cdots+\frac{1}{n!}+\frac{\mathrm{e}^{\xi}}{(n+1)!}\quad(\xi\in(0,1)). $$ 

若取 n=8 ，则

 $$ \frac{\mathrm{e}^{\xi}}{(8+1)!}<\frac{3}{9!}<10^{-5}. $$ 

所以

 $$ \mathrm{e}\approx1+1+\frac{1}{2!}+\cdots+\frac{1}{8!}\approx2.71828. $$ 

▶ 例 4.3.8 ……

求极限  $ \lim_{x\to0^{+}}\frac{e^{\sin^{2}x}-\cos(2\sqrt{x})-2x}{x^{2}} $

解 由例 4.3.6，

 $$ \mathrm{e}^{\sin^{2}x}=1+x^{2}+\frac{1}{6}x^{4}+o(x^{4})\quad(x\rightarrow0), $$ 

 $$ \begin{align*}\cos\big(2\sqrt{x}\big)&=1-\frac{1}{2}\left(2\sqrt{x}\right)^{2}+\frac{1}{4!}\left(2\sqrt{x}\right)^{4}+o(x^{2})\\&=1-2x+\frac{2}{3}x^{2}+o(x^{2})\ (x\to0^{+}),\end{align*} $$ 

所以

 $$ \lim_{x\to0^{+}}\frac{\mathrm{e}^{\sin^{2}x}-\cos(2\sqrt{x})-2x}{x^{2}}=\lim_{x\to0^{+}}\frac{\frac{1}{3}x^{2}+o(x^{2})}{x^{2}}=\frac{1}{3}. $$ 