上面两个来自不同领域的问题，最后都归结为：“当分割的长度 $ \max_{1\leqslant i\leqslant n}\left\{x_{i}-x_{i-1}\right\}\rightarrow0 $时，和式 $ \sum_{i=1}^{n}f(\xi_{i})(x_{i}-x_{i-1}) $的极限。”这就是下面将要引入的黎曼积分的概念.

定义 5.1.1

设 f 是闭区间  $ [a, b] $ 上的有界函数，如果存在实数 I，使得对于  $ [a, b] $ 的任何分割 T： $ a = x_{0} < x_{1} < \cdots < x_{n} = b $，以及在每个子区间  $ [x_{i-1}, x_{i}] $ 中任取的点  $ \xi_{i} $，当分割的长度  $ |T| = \max_{1 \leq i \leq n} \{x_{i} - x_{i-1}\} \to 0 $ 时，就有

 $$ \lim_{|T|\to0}\sum_{i=1}^{n}f(\xi_{i})(x_{i}-x_{i-1})=I. $$ 

即  $ \forall \epsilon > 0, \exists \delta > 0 $，只要分割  $ T $ 的长度  $ |T| < \delta $，无论  $ \xi_i \in [x_{i-1}, x_i] $ 如何取，都有

 $$ \left|\sum_{i=1}^{n}f(\xi_{i})(x_{i}-x_{i-1})-I\right|<\varepsilon, $$ 

则称 f 在闭区间  $ [a,b] $ 上（黎曼）可积，称 I 是 f 在  $ [a,b] $ 上（黎曼）积分，记为

 $$ I=\int_{a}^{b}f(x)\mathrm{d}x. $$ 

a 与 b 分别称为积分的下限与上限，f 称为被积函数，x 称为积分变量。

依照积分定义，问题1中的曲边梯形D的面积为

 $$ S=\int_{a}^{b}f(x)\mathrm{d}x. $$ 

问题 2 中变力 F 使得质点由 a 移动到 b 所做的功为

 $$ W=\int_{a}^{b}F(x)\mathrm{d}x. $$ 

在上述积分定义中，总假定 a<b。但以后也常遇到  $ a \geqslant b $ 的情形，此时由定义不难看到

 $$ \int_{a}^{b}f(x)\mathrm{d}x=-\int_{b}^{a}f(x)\mathrm{d}x,\int_{a}^{a}f(x)\mathrm{d}x=0. $$ 

当 f 在  $ [a, b] $ 上黎曼可积时，记作  $ f \in R[a, b] $.

#### 5.1.2 积分存在的条件

设 f 在  $ [a, b] $ 上有界，且分别以 M、m 为上、下确界，T 为  $ [a, b] $ 的任一分割：

 $$ T:a=x_{0}<x_{1}<\cdots<x_{n}=b. $$ 

任取  $ \xi_{i}\in[x_{i-1},x_{i}] $，又分别记  $ M_{i} $ 与  $ m_{i} $ 为 f 在  $ [x_{i-1},x_{i}] $ 上的上、下确界，i=1，2，…，n（本节后文中总设分割 T 及相应的  $ M_{i} $ 与  $ m_{i} $ 如上）。令

 $$ U(f,T)=\sum_{i=1}^{n}M_{i}(x_{i}-x_{i-1}); $$ 