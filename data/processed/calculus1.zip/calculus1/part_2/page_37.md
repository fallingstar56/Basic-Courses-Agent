10. 设函数  $ y = f(x) $ 在  $ (-1, 1) $ 内二阶可导， $ f''(0) \neq 0 $。 $ \forall x \in (-1, 1) $， $ x \neq 0 $， $ \exists \theta(x) $ 满足  $ f(x) - f(0) = f'(\theta(x)x) $，证明： $ \lim_{\theta(x) \to \frac{1}{2}}\theta(x) = \frac{1}{2} $.

11. 设函数  $ y = f(x) $ 在  $ [0, 1] $ 上二阶可导，且  $ f(0) = f(1) = 0 $， $ \min_{x \in [0, 1]} f(x) = -1 $，求证： $ \exists \xi \in (0, 1) $，使得  $ f''(\xi) \geq 8 $.

12. 设  $ y = f(x) $ 在  $ [a, b] $ 上二阶连续可微，且  $ f(a) = f(b) = 0 $.

证明：(1) $ \max_{a\leqslant x\leqslant b}|f(x)|\leqslant\frac{1}{8}(b-a)^{2}\max_{a\leqslant x\leqslant b}|f''(x)| $;

 $$ \max_{a\leq x\leq b}\left|f^{\prime}(x)\right|\leq\frac{1}{2}(b-a)\max_{a\leq x\leq b}\left|f^{\prime\prime}(x)\right|. $$ 

13. 设  $ f(x) \in C[a, b] $，且 f 在  $ (a, b) $ 内只有一个极值点  $ x_{0} $，证明： $ x_{0} $ 是 f 在  $ [a, b] $ 上的最值点.

14. 设  $ f(x) \in C[a, b] $，证明：在  $ (a, b) $ 内任意两个极大值点之间，必有极小值点.

15. 证明下列不等式：

 $ (x^{a}+y^{a})^{\frac{1}{a}}>(x^{\beta}+y^{\beta})^{\frac{1}{2}} $，其中x，y>0， $ \beta>\alpha>0 $。

16. 求下列极限.

(1)  $ \lim_{x\to1}\frac{x^{x+1}(\ln x+1)-x}{1-x} $;

(2)  $ \lim_{x\to0}\frac{\cos x-\mathrm{e}^{-\frac{x^{2}}{2}}}{x^{4}} $.

17. 设在点 x=0 的某个邻域内， $ f(x) $ 存在二阶导数，已知  $ \lim_{x\to0}\left(1+x+\frac{f(x)}{x}\right)^{\frac{1}{x}}=\mathrm{e}^{2} $，求  $ f(0) $， $ f'(0) $， $ f''(0) $，并计算  $ \lim_{x\to0}\left(1+\frac{f(x)}{x}\right)^{\frac{1}{x}} $.

18. 设函数  $ y = f(x) $ 在点  $ x_{0} $ 处 k 阶可导 ( $ k \geqslant 2 $)，若

 $$ f^{\prime}(x_{0})=f^{\prime\prime}(x_{0})=\cdots=f^{(k-1)}(x_{0})=0,\quad f^{(k)}(x_{0})\neq0, $$ 

证明：当 k 为偶数时， $ x_{0} $ 为  $ f(x) $ 的极值点；当 k 为奇数时， $ x_{0} $ 为  $ f(x) $ 的拐点.

19. 设  $ f(x) $ 在  $ [a,b] $ 上是下凸函数，证明：

(1) $ f(x) $在 $ (a,b) $上处处存在单调导数，且 $ f_{-}(x) $， $ f_{+}(x) $在 $ (a,b) $上单调增加；

(2)  $ \forall x \in (a, b) $，有  $ f_{-}^{\prime}(x) \leqslant f_{+}^{\prime}(x) $;

(3)  $  f(x) \in C(a, b)  $;

(4) 若  $  f_{+}^{\prime}(a)  $,  $  f_{-}^{\prime}(b)  $ 存在，那么  $  f(x) \in C[a, b]  $.

20. 作出函数  $ x^{2} + y^{2} = x^{4} + y^{4} $ 的图像.