(3) $ y=\frac{\ln x}{x} $，求 $ y^{(5)} $

(4) $ y=x^{2}\sin2x $，求 $ y^{(50)} $;

(5)  $ y = x \sinh x $，求  $ y^{(100)} $;

(6) $ y=\frac{1}{2-x-x^{2}} $，求 $ y^{(20)} $;

(7) $ y=e^{ax}\sin bx $,求 $ y^{(n)} $;

(8) $ y=e^{ax}\cos bx $,求 $ y^{(n)} $;

(9) $ y=x^{3}e^{x} $，求 $ y^{(n)} $;

(10) $ y=\ln\sqrt{\frac{1-x}{1+x}} $，求 $ y^{(n)} $.

4. 对下列参数方程，求  $ y''(x) $， $ y'''(x) $.

(1) $ \begin{cases}x=a(t-\sin t),\\y=a(1-\cos t);\end{cases} $ (2) $ \begin{cases}x=\mathrm{e}^{2t}\cos^{2}t,\\y=\mathrm{e}^{2t}\sin^{2}t;\end{cases} $

(3) $ \left\{\begin{aligned}x&=f^{\prime}(t),\\ y&=tf^{\prime}(t)-f(t),\end{aligned}\right. $ 其中 f 三阶可导， $ f^{\prime\prime}(x)\neq0. $

5. 求下列隐函数的二阶导数  $ y''(x) $.

(1)  $ e^y + xy - e = 0 $; (2)  $ \sqrt{x} + \sqrt{y} = a $; (3)  $ y - 2x = (x - y) \ln(x - y) $.

6. 设  $ f(x)=\arctan x $. 证明：

 $ (1+x^{2})f^{(n+2)}(x)+2(n+1)xf^{(n+1)}(x)+n(n+1)f^{(n)}(x)=0, $

并求  $ f^{(n)}(0) $.

7. 设  $ f(x)=(\arcsin x)^{2} $. 证明：

 $ (1-x^{2})f^{(n+2)}(x)-(2n+1)xf^{(n+1)}(x)-n^{2}f^{(n)}(x)=0, $

并求  $ f^{(n)}(0) $.

## 第 3 章 总复习题

1. 设  $ f(x)=\left\{\begin{aligned}&|x|^{4}\sin\frac{1}{x},&x\neq0,\\ &0,&x=0,\end{aligned}\right. $

问：k 取何值时， $ f(x) $ 在 x=0 处

(1) 连续；(2) 可导；(3) 导函数连续.

2. 试证： $ f(x)=\left\{\begin{aligned}&e^{\frac{-1}{x^{2}}},&x\neq0,\\ &0,&x=0,\end{aligned}\right. $ 在 x=0 处任意阶可导.

3. 设函数  $ f(x) $ 可导，

(1) $ f(x+y)=f(x)f(y),\forall x,y\in\mathbb{R} $，证明： $ f(x)\equiv0 $或 $ f(x)=\mathrm{e}^{\lambda x} $， $ \lambda $是常数.

(2) $ f(xy)=f(x)+f(y) $， $ \forall x,y>0 $，证明： $ f(x)\equiv0 $或 $ f(x)=\mu\ln x,\mu $是常数.