计算  $ \lim_{x\to0^{+}}x^{a}\ln x(a>0) $.

 $$ \lim_{x\to0^{+}}x^{a}\ln x=\lim_{x\to0^{+}}\frac{\ln x}{x^{-a}}=\lim_{x\to0^{+}}\frac{x^{-1}}{-\alpha x^{-a-1}}=\lim_{x\to0^{+}}\frac{-x^{a}}{\alpha}=0. $$ 

#### ▶ 例 4.2.9

计算 $ \lim_{x\to0}\left(\frac{\sin x}{x}\right)^{\frac{1}{x^{2}}} $

解 令  $ y=\left(\frac{\sin x}{x}\right)^{\frac{1}{x^{2}}} $，则  $ \ln y=\frac{\ln\sin x-\ln x}{x^{2}}\left(\frac{0}{0}\text{型}\right) $。由定理 4.2.1，

 $$ \begin{aligned}\lim_{x\to0}&\lim_{x\to0}\frac{\ln(\sin x/x)}{x^{2}}=\lim_{x\to0}\frac{\frac{x}{\sin x}\cdot\frac{x\cos x-\sin x}{x^{2}}}{2x}\\&=\lim_{x\to0}\frac{x\cos x-\sin x}{2x^{2}\sin x}=\lim_{x\to0}\frac{-x\sin x}{4x\sin x+2x^{2}\cos x}=-\frac{1}{6},\end{aligned} $$ 

所以

 $$ \lim_{x\to0}\left(\frac{\sin x}{x}\right)^{\frac{1}{x^{2}}}=\lim_{x\to0}\mathrm{e}^{\ln y}=\mathrm{e}^{-\frac{1}{6}}. $$ 

需要特别指出的是，当极限  $ \lim_{x\to x_{0}}\frac{f'(x)}{g'(x)} $ 不存在时，并不能确定极限  $ \lim_{x\to x_{0}}\frac{f(x)}{g(x)} $ 是否存在，因而不能使用洛必达法则. 例如下列极限存在：

 $$ \lim_{x\to+\infty}\frac{x+\cos x}{x}=1;\quad\lim_{x\to0}\frac{x^{2}\sin\frac{1}{x}}{\sin x}=0. $$ 

但是，下面两个极限都不存在：

 $$ \lim_{x\to+\infty}\frac{(x+\cos x)^{\prime}}{x^{\prime}}=\lim_{x\to+\infty}(1-\sin x) $$ 

 $$ \lim_{x\to0}\frac{\left(x^{2}\sin\frac{1}{x}\right)^{\prime}}{\left(\sin x\right)^{\prime}}=\lim_{x\to0}\frac{2x\sin\frac{1}{x}-\cos\frac{1}{x}}{\cos x} $$ 

### 习题 4.2

1.（极限为无穷时的洛必达法则）设函数 f, g 在  $ (x_{0}-\rho, x_{0}+\rho) $ 上可导，且  $ g'(x) \neq 0, \lim_{x \to x_{0}} f(x) = \lim_{x \to x_{0}} g(x) = 0. $ 如果  $ \lim_{x \to x_{0}} \frac{f'(x)}{g'(x)} = \infty $，证明： $ \lim_{x \to x_{0}} \frac{f(x)}{g(x)} = \infty. $

2. 求下列极限.

(1)  $ \lim_{x\to0^{+}}\frac{\ln(1-\cos x)}{\ln x} $;

(2)

 $$ \lim_{x\to0}\frac{e^{x}-e^{\sin x}}{x-\sin x} $$ 