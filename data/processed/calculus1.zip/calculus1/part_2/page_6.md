(1) 若  $ f_{+}^{\prime}(a)f_{-}^{\prime}(b)<0 $，则存在  $ \xi\in(a,b) $，使得  $ f^{\prime}(\xi)=0 $;

(2) 若  $ f_{+}^{\prime}(a) \neq f_{-}^{\prime}(b) $，则对介于  $ f_{+}^{\prime}(a) $ 与  $ f_{-}^{\prime}(b) $ 之间的任何实数  $ \lambda $，存在  $ \xi \in (a, b) $，使得  $ f'(\xi) = \lambda $ （关于导函数的达布定理）.

证明 （1）不妨设  $ f_{+}^{\prime}(a)>0,f_{-}^{\prime}(b)<0 $ （否则，可考虑  $ -f(x) $，即

 $$ \lim_{x\to a^{+}}\frac{f(x)-f(a)}{x-a}>0\ ;\quad\lim_{x\to b^{-}}\frac{f(x)-f(b)}{x-b}<0. $$ 

于是可以分别找到  $ x_{1}, x_{2} \in (a, b) $，使得  $ f(x_{1}) > f(a) $ 且  $ f(x_{2}) > f(b) $，由此知 f 在  $ [a, b] $ 上的最大值在开区间  $ (a, b) $ 内某个点  $ \xi $ 处取得，再由费马定理即知  $ f'(\xi) = 0 $.

(2) 令  $  g(x) = f(x) - \lambda x  $，则  $  g(x)  $ 在  $ [a, b] $ 上可导且  $  g'(a)g'(b) < 0  $，由(1)，存在  $ \xi \in (a, b) $，使得  $  g'(\xi) = 0  $，即  $  f'(\xi) = \lambda  $.

### 习题 4.1

1. 设  $ f(x) $ 在  $ [a, b] $ 上连续，在  $ (a, b) $ 内二阶可导，且有  $ f(a) = f(c) = f(b) $， $ a < c < b $.

证明： $ \exists \xi \in (a, b), f''(\xi) = 0. $

2. 设常数  $ a_{0}, a_{1}, \cdots, a_{n} $ 满足  $ \frac{a_{n}}{n+1} + \frac{a_{n-1}}{n} + \cdots + \frac{a_{1}}{2} + a_{0} = 0 $，证明：多项式  $ a_{n}x^{n} + a_{n-1}x^{n-1} + \cdots + a_{1}x + a_{0} $ 在  $ (0,1) $ 内有一零点.

3. 设  $ f(x) $ 在  $ \mathbb{R} $ 上有 n 阶导数， $ p(x)=a_{n}x^{n}+a_{n-1}x^{n-1}+\cdots+a_{1}x+a_{0} $ 为一个 n 次多项式，如果存在  $ n+1 $ 个不同的点  $ x_{1}, x_{2}, \cdots, x_{n+1} $ 使得  $ f(x_{i})=p(x_{i}) $  $ (i=1,2,\cdots,n+1) $，则  $ \exists \xi \in (a,b) $，使得  $ a_{n}=\frac{f^{(n)}(\xi)}{n!} $.

4. 证明：若  $ f(x) $ 在区间 I 上的 n 阶导数恒为常数，则在此区间上  $ f(x) $ 必为一多项式.

5. 设函数  $  f(x)  $ 在区间 I 上满足：  $ \forall x, y \in I, |f(x) - f(y)| \leqslant M|x - y|^{2} $，证明：  $  f(x)  $ 为常数.

6. 设函数  $  f(x)  $ 在  $ [a, b] $ 上连续，在  $ (a, b) $ 内可导， $  f(a) = f(b)  $ 且  $  f(x)  $ 不是常值函数。试证明  $ \exists \xi \in (a, b) $，使得  $  f'(\xi) > 0  $。

7. 设函数  $  f(x)  $ 在  $ [a, b] $ 上二阶可导， $  f(a) = f(b) = 0  $，且  $ \exists c \in (a, b) $ 使得  $  f(c) > 0  $. 试证明  $ \exists \xi \in (a, b) $，使得  $  f''(\xi) < 0  $.

8. 证明下列等式：

(1)

 $$ \arctan x+\operatorname{arccot} x=\frac{\pi}{2}； $$ 

(2)

 $$ 2\arctan x+\arcsin\frac{2x}{1+x^{2}}=\pi\operatorname{sgn}(x),|x|\geqslant1. $$ 