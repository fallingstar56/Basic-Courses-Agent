可知存在  $ \xi \in (a, b) $，使得

 $$ \varphi^{\prime}(\xi)=f^{\prime}(\xi)-\frac{f(b)-f(a)}{g(b)-g(a)}g^{\prime}(\xi)=0. $$ 

由此立即得到(3)式.

在柯西中值定理中，一种最常用的情形是  $ g(x) \equiv x $，此时便得到著名的拉格朗日中值定理。

定理 4.1.4（拉格朗日中值定理）

设 f 在  $ [a,b] $ 上连续，在  $ (a,b) $ 内可导，则存在  $ \xi \in (a,b) $，使得

 $$ f^{\prime}(\xi)=\frac{f(b)-f(a)}{b-a}. $$ 

拉格朗日中值定理的几何意义是：在定理的条件下，在 $ (a,b) $中必存在一点 $ \xi $，使得曲线 $ y=f(x) $在点 $ (\xi,f(\xi)) $处的切线与两个端点 $ A(a,f(a)) $与 $ B(b,f(b)) $的连线平行（图4.1.2）.

(4) 式也常称为拉格朗日中值公式. 若用  $ x_{0} $ 与 x 分别代替 a 与 b, (4) 式可以改写为

<div style="text-align: center;"><img src="imgs/img_in_image_box_433_337_643_472.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">图 4.1.2</div>


 $$ f(x)-f(x_{0})=f^{\prime}(\xi)(x-x_{0})(\xi\in(x_{0},x)) $$ 

或者用 x 与  $ x + \Delta x $ 分别代替(4)式中的 a 与 b，便得到

 $$ f(x+\Delta x)-f(x)=\Delta x f^{\prime}(x+\theta\Delta x)\quad(0<\theta<1). $$ 

▶ 例 4.1.1

若  $ f'(x) $ 在  $ (a,b) $ 内恒等于零，则 f 在  $ (a,b) $ 内为常数.

证明 只要证对于 $ (a,b) $内任意两点 $ x_{1}<x_{2} $，有 $ f(x_{1})=f(x_{2}) $即可。对 $ f $在 $ [x_{1},x_{2}] $上应用拉格朗日中值公式便知， $ \exists\xi\in(x_{1},x_{2}) $使得

 $$ f(x_{1})-f(x_{2})=f^{\prime}(\xi)(x_{1}-x_{2})=0, $$ 

▶ 例 4.1.2

若 f 在  $ (a, b) $ 内可导，并且存在常数 L > 0，使得

 $$ \mid f^{\prime}(x)\mid\leqslant L\quad(a<x<b), $$ 

则 f 在  $ (a,b) $ 内满足利普希茨条件，即  $ \forall x_{1}x_{2}\in(a,b) $，有

 $$ \mid f(x_{1})-f(x_{2})\mid\leqslant L\mid x_{1}-x_{2}\mid. $$ 

证明  $ \forall x_{1}, x_{2} \in (a, b) $，对  $ f $ 在  $ [x_{1}, x_{2}] $ 上应用定理 4.1.4 便知， $ \exists \xi \in (x_{1}, x_{2}) $ 使得

 $$ \mid f(x_{1})-f(x_{2})\mid=\mid f^{\prime}(\xi)(x_{1}-x_{2})\mid\leqslant L\mid x_{1}-x_{2}\mid. $$ 