7. 设  $ f(x) \in R[a, b] $，求证： $ \forall \varepsilon > 0 $，存在分段常值函数  $ g(x) $，使得

 $$ \int_{a}^{b}\left|f(x)-g(x)\right|\mathrm{d}x<\varepsilon. $$ 

8. 设函数  $  f(x)  $ 满足  $ \forall x, y \in I, |f(x) - f(y)| \leqslant L|x - y| $，证明： $  f(x)  $ 在 I 上一致连续.

9. 证明下列函数在给定区间上一致连续.

(1)  $  f(x) = x^{2}, x \in [a, b]  $; (2)  $  f(x) = \ln x, x \in (2, +\infty)  $;

(3)  $  f(x) = \sin x  $,  $  x \in \mathbb{R}  $;

(4)  $  f(x) = \sqrt{x}  $,  $  x \in [0, +\infty)  $.

10. 若  $ f(x) $ 在  $ [a,b] $ 上一致连续，且在  $ [b,c] $ 上一致连续，则  $ f(x) $ 在  $ [a,c] $ 上一致连续.

11. 若  $ f(x) $ 在  $ [0,1] $ 上一致连续，且在  $ [1,+\infty) $ 上一致连续，则  $ f(x) $ 在  $ [0,+\infty) $ 上一致连续.

12. 设函数  $ f(x) $,  $ g(x) $ 在 I 上一致连续，证明： $ k_{1}f(x)+k_{2}g(x) $ 在 I 上也一致连续.

13. 设 a, b 为实数，且  $ f(x) $ 在  $ (a, b) $ 上一致连续，证明： $ f(x) $ 在  $ (a, b) $ 上有界.

14. 已知  $ f(x) $,  $ g(x) $ 在有界区间 I 上一致连续，证明： $ f(x)g(x) $ 在 I 上一致连续。又问：对于无界区间 I，结论是否仍然成立？若成立，请证明结论；若不成立，举出反例。

15. 证明下列函数在给定区间上不一致连续.

(1)  $  f(x) = x^{2}, x \in [0, +\infty)  $; (2)  $  f(x) = \ln x, x \in (0, +\infty)  $;

(3)  $  f(x) = \sin x^2  $,  $  x \in \mathbb{R}  $; (4)  $  f(x) = x \sin x  $,  $  x \in \mathbb{R}  $.

16. 若  $ f(x) \in C(a, b) $，证明： $ f(x) $ 在  $ (a, b) $ 内一致连续的充要条件为  $ \lim_{x \to a^+} f(x) $， $ \lim_{x \to b^-} f(x) $ 都存在。并说明： $ y = \frac{\sin x}{x} $ 在  $ (0, 1) $ 内一致连续。

### 5.2 黎曼积分的性质

性质 1（积分的线性性质）

设  $ f, g \in R[a, b] $，则对任意的常数  $ \alpha $ 与  $ \beta $，函数  $ \alpha f + \beta g \in R[a, b] $，并且

 $$ \int_{a}^{b}\left(\alpha f(x)+\beta g(x)\right)\mathrm{d}x=\alpha\int_{a}^{b}f(x)\mathrm{d}x+\beta\int_{a}^{b}g(x)\mathrm{d}x. $$ 

证明 由于  $ f, g \in R[a, b] $，故

 $$ \begin{align*}\lim_{\left|T\right|\to0}\sigma(\alpha f+\beta g,T)&=\alpha\lim_{\left|T\right|\to0}\sigma(f,T)+\beta\lim_{\left|T\right|\to0}\sigma(g,T)\\&=\alpha\int_{a}^{b}f(x)\mathrm{d}x+\beta\int_{a}^{b}g(x)\mathrm{d}x,\end{align*} $$ 

从而  $ \alpha f + \beta g \in R[a, b] $，并且(1)式成立。