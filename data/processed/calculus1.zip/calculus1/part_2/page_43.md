同理， $ \exists\delta_{2}>0 $，对于 $ [a,b] $的任一满足 $ |T|<\delta_{2} $的分割T，

 $$ 0\leqslant I-L(f,T)<\varepsilon. $$ 

另一方面，对于 $ [a,b] $的任一分割 T，

 $$ L(f,T)\leqslant\sigma(f,T)\leqslant U(f,T). $$ 

结合(8)式，(9)式与(10)式即得，对于 $ [a,b] $的任一满足 $ |T|<\delta=\min\{\delta_{1},\delta_{2}\} $的分割T，

 $$ \mid\sigma(f,T)-I\mid<\varepsilon. $$ 

所以  $ f \in R[a, b] $ 并且  $ \int_{a}^{b} f(x) \, dx = I. $

▶ 例 5.1.1

求证：狄利克雷函数  $ D(x) $ 在  $ [0,1] $ 上不可积.

证明 对于  $ [0,1] $ 的任一分割 T:  $ 0 = x_{0} < x_{1} < \cdots < x_{n} = 1 $, f 在每个子区间  $ [x_{i-1}, x_{i}] $ 中的上、下确界分别是 1 与 0，从而

 $$ U(D,T)-L(D,T)=\sum_{i=1}^{n}(1-0)(x_{i}-x_{i-1})=1. $$ 

因此  $ D(x) $ 在  $ [0,1] $ 上不可积.

#### 5.1.3 函数的一致连续性

利用定理 5.1.1, 可以得到几个常用的可积函数类, 其中主要的一个函数类就是连续函数类. 为此目的, 需要建立一致连续函数的概念.

定义 5.1.3

设函数 f 在区间 I 上定义. 如果  $ \forall \varepsilon > 0, \exists \delta > 0 $, 使得  $ \forall x, y \in I $, 只要  $ |x - y| < \delta $, 就有

 $$ \left|f(x)-f(y)\right|<\varepsilon, $$ 

则称 f 在区间 I 上一致连续.

函数 f 在区间 I 上一致连续反映的是 f 在区间 I 上的一个整体性质.

证明  $ f(x)=\cos x $ 在  $ \mathbb{R} $ 上一致连续.

证明  $ \forall x, y \in \mathbb{R} $,

 $$ \left|\cos x-\cos y\right|=\left|2\sin\frac{x+y}{2}\sin\frac{x-y}{2}\right|\leqslant\left|x-y\right|. $$ 

于是， $ \forall \varepsilon > 0 $，取  $ \delta = \varepsilon $，则  $ \forall x, y \in \mathbb{R} $，只要  $ |x - y| < \delta $ 便有

 $$ \left|\cos x-\cos y\right|<\varepsilon. $$ 

所以  $ f(x)=\cos x $ 在  $ \mathbb{R} $ 上一致连续.