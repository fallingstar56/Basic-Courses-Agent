 $$ T^{\prime}(x)=\frac{x}{v_{1}\sqrt{x^{2}+h^{2}}}-\frac{d-x}{v_{2}\sqrt{(d-x)^{2}+b^{2}}}, $$ 

 $$ T^{\prime \prime}(x)=\frac{h^{2}}{v_{1}(x^{2}+h^{2})^{\frac{3}{2}}}+\frac{b^{2}}{v_{2}\left[(d-x)^{2}+b^{2}\right]^{\frac{3}{2}}}. $$ 

 $ T^{\prime\prime}(x)>0 $，故 $ T^{\prime}(x) $严格单调递增。由于 $ T^{\prime}(0)<0,T^{\prime}(d)>0 $，从而 $ T^{\prime}(x) $有唯一驻点 $ x_{0}\in(0,d) $，且在 $ [0,x_{0}) $内取负值，在 $ (x_{0},d) $内取正值。进而知 $ T(x) $在 $ [0,x_{0}) $内严格单调递减，在 $ (x_{0},d) $内严格单调递增，所以 $ x_{0} $为 $ T(x) $的最小值点，并且 $ x_{0} $满足等式

 $$ \frac{x_{0}}{v_{1}\sqrt{x_{0}^{2}+h^{2}}}=\frac{d-x_{0}}{v_{2}\sqrt{(d-x_{0})^{2}+b^{2}}}. $$ 

若记 $ \angle APM=\alpha,\angle BPQ=\beta $，则上面等式可改写为

 $$ \frac{\cos\alpha}{v_{1}}=\frac{\cos\beta}{v_{2}}. $$ 

这正是光的折射定律。

### 习题 4.4

1. 单调函数的导数是否单调？

2. 若  $ f'(x_{0})>0 $，是否有  $ f(x) $ 在  $ x_{0} $ 附近单调递增？如果是，请证明；如果不是，举出反例.

3. 若连续函数  $ f(x) $ 在  $ x_{0} $ 处取到极大值，试问是否存在  $ \delta>0 $，使得  $ f(x) $ 在  $ (x_{0}-\delta, x_{0}) $ 内单调递增，在  $ (x_{0}, x_{0}+\delta) $ 内单调递减？如果存在，请证明；如果不存在，举出反例.

4. 研究下列函数的单调性，有极值的求出极值.

(1)  $ y = \arctan x - x, x \in \mathbb{R} $; (2)  $ y = \left(1 + \frac{1}{x}\right)^x, x \in (0, 1) $;

(4)  $ y=2x^{3}-3x^{2}-12x+1 $;

(5) y =  $ \frac{2x^3 + 3x^2 - x - 4}{x^2 - 1} $;

(6)  $ y = \frac{x}{\ln x} $;

(7) $ y=\sin^{3}x+\cos^{3}x; $ (8) $ y=\frac{f(x)}{x},x>0, $其中 $ f(0)=0,f'(x) $单增；

(9) $ f(x)=(x-1)x^{\frac{2}{3}} $

5. 证明下列不等式.

(1)  $ e^{-x^{2}} \leqslant \frac{1}{1+x^{2}} $ (x > 0); (2)  $ \frac{1-x}{1+x} \leqslant e^{-2x} $ (0 \leqslant x \leqslant 1);

(3) $ \sin x+\cos x\geqslant1+x-x^{2}\quad(x\geqslant0) $; (4) $ 2\sqrt{x}>3-\frac{1}{x}\quad(x>1) $;