于是  $ \forall x, y \in [M, +\infty) $，有

 $$ \mid f(x)-f(y)\mid<\frac{\varepsilon}{2}. $$ 

另一方面， $ f\in C[a,M] $，由定理5.1.2，f在区间 $ [a,M] $上一致连续。故 $ \exists\delta>0 $，使得 $ \forall x,y\in[a,M] $，只要 $ |x-y|<\delta $，就有不等式(12)成立。由此知 $ \forall x,y\in[a,+\infty) $，且 $ |x-y|<\delta $，

(1) 若  $ x, y \in [a, M] $ 或  $ x, y \in [M, +\infty) $，则不等式 (12) 成立；

(2) 若  $ x \in [a, M] $,  $ y \in [M, +\infty) $，则  $ |x - M| < \delta $,  $ |M - y| < \delta $，于是

 $$ \mid f(x)-f(y)\mid\leqslant\mid f(x)-f(M)\mid+\mid f(M)-f(y)\mid<\varepsilon, $$ 

所以  $ f(x) $ 在  $ [a, +\infty) $ 上一致连续.

#### 5.1.4 可积函数类

定理 5.1.3 ……

若  $ f \in C[a, b] $，则  $ f \in R[a, b] $.

证明 由定理 5.1.2 有限闭区间上的连续函数一定是一致连续的，所以  $ \forall \varepsilon > 0, \exists \delta > 0 $，使得  $ \forall x, y \in [a, b] $，只要  $ |x - y| < \delta $，就有

 $$ \mid f(x)-f(y)\mid<\frac{\varepsilon}{b-a}. $$ 

令 T 为将  $ [a, b] $ n 等分的分割，则  $ |T| = \frac{b - a}{n} < \delta $，且由 (13) 式，

 $$ 0\leqslant M_{i}-m_{i}<\frac{\varepsilon}{b-a}(i=1,2,\cdots,n), $$ 

于是

 $$ U(f,T)-L(f,T)=\sum_{i=1}^{n}(M_{i}-m_{i})(x_{i}-x_{i-1})<\frac{\varepsilon}{b-a}\bullet(b-a)=\varepsilon. $$ 

应用定理 5.1.1 即得  $ f \in R[a, b] $.

定理 5.1.3 有下面推广.

定理 5.1.4 ……

设 f 在  $ [a,b] $ 上有界，且只有有限多个不连续点，则  $ f \in R[a,b] $.

证明 为叙述方便，不妨假定 f 在  $ [a, b] $ 上只有一个间断点 x = b 。由题设，f 在  $ [a, b] $ 上有界： $ |f(x)| \leqslant M(a \leqslant x \leqslant b) $， $ \forall \varepsilon > 0 $，取  $ c \in (a, b) $ 使得  $ b - c < \frac{\varepsilon}{4M} $。而 f 在  $ [a, c] $ 上连续，根据定理 5.1.3，f 在  $ [a, c] $ 上可积，因此存在  $ [a, c] $ 的一个分割  $ T_{1} $： $ a = x_{0} < x_{1} < \cdots < x_{n} = c $，使得