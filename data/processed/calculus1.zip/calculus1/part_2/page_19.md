#### ▶ 例 4.3.9

求 a 与 k 的值使得极限  $ \lim_{x\to0}\frac{e^{ax^{k}}-\cos(x^{2})}{x^{8}} $ 存在，并求出极限值.

解 将函数  $ \cos(x^{2}) $ 与  $ e^{ax^{*}} $ 分别展开为带皮亚诺余项的麦克劳林公式：

 $$ \cos(x^{2})=1-\frac{1}{2!}x^{4}+\frac{1}{4!}x^{8}+o(x^{8})\quad(x\rightarrow0), $$ 

 $$ \mathrm{e}^{ax^{k}}=1+ax^{k}+\frac{1}{2}(ax^{k})^{2}+o(x^{2k})\quad(x\rightarrow0). $$ 

于是

 $$ \mathrm{e}^{a x^{k}}-\cos(x^{2})=\frac{1}{2}x^{4}+a x^{k}+\frac{a^{2}}{2}x^{2k}-\frac{1}{4!}x^{8}+o(x^{2k})+o(x^{8}). $$ 

由此知，当  $ a=-\frac{1}{2} $ 且 k=4 时，极限  $ \lim_{x\to0}\frac{\mathrm{e}^{ax^{k}}-\cos(x^{2})}{x^{8}}=\frac{1}{12} $

▶ 例 4.3.10 .....

试证明不等式

 $$ \left|\frac{\sin x-\sin y}{x-y}-\cos y\right|\leqslant\frac{1}{2}\mid x-y\mid\quad(x,y\in\mathbb{R}). $$ 

证明 将函数  $ \sin x $ 在点 y 处展开为带拉格朗日余项的 1 阶泰勒公式：

 $$ \sin x=\sin y+(x-y)\cos y-\frac{1}{2}\left(x-y\right)^{2}\sin\xi, $$ 

其中  $ \xi $ 介于 x, y 之间。因此

 $$ \left|\frac{\sin x-\sin y}{x-y}-\cos y\right|=\frac{1}{2}\mid(x-y)\sin\xi\mid\leqslant\frac{1}{2}\mid x-y\mid. $$ 

设  $ f^{\prime\prime}(x) $ 在  $ [-1,1] $ 上连续，且  $ f(1)=1, f(-1)=0, f^{\prime}(0)=0. $ 求证：存在  $ \xi\in(-1,1) $，使得  $ f^{\prime\prime}(\xi)=3. $

证明 利用 f 的带拉格朗日余项的 2 阶麦克劳林公式，有

 $$ f(1)=f(0)+f^{\prime}(0)+\frac{1}{2}f^{\prime \prime}(0)+\frac{1}{6}f^{\prime \prime \prime}(\xi_{1})\quad(-1<\xi_{1}<1), $$ 

 $$ f(-1)=f(0)-f^{\prime}(0)+\frac{1}{2}f^{\prime \prime}(0)-\frac{1}{6}f^{\prime \prime \prime}(\xi_{2})(-1<\xi_{2}<1). $$ 

二式相减可得  $ f''(\xi_{1}) + f'''(\xi_{2}) = 6. $ 而  $ f''(x) $ 在  $ [-1,1] $ 上连续，根据连续函数的介值定理即知存在  $ \xi \in (\xi_{1}, \xi_{2}) \subseteq (-1,1) $，使得  $ f''(\xi) = 3. $

### 习题 4.3

1. 怎样理解“泰勒公式是函数在一点附近的性质”？