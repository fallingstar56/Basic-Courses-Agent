(2) 如果 f 在  $ (a, b) $ 内二阶可导，则 f 在  $ [a, b] $ 中下凸（上凸）的充分必要条件是在  $ (a, b) $ 内  $ f''(x) \geqslant 0 (\leqslant 0) $.

证明 这里只给出下凸情形的证明，上凸情形的证明留给读者来完成.

(1) 必要性 设 f 是区间 I 上的下凸函数. 任取  $ x_{1}, x_{2} \in (a, b) $ 且  $ x_{1} < x_{2} $.  $ \forall x \in (x_{1}, x_{2}) $, 根据定理 4.5.2, 不等式 (4) 成立:

 $$ \frac{f(x)-f(x_{1})}{x-x_{1}}\leqslant\frac{f(x_{2})-f(x_{1})}{x_{2}-x_{1}}\leqslant\frac{f(x_{2})-f(x)}{x_{2}-x}. $$ 

在左端与右端的不等式中分别令  $ x \rightarrow x_{1}^{+} $ 与  $ x \rightarrow x_{2}^{-} $，便得到

 $$ f^{\prime}(x_{1})=f^{\prime}_{+}(x_{1})\leqslant\frac{f(x_{2})-f(x_{1})}{x_{2}-x_{1}}\leqslant f^{\prime}_{-}(x_{2})=f^{\prime}(x_{2}), $$ 

由此知  $ f'(x) $ 在  $ (a,b) $ 单调递增.

充分性 设  $ f'(x) $ 在  $ (a,b) $ 单调递增. 对任意的  $ x_{1}, x_{2} \in (a,b) $, 以及  $ \lambda \in (0,1) $, 利用微分中值定理可得

 $$ \begin{align*}&\lambda f(x_{1})+(1-\lambda)f(x_{2})-f(\lambda x_{1}+(1-\lambda)x_{2})\\=&\lambda\big[f(x_{1})-f(\lambda x_{1}+(1-\lambda)x_{2})\big]+(1-\lambda)\big[f(x_{2})-f(\lambda x_{1}+(1-\lambda)x_{2})\big]\\=&\lambda(1-\lambda)(x_{1}-x_{2})f^{\prime}(\xi)+(1-\lambda)\lambda(x_{2}-x_{1})f^{\prime}(\eta)\\=&(1-\lambda)\lambda(x_{2}-x_{1})\big[f^{\prime}(\eta)-f^{\prime}(\xi)\big]\geqslant0.\end{align*} $$ 

其中  $ \xi $ 介于  $ x_{1} $ 与  $ \lambda x_{1} + (1 - \lambda)x_{2} $ 之间， $ \eta $ 介于  $ \lambda x_{1} + (1 - \lambda)x_{2} $ 与  $ x_{2} $ 之间，所以  $ \xi < \eta $。而  $ f'(x) $ 单调递增，所以

 $$ \lambda f(x_{1})+(1-\lambda)f(x_{2})-f(\lambda x_{1}+(1-\lambda)x_{2})\geqslant0. $$ 

这就得到了 f 的下凸性.

(2) 如果 f 在  $ (a, b) $ 内二阶可导，则  $ f'(x) $ 在  $ (a, b) $ 内单调递增当且仅当在  $ (a, b) $ 内  $ f''(x) \geqslant 0 $。再由(1)即得定理结论。

确定旋轮线 $ \left\{\begin{aligned}x=a(t-\sin t),\\ y=a(1-\cos t)\end{aligned}\right. $  $ (0\leqslant t\leqslant2\pi) $ 的凸性（图 4.5.3）.

解 曲线在  $ t \in [0, 2\pi] $ 上连续，在  $ t \in (0, 2\pi) $ 内有



 $$ \frac{\mathrm{d}y}{\mathrm{d}x}=\frac{\sin t}{1-\cos t}, $$ 

 $$ \frac{\mathrm{d}^{2}y}{\mathrm{d}x^{2}}=\frac{\frac{\mathrm{d}}{\mathrm{d}t}\left(\frac{\sin t}{1-\cos t}\right)}{\frac{\mathrm{d}x}{\mathrm{d}t}}=\frac{-1}{a\left(1-\cos t\right)^{2}}<0. $$ 

<div style="text-align: center;"><img src="imgs/img_in_chart_box_462_738_650_854.jpg" alt="Image" width="26%" /></div>


根据定理 4.5.3 可得曲线在  $ t \in [0, 2\pi] $ 上是上凸的.

<div style="text-align: center;">图 4.5.3</div>
