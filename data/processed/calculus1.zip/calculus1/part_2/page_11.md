设  $ \alpha > 0 $，计算  $ \lim_{x \to +\infty} \frac{\ln x}{x^a} = 0 $.

解  $ \lim_{x\to+\infty}\frac{\ln x}{x^{a}}=\lim_{x\to+\infty}\frac{x^{-1}}{ax^{a-1}}=\lim_{x\to+\infty}\frac{1}{ax^{a}}=0. $

▶ 例 4.2.5

计算  $ \lim_{x\to+\infty}\frac{\frac{\pi}{2}-\arctan x}{x^{-1}} $

解  $ \lim_{x\to+\infty}\frac{\frac{\pi}{2}-\arctan x}{x^{-1}}=\lim_{x\to+\infty}\frac{\frac{-1}{1+x^{2}}}{-x^{-2}}=1. $

设  $ f(x) $ 在  $ (a, +\infty) $ 内可导且  $ \lim_{x \to +\infty} [f'(x) + f(x)] = a $，证明  $ \lim_{x \to +\infty} f(x) = a $， $ \lim_{x \to +\infty} f'(x) = 0 $.

证明 由定理 4.2.3，

 $$ \begin{aligned}\lim_{x\to+\infty}f(x)&=\lim_{x\to+\infty}\frac{\mathrm{e}^{x}f(x)}{\mathrm{e}^{x}}=\lim_{x\to+\infty}\frac{(\mathrm{e}^{x}f(x))^{\prime}}{(\mathrm{e}^{x})^{\prime}}\\&=\lim_{x\to+\infty}(f(x)+f^{\prime}(x))=a.\end{aligned} $$ 

进而知  $ \lim_{x\to+\infty}f'(x)=0. $

以上讨论了 $ \frac{0}{0} $和 $ \frac{\infty}{\infty} $这两种基本不定型的极限问题，此外还常常会遇到形如 $ 0\cdot\infty,\infty-\infty,\infty^{0},0^{0},1^{\infty} $的不定型极限问题，常用的方法是把它们转化成以上两种基本不定型的极限进行计算.

计算 $ \lim_{x\to1}\left(\frac{x}{x-1}-\frac{1}{\ln x}\right) $

解 这是一个 $ \infty-\infty $型的不定型，通分化作 $ \frac{0}{0} $型：

 $$ \begin{aligned}\lim_{x\to1}\left(\frac{x}{x-1}-\frac{1}{\ln x}\right)&=\lim_{x\to1}\frac{x\ln x-x+1}{(x-1)\ln x}\\&=\lim_{x\to1}\frac{\ln x}{\frac{x-1}{x}+\ln x}=\lim_{x\to1}\frac{\frac{1}{x}}{\frac{1}{x^{2}}+\frac{1}{x}}=\frac{1}{2}.\end{aligned} $$ 