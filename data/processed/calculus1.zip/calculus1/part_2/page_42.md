由命题 5.1.2 不难证得（证明留给读者来完成）：对于  $ [a,b] $ 的任一分割 T，

 $$ L(f,T)\leqslant\int_{-a}^{b}f(x)\mathrm{d}x\leqslant\overline{\int_{a}^{b}}f(x)\mathrm{d}x\leqslant U(f,T). $$ 

有了以上准备，现在我们可以给出有界函数积分存在的条件。

定理 5.1.1

设 f 是  $ [a,b] $ 上的有界函数则下列命题等价：

(1)  $  f \in R[a, b]  $;

(2)  $ \forall \varepsilon > 0 $, 存在  $ [a, b] $ 的分割 T, 使得

 $$ U(f,T)-L(f,T)<\varepsilon; $$ 

(3)

 $$ \int_{a}^{b}f(x)\mathrm{d}x=\int_{a}^{b}f(x)\mathrm{d}x. $$ 

证明 (1)  $ \Rightarrow(2) $ 设  $ f \in R[a, b] $，记  $ I = \int_{a}^{b} f(x) \, dx $，根据积分定义， $ \forall \varepsilon > 0 $，存在  $ [a, b] $ 的分割 T，使得无论  $ \xi_i \in [x_{i-1}, x_i] $ 如何取，都有

 $$ \left|\sum_{i=1}^{n}f(\xi_{i})(x_{i}-x_{i-1})-I\right|<\frac{\varepsilon}{3}. $$ 

在(6)式的两端依次对  $ \xi_{i} \in [x_{i-1}, x_{i}] $ 取上确界， $ i = 1, 2, \cdots, n $，便得到

 $$ \left|U(f,T)-I\right|\leqslant\frac{\varepsilon}{3}. $$ 

同理，

 $$ \left|L(f,T)-I\right|\leqslant\frac{\varepsilon}{3}. $$ 

从而(5)式成立.

(2)  $ \Rightarrow(3) $ 由(2)， $ \forall\varepsilon>0 $，

 $$ 0\leqslant\overline{\int_{a}^{b}}f(x)\mathrm{d}x-\int_{a}^{b}f(x)\mathrm{d}x\leqslant U(f,T)-L(f,T)<\varepsilon. $$ 

所以(3)成立.

(3)  $ \Rightarrow(1) $ 记  $ I=\int_{-a}^{b}f(x)dx=\int_{-a}^{b}f(x)dx. $ 由上积分定义， $ \forall\varepsilon>0 $，存在  $ [a,b] $ 的分割  $ T_{0}:a=t_{0}<t_{1}<\cdots<t_{k}=b $，使得

 $$ 0\leqslant U(f,T_{0})-I<\varepsilon/2. $$ 

取  $ \delta_{1}=\frac{\varepsilon}{2k(M-m)} $，其中 M 与 m 分别为 f 在  $ [a,b] $ 上的上确界与下确界。对于  $ [a,b] $ 的任一满足  $ |T|<\delta_{1} $ 的分割 T，将 T 与  $ T_{0} $ 的分点合并而得到的  $ [a,b] $ 的分割记为  $ T' $，由命题 5.1.1（(2)式）及(7)式可得

 $$ \begin{aligned}&0\leqslant U(f,T)-I\leqslant U(f,T^{\prime})+k\mid T\mid(M-m)-I\\&\leqslant U(f,T_{0})-I+k\mid T\mid(M-m)<\epsilon.\\ \end{aligned} $$ 