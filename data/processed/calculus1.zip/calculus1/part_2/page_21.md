8. 证明下列不等式：

 $$ \left|\frac{\ln\frac{x}{y}}{x-y}-\frac{1}{y}\right|\leqslant\frac{1}{2}\mid x-y\mid\quad(x,y\geqslant1,x\neq y). $$ 

9. 设函数  $ y = f(x) $ 在  $ [0, 1] $ 上有连续的三阶导数，且  $ f(0) = f'\left(\frac{1}{2}\right) = 0 $， $ f(1) = \frac{1}{2} $。证明： $ \exists \xi \in (0, 1) $，使得  $ f''(\xi) = 12 $。

10. 设函数  $ y = f(x) $ 在  $ [a, b] $ 上二阶可导，证明： $ \exists \xi \in (a, b) $，使得

 $$ f(b)-2f\Big(\frac{a+b}{2}\Big)+f(a)=\frac{(b-a)^{2}}{4}f^{\prime \prime}(\xi). $$ 

11. 设  $ h > 0, f(x) $ 在  $ [x_{0} - h, x_{0} + h] $ 上可导. 求证：存在  $ 0 < \theta < 1 $，使得

 $$ f(x_{0}+h)-f(x_{0}-h)=\left[f^{\prime}(x_{0}+\theta h)+f^{\prime}(x_{0}-\theta h)\right]h. $$ 

12. 设函数  $ f \in C^{1}[a, b] $，在  $ (a, b) $ 上二阶可导，且  $ f'(a) = f'(b) = 0 $。求证  $ \exists \xi \in (a, b) $ 使得

 $$ \mid f^{\prime \prime}(\xi)\mid\geqslant\frac{4}{(b-a)^{2}}\mid f(b)-f(a)\mid. $$ 

### 4.4 函数的增减性与极值问题

#### 4.4.1 函数的增减性

利用微分中值定理可以得到下列关于函数增减性的判定方法.

定理 4.4.1

设函数 f 在  $ [a,b] $ 上连续，在  $ (a,b) $ 内可导，则

(1) f 在  $ [a, b] $ 上单调递增（递减）的充分必要条件是在  $ (a, b) $ 内  $ f'(x) \geqslant 0 (\leqslant 0) $;

(2) f 在  $ [a, b] $ 上严格单调递增（递减）的充分必要条件是在  $ (a, b) $ 内  $ f'(x) \geqslant 0 (\leqslant 0) $，并且在  $ (a, b) $ 的任何子区间  $ (c, d) $ 内  $ f'(x) $ 不恒等于零.

下面只对单调递增的情形给出证明，对单调递减的情形可类似地得到.

证明 （1）必要性 设 f 在  $ [a, b] $ 上单调递增，则  $ \forall x \in (a, b) $，当  $ x + h \in (a, b) $ 时有

 $$ \frac{f(x+h)-f(x)}{h}\geqslant0, $$ 

于是

 $$ f^{\prime}(x)=\lim_{h\to0}\frac{f(x+h)-f(x)}{h}\geqslant0. $$ 