而当 $ x_{0}>x>x_{0}-\rho $时，

 $$ \frac{f(x)-f(x_{0})}{x-x_{0}}\leqslant0, $$ 

所以

 $$ f^{\prime}(x_{0})=f_{-}^{\prime}(x_{0})=\lim_{x\to x_{0}^{-}}\frac{f(x)-f(x_{0})}{x-x_{0}}\leqslant.0. $$ 

联立(1)和(2)式，便知 $ f'(x_{0})=0 $.

定理 4.1.2（罗尔定理）

设函数 f 在闭区间  $ [a, b] $ 上连续，在开区间  $ (a, b) $ 内可导。如果  $ f(a) = f(b) $，则存在  $ \xi \in (a, b) $，使得（见图 4.1.1）

 $$ f^{\prime}(\xi)=0. $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_243_355_501_466.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;">图 4.1.1</div>


证明 由于  $ f \in C[a, b] $，所以 f 在  $ [a, b] $ 上可以取得最大值 M 和最小值 m.

如果  $ M = m = f(a) = f(b) $，则 f 在  $ [a, b] $ 上恒为常数，此时由导数定义， $ \forall x \in (a, b) $，都有  $ f'(x) = 0 $.

如果 M 与 m 之中至少有一个与  $ f(a) $ 不相等，不妨设  $ M > f(a) $，于是存在  $ \xi \in (a, b) $，使得  $ M = f(\xi) $。显然  $ \xi $ 是 f 的一个极大值点，由定理 4.1.1 便知  $ f'(\xi) = 0 $。

定理 4.1.3（柯西中值定理）

设函数 f, g 都在闭区间  $ [a, b] $ 上连续，在开区间  $ (a, b) $ 内可导，并且在  $ (a, b) $ 中  $ g'(x) \neq 0 $，则存在  $ \xi \in (a, b) $，使得

 $$ \frac{f^{\prime}(\xi)}{g^{\prime}(\xi)}=\frac{f(b)-f(a)}{g(b)-g(a)}. $$ 

证明 由于  $ g'(x) \neq 0 (x \in (a, b)) $，所以由罗尔定理可以推知  $ g(b) \neq g(a) $。作辅助函数

 $$ \varphi(x)=\left[f(x)-f(a)\right]-\frac{f(b)-f(a)}{g(b)-g(a)}\big[g(x)-g(a)\big], $$ 

易见  $ \varphi $ 在  $ [a,b] $ 上连续，在  $ (a,b) $ 内可导，并且  $ \varphi(a)=\varphi(b)=0 $，于是由罗尔定理