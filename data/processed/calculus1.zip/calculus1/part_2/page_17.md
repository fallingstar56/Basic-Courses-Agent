多项式，即

 $$ a_{0}+a_{1}(x-x_{0})+\cdots+a_{n}(x-x_{0})^{n}=o((x-x_{0})^{n})(x\rightarrow x_{0}), $$ 

由式(7)便知 $ a_{0}=0 $.再将等式(7)两端同除以 $ x-x_{0} $可得

 $$ a_{1}+a_{2}(x-x_{0})+\cdots+a_{n}(x-x_{0})^{n-1}=o((x-x_{0})^{n-1})(x\rightarrow x_{0}). $$ 

进而知  $ a_{1}=0 $ ，如此进行下去，便可得到  $ a_{0}=a_{1}=\cdots=a_{n}=0 $ ，从而  $ Q_{n}(x)\equiv P_{n}(x) $.

在上面几个例题中，要得到 f 在点  $ x_{0} $ 的 n 阶泰勒多项式，需要依次计算出 f 在点  $ x_{0} $ 的 1~n 阶导数，这往往是一件比较烦琐的事情。而定理 4.3.3 为我们提供了求 f 在点  $ x_{0} $ 带皮亚诺余项的 n 阶泰勒公式的另一种方法——间接展开法。

#### ▶ 例 4.3.5

求  $ f(x)=\frac{1}{2x-x^{2}} $ 在点  $ x_{0}=1 $ 处带皮亚诺余项的 2n 阶泰勒公式.

解 在例 4.3.4 中，若取 a=-1，则得函数  $ \frac{1}{1+t} $ 的 n 阶麦克劳林公式为

 $$ \frac{1}{1+t}=1-t+t^{2}-\cdots+(-1)^{n}t^{n}+o(t^{n})\quad(t\rightarrow0). $$ 

用-t代替t，即得

 $$ \frac{1}{1-t}=1+t+t^{2}+\cdots+t^{n}+o(t^{n})\quad(t\rightarrow0). $$ 

再令  $ t=(x-1)^{2} $，则当  $ x\rightarrow1 $ 时有

 $$ \begin{aligned}\frac{1}{2x-x^{2}}&=\frac{1}{1-(x-1)^{2}}\\&=1+(x-1)^{2}+(x-1)^{4}+\cdots+(x-1)^{2n}+o((x-1)^{2n}).\end{aligned} $$ 

根据定理 4.3.3，此式即为 f 在点  $ x_{0}=1 $ 处带皮亚诺余项的 2n 阶泰勒公式.

求  $ f(x)=\mathrm{e}^{\sin^{2}x} $ 带皮亚诺余项的 4 阶麦克劳林公式.

解 函数  $ \sin x $ 与  $ e^{x} $ 的带皮亚诺余项的麦克劳林公式分别为

 $$ \sin x=x-\frac{x^{3}}{3!}+o(x^{3})\quad(x\rightarrow0), $$ 

 $$ \mathrm{e}^{u^{2}}=1+u^{2}+\frac{u^{4}}{2!}+o(u^{4})(u\rightarrow0). $$ 

由于当  $ x \rightarrow 0 $ 时  $ u = \sin x \sim x $，于是

 $$ \begin{aligned}\mathrm{e}^{\sin^{2}x}&=1+\left[x-\frac{x^{3}}{3!}+o(x^{3})\right]^{2}+\frac{1}{2!}\left[x-\frac{x^{3}}{3!}+o(x^{3})\right]^{4}+o(x^{4})\\&=1+x^{2}+\frac{1}{6}x^{4}+o(x^{4})\quad(x\rightarrow0).\end{aligned} $$ 