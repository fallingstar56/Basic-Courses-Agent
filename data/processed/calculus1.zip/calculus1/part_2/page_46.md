 $$ U(f,T_{1})-L(f,T_{1})<\varepsilon/2. $$ 

现在考虑区间 $ [a,b] $的分割 $ T_{2} $: $ a=x_{0},x_{1},\cdots,x_{n-1},c,b $，由于

 $$ \sup\{f(x)\mid c\leqslant x\leqslant b\}-\inf\{f(x)\mid c\leqslant x\leqslant b\}\leqslant2M, $$ 

于是

 $$ \begin{aligned}&0\leqslant U(f,T_{2})-L(f,T_{2})\\ &\leqslant\left[U(f,T_{1})-L(f,T_{1})\right]+2M\bullet\frac{\varepsilon}{4M}<\frac{\varepsilon}{2}+\frac{\varepsilon}{2}\\ &=\varepsilon.\\ \end{aligned} $$ 

由定理 5.1.1 即得  $ f \in R[a, b] $.

▶ 例 5.1.5

设  $ f \in C[0,1] $，且  $ m \leqslant f(x) \leqslant M, x \in [0,1] $。又设 g 为  $ [m,M] $ 上连续的下凸函数，求证：

 $$ g\Big(\int_{0}^{1}f(x)\mathrm{d}x\Big)\leqslant\int_{0}^{1}g(f(x))\mathrm{d}x. $$ 

证明 f 与 g 连续，故  $ g \circ f $ 连续。根据定理 5.1.3，f 与  $ g \circ f $ 在  $ [0,1] $ 上可积。又因为 g 是  $ [m,M] $ 上的下凸函数，所以  $ \forall n \in \mathbb{N}^* $，

 $$ g\Big(\sum_{i=1}^{n}\frac{1}{n}f\Big(\frac{i}{n}\Big)\Big)\leqslant\sum_{i=1}^{n}\frac{1}{n}g\Big(f\Big(\frac{i}{n}\Big)\Big). $$ 

令  $ n \rightarrow \infty $ 即得(14)式.

定理 5.1.5 ……

若 f 在  $ [a,b] $ 上单调，则  $ f \in R[a,b] $.

证明 只考虑 f 为单调递增的情形，对单调递减的情形可类似证得.

如果  $ f(a)=f(b) $，则 f 为  $ [a,b] $ 上的常值函数，此时显然有  $ f\in R[a,b] $。下面设  $ f(a)<f(b) $。 $ \forall\varepsilon>0 $，取  $ [a,b] $ 的分割 T，使得

 $$ \mid T\mid=\max_{1\leqslant i\leqslant n}(x_{i}-x_{i-1})<\frac{\varepsilon}{f(b)-f(a)}. $$ 

于是

 $$ \begin{aligned}&0\leqslant U(f,T)-L(f,T)=\sum_{i=1}^{n}(f(x_{i})-f(x_{i-1}))(x_{i}-x_{i-1})\\&\leqslant\left|T\right|\sum_{i=1}^{n}\left[f(x_{i})-f(x_{i-1})\right]=\left|T\right|(f(b)-f(a))\\&<\frac{\varepsilon}{f(b)-f(a)}\bullet\left[f(b)-f(a)\right]=\varepsilon.\\ \end{aligned} $$ 

由定理 5.1.1 即得  $ f \in R[a, b] $.

从以上讨论可以看到， $ [a,b] $上可积函数 f 在  $ [a,b] $ 上只允许有“不太多”的